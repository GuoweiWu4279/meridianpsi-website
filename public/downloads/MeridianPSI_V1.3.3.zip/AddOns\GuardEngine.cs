﻿// GuardEngine.cs
//
// Runtime evaluation engine for the Guard protection system.
//
// Responsibilities:
//   • Load / save GuardConfig (list of GuardRules) to guard.xml
//   • Evaluate all rules on every PSI update (called from PushPsiToHud)
//   • Fire the Triggered event when a rule's conditions are met
//   • Track the disconnect-lock timer (prevents re-evaluation during lockout)
//   • Expose active RiskAlert rules for HUD banner rendering
//   • ForceReset — emergency override that clears all runtime state
//
// No NinjaTrader API dependencies — UI dispatch and broker actions are
// handled by MeridianPSI which subscribes to the Triggered event.

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================================
    // GuardTrigger — payload delivered with the Triggered event
    // =========================================================================

    public class GuardTrigger
    {
        public GuardRule       Rule    { get; set; }
        public GuardActionType Action  { get; set; }
        public string          Message { get; set; }
    }

    // =========================================================================
    // GuardEngine
    // =========================================================================

    public sealed class GuardEngine
    {
        // ── Data directory (injected at startup, same pattern as other data files)
        private static string _dataDir;
        internal static void SetDataDir(string path)
        {
            if (!string.IsNullOrEmpty(path)) _dataDir = path;
        }
        private static string ConfigPath =>
            Path.Combine(_dataDir ?? "", "guard.xml");

        private static readonly XmlSerializer _serializer =
            new XmlSerializer(typeof(GuardConfig));

        // ── State ─────────────────────────────────────────────────────────────
        private GuardConfig          _config          = new GuardConfig();
        private DateTime             _disconnectUntil = DateTime.MinValue;
        private readonly object      _sync            = new object();
        private Action<string>       _logWarning;

        // ── Public properties ─────────────────────────────────────────────────

        public bool MasterEnabled
        {
            get { lock (_sync) return _config.MasterEnabled; }
            set { lock (_sync) _config.MasterEnabled = value; SaveConfig(); }
        }

        public bool IsDisconnectActive
        {
            get { lock (_sync) return DateTime.Now < _disconnectUntil; }
        }

        public TimeSpan DisconnectRemaining
        {
            get
            {
                lock (_sync)
                {
                    var rem = _disconnectUntil - DateTime.Now;
                    return rem > TimeSpan.Zero ? rem : TimeSpan.Zero;
                }
            }
        }

        public IReadOnlyList<GuardRule> Rules
        {
            get { lock (_sync) return _config.Rules.AsReadOnly(); }
        }

        /// <summary>
        /// Returns the names of all currently-active RiskAlert rules whose condition
        /// is still met.  Used by the HUD banner renderer to show a live status string.
        /// Returns an empty list when no RiskAlert is active.
        /// </summary>
        public IReadOnlyList<string> ActiveRiskAlertNames
        {
            get
            {
                lock (_sync)
                    return _config.Rules
                        .Where(r => r.Enabled && r.Action == GuardActionType.RiskAlert && r.RiskAlertActive)
                        .Select(r => r.Name)
                        .ToList()
                        .AsReadOnly();
            }
        }

        /// <summary>True if any enabled RiskAlert rule currently has its condition met.</summary>
        public bool IsRiskAlertActive
        {
            get
            {
                lock (_sync)
                    return _config.Rules.Any(r =>
                        r.Enabled && r.Action == GuardActionType.RiskAlert && r.RiskAlertActive);
            }
        }

        // ── Events ────────────────────────────────────────────────────────────

        /// <summary>
        /// Fired on the calling thread (NT8 event thread) when a rule triggers.
        /// Subscribers must dispatch to the UI thread themselves.
        /// </summary>
        public event Action<GuardTrigger> Triggered;

        // =====================================================================
        // Load / Save
        // =====================================================================

        public static GuardEngine LoadFromFile(Action<string> logWarning = null)
        {
            var engine = new GuardEngine();
            engine._logWarning = logWarning;
            if (string.IsNullOrEmpty(_dataDir) || !File.Exists(ConfigPath))
                return engine;
            try
            {
                using (var sr = new StreamReader(ConfigPath))
                    engine._config = (GuardConfig)_serializer.Deserialize(sr);
            }
            catch (Exception ex)
            {
                logWarning?.Invoke($"[Guard] Failed to load config: {ex.Message}");
            }
            return engine;
        }

        public void SaveConfig()
        {
            if (string.IsNullOrEmpty(_dataDir)) return;
            try
            {
                Directory.CreateDirectory(_dataDir);
                lock (_sync)
                using (var sw = new StreamWriter(ConfigPath))
                    _serializer.Serialize(sw, _config);
            }
            catch (Exception ex)
            {
                _logWarning?.Invoke($"[Guard] SaveConfig failed — rule changes were NOT persisted: {ex.Message}");
            }
        }

        // =====================================================================
        // Rule management (called from the Guard UI tab)
        // =====================================================================

        public void AddRule(GuardRule rule)
        {
            lock (_sync) _config.Rules.Add(rule);
            SaveConfig();
        }

        public void UpdateRule(GuardRule rule)
        {
            lock (_sync)
            {
                int idx = _config.Rules.FindIndex(r => r.Id == rule.Id);
                if (idx >= 0) _config.Rules[idx] = rule;
            }
            SaveConfig();
        }

        public void DeleteRule(string id)
        {
            lock (_sync) _config.Rules.RemoveAll(r => r.Id == id);
            SaveConfig();
        }

        // =====================================================================
        // Emergency override — clears all runtime state without touching rules
        // =====================================================================

        /// <summary>
        /// Clears every runtime latch, counter, and lock timer without modifying
        /// the rules themselves.  Called by the Emergency Override button in the
        /// Guard settings UI.  The action is logged by the caller (MeridianPSI).
        /// </summary>
        public void ForceReset()
        {
            lock (_sync)
            {
                _disconnectUntil = DateTime.MinValue;
                foreach (var r in _config.Rules)
                {
                    // Stamp LastTriggeredUtc to NOW so the rule enters its normal
                    // CooldownMinutes window — prevents it from immediately re-firing
                    // on the next PushPsiToHud evaluation while the underlying condition
                    // is still true.  WasConditionMet=true acts as a secondary gate for
                    // rules whose CooldownMinutes is 0 (IsInCooldown() is always false
                    // in that case, so the latch is the only re-fire barrier).
                    r.LastTriggeredUtc  = DateTime.UtcNow;
                    r.WasConditionMet   = true;
                    r.FirstMetUtc       = DateTime.MinValue;
                    r.ConditionMetCount = 0;
                    r.RiskAlertActive   = false;
                }
            }
        }

        // =====================================================================
        // Evaluation — called from PushPsiToHud on every PSI update
        // =====================================================================

        public void Evaluate(GuardContext ctx)
        {
            List<GuardRule> snapshot;
            bool masterEnabled;
            lock (_sync)
            {
                masterEnabled = _config.MasterEnabled;
                snapshot = new List<GuardRule>(_config.Rules);
            }

            if (!masterEnabled) return;

            // While a disconnect is active, don't pile on more actions.
            if (IsDisconnectActive) return;

            // ── Pass 1: evaluate all rules, updating latches (WasConditionMet,
            //   RiskAlertActive).  Collect the subset that actually want to fire.
            var toFire = new List<GuardRule>();
            foreach (var rule in snapshot)
            {
                if (rule.Evaluate(ctx))
                    toFire.Add(rule);
            }
            if (toFire.Count == 0) return;

            // ── Pass 2: find the highest priority among BLOCKING actions
            //   (Acknowledge / Countdown / Disconnect).  Toast and RiskAlert
            //   are non-blocking and always fire regardless.
            //
            //   Priority: Disconnect=5, Countdown=4, Acknowledge=3, RiskAlert=2, Toast=1
            //
            //   When PSI drops through multiple thresholds in a single tick
            //   (e.g. PSI 70→20 passing Acknowledge @60, Countdown @40, Disconnect @25)
            //   without this gate ALL THREE would produce dialogs simultaneously.
            //   The gate ensures only the most severe blocking action is shown;
            //   the lower-priority ones already have WasConditionMet=true so they
            //   will not re-fire unless their condition clears and re-enters.
            int maxBlocking = 0;
            foreach (var rule in toFire)
            {
                int p = ActionPriority(rule.Action);
                if (p >= 3 && p > maxBlocking) maxBlocking = p;
            }

            // ── Pass 3: fire triggers, suppressing blocking actions below the max.
            foreach (var rule in toFire)
            {
                int p = ActionPriority(rule.Action);

                // Non-blocking (Toast=1, RiskAlert=2): always fire.
                // Blocking (>=3): only fire if at the max priority level.
                if (p >= 3 && p < maxBlocking)
                    continue;

                // Mark cooldown for rules that actually fire.
                rule.LastTriggeredUtc = DateTime.UtcNow;

                if (rule.Action == GuardActionType.Disconnect)
                {
                    lock (_sync)
                        _disconnectUntil = DateTime.Now.AddMinutes(
                            Math.Max(1, rule.LockMinutes));
                }

                string message = string.IsNullOrWhiteSpace(rule.CustomMessage)
                    ? BuildDefaultMessage(rule, ctx)
                    : rule.CustomMessage;

                Triggered?.Invoke(new GuardTrigger
                {
                    Rule    = rule,
                    Action  = rule.Action,
                    Message = message,
                });

                if (rule.Action == GuardActionType.Disconnect) return;
            }
        }

        private static int ActionPriority(GuardActionType a)
        {
            switch (a)
            {
                case GuardActionType.Disconnect:  return 5;
                case GuardActionType.Countdown:   return 4;
                case GuardActionType.Acknowledge: return 3;
                case GuardActionType.RiskAlert:   return 2;
                case GuardActionType.Toast:       return 1;
                default:                          return 0;
            }
        }

        /// <summary>Manually clear the disconnect lock (user override).</summary>
        public void ClearDisconnect()
        {
            lock (_sync) _disconnectUntil = DateTime.MinValue;
        }

        // =====================================================================
        // Helpers
        // =====================================================================

        private static string BuildDefaultMessage(GuardRule rule, GuardContext ctx)
        {
            var parts = new System.Text.StringBuilder();
            parts.AppendLine($"Guard: {rule.Name}");
            parts.AppendLine();
            foreach (var c in rule.Conditions)
            {
                switch (c.Type)
                {
                    case GuardConditionType.PsiBelow:
                        parts.AppendLine($"• PSI {ctx.Psi:F0} dropped below your threshold of {c.Threshold}");
                        break;
                    case GuardConditionType.ConsecutiveLossesAtLeast:
                        parts.AppendLine($"• {ctx.ConsecutiveLosses:F0} consecutive losses (your limit: {c.Threshold})");
                        break;
                    case GuardConditionType.SessionPnlBelow:
                        parts.AppendLine($"• Session P&L −${Math.Abs(ctx.SessionPnl):F0} (your limit: −${c.Threshold})");
                        break;
                    case GuardConditionType.SessionMinutesOver:
                        parts.AppendLine($"• {ctx.SessionMinutes:F0} min trading (your limit: {c.Threshold} min)");
                        break;
                    case GuardConditionType.UnrealizedPnlBelow:
                        parts.AppendLine($"• Floating loss −${Math.Abs(ctx.UnrealizedPnl):F0} (your limit: −${c.Threshold})");
                        break;
                    case GuardConditionType.SingleTradeLossExceeds:
                        parts.AppendLine($"• Last trade lost ${Math.Abs(ctx.LastTradePnl):F0} (your limit: ${c.Threshold})");
                        break;
                }
            }
            parts.AppendLine();
            parts.Append("This is a rule you set for yourself.");
            return parts.ToString().TrimEnd();
        }
    }
}
