﻿// IntelligenceWindow.cs
//
// PSI Intelligence tab — behavioral analytics page.
// Sections (top to bottom, all scrollable):
//   1. Pre-Session Risk Brief
//   2. Monthly Digest  (◀ MMMM YYYY ▶)
//   3. PSI × Performance Correlation table
//   4. Weekday Heatmap
//   5. Progress Trend (6-month sparkline)
//   6. Crash Triggers ranking
//
// This is a Window subclass so MeridianDashboard can transplant its body
// via TransplantWindowBody(), identical to HistoryWindow and SessionReportWindow.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal sealed class IntelligenceWindow : Window
    {
        // ── Data ──────────────────────────────────────────────────────────────
        private readonly List<SessionHistoryEntry> _sessions;

        // ── Navigation state ─────────────────────────────────────────────────
        private DateTime _currentMonth;

        // ── Live rebuild targets ──────────────────────────────────────────────
        private StackPanel _root;   // rebuilt on month navigation

        // ── Apple-style palette (matches SessionReportWindow) ─────────────────
        private static readonly Brush FgPrimary   = new SolidColorBrush(Color.FromRgb(245, 245, 247));
        private static readonly Brush FgSecondary = new SolidColorBrush(Color.FromRgb(174, 174, 178));
        private static readonly Brush FgHint      = new SolidColorBrush(Color.FromRgb(99,  99,  102));
        private static readonly Brush FgAccent    = new SolidColorBrush(Color.FromRgb(10,  132, 255));
        private static readonly Brush BgWindow    = new SolidColorBrush(Color.FromRgb(28,  28,  30));
        private static readonly Brush BgCard      = new SolidColorBrush(Color.FromRgb(38,  38,  40));
        private static readonly Brush BgHeader    = new SolidColorBrush(Color.FromRgb(44,  44,  46));
        private static readonly Color ColStable      = Color.FromRgb( 48, 209,  88);
        private static readonly Color ColYellowGreen = Color.FromRgb(163, 213,  72);
        private static readonly Color ColCaution     = Color.FromRgb(255, 214,   0);
        private static readonly Color ColCritical    = Color.FromRgb(255,  69,  58);

        private static Color CompColor(double pct) =>
            pct >= 85 ? ColStable :
            pct >= 70 ? ColYellowGreen :
            pct >= 50 ? ColCaution : ColCritical;
        private static readonly Color ColAccent   = Color.FromRgb( 10, 132, 255);

        private static readonly string[] DayShort = { "Mon", "Tue", "Wed", "Thu", "Fri" };

        // =====================================================================
        // Constructor
        // =====================================================================

        internal IntelligenceWindow(List<SessionHistoryEntry> sessions)
        {
            _sessions     = sessions ?? new List<SessionHistoryEntry>();
            _currentMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);

            WindowStyle        = WindowStyle.None;
            AllowsTransparency = true;
            Background         = Brushes.Transparent;
            ResizeMode         = ResizeMode.NoResize;
            ShowInTaskbar      = false;
            Title              = "PSI Intelligence";
            Width              = 480;
            Height             = 640;

            var outer = new Border
            {
                CornerRadius    = new CornerRadius(14),
                Background      = BgWindow,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(44) });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // ── Header ───────────────────────────────────────────────────────
            var hdr     = new Border { Background = BgHeader };
            var hdrGrid = new Grid();
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            hdrGrid.Children.Add(new TextBlock
            {
                Text              = "PSI INTELLIGENCE",
                FontSize          = 12,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(14, 0, 0, 0),
            });

            var closeBtn = MakeHeaderBtn("✕");
            closeBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; Close(); };
            Grid.SetColumn(closeBtn, 1);
            hdrGrid.Children.Add(closeBtn);

            hdr.Child = hdrGrid;
            Grid.SetRow(hdr, 0);
            root.Children.Add(hdr);

            // ── Scrollable body ───────────────────────────────────────────────
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Padding = new Thickness(12, 8, 12, 16),
            };

            _root = new StackPanel { Orientation = Orientation.Vertical };
            scroll.Content = _root;
            Grid.SetRow(scroll, 1);
            root.Children.Add(scroll);

            outer.Child = root;
            Content     = outer;

            BuildPage();
        }

        // =====================================================================
        // Page builder — called on initial render and on month navigation
        // =====================================================================

        private void BuildPage()
        {
            _root.Children.Clear();

            var all = _sessions.Where(s => s.TotalTrades > 0).ToList();

            BuildRiskBrief(all);
            BuildMonthlyDigest(all);
            BuildPsiPerfCorrelation(all);
            BuildWeekdayHeatmap(all);
            BuildProgressTrend(all);
            BuildCrashTriggers(all);
        }

        // =====================================================================
        // Section 1: Pre-Session Risk Brief
        // =====================================================================

        private void BuildRiskBrief(List<SessionHistoryEntry> sessions)
        {
            _root.Children.Add(SectionHeader("TODAY'S RISK BRIEF"));

            var brief = IntelligenceEngine.ComputeRiskBrief(sessions);
            var card  = Card();
            var inner = CardInner(card);

            if (!brief.HasEnoughData)
            {
                inner.Children.Add(Placeholder(brief.RecommendationText));
                _root.Children.Add(card);
                return;
            }

            // ── Risk score headline ──────────────────────────────────────────
            Color riskColor = brief.RiskScore >= 70 ? ColCritical
                            : brief.RiskScore >= 50 ? ColCaution
                            : brief.RiskScore >= 30 ? Color.FromRgb(90, 200, 250)
                            : ColStable;

            var headline = new Grid { Margin = new Thickness(0, 0, 0, 8) };
            headline.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            headline.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            headline.Children.Add(new TextBlock
            {
                Text              = $"Today — {DateTime.Today:dddd, MMMM d}",
                FontSize          = 12,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgPrimary,
                VerticalAlignment = VerticalAlignment.Center,
            });

            var riskLbl = new Border
            {
                Background    = new SolidColorBrush(Color.FromArgb(40,
                    riskColor.R, riskColor.G, riskColor.B)),
                CornerRadius  = new CornerRadius(6),
                Padding       = new Thickness(8, 3, 8, 3),
                VerticalAlignment = VerticalAlignment.Center,
                Child = new TextBlock
                {
                    Text       = $"{brief.RiskLabel} Risk  ·  {brief.RiskScore}/100",
                    FontSize   = 11,
                    FontFamily = new FontFamily("Segoe UI"),
                    FontWeight = FontWeights.SemiBold,
                    Foreground = new SolidColorBrush(riskColor),
                },
            };
            Grid.SetColumn(riskLbl, 1);
            headline.Children.Add(riskLbl);
            inner.Children.Add(headline);

            // ── Risk factors ─────────────────────────────────────────────────
            foreach (var f in brief.Factors)
            {
                Color fc = f.IsGood ? ColStable
                         : f.Delta >= 15 ? ColCritical
                         : ColCaution;
                string icon = f.IsGood ? "✓" : f.Delta >= 15 ? "⚠" : "·";

                inner.Children.Add(new TextBlock
                {
                    Text         = $"{icon}  {f.Reason}",
                    FontSize     = 11,
                    FontFamily   = new FontFamily("Segoe UI"),
                    Foreground   = new SolidColorBrush(fc),
                    TextWrapping = TextWrapping.Wrap,
                    Margin       = new Thickness(0, 3, 0, 0),
                });
            }

            // ── Recommendation ────────────────────────────────────────────────
            inner.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(25, 255, 255, 255)),
                Margin     = new Thickness(0, 8, 0, 8),
            });
            inner.Children.Add(new TextBlock
            {
                Text         = brief.RecommendationText,
                FontSize     = 11,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                FontStyle    = FontStyles.Italic,
            });

            _root.Children.Add(card);
        }

        // =====================================================================
        // Section 2: Monthly Digest
        // =====================================================================

        private void BuildMonthlyDigest(List<SessionHistoryEntry> sessions)
        {
            // ── Month navigation header ───────────────────────────────────────
            var navBar  = new Grid { Margin = new Thickness(0, 12, 0, 0) };
            navBar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            navBar.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            navBar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var available     = IntelligenceEngine.GetAvailableMonths(sessions);
            bool canGoPrev    = available.Count > 0 && _currentMonth > available.First();
            bool canGoNext    = _currentMonth < new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);

            var prevBtn = MakeNavArrow("◀", canGoPrev);
            var nextBtn = MakeNavArrow("▶", canGoNext);

            if (canGoPrev)
                prevBtn.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    _currentMonth = _currentMonth.AddMonths(-1);
                    BuildPage();
                };
            if (canGoNext)
                nextBtn.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    _currentMonth = _currentMonth.AddMonths(1);
                    BuildPage();
                };

            var monthLabel = new TextBlock
            {
                Text                = $"MONTHLY DIGEST  ·  {_currentMonth:MMMM yyyy}".ToUpper(),
                FontSize            = 10,
                FontFamily          = new FontFamily("Segoe UI"),
                FontWeight          = FontWeights.SemiBold,
                Foreground          = FgSecondary,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
            };

            Grid.SetColumn(prevBtn,    0);
            Grid.SetColumn(monthLabel, 1);
            Grid.SetColumn(nextBtn,    2);
            navBar.Children.Add(prevBtn);
            navBar.Children.Add(monthLabel);
            navBar.Children.Add(nextBtn);
            _root.Children.Add(navBar);

            // ── Compute digests ───────────────────────────────────────────────
            var prevMonthSessions = sessions
                .Where(s => s.Date >= _currentMonth.AddMonths(-1)
                         && s.Date < _currentMonth).ToList();
            MonthDigest prev = IntelligenceEngine.ComputeMonthDigest(
                sessions, _currentMonth.AddMonths(-1));
            MonthDigest cur  = IntelligenceEngine.ComputeMonthDigest(
                sessions, _currentMonth, prev.SessionCount > 0 ? prev : null);

            var card  = Card();
            var inner = CardInner(card);

            if (cur.SessionCount == 0)
            {
                inner.Children.Add(Placeholder("No trading sessions recorded for this month."));
                _root.Children.Add(card);
                return;
            }

            // ── Grade badge + headline stats ──────────────────────────────────
            var topRow = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            topRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            topRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Grade badge
            Color gradeColor = CompColor(cur.AvgComposure);
            var gradeBadge = new Border
            {
                Background    = new SolidColorBrush(Color.FromArgb(50,
                    gradeColor.R, gradeColor.G, gradeColor.B)),
                BorderBrush   = new SolidColorBrush(Color.FromArgb(120,
                    gradeColor.R, gradeColor.G, gradeColor.B)),
                BorderThickness = new Thickness(1),
                CornerRadius  = new CornerRadius(8),
                Padding       = new Thickness(10, 6, 10, 6),
                Margin        = new Thickness(0, 0, 12, 0),
                VerticalAlignment = VerticalAlignment.Center,
                Child = new TextBlock
                {
                    Text       = cur.GradeLabel,
                    FontSize   = 22,
                    FontFamily = new FontFamily("Segoe UI"),
                    FontWeight = FontWeights.Bold,
                    Foreground = new SolidColorBrush(gradeColor),
                },
            };
            topRow.Children.Add(gradeBadge);

            // Key stats column
            string prevMonthShort = _currentMonth.AddMonths(-1).ToString("MMM");
            int stableDaysDelta = prev.SessionCount > 0 ? cur.StableDays - prev.StableDays : 0;
            var statsCol = new StackPanel { Orientation = Orientation.Vertical };
            statsCol.Children.Add(DigestStatRow(
                "Composure",
                $"{cur.AvgComposure:F0}%",
                cur.ComposureChange.HasValue
                    ? FormatChange(cur.ComposureChange.Value, $"% vs {prevMonthShort}")
                    : null,
                cur.ComposureChange));
            statsCol.Children.Add(DigestStatRow(
                "Stable days",
                $"{cur.StableDays} days",
                prev.SessionCount > 0
                    ? FormatChange(stableDaysDelta, $" days vs {prevMonthShort}")
                    : null,
                prev.SessionCount > 0 ? (double?)stableDaysDelta : null));
            statsCol.Children.Add(DigestStatRow(
                "Win rate",
                $"{cur.WinRate * 100:F0}%",
                null, null));
            statsCol.Children.Add(DigestStatRow(
                "Avg P&L / session",
                cur.AvgPnl >= 0 ? $"+${cur.AvgPnl:F0}" : $"-${Math.Abs(cur.AvgPnl):F0}",
                null, null));

            Grid.SetColumn(statsCol, 1);
            topRow.Children.Add(statsCol);
            inner.Children.Add(topRow);

            // ── Divider ───────────────────────────────────────────────────────
            inner.Children.Add(Divider());

            // ── Best / worst day ──────────────────────────────────────────────
            if (cur.BestDay != null)
            {
                inner.Children.Add(TwoColRow(
                    $"Best day — {cur.BestDay.Date:MMM d}",
                    $"Composure {cur.BestDay.ComposurePct}%",
                    ColStable));
            }
            if (cur.WorstDay != null && cur.WorstDay.Date != cur.BestDay?.Date)
            {
                inner.Children.Add(TwoColRow(
                    $"Hardest day — {cur.WorstDay.Date:MMM d}",
                    $"Composure {cur.WorstDay.ComposurePct}%",
                    ColCritical));
            }

            // ── Strength / Weakness ───────────────────────────────────────────
            inner.Children.Add(Divider());
            inner.Children.Add(TwoColRow("Top strength",   cur.TopStrength, ColStable));
            inner.Children.Add(TwoColRow("Needs attention", cur.TopWeakness, ColCaution));

            _root.Children.Add(card);
        }

        // =====================================================================
        // Section 3: PSI × Performance Correlation
        // =====================================================================

        private void BuildPsiPerfCorrelation(List<SessionHistoryEntry> sessions)
        {
            _root.Children.Add(SectionHeader("PSI × PERFORMANCE  ·  SESSION-LEVEL CORRELATION"));
            _root.Children.Add(new TextBlock
            {
                Text         = "P&L in this section is descriptive only; PSI does not use profit or loss to score discipline.",
                FontSize     = 9,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 2, 0, 8),
            });

            if (sessions.Count < IntelligenceEngine.MinSessionsCorr)
            {
                _root.Children.Add(InsufficientDataCard(
                    IntelligenceEngine.MinSessionsCorr - sessions.Count,
                    "PSI × Performance analysis"));
                return;
            }

            var psiBuckets  = IntelligenceEngine.ComputePsiPerfCorrelation(sessions);
            var compBuckets = IntelligenceEngine.ComputeComposurePerfCorrelation(sessions);

            // ── Two-column card layout ─────────────────────────────────────────
            var outerCard = Card();
            var outerInner = CardInner(outerCard);

            var twoCol = new Grid { Margin = new Thickness(0, 0, 0, 0) };
            twoCol.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            twoCol.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(8) });
            twoCol.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // ── Left: PSI Zone table ───────────────────────────────────────────
            var leftPanel = new StackPanel { Orientation = Orientation.Vertical };

            leftPanel.Children.Add(new TextBlock
            {
                Text       = "Avg PSI zone with session P&L (descriptive)",
                FontSize   = 10,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgSecondary,
                Margin     = new Thickness(0, 0, 0, 6),
                TextWrapping = TextWrapping.Wrap,
            });

            BuildTableHeader(leftPanel, new[] { "Zone", "Days", "Win%", "Avg P&L" },
                             new[] { 1.8, 0.6, 0.6, 1.0 });

            foreach (var b in psiBuckets)
            {
                Color zoneColor = b.PsiMin >= 75 ? ColStable
                                : b.PsiMin >= 55 ? ColCaution
                                : ColCritical;
                if (b.SessionCount == 0)
                    BuildTableRow(leftPanel, new[] { b.Label, "—", "—", "—" },
                        new[] { 1.8, 0.6, 0.6, 1.0 }, zoneColor, dim: true);
                else
                {
                    string pnlStr = b.AvgPnl >= 0 ? $"+${b.AvgPnl:F0}" : $"-${Math.Abs(b.AvgPnl):F0}";
                    BuildTableRow(leftPanel, new[] { b.Label, $"{b.SessionCount}", $"{b.WinRate:F0}%", pnlStr },
                        new[] { 1.8, 0.6, 0.6, 1.0 }, zoneColor, dim: false);
                }
            }

            Grid.SetColumn(leftPanel, 0);
            twoCol.Children.Add(leftPanel);

            // ── Separator ─────────────────────────────────────────────────────
            var sep = new Border
            {
                Width      = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            Grid.SetColumn(sep, 1);
            twoCol.Children.Add(sep);

            // ── Right: Composure table ─────────────────────────────────────────
            var rightPanel = new StackPanel { Orientation = Orientation.Vertical };

            rightPanel.Children.Add(new TextBlock
            {
                Text       = "Composure score with session P&L (descriptive)",
                FontSize   = 10,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgSecondary,
                Margin     = new Thickness(0, 0, 0, 6),
                TextWrapping = TextWrapping.Wrap,
            });

            BuildTableHeader(rightPanel, new[] { "Score", "Days", "Win%", "Avg P&L" },
                             new[] { 1.8, 0.6, 0.6, 1.0 });

            foreach (var b in compBuckets)
            {
                Color zoneColor = CompColor(b.ComposureMin);
                if (b.SessionCount == 0)
                    BuildTableRow(rightPanel, new[] { b.Label, "—", "—", "—" },
                        new[] { 1.8, 0.6, 0.6, 1.0 }, zoneColor, dim: true);
                else
                {
                    string pnlStr = b.AvgPnl >= 0 ? $"+${b.AvgPnl:F0}" : $"-${Math.Abs(b.AvgPnl):F0}";
                    BuildTableRow(rightPanel, new[] { b.Label, $"{b.SessionCount}", $"{b.WinRate:F0}%", pnlStr },
                        new[] { 1.8, 0.6, 0.6, 1.0 }, zoneColor, dim: false);
                }
            }

            Grid.SetColumn(rightPanel, 2);
            twoCol.Children.Add(rightPanel);

            outerInner.Children.Add(twoCol);

            // ── Insights row (full width below tables) ─────────────────────────
            var stableBucket   = psiBuckets.FirstOrDefault(b => b.PsiMin >= 75);
            var criticalBucket = psiBuckets.FirstOrDefault(b => b.PsiMax <= 55);
            if (stableBucket != null && criticalBucket != null
                && stableBucket.SessionCount > 0 && criticalBucket.SessionCount > 0)
            {
                double winDiff = stableBucket.WinRate - criticalBucket.WinRate;
                double pnlDiff = stableBucket.AvgPnl  - criticalBucket.AvgPnl;
                if (Math.Abs(winDiff) > 5 || Math.Abs(pnlDiff) > 50)
                {
                    outerInner.Children.Add(Divider());
                    outerInner.Children.Add(InsightText(
                        $"Stable PSI → {winDiff:F0}% higher win rate and ${pnlDiff:F0} more per session vs. Critical-zone."));
                }
            }

            var composedBucket     = compBuckets.FirstOrDefault(b => b.ComposureMin >= SessionData.ComposureStableThreshold);
            var breakingDownBucket = compBuckets.FirstOrDefault(b => b.ComposureMax <= 40);
            if (composedBucket != null && breakingDownBucket != null
                && breakingDownBucket.SessionCount > 0 && composedBucket.SessionCount > 0)
            {
                double lostPnl = breakingDownBucket.TotalPnl;
                if (lostPnl < -100)
                {
                    outerInner.Children.Add(Divider());
                    outerInner.Children.Add(InsightText(
                        $"Your {breakingDownBucket.SessionCount} 'Breaking Down' session{(breakingDownBucket.SessionCount > 1 ? "s" : "")} " +
                        $"cost ${Math.Abs(lostPnl):F0} in losses — the direct cost of trading while impaired."));
                }
            }

            _root.Children.Add(outerCard);
        }

        // =====================================================================
        // Section 4: Weekday Heatmap
        // =====================================================================

        private void BuildWeekdayHeatmap(List<SessionHistoryEntry> sessions)
        {
            _root.Children.Add(SectionHeader("WEEKDAY PATTERNS"));

            if (sessions.Count < IntelligenceEngine.MinSessionsPattern)
            {
                _root.Children.Add(InsufficientDataCard(
                    IntelligenceEngine.MinSessionsPattern - sessions.Count,
                    "Weekday pattern analysis"));
                return;
            }

            var stats = IntelligenceEngine.ComputeWeekdayStats(sessions);
            if (stats.Length == 0)
            {
                _root.Children.Add(InsufficientDataCard(5, "Weekday pattern analysis"));
                return;
            }

            var card  = Card();
            var inner = CardInner(card);

            // ── Grid: day headers + 4 metric rows ────────────────────────────
            var grid = new Grid { Margin = new Thickness(0, 0, 0, 4) };
            // Col 0: label, Cols 1-5: Mon-Fri
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            for (int d = 0; d < 5; d++)
                grid.ColumnDefinitions.Add(new ColumnDefinition
                    { Width = new GridLength(1, GridUnitType.Star) });

            // Row definitions: header + 4 data rows
            for (int r = 0; r < 5; r++)
                grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(26) });

            // Row 0: day-of-week headers
            for (int d = 0; d < 5; d++)
            {
                var s = stats.FirstOrDefault(x => (int)x.Day == d + 1); // Mon=1..Fri=5
                Color dayColor = s == null || s.SessionCount == 0 ? Color.FromRgb(80, 80, 84)
                               : s.IsHighRisk  ? ColCritical
                               : s.IsBestDay   ? ColStable
                               : Color.FromRgb(174, 174, 178);

                var hdr = new Border
                {
                    Background    = new SolidColorBrush(Color.FromArgb(30,
                        dayColor.R, dayColor.G, dayColor.B)),
                    CornerRadius  = new CornerRadius(5),
                    Margin        = new Thickness(2, 1, 2, 1),
                    Child = new TextBlock
                    {
                        Text                = DayShort[d],
                        FontSize            = 11,
                        FontFamily          = new FontFamily("Segoe UI"),
                        FontWeight          = FontWeights.SemiBold,
                        Foreground          = new SolidColorBrush(dayColor),
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment   = VerticalAlignment.Center,
                        ToolTip             = s?.SessionCount > 0
                            ? $"{s.SessionCount} sessions recorded" : "No sessions",
                    },
                };
                Grid.SetRow(hdr, 0); Grid.SetColumn(hdr, d + 1);
                grid.Children.Add(hdr);
            }

            // Row label col
            AddHeatmapLabel(grid, "Composure", 1);
            AddHeatmapLabel(grid, "Win %",     2);
            AddHeatmapLabel(grid, "Critical %", 3);
            AddHeatmapLabel(grid, "Sessions",  4);

            // Data cells
            double[] allComposure = stats.Where(s => s.SessionCount > 0)
                .Select(s => s.AvgComposure).ToArray();
            double maxComp = allComposure.Length > 0 ? allComposure.Max() : 100;
            double minComp = allComposure.Length > 0 ? allComposure.Min() : 0;

            for (int d = 0; d < 5; d++)
            {
                var s = stats.FirstOrDefault(x => (int)x.Day == d + 1);
                if (s == null || s.SessionCount == 0)
                {
                    // Show "No data" in row 1, empty for others — makes absence explicit
                    AddHeatmapCell(grid, "–", 1, d + 1, Color.FromRgb(60, 60, 64), dim: true);
                    for (int r = 2; r <= 4; r++)
                        AddHeatmapCell(grid, "–", r, d + 1, Color.FromRgb(60, 60, 64), dim: true);
                    continue;
                }

                // Composure cell — use semantic 4-tier CompColor
                Color compColor = CompColor(s.AvgComposure);
                AddHeatmapCell(grid, $"{s.AvgComposure:F0}%", 1, d + 1, compColor, false);

                // Win rate
                Color winColor = s.WinRate >= 55 ? ColStable
                               : s.WinRate >= 45 ? ColCaution
                               : ColCritical;
                AddHeatmapCell(grid, $"{s.WinRate:F0}%", 2, d + 1, winColor, false);

                // Critical %
                Color critColor = s.AvgCriticalPct <= 10 ? ColStable
                                : s.AvgCriticalPct <= 25 ? ColCaution
                                : ColCritical;
                AddHeatmapCell(grid, $"{s.AvgCriticalPct:F0}%", 3, d + 1, critColor, false);

                // Session count
                AddHeatmapCell(grid, $"{s.SessionCount}", 4, d + 1,
                    Color.FromRgb(99, 99, 102), false);
            }

            inner.Children.Add(grid);

            // ── Auto insight ──────────────────────────────────────────────────
            var bestDay  = stats.Where(s => s.SessionCount >= 2).OrderByDescending(s => s.AvgComposure).FirstOrDefault();
            var worstDay = stats.Where(s => s.SessionCount >= 2).OrderBy(s => s.AvgComposure).FirstOrDefault();
            if (bestDay != null && worstDay != null && bestDay.Day != worstDay.Day)
            {
                double gap = bestDay.AvgComposure - worstDay.AvgComposure;
                if (gap > 10)
                {
                    inner.Children.Add(Divider());
                    inner.Children.Add(InsightText(
                        $"Your best day is {bestDay.Day} (avg {bestDay.AvgComposure:F0}% Composure). " +
                        $"Your hardest day is {worstDay.Day} ({worstDay.AvgComposure:F0}%). " +
                        $"Consider reducing size or skipping {worstDay.Day} trades."));
                }
            }

            _root.Children.Add(card);
        }

        // =====================================================================
        // Section 5: Progress Trend
        // =====================================================================

        private void BuildProgressTrend(List<SessionHistoryEntry> sessions)
        {
            _root.Children.Add(SectionHeader("COMPOSURE PROGRESS  ·  LAST 6 MONTHS"));

            var points = IntelligenceEngine.ComputeProgressTrend(sessions, 6);
            var active = points.Where(p => p.SessionCount > 0).ToList();

            var card  = Card();
            var inner = CardInner(card);

            if (active.Count < 2)
            {
                inner.Children.Add(Placeholder(
                    "Need at least 2 months of sessions for trend analysis."));
                _root.Children.Add(card);
                return;
            }

            // ── Sparkline ─────────────────────────────────────────────────────
            var canvas = new Canvas { Height = 60, Margin = new Thickness(0, 4, 0, 8) };
            canvas.Loaded += (_, __) => DrawTrendSparkline(canvas, points);
            inner.Children.Add(canvas);

            // ── Monthly pill row ──────────────────────────────────────────────
            var pillRow = new WrapPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 0, 0, 4),
            };

            foreach (var p in points)
            {
                Color pillColor = p.SessionCount == 0 ? Color.FromRgb(60, 60, 64)
                                : CompColor(p.AvgComposure);

                string val = p.SessionCount == 0 ? "—" : $"{p.AvgComposure:F0}%";

                var pill = new Border
                {
                    Background    = new SolidColorBrush(Color.FromArgb(35,
                        pillColor.R, pillColor.G, pillColor.B)),
                    BorderBrush   = new SolidColorBrush(Color.FromArgb(80,
                        pillColor.R, pillColor.G, pillColor.B)),
                    BorderThickness = new Thickness(1),
                    CornerRadius  = new CornerRadius(8),
                    Padding       = new Thickness(8, 4, 8, 4),
                    Margin        = new Thickness(0, 0, 6, 4),
                    ToolTip       = p.SessionCount > 0
                        ? $"{p.Month:MMMM yyyy}\n{p.SessionCount} sessions\nWin rate {p.WinRate:F0}%\nAvg P&L {(p.AvgPnl >= 0 ? "+" : "")}${p.AvgPnl:F0}"
                        : $"{p.Month:MMMM yyyy} — no sessions",
                    Child = new StackPanel { Orientation = Orientation.Vertical }
                };
                var ps = (StackPanel)pill.Child;
                ps.Children.Add(new TextBlock
                {
                    Text                = p.Month.ToString("MMM"),
                    FontSize            = 9,
                    FontFamily          = new FontFamily("Segoe UI"),
                    Foreground          = new SolidColorBrush(Color.FromRgb(99, 99, 102)),
                    HorizontalAlignment = HorizontalAlignment.Center,
                });
                ps.Children.Add(new TextBlock
                {
                    Text                = val,
                    FontSize            = 13,
                    FontFamily          = new FontFamily("Segoe UI"),
                    FontWeight          = FontWeights.Bold,
                    Foreground          = new SolidColorBrush(pillColor),
                    HorizontalAlignment = HorizontalAlignment.Center,
                });
                pillRow.Children.Add(pill);
            }
            inner.Children.Add(pillRow);

            // ── Trend direction insight ───────────────────────────────────────
            if (active.Count >= 2)
            {
                var first = active.First();
                var last  = active.Last();
                double delta = last.AvgComposure - first.AvgComposure;
                string arrow = delta >= 3 ? "↑" : delta <= -3 ? "↓" : "→";
                Color  tc    = delta >= 3 ? ColStable : delta <= -3 ? ColCritical : ColCaution;

                inner.Children.Add(new TextBlock
                {
                    Text         = $"{arrow}  {Math.Abs(delta):F0} pts {(delta >= 0 ? "improvement" : "decline")} over {active.Count} months  ·  Grade {IntelligenceEngine.ComposureGrade(last.AvgComposure)}",
                    FontSize     = 11,
                    FontFamily   = new FontFamily("Segoe UI"),
                    FontWeight   = FontWeights.SemiBold,
                    Foreground   = new SolidColorBrush(tc),
                    TextWrapping = TextWrapping.Wrap,
                });
            }

            _root.Children.Add(card);
        }

        // =====================================================================
        // Section 6: Crash Triggers
        // =====================================================================

        private void BuildCrashTriggers(List<SessionHistoryEntry> sessions)
        {
            _root.Children.Add(SectionHeader("CRASH SESSION PATTERNS  ·  BEHAVIORS ON YOUR WORST DAYS"));

            var triggers = IntelligenceEngine.ComputeCrashTriggers(sessions);

            if (triggers.Count == 0)
            {
                var eCard = Card();
                CardInner(eCard).Children.Add(Placeholder(
                    sessions.Count < IntelligenceEngine.MinSessionsBasic
                        ? $"Need {IntelligenceEngine.MinSessionsBasic - sessions.Count} more sessions to identify crash patterns."
                        : "No significant crash patterns identified in your session history."));
                _root.Children.Add(eCard);
                return;
            }

            var card  = Card();
            var inner = CardInner(card);

            int crashDayTotal = triggers.Max(t2 => t2.CrashDayCount);

            inner.Children.Add(new TextBlock
            {
                Text         = $"How consistently each behavior appeared in your {crashDayTotal} worst sessions:",
                FontSize     = 10,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 10),
            });

            for (int i = 0; i < triggers.Count; i++)
            {
                var t = triggers[i];
                Color barColor = i == 0 ? ColCritical
                               : i == 1 ? ColCaution
                               : Color.FromRgb(174, 174, 178);

                // Severity badge color
                Color sevColor = t.SeverityLabel == "HIGH" ? ColCritical
                               : t.SeverityLabel == "MED"  ? ColCaution
                               : Color.FromRgb(99, 99, 102);

                var row = new StackPanel
                {
                    Orientation = Orientation.Vertical,
                    Margin      = new Thickness(0, 0, 0, 12),
                };

                // ── Label row: rank + name | frequency text | severity badge ──
                var labelGrid = new Grid();
                labelGrid.ColumnDefinitions.Add(new ColumnDefinition
                    { Width = new GridLength(1, GridUnitType.Star) });
                labelGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                labelGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                labelGrid.Margin = new Thickness(0, 0, 0, 4);

                labelGrid.Children.Add(new TextBlock
                {
                    Text              = $"#{i + 1}  {t.DimName}",
                    FontSize          = 11,
                    FontFamily        = new FontFamily("Segoe UI"),
                    FontWeight        = FontWeights.SemiBold,
                    Foreground        = new SolidColorBrush(barColor),
                    VerticalAlignment = VerticalAlignment.Center,
                });

                // Frequency text: "X / Y worst sessions"
                var freqLbl = new TextBlock
                {
                    Text              = $"{t.PresentOnCrashDays} / {t.CrashDayCount} worst sessions",
                    FontSize          = 10,
                    FontFamily        = new FontFamily("Segoe UI"),
                    Foreground        = FgSecondary,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin            = new Thickness(0, 0, 8, 0),
                };
                Grid.SetColumn(freqLbl, 1);
                labelGrid.Children.Add(freqLbl);

                // Severity badge
                var sevBadge = new Border
                {
                    Background    = new SolidColorBrush(Color.FromArgb(35,
                        sevColor.R, sevColor.G, sevColor.B)),
                    CornerRadius  = new CornerRadius(3),
                    Padding       = new Thickness(5, 1, 5, 1),
                    VerticalAlignment = VerticalAlignment.Center,
                    Child = new TextBlock
                    {
                        Text       = t.SeverityLabel,
                        FontSize   = 9,
                        FontFamily = new FontFamily("Segoe UI"),
                        FontWeight = FontWeights.SemiBold,
                        Foreground = new SolidColorBrush(sevColor),
                    },
                };
                Grid.SetColumn(sevBadge, 2);
                labelGrid.Children.Add(sevBadge);

                row.Children.Add(labelGrid);

                // ── Frequency bar (PresentOnCrashDays / CrashDayCount) ─────────
                double fillPct = t.CrashDayCount > 0
                    ? (double)t.PresentOnCrashDays / t.CrashDayCount : 0;
                var barBg = new Border
                {
                    Background   = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                    CornerRadius = new CornerRadius(3),
                    Height       = 5,
                };
                var barFill = new Border
                {
                    Background          = new SolidColorBrush(barColor),
                    CornerRadius        = new CornerRadius(3),
                    Height              = 5,
                    HorizontalAlignment = HorizontalAlignment.Left,
                };
                barFill.Loaded += (_, __) => { barFill.Width = barBg.ActualWidth * fillPct; };
                barBg.Loaded   += (_, __) => { barFill.Width = barBg.ActualWidth * fillPct; };
                barBg.Child = barFill;
                row.Children.Add(barBg);



                inner.Children.Add(row);
            }

            if (triggers.Count > 0)
            {
                inner.Children.Add(Divider());
                inner.Children.Add(InsightText(
                    $"'{triggers[0].DimName}' is your most consistent crash-day behavior — " +
                    $"present in {triggers[0].PresentOnCrashDays} of your {triggers[0].CrashDayCount} worst sessions. " +
                    $"Controlling this single dimension is your highest-leverage change."));
            }

            _root.Children.Add(card);
        }

        // =====================================================================
        // Drawing helpers
        // =====================================================================

        private void DrawTrendSparkline(Canvas canvas, List<ProgressPoint> points)
        {
            double w   = canvas.ActualWidth;
            double h   = canvas.ActualHeight;
            if (w < 10 || h < 10) return;

            var active = points.Where(p => p.SessionCount > 0).ToList();
            if (active.Count < 2) return;

            double minV = Math.Min(active.Min(p => p.AvgComposure), 30);
            double maxV = Math.Max(active.Max(p => p.AvgComposure), 70);
            double range = maxV - minV;
            if (range < 1) range = 1;

            double stepX = w / (points.Count - 1.0);

            // Zone band (70 = stable threshold)
            double stableY = h - (70.0 - minV) / range * h;
            if (stableY > 0 && stableY < h)
            {
                var band = new Rectangle
                {
                    Width  = w,
                    Height = Math.Max(0, stableY),
                    Fill   = new SolidColorBrush(Color.FromArgb(12, 48, 209, 88)),
                };
                Canvas.SetLeft(band, 0); Canvas.SetTop(band, 0);
                canvas.Children.Add(band);

                var line = new Line
                {
                    X1              = 0, X2 = w,
                    Y1              = stableY, Y2 = stableY,
                    Stroke          = new SolidColorBrush(Color.FromArgb(60, 48, 209, 88)),
                    StrokeThickness = 0.8,
                    StrokeDashArray = new DoubleCollection { 3, 3 },
                };
                canvas.Children.Add(line);
            }

            // Polyline
            var poly = new Polyline
            {
                Stroke          = new SolidColorBrush(Color.FromRgb(10, 132, 255)),
                StrokeThickness = 2,
                StrokeLineJoin  = PenLineJoin.Round,
                StrokeStartLineCap = PenLineCap.Round,
                StrokeEndLineCap   = PenLineCap.Round,
            };

            for (int i = 0; i < points.Count; i++)
            {
                var p = points[i];
                if (p.SessionCount == 0) continue;
                double x = i * stepX;
                double y = h - (p.AvgComposure - minV) / range * (h - 8) - 4;
                poly.Points.Add(new Point(x, y));

                // Dot
                double dotR = 3;
                var dot = new Ellipse
                {
                    Width  = dotR * 2, Height = dotR * 2,
                    Fill   = new SolidColorBrush(Color.FromRgb(10, 132, 255)),
                };
                Canvas.SetLeft(dot, x - dotR);
                Canvas.SetTop(dot, y - dotR);
                canvas.Children.Add(dot);
            }
            canvas.Children.Add(poly);
        }

        // =====================================================================
        // Table builder helpers
        // =====================================================================

        private void BuildTableHeader(StackPanel inner, string[] cols, double[] weights)
        {
            var row = MakeTableRow(cols, weights,
                new SolidColorBrush(Color.FromRgb(99, 99, 102)), bold: true);
            row.Margin = new Thickness(0, 0, 0, 2);
            inner.Children.Add(row);
        }

        private void BuildTableRow(StackPanel inner, string[] cols, double[] weights,
                                   Color accent, bool dim)
        {
            Brush fg = dim ? FgHint : FgSecondary;
            var row = MakeTableRow(cols, weights, fg, bold: false);
            if (!dim)
            {
                // Colorize first cell
                var g = (Grid)row;
                if (g.Children.Count > 0 && g.Children[0] is TextBlock tb)
                    tb.Foreground = new SolidColorBrush(accent);
            }
            row.Margin = new Thickness(0, 0, 0, 2);
            inner.Children.Add(row);
        }

        private static Grid MakeTableRow(string[] cols, double[] weights, Brush fg, bool bold)
        {
            var g = new Grid { Margin = new Thickness(0, 1, 0, 1) };
            for (int i = 0; i < cols.Length; i++)
            {
                g.ColumnDefinitions.Add(new ColumnDefinition
                    { Width = new GridLength(weights[i], GridUnitType.Star) });
                var tb = new TextBlock
                {
                    Text       = cols[i],
                    FontSize   = 11,
                    FontFamily = new FontFamily("Segoe UI"),
                    FontWeight = bold ? FontWeights.SemiBold : FontWeights.Normal,
                    Foreground = fg,
                    HorizontalAlignment = i == 0 ? HorizontalAlignment.Left : HorizontalAlignment.Right,
                    VerticalAlignment   = VerticalAlignment.Center,
                    Padding             = new Thickness(i == 0 ? 0 : 4, 0, 0, 0),
                };
                Grid.SetColumn(tb, i);
                g.Children.Add(tb);
            }
            return g;
        }

        // =====================================================================
        // Heatmap cell helpers
        // =====================================================================

        private static void AddHeatmapLabel(Grid grid, string text, int row)
        {
            var tb = new TextBlock
            {
                Text              = text,
                FontSize          = 10,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(0, 0, 4, 0),
            };
            Grid.SetRow(tb, row); Grid.SetColumn(tb, 0);
            grid.Children.Add(tb);
        }

        private static void AddHeatmapCell(Grid grid, string text, int row, int col,
                                           Color accent, bool dim)
        {
            Brush fg = dim
                ? new SolidColorBrush(Color.FromRgb(60, 60, 64))
                : new SolidColorBrush(accent);

            var cell = new Border
            {
                Background   = new SolidColorBrush(Color.FromArgb(dim ? (byte)0 : (byte)20,
                    accent.R, accent.G, accent.B)),
                CornerRadius = new CornerRadius(4),
                Margin       = new Thickness(2, 1, 2, 1),
                Child = new TextBlock
                {
                    Text                = text,
                    FontSize            = 11,
                    FontFamily          = new FontFamily("Segoe UI"),
                    FontWeight          = FontWeights.SemiBold,
                    Foreground          = fg,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                },
            };
            Grid.SetRow(cell, row); Grid.SetColumn(cell, col);
            grid.Children.Add(cell);
        }

        private static Color HeatColor(double value, double min, double max)
        {
            if (max <= min) return Color.FromRgb(174, 174, 178);
            double t = (value - min) / (max - min);
            if (t >= 0.6) return ColStable;
            if (t >= 0.35) return ColCaution;
            return ColCritical;
        }

        // =====================================================================
        // Shared UI primitives
        // =====================================================================

        private static Border Card() => new Border
        {
            Background      = BgCard,
            CornerRadius    = new CornerRadius(10),
            Padding         = new Thickness(12, 10, 12, 10),
            Margin          = new Thickness(0, 4, 0, 0),
            Child           = new StackPanel { Orientation = Orientation.Vertical },
        };

        private static StackPanel CardInner(Border card) => (StackPanel)card.Child;

        private static UIElement SectionHeader(string text) => new TextBlock
        {
            Text       = text,
            FontSize   = 10,
            FontFamily = new FontFamily("Segoe UI"),
            FontWeight = FontWeights.SemiBold,
            Foreground = FgSecondary,
            Margin     = new Thickness(2, 12, 0, 0),
        };

        private static Border InsufficientDataCard(int remaining, string feature)
        {
            var c = Card();
            CardInner(c).Children.Add(Placeholder(
                $"Need {remaining} more session{(remaining == 1 ? "" : "s")} to unlock {feature}."));
            return c;
        }

        private static UIElement Placeholder(string text) => new TextBlock
        {
            Text         = text,
            FontSize     = 11,
            FontFamily   = new FontFamily("Segoe UI"),
            Foreground   = FgHint,
            TextWrapping = TextWrapping.Wrap,
            Padding      = new Thickness(0, 4, 0, 4),
        };

        private static UIElement InsightText(string text) => new Border
        {
            Background      = new SolidColorBrush(Color.FromArgb(18, 10, 132, 255)),
            BorderBrush     = new SolidColorBrush(Color.FromArgb(120, 10, 132, 255)),
            BorderThickness = new Thickness(2, 0, 0, 0),
            CornerRadius    = new CornerRadius(0, 4, 4, 0),
            Padding         = new Thickness(8, 6, 8, 6),
            Margin          = new Thickness(0, 4, 0, 0),
            Child = new TextBlock
            {
                Text         = $"💡  {text}",
                FontSize     = 11,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
            },
        };

        private static Border Divider() => new Border
        {
            Height     = 1,
            Background = new SolidColorBrush(Color.FromArgb(25, 255, 255, 255)),
            Margin     = new Thickness(0, 6, 0, 6),
        };

        private static UIElement DigestStatRow(string label, string value, string change, double? delta)
        {
            var g = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) });

            g.Children.Add(new TextBlock
            {
                Text              = label,
                FontSize          = 11,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            });

            if (change != null)
            {
                Color cc = delta.HasValue && delta.Value > 0 ? ColStable
                         : delta.HasValue && delta.Value < 0 ? ColCritical
                         : Color.FromRgb(99, 99, 102);
                var changeLbl = new TextBlock
                {
                    Text              = change,
                    FontSize          = 10,
                    FontFamily        = new FontFamily("Segoe UI"),
                    Foreground        = new SolidColorBrush(cc),
                    VerticalAlignment = VerticalAlignment.Center,
                    TextAlignment     = TextAlignment.Right,
                };
                Grid.SetColumn(changeLbl, 1);
                g.Children.Add(changeLbl);
            }

            var valueLbl = new TextBlock
            {
                Text              = value,
                FontSize          = 12,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                TextAlignment     = TextAlignment.Right,
            };
            Grid.SetColumn(valueLbl, 2);
            g.Children.Add(valueLbl);
            return g;
        }

        private static UIElement TwoColRow(string label, string value, Color valueColor)
        {
            var g = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            g.Children.Add(new TextBlock
            {
                Text              = label,
                FontSize          = 11,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            });

            var vLbl = new TextBlock
            {
                Text      = value,
                FontSize  = 11,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(valueColor),
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(vLbl, 1);
            g.Children.Add(vLbl);
            return g;
        }

        private static TextBlock MakeNavArrow(string text, bool enabled) => new TextBlock
        {
            Text              = text,
            FontSize          = 13,
            FontFamily        = new FontFamily("Segoe UI"),
            Foreground        = enabled
                ? new SolidColorBrush(Color.FromRgb(10, 132, 255))
                : new SolidColorBrush(Color.FromRgb(60, 60, 64)),
            Cursor            = enabled ? Cursors.Hand : Cursors.Arrow,
            VerticalAlignment = VerticalAlignment.Center,
            Padding           = new Thickness(4, 0, 4, 0),
        };

        private static Border MakeHeaderBtn(string text)
        {
            var lbl = new TextBlock
            {
                Text              = text,
                FontSize          = 13,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = new SolidColorBrush(Color.FromRgb(142, 142, 147)),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Width             = 40,
                Background        = Brushes.Transparent,
                Cursor            = Cursors.Hand,
                Child             = lbl,
                VerticalAlignment = VerticalAlignment.Center,
            };
            btn.MouseEnter += (_, __) => lbl.Foreground =
                new SolidColorBrush(Color.FromRgb(220, 220, 224));
            btn.MouseLeave += (_, __) => lbl.Foreground =
                new SolidColorBrush(Color.FromRgb(142, 142, 147));
            return btn;
        }

        private static string FormatChange(double delta, string unit)
        {
            if (delta > 0) return $"↑ +{delta:F0}{unit}";
            if (delta < 0) return $"↓ {delta:F0}{unit}";
            return $"→ 0{unit}";
        }
    }
}
