#region Using declarations
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using NinjaTrader.Cbi;
#endregion

// =====================================================================
// PropertyFuzzer — randomised invariant stress-tester.
//
// Purpose: trigger bug classes that no one has thought to write a unit
// test for, by generating thousands of synthetic NT8 event sequences
// drawn from the rough distribution of real trader behaviour, plus
// adversarial perturbations (out-of-order events, duplicate events,
// reversals at unlikely boundaries, deep nesting of partial fills).
//
// Asserted invariants per scenario:
//   • IntegrityCheck.Run produces no violations after a clean session
//     terminates (all positions flat at end → all dictionaries empty).
//   • Counter monotonicity:  TotalTrades and SessionEntryCount are
//     non-decreasing over the scenario.
//   • Counter bounds:        SessionEntryCount ≤ #Add edges seen.
//                            TotalTrades       ≤ SessionEntryCount.
//   • Lifecycle conservation: every Add edge eventually retires (modulo
//     positions still open at end).
//
// Output: FuzzerResults.txt with summary (PASS / FAIL per scenario type),
//         counts of each violation code observed, and the seeds of the
//         first 10 failed scenarios so the failure can be reproduced
//         deterministically.
//
// Determinism: every scenario is seeded.  Re-running with the same seed
// produces an identical event sequence.  The fuzzer chooses a master
// seed from the system clock at startup but logs it, so a CI failure
// can be reproduced exactly.
// =====================================================================

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Outcome of one fuzz scenario.  PASS = no invariants violated.
    /// </summary>
    public sealed class FuzzScenarioResult
    {
        public string Name;
        public int    Seed;
        public bool   Passed;
        public List<string>  ViolatedInvariants = new List<string>();
        public List<IntegrityViolation> ResidualViolations = new List<IntegrityViolation>();
        public int    EventsGenerated;
    }

    /// <summary>
    /// Summary report across N fuzz scenarios.
    /// </summary>
    public sealed class FuzzReport
    {
        public DateTime              StartedUtc;
        public DateTime              FinishedUtc;
        public int                   MasterSeed;
        public int                   ScenarioCount;
        public int                   PassCount;
        public int                   FailCount;
        public Dictionary<string,int> ScenarioFailsByName     = new Dictionary<string,int>();
        public Dictionary<string,int> ViolationCodeFrequency  = new Dictionary<string,int>();
        public Dictionary<string,int> InvariantFailFrequency  = new Dictionary<string,int>();
        public List<FuzzScenarioResult> FirstFailures         = new List<FuzzScenarioResult>();

        public string ToText()
        {
            var sb = new StringBuilder();
            sb.Append("==================== FUZZ REPORT ====================\n");
            sb.Append("Started:     ").Append(StartedUtc.ToString("o")).Append('\n');
            sb.Append("Finished:    ").Append(FinishedUtc.ToString("o")).Append('\n');
            sb.Append("Master seed: ").Append(MasterSeed).Append('\n');
            sb.Append("Scenarios:   ").Append(ScenarioCount).Append('\n');
            sb.Append("Pass:        ").Append(PassCount).Append('\n');
            sb.Append("Fail:        ").Append(FailCount).Append('\n');

            if (FailCount > 0)
            {
                sb.Append("\n--- Fails by scenario name ---\n");
                foreach (var kv in ScenarioFailsByName.OrderByDescending(x => x.Value))
                    sb.Append("  ").Append(kv.Key.PadRight(40)).Append(kv.Value).Append('\n');

                sb.Append("\n--- Invariant failure frequency ---\n");
                foreach (var kv in InvariantFailFrequency.OrderByDescending(x => x.Value))
                    sb.Append("  ").Append(kv.Key.PadRight(40)).Append(kv.Value).Append('\n');

                sb.Append("\n--- IntegrityCheck violation code frequency ---\n");
                foreach (var kv in ViolationCodeFrequency.OrderByDescending(x => x.Value))
                    sb.Append("  ").Append(kv.Key.PadRight(40)).Append(kv.Value).Append('\n');

                sb.Append("\n--- First failures (re-seedable) ---\n");
                foreach (var f in FirstFailures)
                {
                    sb.Append("  scenario='").Append(f.Name).Append("' seed=").Append(f.Seed)
                      .Append(" events=").Append(f.EventsGenerated)
                      .Append(" violatedInvariants=[").Append(string.Join(",", f.ViolatedInvariants)).Append("]")
                      .Append(" residualViolations=").Append(f.ResidualViolations.Count).Append('\n');
                    foreach (var rv in f.ResidualViolations.Take(5))
                        sb.Append("        ").Append(rv).Append('\n');
                }
            }
            sb.Append("\n=========================== END ===========================\n");
            return sb.ToString();
        }
    }

    /// <summary>
    /// Static API: generate scenarios, run them through StandalonePositionSimulator,
    /// assert invariants, produce report.
    /// </summary>
    public static class PropertyFuzzer
    {
        // Names mirror real-world bug classes we want to stress.
        private static readonly string[] ScenarioNames = new[]
        {
            "SimpleEnterExit",
            "PartialFillsThenClose",
            "ReversalNoFlatBetween",
            "BootstrapOrphanThenClose",
            "BootstrapOrphanThenReversal",
            "DuplicatePositionEvents",
            "RapidFireEntries",
            "MultiInstrumentInterleaved",
            "AdversarialOutOfOrder",
            "ManyReversalsOnSameKey",
            // Bug-1 regression: DESYNC shadow-clear followed immediately by same-direction entry.
            "DesyncQuickReentry",
            // Bug-2 regression: stale ghost direction from mode transition poisons next entry.
            "CrossSessionGhostContamination",
            // Bug-3 regression: stale shadow direction triggers spurious lifecycle retirement.
            "StaleDirAfterReversalSuppressed",
            // New: lifecycle-centric arch timing scenarios (Path A/B, scale-out, B3, overnight).
            "PathARemoveBeforeFills",
            "PathBFillsBeforeRemove",
            "ScaleOutThenClose",
            "B3ForceComplete",
            "OvernightRetiringStuck",
            // B1: NT8 Remove event was missed; IntegrityCheck must recover.
            "B1MissedRemove",
        };

        public static FuzzReport Run(int scenarioCount, int? masterSeed = null)
        {
            var rep = new FuzzReport
            {
                StartedUtc    = DateTime.UtcNow,
                ScenarioCount = scenarioCount,
                MasterSeed    = masterSeed ?? Environment.TickCount,
            };
            var rng = new Random(rep.MasterSeed);

            for (int i = 0; i < scenarioCount; i++)
            {
                int seed = rng.Next();
                var name = ScenarioNames[i % ScenarioNames.Length];

                FuzzScenarioResult r;
                try
                {
                    r = RunScenario(name, seed);
                }
                catch (Exception ex)
                {
                    r = new FuzzScenarioResult
                    {
                        Name = name, Seed = seed, Passed = false,
                        ViolatedInvariants = { "ExceptionThrown:" + ex.GetType().Name },
                    };
                }

                if (r.Passed)
                {
                    rep.PassCount++;
                }
                else
                {
                    rep.FailCount++;
                    rep.ScenarioFailsByName.TryGetValue(r.Name, out var c);
                    rep.ScenarioFailsByName[r.Name] = c + 1;
                    foreach (var inv in r.ViolatedInvariants)
                    {
                        rep.InvariantFailFrequency.TryGetValue(inv, out var c2);
                        rep.InvariantFailFrequency[inv] = c2 + 1;
                    }
                    foreach (var rv in r.ResidualViolations)
                    {
                        string code = rv.Code.ToString();
                        rep.ViolationCodeFrequency.TryGetValue(code, out var c3);
                        rep.ViolationCodeFrequency[code] = c3 + 1;
                    }
                    if (rep.FirstFailures.Count < 10) rep.FirstFailures.Add(r);
                }
            }

            rep.FinishedUtc = DateTime.UtcNow;
            return rep;
        }

        public static (FuzzReport report, string resultsPath)
            RunAndWrite(int scenarioCount, string outDir, int? masterSeed = null)
        {
            var rep = Run(scenarioCount, masterSeed);
            string path = Path.Combine(outDir ?? Path.GetTempPath(), "FuzzerResults.txt");
            File.WriteAllText(path, rep.ToText());
            return (rep, path);
        }

        // ── Scenario dispatch ────────────────────────────────────────────

        private static FuzzScenarioResult RunScenario(string name, int seed)
        {
            var rng = new Random(seed);
            var sim = new StandalonePositionSimulator
            {
                SubscriptionTimeUtc = new DateTime(2026, 1, 1, 9, 30, 0, DateTimeKind.Utc),
                BootstrapWindow     = TimeSpan.FromSeconds(2.0),
            };

            // Time cursor advances per generated event so post-bootstrap
            // detection is deterministic per scenario.
            DateTime t = sim.SubscriptionTimeUtc + TimeSpan.FromSeconds(5);

            var events = new List<ParsedPositionEvent>();
            switch (name)
            {
                case "SimpleEnterExit":
                    GenSimpleEnterExit(events, ref t, rng); break;
                case "PartialFillsThenClose":
                    GenPartialThenClose(events, ref t, rng); break;
                case "ReversalNoFlatBetween":
                    GenReversal(events, ref t, rng); break;
                case "BootstrapOrphanThenClose":
                    GenBootstrapOrphan(events, ref t, rng, doReversal: false); break;
                case "BootstrapOrphanThenReversal":
                    GenBootstrapOrphan(events, ref t, rng, doReversal: true); break;
                case "DuplicatePositionEvents":
                    GenDuplicates(events, ref t, rng); break;
                case "RapidFireEntries":
                    GenRapidFire(events, ref t, rng); break;
                case "MultiInstrumentInterleaved":
                    GenMultiInstrument(events, ref t, rng); break;
                case "AdversarialOutOfOrder":
                    GenAdversarialOOO(events, ref t, rng); break;
                case "ManyReversalsOnSameKey":
                    GenManyReversals(events, ref t, rng); break;
                case "DesyncQuickReentry":
                    return RunDesyncQuickReentry(seed);
                case "CrossSessionGhostContamination":
                    return RunCrossSessionGhostContamination(seed);
                case "StaleDirAfterReversalSuppressed":
                    return RunStaleDirAfterReversalSuppressed(seed);
                case "PathARemoveBeforeFills":
                    return RunPathARemoveBeforeFills(seed);
                case "PathBFillsBeforeRemove":
                    return RunPathBFillsBeforeRemove(seed);
                case "ScaleOutThenClose":
                    return RunScaleOutThenClose(seed);
                case "B3ForceComplete":
                    return RunB3ForceComplete(seed);
                case "OvernightRetiringStuck":
                    return RunOvernightRetiringStuck(seed);
                case "B1MissedRemove":
                    return RunB1MissedRemove(seed);
                default:
                    throw new InvalidOperationException("unknown scenario " + name);
            }

            // Drive the simulator and track invariants per event.
            int totalAdds = 0;
            int prevEntries = 0;
            int prevTotalTrades = 0;
            var violatedInv = new List<string>();
            var residual = new List<IntegrityViolation>();

            foreach (var ev in events)
            {
                string posKey = ev.Account + "::" + ev.Instrument;

                // Capture pre-edge state from LIFECYCLE (not shadow state) because
                // shadow is maintained by execution events; at the time of a position
                // event the lifecycle is the authoritative record of what was open.
                sim.Lifecycles.TryGetValue(posKey, out var preLife);
                MarketPosition preDir = preLife != null ? preLife.Direction : MarketPosition.Flat;
                double         preQty = preLife != null ? preLife.MaxQtySeen : 0;

                string edge   = sim.ApplyPositionEvent(posKey, ev);
                if (edge == "ADD") totalAdds++;
                if (edge == "REVERSAL") totalAdds++;

                // Inject synthetic execution events after edges that retire a lifecycle.
                // This mirrors how OnExecutionUpdate consumes _flatPending /
                // _reversalCloseOriginObserved in production.
                if (edge == "REMOVE" && preLife != null && preQty > 0)
                {
                    // Close fill for the old position.
                    var closeSide = preDir == MarketPosition.Long
                        ? MarketPosition.Short : MarketPosition.Long;
                    sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
                    {
                        Time       = ev.Time.AddMilliseconds(10),
                        Account    = ev.Account,
                        Instrument = ev.Instrument,
                        FillSide   = closeSide,
                        Quantity   = preQty,
                        RawLine    = "(synth close fill for REMOVE)",
                    });
                }
                else if (edge == "REVERSAL" && preLife != null && preQty > 0)
                {
                    // 1) Close fill for the OLD leg: consumes both _reversalCloseOriginObserved
                    //    and _flatPending and clears shadow of the old leg.
                    var closeSide = preDir == MarketPosition.Long
                        ? MarketPosition.Short : MarketPosition.Long;
                    sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
                    {
                        Time       = ev.Time.AddMilliseconds(10),
                        Account    = ev.Account,
                        Instrument = ev.Instrument,
                        FillSide   = closeSide,
                        Quantity   = preQty,
                        RawLine    = "(synth close fill for REVERSAL old leg)",
                    });
                    // 2) Entry fill for the NEW leg: sets up shadow state for the
                    //    new position that was opened by the REVERSAL position event.
                    //    Required because ApplyPositionEvent REVERSAL seeds shadow to
                    //    new leg, but the bridge-first close fill clears it.
                    sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
                    {
                        Time       = ev.Time.AddMilliseconds(20),
                        Account    = ev.Account,
                        Instrument = ev.Instrument,
                        FillSide   = ev.Direction,
                        Quantity   = ev.Quantity,
                        RawLine    = "(synth entry fill for REVERSAL new leg)",
                    });
                }

                // Invariant: counter monotonicity
                if (sim.SessionEntryCount < prevEntries)
                    violatedInv.Add("SessionEntryCount decreased");
                if (sim.TotalTrades < prevTotalTrades)
                    violatedInv.Add("TotalTrades decreased");
                prevEntries     = sim.SessionEntryCount;
                prevTotalTrades = sim.TotalTrades;
            }

            // Invariant: SessionEntryCount ≤ totalAdds
            if (sim.SessionEntryCount > totalAdds)
                violatedInv.Add(string.Format("SessionEntryCount({0}) > total ADD edges({1})",
                    sim.SessionEntryCount, totalAdds));

            // Invariant: TotalTrades ≤ SessionEntryCount
            if (sim.TotalTrades > sim.SessionEntryCount)
                violatedInv.Add(string.Format("TotalTrades({0}) > SessionEntryCount({1})",
                    sim.TotalTrades, sim.SessionEntryCount));

            // Final IntegrityCheck against a "clean" NT8 truth derived from
            // the sequence's terminal state.  If the scenario ended with all
            // positions flat, no NT8 truth means EVERYTHING in our state should
            // also be empty / clean.
            var nt8Truth = new Dictionary<string, Nt8PositionSnap>();
            foreach (var kv in sim.Lifecycles)
            {
                nt8Truth[kv.Key] = new Nt8PositionSnap
                {
                    AccountName    = ParseAccount(kv.Key),
                    InstrumentName = ParseInstrument(kv.Key),
                    Direction      = kv.Value.Direction,
                    Quantity       = kv.Value.MaxQtySeen,
                    AveragePrice   = 0,
                };
            }
            var snap = sim.BuildSnapshot(nt8Truth, inBootstrap: false);
            residual.AddRange(IntegrityCheck.Run(snap));

            // Residual violations are an invariant failure — except for
            // legitimate transient bridge entries.  But we expect ZERO
            // residual violations after a fuzzer scenario completes, since
            // these scenarios are sealed (no in-flight events at the end).
            // Filter Info-only violations from "fail" determination.
            int actionable = residual.Count(v => v.Severity != IntegritySeverity.Info);

            return new FuzzScenarioResult
            {
                Name               = name,
                Seed               = seed,
                EventsGenerated    = events.Count,
                Passed             = violatedInv.Count == 0 && actionable == 0,
                ViolatedInvariants = violatedInv,
                ResidualViolations = residual,
            };
        }

        // ── Generators ───────────────────────────────────────────────────
        // Each generator builds a list of ParsedPositionEvent objects.  The
        // semantic of each scenario is descriptive of what bug class it
        // stresses.

        private static void GenSimpleEnterExit(List<ParsedPositionEvent> evs, ref DateTime t, Random rng)
        {
            string acct  = "FuzzAcct";
            string instr = "MNQ";
            var dir = rng.Next(2) == 0 ? MarketPosition.Long : MarketPosition.Short;
            int q   = rng.Next(1, 6);
            evs.Add(MkPos(t, acct, instr, dir, q, "Add"));
            t = t.AddSeconds(rng.Next(5, 600));
            evs.Add(MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
        }

        private static void GenPartialThenClose(List<ParsedPositionEvent> evs, ref DateTime t, Random rng)
        {
            string acct  = "FuzzAcct";
            string instr = "ES";
            var dir = rng.Next(2) == 0 ? MarketPosition.Long : MarketPosition.Short;
            int total = rng.Next(3, 8);
            int built = 0;
            while (built < total)
            {
                int chunk = rng.Next(1, total - built + 1);
                built += chunk;
                evs.Add(MkPos(t, acct, instr, dir, built, built == chunk ? "Add" : "Update"));
                t = t.AddMilliseconds(rng.Next(50, 600));
            }
            // Partial close.
            while (built > 0)
            {
                int chunk = rng.Next(1, built + 1);
                built -= chunk;
                if (built > 0)
                    evs.Add(MkPos(t, acct, instr, dir, built, "Update"));
                else
                    evs.Add(MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
                t = t.AddMilliseconds(rng.Next(50, 600));
            }
        }

        private static void GenReversal(List<ParsedPositionEvent> evs, ref DateTime t, Random rng)
        {
            string acct  = "FuzzAcct";
            string instr = "NQ";
            int q1 = rng.Next(1, 5);
            int q2 = rng.Next(1, 5);
            evs.Add(MkPos(t, acct, instr, MarketPosition.Long, q1, "Add"));
            t = t.AddSeconds(rng.Next(1, 60));
            // Reversal: one Update event with the opposite direction
            evs.Add(MkPos(t, acct, instr, MarketPosition.Short, q2, "Update"));
            t = t.AddSeconds(rng.Next(1, 60));
            evs.Add(MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
        }

        private static void GenBootstrapOrphan(List<ParsedPositionEvent> evs, ref DateTime t, Random rng, bool doReversal)
        {
            // Position event ARRIVES inside the bootstrap window.
            t = new DateTime(2026, 1, 1, 9, 30, 0, DateTimeKind.Utc).AddSeconds(0.5);
            string acct  = "FuzzAcct";
            string instr = "CL";
            evs.Add(MkPos(t, acct, instr, MarketPosition.Short, 2, "Add"));
            t = t.AddSeconds(10);
            if (doReversal)
            {
                evs.Add(MkPos(t, acct, instr, MarketPosition.Long, 3, "Update"));
                t = t.AddSeconds(10);
                evs.Add(MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            }
            else
            {
                evs.Add(MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            }
        }

        private static void GenDuplicates(List<ParsedPositionEvent> evs, ref DateTime t, Random rng)
        {
            string acct = "FuzzAcct"; string instr = "GC";
            var ev1 = MkPos(t, acct, instr, MarketPosition.Long, 2, "Add");
            evs.Add(ev1);
            evs.Add(ev1);  // exact duplicate (NT8 reconnect re-emit)
            t = t.AddSeconds(5);
            var ev2 = MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove");
            evs.Add(ev2);
            evs.Add(ev2);
        }

        private static void GenRapidFire(List<ParsedPositionEvent> evs, ref DateTime t, Random rng)
        {
            string acct = "FuzzAcct"; string instr = "RTY";
            int trades = rng.Next(3, 8);
            for (int i = 0; i < trades; i++)
            {
                var dir = rng.Next(2) == 0 ? MarketPosition.Long : MarketPosition.Short;
                int q   = rng.Next(1, 4);
                evs.Add(MkPos(t, acct, instr, dir, q, "Add"));
                t = t.AddSeconds(rng.Next(1, 4));
                evs.Add(MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
                t = t.AddSeconds(rng.Next(1, 4));
            }
        }

        private static void GenMultiInstrument(List<ParsedPositionEvent> evs, ref DateTime t, Random rng)
        {
            string acct = "FuzzAcct";
            string[] instrs = { "MNQ", "ES", "CL", "GC" };
            int trades = rng.Next(4, 10);
            for (int i = 0; i < trades; i++)
            {
                string ins = instrs[rng.Next(instrs.Length)];
                var dir    = rng.Next(2) == 0 ? MarketPosition.Long : MarketPosition.Short;
                int q      = rng.Next(1, 4);
                evs.Add(MkPos(t, acct, ins, dir, q, "Add"));
                t = t.AddSeconds(rng.Next(1, 6));
                evs.Add(MkPos(t, acct, ins, MarketPosition.Flat, 0, "Remove"));
                t = t.AddSeconds(rng.Next(1, 6));
            }
        }

        private static void GenAdversarialOOO(List<ParsedPositionEvent> evs, ref DateTime t, Random rng)
        {
            // Spurious events: Update without prior Add, Remove without prior Add.
            string acct = "FuzzAcct"; string instr = "MNQ";
            // Stray Remove on flat (idle).
            evs.Add(MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            t = t.AddSeconds(2);
            // Now a real entry.
            evs.Add(MkPos(t, acct, instr, MarketPosition.Long, 3, "Add"));
            t = t.AddSeconds(2);
            // Update with a Quantity DROP (legitimate during partial close).
            evs.Add(MkPos(t, acct, instr, MarketPosition.Long, 1, "Update"));
            t = t.AddSeconds(2);
            evs.Add(MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
        }

        private static void GenManyReversals(List<ParsedPositionEvent> evs, ref DateTime t, Random rng)
        {
            string acct = "FuzzAcct"; string instr = "MNQ";
            var dir = rng.Next(2) == 0 ? MarketPosition.Long : MarketPosition.Short;
            int q   = rng.Next(1, 4);
            evs.Add(MkPos(t, acct, instr, dir, q, "Add"));
            t = t.AddSeconds(2);
            int reversals = rng.Next(3, 7);
            for (int i = 0; i < reversals; i++)
            {
                dir = dir == MarketPosition.Long ? MarketPosition.Short : MarketPosition.Long;
                q = rng.Next(1, 4);
                evs.Add(MkPos(t, acct, instr, dir, q, "Update"));
                t = t.AddSeconds(rng.Next(1, 5));
            }
            evs.Add(MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
        }

        private static ParsedPositionEvent MkPos(DateTime t, string acct, string instr,
                                                 MarketPosition dir, double qty, string op)
        {
            return new ParsedPositionEvent
            {
                Time         = t,
                Account      = acct,
                Instrument   = instr,
                Direction    = dir,
                Quantity     = qty,
                AveragePrice = 0,
                Operation    = op,
                RawLine      = string.Format("(synth) {0} dir={1} qty={2} op={3}",
                                             acct + "::" + instr, dir, qty, op),
            };
        }

        private static string ParseAccount(string posKey)
        {
            int idx = posKey.IndexOf("::", StringComparison.Ordinal);
            return idx < 0 ? posKey : posKey.Substring(0, idx);
        }

        private static string ParseInstrument(string posKey)
        {
            int idx = posKey.IndexOf("::", StringComparison.Ordinal);
            return idx < 0 ? "" : posKey.Substring(idx + 2);
        }

        // ── Bug-1 regression: DESYNC shadow-clear followed by same-direction re-entry ─
        //
        // Scenario: Trade-1 opens → DESYNC fires (shadow cleared, lifecycle left open)
        //           → IntegrityCheck/Rule-3 retires lifecycle via REMOVE path (TotalTrades++)
        //           → Trade-2 opens on same posKey immediately after → closes → TotalTrades++
        //
        // Invariant: TotalTrades == 2 at end.
        // Pre-fix: REMOVE path overwriting _flatPending caused Trade-1's
        //          TryFallbackRecordTrade to silently skip → TotalTrades == 1.
        // Post-fix: lifecycle-ID dedup in TryFallbackRecordTrade ensures both count.
        private static FuzzScenarioResult RunDesyncQuickReentry(int seed)
        {
            string acct  = "FuzzAcct";
            string instr = "MNQ";
            string posKey = acct + "::" + instr;

            var sim = new StandalonePositionSimulator
            {
                SubscriptionTimeUtc = new DateTime(2026, 1, 1, 9, 30, 0, DateTimeKind.Utc),
                BootstrapWindow     = TimeSpan.FromSeconds(2.0),
            };
            DateTime t = sim.SubscriptionTimeUtc + TimeSpan.FromSeconds(5); // post-bootstrap

            var violated = new List<string>();

            // ── Trade 1: ADD ──────────────────────────────────────────────────────────
            string edge1 = sim.ApplyPositionEvent(posKey,
                MkPos(t, acct, instr, MarketPosition.Short, 3, "Add"));
            if (edge1 != "ADD") violated.Add("Trade1: expected ADD edge, got " + edge1);
            if (sim.SessionEntryCount != 1) violated.Add("Trade1: SessionEntryCount should be 1");

            t = t.AddSeconds(5);

            // ── DESYNC: shadow cleared, lifecycle left open (old buggy Rule-3 behaviour) ──
            // In the FIXED code, Rule 3 now calls ReconcileLifecycleEdgeAtomic(Flat)
            // which retires the lifecycle (TotalTrades++) before clearing shadow.
            // ── REMOVE fires (simulates IntegrityCheck/Rule-3 calling ReconcileLifecycleEdgeAtomic(Flat)).
            // In new arch: REMOVE sets IsRemoved=true but TryRecordTrade returns SKIP_FILLS_PENDING
            // until the close fill arrives.
            string removeEdge = sim.ApplyPositionEvent(posKey,
                MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            if (removeEdge != "REMOVE") violated.Add("DESYNC retire: expected REMOVE edge, got " + removeEdge);

            // Inject synthetic close fill (Path A: REMOVE fired before fill).
            // In new arch this is what triggers TryRecordTrade to pass all three gates.
            sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time = t.AddMilliseconds(10), Account = acct, Instrument = instr,
                FillSide = MarketPosition.Long, Quantity = 3, Pnl = -50.0,
                RawLine = "(synth close-fill trade1)",
            });

            // TotalTrades should be 1 AFTER close fill (gate: IsRemoved=true AND fills arrived)
            if (sim.TotalTrades != 1) violated.Add("After DESYNC retire + close fill: TotalTrades should be 1, was " + sim.TotalTrades);

            t = t.AddSeconds(1);

            // ── Trade 2: ADD on same posKey, same direction as Trade 1 ──────────────
            string edge2 = sim.ApplyPositionEvent(posKey,
                MkPos(t, acct, instr, MarketPosition.Short, 2, "Add"));
            if (edge2 != "ADD") violated.Add("Trade2: expected ADD edge, got " + edge2);
            if (sim.SessionEntryCount != 2) violated.Add("Trade2: SessionEntryCount should be 2");

            t = t.AddSeconds(3);

            // ── Trade 2: REMOVE ───────────────────────────────────────────────────────
            string edge3 = sim.ApplyPositionEvent(posKey,
                MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            if (edge3 != "REMOVE") violated.Add("Trade2 close: expected REMOVE edge, got " + edge3);

            sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time = t.AddMilliseconds(10), Account = acct, Instrument = instr,
                FillSide = MarketPosition.Long, Quantity = 2, RawLine = "(synth close-fill trade2)",
            });

            // ── Invariant: TotalTrades == 2 ──────────────────────────────────────────
            if (sim.TotalTrades != 2)
                violated.Add(string.Format(
                    "HUD trade count: expected TotalTrades=2, got {0}. Bug-1 regression: DESYNC dropped Trade-1.",
                    sim.TotalTrades));
            if (sim.SessionEntryCount != 2)
                violated.Add(string.Format(
                    "SessionEntryCount: expected 2, got {0}.", sim.SessionEntryCount));

            // Final integrity check (all positions flat)
            var residual = IntegrityCheck.Run(sim.BuildSnapshot(
                new Dictionary<string, Nt8PositionSnap>(), inBootstrap: false));
            int actionable = residual.Count(v => v.Severity != IntegritySeverity.Info);

            return new FuzzScenarioResult
            {
                Name               = "DesyncQuickReentry",
                Seed               = seed,
                EventsGenerated    = 5, // 2 ADD + 2 REMOVE + 1 DESYNC retire
                Passed             = violated.Count == 0 && actionable == 0,
                ViolatedInvariants = violated,
                ResidualViolations = residual,
            };
        }

        // ── Bug-2 regression: stale ghost direction across Market Replay mode transition ─
        //
        // Scenario: Session-A opens a Long trade but no REMOVE fires (ghost lifecycle).
        //           Mode transition fires → ClearAllPositionTrackingState.
        //           Session-B starts a Short trade → no "Stale direction cleared" false alarm.
        //
        // Invariant: TotalTrades after Session-B's close == 1 (only Session-B counts; the
        //            in-flight Session-A lifecycle is cleared without recording).
        //            SessionEntryCount == 1.
        //            No ghost lifecycle in _lifecycles after the mode transition.
        private static FuzzScenarioResult RunCrossSessionGhostContamination(int seed)
        {
            string acct  = "FuzzAcct";
            string instr = "MNQ";
            string posKey = acct + "::" + instr;

            var sim = new StandalonePositionSimulator
            {
                SubscriptionTimeUtc = new DateTime(2026, 1, 1, 9, 30, 0, DateTimeKind.Utc),
                BootstrapWindow     = TimeSpan.FromSeconds(2.0),
            };
            DateTime t = sim.SubscriptionTimeUtc + TimeSpan.FromSeconds(5);

            var violated = new List<string>();

            // ── Session A: Long trade opens, never closes (ghost lifecycle) ─────────
            string addEdge = sim.ApplyPositionEvent(posKey,
                MkPos(t, acct, instr, MarketPosition.Long, 2, "Add"));
            if (addEdge != "ADD") violated.Add("SessionA: expected ADD edge, got " + addEdge);
            t = t.AddSeconds(10);

            // ── Mode transition (Market Replay restart) → ClearAllPositionTrackingState ──
            // In production: OnTradingModeChanged calls ClearAllPositionTrackingState.
            // In simulator: SimulateModeTransition.
            sim.SimulateModeTransition();

            // After mode transition: lifecycle must be gone, shadow must be clear.
            if (sim.Lifecycles.ContainsKey(posKey))
                violated.Add("After mode transition: lifecycle still in _lifecycles (ghost contamination).");
            if (sim.PositionDirections.ContainsKey(posKey))
                violated.Add("After mode transition: shadow direction still set (stale Long will trigger 'Stale direction cleared').");
            if (sim.TotalTrades != 0)
                violated.Add("After mode transition: TotalTrades should still be 0 (in-flight trade from old domain not recorded).");

            // Reset session state to simulate new session
            sim.SessionEntryCount = 0;

            // ── Session B: New subscription time (new replay session) ──────────────
            sim.SubscriptionTimeUtc = t;
            t = t.AddSeconds(5); // post-bootstrap for Session B

            // Trade B-1: Short (would previously trigger "Stale direction cleared: tracked=Long")
            string edgeB1 = sim.ApplyPositionEvent(posKey,
                MkPos(t, acct, instr, MarketPosition.Short, 1, "Add"));
            if (edgeB1 != "ADD")
                violated.Add("SessionB Trade1: expected ADD edge (no ghost contamination), got " + edgeB1);
            if (sim.SessionEntryCount != 1)
                violated.Add("SessionB: SessionEntryCount should be 1 after first entry.");

            t = t.AddSeconds(3);
            string edgeB2 = sim.ApplyPositionEvent(posKey,
                MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            if (edgeB2 != "REMOVE") violated.Add("SessionB Trade1 close: expected REMOVE, got " + edgeB2);

            sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time = t.AddMilliseconds(10), Account = acct, Instrument = instr,
                FillSide = MarketPosition.Long, Quantity = 1, RawLine = "(synth close SessionB)",
            });

            // ── Invariant: only Session-B's trade is counted ──────────────────────
            if (sim.TotalTrades != 1)
                violated.Add(string.Format(
                    "TotalTrades: expected 1 (only Session-B), got {0}. Ghost from Session-A may have been double-counted or lost.",
                    sim.TotalTrades));

            var residual = IntegrityCheck.Run(sim.BuildSnapshot(
                new Dictionary<string, Nt8PositionSnap>(), inBootstrap: false));
            int actionable = residual.Count(v => v.Severity != IntegritySeverity.Info);

            return new FuzzScenarioResult
            {
                Name               = "CrossSessionGhostContamination",
                Seed               = seed,
                EventsGenerated    = 3, // SessionA ADD + mode-transition + SessionB ADD+REMOVE
                Passed             = violated.Count == 0 && actionable == 0,
                ViolatedInvariants = violated,
                ResidualViolations = residual,
            };
        }

        // ── Bug-3 regression scenario ─────────────────────────────────────────────
        //
        // Reproduces the cascade observed in the 2026-04-24 07-31 PM session:
        //   1. Trade 1 closes via Position-REMOVE → TryFallbackRecordTrade path.
        //   2. TryFallbackRecordTrade fires (simulated): must clear _positionDirections
        //      and _positionQuantities.
        //   3. Trade 2 Short ADD fires → lifecycle created correctly.
        //   4. An execution-level stale-direction-clear check fires AFTER the lifecycle
        //      is already open with the correct Short direction → lifecycle must NOT be
        //      retired (Fix B guard).
        //
        // If Fix A is absent: _positionDirections stays Long → stale-direction-clear
        //   retires the new lifecycle → phantom RecordTrade + correct trade missed.
        // If Fix B is absent: even with Fix A, if the fallback hasn't fired yet (< 200ms),
        //   the new lifecycle is retired and a spurious TryFallbackRecordTrade fires.
        //
        // Invariant: TotalTrades == 2 (Trade 1 via fallback, Trade 2 via normal REMOVE).
        //            No phantom extra trades from the stale-direction-clear cascade.
        private static FuzzScenarioResult RunStaleDirAfterReversalSuppressed(int seed)
        {
            string acct   = "FuzzAcct";
            string instr  = "MNQ";
            string posKey = acct + "::" + instr;

            var sim = new StandalonePositionSimulator
            {
                SubscriptionTimeUtc = new DateTime(2026, 1, 1, 9, 30, 0, DateTimeKind.Utc),
                BootstrapWindow     = TimeSpan.FromSeconds(2.0),
            };
            DateTime t = sim.SubscriptionTimeUtc + TimeSpan.FromSeconds(5);

            var violated = new List<string>();

            // ── Trade 1: Long ADD (3 lots) ────────────────────────────────────────
            string e1 = sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Long,  1, "Add"));
            t = t.AddMilliseconds(100);
            string e2 = sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Long,  2, "Update"));
            t = t.AddMilliseconds(100);
            string e3 = sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Long,  3, "Update"));

            if (e1 != "ADD"    ||
                e2 != "UPDATE" ||
                e3 != "UPDATE")
                violated.Add(string.Format("Trade-1 entry edges: expected ADD,UPDATE,UPDATE got {0},{1},{2}", e1, e2, e3));

            t = t.AddSeconds(20);

            // ── Trade 1 closes: Position REMOVE ──────────────────────────────────
            string eRem = sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            if (eRem != "REMOVE")
                violated.Add("Trade-1 close: expected REMOVE edge, got " + eRem);

            // In new arch: REMOVE alone is SKIP_FILLS_PENDING — need close fill.
            // Inject 3-lot close fill for Trade-1 so TryRecordTrade can pass all gates.
            sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time = eRem == "REMOVE" ? t.AddMilliseconds(10) : t,
                Account = acct, Instrument = instr,
                FillSide = MarketPosition.Short,  // BuyToCover to close Long
                Quantity = 3, Pnl = 75.0,
                RawLine = "(synth close-fill trade1)",
            });

            // TotalTrades should be 1 after REMOVE + close fill
            if (sim.TotalTrades != 1)
                violated.Add(string.Format("After Trade-1 REMOVE+fill: TotalTrades expected 1, got {0}.", sim.TotalTrades));

            // Simulate the shadow-dict cleanup that production code does after close.
            sim.SimulateFallbackShadowCleanup(posKey);

            // After fallback cleanup, shadow direction must be cleared.
            if (sim.PositionDirections.ContainsKey(posKey))
                violated.Add("After FallbackShadowCleanup: _positionDirections still set (Fix A missing — stale-direction-clear cascade will follow).");
            if (sim.PositionQuantities.ContainsKey(posKey))
                violated.Add("After FallbackShadowCleanup: _positionQuantities still set (REVERSAL-SUPPRESSED corruption not cleaned).");

            t = t.AddSeconds(3); // 3 seconds later — well after 200ms fallback window

            // ── Trade 2: Short ADD (3 lots) ───────────────────────────────────────
            string e4 = sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Short, 1, "Add"));
            t = t.AddMilliseconds(100);
            string e5 = sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Short, 2, "Update"));
            t = t.AddMilliseconds(100);
            string e6 = sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Short, 3, "Update"));

            if (e4 != "ADD"    ||
                e5 != "UPDATE" ||
                e6 != "UPDATE")
                violated.Add(string.Format("Trade-2 entry edges: expected ADD,UPDATE,UPDATE got {0},{1},{2}", e4, e5, e6));

            // The lifecycle created for Trade 2 must be Short (not stale Long).
            SimLifecycle lifeT2;
            if (!sim.Lifecycles.TryGetValue(posKey, out lifeT2))
                violated.Add("Trade-2: no lifecycle found after ADD (lifecycle creation failed).");
            else if (lifeT2.Direction != MarketPosition.Short)
                violated.Add(string.Format("Trade-2: lifecycle direction expected Short, got {0}.", lifeT2.Direction));

            // Simulate Fix B: stale-direction-clear with lifecycle already correct.
            // After Fix A cleared the shadow, the shadow direction is Short (from ADD above).
            // A stale-direction-clear fire at this point must NOT retire the lifecycle.
            string staleClearResult = sim.SimulateStaleDirClear(posKey, MarketPosition.Short);
            if (staleClearResult != "DICT_CORRECTED")
                violated.Add(string.Format(
                    "Fix-B: SimulateStaleDirClear should return DICT_CORRECTED when lifecycle direction matches fill, got {0}.",
                    staleClearResult));

            // After Fix B, lifecycle must still be alive.
            if (!sim.Lifecycles.ContainsKey(posKey))
                violated.Add("Fix-B: lifecycle was retired by stale-direction-clear even though direction matched fill (Fix B missing).");

            t = t.AddSeconds(10);

            // ── Trade 2 closes ────────────────────────────────────────────────────
            string eRem2 = sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            if (eRem2 != "REMOVE")
                violated.Add("Trade-2 close: expected REMOVE edge, got " + eRem2);

            // Inject close fill for Trade-2 so TryRecordTrade passes all gates
            sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time = t.AddMilliseconds(10), Account = acct, Instrument = instr,
                FillSide = MarketPosition.Long,  // BuyToCover to close Short
                Quantity = 3, Pnl = -30.0,
                RawLine = "(synth close-fill trade2)",
            });

            if (sim.TotalTrades != 2)
                violated.Add(string.Format(
                    "Final TotalTrades: expected 2 (one per real trade), got {0}. Phantom trades from stale-direction-clear cascade?",
                    sim.TotalTrades));

            var residual = IntegrityCheck.Run(sim.BuildSnapshot(
                new Dictionary<string, Nt8PositionSnap>(), inBootstrap: false));
            int actionable = residual.Count(v => v.Severity != IntegritySeverity.Info);

            return new FuzzScenarioResult
            {
                Name               = "StaleDirAfterReversalSuppressed",
                Seed               = seed,
                EventsGenerated    = 8,
                Passed             = violated.Count == 0 && actionable == 0,
                ViolatedInvariants = violated,
                ResidualViolations = residual,
            };
        }

        // =====================================================================
        // New lifecycle-centric architecture scenarios
        // =====================================================================

        // ── PathARemoveBeforeFills ─────────────────────────────────────────────
        // Scenario: NT8 fires Position REMOVE BEFORE the close execution fill.
        //   1. ADD 2-lot Long position (observed entry).
        //   2. Position REMOVE fires (TryRecordTrade → SKIP_FILLS_PENDING).
        //   3. Close execution fill arrives AFTER Remove (Path A).
        //   4. TryRecordTrade fires from ApplyExecutionEvent → RECORDED.
        //
        // Invariant: TotalTrades == 1 after step 4.
        //            RetiringLifecycles is empty (lifecycle consumed by fill).
        //            IntegrityCheck residual == 0.
        private static FuzzScenarioResult RunPathARemoveBeforeFills(int seed)
        {
            string acct   = "FuzzAcct";
            string instr  = "MNQ";
            string posKey = acct + "::" + instr;
            var violated  = new List<string>();

            var sim = new StandalonePositionSimulator
            {
                SubscriptionTimeUtc = new DateTime(2026, 1, 1, 9, 30, 0, DateTimeKind.Utc),
                BootstrapWindow     = TimeSpan.FromSeconds(2.0),
            };
            DateTime t = sim.SubscriptionTimeUtc + TimeSpan.FromSeconds(5);

            // Step 1: ADD
            string e1 = sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Long, 2, "Add"));
            if (e1 != "ADD") violated.Add("Expected ADD, got " + e1);
            if (sim.SessionEntryCount != 1) violated.Add("SessionEntryCount expected 1, got " + sim.SessionEntryCount);

            t = t.AddSeconds(30);

            // Step 2: REMOVE fires (fills not yet arrived → SKIP_FILLS_PENDING)
            string e2 = sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            if (e2 != "REMOVE") violated.Add("Expected REMOVE, got " + e2);
            if (sim.TotalTrades != 0)
                violated.Add("After REMOVE only (no fills): TotalTrades should be 0, was " + sim.TotalTrades);
            if (!sim.RetiringLifecycles.ContainsKey(posKey))
                violated.Add("After REMOVE: lifecycle not in RetiringLifecycles");

            // Step 3: Close fill arrives 50ms after REMOVE (Path A)
            string e3 = sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time     = t.AddMilliseconds(50),
                Account  = acct, Instrument = instr,
                FillSide = MarketPosition.Short,   // sell to close Long
                Quantity = 2, Pnl = 125.0,
                RawLine  = "(synth Path-A close fill)",
            });
            if (e3 != "EXEC_CLOSE_RETIRING")
                violated.Add("Path A close fill: expected EXEC_CLOSE_RETIRING, got " + e3);

            // Step 4: Invariants after Path A close fill
            if (sim.TotalTrades != 1)
                violated.Add("After Path A close fill: TotalTrades expected 1, got " + sim.TotalTrades);
            if (sim.RetiringLifecycles.ContainsKey(posKey))
                violated.Add("After recording: RetiringLifecycles should be empty");

            var nt8Truth = new Dictionary<string, Nt8PositionSnap>(); // NT8 is flat
            var residual = IntegrityCheck.Run(sim.BuildSnapshot(nt8Truth, inBootstrap: false));
            int actionable = residual.Count(v => v.Severity != IntegritySeverity.Info);

            return new FuzzScenarioResult
            {
                Name               = "PathARemoveBeforeFills",
                Seed               = seed,
                EventsGenerated    = 3,
                Passed             = violated.Count == 0 && actionable == 0,
                ViolatedInvariants = violated,
                ResidualViolations = residual,
            };
        }

        // ── PathBFillsBeforeRemove ─────────────────────────────────────────────
        // Scenario: 3 close fills arrive BEFORE NT8 fires Position REMOVE.
        //   1. ADD 3-lot Long position (observed entry).
        //   2. Three close fills arrive (each 1-lot partial fill). After each,
        //      TryRecordTrade returns SKIP_NOT_REMOVED (IsRemoved still false).
        //   3. Position REMOVE fires.  REMOVE calls TryRecordTrade:
        //      all 3 fills already in AccumulatedPnl, PostCloseQty=3=QtyAtLastScaleIn
        //      → RECORDED.
        //
        // Invariant: TotalTrades == 1 after REMOVE with correct accumulated PnL.
        //            No fill is double-counted.
        private static FuzzScenarioResult RunPathBFillsBeforeRemove(int seed)
        {
            string acct   = "FuzzAcct";
            string instr  = "ES";
            string posKey = acct + "::" + instr;
            var violated  = new List<string>();

            var sim = new StandalonePositionSimulator
            {
                SubscriptionTimeUtc = new DateTime(2026, 1, 1, 9, 30, 0, DateTimeKind.Utc),
                BootstrapWindow     = TimeSpan.FromSeconds(2.0),
            };
            DateTime t = sim.SubscriptionTimeUtc + TimeSpan.FromSeconds(5);

            // Step 1: ADD 3-lot Long
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Long, 3, "Add"));
            t = t.AddSeconds(60);

            // Step 2: 3 close fills arrive (3 × 1-lot) BEFORE REMOVE
            // Fill 1
            string f1 = sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time     = t, Account = acct, Instrument = instr,
                FillSide = MarketPosition.Short, Quantity = 1, Pnl = -50.0,
                RawLine  = "(fill 1 of 3)",
            });
            if (sim.TotalTrades != 0)
                violated.Add("After fill 1 (no REMOVE yet): TotalTrades should be 0");

            // Fill 2
            t = t.AddMilliseconds(50);
            string f2 = sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time     = t, Account = acct, Instrument = instr,
                FillSide = MarketPosition.Short, Quantity = 1, Pnl = -25.0,
                RawLine  = "(fill 2 of 3)",
            });
            if (sim.TotalTrades != 0)
                violated.Add("After fill 2 (no REMOVE yet): TotalTrades should be 0");

            // Fill 3
            t = t.AddMilliseconds(50);
            string f3 = sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time     = t, Account = acct, Instrument = instr,
                FillSide = MarketPosition.Short, Quantity = 1, Pnl = 10.0,
                RawLine  = "(fill 3 of 3)",
            });
            if (sim.TotalTrades != 0)
                violated.Add("After fill 3 (no REMOVE yet): TotalTrades should be 0");

            // Step 3: REMOVE fires — all fills already accumulated → RECORDED
            t = t.AddMilliseconds(200);
            string eRem = sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            if (eRem != "REMOVE") violated.Add("Expected REMOVE, got " + eRem);
            if (sim.TotalTrades != 1)
                violated.Add("After Path B REMOVE: TotalTrades expected 1, got " + sim.TotalTrades);

            // Verify PnL is sum of all 3 fills (no double-counting)
            // Note: simulator doesn't expose AccumulatedPnl after recording, so we
            // just verify the lifecycle is consumed and TotalTrades is exactly 1.
            if (sim.RetiringLifecycles.ContainsKey(posKey))
                violated.Add("After recording: RetiringLifecycles should be empty");

            // Second REMOVE (duplicate event, common during NT8 reconnect) must be no-op
            sim.ApplyPositionEvent(posKey, MkPos(t.AddMilliseconds(1), acct, instr, MarketPosition.Flat, 0, "Remove"));
            if (sim.TotalTrades != 1)
                violated.Add("Duplicate REMOVE produced phantom trade (double-count)");

            var nt8Truth = new Dictionary<string, Nt8PositionSnap>();
            var residual = IntegrityCheck.Run(sim.BuildSnapshot(nt8Truth, inBootstrap: false));
            int actionable = residual.Count(v => v.Severity != IntegritySeverity.Info);

            return new FuzzScenarioResult
            {
                Name               = "PathBFillsBeforeRemove",
                Seed               = seed,
                EventsGenerated    = 5,
                Passed             = violated.Count == 0 && actionable == 0,
                ViolatedInvariants = violated,
                ResidualViolations = residual,
            };
        }

        // ── ScaleOutThenClose ─────────────────────────────────────────────────
        // Scenario: 3-lot position, partial scale-out (1 lot), then full close (2 lots).
        //   Tests that QtyAtLastScaleIn / PostLastScaleInCloseQty gate works correctly
        //   for scale-out: the single trade records after BOTH fills total the full qty.
        //
        //   1. ADD 3-lot Long.
        //   2. UPDATE → 2-lot (scale-out via partial close fill).
        //   3. Close fill for 1 lot arrives.
        //   4. Close fill for 2 lots arrives.
        //   5. REMOVE fires.
        //   Invariant: TotalTrades == 1 (not 2). Single trade with sum PnL.
        //
        //   Also tests scale-IN: add a 4th lot after step 1, then close all 4.
        //   The gate resets QtyAtLastScaleIn to 4 on UPDATE-increase.
        private static FuzzScenarioResult RunScaleOutThenClose(int seed)
        {
            string acct   = "FuzzAcct";
            string instr  = "NQ";
            string posKey = acct + "::" + instr;
            var violated  = new List<string>();

            var sim = new StandalonePositionSimulator
            {
                SubscriptionTimeUtc = new DateTime(2026, 1, 1, 9, 30, 0, DateTimeKind.Utc),
                BootstrapWindow     = TimeSpan.FromSeconds(2.0),
            };
            DateTime t = sim.SubscriptionTimeUtc + TimeSpan.FromSeconds(5);

            // ── Scenario A: 3-lot with scale-out ─────────────────────────────
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Long, 3, "Add"));
            t = t.AddSeconds(10);

            // Partial scale-out: UPDATE shows position reduced to 2
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Long, 2, "Update"));

            // Scale-out close fill (1 lot)
            sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time = t.AddMilliseconds(20), Account = acct, Instrument = instr,
                FillSide = MarketPosition.Short, Quantity = 1, Pnl = 50.0,
                RawLine = "(scale-out fill 1/3)",
            });
            if (sim.TotalTrades != 0)
                violated.Add("After scale-out fill (REMOVE not yet fired): TotalTrades should be 0");

            t = t.AddSeconds(20);

            // Full close: UPDATE shows position reduced to 0 then REMOVE fires
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Long, 2, "Update")); // NT8 may emit this

            // Close fill for remaining 2 lots
            sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time = t.AddMilliseconds(20), Account = acct, Instrument = instr,
                FillSide = MarketPosition.Short, Quantity = 2, Pnl = -30.0,
                RawLine = "(full close fill 2+3/3)",
            });

            // REMOVE fires after final close
            string eRem = sim.ApplyPositionEvent(posKey, MkPos(t.AddMilliseconds(100), acct, instr, MarketPosition.Flat, 0, "Remove"));
            if (eRem != "REMOVE") violated.Add("ScenarioA: expected REMOVE, got " + eRem);
            if (sim.TotalTrades != 1)
                violated.Add("ScenarioA: TotalTrades expected 1 (not 2), got " + sim.TotalTrades);

            // ── Scenario B (same posKey after gap): scale-IN then close ──────
            t = t.AddSeconds(60);
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Short, 1, "Add"));
            t = t.AddSeconds(2);
            // Scale-IN: position grows from 1→3
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Short, 2, "Update"));
            sim.ApplyPositionEvent(posKey, MkPos(t.AddMilliseconds(50), acct, instr, MarketPosition.Short, 3, "Update"));
            // QtyAtLastScaleIn should now be 3
            SimLifecycle lifeB;
            if (!sim.Lifecycles.TryGetValue(posKey, out lifeB))
                violated.Add("ScenarioB: no lifecycle after scale-in");
            else if (lifeB.QtyAtLastScaleIn != 3)
                violated.Add("ScenarioB: QtyAtLastScaleIn expected 3 (scale-in reset), got " + lifeB.QtyAtLastScaleIn);

            t = t.AddSeconds(30);
            // Close all 3 lots in one fill
            sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time = t, Account = acct, Instrument = instr,
                FillSide = MarketPosition.Long, Quantity = 3, Pnl = 200.0,
                RawLine = "(full close scale-in position)",
            });
            sim.ApplyPositionEvent(posKey, MkPos(t.AddMilliseconds(50), acct, instr, MarketPosition.Flat, 0, "Remove"));
            if (sim.TotalTrades != 2)
                violated.Add("ScenarioB: TotalTrades expected 2 after scale-in position, got " + sim.TotalTrades);

            var nt8Truth = new Dictionary<string, Nt8PositionSnap>();
            var residual = IntegrityCheck.Run(sim.BuildSnapshot(nt8Truth, inBootstrap: false));
            int actionable = residual.Count(v => v.Severity != IntegritySeverity.Info);

            return new FuzzScenarioResult
            {
                Name               = "ScaleOutThenClose",
                Seed               = seed,
                EventsGenerated    = 12,
                Passed             = violated.Count == 0 && actionable == 0,
                ViolatedInvariants = violated,
                ResidualViolations = residual,
            };
        }

        // ── B3ForceComplete ───────────────────────────────────────────────────
        // Scenario: NT8 fires REMOVE, lifecycle enters RetiringLifecycles, but
        //   the close fill NEVER arrives (NT8 bug / fill lost in transit).
        //   IntegrityCheck B3 repair must force-complete after 5s.
        //
        //   1. ADD 2-lot observed position.
        //   2. REMOVE fires → lifecycle in RetiringLifecycles, TotalTrades=0.
        //   3. Only a PARTIAL fill (1 lot) arrives. Gate still blocks (1 < 2).
        //   4. SimulateB3ForceComplete fires → accepts partial PnL → RECORDED.
        //   Invariant: TotalTrades == 1 after B3. IntegrityCheck residual == 0.
        private static FuzzScenarioResult RunB3ForceComplete(int seed)
        {
            string acct   = "FuzzAcct";
            string instr  = "MES";
            string posKey = acct + "::" + instr;
            var violated  = new List<string>();

            var sim = new StandalonePositionSimulator
            {
                SubscriptionTimeUtc = new DateTime(2026, 1, 1, 9, 30, 0, DateTimeKind.Utc),
                BootstrapWindow     = TimeSpan.FromSeconds(2.0),
            };
            DateTime t = sim.SubscriptionTimeUtc + TimeSpan.FromSeconds(5);

            // ADD 2-lot observed position
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Long, 2, "Add"));
            t = t.AddSeconds(30);

            // REMOVE fires
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            if (sim.TotalTrades != 0)
                violated.Add("After REMOVE (no fills): TotalTrades should be 0");
            if (!sim.RetiringLifecycles.ContainsKey(posKey))
                violated.Add("Lifecycle not in RetiringLifecycles after REMOVE");

            // Only 1 of 2 expected fills arrives (partial — NT8 bug)
            sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time = t.AddMilliseconds(100), Account = acct, Instrument = instr,
                FillSide = MarketPosition.Short, Quantity = 1, Pnl = 62.5,
                RawLine  = "(partial fill — 1 of 2 lots arrived)",
            });
            if (sim.TotalTrades != 0)
                violated.Add("After partial fill only: TotalTrades should still be 0 (gate: 1 < 2)");
            if (!sim.RetiringLifecycles.ContainsKey(posKey))
                violated.Add("Lifecycle should still be in RetiringLifecycles (not yet complete)");

            // 5+ seconds pass. IntegrityCheck B3 fires (simulated via SimulateB3ForceComplete).
            string b3Result = sim.SimulateB3ForceComplete(posKey);
            if (!b3Result.Contains("RECORDED"))
                violated.Add("B3 force-complete: expected RECORDED in result, got " + b3Result);
            if (sim.TotalTrades != 1)
                violated.Add("After B3 ForceComplete: TotalTrades expected 1, got " + sim.TotalTrades);
            if (sim.RetiringLifecycles.ContainsKey(posKey))
                violated.Add("After B3: RetiringLifecycles should be empty");

            // Idempotency: calling B3 again must be a no-op
            sim.SimulateB3ForceComplete(posKey);
            if (sim.TotalTrades != 1)
                violated.Add("B3 ForceComplete is not idempotent — TotalTrades incremented again");

            var nt8Truth = new Dictionary<string, Nt8PositionSnap>();
            var residual = IntegrityCheck.Run(sim.BuildSnapshot(nt8Truth, inBootstrap: false));
            int actionable = residual.Count(v => v.Severity != IntegritySeverity.Info);

            return new FuzzScenarioResult
            {
                Name               = "B3ForceComplete",
                Seed               = seed,
                EventsGenerated    = 4,
                Passed             = violated.Count == 0 && actionable == 0,
                ViolatedInvariants = violated,
                ResidualViolations = residual,
            };
        }

        // ── OvernightRetiringStuck ────────────────────────────────────────────
        // Scenario: session boundary fires while a lifecycle is still in
        //   RetiringLifecycles (REMOVE fired at EOD, close fill not yet processed).
        //   SimulateOvernightDecay must force-complete it so the trade is not lost.
        //
        //   Also tests that an overnight hold (position open across midnight) is
        //   correctly preserved into the next session and recorded when it eventually
        //   closes.
        //
        //   Session A:
        //     Trade 1: completes normally before EOD → TotalTrades=1.
        //     Trade 2: REMOVE fires at EOD but close fill hasn't processed yet
        //              → SimulateOvernightDecay force-completes it → TotalTrades=2.
        //   Session B (next day):
        //     Position held overnight (from before Session B subscription) — bootstrap
        //     ghost, should NOT count as a trade.
        //     Trade 3: new observed position opens and closes → TotalTrades=3.
        private static FuzzScenarioResult RunOvernightRetiringStuck(int seed)
        {
            string acct   = "FuzzAcct";
            string instr  = "RTY";
            string posKey = acct + "::" + instr;
            var violated  = new List<string>();

            var sim = new StandalonePositionSimulator
            {
                SubscriptionTimeUtc = new DateTime(2026, 1, 1, 9, 30, 0, DateTimeKind.Utc),
                BootstrapWindow     = TimeSpan.FromSeconds(2.0),
            };
            DateTime t = sim.SubscriptionTimeUtc + TimeSpan.FromSeconds(5);

            // ── Session A: Trade 1 — normal close ──────────────────────────────
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Long, 1, "Add"));
            t = t.AddSeconds(30);
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            // Close fill arrives normally
            sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time = t.AddMilliseconds(50), Account = acct, Instrument = instr,
                FillSide = MarketPosition.Short, Quantity = 1, Pnl = 40.0,
                RawLine  = "(Trade1 close)",
            });
            if (sim.TotalTrades != 1)
                violated.Add("After Trade-1: TotalTrades expected 1, got " + sim.TotalTrades);

            // ── Session A: Trade 2 — REMOVE fires at EOD, fill NOT yet processed ─
            t = t.AddSeconds(3600);
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Short, 2, "Add"));
            t = t.AddSeconds(120);
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            // Note: close fill NOT injected here — simulates EOD where fill is still in transit

            if (sim.TotalTrades != 1)
                violated.Add("After Trade-2 REMOVE (no fill): TotalTrades should still be 1");
            if (!sim.RetiringLifecycles.ContainsKey(posKey))
                violated.Add("Trade-2 lifecycle should be in RetiringLifecycles");

            // ── EOD: overnight decay fires — must force-complete Trade 2 ───────
            sim.SimulateOvernightDecay();

            if (sim.TotalTrades != 2)
                violated.Add("After OvernightDecay: TotalTrades expected 2 (Trade-2 force-completed), got " + sim.TotalTrades);
            if (sim.RetiringLifecycles.ContainsKey(posKey))
                violated.Add("After OvernightDecay: RetiringLifecycles should be empty");
            if (sim.SessionEntryCount != 0)
                violated.Add("After OvernightDecay: SessionEntryCount should be reset to 0, got " + sim.SessionEntryCount);

            // ── Session B: bootstrap ghost (position held overnight, pre-subscription) ─
            t = t.AddSeconds(28800); // 8 hours later (next morning)
            sim.SubscriptionTimeUtc = t;  // new subscription
            // NT8 bootstrap replays this as "Add" but it's before BootstrapWindow
            sim.ApplyPositionEvent(posKey, MkPos(t.AddMilliseconds(100), acct, instr, MarketPosition.Long, 3, "Add"));
            // This ADD is within the bootstrap window → OriginObserved=false
            SimLifecycle ghostLife;
            if (!sim.Lifecycles.TryGetValue(posKey, out ghostLife))
                violated.Add("SessionB: ghost lifecycle not created");
            else if (ghostLife.OriginObserved)
                violated.Add("SessionB: ghost lifecycle should have OriginObserved=false (bootstrap)");

            // Ghost position closes (NT8 bootstrap REMOVE)
            t = t.AddMilliseconds(500);
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time = t.AddMilliseconds(50), Account = acct, Instrument = instr,
                FillSide = MarketPosition.Short, Quantity = 3, Pnl = 0.0,
                RawLine  = "(ghost close bootstrap)",
            });
            // Must NOT increment TotalTrades (bootstrap ghost)
            if (sim.TotalTrades != 2)
                violated.Add("After bootstrap ghost close: TotalTrades should still be 2, got " + sim.TotalTrades);

            // ── Session B: Trade 3 — observed entry, normal close ────────────
            t = t.AddSeconds(10); // post-bootstrap window
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Short, 1, "Add"));
            t = t.AddSeconds(60);
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Flat, 0, "Remove"));
            sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time = t.AddMilliseconds(50), Account = acct, Instrument = instr,
                FillSide = MarketPosition.Long, Quantity = 1, Pnl = -20.0,
                RawLine  = "(Trade3 close Session B)",
            });
            if (sim.TotalTrades != 3)
                violated.Add("After Trade-3 (SessionB): TotalTrades expected 3, got " + sim.TotalTrades);

            var nt8Truth = new Dictionary<string, Nt8PositionSnap>();
            var residual = IntegrityCheck.Run(sim.BuildSnapshot(nt8Truth, inBootstrap: false));
            int actionable = residual.Count(v => v.Severity != IntegritySeverity.Info);

            return new FuzzScenarioResult
            {
                Name               = "OvernightRetiringStuck",
                Seed               = seed,
                EventsGenerated    = 12,
                Passed             = violated.Count == 0 && actionable == 0,
                ViolatedInvariants = violated,
                ResidualViolations = residual,
            };
        }
        // ── B1MissedRemove ────────────────────────────────────────────────────
        // Scenario: NT8 fires the close fill but the Position REMOVE event is
        //   completely missed (NT8 bug in rare disconnect/reconnect cases).
        //   IntegrityCheck B1 repair detects: lifecycle still active + NT8 flat.
        //   Simulated via SimulateB1MissedRemove.
        //
        //   1. ADD 1-lot Long (observed).
        //   2. Close fill arrives — but REMOVE event is never fired.
        //      Lifecycle stays in _lifecycles (IsRemoved=false).
        //      TryRecordTrade called from ApplyExecutionEvent returns SKIP_NOT_REMOVED.
        //   3. SimulateB1MissedRemove: sets IsRemoved=true, moves to RetiringLifecycles,
        //      calls TryRecordTrade → RECORDED (fills already accumulated).
        //   Invariant: TotalTrades == 1 after B1 repair.
        //              IntegrityCheck residual == 0.
        private static FuzzScenarioResult RunB1MissedRemove(int seed)
        {
            string acct   = "FuzzAcct";
            string instr  = "CL";
            string posKey = acct + "::" + instr;
            var violated  = new List<string>();

            var sim = new StandalonePositionSimulator
            {
                SubscriptionTimeUtc = new DateTime(2026, 1, 1, 9, 30, 0, DateTimeKind.Utc),
                BootstrapWindow     = TimeSpan.FromSeconds(2.0),
            };
            DateTime t = sim.SubscriptionTimeUtc + TimeSpan.FromSeconds(5);

            // ADD 1-lot Long (observed)
            sim.ApplyPositionEvent(posKey, MkPos(t, acct, instr, MarketPosition.Long, 1, "Add"));
            t = t.AddSeconds(60);

            // Close fill arrives — but REMOVE never fires (missed event)
            string f1 = sim.ApplyExecutionEvent(posKey, new ParsedExecutionEvent
            {
                Time = t, Account = acct, Instrument = instr,
                FillSide = MarketPosition.Short, Quantity = 1, Pnl = 37.5,
                RawLine  = "(close fill — REMOVE never fires)",
            });
            // Fill is against active lifecycle: AccumulatedPnl updated, PostCloseQty updated
            // but TryRecordTrade returns SKIP_NOT_REMOVED (IsRemoved=false)
            if (sim.TotalTrades != 0)
                violated.Add("After close fill (no REMOVE): TotalTrades should be 0 (IsRemoved=false blocks gate)");
            if (!sim.Lifecycles.ContainsKey(posKey))
                violated.Add("Lifecycle should still be in active _lifecycles (no REMOVE fired)");

            // IntegrityCheck 1s timer fires: NT8 says flat, lifecycle still open → B1 repair
            string b1Result = sim.SimulateB1MissedRemove(posKey);
            if (!b1Result.Contains("RECORDED"))
                violated.Add("B1 repair: expected RECORDED, got " + b1Result);
            if (sim.TotalTrades != 1)
                violated.Add("After B1 repair: TotalTrades expected 1, got " + sim.TotalTrades);
            if (sim.Lifecycles.ContainsKey(posKey))
                violated.Add("After B1 repair: lifecycle should be gone from active _lifecycles");
            if (sim.RetiringLifecycles.ContainsKey(posKey))
                violated.Add("After B1 repair: lifecycle should be consumed from RetiringLifecycles");

            // Idempotency: calling B1 again must be a no-op
            sim.SimulateB1MissedRemove(posKey);
            if (sim.TotalTrades != 1)
                violated.Add("B1 repair is not idempotent — TotalTrades incremented again");

            var nt8Truth = new Dictionary<string, Nt8PositionSnap>();
            var residual = IntegrityCheck.Run(sim.BuildSnapshot(nt8Truth, inBootstrap: false));
            int actionable = residual.Count(v => v.Severity != IntegritySeverity.Info);

            return new FuzzScenarioResult
            {
                Name               = "B1MissedRemove",
                Seed               = seed,
                EventsGenerated    = 3,
                Passed             = violated.Count == 0 && actionable == 0,
                ViolatedInvariants = violated,
                ResidualViolations = residual,
            };
        }
    }
}

