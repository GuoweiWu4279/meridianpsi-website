// DemoDataSeeder.cs
//
// Marketing / screenshot helper — generates 5 months of realistic,
// story-driven fake session history so UI screenshots show a compelling
// "trader transformation arc".
//
// Story arc:
//   Dec 2025 — Chaos.    Revenge spirals. Two crash weeks.  False hope mid-month.
//   Jan 2026 — Flicker.  First big winning day (+$1,640) — then gives it back.
//   Feb 2026 — Pattern.  Clear weekday rhythm emerging; turning-point day Feb 18.
//   Mar 2026 — Surge.    Breakthrough month; two 4-session green streaks.
//   Apr 2026 — Control.  Strong streak, disciplined execution.
//
// Key design principles:
//   • Even bad months have green days (false hope) — realistic, builds tension.
//   • Even good months have a losing session or two — not every day is perfect.
//   • P&L is probabilistic with composure, not deterministic.
//   • ~10 "story anchor" sessions are hardcoded for narrative punch; the rest
//     are procedurally generated from monthly profiles.
//   • Dollar amounts reflect a realistic NQ futures trader ($20/point).
//
// Weekday pattern (visible in Intelligence Heatmap):
//   Wednesday = best (+10 composure, +$140 P&L bias)
//   Thursday  = good (+5, +$70)
//   Tuesday   = neutral (-2, +$15)
//   Monday    = rough (-8, -$90)
//   Friday    = worst (-12, -$130)

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal static class DemoDataSeeder
    {
        // =====================================================================
        // Monthly profiles
        // =====================================================================

        private struct MonthProfile
        {
            public int    Month, Year;
            public int    BaseComposure, ComposureSpread;
            public double BaseWinRate,   WinRateSpread;
            public double BaseAvgPnl,    PnlSpread;
            public double D1Bias,        D7Bias;
        }

        private static readonly MonthProfile[] Profiles =
        {
            new MonthProfile { Month=12, Year=2025, BaseComposure=50, ComposureSpread=15,
                BaseWinRate=0.37, WinRateSpread=0.12, BaseAvgPnl=-380, PnlSpread=1100,
                D1Bias=0.82, D7Bias=0.52 },
            new MonthProfile { Month= 1, Year=2026, BaseComposure=61, ComposureSpread=13,
                BaseWinRate=0.44, WinRateSpread=0.11, BaseAvgPnl= +95, PnlSpread= 950,
                D1Bias=0.55, D7Bias=0.32 },
            new MonthProfile { Month= 2, Year=2026, BaseComposure=68, ComposureSpread=11,
                BaseWinRate=0.51, WinRateSpread=0.10, BaseAvgPnl=+380, PnlSpread= 800,
                D1Bias=0.30, D7Bias=0.20 },
            new MonthProfile { Month= 3, Year=2026, BaseComposure=74, ComposureSpread= 9,
                BaseWinRate=0.58, WinRateSpread=0.08, BaseAvgPnl=+720, PnlSpread= 650,
                D1Bias=0.18, D7Bias=0.14 },
            new MonthProfile { Month= 4, Year=2026, BaseComposure=79, ComposureSpread= 7,
                BaseWinRate=0.63, WinRateSpread=0.07, BaseAvgPnl=+980, PnlSpread= 500,
                D1Bias=0.10, D7Bias=0.09 },
            new MonthProfile { Month= 5, Year=2026, BaseComposure=83, ComposureSpread= 6,
                BaseWinRate=0.66, WinRateSpread=0.06, BaseAvgPnl=+1150, PnlSpread= 420,
                D1Bias=0.07, D7Bias=0.06 },
        };

        // Weekday bias (index = (int)DayOfWeek: 0=Sun … 6=Sat)
        private static readonly int[]    ComposureDow = { 0, -8,  -2, +10,  +5, -12, 0 };
        private static readonly double[] PnlDow       = { 0, -90, +15, +140, +70, -130, 0 };

        // =====================================================================
        // Story anchor sessions — hardcoded for narrative punch
        // These override the procedural generation for specific key dates.
        //
        //  composure, pnl, total, wins
        // =====================================================================

        private static readonly Dictionary<DateTime, (int comp, double pnl, int total, int wins)>
            Anchors = new Dictionary<DateTime, (int, double, int, int)>
        {
            // ── December 2025: spiral and false hope ─────────────────────────
            // Week 1: decent start
            { new DateTime(2025, 12,  3), (68,  +840, 4, 3) },  // Wed: good start
            { new DateTime(2025, 12,  5), (51,  -620, 5, 2) },  // Fri: FOMO, gives some back

            // Week 2: the spiral
            // Dec 9 is a showcase session (CrashDaySummary) — composure/pnl set there
            { new DateTime(2025, 12, 10), (44, -1420, 7, 2) },  // Wed: still tilted day after crash
            { new DateTime(2025, 12, 11), (38, -1850, 8, 1) },  // Thu: deepest hole of the month
            { new DateTime(2025, 12, 12), (59,  +480, 4, 3) },  // Fri: lucky recovery, false hope

            // Week 3: false hope then second crash
            { new DateTime(2025, 12, 15), (65,  +920, 5, 4) },  // Mon: "I'm back!" — false hope
            { new DateTime(2025, 12, 16), (71,  +740, 4, 3) },  // Tue: two in a row, very convincing
            { new DateTime(2025, 12, 17), (47, -2140, 9, 2) },  // Wed: overconfidence → second crash
            { new DateTime(2025, 12, 19), (40, -1680, 7, 2) },  // Fri: still tilted

            // Week 4 (shortened): limping to year end
            { new DateTime(2025, 12, 22), (55,  +360, 3, 2) },  // Mon: cautious, small win
            { new DateTime(2025, 12, 23), (48,  -580, 5, 2) },  // Tue: back in old habits
            { new DateTime(2025, 12, 30), (58,  +290, 3, 2) },  // Tue: year-end quiet session
            { new DateTime(2025, 12, 31), (52,  -440, 4, 2) },  // Wed: flat end to a rough year

            // ── January 2026: flicker of hope ────────────────────────────────
            { new DateTime(2026,  1,  2), (55,  -680, 5, 2) },  // Fri: bad start to the year
            { new DateTime(2026,  1,  6), (63,  +520, 4, 3) },  // Tue: small win
            { new DateTime(2026,  1,  7), (72, +1640, 5, 4) },  // Wed: first BIG win — "it clicked"
            { new DateTime(2026,  1,  8), (58,  -390, 4, 2) },  // Thu: follow-through fades
            { new DateTime(2026,  1,  9), (44, -1580, 7, 2) },  // Fri: gives back Wed's gain
            { new DateTime(2026,  1, 13), (67,  +780, 5, 4) },  // Tue: rebounds
            { new DateTime(2026,  1, 14), (74, +1120, 4, 3) },  // Wed: second good week
            { new DateTime(2026,  1, 21), (69,  +640, 4, 3) },  // Wed: post-MLK
            { new DateTime(2026,  1, 22), (49,  -840, 6, 2) },  // Thu: one bad day per week
            { new DateTime(2026,  1, 27), (71,  +580, 4, 3) },  // Tue
            { new DateTime(2026,  1, 28), (76,  +920, 4, 3) },  // Wed: month ends on upswing

            // ── February 2026: pattern recognition ───────────────────────────
            { new DateTime(2026,  2,  3), (71,  +840, 4, 3) },  // Tue
            { new DateTime(2026,  2,  4), (64,  -540, 5, 2) },  // Wed: near-miss (unusual bad Wed)
            { new DateTime(2026,  2,  5), (69,  +680, 4, 3) },  // Thu: bounces back
            { new DateTime(2026,  2, 11), (74, +1020, 4, 3) },  // Wed: clear mid-week strength
            { new DateTime(2026,  2, 12), (68,  +460, 4, 3) },  // Thu
            { new DateTime(2026,  2, 13), (50,  -760, 6, 2) },  // Fri: Friday effect still showing
            // Feb 18 is turning-point showcase session
            { new DateTime(2026,  2, 19), (77, +1140, 4, 3) },  // Thu: post turning-point surge
            { new DateTime(2026,  2, 20), (55,  -380, 4, 2) },  // Fri: still can't hold Fridays

            // ── March 2026: breakthrough ──────────────────────────────────────
            { new DateTime(2026,  3,  3), (76, +1040, 4, 3) },  // Tue
            { new DateTime(2026,  3,  4), (82, +1580, 5, 4) },  // Wed: breakthrough day
            { new DateTime(2026,  3,  5), (78,  +920, 4, 3) },  // Thu: 3-day streak
            { new DateTime(2026,  3,  6), (62,  -320, 4, 2) },  // Fri: still a minor Friday stumble
            { new DateTime(2026,  3, 10), (74,  +840, 4, 3) },  // Tue
            { new DateTime(2026,  3, 11), (85, +1760, 5, 4) },  // Wed: best day yet
            { new DateTime(2026,  3, 12), (80,  +980, 4, 3) },  // Thu: back-to-back strong
            { new DateTime(2026,  3, 13), (68,  +340, 4, 3) },  // Fri: small win on a Friday!
            { new DateTime(2026,  3, 17), (79, +1120, 4, 3) },  // Tue
            { new DateTime(2026,  3, 18), (83, +1440, 5, 4) },  // Wed: another big day
            { new DateTime(2026,  3, 19), (75,  +680, 4, 3) },  // Thu
            { new DateTime(2026,  3, 20), (57,  -480, 5, 2) },  // Fri: one last bad Friday
            { new DateTime(2026,  3, 24), (80, +1020, 4, 3) },  // Tue
            { new DateTime(2026,  3, 25), (88, +2120, 5, 5) },  // Wed: BEST DAY of March
            { new DateTime(2026,  3, 26), (82,  +960, 4, 3) },  // Thu
            { new DateTime(2026,  3, 27), (70,  +420, 4, 3) },  // Fri: even Fridays getting better

            // ── April 2026: control ───────────────────────────────────────────
            { new DateTime(2026,  4,  1), (82, +1240, 4, 3) },  // Wed
            { new DateTime(2026,  4,  2), (79,  +880, 4, 3) },  // Thu
            // Apr 8 is great-day showcase session
            { new DateTime(2026,  4,  9), (83, +1640, 4, 4) },  // Thu: after the great Wed
            { new DateTime(2026,  4, 10), (72,  +460, 4, 3) },  // Fri: disciplined Friday
            { new DateTime(2026,  4, 13), (68,  -280, 4, 2) },  // Mon: small Monday stumble
            { new DateTime(2026,  4, 14), (85, +1380, 4, 4) },  // Tue: strong close
            { new DateTime(2026,  4, 15), (84, +1520, 4, 4) },  // Wed: perfect back-to-back
            { new DateTime(2026,  4, 16), (81, +1080, 4, 3) },  // Thu: solid follow-through
            { new DateTime(2026,  4, 17), (74,  +640, 4, 3) },  // Fri: Fridays now consistently green
            { new DateTime(2026,  4, 20), (66,  -180, 4, 2) },  // Mon: small dip, stopped early
            { new DateTime(2026,  4, 21), (83, +1360, 4, 3) },  // Tue: clean bounce
            { new DateTime(2026,  4, 22), (87, +1840, 5, 4) },  // Wed: best April day yet
            { new DateTime(2026,  4, 23), (82, +1020, 4, 3) },  // Thu: stays disciplined
            { new DateTime(2026,  4, 24), (77,  +740, 4, 3) },  // Fri: another green Friday
            { new DateTime(2026,  4, 28), (79,  +860, 4, 3) },  // Mon: steady start to new week
            { new DateTime(2026,  4, 29), (84, +1380, 4, 3) },  // Tue: strong continuation
            { new DateTime(2026,  4, 30), (80,  +840, 4, 3) },  // Wed: solid close to April

            // ── May 2026: sustained control ────────────────────────────────────────
            { new DateTime(2026,  5,  1), (76,  +560, 3, 2) },  // Fri: disciplined, quit early
            // May 4 (today) is the showcase session — generated by BuildTodaySummary()
        };

        // =====================================================================
        // Trading schedule
        // =====================================================================

        private static readonly DateTime[] TradingDays = BuildSchedule();

        private static DateTime[] BuildSchedule()
        {
            var days = new List<DateTime>();
            var holidays = new HashSet<DateTime>
            {
                new DateTime(2025, 12, 24),
                new DateTime(2025, 12, 25),
                new DateTime(2026,  1,  1),
                new DateTime(2026,  1, 19),
                new DateTime(2026,  2, 16),
                new DateTime(2026,  4,  3),
            };

            for (var d = new DateTime(2025, 12, 1); d <= new DateTime(2026, 5, 4); d = d.AddDays(1))
            {
                if (d.DayOfWeek == DayOfWeek.Saturday ||
                    d.DayOfWeek == DayOfWeek.Sunday   ||
                    holidays.Contains(d.Date))
                    continue;
                days.Add(d.Date);
            }
            return days.ToArray();
        }

        // =====================================================================
        // Public entry point
        // =====================================================================

        public static string Seed(Action<string> log = null)
        {
            try
            {
                var rng = new Random(42);

                // Load existing data — real trading sessions recorded by the user must
                // never be erased by the demo seeder.  We only INSERT for dates that
                // do not already have an entry.
                var store         = SessionHistoryStore.LoadFromFile(log);
                var existingDates = new System.Collections.Generic.HashSet<DateTime>();
                foreach (var s in store.Sessions) existingDates.Add(s.Date.Date);

                int seeded = 0;
                foreach (var date in TradingDays)
                {
                    if (existingDates.Contains(date.Date)) continue; // preserve real data

                    var prof = GetProfile(date.Month, date.Year);
                    if (prof == null) continue;

                    SessionHistoryEntry entry;
                    if      (date == new DateTime(2026,  4,  8)) entry = GreatDaySummary();
                    else if (date == new DateTime(2025, 12,  9)) entry = CrashDaySummary();
                    else if (date == new DateTime(2026,  2, 18)) entry = TurningPointSummary();
                    else if (date == new DateTime(2026,  5,  4)) entry = TodaySummary();
                    else if (Anchors.TryGetValue(date, out var a))
                        entry = GenerateFromAnchor(date, a.comp, a.pnl, a.total, a.wins, prof.Value, rng);
                    else
                        entry = GenerateEntry(date, prof.Value, rng);

                    store.Sessions.Add(entry);
                    seeded++;
                }

                store.Sessions.Sort((a, b) => a.Date.CompareTo(b.Date));
                store.SaveToFile(log);
                SeedDetailFiles(log);

                int real = existingDates.Count;
                return $"Done — added {seeded} demo sessions ({real} existing session(s) preserved).  4 detail files written.";
            }
            catch (Exception ex)
            {
                string msg = $"[DemoDataSeeder] Seed failed: {ex.Message}";
                log?.Invoke(msg);
                return msg;
            }
        }

        // =====================================================================
        // Entry generation
        // =====================================================================

        private static MonthProfile? GetProfile(int month, int year)
        {
            foreach (var p in Profiles)
                if (p.Month == month && p.Year == year) return p;
            return null;
        }

        private static SessionHistoryEntry GenerateFromAnchor(
            DateTime date, int composure, double pnl,
            int total, int wins, MonthProfile prof, Random rng)
        {
            wins = Clamp(wins, 0, total);
            return BuildEntry(date, composure, pnl, total, wins, prof, rng);
        }

        private static SessionHistoryEntry GenerateEntry(
            DateTime date, MonthProfile prof, Random rng)
        {
            int dow = (int)date.DayOfWeek;

            int composure = Clamp(
                prof.BaseComposure
                + ComposureDow[dow]
                + rng.Next(-prof.ComposureSpread / 2, prof.ComposureSpread / 2 + 1),
                20, 99);

            // P&L drawn from profile distribution — composure adds a soft nudge only.
            // Correlation is present but imperfect so even bad months have green days.
            double rawPnl = prof.BaseAvgPnl
                          + PnlDow[dow]
                          + (rng.NextDouble() * 2 - 1) * prof.PnlSpread;

            double composureNudge = (composure - 62.0) * prof.PnlSpread * 0.012;
            double pnl = rawPnl + composureNudge;

            // Tilt amplifier: very low composure risks a runaway loss (~55% of the time)
            if (composure < 48 && rng.NextDouble() > 0.45)
                pnl -= rng.NextDouble() * prof.PnlSpread * 0.7;

            double winRate = Clamp01(prof.BaseWinRate + (rng.NextDouble() - 0.5) * prof.WinRateSpread);
            int    total   = rng.Next(3, 10);
            int    wins    = Clamp((int)Math.Round(total * winRate), 0, total);

            return BuildEntry(date, composure, pnl, total, wins, prof, rng);
        }

        private static SessionHistoryEntry BuildEntry(
            DateTime date, int composure, double pnl,
            int total, int wins, MonthProfile prof, Random rng)
        {
            double startPsi = Clamp(composure * 0.93 + rng.NextDouble() * 7, 35, 99);
            double finalPsi = Clamp(composure + (rng.NextDouble() * 6 - 3),  28, 99);
            double minPsi   = Clamp(finalPsi - rng.NextDouble() * 22 - 1,    22, finalPsi);
            double avgPsi   = Clamp((startPsi + finalPsi + minPsi) / 3 + rng.NextDouble() * 4 - 2, 22, 99);

            int    dur      = rng.Next(95, 242);

            double stableFrac = composure / 100.0;
            double stableMin  = dur * stableFrac;
            double cautionMin = dur * (1 - stableFrac) * 0.55;
            double critMin    = dur * (1 - stableFrac) * 0.45;

            int alerts = composure < 48 ? rng.Next(2, 6) :
                         composure < 68 ? rng.Next(0, 2) : 0;
            int naked  = composure < 44 ? rng.Next(1, 4) : 0;

            bool isCrash = composure < 52;
            bool isGood  = composure >= 74;

            double d1 = isCrash ? prof.D1Bias + rng.NextDouble() * 0.20
                      : isGood  ? rng.NextDouble() * 0.14
                                : prof.D1Bias * 0.36 + rng.NextDouble() * 0.18;

            double d2 = isCrash ? 0.44 + rng.NextDouble() * 0.26
                      : isGood  ? rng.NextDouble() * 0.11
                                : 0.18 + rng.NextDouble() * 0.14;

            double d3 = rng.NextDouble() * (isCrash ? 0.26 : 0.12);
            double d4 = rng.NextDouble() * (isCrash ? 0.30 : 0.14);

            double d5 = isCrash ? 0.34 + rng.NextDouble() * 0.22
                                : rng.NextDouble() * 0.20;

            double d6 = isCrash ? rng.NextDouble() * 0.30 : rng.NextDouble() * 0.10;

            double d7 = isCrash ? prof.D7Bias + rng.NextDouble() * 0.16
                      : isGood  ? rng.NextDouble() * 0.14
                                : prof.D7Bias * 0.48 + rng.NextDouble() * 0.14;

            return new SessionHistoryEntry
            {
                Date                    = date.Date,
                StartPsi                = R1(startPsi),
                MinPsi                  = R1(minPsi),
                FinalPsi                = R1(finalPsi),
                AvgPsi                  = R1(avgPsi),
                TotalTrades             = total,
                WinTrades               = wins,
                TotalPnl                = Math.Round(pnl, 2),
                DurationMinutes         = dur,
                TimeInStableMin         = R1(stableMin),
                TimeInCautionMin        = R1(cautionMin),
                TimeInCriticalMin       = R1(critMin),
                AlertsFired             = alerts,
                NakedPositionDetections = naked,
                ComposurePct            = composure,
                D1 = R3(d1), D2 = R3(d2), D3 = R3(d3),
                D4 = R3(d4), D5 = R3(d5), D6 = R3(d6), D7 = R3(d7),
            };
        }

        // =====================================================================
        // Showcase session summaries (match the hand-crafted detail files)
        // =====================================================================

        private static SessionHistoryEntry GreatDaySummary() => new SessionHistoryEntry
        {
            Date = new DateTime(2026, 4, 8), StartPsi = 95.4, MinPsi = 91.8,
            FinalPsi = 97.2, AvgPsi = 94.8, TotalTrades = 4, WinTrades = 3,
            TotalPnl = 1850.00, DurationMinutes = 195,
            TimeInStableMin = 190, TimeInCautionMin = 5, TimeInCriticalMin = 0,
            AlertsFired = 0, NakedPositionDetections = 0, ComposurePct = 94,
            D1=0.048, D2=0.032, D3=0.000, D4=0.040, D5=0.042, D6=0.000, D7=0.050,
        };

        private static SessionHistoryEntry CrashDaySummary() => new SessionHistoryEntry
        {
            Date = new DateTime(2025, 12, 9), StartPsi = 88.2, MinPsi = 36.4,
            FinalPsi = 39.8, AvgPsi = 57.4, TotalTrades = 8, WinTrades = 2,
            TotalPnl = -3200.00, DurationMinutes = 295,
            TimeInStableMin = 35, TimeInCautionMin = 78, TimeInCriticalMin = 182,
            AlertsFired = 4, NakedPositionDetections = 3, ComposurePct = 34,
            D1=0.842, D2=0.562, D3=0.118, D4=0.322, D5=0.492, D6=0.254, D7=0.704,
        };

        private static SessionHistoryEntry TurningPointSummary() => new SessionHistoryEntry
        {
            Date = new DateTime(2026, 2, 18), StartPsi = 83.4, MinPsi = 63.8,
            FinalPsi = 79.2, AvgPsi = 76.4, TotalTrades = 5, WinTrades = 3,
            TotalPnl = 1250.00, DurationMinutes = 210,
            TimeInStableMin = 148, TimeInCautionMin = 55, TimeInCriticalMin = 0,
            AlertsFired = 1, NakedPositionDetections = 0, ComposurePct = 72,
            D1=0.174, D2=0.182, D3=0.036, D4=0.110, D5=0.158, D6=0.054, D7=0.136,
        };

        // ── Today's session (May 4, 2026 – Monday) ───────────────────────────
        // Story: solid Monday morning. Brief dip on trade 2 (respected the stop),
        //        recovered composure and closed the day green.
        private static SessionHistoryEntry TodaySummary() => new SessionHistoryEntry
        {
            Date = new DateTime(2026, 5, 4), StartPsi = 87.2, MinPsi = 76.4,
            FinalPsi = 84.6, AvgPsi = 82.8, TotalTrades = 3, WinTrades = 2,
            TotalPnl = 1250.00, DurationMinutes = 155,
            TimeInStableMin = 128, TimeInCautionMin = 27, TimeInCriticalMin = 0,
            AlertsFired = 0, NakedPositionDetections = 0, ComposurePct = 83,
            D1=0.058, D2=0.044, D3=0.000, D4=0.036, D5=0.048, D6=0.000, D7=0.042,
        };

        // =====================================================================
        // SessionDetail files — 3 showcase sessions (full PSI timeline + fills)
        // =====================================================================

        private static void SeedDetailFiles(Action<string> log)
        {
            string sessionsDir = Path.Combine(SessionHistoryStore.DataDir, "sessions");
            try { Directory.CreateDirectory(sessionsDir); } catch { }

            SaveDetail(new DateTime(2026,  4,  8), BuildGreatDayDetail(),     sessionsDir, log);
            SaveDetail(new DateTime(2025, 12,  9), BuildCrashDayDetail(),     sessionsDir, log);
            SaveDetail(new DateTime(2026,  2, 18), BuildTurningPointDetail(), sessionsDir, log);
            SaveDetail(new DateTime(2026,  5,  4), BuildTodayDetail(),        sessionsDir, log);
        }

        private static void SaveDetail(
            DateTime date, SessionDetail detail, string dir, Action<string> log)
        {
            try
            {
                string path     = Path.Combine(dir, date.ToString("yyyy-MM-dd") + ".xml");
                string tempPath = path + ".tmp";
                var xs = new XmlSerializer(typeof(SessionDetail));
                using (var fs = new FileStream(tempPath, FileMode.Create,
                                               FileAccess.Write, FileShare.None))
                    xs.Serialize(fs, detail);
                if (File.Exists(path)) File.Delete(path);
                File.Move(tempPath, path);
            }
            catch (Exception ex)
            {
                log?.Invoke($"[DemoDataSeeder] Detail save failed ({date:yyyy-MM-dd}): {ex.Message}");
            }
        }

        // ── Showcase 1: Perfect execution day (Apr 8, 2026 – Wednesday) ──────
        private static SessionDetail BuildGreatDayDetail()
        {
            var d = new SessionDetail
            {
                PrevFinalPsi = 94.8, PrevAlerts = 0,
                PeakDebtD2 = 0.03, PeakDebtD3 = 0.01, PeakDebtD5 = 0.05, PeakDebtD6 = 0.00,
            };

            var open  = new DateTime(2026, 4, 8, 9, 30, 0);
            var close = new DateTime(2026, 4, 8, 13, 0, 0);
            var rng   = new Random(101);

            double psi = 95.0;
            for (var t = open; t <= close; t = t.AddMinutes(2))
            {
                psi = Clamp(psi + (rng.NextDouble() * 1.6 - 0.7), 89, 99);
                d.PsiHistory.Add(new SdPsiPoint { Ticks = t.Ticks, V = (float)R1(psi) });
            }

            // 4 trades: W +$625, W +$500, L -$250 (respected stop), W +$975
            d.Fills.Add(Fill(open.AddMinutes( 18), true, true,   +625.00f,  820, 96.2f, 0.04f,0.03f,0.00f,0.04f,0.04f,0.00f,0.05f));
            d.Fills.Add(Fill(open.AddMinutes( 52), true, true,   +500.00f, 1240, 94.8f, 0.05f,0.04f,0.00f,0.04f,0.06f,0.00f,0.07f));
            d.Fills.Add(Fill(open.AddMinutes( 95), true, false,  -250.00f,  460, 93.5f, 0.07f,0.04f,0.00f,0.05f,0.04f,0.00f,0.04f));
            d.Fills.Add(Fill(open.AddMinutes(148), true, true,   +975.00f, 1820, 96.4f, 0.03f,0.02f,0.00f,0.03f,0.03f,0.00f,0.04f));
            return d;
        }

        // ── Showcase 2: Revenge-trading crash day (Dec 9, 2025 – Tuesday) ────
        private static SessionDetail BuildCrashDayDetail()
        {
            var d = new SessionDetail
            {
                PrevFinalPsi = 82.4, PrevAlerts = 1,
                PeakDebtD2 = 0.68, PeakDebtD3 = 0.20, PeakDebtD5 = 0.60, PeakDebtD6 = 0.30,
            };

            var open  = new DateTime(2025, 12, 9, 9, 30, 0);
            var close = new DateTime(2025, 12, 9, 14, 25, 0);
            var rng   = new Random(202);

            double psi = 88.0;
            for (var t = open; t < open.AddMinutes(35); t = t.AddMinutes(2))
            {
                psi = Clamp(psi + (rng.NextDouble() * 1.0 - 0.5), 83, 92);
                d.PsiHistory.Add(new SdPsiPoint { Ticks = t.Ticks, V = (float)R1(psi) });
            }
            psi = 73.0;
            for (var t = open.AddMinutes(35); t < open.AddMinutes(80); t = t.AddMinutes(2))
            {
                psi = Clamp(psi - rng.NextDouble() * 1.4, 62, 77);
                d.PsiHistory.Add(new SdPsiPoint { Ticks = t.Ticks, V = (float)R1(psi) });
            }
            psi = 59.0;
            for (var t = open.AddMinutes(80); t < open.AddMinutes(195); t = t.AddMinutes(2))
            {
                psi = Clamp(psi - rng.NextDouble() * 1.8 + 0.2, 34, 63);
                d.PsiHistory.Add(new SdPsiPoint { Ticks = t.Ticks, V = (float)R1(psi) });
            }
            psi = 39.0;
            for (var t = open.AddMinutes(195); t <= close; t = t.AddMinutes(2))
            {
                psi = Clamp(psi + rng.NextDouble() * 0.7 - 0.1, 36, 48);
                d.PsiHistory.Add(new SdPsiPoint { Ticks = t.Ticks, V = (float)R1(psi) });
            }

            d.Fills.Add(Fill(open.AddMinutes( 20), true, true,   +375.00f,  760, 87.2f, 0.08f,0.10f,0.04f,0.07f,0.09f,0.04f,0.10f));
            d.Fills.Add(Fill(open.AddMinutes( 46), true, false,  -750.00f,  920, 73.6f, 0.52f,0.55f,0.10f,0.18f,0.42f,0.16f,0.40f));
            d.Fills.Add(Fill(open.AddMinutes( 62), true, false,  -625.00f,  420, 67.4f, 0.84f,0.62f,0.08f,0.26f,0.50f,0.24f,0.68f));
            d.Fills.Add(Fill(open.AddMinutes( 79), true, false,  -500.00f,  340, 60.2f, 0.92f,0.48f,0.10f,0.34f,0.38f,0.28f,0.76f));
            d.Fills.Add(Fill(open.AddMinutes( 98), true, false, -1125.00f,  580, 50.8f, 0.90f,0.58f,0.16f,0.40f,0.56f,0.30f,0.72f));
            d.Fills.Add(Fill(open.AddMinutes(128), true, true,   +250.00f, 1200, 46.4f, 0.42f,0.36f,0.08f,0.20f,0.32f,0.16f,0.38f));
            d.Fills.Add(Fill(open.AddMinutes(157), true, false,  -500.00f,  440, 41.8f, 0.74f,0.46f,0.10f,0.28f,0.44f,0.20f,0.64f));
            d.Fills.Add(Fill(open.AddMinutes(188), true, false,  -325.00f,  620, 39.6f, 0.70f,0.52f,0.12f,0.24f,0.50f,0.22f,0.58f));
            return d;
        }

        // ── Showcase 3: Turning-point day (Feb 18, 2026 – Wednesday) ─────────
        private static SessionDetail BuildTurningPointDetail()
        {
            var d = new SessionDetail
            {
                PrevFinalPsi = 71.8, PrevAlerts = 1,
                PeakDebtD2 = 0.26, PeakDebtD3 = 0.07, PeakDebtD5 = 0.30, PeakDebtD6 = 0.11,
            };

            var open  = new DateTime(2026, 2, 18, 9, 30, 0);
            var close = new DateTime(2026, 2, 18, 13, 0, 0);
            var rng   = new Random(303);

            double psi = 83.0;
            for (var t = open; t < open.AddMinutes(50); t = t.AddMinutes(2))
            {
                psi = Clamp(psi + (rng.NextDouble() * 1.2 - 0.4), 78, 88);
                d.PsiHistory.Add(new SdPsiPoint { Ticks = t.Ticks, V = (float)R1(psi) });
            }
            psi = 70.0;
            for (var t = open.AddMinutes(50); t < open.AddMinutes(95); t = t.AddMinutes(2))
            {
                psi = Clamp(psi + (rng.NextDouble() * 1.0 - 0.3), 62, 75);
                d.PsiHistory.Add(new SdPsiPoint { Ticks = t.Ticks, V = (float)R1(psi) });
            }
            psi = 74.0;
            for (var t = open.AddMinutes(95); t < open.AddMinutes(155); t = t.AddMinutes(2))
            {
                psi = Clamp(psi + rng.NextDouble() * 1.1 - 0.1, 70, 83);
                d.PsiHistory.Add(new SdPsiPoint { Ticks = t.Ticks, V = (float)R1(psi) });
            }
            psi = 78.0;
            for (var t = open.AddMinutes(155); t <= close; t = t.AddMinutes(2))
            {
                psi = Clamp(psi + (rng.NextDouble() * 1.0 - 0.2), 74, 83);
                d.PsiHistory.Add(new SdPsiPoint { Ticks = t.Ticks, V = (float)R1(psi) });
            }

            d.Fills.Add(Fill(open.AddMinutes( 18), true, true,  +500.00f, 1080, 84.2f, 0.11f,0.14f,0.04f,0.09f,0.11f,0.05f,0.13f));
            d.Fills.Add(Fill(open.AddMinutes( 45), true, true,  +375.00f,  860, 82.8f, 0.09f,0.11f,0.03f,0.07f,0.13f,0.04f,0.11f));
            d.Fills.Add(Fill(open.AddMinutes( 68), true, false, -625.00f,  540, 70.4f, 0.36f,0.30f,0.07f,0.17f,0.26f,0.10f,0.23f));
            d.Fills.Add(Fill(open.AddMinutes(115), true, true,  +625.00f, 1440, 76.2f, 0.12f,0.14f,0.04f,0.10f,0.16f,0.06f,0.11f));
            d.Fills.Add(Fill(open.AddMinutes(162), true, true,  +375.00f, 1680, 79.1f, 0.07f,0.09f,0.02f,0.07f,0.09f,0.03f,0.07f));
            return d;
        }

        // ── Showcase 4: Today's session (May 4, 2026 – Monday) ───────────────
        // Solid Monday morning. Brief stumble on trade 2 (stop respected),
        // composure held, closed green with disciplined execution.
        private static SessionDetail BuildTodayDetail()
        {
            var d = new SessionDetail
            {
                PrevFinalPsi = 83.8, PrevAlerts = 0,
                PeakDebtD2 = 0.05, PeakDebtD3 = 0.00, PeakDebtD5 = 0.06, PeakDebtD6 = 0.00,
            };

            var open  = new DateTime(2026, 5, 4, 9, 30, 0);
            var close = new DateTime(2026, 5, 4, 12, 5, 0);
            var rng   = new Random(404);

            // Phase 1: strong start (0–45 min)
            double psi = 87.0;
            for (var t = open; t < open.AddMinutes(45); t = t.AddMinutes(2))
            {
                psi = Clamp(psi + (rng.NextDouble() * 1.2 - 0.4), 84, 91);
                d.PsiHistory.Add(new SdPsiPoint { Ticks = t.Ticks, V = (float)R1(psi) });
            }
            // Phase 2: dip after loss on trade 2 (45–85 min)
            psi = 80.0;
            for (var t = open.AddMinutes(45); t < open.AddMinutes(85); t = t.AddMinutes(2))
            {
                psi = Clamp(psi + (rng.NextDouble() * 0.9 - 0.2), 76, 83);
                d.PsiHistory.Add(new SdPsiPoint { Ticks = t.Ticks, V = (float)R1(psi) });
            }
            // Phase 3: recovery — composure restored (85–155 min)
            psi = 82.0;
            for (var t = open.AddMinutes(85); t <= close; t = t.AddMinutes(2))
            {
                psi = Clamp(psi + (rng.NextDouble() * 1.0 - 0.2), 80, 87);
                d.PsiHistory.Add(new SdPsiPoint { Ticks = t.Ticks, V = (float)R1(psi) });
            }

            // Trade 1: W +$625 (quick scalp, 18 min hold, PSI 88)
            d.Fills.Add(Fill(open.AddMinutes( 18), true, true,   +625.00f,  1080, 88.2f, 0.05f,0.04f,0.00f,0.04f,0.04f,0.00f,0.04f));
            // Trade 2: L -$250 (respected stop, 38 min hold, PSI 80)
            d.Fills.Add(Fill(open.AddMinutes( 62), true, false,  -250.00f,  2280, 79.6f, 0.09f,0.06f,0.00f,0.05f,0.07f,0.00f,0.05f));
            // Trade 3: W +$875 (trend trade, 58 min hold, PSI 84)
            d.Fills.Add(Fill(open.AddMinutes(123), true, true,   +875.00f,  3480, 84.4f, 0.04f,0.03f,0.00f,0.03f,0.05f,0.00f,0.04f));
            return d;
        }

        // =====================================================================
        // Helpers
        // =====================================================================

        private static SdFill Fill(
            DateTime time, bool closing, bool win, float pnl, float holdSec,
            float psi, float d1, float d2, float d3, float d4, float d5, float d6, float d7)
            => new SdFill
            {
                Ticks = time.Ticks, IsClosing = closing, IsWin = win,
                Pnl = pnl, HoldSeconds = holdSec, Psi = psi,
                D1 = d1, D2 = d2, D3 = d3, D4 = d4, D5 = d5, D6 = d6, D7 = d7,
            };

        private static int    Clamp(int    v, int    lo, int    hi) => v < lo ? lo : v > hi ? hi : v;
        private static double Clamp(double v, double lo, double hi) => v < lo ? lo : v > hi ? hi : v;
        private static double Clamp01(double v) => v < 0 ? 0 : v > 1 ? 1 : v;
        private static double R1(double v) => Math.Round(v, 1);
        private static double R3(double v) => Math.Round(v, 3);
    }
}
