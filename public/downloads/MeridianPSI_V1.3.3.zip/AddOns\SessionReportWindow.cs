// SessionReportWindow.cs
//
// End-of-session (or on-demand) summary report window.
// Apple-style dark theme, consistent with ProfileSettingsWindow.
// Sections: Overview, PSI Timeline, Time in State, Signal Breakdown,
//           Trade Stats, vs Yesterday.
//
// The window is read-only; it never writes to the SessionData it receives.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal sealed class SessionReportWindow : Window
    {
        // ── Data ──────────────────────────────────────────────────────────────
        private readonly SessionData _data;

        // ── Apple-style palette (matches ProfileSettingsWindow) ───────────────
        private static readonly Brush FgPrimary   = new SolidColorBrush(Color.FromRgb(245, 245, 247));
        private static readonly Brush FgSecondary = new SolidColorBrush(Color.FromRgb(174, 174, 178));
        private static readonly Brush FgHint      = new SolidColorBrush(Color.FromRgb(99,  99,  102));
        private static readonly Brush FgAccent    = new SolidColorBrush(Color.FromRgb(10,  132, 255));
        private static readonly Brush BgWindow    = new SolidColorBrush(Color.FromRgb(28,  28,  30));
        private static readonly Brush BgCard      = new SolidColorBrush(Color.FromRgb(38,  38,  40));
        private static readonly Brush BgHeader    = new SolidColorBrush(Color.FromRgb(44,  44,  46));
        private static readonly Color ColStable      = Color.FromRgb( 48, 209,  88);
        private static readonly Color ColYellowGreen = Color.FromRgb(163, 213,  72);
        private static readonly Color ColCaution     = Color.FromRgb(255, 214,   0);
        private static readonly Color ColCritical    = Color.FromRgb(255,  69,  58);

        private static Color CompColor(int pct) =>
            pct >= 85 ? ColStable :
            pct >= 70 ? ColYellowGreen :
            pct >= 50 ? ColCaution : ColCritical;

        private static readonly string[] DimLabels =
            { "Revenge entry", "Stop manipulation", "Size spike",
              "Hold Bias", "Position overstay", "Rule violations", "Overtrading pace" };

        // Human-readable tooltips for each D-score dimension.
        // Shown on hover over D1–D6 labels everywhere in the report.
        private static readonly string[] DimTooltips =
        {
            "D1 · Revenge Entry\n" +
            "Re-entered a position too quickly after a loss, or with a significantly larger size.\n" +
            "Classic emotional trading pattern — chasing a loss instead of waiting for the next clean setup.",

            "D2 · Stop Manipulation\n" +
            "Moved your stop-loss in the losing direction mid-trade, widening your risk exposure.\n" +
            "Also fires when a position is held with NO stop-loss order present (ATM removed).",

            "D3 · Size Spike\n" +
            "Position size significantly exceeded your own historical normal — a statistical outlier.\n" +
            "Consistent sizing is a core discipline marker; outliers often signal emotional conviction.",

            "D4 · Hold Bias\n" +
            "Held losing positions significantly longer than winning ones — the classic 'cut winners, ride losers' pattern.\n" +
            "Fires when your avg loss hold time far exceeds your avg win hold time this session.",

            "D5 · Position Overstay\n" +
            "An open losing position held beyond your personal 90th-percentile hold time.\n" +
            "Timer-based: fires every 30 s when an underwater position lingers past your historical norm.",

            "D6 · Rule Violations\n" +
            "Broke one or more of your declared trading rules:\n" +
            "  • Traded outside your declared session window\n" +
            "  • Stop-loss wider than your declared maximum\n" +
            "  • Position size larger than 1.5 × your declared maximum",

            "D7 · Overtrading Pace\n" +
            "Your entry pace accelerated significantly above your own session rhythm.\n" +
            "Fires when the gap between recent entries is much shorter than your session average,\n" +
            "OR when your session average pace far exceeds your declared LambdaVelocity baseline.\n" +
            "Activates regardless of win/loss outcome — a fast pace often precedes discipline failures.",
        };

        // ── Canvas ref (drawn after layout) ──────────────────────────────────
        private Canvas   _timelineCanvas;
        private Polyline _timelineLine;

        public SessionReportWindow(SessionData data)
        {
            _data = data ?? throw new ArgumentNullException("data");

            WindowStyle        = WindowStyle.None;
            AllowsTransparency = true;
            Background         = Brushes.Transparent;
            ResizeMode         = ResizeMode.CanResizeWithGrip;
            ShowInTaskbar      = true;
            Title              = "PSI Session Report";
            Width              = 480;
            Height             = 640;
            MinWidth           = 380;
            MinHeight          = 480;

            // Centre on screen
            Left = (SystemParameters.WorkArea.Width  - Width)  / 2;
            Top  = (SystemParameters.WorkArea.Height - Height) / 2;

            // ── Outer card with rounded corners ────────────────────────────────
            var card = new Border
            {
                CornerRadius    = new CornerRadius(14),
                Background      = BgWindow,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(44) });  // header
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // scroll

            // ── Header bar ───────────────────────────────────────────────────
            var hdr = new Border { Background = BgHeader };
            var hdrGrid = new Grid();
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // share
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // close

            var titleBlock = new TextBlock
            {
                Text              = $"SESSION REPORT  ·  {data.Date:MMMM d, yyyy}",
                FontSize          = 12,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(16, 0, 0, 0),
            };

            var shareBtn = MakeIconBtn("⎘", "Copy session summary (Discord / X)");
            shareBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                CopySummaryToClipboard(shareBtn);
            };

            var clsBtn = MakeIconBtn("✕", "Close");
            clsBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; Close(); };

            Grid.SetColumn(titleBlock, 0); hdrGrid.Children.Add(titleBlock);
            Grid.SetColumn(shareBtn,   1); hdrGrid.Children.Add(shareBtn);
            Grid.SetColumn(clsBtn,     2); hdrGrid.Children.Add(clsBtn);
            hdr.Child = hdrGrid;

            hdrGrid.MouseLeftButtonDown += (_, e) =>
            {
                if (!e.Handled && e.ButtonState == MouseButtonState.Pressed) DragMove();
            };

            Grid.SetRow(hdr, 0); root.Children.Add(hdr);

            // ── Scrollable content ───────────────────────────────────────────
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Background                    = Brushes.Transparent,
            };

            var content = new StackPanel
            {
                Margin      = new Thickness(16, 12, 16, 20),
                Orientation = Orientation.Vertical,
            };

            // ── Section: OVERVIEW ────────────────────────────────────────────
            content.Children.Add(SectionHeader("OVERVIEW"));
            content.Children.Add(BuildOverviewRow());
            content.Children.Add(Spacer(12));

            // ── Section: TRADES ──────────────────────────────────────────────
            content.Children.Add(SectionHeader("TRADES"));
            content.Children.Add(BuildTradesCard());
            content.Children.Add(Spacer(12));

            // ── Section: BEHAVIORAL QUALITY ──────────────────────────────────
            // Always rendered so new users discover the feature immediately.
            content.Children.Add(SectionHeader("COMPOSURE"));
            content.Children.Add(BuildBehavioralQualityCard());
            content.Children.Add(Spacer(12));

            // ── Section: SIGNAL BREAKDOWN ────────────────────────────────────
            content.Children.Add(SectionHeader("SIGNAL BREAKDOWN  (D1 – D7)"));
            content.Children.Add(BuildDimBreakdownCard());
            content.Children.Add(Spacer(12));

            // ── Section: PSI TIMELINE ────────────────────────────────────────
            content.Children.Add(SectionHeader("PSI TIMELINE  (this session)"));
            content.Children.Add(BuildTimelineCard());
            content.Children.Add(Spacer(12));

            // ── Section: TILT CASCADE ─────────────────────────────────────────
            // Always rendered so new users discover the feature immediately.
            content.Children.Add(SectionHeader("TILT CASCADE  (session fill log)"));
            content.Children.Add(BuildTiltCascadeCard());
            content.Children.Add(Spacer(12));

            // ── Section: RISK DISCIPLINE ─────────────────────────────────────
            content.Children.Add(SectionHeader("RISK DISCIPLINE"));
            content.Children.Add(BuildRiskDisciplineCard());
            content.Children.Add(Spacer(12));

            // ── Section: vs YESTERDAY ────────────────────────────────────────
            if (_data.PrevFinalPsi > 0)
            {
                content.Children.Add(SectionHeader("vs PREVIOUS SESSION"));
                content.Children.Add(BuildComparisonCard());
                content.Children.Add(Spacer(12));
            }

            scroll.Content = content;
            Grid.SetRow(scroll, 1); root.Children.Add(scroll);

            card.Child = root;
            Content    = card;

            // Draw the PSI timeline after the window is laid out
            Loaded += (_, __) => DrawTimeline();
        }

        // =====================================================================
        // Section builders
        // =====================================================================

        private UIElement BuildOverviewRow()
        {
            // 4 stat boxes: Start PSI | Min PSI | Final PSI | Alerts
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(8) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(8) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(8) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var startColor  = PsiColorBrush(_data.StartPsi);
            var minColor    = PsiColorBrush(_data.MinPsi);
            var finalColor  = PsiColorBrush(_data.FinalPsi);
            var alertColor  = _data.AlertsFired > 0
                ? new SolidColorBrush(ColCritical)
                : new SolidColorBrush(ColStable);

            var nakedColor = _data.NakedPositionDetections > 0
                ? new SolidColorBrush(ColCritical)
                : new SolidColorBrush(ColStable);

            // Approximate naked exposure: detections × 30 s poll interval
            string nakedStr = _data.NakedPositionDetections == 0
                ? "0"
                : $"{_data.NakedPositionDetections}×";

            var boxes = new[]
            {
                StatBox("START",    $"{(int)_data.StartPsi}",       startColor),
                StatBox("LOWEST",   $"{(int)_data.MinPsi}",         minColor),
                StatBox("FINAL",    $"{(int)_data.FinalPsi}",       finalColor),
                StatBox("PSI ALERTS", $"{_data.AlertsFired}",         alertColor),
            };

            int col = 0;
            foreach (var box in boxes)
            {
                Grid.SetColumn(box, col);
                g.Children.Add(box);
                col += 2;
            }
            return g;
        }

        private UIElement BuildTimelineCard()
        {
            var card = Card();
            var inner = (StackPanel)((Border)card).Child;

            // Canvas for the chart — sized via SizeChanged
            _timelineCanvas = new Canvas
            {
                Height          = 100,
                ClipToBounds    = true,
                Background      = new SolidColorBrush(Color.FromRgb(28, 28, 30)),
            };

            // Zone bands (drawn relative to canvas height = 100)
            // y = (1 - psi/100) * h  →  PSI 88 ≈ top 12 %, PSI 55 ≈ top 45 %
            // Stable   (PSI ≥ 88):  top 12 %
            // Caution  (PSI 55–87): next 33 %
            // Critical (PSI  < 55): bottom 55 %
            var critBand  = ZoneBand(ColCritical, 40, 55); // placeholder heights
            var cautBand  = ZoneBand(ColCaution,  40, 33);
            var stablBand = ZoneBand(ColStable,   40, 12);

            _timelineCanvas.Children.Add(critBand);
            _timelineCanvas.Children.Add(cautBand);
            _timelineCanvas.Children.Add(stablBand);

            _timelineLine = new Polyline
            {
                Stroke          = new SolidColorBrush(Color.FromRgb(245, 245, 247)),
                StrokeThickness = 1.5,
                StrokeLineJoin  = PenLineJoin.Round,
            };
            _timelineCanvas.Children.Add(_timelineLine);

            _timelineCanvas.SizeChanged += (_, e) => PositionBands(e.NewSize, critBand, cautBand, stablBand);

            // X-axis: time labels (first and last)
            var xRow = new Grid();
            xRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            xRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var startLabel = SmallText("— earliest fill", TextAlignment.Left);
            var endLabel   = SmallText("latest fill —", TextAlignment.Right);
            Grid.SetColumn(startLabel, 0); xRow.Children.Add(startLabel);
            Grid.SetColumn(endLabel,   1); xRow.Children.Add(endLabel);

            inner.Children.Add(_timelineCanvas);
            inner.Children.Add(Spacer(4));
            inner.Children.Add(xRow);
            return card;
        }

        private UIElement BuildTimeInStateCard()
        {
            var card  = Card();
            var inner = (StackPanel)((Border)card).Child;

            double totalMinutes = _data.PsiHistory.Count < 2
                ? 1.0
                : (_data.PsiHistory[_data.PsiHistory.Count - 1].Time
                   - _data.PsiHistory[0].Time).TotalMinutes;
            if (totalMinutes <= 0) totalMinutes = 1;

            double cautMin  = _data.TimeInCaution.TotalMinutes;
            double critMin  = _data.TimeInCritical.TotalMinutes;
            double stabMin  = Math.Max(0, totalMinutes - cautMin - critMin);

            inner.Children.Add(StateBarRow("STABLE",   stabMin, totalMinutes, ColStable));
            inner.Children.Add(Spacer(6));
            inner.Children.Add(StateBarRow("CAUTION",  cautMin, totalMinutes, ColCaution));
            inner.Children.Add(Spacer(6));
            inner.Children.Add(StateBarRow("CRITICAL", critMin, totalMinutes, ColCritical));
            return card;
        }

        private UIElement BuildDimBreakdownCard()
        {
            var card  = Card();
            var inner = (StackPanel)((Border)card).Child;

            double total = _data.DimCumScore.Sum();
            if (total <= 0)
            {
                inner.Children.Add(new TextBlock
                {
                    Text       = "No signal data recorded yet for this session.",
                    Foreground = FgHint,
                    FontSize   = 11,
                    FontFamily = new FontFamily("Segoe UI"),
                    Margin     = new Thickness(0, 4, 0, 4),
                });
                return card;
            }

            // Sort by contribution descending for readability
            var ranked = _data.DimCumScore
                .Select((v, i) => new { Index = i, Value = v })
                .OrderByDescending(x => x.Value)
                .ToArray();

            bool first = true;
            foreach (var item in ranked)
            {
                if (!first) inner.Children.Add(Spacer(6));
                first = false;

                double pct = total > 0 ? item.Value / total : 0;
                inner.Children.Add(DimBarRow(
                    DimLabels[item.Index], pct, DimTooltips[item.Index]));
            }
            return card;
        }

        private UIElement BuildTradesCard()
        {
            var card  = Card();
            var inner = (StackPanel)((Border)card).Child;

            int   loss    = _data.TotalTrades - _data.WinTrades;
            double winPct  = _data.TotalTrades > 0
                ? 100.0 * _data.WinTrades / _data.TotalTrades
                : 0;

            var row = new Grid();
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var wins = StatBox("WIN",   $"{_data.WinTrades}",
                new SolidColorBrush(ColStable));
            var losses = StatBox("LOSS", $"{loss}",
                loss > 0 ? new SolidColorBrush(ColCritical) : new SolidColorBrush(ColStable));
            var total = StatBox("TOTAL", $"{_data.TotalTrades}",
                FgPrimary as SolidColorBrush ?? new SolidColorBrush(Color.FromRgb(245, 245, 247)));
            var wr    = StatBox("WIN %", $"{winPct:F0}%",
                new SolidColorBrush(winPct >= 50 ? ColStable : ColCaution));

            Grid.SetColumn(total, 0); row.Children.Add(total);
            Grid.SetColumn(wins,  1); row.Children.Add(wins);
            Grid.SetColumn(losses,2); row.Children.Add(losses);
            Grid.SetColumn(wr,    3); row.Children.Add(wr);
            inner.Children.Add(row);
            return card;
        }

        // =====================================================================
        // Behavioral Quality Score
        // =====================================================================

        private UIElement BuildBehavioralQualityCard()
        {
            var card  = Card();
            var inner = (StackPanel)((Border)card).Child;

            if (_data.Trades.Count == 0)
            {
                inner.Children.Add(EmptyStatePlaceholder(
                    "Awaiting trade data. Complete your first trade to unlock behavioral analysis."));
                return card;
            }

            // ── Composure score: time-weighted PSI zone distribution ─────────
            // Headline = (stableMin×1.0 + cautionMin×0.3 + criticalMin×0.05) / totalMin × 100
            // This directly answers "how much of the session were you psychologically stable?"
            int qScore = _data.GetZoneComposurePct();

            Color qColor = CompColor(qScore);
            string qLabel = qScore >= 85 ? "Fully Composed"
                          : qScore >= 70 ? "Composed"
                          : qScore >= 50 ? "Slipping"
                          : "Breaking Down";

            // ── Score headline ──────────────────────────────────────────────
            var headline = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            headline.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            headline.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var titleLbl = new TextBlock
            {
                Text              = "Composure Score",
                FontSize          = 12,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                ToolTip           = "Time-weighted zone score: stable=1.0  caution=0.3  critical=0.05\n" +
                                    "Measures the proportion of active session time spent in each PSI zone.\n" +
                                    "100% = fully stable throughout.  ≈10% = almost all time in Critical.",
            };
            headline.Children.Add(titleLbl);

            var scoreLbl = new TextBlock
            {
                Text              = $"{qScore}%  {qLabel}",
                FontSize          = 14,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.Bold,
                Foreground        = new SolidColorBrush(qColor),
                VerticalAlignment = VerticalAlignment.Center,
                TextAlignment     = TextAlignment.Right,
            };
            Grid.SetColumn(scoreLbl, 1); headline.Children.Add(scoreLbl);
            inner.Children.Add(headline);

            // ── PSI zone time bars ──────────────────────────────────────────
            _data.GetZoneTimes(out double stableMin_r, out double cautionMin_r, out double criticalMin_r);
            double totalMin_r = stableMin_r + cautionMin_r + criticalMin_r;

            if (totalMin_r > 0.1)
            {
                inner.Children.Add(new Border
                {
                    Height     = 1,
                    Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                    Margin     = new Thickness(0, 0, 0, 8),
                });
                inner.Children.Add(new TextBlock
                {
                    Text       = "Zone time breakdown",
                    FontSize   = 10,
                    FontFamily = new FontFamily("Segoe UI"),
                    FontWeight = FontWeights.SemiBold,
                    Foreground = FgSecondary,
                    Margin     = new Thickness(0, 0, 0, 5),
                });
                inner.Children.Add(ComposureComponentRow(
                    $"Stable  ({stableMin_r:F0} min)",
                    stableMin_r / totalMin_r,
                    "Time spent with PSI ≥ 88 (Stable zone).\nCounts at full weight toward Composure.",
                    ColStable));
                inner.Children.Add(Spacer(4));
                inner.Children.Add(ComposureComponentRow(
                    $"Caution  ({cautionMin_r:F0} min)",
                    cautionMin_r / totalMin_r,
                    "Time spent with PSI 55–87 (Caution zone).\nCounts at 0.3× weight toward Composure.",
                    ColCaution));
                inner.Children.Add(Spacer(4));
                inner.Children.Add(ComposureComponentRow(
                    $"Critical  ({criticalMin_r:F0} min)",
                    criticalMin_r / totalMin_r,
                    "Time spent with PSI < 55 (Critical zone).\nCounts at 0.05× weight toward Composure.",
                    ColCritical));
            }

            // ── Separator ───────────────────────────────────────────────────
            inner.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 8, 0, 8),
            });

            // ── Behavioral violation diagnostics ─────────────────────────────
            // EWMA peak debts: show WHAT drove PSI into lower zones.
            inner.Children.Add(new TextBlock
            {
                Text       = "Behavioral violations (what drove the score down)",
                FontSize   = 10,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = FgSecondary,
                Margin     = new Thickness(0, 0, 0, 5),
            });
            _data.GetComposureComponents(
                out double oversizeComp, out double holdComp, out double slComp, out double ruleComp);
            inner.Children.Add(ComposureComponentRow(
                "Oversize control", oversizeComp,
                "D3 · how free the session was from position-size violations.\n" +
                "Based on peak D3 EWMA debt. 100% = never exceeded SizeMax.\n" +
                "0% = held maximum oversize debt the entire session."));
            inner.Children.Add(Spacer(6));
            inner.Children.Add(ComposureComponentRow(
                "Hold quality", holdComp,
                "D5 · how free the session was from overstaying losing positions.\n" +
                "Based on peak D5 EWMA debt. 100% = exits were timely.\n" +
                "0% = held underwater positions past personal 90th-pct hold time."));
            inner.Children.Add(Spacer(6));
            inner.Children.Add(ComposureComponentRow(
                "SL integrity", slComp,
                "D2 · how free the session was from stop-loss manipulation.\n" +
                "Based on peak D2 EWMA debt. 100% = stops held or tightened.\n" +
                "0% = repeated adverse stop moves or unprotected positions detected."));
            inner.Children.Add(Spacer(6));
            inner.Children.Add(ComposureComponentRow(
                "Rule compliance", ruleComp,
                "D6 · how free the session was from session-window rule violations.\n" +
                "Based on peak D6 EWMA debt. 100% = all trades within defined session window.\n" +
                "0% = traded heavily outside defined session hours."));

            // ── Behavioral events count ──────────────────────────────────────
            int events = _data.Trades.Count(t => t.MaxD >= 0.5);
            if (events > 0)
            {
                inner.Children.Add(Spacer(10));
                inner.Children.Add(new Border
                {
                    Height     = 1,
                    Background = new SolidColorBrush(Color.FromArgb(20, 255, 255, 255)),
                    Margin     = new Thickness(0, 0, 0, 6),
                });
                inner.Children.Add(new TextBlock
                {
                    Text = $"⚡  {events} behavioral event{(events > 1 ? "s" : "")} this session " +
                           $"(fills where a D-score reached ≥ 50%).",
                    FontSize     = 10,
                    FontFamily   = new FontFamily("Segoe UI"),
                    Foreground   = new SolidColorBrush(ColCaution),
                    TextWrapping = TextWrapping.Wrap,
                });
            }

            // ── Elevated-win callout ─────────────────────────────────────────
            var closing = _data.Trades.Where(t => t.IsClosing).ToList();
            int elevWins = closing.Count(t => t.IsElevated && t.IsWin);
            if (elevWins > 0)
            {
                inner.Children.Add(Spacer(6));
                inner.Children.Add(new TextBlock
                {
                    Text = $"⚠  {elevWins} profitable trade{(elevWins > 1 ? "s" : "")} occurred " +
                           "while behavioral signals were elevated. These gains may not be repeatable " +
                           "— reckless execution that happened to work is not disciplined edge.",
                    FontSize     = 10,
                    FontFamily   = new FontFamily("Segoe UI"),
                    Foreground   = new SolidColorBrush(ColCaution),
                    TextWrapping = TextWrapping.Wrap,
                    Margin       = new Thickness(0, 0, 0, 2),
                });
            }

            return card;
        }

        /// <summary>Renders a labeled mini progress bar for one Composure component.</summary>
        private static UIElement ComposureComponentRow(string label, double value, string tooltip,
            Color? explicitBarColor = null)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(110) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(34) });

            Color barColor = explicitBarColor ?? (
                value >= 0.70 ? ColStable
                : value >= 0.40 ? ColCaution
                : ColCritical);

            var lbl = new TextBlock
            {
                Text              = label,
                FontSize          = 11,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(lbl, 0); g.Children.Add(lbl);

            var trackBg = new Border
            {
                Height            = 5,
                Background        = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                CornerRadius      = new CornerRadius(2.5),
                VerticalAlignment = VerticalAlignment.Center,
                Cursor            = Cursors.Help,
                ToolTip           = MakeTooltip(tooltip),
            };
            var fill = new Border
            {
                Height            = 5,
                Background        = new SolidColorBrush(barColor),
                CornerRadius      = new CornerRadius(2.5),
                HorizontalAlignment = HorizontalAlignment.Left,
                Width             = double.NaN,
            };
            var track = new Grid();
            track.Children.Add(trackBg);
            track.Children.Add(fill);
            fill.SizeChanged += (s, e) =>
            {
                if (track.ActualWidth > 0)
                    fill.Width = Math.Max(0, track.ActualWidth * value);
            };
            track.SizeChanged += (s, e) =>
                fill.Width = Math.Max(0, e.NewSize.Width * value);
            Grid.SetColumn(track, 1); g.Children.Add(track);

            var pctLbl = new TextBlock
            {
                Text              = $"{(int)(value * 100)}%",
                FontSize          = 10,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = new SolidColorBrush(barColor),
                FontWeight        = FontWeights.SemiBold,
                TextAlignment     = TextAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(6, 0, 0, 0),
            };
            Grid.SetColumn(pctLbl, 2); g.Children.Add(pctLbl);

            return g;
        }

        private static UIElement QualityTableRow(string tier, string count, string total, string avg,
                                                  Brush tierColor, bool isBold = false)
        {
            var g = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.8, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.0, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.0, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.0, GridUnitType.Star) });

            FontWeight fw = isBold ? FontWeights.SemiBold : FontWeights.Normal;
            double fs = isBold ? 9 : 11;

            void Add(int col, string text, Brush brush, TextAlignment align = TextAlignment.Left)
            {
                var tb = new TextBlock
                {
                    Text          = text,
                    FontSize      = fs,
                    FontFamily    = new FontFamily("Segoe UI"),
                    FontWeight    = fw,
                    Foreground    = brush,
                    TextAlignment = align,
                };
                Grid.SetColumn(tb, col); g.Children.Add(tb);
            }

            Add(0, tier,  tierColor);
            Add(1, count, isBold ? FgSecondary : FgPrimary,  TextAlignment.Right);
            Add(2, total, isBold ? FgSecondary : FgPrimary,  TextAlignment.Right);
            Add(3, avg,   isBold ? FgSecondary : FgPrimary,  TextAlignment.Right);
            return g;
        }

        private static string FormatPnl(double v)
        {
            return v >= 0 ? $"+${v:F0}" : $"-${Math.Abs(v):F0}";
        }

        // =====================================================================
        // Tilt Cascade
        // =====================================================================

        private UIElement BuildTiltCascadeCard()
        {
            var card  = Card();
            var inner = (StackPanel)((Border)card).Child;

            var fills = _data.Trades;
            if (fills.Count == 0)
            {
                inner.Children.Add(EmptyStatePlaceholder(
                    "No emotional events recorded yet. Start trading to generate your tilt timeline."));
                return card;
            }

            // Column header
            inner.Children.Add(CascadeHeaderRow());
            inner.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(25, 255, 255, 255)),
                Margin     = new Thickness(0, 3, 0, 3),
            });

            double prevPsi = fills[0].Psi;

            for (int i = 0; i < fills.Count; i++)
            {
                var f = fills[i];

                // Zone-change separator
                PsiZone curZone  = SessionData.ZoneOf(f.Psi);
                PsiZone prevZone = SessionData.ZoneOf(prevPsi);
                if (i > 0 && curZone != prevZone)
                {
                    string zoneLabel = curZone == PsiZone.Critical ? "── CRITICAL ZONE ──────────────────────────"
                                     : curZone == PsiZone.Caution  ? "── CAUTION ZONE ───────────────────────────"
                                     : "── STABLE ZONE ────────────────────────────";
                    Color zoneCol = curZone == PsiZone.Critical ? ColCritical
                                  : curZone == PsiZone.Caution  ? ColCaution
                                  : ColStable;
                    inner.Children.Add(new TextBlock
                    {
                        Text       = zoneLabel,
                        FontSize   = 9,
                        FontFamily = new FontFamily("Segoe UI"),
                        Foreground = new SolidColorBrush(
                            Color.FromArgb(180, zoneCol.R, zoneCol.G, zoneCol.B)),
                        Margin     = new Thickness(0, 4, 0, 4),
                    });
                }

                inner.Children.Add(CascadeFillRow(f, prevPsi));
                prevPsi = f.Psi;
            }

            return card;
        }

        private static UIElement CascadeHeaderRow()
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(56)  }); // time
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(38)  }); // type
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); // pnl/hold
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(36)  }); // psi
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80)  }); // signals

            void H(int col, string t)
            {
                var tb = new TextBlock
                {
                    Text          = t,
                    FontSize      = 9,
                    FontFamily    = new FontFamily("Segoe UI"),
                    FontWeight    = FontWeights.SemiBold,
                    Foreground    = FgHint,
                    TextAlignment = col >= 2 ? TextAlignment.Right : TextAlignment.Left,
                };
                Grid.SetColumn(tb, col); g.Children.Add(tb);
            }
            H(0, "TIME"); H(1, "TYPE"); H(2, "P&L / HOLD"); H(3, "PSI"); H(4, "SIGNALS");
            return g;
        }

        private static UIElement CascadeFillRow(TradeRecord f, double prevPsi)
        {
            double psiDelta = f.Psi - prevPsi;

            var g = new Grid { Margin = new Thickness(0, 1, 0, 1) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(56)  });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(38)  });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(36)  });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80)  });

            Color rowColor = f.IsClosing
                ? (f.IsWin ? ColStable : ColCritical)
                : Color.FromRgb(174, 174, 178); // entry = neutral grey

            // Time
            var timeTb = new TextBlock
            {
                Text      = f.Time.ToString("HH:mm:ss"),
                FontSize  = 10,
                FontFamily = new FontFamily("Segoe UI Mono, Consolas"),
                Foreground = new SolidColorBrush(Color.FromRgb(174, 174, 178)),
            };
            Grid.SetColumn(timeTb, 0); g.Children.Add(timeTb);

            // Type (ENTRY / WIN / LOSS)
            string typeText = f.IsClosing ? (f.IsWin ? "WIN" : "LOSS") : "ENTRY";
            var typeTb = new TextBlock
            {
                Text       = typeText,
                FontSize   = 9,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(rowColor),
            };
            Grid.SetColumn(typeTb, 1); g.Children.Add(typeTb);

            // P&L / hold
            string midText = f.IsClosing
                ? (f.Pnl >= 0 ? $"+${f.Pnl:F0}" : $"-${Math.Abs(f.Pnl):F0}")
                  + (f.HoldSeconds >= 60
                      ? $"  {(int)(f.HoldSeconds/60)}m{(int)(f.HoldSeconds%60):D2}s"
                      : f.HoldSeconds > 0 ? $"  {(int)f.HoldSeconds}s" : "")
                : "—";
            Color midColor = f.IsClosing
                ? (f.Pnl > 0 ? ColStable : f.Pnl < 0 ? ColCritical : Color.FromRgb(174, 174, 178))
                : Color.FromRgb(99, 99, 102);
            var midTb = new TextBlock
            {
                Text          = midText,
                FontSize      = 10,
                FontFamily    = new FontFamily("Segoe UI"),
                Foreground    = new SolidColorBrush(midColor),
                TextAlignment = TextAlignment.Right,
            };
            Grid.SetColumn(midTb, 2); g.Children.Add(midTb);

            // PSI (with delta arrow for closing fills)
            string psiText = $"{(int)f.Psi}";
            if (f.IsClosing && Math.Abs(psiDelta) >= 2)
                psiText += psiDelta > 0 ? " ▲" : " ▼";
            Color psiColor = f.Psi >= 70 ? ColStable
                           : f.Psi >= 40 ? ColCaution
                           : ColCritical;
            var psiTb = new TextBlock
            {
                Text          = psiText,
                FontSize      = 10,
                FontFamily    = new FontFamily("Segoe UI"),
                FontWeight    = FontWeights.SemiBold,
                Foreground    = new SolidColorBrush(psiColor),
                TextAlignment = TextAlignment.Right,
            };
            Grid.SetColumn(psiTb, 3); g.Children.Add(psiTb);

            // Signal badges — D1–D7, shown when score ≥ 0.3; tooltip on hover
            var sigSP = new StackPanel { Orientation = Orientation.Horizontal };
            string[] dLabels = { "D1", "D2", "D3", "D4", "D5", "D6", "D7" };
            double[] dScores = { f.D1, f.D2, f.D3, f.D4, f.D5, f.D6, f.D7 };
            for (int i = 0; i < 7; i++)
            {
                if (dScores[i] < 0.3) continue;
                Color dc = dScores[i] >= 0.6 ? ColCritical : ColCaution;
                sigSP.Children.Add(new Border
                {
                    Background    = new SolidColorBrush(Color.FromArgb(200, dc.R, dc.G, dc.B)),
                    CornerRadius  = new CornerRadius(3),
                    Padding       = new Thickness(3, 1, 3, 1),
                    Margin        = new Thickness(0, 0, 2, 0),
                    Cursor        = Cursors.Help,
                    ToolTip       = MakeTooltip(DimTooltips[i]),
                    Child         = new TextBlock
                    {
                        Text       = dLabels[i],
                        FontSize   = 8,
                        FontFamily = new FontFamily("Segoe UI"),
                        FontWeight = FontWeights.SemiBold,
                        Foreground = new SolidColorBrush(Color.FromRgb(28, 28, 30)),
                    },
                });
            }
            Grid.SetColumn(sigSP, 4); g.Children.Add(sigSP);

            return g;
        }

        private UIElement BuildRiskDisciplineCard()
        {
            var card  = Card();
            var inner = (StackPanel)((Border)card).Child;

            int    naked    = _data.NakedPositionDetections;
            // Each detection ≈ one 30-second timer poll → approx exposure seconds
            int    nakedSec = naked * 30;
            string nakedTime = nakedSec >= 60
                ? $"~{nakedSec / 60} min {nakedSec % 60} s"
                : nakedSec > 0 ? $"~{nakedSec} s" : "None";

            bool isOk = naked == 0;
            var statusColor = new SolidColorBrush(isOk ? ColStable : ColCritical);
            string statusText = isOk
                ? "All positions had stop-loss protection"
                : $"Unprotected position detected {naked}× (approx {nakedTime})";

            // Header row: naked-position status
            var statusRow = new Grid();
            statusRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            statusRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var dot = new Ellipse
            {
                Width             = 8,
                Height            = 8,
                Fill              = statusColor,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(0, 0, 8, 0),
            };
            var statusLbl = new TextBlock
            {
                Text              = statusText,
                FontSize          = 11,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = statusColor,
                VerticalAlignment = VerticalAlignment.Center,
                TextWrapping      = TextWrapping.Wrap,
            };
            Grid.SetColumn(dot,       0); statusRow.Children.Add(dot);
            Grid.SetColumn(statusLbl, 1); statusRow.Children.Add(statusLbl);
            inner.Children.Add(statusRow);

            if (!isOk)
            {
                inner.Children.Add(Spacer(8));
                inner.Children.Add(new TextBlock
                {
                    Text         = "A position was open without a covering stop-loss order. " +
                                   "This is the highest-risk behaviour detected this session — " +
                                   "unlimited downside exposure while in an elevated emotional state.",
                    FontSize     = 10,
                    FontFamily   = new FontFamily("Segoe UI"),
                    Foreground   = new SolidColorBrush(Color.FromRgb(174, 174, 178)),
                    TextWrapping = TextWrapping.Wrap,
                    Margin       = new Thickness(16, 0, 0, 0),
                });
            }

            return card;
        }

        private UIElement BuildComparisonCard()
        {
            var card  = Card();
            var inner = (StackPanel)((Border)card).Child;

            double psiDelta    = _data.FinalPsi - _data.PrevFinalPsi;
            int    alertDelta  = _data.AlertsFired - _data.PrevAlerts;

            inner.Children.Add(CompRow("Final PSI",
                psiDelta > 0 ? $"+{psiDelta:F0} pts  ▲ better" :
                psiDelta < 0 ? $"{psiDelta:F0} pts  ▼ worse" : "No change",
                psiDelta >= 0 ? new SolidColorBrush(ColStable) : new SolidColorBrush(ColCritical)));

            inner.Children.Add(Spacer(6));

            inner.Children.Add(CompRow("Alerts fired",
                alertDelta < 0 ? $"{alertDelta}  ▼ fewer"   :
                alertDelta > 0 ? $"+{alertDelta}  ▲ more"   : "Same as before",
                alertDelta <= 0 ? new SolidColorBrush(ColStable) : new SolidColorBrush(ColCritical)));

            return card;
        }

        // =====================================================================
        // Timeline chart drawing (called after layout so ActualWidth is known)
        // =====================================================================

        private void DrawTimeline()
        {
            if (_data.PsiHistory.Count < 2 || _timelineCanvas == null) return;

            double w = _timelineCanvas.ActualWidth;
            double h = _timelineCanvas.ActualHeight;
            if (w < 2 || h < 2) return;

            var history = _data.PsiHistory;
            double totalSec = Math.Max(1,
                (history[history.Count - 1].Time - history[0].Time).TotalSeconds);

            var pts = new PointCollection(history.Count);
            foreach (var snap in history)
            {
                double elapsed = (snap.Time - history[0].Time).TotalSeconds;
                double x = elapsed / totalSec * (w - 4) + 2;
                double y = (1.0 - snap.Psi / 100.0) * (h - 4) + 2;
                pts.Add(new Point(x, y));
            }
            _timelineLine.Points = pts;

            // Reposition zone bands that were added to the canvas
            PositionBands(new Size(w, h), null, null, null);
        }

        private static void PositionBands(Size sz,
            Rectangle critBand, Rectangle cautBand, Rectangle stabBand)
        {
            double w = sz.Width;
            double h = sz.Height;
            if (w <= 0 || h <= 0) return;

            // PSI thresholds: Stable ≥ 88, Caution 55–87, Critical < 55
            // y = (1 - psi/100) * h  →  PSI 88 → top 12 %, PSI 55 → top 45 %
            double stabH  = h * 0.12;
            double cautH  = h * 0.33;
            double critH  = h - stabH - cautH;

            if (critBand  != null) { critBand.Width  = w; critBand.Height  = critH;  Canvas.SetTop(critBand,  h - critH); }
            if (cautBand  != null) { cautBand.Width  = w; cautBand.Height  = cautH;  Canvas.SetTop(cautBand,  h - critH - cautH); }
            if (stabBand  != null) { stabBand.Width  = w; stabBand.Height  = stabH;  Canvas.SetTop(stabBand,  0); }
        }

        private static Rectangle ZoneBand(Color col, byte alpha, double initialH)
        {
            var r = new Rectangle
            {
                Fill   = new SolidColorBrush(Color.FromArgb(alpha, col.R, col.G, col.B)),
                Width  = 100, // will be updated by SizeChanged / PositionBands
                Height = initialH,
            };
            Canvas.SetLeft(r, 0);
            return r;
        }

        // =====================================================================
        // Sub-row builders
        // =====================================================================

        private static UIElement StatBox(string label, string value, SolidColorBrush valueBrush)
        {
            var sp = new StackPanel
            {
                Orientation         = Orientation.Vertical,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 8, 0, 8),
            };
            sp.Children.Add(new TextBlock
            {
                Text                = value,
                FontSize            = 28,
                FontWeight          = FontWeights.Bold,
                FontFamily          = new FontFamily("Segoe UI"),
                Foreground          = valueBrush,
                HorizontalAlignment = HorizontalAlignment.Center,
                TextAlignment       = TextAlignment.Center,
            });
            sp.Children.Add(new TextBlock
            {
                Text                = label,
                FontSize            = 9,
                FontFamily          = new FontFamily("Segoe UI"),
                FontWeight          = FontWeights.SemiBold,
                Foreground          = FgSecondary,
                HorizontalAlignment = HorizontalAlignment.Center,
                TextAlignment       = TextAlignment.Center,
                Margin              = new Thickness(0, 2, 0, 0),
            });
            var border = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(44, 44, 46)),
                CornerRadius    = new CornerRadius(8),
                Child           = sp,
                Margin          = new Thickness(0, 0, 0, 0),
            };
            return border;
        }

        private static UIElement StateBarRow(string label, double minutes, double totalMinutes, Color col)
        {
            double fraction = totalMinutes > 0 ? Math.Min(1, minutes / totalMinutes) : 0;
            int    pct      = (int)Math.Round(fraction * 100);
            string minStr   = minutes >= 1 ? $"{(int)minutes} min" : $"{(int)(minutes * 60)} sec";

            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(72) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(52) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(36) });

            var nameLbl = new TextBlock
            {
                Text              = label,
                FontSize          = 11,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.Medium,
                Foreground        = new SolidColorBrush(col),
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(nameLbl, 0); g.Children.Add(nameLbl);

            // Bar track
            var track = new Border
            {
                Height          = 6,
                Background      = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                CornerRadius    = new CornerRadius(3),
                VerticalAlignment = VerticalAlignment.Center,
            };
            var barGrid = new Grid();
            barGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(fraction, GridUnitType.Star) });
            barGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.0 - fraction, GridUnitType.Star) });
            var fill = new Border
            {
                Background   = new SolidColorBrush(col),
                CornerRadius = new CornerRadius(3),
            };
            Grid.SetColumn(fill, 0); barGrid.Children.Add(fill);
            track.Child = barGrid;
            Grid.SetColumn(track, 1); g.Children.Add(track);

            var timeLbl = new TextBlock
            {
                Text              = minStr,
                FontSize          = 10,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgSecondary,
                TextAlignment     = TextAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(8, 0, 4, 0),
            };
            Grid.SetColumn(timeLbl, 2); g.Children.Add(timeLbl);

            var pctLbl = new TextBlock
            {
                Text              = $"{pct}%",
                FontSize          = 10,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgHint,
                TextAlignment     = TextAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(pctLbl, 3); g.Children.Add(pctLbl);

            return g;
        }

        private static UIElement DimBarRow(string label, double fraction,
                                           string tooltip = null)
        {
            int pct = (int)Math.Round(fraction * 100);

            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(130) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(36) });

            var lbl = new TextBlock
            {
                Text              = label,
                FontSize          = 11,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Cursor            = tooltip != null ? Cursors.Help : Cursors.Arrow,
                ToolTip           = tooltip != null ? MakeTooltip(tooltip) : null,
            };
            Grid.SetColumn(lbl, 0); g.Children.Add(lbl);

            var track = new Border
            {
                Height            = 6,
                Background        = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                CornerRadius      = new CornerRadius(3),
                VerticalAlignment = VerticalAlignment.Center,
            };
            var barG = new Grid();
            barG.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(fraction,       GridUnitType.Star) });
            barG.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.0 - fraction, GridUnitType.Star) });

            // Color: gradient based on fraction (high fraction = more critical)
            Color barCol = fraction > 0.4
                ? LerpColor(ColCaution, ColCritical, (fraction - 0.4) / 0.6)
                : LerpColor(ColStable,  ColCaution,  fraction / 0.4);

            var fill = new Border { Background = new SolidColorBrush(barCol), CornerRadius = new CornerRadius(3) };
            Grid.SetColumn(fill, 0); barG.Children.Add(fill);
            track.Child = barG;
            Grid.SetColumn(track, 1); g.Children.Add(track);

            var pctLbl = new TextBlock
            {
                Text              = $"{pct}%",
                FontSize          = 10,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgHint,
                TextAlignment     = TextAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(pctLbl, 2); g.Children.Add(pctLbl);

            return g;
        }

        private static UIElement CompRow(string label, string value, SolidColorBrush valueBrush)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(110) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            g.Children.Add(new TextBlock
            {
                Text              = label,
                FontSize          = 11,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            });
            var valLbl = new TextBlock
            {
                Text              = value,
                FontSize          = 11,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.SemiBold,
                Foreground        = valueBrush,
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(valLbl, 1); g.Children.Add(valLbl);
            return g;
        }

        // =====================================================================
        // Layout helpers
        // =====================================================================

        private static Border Card()
        {
            return new Border
            {
                Background      = BgCard,
                CornerRadius    = new CornerRadius(10),
                Padding         = new Thickness(12, 10, 12, 10),
                Margin          = new Thickness(0, 4, 0, 0),
                Child           = new StackPanel { Orientation = Orientation.Vertical },
            };
        }

        private static UIElement SectionHeader(string text) => new TextBlock
        {
            Text       = text,
            FontSize   = 10,
            FontFamily = new FontFamily("Segoe UI"),
            FontWeight = FontWeights.SemiBold,
            Foreground = FgSecondary,
            Margin     = new Thickness(2, 12, 0, 0),
        };

        private static UIElement Spacer(double height) => new Border { Height = height };

        private static TextBlock SmallText(string text, TextAlignment align) => new TextBlock
        {
            Text          = text,
            FontSize      = 9,
            FontFamily    = new FontFamily("Segoe UI"),
            Foreground    = FgHint,
            TextAlignment = align,
        };

        private static Label MakeIconBtn(string text, string tip)
        {
            var lbl = new Label
            {
                Content                    = text,
                FontSize                   = 12,
                Width                      = 40,
                Height                     = 44,
                Foreground                 = new SolidColorBrush(Color.FromRgb(142, 142, 147)),
                HorizontalContentAlignment = HorizontalAlignment.Center,
                VerticalContentAlignment   = VerticalAlignment.Center,
                Padding                    = new Thickness(0),
                Cursor                     = Cursors.Hand,
                ToolTip                    = tip,
            };
            lbl.MouseEnter += (_, __) => lbl.Foreground = new SolidColorBrush(Color.FromRgb(220, 220, 224));
            lbl.MouseLeave += (_, __) => lbl.Foreground = new SolidColorBrush(Color.FromRgb(142, 142, 147));
            return lbl;
        }

        // =====================================================================
        // Copy / share
        // =====================================================================

        /// <summary>
        /// Copies a compact session summary to the clipboard.
        /// Called from the Hub action bar (no button to flash) or from the
        /// window header button (passes the button for the flash animation).
        /// </summary>
        internal void CopySummaryToClipboard() => CopySummaryToClipboard(null);

        /// <summary>
        /// Builds a compact emoji-rich text summary and puts it on the clipboard.
        /// Briefly flashes the button label to "✓ Copied!" as feedback.
        /// </summary>
        private void CopySummaryToClipboard(Label btn)
        {
            // ── Build the summary text ────────────────────────────────────────
            string zone = _data.FinalPsi >= 70 ? "STABLE"
                        : _data.FinalPsi >= 40 ? "CAUTION"
                        : "CRITICAL";

            int winPct = _data.TotalTrades > 0
                ? (int)(100.0 * _data.WinTrades / _data.TotalTrades) : 0;

            // Composure score — zone-time based (matches BuildBehavioralQualityCard)
            int bqScore  = _data.GetZoneComposurePct();
            string bqTag = bqScore >= 70 ? "Composed" : bqScore >= 40 ? "Slipping" : "Breaking Down";
            _data.GetZoneTimes(out double stableMin_cb, out double cautionMin_cb, out double criticalMin_cb);

            // Diagnostic breakdown bars data
            _data.GetComposureComponents(out double oversizeComp, out double holdComp,
                                         out double slComp,       out double ruleComp);

            // Top signal
            double topVal  = 0;
            int    topIdx  = -1;
            for (int i = 0; i < 7; i++)
            {
                if (_data.DimCumScore[i] > topVal) { topVal = _data.DimCumScore[i]; topIdx = i; }
            }
            string[] shortLabels = { "Revenge Entry", "Stop Manipulation", "Size Spike",
                                     "Hold Bias",     "Position Overstay", "Rule Violations",
                                     "Overtrading" };
            string topSignalLine = topIdx >= 0
                ? $"\u26a0\ufe0f  Top Signal: {shortLabels[topIdx]}"
                : "\u2705  No significant behavioral signals";

            string nakedLine = _data.NakedPositionDetections > 0
                ? $"🚫  Unprotected position: {_data.NakedPositionDetections}× detected\n"
                : "";

            var sb = new System.Text.StringBuilder();
            sb.AppendLine("🧠 Trading Mindset Report");
            sb.AppendLine($"📅 {_data.Date:MMMM d, yyyy}");
            sb.AppendLine();
            sb.AppendLine("📊 PSI (Psychological State Index)");
            sb.AppendLine($"   Start: {(int)_data.StartPsi}  ·  Lowest: {(int)_data.MinPsi}  ·  Final: {(int)_data.FinalPsi} ({zone})");
            sb.AppendLine($"   Alerts fired: {_data.AlertsFired}");
            sb.AppendLine();
            sb.AppendLine("💰 Trade Results");
            sb.AppendLine($"   {_data.TotalTrades} trades  ·  {_data.WinTrades}W / {_data.TotalTrades - _data.WinTrades}L  ·  {winPct}% win rate");
            sb.AppendLine();
            sb.AppendLine("🎯 Composure Score");
            sb.AppendLine($"   Score: {bqScore}% ({bqTag})  [zone-time weighted]");
            sb.AppendLine($"   Stable: {(int)stableMin_cb} min  ·  " +
                          $"Caution: {(int)cautionMin_cb} min  ·  " +
                          $"Critical: {(int)criticalMin_cb} min");
            sb.AppendLine($"   Oversize: {(int)(oversizeComp*100)}%  ·  " +
                          $"Hold: {(int)(holdComp*100)}%  ·  " +
                          $"SL: {(int)(slComp*100)}%  ·  " +
                          $"Rules: {(int)(ruleComp*100)}%");
            sb.AppendLine();
            sb.AppendLine(topSignalLine);
            if (!string.IsNullOrEmpty(nakedLine)) sb.Append(nakedLine);
            sb.AppendLine();
            sb.AppendLine("Monitored by MeridianPSI · PSI Engine 🧠");

            string summary = sb.ToString().TrimEnd();

            // ── Copy to clipboard on UI thread ────────────────────────────────
            try
            {
                System.Windows.Clipboard.SetText(summary);
            }
            catch { return; } // clipboard unavailable — silent fail

            // ── Flash the button ──────────────────────────────────────────────
            if (btn != null)
            {
                string original = btn.Content as string ?? "⎘";
                btn.Content    = "✓";
                btn.Foreground = new SolidColorBrush(Color.FromRgb(48, 209, 88)); // green

                var timer = new System.Windows.Threading.DispatcherTimer
                {
                    Interval = TimeSpan.FromSeconds(2),
                };
                timer.Tick += (_, __) =>
                {
                    btn.Content    = original;
                    btn.Foreground = new SolidColorBrush(Color.FromRgb(142, 142, 147));
                    timer.Stop();
                };
                timer.Start();
            }
        }

        // =====================================================================
        // Empty-state placeholder
        // =====================================================================

        /// <summary>
        /// Italic hint text shown inside a card when no trade data is available yet.
        /// Keeps sections visible so new users discover the features before trading.
        /// </summary>
        private static UIElement EmptyStatePlaceholder(string message)
        {
            return new TextBlock
            {
                Text            = message,
                FontSize        = 11,
                FontFamily      = new FontFamily("Segoe UI"),
                FontStyle       = FontStyles.Italic,
                Foreground      = FgHint,
                TextWrapping    = TextWrapping.Wrap,
                TextAlignment   = TextAlignment.Center,
                Margin          = new Thickness(8, 8, 8, 8),
            };
        }

        // =====================================================================
        // Tooltip helper
        // =====================================================================

        /// <summary>
        /// Creates a styled dark ToolTip that matches the report's visual theme.
        /// </summary>
        private static ToolTip MakeTooltip(string text)
        {
            return new ToolTip
            {
                Content    = new TextBlock
                {
                    Text         = text,
                    FontSize     = 11,
                    FontFamily   = new FontFamily("Segoe UI"),
                    Foreground   = new SolidColorBrush(Color.FromRgb(230, 230, 232)),
                    TextWrapping = TextWrapping.Wrap,
                    MaxWidth     = 320,
                },
                Background      = new SolidColorBrush(Color.FromRgb(38, 38, 40)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(10, 8, 10, 8),
                HasDropShadow   = true,
            };
        }

        // =====================================================================
        // Color helpers
        // =====================================================================

        private static SolidColorBrush PsiColorBrush(double psi)
        {
            if (psi >= 70) return new SolidColorBrush(LerpColor(ColCaution, ColStable,  (psi - 70.0) / 30.0));
            if (psi >= 40) return new SolidColorBrush(LerpColor(ColCritical, ColCaution, (psi - 40.0) / 30.0));
            return new SolidColorBrush(ColCritical);
        }

        private static Color LerpColor(Color a, Color b, double t)
        {
            t = t < 0 ? 0 : t > 1 ? 1 : t;
            return Color.FromRgb(
                (byte)(a.R + (b.R - a.R) * t),
                (byte)(a.G + (b.G - a.G) * t),
                (byte)(a.B + (b.B - a.B) * t));
        }
    }
}
