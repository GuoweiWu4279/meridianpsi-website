// IntelligenceEngine.cs
//
// Pure computation layer for the PSI Intelligence tab.
// No UI dependencies — operates entirely on List<SessionHistoryEntry>.
// All public types are internal to the add-on.

using System;
using System.Collections.Generic;
using System.Linq;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================================
    // Data models
    // =========================================================================

    internal sealed class MonthDigest
    {
        public DateTime Month;           // first day of the month (yyyy-MM-01)
        public int      SessionCount;
        public double   AvgComposure;
        public int      StableDays;      // sessions with ComposurePct >= 70
        public double   StableDayRate;   // StableDays / SessionCount
        public SessionHistoryEntry BestDay;
        public SessionHistoryEntry WorstDay;
        public double   TotalPnl;
        public double   AvgPnl;
        public double   WinRate;
        public int      TotalTrades;
        public double   AvgCriticalPct;  // avg (CriticalMin / DurationMin)
        public double[] AvgDScores = new double[7]; // D1–D7
        public string   TopStrength;     // dimension with lowest avg score
        public string   TopWeakness;     // dimension with highest avg score
        // Month-over-month comparison (null when prev month unavailable)
        public double?  ComposureChange;
        public double?  StableDayRateChange;
        public string   GradeLabel;      // A+, A, B+, B, C+, C, D
    }

    internal sealed class WeekdayStats
    {
        public DayOfWeek Day;
        public int       SessionCount;
        public double    AvgComposure;
        public double    WinRate;
        public double    AvgPnl;
        public double    AvgCriticalPct;
        public double    AvgD3;   // oversize
        public double    AvgD1;   // revenge / consecutive loss
        public bool      IsHighRisk;   // composure notably below overall avg
        public bool      IsBestDay;    // composure notably above overall avg
    }

    internal sealed class PsiPerfBucket
    {
        public string Label;
        public double PsiMin;
        public double PsiMax;
        public int    SessionCount;
        public double WinRate;
        public double AvgPnl;
        public double TotalPnl;
        public double AvgComposure;
        public double SessionFraction; // % of all sessions in this bucket
    }

    internal sealed class ComposurePerfBucket
    {
        public string Label;
        public int    ComposureMin;
        public int    ComposureMax;
        public int    SessionCount;
        public double WinRate;
        public double AvgPnl;
        public double TotalPnl;
    }

    internal sealed class ProgressPoint
    {
        public DateTime Month;
        public double   AvgComposure;
        public int      StableDays;
        public int      SessionCount;
        public double   WinRate;
        public double   AvgPnl;
    }

    internal sealed class RiskFactor
    {
        public string Reason;
        public int    Delta;    // positive = more risk, negative = reduces risk
        public bool   IsGood => Delta < 0;
    }

    internal sealed class RiskBriefData
    {
        public int      RiskScore;           // 0–100
        public string   RiskLabel;           // "Low" / "Moderate" / "Elevated" / "High"
        public DayOfWeek TodayDayOfWeek;
        public double   TodayHistoricalAvgComposure; // avg composure for this day of week
        public double   OverallAvgComposure;
        public bool     IsTodayAboveAverage;
        public int      ConsecutiveLowSessions;  // days in a row with Composure < 50
        public string   TopWeaknessThisWeek;     // dim name with highest avg score last 7 days
        public double   TopWeaknessScore;        // 0–1
        public string   RecommendationText;
        public List<RiskFactor> Factors;
        public bool     HasEnoughData;
    }

    internal sealed class CrashTrigger
    {
        public string DimName;
        public int    DimIndex;
        public double CorrelationScore;      // how often this dim is elevated on high-critical days
        public double AvgScoreOnCrashDays;
        public double AvgScoreOnNormalDays;
        public int    CrashDayCount;
        public int    PresentOnCrashDays;    // crash days where this D-score > 0.2
        public string SeverityLabel;         // LOW / MED / HIGH based on avg score on crash days
    }

    // =========================================================================
    // Computation engine
    // =========================================================================

    internal static class IntelligenceEngine
    {
        internal const int MinSessionsBasic   = 5;
        internal const int MinSessionsPattern = 10;
        internal const int MinSessionsCorr    = 8;

        private static readonly string[] DimNames =
        {
            "Revenge Entry", "Stop Manipulation", "Size Spike",
            "Hold Bias", "Position Overstay", "Rule Violations", "Overtrading Pace"
        };

        // Positive framing used when this dimension is a *strength* (lowest D-score)
        private static readonly string[] DimStrengthNames =
        {
            "Entry Discipline",     // Revenge Entry
            "Stop Adherence",       // Stop Manipulation
            "Size Consistency",     // Size Spike
            "Execution Neutrality", // Hold Bias
            "Exit Timing",          // Position Overstay
            "Rule Adherence",       // Rule Violations
            "Pace Control",         // Overtrading Pace
        };

        private static string DimStrengthName(int i) =>
            i >= 0 && i < DimStrengthNames.Length ? DimStrengthNames[i] : "Unknown";

        // ── Helpers ──────────────────────────────────────────────────────────

        private static double[] DScores(SessionHistoryEntry e) =>
            new[] { e.D1, e.D2, e.D3, e.D4, e.D5, e.D6, e.D7 };

        private static double CriticalPct(SessionHistoryEntry e) =>
            e.DurationMinutes > 0
                ? Math.Min(1.0, e.TimeInCriticalMin / e.DurationMinutes)
                : 0.0;

        private static double WinRateOf(IList<SessionHistoryEntry> sessions)
        {
            int total = sessions.Sum(s => s.TotalTrades);
            int wins  = sessions.Sum(s => s.WinTrades);
            return total > 0 ? (double)wins / total : 0.0;
        }

        internal static string ComposureGrade(double composure)
        {
            if (composure >= 90) return "A+";
            if (composure >= 80) return "A";
            if (composure >= SessionData.ComposureStableThreshold) return "B+";
            if (composure >= 60) return "B";
            if (composure >= 50) return "C+";
            if (composure >= 40) return "C";
            return "D";
        }

        private static string DimName(int i) =>
            i >= 0 && i < DimNames.Length ? DimNames[i] : "Unknown";

        // ── Monthly Digest ────────────────────────────────────────────────────

        internal static MonthDigest ComputeMonthDigest(
            List<SessionHistoryEntry> allSessions,
            DateTime month,
            MonthDigest prevMonthDigest = null)
        {
            var start = new DateTime(month.Year, month.Month, 1);
            var end   = start.AddMonths(1);

            var sessions = allSessions
                .Where(s => s.Date >= start && s.Date < end && s.TotalTrades > 0)
                .ToList();

            var digest = new MonthDigest { Month = start };

            if (sessions.Count == 0) return digest;

            digest.SessionCount = sessions.Count;
            digest.AvgComposure = sessions.Average(s => s.ComposurePct);
            digest.StableDays   = sessions.Count(s => s.ComposurePct >= SessionData.ComposureStableThreshold);
            digest.StableDayRate = (double)digest.StableDays / digest.SessionCount;
            digest.BestDay       = sessions.OrderByDescending(s => s.ComposurePct).First();
            digest.WorstDay      = sessions.OrderBy(s => s.ComposurePct).First();
            digest.TotalPnl      = sessions.Sum(s => s.TotalPnl);
            digest.AvgPnl        = sessions.Average(s => s.TotalPnl);
            digest.TotalTrades   = sessions.Sum(s => s.TotalTrades);
            digest.WinRate       = WinRateOf(sessions);
            digest.AvgCriticalPct = sessions.Average(CriticalPct) * 100.0;

            // Average D-scores
            for (int i = 0; i < 7; i++)
            {
                int idx = i;
                digest.AvgDScores[i] = sessions.Average(s => DScores(s)[idx]);
            }

            // Strength = lowest D, Weakness = highest D (non-D4, D4 is less actionable)
            int[] actionable = new[] { 0, 1, 2, 4, 5, 6 }; // skip D4 (hold bias - less controllable)
            int strengthIdx = actionable.OrderBy(i => digest.AvgDScores[i]).First();
            int weaknessIdx = actionable.OrderByDescending(i => digest.AvgDScores[i]).First();
            digest.TopStrength = DimName(strengthIdx);
            digest.TopWeakness = DimName(weaknessIdx);

            // Month-over-month comparison
            if (prevMonthDigest != null && prevMonthDigest.SessionCount > 0)
            {
                digest.ComposureChange      = digest.AvgComposure  - prevMonthDigest.AvgComposure;
                digest.StableDayRateChange  = digest.StableDayRate - prevMonthDigest.StableDayRate;
            }

            digest.GradeLabel = ComposureGrade(digest.AvgComposure);
            return digest;
        }

        // ── Weekday Stats ─────────────────────────────────────────────────────

        internal static WeekdayStats[] ComputeWeekdayStats(List<SessionHistoryEntry> sessions)
        {
            var tradingSessions = sessions.Where(s => s.TotalTrades > 0).ToList();
            if (tradingSessions.Count == 0)
                return Array.Empty<WeekdayStats>();

            double overallAvgComposure = tradingSessions.Average(s => s.ComposurePct);

            var days = new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday,
                               DayOfWeek.Thursday, DayOfWeek.Friday };

            return days.Select(dow =>
            {
                var ds = tradingSessions.Where(s => s.Date.DayOfWeek == dow).ToList();
                if (ds.Count == 0)
                    return new WeekdayStats { Day = dow, SessionCount = 0 };

                double avgComp = ds.Average(s => s.ComposurePct);
                return new WeekdayStats
                {
                    Day             = dow,
                    SessionCount    = ds.Count,
                    AvgComposure    = avgComp,
                    WinRate         = WinRateOf(ds) * 100.0,
                    AvgPnl          = ds.Average(s => s.TotalPnl),
                    AvgCriticalPct  = ds.Average(CriticalPct) * 100.0,
                    AvgD3           = ds.Average(s => s.D3),
                    AvgD1           = ds.Average(s => s.D1),
                    IsHighRisk      = avgComp < overallAvgComposure - 10,
                    IsBestDay       = avgComp > overallAvgComposure + 10,
                };
            }).ToArray();
        }

        // ── PSI × Performance Correlation ─────────────────────────────────────

        internal static PsiPerfBucket[] ComputePsiPerfCorrelation(List<SessionHistoryEntry> sessions)
        {
            var ts = sessions.Where(s => s.TotalTrades > 0).ToList();
            if (ts.Count == 0) return Array.Empty<PsiPerfBucket>();

            var buckets = new[]
            {
                (label: "Stable  (AvgPSI ≥ 75)", min: 75.0, max: 101.0),
                (label: "Caution  (AvgPSI 55–74)", min: 55.0, max: 75.0),
                (label: "Critical  (AvgPSI < 55)",  min:  0.0, max: 55.0),
            };

            return buckets.Select(b =>
            {
                var g = ts.Where(s => s.AvgPsi >= b.min && s.AvgPsi < b.max).ToList();
                return new PsiPerfBucket
                {
                    Label           = b.label,
                    PsiMin          = b.min,
                    PsiMax          = b.max,
                    SessionCount    = g.Count,
                    WinRate         = g.Count > 0 ? WinRateOf(g) * 100.0 : 0.0,
                    AvgPnl          = g.Count > 0 ? g.Average(s => s.TotalPnl) : 0.0,
                    TotalPnl        = g.Count > 0 ? g.Sum(s => s.TotalPnl) : 0.0,
                    AvgComposure    = g.Count > 0 ? g.Average(s => s.ComposurePct) : 0.0,
                    SessionFraction = ts.Count > 0 ? (double)g.Count / ts.Count * 100.0 : 0.0,
                };
            }).ToArray();
        }

        internal static ComposurePerfBucket[] ComputeComposurePerfCorrelation(
            List<SessionHistoryEntry> sessions)
        {
            var ts = sessions.Where(s => s.TotalTrades > 0).ToList();
            if (ts.Count == 0) return Array.Empty<ComposurePerfBucket>();

            var buckets = new[]
            {
                (label: "Composed  (≥ 70%)", min: 70, max: 101),
                (label: "Slipping  (40–69%)", min: 40, max: 70),
                (label: "Breaking Down  (< 40%)", min: 0, max: 40),
            };

            return buckets.Select(b =>
            {
                var g = ts.Where(s => s.ComposurePct >= b.min && s.ComposurePct < b.max).ToList();
                return new ComposurePerfBucket
                {
                    Label        = b.label,
                    ComposureMin = b.min,
                    ComposureMax = b.max,
                    SessionCount = g.Count,
                    WinRate      = g.Count > 0 ? WinRateOf(g) * 100.0 : 0.0,
                    AvgPnl       = g.Count > 0 ? g.Average(s => s.TotalPnl) : 0.0,
                    TotalPnl     = g.Count > 0 ? g.Sum(s => s.TotalPnl) : 0.0,
                };
            }).ToArray();
        }

        // ── Progress Trend ────────────────────────────────────────────────────

        internal static List<ProgressPoint> ComputeProgressTrend(
            List<SessionHistoryEntry> sessions, int months = 6)
        {
            var ts     = sessions.Where(s => s.TotalTrades > 0).ToList();
            var result = new List<ProgressPoint>();
            var today  = DateTime.Today;

            for (int m = months - 1; m >= 0; m--)
            {
                var month = new DateTime(today.Year, today.Month, 1).AddMonths(-m);
                var end   = month.AddMonths(1);
                var g     = ts.Where(s => s.Date >= month && s.Date < end).ToList();
                result.Add(new ProgressPoint
                {
                    Month         = month,
                    AvgComposure  = g.Count > 0 ? g.Average(s => s.ComposurePct) : -1,
                    StableDays    = g.Count(s => s.ComposurePct >= SessionData.ComposureStableThreshold),
                    SessionCount  = g.Count,
                    WinRate       = g.Count > 0 ? WinRateOf(g) * 100.0 : 0.0,
                    AvgPnl        = g.Count > 0 ? g.Average(s => s.TotalPnl) : 0.0,
                });
            }
            return result;
        }

        // ── Crash Triggers ────────────────────────────────────────────────────

        internal static List<CrashTrigger> ComputeCrashTriggers(
            List<SessionHistoryEntry> sessions)
        {
            var ts = sessions.Where(s => s.TotalTrades > 0 && s.DurationMinutes > 0).ToList();
            if (ts.Count < MinSessionsBasic) return new List<CrashTrigger>();

            // "Crash day" = top 25% of sessions by Critical time %
            double threshold = ts
                .Select(CriticalPct)
                .OrderByDescending(x => x)
                .Skip(Math.Max(0, (int)(ts.Count * 0.25) - 1))
                .FirstOrDefault();
            threshold = Math.Max(0.10, threshold); // at least 10% critical time

            var crashDays  = ts.Where(s => CriticalPct(s) >= threshold).ToList();
            var normalDays = ts.Where(s => CriticalPct(s) < threshold).ToList();

            if (crashDays.Count == 0) return new List<CrashTrigger>();

            var triggers = new List<CrashTrigger>();
            for (int i = 0; i < 7; i++)
            {
                int idx = i;
                double avgCrash  = crashDays.Average(s => DScores(s)[idx]);
                double avgNormal = normalDays.Count > 0
                    ? normalDays.Average(s => DScores(s)[idx]) : 0.0;

                // Correlation score: how much higher is this D on crash days vs normal days
                double correlation = avgNormal > 0.001
                    ? (avgCrash - avgNormal) / (avgCrash + avgNormal + 0.001)
                    : avgCrash;

                // Count crash days where this behavior was meaningfully active (D-score > 0.2)
                int presentOnCrash = crashDays.Count(s => DScores(s)[idx] > 0.2);

                string severity = avgCrash >= 0.6 ? "HIGH"
                                : avgCrash >= 0.3 ? "MED"
                                : "LOW";

                triggers.Add(new CrashTrigger
                {
                    DimName              = DimNames[i],
                    DimIndex             = i,
                    CorrelationScore     = Math.Max(0, correlation),
                    AvgScoreOnCrashDays  = avgCrash,
                    AvgScoreOnNormalDays = avgNormal,
                    CrashDayCount        = crashDays.Count,
                    PresentOnCrashDays   = presentOnCrash,
                    SeverityLabel        = severity,
                });
            }

            return triggers
                .Where(t => t.PresentOnCrashDays > 0)
                .OrderByDescending(t => t.PresentOnCrashDays)
                .ThenByDescending(t => t.CorrelationScore)
                .Take(4)
                .ToList();
        }

        // ── Pre-Session Risk Brief ─────────────────────────────────────────────

        internal static RiskBriefData ComputeRiskBrief(List<SessionHistoryEntry> sessions)
        {
            var result = new RiskBriefData
            {
                TodayDayOfWeek = DateTime.Today.DayOfWeek,
                Factors        = new List<RiskFactor>(),
            };

            var ts = sessions
                .Where(s => s.TotalTrades > 0)
                .OrderByDescending(s => s.Date)
                .ToList();

            if (ts.Count < MinSessionsBasic)
            {
                result.HasEnoughData = false;
                result.RecommendationText =
                    $"Complete {MinSessionsBasic - ts.Count} more session{(MinSessionsBasic - ts.Count == 1 ? "" : "s")} " +
                    "with trades to unlock your personalized risk brief.";
                return result;
            }

            result.HasEnoughData       = true;
            result.OverallAvgComposure = ts.Average(s => s.ComposurePct);

            // Factor 1: Last session composure
            var last = ts.First();
            if (last.ComposurePct < 40)
            {
                result.Factors.Add(new RiskFactor
                {
                    Reason = $"Last session Composure was very low ({last.ComposurePct}%)",
                    Delta  = 20,
                });
            }
            else if (last.ComposurePct < 60)
            {
                result.Factors.Add(new RiskFactor
                {
                    Reason = $"Last session Composure was below average ({last.ComposurePct}%)",
                    Delta  = 10,
                });
            }
            else if (last.ComposurePct >= 80)
            {
                result.Factors.Add(new RiskFactor
                {
                    Reason = $"Last session was strong (Composure {last.ComposurePct}%)",
                    Delta  = -8,
                });
            }

            // Factor 2: Consecutive low-composure sessions
            int consecutive = 0;
            foreach (var s in ts)
            {
                if (s.ComposurePct < 50) consecutive++;
                else break;
            }
            result.ConsecutiveLowSessions = consecutive;
            if (consecutive >= 3)
            {
                result.Factors.Add(new RiskFactor
                {
                    Reason = $"{consecutive} consecutive sessions with Composure < 50%",
                    Delta  = 20,
                });
            }
            else if (consecutive == 2)
            {
                result.Factors.Add(new RiskFactor
                {
                    Reason = "2 consecutive sessions with Composure < 50%",
                    Delta  = 12,
                });
            }

            // Factor 3: Day-of-week pattern
            var todaySessions = ts
                .Where(s => s.Date.DayOfWeek == result.TodayDayOfWeek)
                .ToList();
            if (todaySessions.Count >= 3)
            {
                result.TodayHistoricalAvgComposure = todaySessions.Average(s => s.ComposurePct);
                double diff = result.TodayHistoricalAvgComposure - result.OverallAvgComposure;
                result.IsTodayAboveAverage = diff > 5;

                if (diff < -10)
                {
                    result.Factors.Add(new RiskFactor
                    {
                        Reason = $"Historically your worst day: avg Composure {result.TodayHistoricalAvgComposure:F0}% on {result.TodayDayOfWeek}s",
                        Delta  = 15,
                    });
                }
                else if (diff > 10)
                {
                    result.Factors.Add(new RiskFactor
                    {
                        Reason = $"Historically your best day: avg Composure {result.TodayHistoricalAvgComposure:F0}% on {result.TodayDayOfWeek}s",
                        Delta  = -10,
                    });
                }
            }

            // Factor 4: Recent weakness (last 7 sessions)
            var recent7 = ts.Take(7).ToList();
            double[] avgRecent = new double[7];
            for (int i = 0; i < 7; i++)
            {
                int idx = i;
                avgRecent[i] = recent7.Average(s => DScores(s)[idx]);
            }
            int worstDim = new[] { 0, 1, 2, 4, 5, 6 }
                .OrderByDescending(i => avgRecent[i]).First();
            result.TopWeaknessThisWeek = DimNames[worstDim];
            result.TopWeaknessScore    = avgRecent[worstDim];

            if (result.TopWeaknessScore >= 0.35)
            {
                result.Factors.Add(new RiskFactor
                {
                    Reason = $"'{result.TopWeaknessThisWeek}' active in {recent7.Count(s => DScores(s)[worstDim] >= 0.2)}/{recent7.Count} recent sessions",
                    Delta  = 12,
                });
            }

            // Factor 5: Improving trend
            if (ts.Count >= 6)
            {
                double recent3 = ts.Take(3).Average(s => s.ComposurePct);
                double prior3  = ts.Skip(3).Take(3).Average(s => s.ComposurePct);
                if (recent3 - prior3 >= 10)
                {
                    result.Factors.Add(new RiskFactor
                    {
                        Reason = $"Composure trending up ({prior3:F0}% → {recent3:F0}% over last 6 sessions)",
                        Delta  = -12,
                    });
                }
                else if (prior3 - recent3 >= 10)
                {
                    result.Factors.Add(new RiskFactor
                    {
                        Reason = $"Composure trending down ({prior3:F0}% → {recent3:F0}% over last 6 sessions)",
                        Delta  = 12,
                    });
                }
            }

            // Compute final score
            int baseScore = 30;
            int totalDelta = result.Factors.Sum(f => f.Delta);
            result.RiskScore = Math.Max(0, Math.Min(100, baseScore + totalDelta));

            result.RiskLabel = result.RiskScore >= 70 ? "High"
                             : result.RiskScore >= 50 ? "Elevated"
                             : result.RiskScore >= 30 ? "Moderate"
                             : "Low";

            // Recommendation text
            if (result.RiskScore >= 70)
                result.RecommendationText =
                    $"High risk today. Consider reducing size by 50% and setting a hard 2-loss stop. " +
                    $"Your top active risk: '{result.TopWeaknessThisWeek}'.";
            else if (result.RiskScore >= 50)
                result.RecommendationText =
                    $"Elevated risk. Trade with caution — set your Guard rules before entering. " +
                    $"Watch for '{result.TopWeaknessThisWeek}' patterns.";
            else if (result.RiskScore >= 30)
                result.RecommendationText =
                    "Normal risk. No specific warnings — execute your plan.";
            else
                result.RecommendationText =
                    "Conditions are favorable. Your recent trend is positive.";

            return result;
        }

        // ── Convenience: list of available months with data ───────────────────

        internal static List<DateTime> GetAvailableMonths(List<SessionHistoryEntry> sessions)
        {
            return sessions
                .Where(s => s.TotalTrades > 0)
                .Select(s => new DateTime(s.Date.Year, s.Date.Month, 1))
                .Distinct()
                .OrderBy(m => m)
                .ToList();
        }
    }
}
