// JournalStore.cs
//
// v1.2 Journal — passive, non-intrusive trader self-capture.
//
// Design intent (ARCHITECTURE.md §14.3 Journaling System):
//   • Zero mandatory input: the trader may use none, some, or all of the
//     capture granularities.  PSI is never gated on journal presence.
//   • Multi-granularity:
//       1. Passive mechanical (engine-recorded behavioural events).
//       2. One-click emotional tags (😌 / 😐 / 😬 → Calm / Neutral / Stressed).
//       3. Quick notes — one-line free text.
//       4. Session-end summary (opportunity, not requirement).
//       5. Next-session review — surfaces yesterday's notes on first open.
//   • Evidence-anchored recall: every entry stores the PSI value, dominant
//     dimension, and session-P&L at the moment of capture so the trader
//     cannot fully retcon their emotional state later.
//   • Local-only persistence: journal.csv alongside baseline.xml; never
//     transmitted without explicit user consent (v1.3 opt-in).
//
// File format: append-only CSV so the file is trivially exportable and
// readable without any NinjaTrader machinery.
//
//   timestamp,session_date,kind,emotion,psi,dominant_dim,session_pnl,note
//
// Fields:
//   timestamp       ISO-8601 local time of the entry
//   session_date    yyyy-MM-dd anchor of the active trading session
//   kind            "QuickNote" | "EmotionTag" | "SessionSummary" | "EngineEvent"
//   emotion         "Calm" | "Neutral" | "Stressed" | ""  (blank for notes only)
//   psi             PSI value at capture time (snapshot, 2 dp)
//   dominant_dim    highest-debt dimension label or empty
//   session_pnl     realised session P&L at capture time ($)
//   note            free text (CSV-escaped)
//
// Thread-safety: Append is guarded by a per-file lock.  Reads load the
// whole file into memory (target: hundreds of entries per session at most).

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;

namespace NinjaTrader.NinjaScript.AddOns
{
    public enum JournalEmotion
    {
        None     = 0,
        Calm     = 1,
        Neutral  = 2,
        Stressed = 3,
    }

    /// <summary>
    /// Canonical journal-entry kinds.  Use <see cref="JournalKindExt.ToStored"/>
    /// to convert to the string stored in the CSV column.
    /// </summary>
    public enum JournalKind
    {
        QuickNote        = 0,
        EmotionTag       = 1,
        SessionSummary   = 2,
        EngineEvent      = 3,
        NextSessionReview = 4,
    }

    internal static class JournalKindExt
    {
        public static string ToStored(this JournalKind k)
        {
            switch (k)
            {
                case JournalKind.QuickNote:         return "QuickNote";
                case JournalKind.EmotionTag:        return "EmotionTag";
                case JournalKind.SessionSummary:    return "SessionSummary";
                case JournalKind.EngineEvent:       return "EngineEvent";
                case JournalKind.NextSessionReview: return "NextSessionReview";
                default:                            return "QuickNote";
            }
        }
    }

    public sealed class JournalEntry
    {
        public DateTime       Timestamp;
        public DateTime       SessionDate;
        public string         Kind;             // see header
        public JournalEmotion Emotion;
        public double         Psi;
        public string         DominantDim;
        public double         SessionPnl;
        public string         Note;

        public string EmotionString
        {
            get
            {
                switch (Emotion)
                {
                    case JournalEmotion.Calm:     return "Calm";
                    case JournalEmotion.Neutral:  return "Neutral";
                    case JournalEmotion.Stressed: return "Stressed";
                    default:                      return "";
                }
            }
        }
    }

    public static class JournalStore
    {
        private static readonly object _sync = new object();

        // Data dir defaults to the same folder as baseline.xml / profile.xml.
        private static string _dataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "NinjaTrader 8", "bin", "Custom", "AddOns", "TradeMonitorData");

        /// <summary>Redirect the journal file to a custom directory (test harness).</summary>
        internal static void SetDataDir(string path)
        {
            if (!string.IsNullOrEmpty(path)) _dataDir = path;
        }

        public static string JournalPath => Path.Combine(_dataDir, "journal.csv");

        /// <summary>
        /// Append a single entry.  Safe to call from any thread.
        /// Silently swallows I/O errors — journaling must never break trading.
        /// If <paramref name="onError"/> is supplied, errors are routed there
        /// but still swallowed.
        /// </summary>
        public static void Append(JournalEntry entry, Action<string> onError = null)
        {
            if (entry == null) return;
            try
            {
                lock (_sync)
                {
                    if (!Directory.Exists(_dataDir))
                        Directory.CreateDirectory(_dataDir);

                    bool needsHeader = !File.Exists(JournalPath);
                    using (var sw = new StreamWriter(JournalPath, append: true, encoding: Encoding.UTF8))
                    {
                        if (needsHeader)
                            sw.WriteLine("timestamp,session_date,kind,emotion,psi,dominant_dim,session_pnl,note");
                        sw.WriteLine(FormatRow(entry));
                    }
                }
            }
            catch (Exception ex)
            {
                try { onError?.Invoke("[JournalStore] Append failed: " + ex.Message); } catch { }
            }
        }

        /// <summary>
        /// Load every entry (or filter by session date).  Returns empty list
        /// on any I/O or parse error.
        /// </summary>
        public static List<JournalEntry> LoadAll()
        {
            var result = new List<JournalEntry>();
            try
            {
                lock (_sync)
                {
                    if (!File.Exists(JournalPath)) return result;

                    using (var sr = new StreamReader(JournalPath, Encoding.UTF8))
                    {
                        string line;
                        bool   first = true;
                        while ((line = sr.ReadLine()) != null)
                        {
                            if (first) { first = false; continue; }  // skip header
                            if (string.IsNullOrWhiteSpace(line)) continue;

                            var entry = ParseRow(line);
                            if (entry != null) result.Add(entry);
                        }
                    }
                }
            }
            catch { /* swallow */ }
            return result;
        }

        /// <summary>
        /// Return the most recent N entries matching the given session date
        /// (null = any).  For the HUD "recall yesterday" surface: pass
        /// previous session date and take limit ≤ 10.
        /// </summary>
        public static List<JournalEntry> Recent(int limit, DateTime? sessionDate = null)
        {
            var all = LoadAll();
            var filtered = new List<JournalEntry>();
            for (int i = all.Count - 1; i >= 0 && filtered.Count < limit; i--)
            {
                var e = all[i];
                if (sessionDate.HasValue && e.SessionDate.Date != sessionDate.Value.Date)
                    continue;
                filtered.Add(e);
            }
            filtered.Reverse();
            return filtered;
        }

        // =====================================================================
        // CSV encoding
        // =====================================================================

        private static string FormatRow(JournalEntry e)
        {
            var inv = CultureInfo.InvariantCulture;
            return string.Join(",",
                e.Timestamp.ToString("yyyy-MM-dd HH:mm:ss", inv),
                e.SessionDate.ToString("yyyy-MM-dd", inv),
                CsvEscape(e.Kind ?? ""),
                e.EmotionString,
                e.Psi.ToString("F2", inv),
                CsvEscape(e.DominantDim ?? ""),
                e.SessionPnl.ToString("F2", inv),
                CsvEscape(e.Note ?? ""));
        }

        private static JournalEntry ParseRow(string line)
        {
            var fields = SplitCsv(line);
            if (fields.Count < 8) return null;

            var inv = CultureInfo.InvariantCulture;
            var e = new JournalEntry();

            if (!DateTime.TryParseExact(fields[0], "yyyy-MM-dd HH:mm:ss",
                    inv, DateTimeStyles.None, out e.Timestamp)) return null;
            if (!DateTime.TryParseExact(fields[1], "yyyy-MM-dd",
                    inv, DateTimeStyles.None, out e.SessionDate)) return null;

            e.Kind = fields[2];
            switch (fields[3])
            {
                case "Calm":     e.Emotion = JournalEmotion.Calm;     break;
                case "Neutral":  e.Emotion = JournalEmotion.Neutral;  break;
                case "Stressed": e.Emotion = JournalEmotion.Stressed; break;
                default:         e.Emotion = JournalEmotion.None;     break;
            }
            double.TryParse(fields[4], NumberStyles.Float, inv, out e.Psi);
            e.DominantDim = fields[5];
            double.TryParse(fields[6], NumberStyles.Float, inv, out e.SessionPnl);
            e.Note = fields[7];
            return e;
        }

        // =====================================================================
        // Per-day rich journal notes (daynotes.csv)
        //   date,note
        // One row per trading date. Overwritten (not appended) on save so the
        // trader can revise their note at any time.
        // =====================================================================

        public static string DayNotesPath => Path.Combine(_dataDir, "daynotes.csv");

        /// <summary>
        /// Return the full-text journal note saved for <paramref name="date"/>,
        /// or an empty string if none exists.
        /// </summary>
        public static string LoadDayNote(DateTime date)
        {
            try
            {
                lock (_sync)
                {
                    if (!File.Exists(DayNotesPath)) return "";
                    string key = date.Date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                    using (var sr = new StreamReader(DayNotesPath, Encoding.UTF8))
                    {
                        string line;
                        bool first = true;
                        while ((line = sr.ReadLine()) != null)
                        {
                            if (first) { first = false; continue; } // skip header
                            if (string.IsNullOrWhiteSpace(line)) continue;
                            var fields = SplitCsv(line);
                            if (fields.Count >= 2 && fields[0] == key)
                                return UnescapeNote(fields[1]);
                        }
                    }
                }
            }
            catch { }
            return "";
        }

        /// <summary>
        /// Save (or replace) the full-text journal note for <paramref name="date"/>.
        /// Passing an empty/null string removes the entry for that date.
        /// </summary>
        public static void SaveDayNote(DateTime date, string note)
        {
            try
            {
                lock (_sync)
                {
                    if (!Directory.Exists(_dataDir))
                        Directory.CreateDirectory(_dataDir);

                    string key   = date.Date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                    var    rows  = new List<string>();
                    bool   found = false;

                    if (File.Exists(DayNotesPath))
                    {
                        using (var sr = new StreamReader(DayNotesPath, Encoding.UTF8))
                        {
                            string line;
                            bool   first = true;
                            while ((line = sr.ReadLine()) != null)
                            {
                                if (first) { first = false; continue; } // skip header
                                if (string.IsNullOrWhiteSpace(line)) continue;
                                var fields = SplitCsv(line);
                                if (fields.Count >= 1 && fields[0] == key)
                                {
                                    found = true;
                                    if (!string.IsNullOrEmpty(note))
                                        rows.Add(key + "," + CsvEscape(EscapeNote(note)));
                                    // else: omit (effectively deletes)
                                }
                                else
                                {
                                    rows.Add(line);
                                }
                            }
                        }
                    }

                    if (!found && !string.IsNullOrEmpty(note))
                        rows.Add(key + "," + CsvEscape(EscapeNote(note)));

                    using (var sw = new StreamWriter(DayNotesPath, append: false, encoding: Encoding.UTF8))
                    {
                        sw.WriteLine("date,note");
                        foreach (var r in rows) sw.WriteLine(r);
                    }
                }
            }
            catch { }
        }

        // =====================================================================
        // Auto-compile: assemble a draft day-note from granular journal entries
        // =====================================================================

        /// <summary>
        /// Build a formatted draft journal note for <paramref name="date"/> by
        /// reading all granular entries (quick notes, emotion tags, session summary)
        /// from <see cref="JournalPath"/> for that date and combining them with the
        /// supplied session statistics.
        ///
        /// The result is meant to be shown in the day-note box for the trader to
        /// review and edit before calling <see cref="SaveDayNote"/>.  It is NOT
        /// automatically saved.
        /// </summary>
        /// <param name="date">Session date to compile.</param>
        /// <param name="finalPsi">PSI at session close (or current PSI if still live).</param>
        /// <param name="trades">Total completed trades this session.</param>
        /// <param name="pnl">Net realised P&amp;L for the session.</param>
        /// <param name="winRate">Win rate 0–1 (pass -1 if unavailable).</param>
        /// <param name="dominantDim">Dominant PSI dimension label, or null.</param>
        public static string CompileSessionJournal(DateTime date,
                                                   double   finalPsi,
                                                   int      trades,
                                                   double   pnl,
                                                   double   winRate,
                                                   string   dominantDim)
        {
            var entries = new List<JournalEntry>();
            try { entries = LoadAll(); }
            catch { }

            // Filter to the requested date, skip engine-internal EngineEvent rows
            var day = new List<JournalEntry>();
            foreach (var e in entries)
            {
                if (e.SessionDate.Date == date.Date &&
                    !string.Equals(e.Kind, "EngineEvent", StringComparison.OrdinalIgnoreCase))
                    day.Add(e);
            }

            var inv = CultureInfo.InvariantCulture;
            var sb  = new StringBuilder();

            // ── Header ────────────────────────────────────────────────────────
            sb.AppendLine("SESSION JOURNAL — " + date.ToString("dddd, MMMM d, yyyy"));
            sb.AppendLine(new string('─', 46));
            sb.AppendLine();

            // ── Stats row ─────────────────────────────────────────────────────
            sb.Append("Trades: ").Append(trades);
            sb.Append("  •  P&L: ").Append(pnl >= 0 ? "+" : "").Append(pnl.ToString("F2", inv));
            if (winRate >= 0)
                sb.Append("  •  Win Rate: ").Append((winRate * 100.0).ToString("F0", inv)).Append('%');
            sb.AppendLine();
            sb.Append("Final PSI: ").Append(finalPsi.ToString("F1", inv));
            if (!string.IsNullOrEmpty(dominantDim))
                sb.Append("  •  Dominant: ").Append(dominantDim);
            sb.AppendLine();
            sb.AppendLine();

            // ── Chronological timeline ─────────────────────────────────────────
            if (day.Count > 0)
            {
                sb.AppendLine("TIMELINE");
                sb.AppendLine(new string('─', 46));
                foreach (var e in day)
                {
                    string timeStr = e.Timestamp.ToString("HH:mm", inv);
                    string psiStr  = "PSI " + e.Psi.ToString("F0", inv);

                    // Emotion icon + label
                    string icon;
                    switch (e.Emotion)
                    {
                        case JournalEmotion.Calm:     icon = "\U0001F600 Calm"; break;
                        case JournalEmotion.Neutral:  icon = "\U0001F610 Neutral"; break;
                        case JournalEmotion.Stressed: icon = "\U0001F62C Stressed"; break;
                        default:
                            icon = string.Equals(e.Kind, "SessionSummary",
                                       StringComparison.OrdinalIgnoreCase)
                                   ? "\U0001F4CB Summary"
                                   : "\U0001F4DD Note";
                            break;
                    }

                    sb.Append(timeStr).Append("  ").Append(icon.PadRight(14));
                    if (!string.IsNullOrWhiteSpace(e.Note))
                        sb.Append("— ").Append(e.Note.Replace("\n", " ").Replace("\r", ""));
                    sb.Append("  [").Append(psiStr).Append(']');
                    sb.AppendLine();
                }
                sb.AppendLine();
            }
            else
            {
                sb.AppendLine("No quick notes or emotion tags recorded for this session.");
                sb.AppendLine();
            }

            // ── Reflection (pre-filled from saved reflection, or blank prompts) ──
            var (refl_well, refl_improve, refl_focus) = LoadReflection(date);
            sb.AppendLine(new string('─', 46));
            sb.AppendLine("REFLECTIONS");
            sb.AppendLine();
            sb.AppendLine("What went well:");
            if (!string.IsNullOrWhiteSpace(refl_well))
                sb.AppendLine(refl_well);
            sb.AppendLine();
            sb.AppendLine("What to improve:");
            if (!string.IsNullOrWhiteSpace(refl_improve))
                sb.AppendLine(refl_improve);
            sb.AppendLine();
            sb.AppendLine("Focus for next session:");
            if (!string.IsNullOrWhiteSpace(refl_focus))
                sb.AppendLine(refl_focus);

            return sb.ToString();
        }

        /// <summary>
        /// Load all day notes as a dictionary keyed by date.Date.
        /// Used by HistoryWindow to show notes for calendar entries.
        /// </summary>
        public static Dictionary<DateTime, string> LoadAllDayNotes()
        {
            var dict = new Dictionary<DateTime, string>();
            try
            {
                lock (_sync)
                {
                    if (!File.Exists(DayNotesPath)) return dict;
                    using (var sr = new StreamReader(DayNotesPath, Encoding.UTF8))
                    {
                        string line;
                        bool   first = true;
                        while ((line = sr.ReadLine()) != null)
                        {
                            if (first) { first = false; continue; }
                            if (string.IsNullOrWhiteSpace(line)) continue;
                            var fields = SplitCsv(line);
                            if (fields.Count < 2) continue;
                            DateTime d;
                            if (DateTime.TryParseExact(fields[0], "yyyy-MM-dd",
                                    CultureInfo.InvariantCulture, DateTimeStyles.None, out d)
                                && !string.IsNullOrEmpty(fields[1]))
                                dict[d.Date] = UnescapeNote(fields[1]);
                        }
                    }
                }
            }
            catch { }
            return dict;
        }

        // =====================================================================
        // Reflection persistence  (what went well / improve / focus)
        // =====================================================================

        public static string ReflectionsPath => Path.Combine(_dataDir, "reflections.csv");

        public static void SaveReflection(DateTime date, string wentWell, string improve, string focus)
        {
            try
            {
                lock (_sync)
                {
                    if (!Directory.Exists(_dataDir)) Directory.CreateDirectory(_dataDir);
                    string key  = date.Date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                    var    rows = new List<string>();
                    bool   found = false;

                    if (File.Exists(ReflectionsPath))
                    {
                        using (var sr = new StreamReader(ReflectionsPath, Encoding.UTF8))
                        {
                            string line;
                            bool   first = true;
                            while ((line = sr.ReadLine()) != null)
                            {
                                if (first) { first = false; continue; }
                                if (string.IsNullOrWhiteSpace(line)) continue;
                                var f = SplitCsv(line);
                                if (f.Count >= 1 && f[0] == key)
                                    found = true;
                                else
                                    rows.Add(line);
                            }
                        }
                    }

                    bool hasContent = !string.IsNullOrWhiteSpace(wentWell)
                                   || !string.IsNullOrWhiteSpace(improve)
                                   || !string.IsNullOrWhiteSpace(focus);
                    if (hasContent)
                        rows.Add(string.Join(",",
                            key,
                            CsvEscape(EscapeNote(wentWell ?? "")),
                            CsvEscape(EscapeNote(improve  ?? "")),
                            CsvEscape(EscapeNote(focus    ?? ""))));

                    using (var sw = new StreamWriter(ReflectionsPath, append: false, encoding: Encoding.UTF8))
                    {
                        sw.WriteLine("date,went_well,improve,focus");
                        foreach (var r in rows) sw.WriteLine(r);
                    }
                }
            }
            catch { }
        }

        public static (string wentWell, string improve, string focus) LoadReflection(DateTime date)
        {
            try
            {
                lock (_sync)
                {
                    if (!File.Exists(ReflectionsPath)) return ("", "", "");
                    string key = date.Date.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
                    using (var sr = new StreamReader(ReflectionsPath, Encoding.UTF8))
                    {
                        string line;
                        bool   first = true;
                        while ((line = sr.ReadLine()) != null)
                        {
                            if (first) { first = false; continue; }
                            if (string.IsNullOrWhiteSpace(line)) continue;
                            var f = SplitCsv(line);
                            if (f.Count >= 4 && f[0] == key)
                                return (UnescapeNote(f[1]), UnescapeNote(f[2]), UnescapeNote(f[3]));
                            if (f.Count == 3 && f[0] == key)
                                return (UnescapeNote(f[1]), UnescapeNote(f[2]), "");
                        }
                    }
                }
            }
            catch { }
            return ("", "", "");
        }

        // =====================================================================
        // CSV helpers
        // =====================================================================

        /// <summary>Flatten newlines to the two-char sequence \n so a record stays on one line.</summary>
        private static string EscapeNote(string s)
        {
            if (string.IsNullOrEmpty(s)) return s;
            return s.Replace("\r\n", "\\n").Replace("\r", "\\n").Replace("\n", "\\n");
        }

        /// <summary>Restore newlines escaped by <see cref="EscapeNote"/>.</summary>
        private static string UnescapeNote(string s)
        {
            if (string.IsNullOrEmpty(s)) return s;
            return s.Replace("\\n", "\n");
        }

        private static string CsvEscape(string s)        {
            if (string.IsNullOrEmpty(s)) return "";
            bool needsQuote = s.IndexOfAny(new[] { ',', '"', '\n', '\r' }) >= 0;
            if (!needsQuote) return s;
            return "\"" + s.Replace("\"", "\"\"") + "\"";
        }

        private static List<string> SplitCsv(string line)
        {
            var fields = new List<string>();
            var sb     = new StringBuilder();
            bool inQuotes = false;

            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];
                if (inQuotes)
                {
                    if (c == '"')
                    {
                        if (i + 1 < line.Length && line[i + 1] == '"') { sb.Append('"'); i++; }
                        else                                             inQuotes = false;
                    }
                    else sb.Append(c);
                }
                else
                {
                    if      (c == ',') { fields.Add(sb.ToString()); sb.Length = 0; }
                    else if (c == '"') inQuotes = true;
                    else               sb.Append(c);
                }
            }
            fields.Add(sb.ToString());
            return fields;
        }
    }
}
