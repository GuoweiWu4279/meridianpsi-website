// HistoryWindow.cs
//
// "My History" analytics dashboard — navigable month calendar, PSI trend
// chart, key performance tiles, and a filterable/expandable session log.
//
// Reads only from SessionHistoryStore (history.xml); never writes.
// Apple dark-mode style, consistent with SessionReportWindow.
//
// Redesign summary (2026-04-15):
//   - Month navigation: ◀ APRIL 2026 ▶ calendar (replaces fixed 5-week view)
//   - Stats tiles and PSI chart are month-scoped (follow the viewed month)
//   - Session log has a zone filter pill-bar (ALL / STABLE / CAUTION / CRITICAL)
//   - Clicking a session log row expands an inline detail panel
//   - "View Today's Full Report →" link navigates to the Session tab
//   - CopySummary() is internal so the Hub can call it from its action bar

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using Microsoft.Win32;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal sealed class HistoryWindow : Window
    {
        // ── Data ──────────────────────────────────────────────────────────────
        private readonly SessionHistoryStore       _store;
        private DateTime                           _viewMonth;    // first day of the currently viewed month
        private List<SessionHistoryEntry>          _monthEntries; // sessions in _viewMonth
        private PsiZone?                           _zoneFilter;   // null = ALL
        private SessionHistoryEntry                _expandedEntry;// currently expanded row (null = none)

        // ── Rebuildable section holders ───────────────────────────────────────
        // Each section is a StackPanel that gets cleared/rebuilt when the view
        // changes without disturbing the overall ScrollViewer scroll position.
        private readonly StackPanel _tilesSection = new StackPanel();
        private readonly StackPanel _chartSection = new StackPanel();
        private readonly StackPanel _calSection   = new StackPanel();
        private readonly StackPanel _listSection  = new StackPanel();

        // Selected calendar date (shows inline detail card below the calendar grid)
        private DateTime? _selectedCalendarDate;

        // ── Chart canvas ref kept for resize-event rebinding ─────────────────
        private Canvas _chartCanvas;

        // ── Event fired by the "View Today's Full Report" link ────────────────
        public event Action            ViewTodayRequested;
        public event Action            ClearHistoryRequested;
        // ── Event fired by the "Edit in Journal →" link in a session expand panel ──
        // Argument: the session date to navigate the Journal page to.
        public event Action<DateTime>  ViewJournalRequested;

        // ── Apple dark-mode palette (matches SessionReportWindow) ─────────────
        private static readonly Brush FgPrimary   = new SolidColorBrush(Color.FromRgb(245, 245, 247));
        private static readonly Brush FgSecondary = new SolidColorBrush(Color.FromRgb(174, 174, 178));
        private static readonly Brush FgHint      = new SolidColorBrush(Color.FromRgb( 99,  99, 102));
        private static readonly Brush FgAccent    = new SolidColorBrush(Color.FromRgb( 10, 132, 255));
        private static readonly Brush BgWindow    = new SolidColorBrush(Color.FromRgb( 28,  28,  30));
        private static readonly Brush BgCard      = new SolidColorBrush(Color.FromRgb( 38,  38,  40));
        private static readonly Brush BgHeader    = new SolidColorBrush(Color.FromRgb( 44,  44,  46));

        static HistoryWindow()
        {
            ((SolidColorBrush)FgPrimary  ).Freeze();
            ((SolidColorBrush)FgSecondary).Freeze();
            ((SolidColorBrush)FgHint     ).Freeze();
            ((SolidColorBrush)FgAccent   ).Freeze();
            ((SolidColorBrush)BgWindow   ).Freeze();
            ((SolidColorBrush)BgCard     ).Freeze();
            ((SolidColorBrush)BgHeader   ).Freeze();
        }

        private static readonly Color ColStable      = Color.FromRgb( 48, 209,  88);
        private static readonly Color ColYellowGreen = Color.FromRgb(163, 213,  72); // 70–84% composure
        private static readonly Color ColCaution     = Color.FromRgb(255, 214,   0);
        private static readonly Color ColCritical    = Color.FromRgb(255,  69,  58);

        // 4-tier composure colour: ≥85 green · 70-84 lime · 50-69 yellow · <50 red
        private Color CompColor(int pct) =>
            pct >= 85 ? ColStable :
            pct >= 70 ? ColYellowGreen :
            pct >= 50 ? ColCaution : ColCritical;

        // =====================================================================
        // Constructor
        // =====================================================================

        public HistoryWindow(SessionHistoryStore store)
        {
            _store = store ?? new SessionHistoryStore();

            // ── Window chrome ─────────────────────────────────────────────────
            WindowStyle        = WindowStyle.None;
            AllowsTransparency = true;
            Background         = Brushes.Transparent;
            ResizeMode         = ResizeMode.CanResizeWithGrip;
            ShowInTaskbar      = true;
            Title              = "PSI My History";
            Width              = 580;
            Height             = 760;
            MinWidth           = 440;
            MinHeight          = 560;
            Left = (SystemParameters.WorkArea.Width  - Width)  / 2;
            Top  = (SystemParameters.WorkArea.Height - Height) / 2;

            // ── Outer rounded card ────────────────────────────────────────────
            var card = new Border
            {
                CornerRadius    = new CornerRadius(14),
                Background      = BgWindow,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(44) });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // ── Header bar ────────────────────────────────────────────────────
            var hdrBorder = new Border { Background = BgHeader };
            hdrBorder.MouseLeftButtonDown += (s, e) => DragMove();

            var hdrGrid = new Grid();
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var titleText = new TextBlock
            {
                Text              = "MY HISTORY",
                Foreground        = FgPrimary,
                FontSize          = 12,
                FontWeight        = FontWeights.SemiBold,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(16, 0, 0, 0),
            };
            Grid.SetColumn(titleText, 0);

            var copyBtn = MakeHeaderButton("⎘");
            copyBtn.ToolTip = "Copy month summary to clipboard";
            copyBtn.Click  += (s, e) => CopySummary();
            Grid.SetColumn(copyBtn, 1);

            var exportBtn = MakeHeaderButton("↓");
            exportBtn.ToolTip = "Export all history to CSV";
            exportBtn.Click   += (s, e) => ExportCsv();
            Grid.SetColumn(exportBtn, 2);

            var closeBtn = MakeHeaderButton("✕");
            closeBtn.Click += (s, e) => Close();
            Grid.SetColumn(closeBtn, 3);

            hdrGrid.Children.Add(titleText);
            hdrGrid.Children.Add(copyBtn);
            hdrGrid.Children.Add(exportBtn);
            hdrGrid.Children.Add(closeBtn);
            hdrBorder.Child = hdrGrid;
            Grid.SetRow(hdrBorder, 0);

            // ── Scrollable body ───────────────────────────────────────────────
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };

            var body = new StackPanel { Margin = new Thickness(14, 12, 14, 18) };

            // Wire section holders into the body (gaps are permanent spacers)
            body.Children.Add(_tilesSection);
            body.Children.Add(Gap(16));
            body.Children.Add(_chartSection);
            body.Children.Add(Gap(16));
            body.Children.Add(_calSection);
            body.Children.Add(Gap(16));
            body.Children.Add(_listSection);

            scroll.Content = body;
            Grid.SetRow(scroll, 1);

            root.Children.Add(hdrBorder);
            root.Children.Add(scroll);
            card.Child = root;
            Content    = card;

            // ── Initial month: current calendar month ─────────────────────────
            SetViewMonth(new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1));
        }

        // =====================================================================
        // View-state management
        // =====================================================================

        private void SetViewMonth(DateTime month)
        {
            _viewMonth = new DateTime(month.Year, month.Month, 1);
            _monthEntries = _store.Sessions
                .Where(s => s.Date.Year == _viewMonth.Year && s.Date.Month == _viewMonth.Month)
                .OrderBy(s => s.Date)
                .ToList();
            _expandedEntry         = null;
            _selectedCalendarDate  = null;
            RebuildAll();
        }

        private void RebuildAll()
        {
            _tilesSection.Children.Clear();
            BuildStatTiles(_tilesSection);

            _chartSection.Children.Clear();
            BuildPsiTrendChart(_chartSection);

            _calSection.Children.Clear();
            BuildCalendarSection(_calSection);

            _listSection.Children.Clear();
            BuildSessionList(_listSection);
        }

        private void RebuildCalSection()
        {
            _calSection.Children.Clear();
            BuildCalendarSection(_calSection);
        }

        // Only rebuilds the session list (filter change or row expand/collapse).
        // Preserves scroll position since the upper sections are untouched.
        private void RebuildListOnly()
        {
            _listSection.Children.Clear();
            BuildSessionList(_listSection);
        }

        // =====================================================================
        // Stat tiles  (month-scoped)
        // =====================================================================

        private void BuildStatTiles(Panel parent)
        {
            var grid = new Grid();
            for (int i = 0; i < 4; i++)
                grid.ColumnDefinitions.Add(
                    new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            string monthLabel = _viewMonth.ToString("MMM yyyy");
            var    tradingDays = _monthEntries.Where(e => e.TotalTrades > 0).ToList();

            // STREAK — always global; a streak today is independent of view month
            int   streak    = _store.CurrentStableStreak();
            Color streakCol = streak >= 3 ? ColStable
                            : streak >= 1 ? ColCaution
                            : Color.FromRgb(120, 120, 128);
            AddTile(grid, 0, "STREAK",
                    streak > 0 ? $"{streak}" : "0",
                    streakCol,
                    streak == 1 ? "day" : "days");

            // STABLE DAYS — month percentage (sessions with ComposurePct >= ComposureStableThreshold)
            double? stabPct = _monthEntries.Count > 0
                ? 100.0 * _monthEntries.Count(e => e.ComposurePct >= SessionData.ComposureStableThreshold) / _monthEntries.Count
                : (double?)null;
            Color stabCol = !stabPct.HasValue     ? Color.FromRgb(120, 120, 128)
                          : stabPct.Value >= 60   ? ColStable
                          : stabPct.Value >= 40   ? ColCaution : ColCritical;
            AddTile(grid, 1, "STABLE DAYS",
                    stabPct.HasValue ? $"{stabPct.Value:0}%" : "–",
                    stabCol, monthLabel);

            // COMPOSURE — month average (trading days only)
            string compStr = tradingDays.Count > 0
                ? $"{(int)tradingDays.Average(e => e.ComposurePct)}%"
                : "–";
            Color compCol = tradingDays.Count > 0
                ? CompColor((int)tradingDays.Average(e => e.ComposurePct))
                : Color.FromRgb(120, 120, 128);
            AddTile(grid, 2, "COMPOSURE", compStr, compCol, monthLabel);

            // AVG P&L — month average
            double? avgPnl = tradingDays.Count > 0
                ? tradingDays.Average(e => e.TotalPnl)
                : (double?)null;
            Color pnlCol = !avgPnl.HasValue ? Color.FromRgb(120, 120, 128)
                         : avgPnl.Value >= 0 ? ColStable : ColCritical;
            string pnlStr = !avgPnl.HasValue ? "–"
                : (avgPnl.Value >= 0 ? "+" : "-") + "$" + Math.Abs(avgPnl.Value).ToString("0");
            AddTile(grid, 3, "AVG P&L", pnlStr, pnlCol, monthLabel);

            parent.Children.Add(grid);
        }

        private static void AddTile(Grid grid, int col,
                                    string label, string value, Color valueColor, string sub)
        {
            var card = new Border
            {
                Background   = new SolidColorBrush(Color.FromRgb(38, 38, 40)),
                CornerRadius = new CornerRadius(10),
                Margin       = new Thickness(col == 0 ? 0 : 4, 0, 0, 0),
                Padding      = new Thickness(8, 10, 8, 10),
            };
            var sp = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            sp.Children.Add(new TextBlock
            {
                Text                = label,
                Foreground          = new SolidColorBrush(Color.FromRgb(99, 99, 102)),
                FontSize            = 8.5,
                FontWeight          = FontWeights.SemiBold,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 4),
            });
            sp.Children.Add(new TextBlock
            {
                Text                = value,
                Foreground          = new SolidColorBrush(valueColor),
                FontSize            = 20,
                FontWeight          = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center,
            });
            sp.Children.Add(new TextBlock
            {
                Text                = sub,
                Foreground          = new SolidColorBrush(Color.FromRgb(99, 99, 102)),
                FontSize            = 8.5,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 2, 0, 0),
            });
            card.Child = sp;
            Grid.SetColumn(card, col);
            grid.Children.Add(card);
        }

        // =====================================================================
        // PSI trend chart  (month-scoped)
        // =====================================================================

        private void BuildPsiTrendChart(Panel parent)
        {
            parent.Children.Add(SectionLabel("PSI TREND  ·  FINAL SCORE PER SESSION"));

            var card = new Border
            {
                Background   = BgCard,
                CornerRadius = new CornerRadius(10),
                Padding      = new Thickness(12, 10, 12, 6),
            };

            if (_monthEntries.Count == 0)
            {
                card.Child = Placeholder("No sessions recorded for " + _viewMonth.ToString("MMMM yyyy") + ".");
                parent.Children.Add(card);
                return;
            }

            var outer = new Grid();
            outer.RowDefinitions.Add(new RowDefinition { Height = new GridLength(150) });
            outer.RowDefinitions.Add(new RowDefinition { Height = new GridLength(18) });

            // Capture local canvas ref so the closure doesn't use the field after it changes
            var canvas = new Canvas { Height = 150, ClipToBounds = true };
            _chartCanvas = canvas;
            canvas.SizeChanged += (s, e) => DrawPsiChart(canvas, e.NewSize.Width);
            Grid.SetRow(canvas, 0);

            var xLabels = new Canvas { Height = 18 };
            canvas.Tag = xLabels;
            Grid.SetRow(xLabels, 1);

            outer.Children.Add(canvas);
            outer.Children.Add(xLabels);
            card.Child = outer;
            parent.Children.Add(card);
        }

        private void DrawPsiChart(Canvas canvas, double w)
        {
            canvas.Children.Clear();

            double h = canvas.ActualHeight;
            if (w < 10 || h < 10) return;

            var entries = _monthEntries; // local snapshot
            if (entries.Count == 0) return;

            const double padTop = 6, padBot = 6;
            double plotH = h - padTop - padBot;
            double yOf(double psi) => padTop + (1.0 - psi / 100.0) * plotH;

            const double padLeft = 22, padRight = 4;
            double plotW = w - padLeft - padRight;
            int    n     = entries.Count;
            double xOf(int i) => padLeft + (n == 1 ? plotW / 2.0 : i * plotW / (n - 1.0));

            // ── Zone background bands ─────────────────────────────────────────
            double zCrit = SessionData.ZoneCriticalThreshold;
            double zStab = SessionData.ZoneStableThreshold;
            canvas.Children.Add(MakeChartBand(padLeft, plotW, yOf(zCrit), yOf(100), Color.FromArgb(15, 255, 69, 58)));
            canvas.Children.Add(MakeChartBand(padLeft, plotW, yOf(zStab), yOf(zCrit), Color.FromArgb(15, 255, 214, 0)));

            // ── Threshold grid lines ──────────────────────────────────────────
            foreach (double psi in new[] { zCrit, zStab })
            {
                double y = yOf(psi);
                canvas.Children.Add(new Line
                {
                    X1 = padLeft, Y1 = y, X2 = padLeft + plotW, Y2 = y,
                    Stroke          = new SolidColorBrush(Color.FromArgb(35, 255, 255, 255)),
                    StrokeThickness = 1,
                    StrokeDashArray = new DoubleCollection(new[] { 3.0, 4.0 }),
                });
                var yLbl = new TextBlock
                {
                    Text       = ((int)psi).ToString(),
                    Foreground = new SolidColorBrush(Color.FromRgb(99, 99, 102)),
                    FontSize   = 9,
                };
                Canvas.SetLeft(yLbl, 0);
                Canvas.SetTop(yLbl, y - 6);
                canvas.Children.Add(yLbl);
            }

            // ── Points ───────────────────────────────────────────────────────
            var pts = new Point[n];
            for (int i = 0; i < n; i++)
                pts[i] = new Point(xOf(i), yOf(entries[i].FinalPsi));

            // ── Filled gradient area ──────────────────────────────────────────
            var areaPts = new PointCollection(n + 2);
            foreach (var p in pts) areaPts.Add(p);
            areaPts.Add(new Point(pts[n - 1].X, h));
            areaPts.Add(new Point(pts[0].X, h));
            canvas.Children.Add(new Polygon
            {
                Points = areaPts,
                Fill   = new LinearGradientBrush(
                    Color.FromArgb(55, 10, 132, 255),
                    Color.FromArgb( 0, 10, 132, 255),
                    new Point(0, 0), new Point(0, 1)),
            });

            // ── Polyline ─────────────────────────────────────────────────────
            canvas.Children.Add(new Polyline
            {
                Points          = new PointCollection(pts),
                Stroke          = FgAccent,
                StrokeThickness = 2,
                StrokeLineJoin  = PenLineJoin.Round,
            });

            // ── Dots with tooltips ────────────────────────────────────────────
            for (int i = 0; i < n; i++)
            {
                var e   = entries[i];
                var dot = new Ellipse
                {
                    Width  = 7, Height = 7,
                    Fill   = new SolidColorBrush(ZoneColor(e.FinalZone)),
                    Stroke = BgCard, StrokeThickness = 1.5,
                    ToolTip = BuildDotTooltip(e),
                };
                Canvas.SetLeft(dot, pts[i].X - 3.5);
                Canvas.SetTop(dot,  pts[i].Y - 3.5);
                canvas.Children.Add(dot);
            }

            // ── X-axis date labels ────────────────────────────────────────────
            if (!(canvas.Tag is Canvas xCanvas)) return;
            xCanvas.Children.Clear();
            int step = Math.Max(1, (int)Math.Ceiling(n / 8.0));
            for (int i = 0; i < n; i += step)
            {
                var lbl = new TextBlock
                {
                    Text       = entries[i].Date.Day.ToString(),
                    Foreground = new SolidColorBrush(Color.FromRgb(99, 99, 102)),
                    FontSize   = 9,
                };
                Canvas.SetLeft(lbl, xOf(i) - 6);
                Canvas.SetTop(lbl, 1);
                xCanvas.Children.Add(lbl);
            }
        }

        private static Rectangle MakeChartBand(double left, double width, double top, double bottom, Color fill)
        {
            var r = new Rectangle
            {
                Width  = width,
                Height = Math.Max(0, bottom - top),
                Fill   = new SolidColorBrush(fill),
            };
            Canvas.SetLeft(r, left);
            Canvas.SetTop(r, top);
            return r;
        }

        private static string BuildDotTooltip(SessionHistoryEntry e)
        {
            string pnl = (e.TotalPnl >= 0 ? "+" : "") + "$" + Math.Abs(e.TotalPnl).ToString("0");
            return $"{e.Date:MMM d, yyyy}\n" +
                   $"Final PSI: {e.FinalPsi:0}  ({e.FinalZone})\n" +
                   $"Trades: {e.TotalTrades}  Win%: {e.WinPct:0}%\n" +
                   $"P&L: {pnl}  COMP: {e.ComposurePct}%";
        }

        // =====================================================================
        // Calendar heatmap — navigable month view
        // =====================================================================

        private void BuildCalendarSection(Panel parent)
        {
            // ── Navigation header: ◀  APRIL 2026  ▶ ─────────────────────────
            var navRow = new Grid { Margin = new Thickness(2, 0, 2, 8) };
            navRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            navRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            navRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            // Determine navigation limits
            // Allow going back up to 5 years (matches MaxEntries = 1825).
            // Not restricted to months that have data — empty months are fine.
            DateTime minMonth    = new DateTime(DateTime.Today.AddYears(-5).Year,
                                               DateTime.Today.AddYears(-5).Month, 1);
            DateTime currentMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            bool canGoPrev = _viewMonth > minMonth;
            bool canGoNext = _viewMonth < currentMonth;

            var prevBtn = MakeNavArrowBtn("◀", canGoPrev);
            prevBtn.MouseLeftButtonDown += (s, e) =>
            {
                if (!canGoPrev) return;
                e.Handled = true;
                SetViewMonth(_viewMonth.AddMonths(-1));
            };
            Grid.SetColumn(prevBtn, 0);

            var monthLbl = new TextBlock
            {
                Text                = _viewMonth.ToString("MMMM yyyy").ToUpper(),
                Foreground          = FgPrimary,
                FontSize            = 11,
                FontWeight          = FontWeights.SemiBold,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
            };
            Grid.SetColumn(monthLbl, 1);

            var nextBtn = MakeNavArrowBtn("▶", canGoNext);
            nextBtn.MouseLeftButtonDown += (s, e) =>
            {
                if (!canGoNext) return;
                e.Handled = true;
                SetViewMonth(_viewMonth.AddMonths(1));
            };
            Grid.SetColumn(nextBtn, 2);

            navRow.Children.Add(prevBtn);
            navRow.Children.Add(monthLbl);
            navRow.Children.Add(nextBtn);
            parent.Children.Add(navRow);

            // ── Calendar card ─────────────────────────────────────────────────
            var card = new Border
            {
                Background   = BgCard,
                CornerRadius = new CornerRadius(10),
                Padding      = new Thickness(10, 8, 10, 8),
            };

            // Build lookup: date → entry
            var byDate = _store.Sessions
                .Where(s => s.Date.Year == _viewMonth.Year && s.Date.Month == _viewMonth.Month)
                .ToDictionary(e => e.Date.Date);

            int daysInMonth = DateTime.DaysInMonth(_viewMonth.Year, _viewMonth.Month);
            // Day offset: how many columns the 1st falls from Monday (Mon=0…Sun=6)
            int startOffset = ((int)_viewMonth.DayOfWeek + 6) % 7;
            int totalCells  = startOffset + daysInMonth;
            int rows        = (int)Math.Ceiling(totalCells / 7.0);

            var calGrid = new Grid();
            for (int c = 0; c < 7; c++)
                calGrid.ColumnDefinitions.Add(
                    new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            calGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto }); // header
            for (int r = 0; r < rows; r++)
                calGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(32) });

            // Day-name headers
            string[] dayNames = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun" };
            for (int c = 0; c < 7; c++)
            {
                var lbl = new TextBlock
                {
                    Text                = dayNames[c],
                    Foreground          = FgHint,
                    FontSize            = 9,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    Margin              = new Thickness(0, 0, 0, 4),
                };
                Grid.SetRow(lbl, 0);
                Grid.SetColumn(lbl, c);
                calGrid.Children.Add(lbl);
            }

            DateTime today = DateTime.Today;

            for (int cell = 0; cell < rows * 7; cell++)
            {
                int row = cell / 7 + 1;
                int col = cell % 7;
                int dayNum = cell - startOffset + 1; // 1-based day of month

                // Cells before/after the month: empty placeholder
                if (dayNum < 1 || dayNum > daysInMonth)
                {
                    var empty = new Border
                    {
                        Background = new SolidColorBrush(Color.FromArgb(8, 255, 255, 255)),
                        CornerRadius = new CornerRadius(4),
                        Margin     = new Thickness(2),
                    };
                    Grid.SetRow(empty, row);
                    Grid.SetColumn(empty, col);
                    calGrid.Children.Add(empty);
                    continue;
                }

                var cellDate = new DateTime(_viewMonth.Year, _viewMonth.Month, dayNum);
                bool isFuture = cellDate > today;

                Color  cellColor;
                string tooltip;

                if (isFuture)
                {
                    cellColor = Color.FromArgb(8, 255, 255, 255);
                    tooltip   = null;
                }
                else if (!byDate.TryGetValue(cellDate.Date, out SessionHistoryEntry entry)
                         || entry.TotalTrades == 0)
                {
                    bool isWeekend = cellDate.DayOfWeek == DayOfWeek.Saturday ||
                                    cellDate.DayOfWeek == DayOfWeek.Sunday;
                    byte alpha = isWeekend ? (byte)12 : (byte)30;
                    cellColor = Color.FromArgb(alpha, 255, 255, 255);
                    tooltip   = entry == null
                        ? $"{cellDate:MMM d}  —  No data recorded"
                        : $"{cellDate:MMM d}  —  Monitored (no trades)";
                }
                else
                {
                    Color zc = ZoneColor(entry.FinalZone);
                    cellColor = Color.FromArgb(185, zc.R, zc.G, zc.B);
                    string pnl = (entry.TotalPnl >= 0 ? "+" : "-") + "$" +
                                 Math.Abs(entry.TotalPnl).ToString("0");
                    tooltip = $"{cellDate:ddd MMM d}\n" +
                              $"Final PSI: {entry.FinalPsi:0}  ({entry.FinalZone})\n" +
                              $"Trades: {entry.TotalTrades}  P&L: {pnl}\n" +
                              $"COMP: {entry.ComposurePct}%  Win%: {entry.WinPct:0}%";
                }

                bool isToday = cellDate.Date == today.Date;

                var cellBorder = new Border
                {
                    Background      = new SolidColorBrush(cellColor),
                    CornerRadius    = new CornerRadius(4),
                    Margin          = new Thickness(2),
                    BorderBrush     = isToday
                        ? new SolidColorBrush(Color.FromArgb(200, 10, 132, 255))
                        : Brushes.Transparent,
                    BorderThickness = new Thickness(isToday ? 1.5 : 0),
                };
                if (tooltip != null) cellBorder.ToolTip = tooltip;
                cellBorder.Child = new TextBlock
                {
                    Text                = dayNum.ToString(),
                    Foreground          = new SolidColorBrush(
                        isFuture
                            ? Color.FromArgb(40, 245, 245, 247)
                            : Color.FromArgb(140, 245, 245, 247)),
                    FontSize            = 9,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                };

                // Cells with a recorded session can be clicked to show an inline
                // detail card directly below the calendar grid.
                if (!isFuture && byDate.TryGetValue(cellDate.Date, out SessionHistoryEntry clickEntry)
                              && clickEntry.TotalTrades > 0)
                {
                    bool isSelected = _selectedCalendarDate.HasValue &&
                                      _selectedCalendarDate.Value == cellDate.Date;
                    // Highlight selected cell with stronger border
                    if (isSelected)
                    {
                        cellBorder.BorderBrush     = new SolidColorBrush(Color.FromArgb(220, 245, 245, 247));
                        cellBorder.BorderThickness = new Thickness(1.5);
                    }

                    cellBorder.Cursor = Cursors.Hand;
                    var ce = clickEntry;
                    var cd = cellDate.Date;
                    cellBorder.MouseEnter += (_, __) =>
                    {
                        if (!isSelected)
                            cellBorder.BorderBrush = new SolidColorBrush(Color.FromArgb(140, 245, 245, 247));
                    };
                    cellBorder.MouseLeave += (_, __) =>
                    {
                        if (!isSelected)
                            cellBorder.BorderBrush = isToday
                                ? new SolidColorBrush(Color.FromArgb(200, 10, 132, 255))
                                : Brushes.Transparent;
                    };
                    cellBorder.MouseLeftButtonDown += (_, ev) =>
                    {
                        ev.Handled = true;
                        _selectedCalendarDate = (_selectedCalendarDate.HasValue &&
                                                  _selectedCalendarDate.Value == cd)
                            ? (DateTime?)null
                            : cd;
                        RebuildCalSection();
                    };
                }
                Grid.SetRow(cellBorder, row);
                Grid.SetColumn(cellBorder, col);
                calGrid.Children.Add(cellBorder);
            }

            card.Child = calGrid;
            parent.Children.Add(card);

            // ── Inline detail card for the selected date ──────────────────────
            if (_selectedCalendarDate.HasValue &&
                byDate.TryGetValue(_selectedCalendarDate.Value, out SessionHistoryEntry selEntry) &&
                selEntry.TotalTrades > 0)
            {
                parent.Children.Add(Gap(4));
                parent.Children.Add(BuildExpandPanel(selEntry));
            }
        }

        private static Border MakeNavArrowBtn(string glyph, bool enabled)
        {
            var lbl = new TextBlock
            {
                Text                = glyph,
                FontSize            = 13,
                Foreground          = enabled
                    ? FgSecondary
                    : new SolidColorBrush(Color.FromRgb(60, 60, 65)),
                VerticalAlignment   = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            var btn = new Border
            {
                Width   = 28,
                Height  = 24,
                Background = Brushes.Transparent,
                Cursor  = enabled ? Cursors.Hand : Cursors.Arrow,
                Child   = lbl,
                VerticalAlignment = VerticalAlignment.Center,
            };
            if (enabled)
            {
                btn.MouseEnter += (_, __) => lbl.Foreground = FgPrimary;
                btn.MouseLeave += (_, __) => lbl.Foreground = FgSecondary;
            }
            return btn;
        }

        // =====================================================================
        // Session log — filter bar + expandable rows
        // =====================================================================

        private void BuildSessionList(Panel parent)
        {
            parent.Children.Add(SectionLabel("SESSION LOG"));

            // ── Filter pill bar ───────────────────────────────────────────────
            parent.Children.Add(BuildFilterBar());
            parent.Children.Add(Gap(8));

            // Apply zone filter
            var filtered = _zoneFilter.HasValue
                ? _monthEntries.Where(e => e.FinalZone == _zoneFilter.Value).ToList()
                : _monthEntries.ToList();

            var card = new Border
            {
                Background   = BgCard,
                CornerRadius = new CornerRadius(10),
                Padding      = new Thickness(0, 4, 0, 4),
            };

            if (filtered.Count == 0)
            {
                card.Child = new Border
                {
                    Padding = new Thickness(12, 10, 12, 10),
                    Child   = Placeholder(
                        _monthEntries.Count == 0
                            ? "No sessions recorded for " + _viewMonth.ToString("MMMM yyyy") + "."
                            : "No " + (_zoneFilter.HasValue ? _zoneFilter.Value.ToString() : "") + " sessions this month."),
                };
                parent.Children.Add(card);
            }
            else
            {
                var listStack = new StackPanel();
                listStack.Children.Add(SessionTableHeader());

                bool alt = false;
                foreach (var e in filtered.OrderByDescending(x => x.Date))
                {
                    bool isExpanded = (_expandedEntry != null &&
                                       _expandedEntry.Date.Date == e.Date.Date);
                    listStack.Children.Add(BuildSessionRow(e, alt, isExpanded));
                    alt = !alt;
                }

                card.Child = listStack;
                parent.Children.Add(card);
            }

            // ── "View Today's Full Report →" link ─────────────────────────────
            bool isCurrentMonth = _viewMonth.Year  == DateTime.Today.Year &&
                                  _viewMonth.Month == DateTime.Today.Month;
            if (isCurrentMonth && ViewTodayRequested != null)
            {
                var link = new Border
                {
                    Padding = new Thickness(2, 12, 2, 0),
                    Cursor  = Cursors.Hand,
                };
                var linkTb = new TextBlock
                {
                    Text                = "View Today's Full Report  →",
                    Foreground          = FgAccent,
                    FontSize            = 11,
                    FontWeight          = FontWeights.SemiBold,
                    HorizontalAlignment = HorizontalAlignment.Right,
                };
                link.Child = linkTb;
                link.MouseEnter += (_, __) => linkTb.TextDecorations = TextDecorations.Underline;
                link.MouseLeave += (_, __) => linkTb.TextDecorations = null;
                link.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    ViewTodayRequested?.Invoke();
                };
                parent.Children.Add(link);
            }

            parent.Children.Add(Gap(16));
        }

        private UIElement BuildFilterBar()
        {
            var sp = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(2, 0, 2, 0),
            };

            sp.Children.Add(MakeFilterPill("ALL",      null));
            sp.Children.Add(MakeFilterPill("STABLE",   PsiZone.Stable));
            sp.Children.Add(MakeFilterPill("CAUTION",  PsiZone.Caution));
            sp.Children.Add(MakeFilterPill("CRITICAL", PsiZone.Critical));

            return sp;
        }

        private Border MakeFilterPill(string label, PsiZone? zone)
        {
            bool isActive = (zone == null && !_zoneFilter.HasValue) ||
                            (zone.HasValue && _zoneFilter == zone);

            Color dotColor = zone == null     ? Color.FromRgb(174, 174, 178)
                           : zone == PsiZone.Stable   ? ColStable
                           : zone == PsiZone.Caution  ? ColCaution : ColCritical;

            var content = new StackPanel
            {
                Orientation       = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
            };

            if (zone.HasValue)
            {
                content.Children.Add(new Ellipse
                {
                    Width   = 6,
                    Height  = 6,
                    Fill    = new SolidColorBrush(dotColor),
                    Margin  = new Thickness(0, 0, 5, 0),
                    VerticalAlignment = VerticalAlignment.Center,
                });
            }

            content.Children.Add(new TextBlock
            {
                Text                = label,
                FontSize            = 10,
                FontWeight          = isActive ? FontWeights.SemiBold : FontWeights.Normal,
                Foreground          = isActive ? FgPrimary : FgSecondary,
                VerticalAlignment   = VerticalAlignment.Center,
            });

            var pill = new Border
            {
                Background      = isActive
                    ? new SolidColorBrush(Color.FromArgb(40, 255, 255, 255))
                    : Brushes.Transparent,
                BorderBrush     = isActive
                    ? new SolidColorBrush(Color.FromArgb(60, 255, 255, 255))
                    : Brushes.Transparent,
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(12),
                Padding         = new Thickness(10, 4, 10, 4),
                Margin          = new Thickness(0, 0, 6, 0),
                Cursor          = Cursors.Hand,
                Child           = content,
            };

            pill.MouseEnter += (_, __) =>
            {
                if (!isActive)
                    pill.Background = new SolidColorBrush(Color.FromArgb(20, 255, 255, 255));
            };
            pill.MouseLeave += (_, __) =>
            {
                if (!isActive)
                    pill.Background = Brushes.Transparent;
            };
            pill.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                _zoneFilter = zone;
                RebuildListOnly();
            };

            return pill;
        }

        private static UIElement SessionTableHeader()
        {
            var g = new Grid { Margin = new Thickness(12, 2, 12, 5) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(46) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(66) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(36) });

            string[] heads = { "DATE", "PSI", "TRADES", "P&L", "COMP" };
            for (int i = 0; i < heads.Length; i++)
            {
                var tb = new TextBlock
                {
                    Text                = heads[i],
                    Foreground          = FgHint,
                    FontSize            = 9,
                    FontWeight          = FontWeights.SemiBold,
                    VerticalAlignment   = VerticalAlignment.Center,
                    HorizontalAlignment = i > 1 ? HorizontalAlignment.Right : HorizontalAlignment.Left,
                };
                Grid.SetColumn(tb, i);
                g.Children.Add(tb);
            }
            return g;
        }

        private UIElement BuildSessionRow(SessionHistoryEntry e, bool alt, bool expanded)
        {
            var wrapper = new StackPanel();

            // ── Row ───────────────────────────────────────────────────────────
            var rowBorder = new Border
            {
                Background = new SolidColorBrush(alt
                    ? Color.FromArgb(12, 255, 255, 255)
                    : Color.FromArgb(0, 255, 255, 255)),
                Padding    = new Thickness(12, 6, 12, 6),
                Cursor     = Cursors.Hand,
            };
            rowBorder.MouseEnter += (_, __) =>
                rowBorder.Background = new SolidColorBrush(Color.FromArgb(22, 255, 255, 255));
            rowBorder.MouseLeave += (_, __) =>
                rowBorder.Background = new SolidColorBrush(alt
                    ? Color.FromArgb(12, 255, 255, 255)
                    : Color.FromArgb(0, 255, 255, 255));
            rowBorder.MouseLeftButtonDown += (_, ev) =>
            {
                ev.Handled = true;
                _expandedEntry = (_expandedEntry != null &&
                                  _expandedEntry.Date.Date == e.Date.Date)
                    ? null
                    : e;
                RebuildListOnly();
            };

            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(60) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(46) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(66) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(36) });

            // Date
            AddCell(g, 0, new TextBlock
            {
                Text = e.Date.ToString("MMM d"),
                Foreground = FgSecondary, FontSize = 11,
                VerticalAlignment = VerticalAlignment.Center,
            });

            // PSI mini-bar
            var psiWrap = new Grid();
            psiWrap.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(28) });
            psiWrap.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var psiNum = new TextBlock
            {
                Text              = e.FinalPsi.ToString("0"),
                Foreground        = new SolidColorBrush(ZoneColor(e.FinalZone)),
                FontSize          = 11, FontWeight = FontWeights.SemiBold,
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(psiNum, 0);
            psiWrap.Children.Add(psiNum);

            var barGrid = new Grid { Height = 4, VerticalAlignment = VerticalAlignment.Center };
            double fill  = Math.Max(0, Math.Min(100, e.FinalPsi));
            double empty = 100.0 - fill;
            barGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(fill,  GridUnitType.Star) });
            barGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(empty, GridUnitType.Star) });
            var fillRect  = new Border { Background = new SolidColorBrush(ZoneColor(e.FinalZone)), CornerRadius = new CornerRadius(2) };
            var emptyRect = new Border { Background = new SolidColorBrush(Color.FromArgb(35, 255, 255, 255)), CornerRadius = new CornerRadius(2) };
            Grid.SetColumn(fillRect,  0); barGrid.Children.Add(fillRect);
            Grid.SetColumn(emptyRect, 1); barGrid.Children.Add(emptyRect);
            Grid.SetColumn(barGrid, 1);
            psiWrap.Children.Add(barGrid);
            AddCell(g, 1, psiWrap);

            // Trades
            AddCell(g, 2, new TextBlock
            {
                Text = e.TotalTrades.ToString(),
                Foreground = FgSecondary, FontSize = 11,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment   = VerticalAlignment.Center,
            });

            // P&L
            bool pos = e.TotalPnl >= 0;
            AddCell(g, 3, new TextBlock
            {
                Text       = (pos ? "+" : "-") + "$" + Math.Abs(e.TotalPnl).ToString("0"),
                Foreground = new SolidColorBrush(pos ? ColStable : ColCritical),
                FontSize   = 11, FontWeight = FontWeights.SemiBold,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment   = VerticalAlignment.Center,
            });

            // Composure
            Color compC = CompColor(e.ComposurePct);
            AddCell(g, 4, new TextBlock
            {
                Text       = e.ComposurePct + "%",
                Foreground = new SolidColorBrush(compC),
                FontSize   = 11,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment   = VerticalAlignment.Center,
            });

            rowBorder.Child = g;
            wrapper.Children.Add(rowBorder);

            // ── Inline expand panel ───────────────────────────────────────────
            if (expanded)
                wrapper.Children.Add(BuildExpandPanel(e));

            return wrapper;
        }

        private UIElement BuildExpandPanel(SessionHistoryEntry e)
        {
            var panel = new Border
            {
                Background      = new SolidColorBrush(Color.FromArgb(18, 10, 132, 255)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 10, 132, 255)),
                BorderThickness = new Thickness(0, 0, 0, 1),
                Padding         = new Thickness(12, 10, 12, 12),
            };

            var stack = new StackPanel();

            // Date headline
            stack.Children.Add(new TextBlock
            {
                Text       = e.Date.ToString("dddd, MMMM d, yyyy"),
                FontSize   = 11,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgPrimary,
                Margin     = new Thickness(0, 0, 0, 8),
            });

            // PSI arc row
            stack.Children.Add(DetailRow(
                "PSI",
                $"{e.StartPsi:0} → {e.FinalPsi:0}",
                $"  low {e.MinPsi:0} · avg {e.AvgPsi:0}"));

            // Time-in-zone proportional bar + text
            double total = Math.Max(1.0, e.TimeInStableMin + e.TimeInCautionMin + e.TimeInCriticalMin);
            stack.Children.Add(Gap(6));
            stack.Children.Add(BuildZoneTimeBar(e.TimeInStableMin, e.TimeInCautionMin, e.TimeInCriticalMin, total));

            // Composure
            stack.Children.Add(Gap(6));
            Color compC = CompColor(e.ComposurePct);
            stack.Children.Add(DetailRow("COMPOSURE",
                $"{e.ComposurePct}%", "", compC));

            // Top signal dimension
            if (e.TopDimensionIndex >= 0)
            {
                stack.Children.Add(Gap(4));
                stack.Children.Add(DetailRow("SIGNAL", e.TopDimensionLabel, ""));
            }

            // Duration / trades
            stack.Children.Add(Gap(4));
            string dur = e.DurationMinutes > 0 ? $"{e.DurationMinutes} min · " : "";
            stack.Children.Add(DetailRow("SESSION",
                $"{dur}{e.TotalTrades} trades",
                e.TotalTrades > 0 ? $"  Win {e.WinPct:0}%" : ""));

            // Naked position warning
            if (e.NakedPositionDetections > 0)
            {
                stack.Children.Add(Gap(6));
                stack.Children.Add(new TextBlock
                {
                    Text         = $"⚠  Naked position detected {e.NakedPositionDetections}×",
                    FontSize     = 10,
                    Foreground   = new SolidColorBrush(ColCritical),
                    TextWrapping = TextWrapping.Wrap,
                });
            }

            // "View Full Report" — only visible when a Tier-2 detail file exists
            if (SessionDetailStore.Exists(e.Date))
            {
                stack.Children.Add(Gap(10));

                var btnBorder = new Border
                {
                    Background      = new SolidColorBrush(Color.FromArgb(40, 10, 132, 255)),
                    BorderBrush     = new SolidColorBrush(Color.FromArgb(100, 10, 132, 255)),
                    BorderThickness = new Thickness(1),
                    CornerRadius    = new CornerRadius(4),
                    Padding         = new Thickness(10, 5, 10, 5),
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Cursor          = Cursors.Hand,
                };

                btnBorder.Child = new TextBlock
                {
                    Text       = "View Full Report →",
                    FontSize   = 11,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = new SolidColorBrush(Color.FromRgb(100, 180, 255)),
                };

                var capturedEntry = e;
                btnBorder.MouseLeftButtonDown += (_, ev) =>
                {
                    ev.Handled = true;
                    var detail = SessionDetailStore.Load(capturedEntry.Date);
                    if (detail == null) return;
                    var sd = SessionData.FromArchive(capturedEntry, detail);
                    sd.Flush(sd.Date);
                    new SessionReportWindow(sd).Show();
                };

                btnBorder.MouseEnter += (_, __) =>
                    btnBorder.Background = new SolidColorBrush(Color.FromArgb(70, 10, 132, 255));
                btnBorder.MouseLeave += (_, __) =>
                    btnBorder.Background = new SolidColorBrush(Color.FromArgb(40, 10, 132, 255));

                stack.Children.Add(btnBorder);
            }

            // ── Journal section ───────────────────────────────────────────────
            // Day note (full text) + quick-note / emotion-tag entries for this date.
            try
            {
                string dayNote = JournalStore.LoadDayNote(e.Date);
                var    entries = JournalStore.Recent(limit: 50, sessionDate: e.Date);

                bool hasNote    = !string.IsNullOrWhiteSpace(dayNote);
                bool hasEntries = entries.Count > 0;

                if (hasNote || hasEntries)
                {
                    stack.Children.Add(new Border
                    {
                        Height     = 1,
                        Background = new SolidColorBrush(Color.FromArgb(25, 255, 255, 255)),
                        Margin     = new Thickness(0, 10, 0, 10),
                    });
                    stack.Children.Add(new TextBlock
                    {
                        Text       = "JOURNAL",
                        FontSize   = 9,
                        FontFamily = new FontFamily("Segoe UI"),
                        Foreground = FgHint,
                        FontWeight = FontWeights.SemiBold,
                        Margin     = new Thickness(0, 0, 0, 6),
                    });

                    if (hasNote)
                    {
                        stack.Children.Add(new TextBlock
                        {
                            Text         = dayNote,
                            FontSize     = 11,
                            FontFamily   = new FontFamily("Segoe UI"),
                            Foreground   = FgPrimary,
                            TextWrapping = TextWrapping.Wrap,
                            Margin       = new Thickness(0, 0, 0, 8),
                        });
                    }

                    foreach (var je in entries)
                    {
                        string em = je.EmotionString;
                        string kindStr;
                        if (!string.IsNullOrEmpty(em))
                            kindStr = em;
                        else if (string.Equals(je.Kind, "SessionSummary", StringComparison.OrdinalIgnoreCase))
                            kindStr = "Session summary";
                        else
                            kindStr = "Note";

                        var entryGrid = new Grid { Margin = new Thickness(0, 0, 0, 4) };
                        entryGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
                        entryGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

                        var timeBlock = new TextBlock
                        {
                            Text       = je.Timestamp.ToString("HH:mm") + "  " + kindStr,
                            FontSize   = 9,
                            FontFamily = new FontFamily("Segoe UI Semibold"),
                            Foreground = FgHint,
                        };
                        Grid.SetColumn(timeBlock, 0);
                        entryGrid.Children.Add(timeBlock);

                        if (!string.IsNullOrWhiteSpace(je.Note))
                        {
                            var noteBlock = new TextBlock
                            {
                                Text         = je.Note,
                                FontSize     = 10,
                                FontFamily   = new FontFamily("Segoe UI"),
                                Foreground   = FgSecondary,
                                TextWrapping = TextWrapping.Wrap,
                            };
                            Grid.SetColumn(noteBlock, 1);
                            entryGrid.Children.Add(noteBlock);
                        }
                        stack.Children.Add(entryGrid);
                    }
                }
            }
            catch { }

            // ── Journal link ─────────────────────────────────────────────────
            // Has content  → "📔 View / Edit Journal →"  (green, prominent)
            // No content   → "📔 Write Journal →"         (dim, secondary — allows
            //                 the trader to add a retroactive note for this session)
            if (ViewJournalRequested != null)
            {
                bool hasJournalContent = false;
                try
                {
                    string dn = JournalStore.LoadDayNote(e.Date);
                    hasJournalContent = !string.IsNullOrWhiteSpace(dn)
                                        || JournalStore.Recent(limit: 1, sessionDate: e.Date).Count > 0;
                }
                catch { }

                stack.Children.Add(Gap(8));
                var journalLink = new Border
                {
                    Background          = Brushes.Transparent,
                    Cursor              = Cursors.Hand,
                    HorizontalAlignment = HorizontalAlignment.Left,
                };
                var journalLinkTb = new TextBlock
                {
                    Text       = hasJournalContent
                                 ? "\U0001F4D4  View / Edit Journal \u2192"
                                 : "\U0001F4D4  Write Journal \u2192",
                    FontSize   = 11,
                    FontWeight = hasJournalContent ? FontWeights.SemiBold : FontWeights.Normal,
                    Foreground = hasJournalContent
                                 ? new SolidColorBrush(Color.FromRgb(80, 230, 130))
                                 : FgHint,
                    FontFamily = new FontFamily("Segoe UI"),
                };
                journalLink.Child = journalLinkTb;
                journalLink.MouseEnter += (_, __) =>
                {
                    journalLinkTb.TextDecorations = TextDecorations.Underline;
                    if (!hasJournalContent) journalLinkTb.Foreground = FgSecondary;
                };
                journalLink.MouseLeave += (_, __) =>
                {
                    journalLinkTb.TextDecorations = null;
                    journalLinkTb.Foreground = hasJournalContent
                        ? new SolidColorBrush(Color.FromRgb(80, 230, 130)) : FgHint;
                };
                var capturedDate = e.Date;
                journalLink.MouseLeftButtonDown += (_, ev) =>
                {
                    ev.Handled = true;
                    ViewJournalRequested?.Invoke(capturedDate);
                };
                stack.Children.Add(journalLink);
            }

            panel.Child = stack;
            return panel;
        }

        private UIElement BuildDangerZone()
        {
            var container = new Border
            {
                Background      = new SolidColorBrush(Color.FromArgb(15, 255, 69, 58)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 69, 58)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(8),
                Padding         = new Thickness(14, 10, 14, 12),
            };

            var clearBtn = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(55, 30, 30)),
                CornerRadius    = new CornerRadius(6),
                Padding         = new Thickness(14, 8, 14, 8),
                Cursor          = Cursors.Hand,
                BorderBrush     = new SolidColorBrush(Color.FromRgb(255, 69, 58)),
                BorderThickness = new Thickness(1),
            };

            var btnStack = new StackPanel();
            btnStack.Children.Add(new TextBlock
            {
                Text       = "Clear Session History",
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(255, 69, 58)),
            });
            btnStack.Children.Add(new TextBlock
            {
                Text         = "Deletes all session log entries. Does not affect your statistical baseline.",
                FontSize     = 10,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 3, 0, 0),
            });
            clearBtn.Child = btnStack;

            clearBtn.MouseEnter += (_, __) =>
                clearBtn.Background = new SolidColorBrush(Color.FromRgb(80, 30, 30));
            clearBtn.MouseLeave += (_, __) =>
                clearBtn.Background = new SolidColorBrush(Color.FromRgb(55, 30, 30));

            clearBtn.MouseLeftButtonDown += (_, ev) =>
            {
                ev.Handled = true;
                // Use the parent Hub window as MessageBox owner so the dialog always
                // appears in front (Window.GetWindow finds the Hub since HistoryWindow's
                // content is transplanted into the Hub's visual tree).
                var owner = Window.GetWindow(_listSection);
                var result = MessageBox.Show(
                    owner,
                    "This will permanently delete all session history entries.\n\n" +
                    "Your statistical baseline is NOT affected — only the session log will be cleared.\n\n" +
                    "Are you sure?",
                    "Clear Session History",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning,
                    MessageBoxResult.No);

                if (result == MessageBoxResult.Yes)
                    ClearHistoryRequested?.Invoke();
            };

            container.Child = clearBtn;
            return container;
        }

        private static UIElement DetailRow(string label, string value, string sub,
                                           Color? valueColor = null)
        {
            var g = new Grid { Margin = new Thickness(0, 1, 0, 1) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(72) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            g.Children.Add(new TextBlock
            {
                Text              = label,
                FontSize          = 9,
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgHint,
                VerticalAlignment = VerticalAlignment.Center,
            });

            var valSp = new StackPanel { Orientation = Orientation.Horizontal };
            valSp.Children.Add(new TextBlock
            {
                Text              = value,
                FontSize          = 11,
                FontWeight        = FontWeights.SemiBold,
                Foreground        = valueColor.HasValue
                    ? new SolidColorBrush(valueColor.Value)
                    : FgPrimary,
                VerticalAlignment = VerticalAlignment.Center,
            });
            if (!string.IsNullOrEmpty(sub))
            {
                valSp.Children.Add(new TextBlock
                {
                    Text              = sub,
                    FontSize          = 10,
                    Foreground        = FgSecondary,
                    VerticalAlignment = VerticalAlignment.Center,
                });
            }
            Grid.SetColumn(valSp, 1);
            g.Children.Add(valSp);
            return g;
        }

        private static UIElement BuildZoneTimeBar(double stableMin, double cautionMin,
                                                  double criticalMin, double totalMin)
        {
            double stabFrac = stableMin  / totalMin;
            double cautFrac = cautionMin / totalMin;
            double critFrac = criticalMin / totalMin;

            var g = new Grid { Margin = new Thickness(0, 1, 0, 1) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(72) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            g.Children.Add(new TextBlock
            {
                Text              = "ZONE TIME",
                FontSize          = 9,
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgHint,
                VerticalAlignment = VerticalAlignment.Center,
            });

            var barOuter = new StackPanel
            {
                Orientation       = Orientation.Vertical,
                VerticalAlignment = VerticalAlignment.Center,
            };

            // Segmented bar
            var barRow = new Grid { Height = 6 };
            barRow.ColumnDefinitions.Add(new ColumnDefinition
                { Width = new GridLength(stabFrac, GridUnitType.Star) });
            barRow.ColumnDefinitions.Add(new ColumnDefinition
                { Width = new GridLength(cautFrac, GridUnitType.Star) });
            barRow.ColumnDefinitions.Add(new ColumnDefinition
                { Width = new GridLength(critFrac, GridUnitType.Star) });

            var stabFill = new Border { Background = new SolidColorBrush(ColStable),   CornerRadius = new CornerRadius(3, 0, 0, 3), Height = 6 };
            var cautFill = new Border { Background = new SolidColorBrush(ColCaution),  Height = 6 };
            var critFill = new Border { Background = new SolidColorBrush(ColCritical), CornerRadius = new CornerRadius(0, 3, 3, 0), Height = 6 };
            Grid.SetColumn(stabFill, 0); barRow.Children.Add(stabFill);
            Grid.SetColumn(cautFill, 1); barRow.Children.Add(cautFill);
            Grid.SetColumn(critFill, 2); barRow.Children.Add(critFill);
            barOuter.Children.Add(barRow);

            // Labels below bar
            string stabStr  = stableMin  >= 1 ? $"{(int)stableMin}m stable"  : "";
            string cautStr  = cautionMin >= 1 ? $"{(int)cautionMin}m caution" : "";
            string critStr  = criticalMin >= 1 ? $"{(int)criticalMin}m crit." : "";
            var parts = new[] { stabStr, cautStr, critStr }.Where(s => s.Length > 0);
            barOuter.Children.Add(new TextBlock
            {
                Text       = string.Join("  ·  ", parts),
                FontSize   = 9,
                Foreground = FgHint,
                Margin     = new Thickness(0, 3, 0, 0),
            });

            Grid.SetColumn(barOuter, 1);
            g.Children.Add(barOuter);
            return g;
        }

        // =====================================================================
        // Copy-to-clipboard summary  (internal so Hub can call it)
        // =====================================================================

        internal void CopySummary()        {
            var tradingDays = _monthEntries.Where(e => e.TotalTrades > 0).ToList();

            double? stabPct = _monthEntries.Count > 0
                ? 100.0 * _monthEntries.Count(e => e.ComposurePct >= SessionData.ComposureStableThreshold) / _monthEntries.Count
                : (double?)null;
            double? avgPnl  = tradingDays.Count > 0 ? tradingDays.Average(e => e.TotalPnl) : (double?)null;
            double? avgBq   = tradingDays.Count > 0 ? tradingDays.Average(e => e.ComposurePct) : (double?)null;
            int     streak  = _store.CurrentStableStreak();

            var sb = new StringBuilder();
            sb.AppendLine("PSI HISTORY  ·  " + _viewMonth.ToString("MMMM yyyy").ToUpper());
            sb.AppendLine("────────────────────────────");
            sb.AppendLine($"Stable streak:    {streak} day{(streak != 1 ? "s" : "")}");
            sb.AppendLine($"Stable sessions:  {(stabPct.HasValue ? $"{stabPct.Value:0}%" : "–")}");
            sb.AppendLine($"Avg P&L:          {(!avgPnl.HasValue ? "–" : (avgPnl.Value >= 0 ? "+" : "-") + "$" + Math.Abs(avgPnl.Value).ToString("0"))} / session");
            sb.AppendLine($"Avg composure:    {(avgBq.HasValue ? $"{avgBq.Value:0}%" : "–")}");
            sb.AppendLine();
            sb.AppendLine("RECENT SESSIONS");
            foreach (var e in _monthEntries.OrderByDescending(x => x.Date).Take(7))
            {
                string z   = e.FinalZone == PsiZone.Stable   ? "[S]"
                           : e.FinalZone == PsiZone.Caution  ? "[C]" : "[X]";
                string pnl = (e.TotalPnl >= 0 ? "+" : "-") + "$" + Math.Abs(e.TotalPnl).ToString("0");
                sb.AppendLine($"  {z} {e.Date:MMM d}  PSI {e.FinalPsi:0}  {pnl}  COMP {e.ComposurePct}%");
            }
            sb.AppendLine();
            sb.AppendLine("Monitored by MeridianPSI");

            try { System.Windows.Clipboard.SetText(sb.ToString().TrimEnd()); }
            catch { /* clipboard failure is non-critical */ }
        }

        private void ExportCsv()
        {
            var allSessions = _store.Sessions
                                    .OrderBy(e => e.Date)
                                    .ToList();
            if (allSessions.Count == 0)
            {
                MessageBox.Show("No session history to export.", "MeridianPSI",
                                MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var dlg = new SaveFileDialog
            {
                Title      = "Export Session History",
                Filter     = "CSV files (*.csv)|*.csv",
                FileName   = $"PSI_History_{DateTime.Today:yyyy-MM-dd}.csv",
                DefaultExt = ".csv",
            };
            if (dlg.ShowDialog() != true) return;

            try
            {
                var csv = new StringBuilder();
                csv.AppendLine(
                    "Date,StartPsi,MinPsi,FinalPsi,AvgPsi,Trades,Wins,WinRate%," +
                    "PnL,DurationMin,ComposurePct,Zone," +
                    "Alerts,TimeStableMin,TimeCautionMin,TimeCriticalMin," +
                    "D1,D2,D3,D4,D5,D6,D7");

                foreach (var e in allSessions)
                {
                    int wins = e.WinTrades;
                    double wr = e.TotalTrades > 0 ? 100.0 * wins / e.TotalTrades : 0;
                    csv.AppendLine(
                        $"{e.Date:yyyy-MM-dd}," +
                        $"{e.StartPsi:0.0},{e.MinPsi:0.0},{e.FinalPsi:0.0},{e.AvgPsi:0.0}," +
                        $"{e.TotalTrades},{wins},{wr:0.0}," +
                        $"{e.TotalPnl:0.00},{e.DurationMinutes},{e.ComposurePct}," +
                        $"{e.FinalZone}," +
                        $"{e.AlertsFired}," +
                        $"{e.TimeInStableMin:0.0},{e.TimeInCautionMin:0.0},{e.TimeInCriticalMin:0.0}," +
                        $"{e.D1:0.0},{e.D2:0.0},{e.D3:0.0},{e.D4:0.0},{e.D5:0.0},{e.D6:0.0},{e.D7:0.0}");
                }

                File.WriteAllText(dlg.FileName, csv.ToString(), Encoding.UTF8);
                MessageBox.Show(
                    $"Exported {allSessions.Count} sessions to:\n{dlg.FileName}",
                    "MeridianPSI — Export Complete",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Export failed: {ex.Message}", "MeridianPSI",
                                MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // =====================================================================
        // Helpers
        // =====================================================================

        private static Color ZoneColor(PsiZone z) =>
            z == PsiZone.Stable  ? ColStable  :
            z == PsiZone.Caution ? ColCaution : ColCritical;

        private static void AddCell(Grid g, int col, UIElement el)
        {
            Grid.SetColumn(el, col);
            g.Children.Add(el);
        }

        private static TextBlock SectionLabel(string text) =>
            new TextBlock
            {
                Text       = text,
                Foreground = FgHint,
                FontSize   = 9,
                FontWeight = FontWeights.SemiBold,
                Margin     = new Thickness(2, 0, 0, 6),
            };

        private static Border Gap(double height) => new Border { Height = height };

        private static TextBlock Placeholder(string msg) =>
            new TextBlock
            {
                Text                = msg,
                Foreground          = FgHint,
                FontSize            = 11,
                FontStyle           = FontStyles.Italic,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 12, 0, 12),
            };

        private static Button MakeHeaderButton(string glyph) =>
            new Button
            {
                Content                    = glyph,
                Width                      = 36,
                Foreground                 = FgSecondary,
                Background                 = Brushes.Transparent,
                BorderThickness            = new Thickness(0),
                FontSize                   = 13,
                Cursor                     = Cursors.Hand,
                VerticalContentAlignment   = VerticalAlignment.Center,
                HorizontalContentAlignment = HorizontalAlignment.Center,
            };
    }
}
