﻿#region Using declarations
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Shapes;
using System.Windows.Shell;
using System.Windows.Threading;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;
#endregion

// This namespace holds Add ons in this folder and is required. Do not change it.
namespace NinjaTrader.NinjaScript.AddOns
{
    // =====================================================================
    // PsiInsightSnapshot — point-in-time view of the V2 engine's observability
    // surface, consumed by the Dashboard Session Insight panel.  All fields
    // are copies; the caller can render on the UI thread without locking.
    // Indices are 1..7 for dimensions (index 0 unused) to match the engine.
    // =====================================================================
    public struct PsiInsightSnapshot
    {
        public double          CurrentPsi;
        public double          CurrentPressure;
        public double          PeakPressure;
        public int             ClassACommitCount;
        public double[]        PeakSeverityPerDim;   // length 8, index 1..7
        public CommitEvent[]   RecentCommits;        // oldest first
        public CommitClass[]   DimLastClass;         // length 8, index 1..7

        public PsiInsightSnapshot(bool empty)
        {
            CurrentPsi         = 100.0;
            CurrentPressure    = 0.0;
            PeakPressure       = 0.0;
            ClassACommitCount  = 0;
            PeakSeverityPerDim = new double[8];
            RecentCommits      = new CommitEvent[0];
            DimLastClass       = new CommitClass[8];
        }
    }

    public class MeridianPSI : NinjaTrader.NinjaScript.AddOnBase
    {
        // NT8 Ecosystem `VendorLicense(1468)` call removed in v1.3.2.
        // Licensing is enforced exclusively via the in-product Whop license
        // (see `LicenseManager.cs`).  This eliminates the NT8 "Vendor
        // Notification: A license is required" dialog that blocked paying
        // customers who had not yet been provisioned on the NT8 Vendor
        // Dashboard, and removes the parallel manual ops burden of keeping
        // two licensing systems in sync.
        internal const string ProductVersion = "1.3.3";

        // ── Update notification (populated by CheckForUpdateAsync at startup) ─
        private string _updateVersion = null;  // null = no update / check pending
        private string _updateNotes   = null;

        // =====================================================================
        // License manager
        // =====================================================================

        private readonly LicenseManager _licenseManager = new LicenseManager();

        // =====================================================================
        // Guard engine + session P&L
        // =====================================================================

        private GuardEngine _guardEngine;

        /// <summary>Session realised P&amp;L accumulated from fills; reset on new session date.</summary>
        private double _sessionPnl = 0.0;

        /// <summary>
        /// P&amp;L of the most recently completed round-trip trade (negative = loss).
        /// Updated on each closing fill; passed to GuardContext for SingleTradeLossExceeds.
        /// </summary>
        private double _lastTradePnl = 0.0;

        // PSI value at the time the last drop-notification was displayed.
        // Tracked on the NT8 event thread (PushPsiToHud).
        // Resets upward when PSI recovers ≥ 5 pts so the user always sees
        // a fresh notification after a meaningful PSI rebound.
        private double   _lastNotifPsi        = 100.0;

        // Wall-clock UTC of the last time a Class A drop incremented the
        // Alerts counter.  Used to group all partial fills of the same
        // entry decision into a single alert count (5 s window).  Purely
        // for counting — the notification banners are unaffected.
        private DateTime _lastAlertCountUtc   = DateTime.MinValue;

        // =====================================================================
        // Core engine components
        // =====================================================================

        private StrategyProfile  _profile;
        private TradeBaseline    _baseline;

        // ── Display settings (HUD visual preferences) ────────────────────────
        private DisplaySettings  _displaySettings = new DisplaySettings();
        // evidence-accumulator engine (PsiEngineV2).  The V1 PsiEngine
        // remains in the codebase only for offline regression tests
        // (PsiTestRunner.cs) and rollback reference; it is no longer
        // instantiated at runtime.  See ARCHITECTURE.md §15 for the V2
        // design contract and the 104-scenario acceptance suite that
        // gates this cutover.
        private PsiEngineV2      _engine;

        // ── PSI drop attribution log (v2) ─────────────────────────────────
        // Every HUD push compares the last observed commit-count against the
        // engine's current RecentCommits array.  Any NEW commits since the
        // last push are emitted to the NT8 Output window with dim / class /
        // magnitude / pressure, so the trader can reconstruct exactly what
        // moved PSI.  Kept off the critical path: pure read, no lock on the
        // engine (RecentCommits already locks internally).
        private int      _lastSeenCommitCount = 0;
        private double   _lastSeenPsi         = 100.0;

        // Single authoritative time / mode source.  See TradingClock.cs and
        // ARCHITECTURE.md §12.  All engine time reads go through this object
        // so Live ↔ Playback transitions reset the EWMA clock cleanly without
        // cross-domain contamination.
        private readonly TradingClock _clock = new TradingClock();

        // =====================================================================
        // UI
        // =====================================================================

        private PsiOverlayWindow      _overlayWindow;
        private MeridianDashboard     _hubWindow;
        private NTMenuItem            _openHudMenuItem;
        private NTMenuItem            _openDashMenuItem;

        // =====================================================================
        // Account subscriptions
        // Accessed from both state-change thread and timer thread → needs lock.
        // =====================================================================

        private readonly object        _accountsLock       = new object();
        private readonly List<Account> _subscribedAccounts = new List<Account>();
        // Maps account name → the Account object reference currently wired to our handlers.
        // Object-reference identity (not string equality) is the epoch discriminator:
        // a new Account instance from NT8 is an unconditional new connection epoch even
        // when NT8 never fires a Disconnect event first (e.g. Market Replay timeline scrub).
        private readonly Dictionary<string, Account> _activeAccountRefs = new Dictionary<string, Account>();

        // =====================================================================
        // Position entry-time tracking (for holdSeconds calculation)
        // Key: "AccountName::InstrumentName"
        // ConcurrentDictionary handles concurrent reads from the timer thread.
        // =====================================================================

        private readonly ConcurrentDictionary<string, DateTime> _positionEntryTimes
            = new ConcurrentDictionary<string, DateTime>();
        private readonly ConcurrentDictionary<string, double> _positionEntryPrices
            = new ConcurrentDictionary<string, double>();

        // =====================================================================
        // Inter-trade gap anchor (Axiom A4 — REMEDIATION_PLAN_v1.2.md)
        // =====================================================================
        // Timestamp of the most recent round-trip-final close.  Used on the
        // NEXT round-trip's close to compute the "gap" = entry_time(new)
        // − close_time(previous), which feeds TradeBaseline.UpdateInterTradeGap
        // and thereby personalises D1 revenge percentile to this trader's
        // observed rhythm.  Reset to MinValue on StartNewSession and in the
        // same places _positionEntryTimes is cleared (Playback rewind, etc.),
        // so the first trade of a session never fires a gap update (it has
        // no previous close).
        // =====================================================================
        private DateTime _lastRoundTripCloseTime = DateTime.MinValue;
        private readonly ConcurrentDictionary<string, MarketPosition> _positionDirections
            = new ConcurrentDictionary<string, MarketPosition>();

        // ── Per-trade disk-save queue (single-writer, non-blocking) ─────────
        // Problem solved: two threads writing the same XML file at once →
        // IOException.  Solution: each RecordTrade call builds an immutable
        // SessionDetail snapshot on the recording thread (all SessionData reads
        // happen under SessionData's own lock), then enqueues the frozen value.
        // A CAS counter (_saveWorkerRunning) guarantees at most ONE ThreadPool
        // worker drains the queue at any given time, so the file is only ever
        // opened by one writer simultaneously.
        //
        // Tuple layout: (session-date for PathFor, immutable SessionDetail).
        private readonly ConcurrentQueue<(DateTime Date, SessionDetail Detail)> _pendingSaves
            = new ConcurrentQueue<(DateTime, SessionDetail)>();
        private int _saveWorkerRunning = 0;  // Interlocked: 0 = idle, 1 = running
        private int _isShuttingDown    = 0;  // Interlocked: 1 = Terminated fired, no new workers

        // Cumulative open-position quantity per posKey.
        // Updated on every entry/scale-in fill so D3 sees the true combined exposure
        // even when two fills arrive in the same second (NT8 Position event fires before
        // Execution event, so fill.Account.Positions is already updated, but this dict
        // gives us a reliable fallback and handles scale-ins correctly).
        //
        // [M4 WILL DELETE] — shadow-state counter, replaced by _lifecycles +
        // Position.Quantity read-through.  See REMEDIATION_PLAN_v1.2.md Axiom A1.
        private readonly ConcurrentDictionary<string, double> _positionQuantities
            = new ConcurrentDictionary<string, double>();

        // =====================================================================
        // Position lifecycle metadata (Axiom A1 — REMEDIATION_PLAN_v1.2.md)
        // =====================================================================
        // TradeMonitor does NOT duplicate NT8's authoritative position state
        // (Quantity / MarketPosition / AveragePrice).  Those are always read
        // fresh from the NT8 Position object when needed.  This dictionary
        // holds ONLY metadata NT8 does not publish itself:
        //
        //   • LifecycleId    — minted on each Operation_Add edge so the
        //                      engine can correlate orders/fills to the
        //                      round-trip lifecycle that opened with them.
        //   • EntryTime      — the first fill time of this lifecycle (for
        //                      holdSeconds accounting; survives scale-ins).
        //   • MaxQtySeen     — high-water mark of the position quantity
        //                      seen across all Updates (diagnostics only).
        //   • OriginObserved — true iff the Operation_Add for this
        //                      lifecycle was observed in the current
        //                      process lifetime.  Gates RecordTrade (Axiom
        //                      A3): orphan closes — positions that already
        //                      existed in NT8 when TradeMonitor started
        //                      (post-restart / post-replay-rewind) — are
        //                      logged but NOT counted as session trades.
        //
        // Populated by OnPositionUpdate (Axiom A2), not OnExecutionUpdate.
        // M1/M2 add the type and dictionary but leave shadow state intact;
        // M4 is the cutover that deletes shadow state and makes this the
        // single source of lifecycle truth.
        // =====================================================================

        /// <summary>
        /// Per-position lifecycle metadata.  Keyed by <c>AccountName::InstrumentName</c>.
        /// See class comment above for field semantics.
        /// </summary>
        /// <remarks>
        /// <para>
        /// <c>Direction</c> is stored so that a <em>reversal</em> event — which NT8
        /// can legitimately deliver as a single <c>Operation.Update</c> event
        /// when there is no flat state between the old and the new position
        /// (per NT8 PositionUpdate docs) — can be detected as
        /// <c>existing.Direction != e.Position.MarketPosition</c>.  In that
        /// case the old lifecycle is considered Removed and a new lifecycle
        /// is considered Added on the same event, which preserves Axiom A2's
        /// "one Remove and one Add per round-trip, regardless of how NT8
        /// packages the transition."
        /// </para>
        /// </remarks>
        internal sealed class PositionLifecycle
        {
            /// <summary>Unique identifier minted when the Add edge fired.</summary>
            public Guid           LifecycleId    { get; set; }
            /// <summary>Platform timestamp of the first fill that opened this lifecycle.</summary>
            public DateTime       EntryTime      { get; set; }
            /// <summary>High-water mark of observed position quantity (diagnostics).</summary>
            public double         MaxQtySeen     { get; set; }
            /// <summary>True iff the Add edge was observed in this process lifetime.</summary>
            public bool           OriginObserved { get; set; }
            /// <summary>
            /// Wall-clock UTC time at which MintLifecycle created this lifecycle.
            /// Used by IntegrityCheck C2 to distinguish true bootstrap ghosts
            /// (minted within BootstrapReplayWindow of _accountSubscribedAt) from
            /// incorrectly tagged lifecycles (minted after bootstrap window closed).
            /// </summary>
            public DateTime       MintedAt       { get; set; }
            /// <summary>Direction this lifecycle opened in (Long or Short — never Flat).</summary>
            public MarketPosition Direction      { get; set; }

            // ── Trade recording state (owned exclusively — never touched by external code) ──
            /// <summary>posKey this lifecycle is keyed under (needed inside TryRecordTrade).</summary>
            public string         PosKey                  { get; set; }
            /// <summary>Cumulative net P&amp;L across all closing fills for this lifecycle.</summary>
            public double         AccumulatedPnl          { get; set; }
            /// <summary>
            /// Position size at the last scale-in (or initial entry).
            /// Closing fills must accumulate PostLastScaleInCloseQty equal to this
            /// value before TryRecordTrade will gate the recording as complete.
            /// Reset to the new qty on every scale-in (UPDATE that grows the position).
            /// </summary>
            public int            QtyAtLastScaleIn        { get; set; }
            /// <summary>
            /// Sum of closing-fill quantities received since the last scale-in.
            /// TryRecordTrade fires when this equals QtyAtLastScaleIn AND IsRemoved is true.
            /// </summary>
            public int            PostLastScaleInCloseQty { get; set; }
            /// <summary>Set by the REMOVE edge; never reset. Signals that NT8 confirmed flat.</summary>
            public bool           IsRemoved               { get; set; }
            /// <summary>Set by TryRecordTrade after recording; never reset. Idempotency guard.</summary>
            public bool           Recorded                { get; set; }
            /// <summary>Platform timestamp of the last closing fill (used for hold-time in TryRecordTrade).</summary>
            public DateTime       LastCloseFillTime       { get; set; }
        }

        /// <summary>
        /// Position lifecycle table (Axiom A1).  One entry per currently-open
        /// NT8 position; removed when <c>Operation_Remove</c> fires.  Concurrent
        /// because OnPositionUpdate fires on the NT8 dispatcher thread while
        /// the PSI poll timer reads on the ThreadPool.
        /// </summary>
        private readonly ConcurrentDictionary<string, PositionLifecycle> _lifecycles
            = new ConcurrentDictionary<string, PositionLifecycle>();

        /// <summary>
        /// Retiring lifecycle table — holds lifecycles between the NT8 Remove event
        /// and <c>TryRecordTrade</c> setting <c>Recorded = true</c>.  One entry per
        /// recently-closed position, keyed by the same posKey as <c>_lifecycles</c>.
        /// Close fills arriving after Remove look up the lifecycle here.
        /// Entry is removed by <c>TryRecordTrade</c> once recording succeeds, or by
        /// the 500 ms liveness timer if recording already completed via the hot path.
        /// </summary>
        private readonly ConcurrentDictionary<string, PositionLifecycle> _retiringLifecycles
            = new ConcurrentDictionary<string, PositionLifecycle>();

        /// <summary>
        /// Subscription-time wall-clock anchor per account (Axiom A3).
        /// NT8 replays the current position state via <c>PositionUpdate</c>
        /// immediately after an account subscription — those replayed Add
        /// edges pertain to positions that existed BEFORE TradeMonitor was
        /// running, so they are <em>observed orphans</em> and must not be
        /// counted toward session trade counts.  A bootstrap window of
        /// 2 s is used to distinguish replays from genuine new entries.
        /// </summary>
        private readonly ConcurrentDictionary<string, DateTime> _accountSubscribedAt
            = new ConcurrentDictionary<string, DateTime>();

        /// <summary>
        /// How long after subscribing we treat first-seen Add edges as
        /// bootstrap replays rather than genuine entries (Axiom A3).
        /// </summary>
        private static readonly TimeSpan BootstrapReplayWindow = TimeSpan.FromSeconds(2.0);

        // Maximum Adverse Excursion (MAE) per posKey.
        // Tracks the lowest unrealised PnL observed during a position's life.
        // Updated on every timer tick (BuildPositionSnapshots) and cleared when
        // the position fully closes.  Passed into PositionSnapshot so CalcD5 can
        // penalise a position that was deeply underwater even after it recovers
        // to breakeven/profit — the psychological impact of that period remains.
        private readonly ConcurrentDictionary<string, double> _positionMinPnl
            = new ConcurrentDictionary<string, double>();

        // P&L is computed as gross (price movement only, no fees) via the
        // manual formula: (exitPrice − entryPrice) × closingQty × pointValue.
        // Design rationale: PSI monitors trading discipline (did the trade go
        // in the right direction?), not net profitability after commissions.
        // Fees are a business cost, not evidence of discipline quality.
        // A trade that moved the right way is a win regardless of commission.
        // _positionEntryPrices (below) is the only price-tracking state needed.

        // Fill deduplication for copy-trading (Replikanto / signal-copy) setups.
        // When multiple DIFFERENT accounts receive the same signal within 250 ms,
        // only the first account's fill contributes to PSI.
        // Fills from the SAME account are NEVER deduplicated — this allows partial
        // fills of one order AND multiple simultaneous ATM-strategy fills (e.g. two
        // ATM strategies on the same account both hitting Target1 at the same time).
        // Key: "InstrumentName|Direction|Qty"  Value: (first account name, fill ticks)
        private readonly ConcurrentDictionary<string, (string AccountName, long Ticks)> _fillDedup
            = new ConcurrentDictionary<string, (string, long)>(StringComparer.Ordinal);
        // 250 ms: wide enough to catch Replikanto copies (≤ 150 ms apart).
        private const long DedupWindowTicks = 2_500_000L; // 250 ms

        // =====================================================================
        // Timers
        //
        // Two separate timers with different cadences:
        //
        //   _psiPollTimer  (5 s)  — PollPositions + PushPsiToHud.
        //       Drives the continuous evidence signals (D3 Class B oversize
        //       persistence, D5 overstay, D2 naked) at a rate fine enough that
        //       users see PSI declining SMOOTHLY while holding an oversize
        //       position — not in one large jump every 30 s.  5 s was chosen
        //       to balance visual smoothness (~0.5–2 PSI pts per tick at
        //       typical oversize rates) against log volume.
        //
        //   _adminTimer  (30 s)  — administrative checks only.
        //       Account discovery, mode detection refresh, P&L reconciliation,
        //       Hub session tab refresh.  These do NOT need sub-minute cadence.
        //
        // This separation matches the Axiom 2 contract: E_i evidence is
        // supposed to integrate CONTINUOUSLY; the 30 s batch was a convenience
        // approximation that violated the spirit of that axiom by making the
        // continuous signal visible as discrete 10-15 pt PSI jumps.
        // =====================================================================

        private System.Timers.Timer _psiPollTimer;
        private System.Timers.Timer _adminTimer;

        // =====================================================================
        // IntegrityCheck timer (1 s).  Every tick: build an immutable snapshot
        // of all internal state + NT8 ground truth, run IntegrityCheck.Run, log
        // [INTEGRITY VIOLATION] for each violation, and (after the per-violation
        // grace window has elapsed) auto-repair using NT8 truth.
        //
        // Persistence filter: a Warning-level violation must persist >= 1 s
        // before being repaired, so transient mid-event windows (where shadow
        // and NT8 disagree for microseconds between OnExecutionUpdate and
        // OnPositionUpdate) don't trigger unnecessary repair.  Critical
        // violations skip the grace window — they're logged and repaired on
        // the next tick.  See ARCHITECTURE.md §15 for the design contract.
        // =====================================================================
        private System.Timers.Timer _integrityTimer;

        // First-seen wall-clock for each (Code, PosKey) violation pair.
        // Used by the persistence filter — a Warning violation is repaired
        // only when (now - firstSeen) >= IntegrityRepairGrace.
        private readonly System.Collections.Concurrent.ConcurrentDictionary<string, DateTime>
            _integrityFirstSeen = new System.Collections.Concurrent.ConcurrentDictionary<string, DateTime>();

        private static readonly TimeSpan IntegrityRepairGrace = TimeSpan.FromSeconds(1.0);

        // [M6 / Axiom A5] UI dispatcher captured once from State.Configure
        // (guaranteed main-thread).  Timer callbacks invoke their engine-
        // facing body via _uiDispatcher.BeginInvoke so _clock.EngineTime
        // reads always happen on the main thread, not the ThreadPool
        // (NT8 LANDMINE 7 — Globals.Now returns wall-clock off-main in
        // Playback).  Null when State.Configure has not yet run.
        private System.Windows.Threading.Dispatcher _uiDispatcher;

        // =====================================================================
        // Session-date tracking (detect new trading day on first fill)
        // =====================================================================

        private DateTime _lastSessionDate = DateTime.MinValue;

        // =====================================================================
        // Playback rewind detection
        // Rewind detection is delegated to TradingClock.IsPlaybackRewind().
        // TradingClock.LastFillPlatformTime holds the previous fill's timestamp;
        // it is compared against each incoming fill BEFORE RecordFillAnchor is
        // called, so the old value is still available at detection time.
        // =====================================================================

        private const int PlaybackRewindToleranceMinutes = 2;

        // =====================================================================
        // ATM partial-close grace period
        // After a partial close the broker briefly cancels/resubmits the stop
        // order.  During this window the position appears "naked".  We record
        // the wall-clock (UTC) time of the last partial close and suppress the
        // naked check for PartialCloseGraceSec seconds.
        // =====================================================================

        private WallClockGate _partialCloseGate = new WallClockGate(PartialCloseGraceSec);
        private const double PartialCloseGraceSec = 5.0;

        // =====================================================================
        // DESYNC grace period
        // When the user drags the Market Replay timeline, NinjaTrader shows
        // a historical position that the user did NOT create.  These positions
        // have no ATM stops (no user orders).  After a DESYNC repair we
        // suppress naked-position detection for DesyncGraceSec so these
        // reconciled positions don't crash PSI.
        // =====================================================================

        private WallClockGate _desyncRepairGate = new WallClockGate(DesyncGraceSec);
        private const double DesyncGraceSec = 60.0;

        // =====================================================================
        // Monitoring on/off state  (toggled from the HUD pill button)
        // =====================================================================

        private bool _monitoringEnabled = true;

        // Tracks whether the previous poll observed an open position.  Used to
        // detect the open→flat edge in non-live mode, where the engine's
        // `_lastTick` must transition from the fill-time domain (anchored on the
        // last fill) to the wall-clock domain (used while flat) exactly once.
        // Reset to false on session reset / rewind / mode change.
        private bool _prevPollHadOpenPosition = false;

        // ── Guard window position memory (persists within a session) ──────────
        // Null = first pop-up ever → default to upper-centre of screen.
        // Once the user drags any Guard window, the offset is remembered and all
        // subsequent windows open at that location.
        private double? _guardWinLeft;
        private double? _guardWinTop;

        // =====================================================================
        // First-run flag — set in Configure when profile.xml does not exist yet.
        // Cleared after the settings hub is opened once in OnWindowCreated.
        // =====================================================================

        private bool _isFirstRun;

        // =====================================================================
        // Baseline recording suspension  (SIM / PLAYBACK / TEST mode)
        // When suspended, PSI still computes in real-time (user sees their
        // score) but _baseline stats are NOT updated, preventing simulation
        // or playback data from contaminating the live trading baseline.
        // =====================================================================

        private bool   _baselineRecordingSuspended;
        private string _baselineSuspendReason;   // "SIM", "PLAYBACK", "TEST", or null

        // =====================================================================
        // Session data accumulator
        // =====================================================================

        private SessionData _currentSession = new SessionData();

        // =====================================================================
        // Session history store  ("My History" feature)
        // =====================================================================

        private SessionHistoryStore _historyStore;

        // =====================================================================
        // Alert state  (prevents repeated alerts during the same PSI drop)
        // =====================================================================

        private PsiZone  _prevAlertZone  = PsiZone.Stable;
        private DateTime _lastCritAlert  = DateTime.MinValue;
        private DateTime _lastWarnAlert  = DateTime.MinValue;
        private DateTime _lastCautAlert  = DateTime.MinValue;

        // =====================================================================
        // Lifecycle
        // =====================================================================

        protected override void OnStateChange()
        {
            if (State == State.SetDefaults)
            {
                Description = "Real-time Psychological Stability Index (PSI) monitor for day traders.";
                Name        = "TradeMonitor";
            }

            // -----------------------------------------------------------------
            else if (State == State.Configure)
            {
                // Resolve data directory using NT8's authoritative data root.
                // This handles OneDrive Document-folder redirection and non-default
                // NT8 installation locations — both break the hard-coded MyDocuments path.
                string dataDir = System.IO.Path.Combine(
                    NinjaTrader.Core.Globals.UserDataDir,
                    "bin", "Custom", "AddOns", "TradeMonitorData");
                StrategyProfile.SetDataDir(dataDir);
                TradeBaseline.SetDataDir(dataDir);
                SessionHistoryStore.SetDataDir(dataDir);
                LicenseManager.SetDataDir(dataDir);
                GuardEngine.SetDataDir(dataDir);
                MeridianDashboard.SetDataDir(dataDir);

                // Load display preferences (UI-only, separate from trading profile).
                _displaySettings = DisplaySettings.Load(DisplaySettingsPath);

                // Bind license to the NT8 installation fingerprint (same approach
                // as other commercial NT8 vendors such as Replikanto).  This means
                // reinstalling Windows will NOT invalidate the user's activation —
                // the license is tied to the NT8 install, not the underlying OS.
                try
                {
                    string ntFingerprint = NinjaTrader.Core.Globals.GenerateLicenseCode();
                    LicenseManager.SetMachineId(ntFingerprint);
                }
                catch { /* falls back to Windows MachineGuid inside LicenseManager */ }

                // Kick off license validation asynchronously — never blocks NT8 startup.
                _ = _licenseManager.InitialiseAsync();

                // Check for available updates in the background.
                // Runs once per NT8 session; result surfaced via HUD badge and Dashboard.
                _ = CheckForUpdateAsync();

                // Detect first run before loading (file doesn't exist yet).
                _isFirstRun = !System.IO.File.Exists(StrategyProfile.ProfilePath);

                // Log version for support / bug reports.
                var ntVer = typeof(NinjaTrader.Core.Globals).Assembly.GetName().Version;
                Log($"[TradeMonitor] PSI v{ProductVersion} initializing (NinjaTrader {ntVer})", LogLevel.Information);

                // Load persisted profile, baseline, and session history.
                _profile      = StrategyProfile.LoadFromFile(LogWarning);
                _baseline     = TradeBaseline.LoadFromFile(LogWarning);
                _historyStore = SessionHistoryStore.LoadFromFile(LogWarning);
                _engine       = new PsiEngineV2(_profile, _baseline,
                                                PsiEngineV2Config.FromProfile(_profile));

                // v1.1 observability: route engine-level attribution strings
                // (B1 PSI-drop attribution, B2 session summary, B3 sanity-
                // clamp warnings) through the TradeMonitor log sink.
                _engine.SetDebugLogger(msg => Log(msg, LogLevel.Information));

                _guardEngine  = GuardEngine.LoadFromFile(LogWarning);
                _guardEngine.Triggered += OnGuardTriggered;

                // Wire the TradingClock into the engine's reset machinery.
                // Any Live ↔ Playback / Sim transition forces a fresh session so
                // we never integrate EWMA across time domains.  Fix-A style
                // position corrections are still separate (they do not cross
                // time domains) and run through OnPositionTrackingCorrection.
                _clock.ModeChanged += OnTradingModeChanged;

                // [M5 / Axiom A5] Pin the clock's main-thread affinity.
                // State.Configure always runs on NT8's UI dispatcher thread,
                // so capturing the thread ID here gives TradingClock the
                // reference point it needs to distinguish on-main reads
                // (safe Globals.Now) from off-main reads (Playback
                // LANDMINE 7 — must return cached value instead).
                _clock.CaptureMainThread();

                // [M6 / Axiom A5] Capture the UI dispatcher so background
                // timer callbacks (OnPsiPollTimerElapsed, OnAdminTimerElapsed)
                // can marshal their engine-facing work onto the main thread
                // before reading _clock.EngineTime.
                //
                // CRITICAL: must be Application.Current.Dispatcher, NOT
                // Dispatcher.CurrentDispatcher.  NT8 has been observed to
                // invoke OnStateChange(State.Configure) on a worker thread
                // (multiple AddOn re-instantiations during a session are
                // proof of this — see ARCHITECTURE.md §10 entry 2026-04-26
                // HUD silent-update bug).  Dispatcher.CurrentDispatcher on a
                // worker thread CREATES a brand-new thread-local dispatcher
                // with no message pump; every subsequent BeginInvoke queues
                // to it forever and the callback NEVER runs.
                // Application.Current.Dispatcher is the WPF Application's
                // main-UI-thread dispatcher — it owns every Window in the
                // process (HUD + Hub + Control Center) and is the only
                // dispatcher that pumps messages.
                _uiDispatcher = Application.Current != null
                    ? Application.Current.Dispatcher
                    : System.Windows.Threading.Dispatcher.CurrentDispatcher;

                // Start the session using whatever the last recorded final PSI was.
                _engine.StartNewSession(_baseline.LastSessionFinalPsi);
                _prevPollHadOpenPosition = false;
                ResetCommitAttributionTracking();

                // ── Developer testing hook ────────────────────────────────────
                // Set RUN_PSI_TESTS to true in PsiTestRunner.cs to run all 20
                // scenarios on startup.  Results go to Desktop/PsiTestResults.txt.
                // KEEP FALSE in production builds.
                if (PsiTestRunner.RunOnStartup)
                {
                    try
                    {
                        string report = PsiTestRunner.RunAll();
                        LogWarning("[TradeMonitor] PsiTestRunner complete — see Desktop/PsiTestResults.txt");
                    }
                    catch (Exception ex)
                    {
                        LogWarning("[TradeMonitor] PsiTestRunner exception: " + ex.Message);
                    }
                }

                // Subscribe to NT8's static account-status event FIRST so any
                // account that connects while we iterate Account.All is not missed
                // in the race window between the event subscription and the loop.
                // This is the PRIMARY subscription mechanism — when Playback101 or
                // Sim101 connects (user starts Market Replay), we subscribe instantly.
                Account.AccountStatusUpdate += OnAccountStatusUpdate;

                // Subscribe to accounts that are already connected right now.
                lock (_accountsLock)
                {
                    foreach (Account account in Account.All)
                        TrySubscribeAccount(account);
                }

                // PSI poll timer (5 s): continuous evidence signals — D3 Class B,
                // D5 overstay, D2 naked — update at HUD-visible cadence so PSI
                // declines smoothly while the trader holds an oversize / overdue
                // position rather than in a single large batch every 30 s.
                _psiPollTimer           = new System.Timers.Timer(5000);
                _psiPollTimer.AutoReset = true;
                _psiPollTimer.Elapsed  += OnPsiPollTimerElapsed;
                _psiPollTimer.Start();

                // Admin timer (30 s): secondary safety-net for account discovery,
                // mode-detection refresh, P&L reconciliation, Hub session tab refresh.
                // Primary account subscription is event-driven via Account.AccountStatusUpdate.
                _adminTimer           = new System.Timers.Timer(30000);
                _adminTimer.AutoReset = true;
                _adminTimer.Elapsed  += OnAdminTimerElapsed;
                _adminTimer.Start();

                // Integrity timer (1 s): self-healing invariant assertion.  See field
                // declaration for design contract.
                _integrityTimer           = new System.Timers.Timer(1000);
                _integrityTimer.AutoReset = true;
                _integrityTimer.Elapsed  += OnIntegrityTimerElapsed;
                _integrityTimer.Start();

                // Detect sim/playback from subscribed accounts at startup so
                // the badge is correct even before the first fill arrives.
                RefreshBaselineSuspendStatus();

                // Warn if the baseline appears contaminated by past Playback/Sim data
                // (N >> 0 but SessionCount == 0 means data arrived before proper session
                // tracking or sim-detection existed).
                int totalBaselineN = _baseline.MuSize.N + _baseline.MuLoss.N;
                if (_baseline.SessionCount == 0 && totalBaselineN > 10)
                {
                    Log("[TradeMonitor] WARNING: Your baseline contains " + totalBaselineN +
                        " data points but SessionCount=0. This likely means Playback/Simulation " +
                        "data leaked into your baseline before the auto-detection feature was added. " +
                        "Open Control Center > New > TradeMonitor Profile to review your data, " +
                        "and use the Reset Baseline button if needed.",
                        LogLevel.Warning);
                }

                // Auto-open the HUD so it is always visible after a recompile/restart.
                // ShowOrActivateHud dispatches via InvokeAsync, so it queues AFTER
                // State.Terminated's window-close (also InvokeAsync) on the same
                // dispatcher FIFO — old window closes first, new window opens second.
                ShowOrActivateHud();
            }

            // -----------------------------------------------------------------
            else if (State == State.Terminated)
            {
                // Stop timers first to prevent callbacks after teardown.
                if (_psiPollTimer != null)
                {
                    _psiPollTimer.Stop();
                    _psiPollTimer.Elapsed -= OnPsiPollTimerElapsed;
                    _psiPollTimer.Dispose();
                    _psiPollTimer = null;
                }
                if (_adminTimer != null)
                {
                    _adminTimer.Stop();
                    _adminTimer.Elapsed -= OnAdminTimerElapsed;
                    _adminTimer.Dispose();
                    _adminTimer = null;
                }
                if (_integrityTimer != null)
                {
                    _integrityTimer.Stop();
                    _integrityTimer.Elapsed -= OnIntegrityTimerElapsed;
                    _integrityTimer.Dispose();
                    _integrityTimer = null;
                }

                // Detach the static account-status event (primary subscription mechanism).
                Account.AccountStatusUpdate -= OnAccountStatusUpdate;

                // Unsubscribe all accounts.
                lock (_accountsLock)
                {
                    foreach (Account account in _subscribedAccounts)
                    {
                        account.ExecutionUpdate -= OnExecutionUpdate;
                        account.OrderUpdate     -= OnOrderUpdate;
                        account.PositionUpdate  -= OnPositionUpdate;
                    }
                    _subscribedAccounts.Clear();
                    _activeAccountRefs.Clear();
                }

                // Detach Guard event handler to prevent stray callbacks.
                if (_guardEngine != null)
                    _guardEngine.Triggered -= OnGuardTriggered;

                // Persist the baseline so history survives restarts.
                _baseline?.SaveToFile(LogWarning);

                // Save the current (in-progress) session to history if any trades
                // occurred.  This handles the "NT8 closed mid-session" case so no
                // data is silently lost when the user shuts down before a new
                // session would naturally have triggered the archive.
                if (_currentSession.HasRecordedTrades() && _historyStore != null)
                {
                    // Signal shutdown — no new background save workers will be armed.
                    // Any active worker is serialized via SessionDetailStore._fileIOLock;
                    // the Save call below acquires that same lock and blocks until the
                    // worker releases it (typically < 2 ms).  No SpinWait, no timeout.
                    Interlocked.Exchange(ref _isShuttingDown, 1);

                    var now = NinjaTrader.Core.Globals.Now;
                    _currentSession.Flush(now);
                    _historyStore.Append(_currentSession.ToHistoryEntry(), LogWarning);
                    SessionDetailStore.Save(_currentSession, LogWarning);
                }

                if (_openHudMenuItem != null)
                {
                    _openHudMenuItem.Click -= OnOpenHudMenuItemClick;
                    _openHudMenuItem = null;
                }
                if (_openDashMenuItem != null)
                {
                    _openDashMenuItem.Click -= OnOpenDashMenuItemClick;
                    _openDashMenuItem = null;
                }

                // Close all open windows on the UI thread.
                if (Application.Current == null) return;

                // Persist the HUD layout synchronously BEFORE the async close so that
                // the layout file is always written even if the WPF dispatcher stops
                // processing InvokeAsync work items during rapid shutdown.
                // Dispatcher.Invoke is safe here: State.Terminated is called on a
                // background thread, never on the UI thread itself.
                Application.Current.Dispatcher.Invoke(() =>
                    _overlayWindow?.PersistLayout());

                Application.Current.Dispatcher.InvokeAsync(() =>
                {
                    if (_overlayWindow != null)
                    {
                        _overlayWindow.Close();
                        _overlayWindow = null;
                    }
                    if (_hubWindow != null)
                    {
                        _hubWindow.Close();
                        _hubWindow = null;
                    }
                });
            }
        }

        protected override void OnWindowCreated(Window window)
        {
            base.OnWindowCreated(window);

            ControlCenter cc = window as ControlCenter;
            if (cc == null) return;

            MenuItem newMenu = cc.FindFirst("ControlCenterMenuItemNew") as MenuItem;
            if (newMenu == null) return;

            // Clean stale duplicated menu items (can happen after script reloads).
            for (int i = newMenu.Items.Count - 1; i >= 0; i--)
            {
                MenuItem existing = newMenu.Items[i] as MenuItem;
                if (existing == null) continue;
                string hdr = existing.Header as string ?? "";
                if (hdr.StartsWith("MeridianPSI") || hdr.StartsWith("Meridian Dashboard"))
                    newMenu.Items.RemoveAt(i);
            }

            if (_openHudMenuItem != null)
            {
                _openHudMenuItem.Click -= OnOpenHudMenuItemClick;
                _openHudMenuItem = null;
            }
            if (_openDashMenuItem != null)
            {
                _openDashMenuItem.Click -= OnOpenDashMenuItemClick;
                _openDashMenuItem = null;
            }

            _openHudMenuItem = new NTMenuItem
            {
                Header = "MeridianPSI",
                Style  = Application.Current.TryFindResource("MainMenuItem") as Style
            };
            _openHudMenuItem.Click += OnOpenHudMenuItemClick;
            newMenu.Items.Add(_openHudMenuItem);

            _openDashMenuItem = new NTMenuItem
            {
                Header = "Meridian Dashboard",
                Style  = Application.Current.TryFindResource("MainMenuItem") as Style
            };
            _openDashMenuItem.Click += OnOpenDashMenuItemClick;
            newMenu.Items.Add(_openDashMenuItem);

            // First run: open the Dashboard to the Settings page automatically
            // so the user configures their profile before PSI begins scoring.
            if (_isFirstRun)
            {
                _isFirstRun = false;
                var timer = new System.Windows.Threading.DispatcherTimer
                {
                    Interval = TimeSpan.FromMilliseconds(900)
                };
                timer.Tick += (s, _e) =>
                {
                    ((System.Windows.Threading.DispatcherTimer)s).Stop();
                    ShowOrActivateHub(HubPage.Settings);
                };
                timer.Start();
            }
        }

        protected override void OnWindowDestroyed(Window window)
        {
            base.OnWindowDestroyed(window);

            ControlCenter cc = window as ControlCenter;
            if (cc == null) return;

            MenuItem newMenu = cc.FindFirst("ControlCenterMenuItemNew") as MenuItem;
            if (newMenu != null)
            {
                for (int i = newMenu.Items.Count - 1; i >= 0; i--)
                {
                    MenuItem existing = newMenu.Items[i] as MenuItem;
                    if (existing == null) continue;
                    string hdr = existing.Header as string ?? "";
                    if (hdr.StartsWith("MeridianPSI") || hdr.StartsWith("Meridian Dashboard"))
                        newMenu.Items.RemoveAt(i);
                }
            }

            if (_openHudMenuItem != null)
            {
                _openHudMenuItem.Click -= OnOpenHudMenuItemClick;
                _openHudMenuItem = null;
            }
            if (_openDashMenuItem != null)
            {
                _openDashMenuItem.Click -= OnOpenDashMenuItemClick;
                _openDashMenuItem = null;
            }
        }

        // =====================================================================
        // Execution event handler  (NT8 account thread — NOT the UI thread)
        // =====================================================================

        // ── Copy-trading deduplication ────────────────────────────────────────
        // Returns true ONLY when a fill from a DIFFERENT account has the same
        // instrument/direction/qty within 250 ms (Replikanto copy-trade pattern).
        // Fills from the SAME account are always allowed through, even if they
        // share the same parameters — e.g. two ATM strategies on Playback101 both
        // hitting Target1 simultaneously, or partial fills of a single order.
        private bool IsCopyTradingDuplicate(string accountName, string instrName, MarketPosition dir, double qty, DateTime t)
        {
            string key      = instrName + "|" + dir + "|" + ((int)qty).ToString();
            long   nowTicks = t.Ticks;
            (string AccountName, long Ticks) prev;
            if (_fillDedup.TryGetValue(key, out prev) &&
                (nowTicks - prev.Ticks) < DedupWindowTicks &&
                prev.AccountName != accountName)
            {
                return true; // Different account within window = copy-trade duplicate
            }
            _fillDedup[key] = (accountName, nowTicks);
            return false;
        }

        private void OnExecutionUpdate(object sender, ExecutionEventArgs e)
        {
            if (e?.Execution == null)  return;
            if (!_monitoringEnabled)   return;

            Execution fill = e.Execution;
            if (fill.Instrument?.MasterInstrument == null) return;

            string instrName   = fill.Instrument.MasterInstrument.Name;
            string accountName = fill.Account?.Name ?? "Unknown";
            string posKey      = PositionKey(accountName, instrName);

            // ── Update TradingClock + baseline recording suspension ──────────
            // TradingClock is the single authority for mode.  It raises
            // ModeChanged on any transition (→ OnTradingModeChanged) which
            // triggers ResetClockAnchor in the engine.  _baselineRecordingSuspended
            // mirrors (Mode != Live || TestMode) for backward compatibility with
            // pre-Provenance baseline-suspend call sites; the authoritative
            // filter is DataProvenance on the TradeRecord (TradeBaseline only
            // admits Provenance == Live — see ARCHITECTURE.md §13).
            Account fillAccount = sender as Account;
            TradingMode inferredMode = TradingClock.InferMode(fillAccount);
            _clock.UpdateMode(inferredMode);

            string suspendReason = inferredMode == TradingMode.Playback ? "PLAYBACK"
                                 : inferredMode == TradingMode.Simulation ? "SIM"
                                 : (_profile != null && _profile.IsTestModeActive) ? "TEST"
                                 : null;

            bool   wasSuspended = _baselineRecordingSuspended;
            string oldReason    = _baselineSuspendReason;
            _baselineRecordingSuspended = suspendReason != null;
            _baselineSuspendReason      = suspendReason;

            if (_baselineRecordingSuspended != wasSuspended || suspendReason != oldReason)
            {
                string logMsg = _baselineRecordingSuspended
                    ? $"[TradeMonitor] Baseline recording SUSPENDED — {suspendReason} ({accountName})."
                    : "[TradeMonitor] Baseline recording RESUMED — live account detected.";
                Log(logMsg, LogLevel.Information);

                string hudBadge = GetHudBadgeText();
                Application.Current?.Dispatcher.InvokeAsync(
                    () => _overlayWindow?.UpdateBaselineStatus(hudBadge));
            }

            _desyncRepairGate.Clear();

            // ── Copy-trading deduplication ─────────────────────────────────────
            // Skip fills from Replikanto follower accounts on DIFFERENT accounts.
            // Same-account fills (partial fills, multiple ATM strategies) always pass.
            if (IsCopyTradingDuplicate(accountName, instrName, fill.MarketPosition, fill.Quantity, fill.Time))
                return;

            // ── R5: Strategy-order filter (v1.1.2) ─────────────────────────────
            // When the user has declared they run automated NinjaScript
            // strategies alongside discretionary trading, exclude strategy-
            // sourced fills so PSI only reflects manual decisions.  The NT8
            // Cbi.Order API does not expose a Strategy reference; the best
            // available proxy is FromEntrySignal which is non-empty on any
            // fill whose closing order was generated by a NinjaScript strategy
            // exit signal.  ATM hotkey, Chart Trader, and SuperDOM fills all
            // leave FromEntrySignal empty, so those always pass.
            if (_profile?.ExcludeStrategyOrders == true &&
                !string.IsNullOrEmpty(fill.Order?.FromEntrySignal))
            {
                Log(string.Format(
                    "[TradeMonitor] R5 skip strategy-owned fill {0} qty={1} signal={2}",
                    instrName, fill.Quantity, fill.Order.FromEntrySignal),
                    LogLevel.Information);
                return;
            }

            // ── Playback rewind / account reset detection ──────────────────────
            // When NinjaTrader Playback is reset or rewound, new fills arrive with
            // timestamps earlier than the last known fill.Time.  The position-tracking
            // dicts and PSI engine still hold state from the previous run, causing
            // completely wrong isClosingFill detection and PSI values.
            // Detection: TradingClock.IsPlaybackRewind compares fill.Time against the
            // last anchored fill platform time.  The anchor is updated AFTER this block
            // (via RecordFillAnchor at the end of fill ingestion), so the comparison
            // always sees the previous fill's timestamp.
            if (_clock.IsPlaybackRewind(fill.Time, PlaybackRewindToleranceMinutes))
            {
                Log("[TradeMonitor] Playback rewind detected (fill " +
                    fill.Time.ToString("HH:mm:ss") + " < last " +
                    _clock.LastFillPlatformTime.ToString("HH:mm:ss") + ") — resetting session state.",
                    LogLevel.Warning);

                // Clear all stale position tracking.
                _positionDirections.Clear();
                _positionEntryPrices.Clear();
                _positionEntryTimes.Clear();
                _positionQuantities.Clear();
                _positionMinPnl.Clear();
                _lifecycles.Clear();
                _retiringLifecycles.Clear();  // clear any pending recording state
                _fillDedup.Clear();
                // [Axiom A4] Reset inter-trade-gap anchor — the first trade
                // after a session rollover must NOT be treated as a rapid
                // re-entry against yesterday's last close.
                _lastRoundTripCloseTime = DateTime.MinValue;

                _partialCloseGate.Clear();
                _desyncRepairGate.Clear();
                _clock.ClearFillAnchor();
                _prevPollHadOpenPosition = false;   // new replay run — no positions tracked yet

                // Force re-detection of session date on the next fill.
                _lastSessionDate = DateTime.MinValue;

                // Restart PSI engine and baseline for the new Playback run.
                double currentPsi = _engine.CurrentPsi;
                _engine.StartNewSession(currentPsi);
                ResetCommitAttributionTracking();
                if (!_baselineRecordingSuspended)
                    _baseline.StartNewSession(currentPsi, LogWarning);
                _currentSession = new SessionData
                {
                    Date         = DateTime.MinValue,
                    PrevFinalPsi = currentPsi,
                };
                _sessionPnl = 0.0;
            }
            // Capture the previous fill time BEFORE calling RecordFillAnchor so
            // that the session-boundary code below can compute the true overnight
            // gap between the last fill of the previous session and this fill.
            DateTime prevFillTime = _clock.LastFillPlatformTime;

            // Anchor the TradingClock so PollTime can synthesise a Playback-
            // domain poll time advancing at wall-clock rate while a position is
            // held.  (Live mode: anchor is unused because PollTime returns
            // DateTime.Now directly.)  Also advances the IsPlaybackRewind baseline.
            _clock.RecordFillAnchor(fill.Time);

            // ── Session-boundary detection ─────────────────────────────────────
            // Session day boundary = calendar midnight.  D6 (trading-outside-window)
            // still uses profile.SessionStart — that is a penalty boundary, not a
            // day-reset boundary.  Decoupling these two concepts means a pre-market
            // fill at 6:28 AM (with SessionStart = 6:30 AM) correctly belongs to
            // today's session rather than yesterday's.
            DateTime sessionAnchorDate = GetSessionAnchorDate(fill.Time);
            if (sessionAnchorDate != _lastSessionDate)
            {
                if (_lastSessionDate != DateTime.MinValue)
                {
                    // B2: emit end-of-session PSI summary BEFORE resetting the
                    // engine so peaks / durations / counters are still live.
                    try { Log(_engine.BuildSessionSummary(), LogLevel.Information); }
                    catch { /* summary is diagnostic-only; never break archival */ }

                    // ── Archive the session that just ended ────────────────────
                    _currentSession.Flush(fill.Time);
                    var archived = _currentSession;

                    // Persist to the rolling 5-year history file.
                    _historyStore?.Append(archived.ToHistoryEntry(), LogWarning);
                    QueueSessionDetailSave(archived);

                    // Start a fresh session, carrying forward the prev-session ref.
                    // Use LastFillPsi (not FinalPsi) so the comparison reflects the
                    // trader's psychological state when they STOPPED TRADING, not the
                    // partially recovered value that accumulates during post-trade idle.
                    _currentSession = new SessionData
                    {
                        Date         = sessionAnchorDate,
                        PrevFinalPsi = archived.LastFillPsi,
                        PrevAlerts   = archived.AlertsFired,
                    };
                    _prevAlertZone     = PsiZone.Stable; // allow fresh alerts next session
                    _lastNotifPsi      = 100.0;           // reset drop-notification anchor
                    _lastAlertCountUtc = DateTime.MinValue; // reset alert dedup window

                    // Auto-open the Hub to the Session page on session end.
                    Application.Current?.Dispatcher.InvokeAsync(() =>
                    {
                        if (archived.PsiHistory.Count > 0)
                            ShowOrActivateHub(HubPage.Session);
                    });

                    // Reset the PSI engine / baseline for the new session.
                    // Use ApplyOvernightDecay with the actual elapsed hours so each C_i
                    // dimension's debt decays proportionally to the real overnight gap.
                    // (Weekend = ~60 h → more recovery than a standard 16 h overnight.)
                    double prevPsi = _engine.CurrentPsi;
                    if (!_baselineRecordingSuspended)
                        _baseline.StartNewSession(prevPsi, LogWarning);
                    double overnightHours = prevFillTime != DateTime.MinValue
                        ? Math.Max(0.0, (fill.Time - prevFillTime).TotalHours)
                        : _engine.Config.OvernightEstimatedHours;
                    _engine.ApplyOvernightDecay(overnightHours);
                    _sessionPnl   = 0.0;  // reset daily P&L for Guard conditions
                    _lastTradePnl = 0.0;

                    // Reset the HUD timeline for the new session day.
                    _uiDispatcher.BeginInvoke((Action)(() => _overlayWindow?.ResetHudSession()));

                }
                else
                {
                    // First fill ever — set the session date on the accumulator.
                    _currentSession.SetSessionDate(sessionAnchorDate);
                }
                _lastSessionDate = sessionAnchorDate;
            }

            // ── Determine whether this fill opens or closes a position ─────────
            // Open/close classification uses ONLY active/retiring lifecycles — never
            // _positionDirections. NT8 can deliver OnExecutionUpdate before
            // OnPositionUpdate mints a lifecycle; in that case both maps miss and
            // trackedDir stays Flat here → the fill is classified as entry (not
            // exit).  Stale shadow-dict state cannot mis-route that first fill.
            // Bootstrap orphan closes: wasNt8ReconcileClose (AuthoritativePosition
            // scan below) sets trackedDir from account.Positions when no lifecycle
            // exists yet a live NT8 position matches this fill as a close.
            PositionLifecycle retiringLc = null;
            _retiringLifecycles.TryGetValue(posKey, out retiringLc);

            PositionLifecycle activeLc = null;
            _lifecycles.TryGetValue(posKey, out activeLc);

            MarketPosition trackedDir = MarketPosition.Flat;
            if (retiringLc != null)
                trackedDir = retiringLc.Direction;
            else if (activeLc != null)
                trackedDir = activeLc.Direction;

            // ── NT8 Position Reconciliation ──────────────────────────────────
            // After a Playback rewind, "cleanup" close orders from the previous
            // session fire while trackedDir = Flat.  Without reconciliation
            // these are treated as new entries, poisoning all subsequent tracking.
            // Fix: if trackedDir = Flat but NT8 shows an open position in the
            // direction being sold/covered, borrow NT8's position info.
            // NT8 fires OnExecutionUpdate BEFORE OnPositionUpdate, so at this
            // moment account.Positions still reflects the PRE-fill state.
            //
            // IMPORTANT: fills processed through this path are TRACKING CORRECTIONS,
            // not independently-observed round-trips.  wasNt8ReconcileClose gates
            // isRoundTripFinal below to prevent double-counting consecutive losses.
            bool wasNt8ReconcileClose = false;
            if (trackedDir == MarketPosition.Flat && retiringLc == null && fill.Order?.Account != null)
            {
                bool isClosingDirection =
                    fill.MarketPosition == MarketPosition.Short ||
                    fill.MarketPosition == MarketPosition.Long;
                if (isClosingDirection)
                {
                    try
                    {
                        foreach (Position ntPos in fill.Order.Account.Positions)
                        {
                            if (ntPos.Instrument?.MasterInstrument !=
                                fill.Order.Instrument?.MasterInstrument) continue;
                            if (ntPos.MarketPosition == MarketPosition.Flat) continue;

                            bool matchesClose =
                                (ntPos.MarketPosition == MarketPosition.Long  && fill.MarketPosition == MarketPosition.Short) ||
                                (ntPos.MarketPosition == MarketPosition.Short && fill.MarketPosition == MarketPosition.Long);

                            if (matchesClose)
                            {
                            Log(string.Format(
                                "[TradeMonitor] NT8 reconcile: trackedDir=Flat but NT8 has {0} {1} {2} — treating fill as close.",
                                ntPos.MarketPosition, ntPos.Quantity, instrName),
                                LogLevel.Warning);
                            wasNt8ReconcileClose = true;
                            trackedDir = ntPos.MarketPosition;
                            _positionDirections[posKey] = trackedDir;
                            Log(string.Format("[TradeMonitor] DIRSET {0}={1} [site=NT8reconcile fill={2}]",
                                posKey, trackedDir, fill.Time.ToString("HH:mm:ss.fff")), LogLevel.Information);
                                _positionQuantities[posKey] = ntPos.Quantity;
                                if (!_positionEntryPrices.ContainsKey(posKey))
                                    _positionEntryPrices[posKey] = ntPos.AveragePrice;
                                if (!_positionEntryTimes.ContainsKey(posKey))
                                    _positionEntryTimes[posKey] = fill.Time;
                                break;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        LogMonitorException("NT8 reconcile (position scan)", ex);
                    }
                }
            }

            bool isClosingFill = trackedDir != MarketPosition.Flat && (
                (trackedDir == MarketPosition.Long  && fill.MarketPosition == MarketPosition.Short) ||
                (trackedDir == MarketPosition.Short && fill.MarketPosition == MarketPosition.Long));

            // Reversal detection: retiring lifecycle (old leg) + active lifecycle (new leg)
            // in opposite directions.  The fill closes the old leg AND opens a new one.
            bool isReversal  = false;
            double closingQty = fill.Quantity;
            if (isClosingFill && retiringLc != null && activeLc != null
                && activeLc.Direction != retiringLc.Direction)
            {
                isReversal = true;
                closingQty = retiringLc.QtyAtLastScaleIn; // only closing portion has realised P&L
            }

            // ── Hold time ─────────────────────────────────────────────────────
            // Computed here so PSI engine always receives an accurate holdSeconds.
            // isFullClose is determined after PnL accumulation; for the lifecycle
            // path it depends on PostLastScaleInCloseQty (updated in PnL section).
            double holdSeconds = 0.0;
            if (isClosingFill)
            {
                DateTime entryTimeForHold;
                if (_positionEntryTimes.TryGetValue(posKey, out entryTimeForHold))
                    holdSeconds = Math.Max(0, (fill.Time - entryTimeForHold).TotalSeconds);
                else if (retiringLc != null)
                    holdSeconds = Math.Max(0, (fill.Time - retiringLc.EntryTime).TotalSeconds);
                else if (activeLc != null)
                    holdSeconds = Math.Max(0, (fill.Time - activeLc.EntryTime).TotalSeconds);
            }
            else
            {
                // Entry or scale-in.
                // If trackedDir == Flat this is a brand-new position → always stamp entry time.
                // If trackedDir matches fill direction it's a scale-in → keep original entry time.
                if (trackedDir == MarketPosition.Flat)
                    _positionEntryTimes[posKey] = fill.Time;
                else
                    _positionEntryTimes.TryAdd(posKey, fill.Time);

                // Update lifecycle entry time with actual fill time (more accurate than
                // FillAlignedTime used in MintLifecycle — NT8 fires OnPositionUpdate before
                // OnExecutionUpdate, so entry fill time wasn't available at mint time).
                if (activeLc != null && trackedDir == MarketPosition.Flat)
                    activeLc.EntryTime = fill.Time;

                // NT8 usually fires OnPositionUpdate before OnExecutionUpdate, so
                // fill.Account.Positions often already reflects the post-fill state.
                bool posFound = false;
                try
                {
                    foreach (Position pos in fill.Account.Positions)
                    {
                        if (pos.Instrument == fill.Instrument &&
                            pos.MarketPosition != MarketPosition.Flat)
                        {
                            _positionEntryPrices[posKey] = pos.AveragePrice;
                            _positionDirections[posKey]  = pos.MarketPosition;
                            Log(string.Format("[TradeMonitor] DIRSET {0}={1} [site=posFound qty={2} fill={3}]",
                                posKey, pos.MarketPosition, pos.Quantity, fill.Time.ToString("HH:mm:ss.fff")), LogLevel.Information);
                            _positionQuantities.AddOrUpdate(posKey, fill.Quantity,
                                                            (k, old) => old + fill.Quantity);
                            posFound = true;
                            break;
                        }
                    }
                }
                catch (Exception ex)
                {
                    LogMonitorException("Position sync after entry fill", ex);
                }

                if (!posFound)
                {
                    _positionDirections[posKey] = fill.MarketPosition;
                    Log(string.Format("[TradeMonitor] DIRSET {0}={1} [site=fallback(no-pos) fillAction={2} fill={3}]",
                        posKey, fill.MarketPosition, fill.Order?.OrderAction, fill.Time.ToString("HH:mm:ss.fff")), LogLevel.Information);
                    _positionQuantities.AddOrUpdate(posKey, fill.Quantity,
                                                    (k, old) => old + fill.Quantity);
                    _positionEntryPrices.TryAdd(posKey, fill.Price);
                }
            }

            // ── Fill direction (for PsiEngine D1 reversal detection) ──────────
            int fillDirection = 0;
            if (!isClosingFill)
            {
                if      (fill.MarketPosition == MarketPosition.Long)  fillDirection =  1;
                else if (fill.MarketPosition == MarketPosition.Short) fillDirection = -1;
            }
            else
            {
                if      (trackedDir == MarketPosition.Long)  fillDirection =  1;
                else if (trackedDir == MarketPosition.Short) fillDirection = -1;
            }

            // ── PnL and outcome ───────────────────────────────────────────────
            // For reversals, only the closing portion (closingQty) generates realised P&L.
            double pnl   = 0.0;
            double size  = fill.Quantity;
            bool   isRealizedFill = isClosingFill;

            // ── Gross P&L (price movement only, no fees) ─────────────────────────
            // PSI monitors discipline: did the trade go in the intended direction?
            // Commissions and fees are a business cost, not a discipline signal.
            // A trade that moved the right way is a WIN regardless of commission.
            // Single code path: no NT8 API calls, no timing dependencies, works
            // identically on Live, Simulation, and Playback connections.
            if (isRealizedFill && trackedDir != MarketPosition.Flat
                && _positionEntryPrices.TryGetValue(posKey, out double entryPrice))
            {
                double pointValue = fill.Instrument.MasterInstrument.PointValue;
                if (pointValue <= 0) pointValue = 1.0;

                pnl = trackedDir == MarketPosition.Long
                    ? (fill.Price - entryPrice) * closingQty * pointValue
                    : (entryPrice - fill.Price) * closingQty * pointValue;
            }

            bool isWin = pnl > 0;

            // ── Lifecycle PnL accumulation (replaces _pendingPartialPnl/Qty) ──
            // Accumulate pnl and closing qty into the lifecycle object so that
            // TryRecordTrade sees the complete round-trip values.
            PositionLifecycle lcForAccumulation = retiringLc ?? activeLc;
            if (isRealizedFill && lcForAccumulation != null)
            {
                lcForAccumulation.AccumulatedPnl          += pnl;
                lcForAccumulation.PostLastScaleInCloseQty += (int)closingQty;
                lcForAccumulation.LastCloseFillTime        = fill.Time;
            }

            // isFullClose: true when accumulated close fills have matched the open quantity.
            //
            // Path A (REMOVE fired first): check retiringLc qty — original behaviour.
            // Path B (fills arrive before REMOVE): check activeLc qty.  TryRecordTrade
            // still gates on IsRemoved=true so premature session recording cannot occur.
            // isRoundTripFinal correctly fires so _consecutiveLosses and Guard see the
            // round-trip result immediately rather than waiting for the REMOVE event.
            bool isFullClose = false;
            if (isRealizedFill && retiringLc != null)
                isFullClose = retiringLc.PostLastScaleInCloseQty >= retiringLc.QtyAtLastScaleIn;
            else if (isRealizedFill && activeLc != null)
                isFullClose = activeLc.PostLastScaleInCloseQty >= activeLc.QtyAtLastScaleIn;

            // For the NT8 reconcile path (no lifecycle), fall back to shadow-qty
            // detection — these fills are not tracked for recording anyway
            // (wasNt8ReconcileClose=true gates isRoundTripFinal=false below).
            if (isRealizedFill && retiringLc == null && activeLc == null && wasNt8ReconcileClose)
            {
                double trackedQtyFallback;
                if (_positionQuantities.TryGetValue(posKey, out trackedQtyFallback))
                {
                    double remainingFallback = trackedQtyFallback - fill.Quantity;
                    isFullClose = remainingFallback <= 0.01;
                    if (isFullClose)
                        _positionQuantities.TryRemove(posKey, out _);
                    else
                        _positionQuantities[posKey] = remainingFallback;
                }
                else
                {
                    isFullClose = true; // qty key absent — assume full close
                }
            }

            // ── Inter-trade gap for D1 revenge personalisation ────────────────
            if (isRealizedFill && isFullClose && !_baselineRecordingSuspended)
            {
                DateTime entryTimeGap;
                if (_positionEntryTimes.TryGetValue(posKey, out entryTimeGap))
                {
                    if (_lastRoundTripCloseTime != DateTime.MinValue)
                    {
                        double gapSec = (entryTimeGap - _lastRoundTripCloseTime).TotalSeconds;
                        if (gapSec >= 0.0 && gapSec <= 86400.0)
                            _baseline.UpdateInterTradeGap(gapSec);
                    }
                    _lastRoundTripCloseTime = fill.Time;
                }
            }

            // ── roundTripPnl for PSI engine ────────────────────────────────────
            // Use accumulated lifecycle PnL when available; fall back to single-fill pnl.
            double roundTripPnl = lcForAccumulation != null && isRealizedFill
                ? lcForAccumulation.AccumulatedPnl
                : pnl;
            bool roundTripWin = roundTripPnl > 0;

            // Reversal new-position tracking (entry side).
            if (isClosingFill && isFullClose && isReversal)
            {
                double newQty = fill.Quantity - closingQty;
                MarketPosition newDir = fill.MarketPosition;
                _positionDirections[posKey]  = newDir;
                Log(string.Format("[TradeMonitor] DIRSET {0}={1} [site=reversal excess={2} fill={3}]",
                    posKey, newDir, newQty, fill.Time.ToString("HH:mm:ss.fff")), LogLevel.Information);
                _positionQuantities[posKey]  = newQty;
                _positionEntryPrices[posKey] = fill.Price;
                _positionEntryTimes[posKey]  = fill.Time;
                // Update new lifecycle entry time with actual fill time.
                if (activeLc != null)
                    activeLc.EntryTime = fill.Time;
            }

            // Baseline update: only on full close with accumulated round-trip stats.
            if (isRealizedFill && isFullClose && !_baselineRecordingSuspended)
                _baseline.UpdateOnExecution(roundTripPnl, fill.Quantity, holdSeconds, roundTripWin);

            // Violation frequency counters.
            if (!_baselineRecordingSuspended)
            {
                _baseline.TotalTradeEvents++;
                TimeSpan tod = fill.Time.TimeOfDay;
                if (tod < _profile.SessionStart || tod > _profile.SessionEnd)
                    _baseline.SessionWindowViolCount++;
            }

            // ── PSI calculation ───────────────────────────────────────────────
            ExitKind exitKind = InferExitKind(fill, isClosingFill, isReversal);
            bool isRoundTripFinal = !isRealizedFill || (isFullClose && !wasNt8ReconcileClose);

            double preExecPsi = _engine.CurrentPsi;
            var postFillSnaps = BuildPositionSnapshots(fill.Time);
            double newPsi = _engine.ProcessExecution(
                pnl, size, fill.Time, isWin, holdSeconds, postFillSnaps, fillDirection,
                exitKind, isRoundTripFinal, roundTripPnl);

            // Accumulate realised P&L for Guard condition evaluation.
            if (pnl != 0.0) _sessionPnl += pnl;

            // Track last-trade P&L for SingleTradeLossExceeds Guard condition.
            if (isRealizedFill && isFullClose)
                _lastTradePnl = roundTripPnl;

            // ── Session trade stats (lifecycle-gated, M4) ─────────────────────
            // TryRecordTrade is called from the lifecycle gate; inline here only
            // for the fills-before-Remove full-close case where the lifecycle is
            // still in _lifecycles (TryRecordTrade gate will fail on IsRemoved=false,
            // so REMOVE will handle final recording).
            // RecordEntry: for entry fills, gate on IsPostBootstrap only.
            if (isRealizedFill && isFullClose && lcForAccumulation != null)
                TryRecordTrade(lcForAccumulation);

            if (!isClosingFill && IsPostBootstrap(fill.Account))
            {
                _currentSession.RecordEntry(fill.Time, newPsi,
                    _engine.ScoreD1, _engine.ScoreD2, _engine.ScoreD3,
                    _engine.ScoreD4, _engine.ScoreD5, _engine.ScoreD6, _engine.ScoreD7);
            }

            // ── Update HUD journal trade context ───────────────────────────────
            if (isRealizedFill && isFullClose && _overlayWindow != null)
            {
                string dir = trackedDir == MarketPosition.Long ? "Long"
                           : trackedDir == MarketPosition.Short ? "Short"
                           : "Flat";
                _overlayWindow.UpdateLastTradeContext(
                    _currentSession.TotalTrades, dir, roundTripPnl);
            }

            // ── HUD update ────────────────────────────────────────────────────
            PushPsiToHud(newPsi, fromFill: true, eventTime: fill.Time);

            // ── Diagnostic log ────────────────────────────────────────────────
            double loggedNetQty = 0.0;
            _positionQuantities.TryGetValue(posKey, out loggedNetQty);
            Log(
                string.Format(
                    "[TradeMonitor] {0} | {1} | {2} | qty:{3} | raw D1:{4:F2} D2:{5:F2} D3:{6:F2} D4:{7:F2} D5:{8:F2} D6:{9:F2} D7:{10:F2} | debt D1:{11:F1} D2:{12:F1} D3:{13:F1} D4:{14:F1} D5:{15:F1} D6:{16:F1} D7:{17:F1} | PnL:{18:F2} | hold:{19:F0}s | PSI:{20:F1}→{21:F1}",
                    fill.Time.ToString("HH:mm:ss.fff"),
                    isRealizedFill ? "EXIT " : "ENTRY",
                    instrName,
                    (int)loggedNetQty,
                    _engine.ScoreD1, _engine.ScoreD2, _engine.ScoreD3,
                    _engine.ScoreD4, _engine.ScoreD5, _engine.ScoreD6, _engine.ScoreD7,
                    _engine.DebtD1,  _engine.DebtD2,  _engine.DebtD3,
                    _engine.DebtD4,  _engine.DebtD5,  _engine.DebtD6,  _engine.DebtD7,
                    pnl,
                    holdSeconds,
                    preExecPsi,
                    newPsi),
                LogLevel.Information);

            if (isClosingFill && isFullClose && !isReversal)
            {
                // Clean up only for genuine flat closes (not reversals — those already
                // set up new position tracking in the reversal block above).
                _positionEntryPrices.TryRemove(posKey, out _);
                _positionDirections.TryRemove(posKey, out _);
                _positionMinPnl.TryRemove(posKey, out _);
                if (isRealizedFill)
                    _positionEntryTimes.TryRemove(posKey, out _);
                if (!wasNt8ReconcileClose)
                    _positionQuantities.TryRemove(posKey, out _);
            }
        }

        // =====================================================================
        // Order-update event handler  (NT8 account thread)
        // Used to detect D2 (stop-loss manipulation) and D6 (SL range violation).
        // =====================================================================

        private void OnOrderUpdate(object sender, OrderEventArgs e)
        {
            if (e?.Order == null)    return;
            if (!_monitoringEnabled) return;

            Order order = e.Order;

            // Only track actively working stop orders.
            if (order.OrderState != OrderState.Working)  return;
            if (order.StopPrice  <= 0)                   return;
            if (order.OrderType  != OrderType.StopMarket &&
                order.OrderType  != OrderType.StopLimit)  return;
            if (order.Instrument?.MasterInstrument == null) return;

            try
            {
                double tickSize = order.Instrument.MasterInstrument.TickSize;
                if (tickSize <= 0) return;

                // Find the active position to determine the entry price.
                double entryPrice = 0.0;
                foreach (Position pos in order.Account.Positions)
                {
                    if (pos.Instrument == order.Instrument &&
                        pos.MarketPosition != MarketPosition.Flat)
                    {
                        entryPrice = pos.AveragePrice;
                        break;
                    }
                }

                if (entryPrice <= 0) return;

                // SL width in ticks = absolute distance from entry to stop.
                double slTicks = Math.Abs(entryPrice - order.StopPrice) / tickSize;
                if (slTicks <= 0) return;

                // Forward to engine (D2 adverse-move tracking + D6 SL compliance).
                //
                // ProcessOrderChange takes ONLY the order-id + SL width.
                // No timestamp, no position snapshots, no AdvanceTime.
                // Continuous-state (D5/D3/D2 naked) is advanced exclusively
                // from ProcessExecution (fill.Time) and PollPositions (UI-thread
                // EngineTime) — the two callers with authoritative time anchors.
                // See ARCHITECTURE.md §11 Landmine 13 + psi-v2-evidence-accumulator
                // rule 11.
                _engine.ProcessOrderChange(order.Id.ToString(), slTicks);
                PushPsiToHud(_engine.CurrentPsi, eventTime: _clock.FillAlignedTime);
            }
            catch (Exception ex)
            {
                LogMonitorException("OnOrderUpdate (SL tracking)", ex);
            }
        }

        // =====================================================================
        // Position-update event handler  (NT8 account thread)
        // Provides IMMEDIATE detection of positions that go flat without a
        // corresponding ExecutionUpdate — the primary case being an account
        // reset (Playback/Simulation restart) that clears the position without
        // firing a close execution.
        //
        // Race-condition contract:
        //   NT8 fires PositionUpdate BEFORE ExecutionUpdate for the same fill.
        //   Clearing our shadow state here for a NORMAL close would cause the
        //   subsequent ExecutionUpdate to see trackedDir=Flat and treat the
        //   close fill as a new entry — the exact ghost-state bug we are fixing.
        //
        //   We therefore clear ONLY when the flat event cannot be explained by
        //   a normal close fill:
        //     • There are no open close-direction working orders.
        //   If working orders exist, ExecutionUpdate will handle the close fill
        //   and we must not race it.
        //   If pending partial PnL exists but NO working orders remain, that means
        //   the account was reset mid-ATM-sequence and the pending state is orphaned
        //   — we clear it along with all other ghost state.
        // =====================================================================

        /// <summary>
        /// Invoked by <see cref="TradingClock.ModeChanged"/> when the active
        /// trading mode transitions (Live ↔ Playback ↔ Simulation).  A mode
        /// transition means we are crossing time domains — integrating EWMA
        /// across the boundary would integrate e.g. 8 hours of wall-clock onto
        /// a playback anchor, collapsing C_i to near-zero.  We therefore reset
        /// the engine's clock anchor; C_i, PSI and session state are preserved
        /// (the trader's history persists through mode swaps, only the clock
        /// is re-synchronised on the next event).
        /// </summary>
        private void OnTradingModeChanged(TradingMode previous, TradingMode current)
        {
            Log(string.Format(
                "[TradeMonitor] TradingClock mode transition {0} → {1}. Resetting engine clock anchor.",
                previous, current),
                LogLevel.Information);

            _engine?.ResetClockAnchor();
            _clock.ClearFillAnchor();
            _prevPollHadOpenPosition = false;   // mode change — domain reset

            // Cross-session ghost contamination fix (Bug 2, 2026-04-24).
            // A mode transition (e.g. Live→Playback, Unknown→Playback after Market Replay
            // restart) crosses time domains.  Any position tracked from the previous domain
            // is now stale — its direction, entry time, and lifecycle ID are all invalid in
            // the new domain.  If we leave _positionDirections intact, the first fill in the
            // new session sees e.g. trackedDir=Long (from a prior Playback session), triggers
            // "Stale direction cleared", and silently discards whatever lifecycle was open —
            // causing the new session's Trade-1 to be miscounted.
            //
            // Clearing ALL position-tracking state here is the correct architectural action:
            // the previous domain's open trades cannot be reconciled across the boundary.
            // In-flight observed lifecycles are lost (they will not appear in TotalTrades),
            // but this is the same outcome as before the fix — we are not regressing.
            ClearAllPositionTrackingState("mode-transition");

            // Refresh HUD badge so the banner reflects the new mode promptly.
            string hudBadge = GetHudBadgeText();
            Application.Current?.Dispatcher.InvokeAsync(
                () => _overlayWindow?.UpdateBaselineStatus(hudBadge));
        }

        /// <summary>
        /// Atomically clear every position-tracking dictionary and bridge dict.
        /// Called on mode transitions (Live↔Playback↔Sim) to prevent stale state
        /// from one time domain contaminating the next.
        /// Does NOT clear behavioural debt (C_i), session PnL, streak counters, or
        /// PSI — those are psychological facts that survive a domain boundary.
        /// </summary>
        private void ClearAllPositionTrackingState(string reason)
        {
            _positionDirections.Clear();
            _positionQuantities.Clear();
            _positionEntryTimes.Clear();
            _positionEntryPrices.Clear();
            _positionMinPnl.Clear();

            int lifecycleCount = _lifecycles.Count + _retiringLifecycles.Count;
            if (lifecycleCount > 0)
            {
                Log(string.Format(
                    "[TradeMonitor] ClearAllPositionTrackingState [{0}]: retiring {1} in-flight lifecycle(s) without RecordTrade (cross-domain, PnL unavailable).",
                    reason, lifecycleCount), LogLevel.Warning);
            }
            _lifecycles.Clear();
            _retiringLifecycles.Clear();

            _engine?.OnPositionTrackingCorrection();
            // When ALL lifecycles are cleared (mode transition), the session
            // entry counter is also invalid — it counts lifecycle ADDs that no
            // longer exist.  Reset so D7's saturating-marginal curve starts
            // fresh and does not begin pre-saturated by phantom entries from
            // the previous mode epoch.  OnPositionTrackingCorrection alone
            // intentionally preserves these counters (single-position
            // reconcile semantics); this explicit call covers the full-clear.
            _engine?.ResetSessionEntryCounters();
            _lastSessionDate = DateTime.MinValue;
            _partialCloseGate.Clear();
            _desyncRepairGate.Clear();

            Log(string.Format("[TradeMonitor] All position tracking cleared [{0}].", reason),
                LogLevel.Information);
        }

        /// <summary>
        /// Full epoch reset triggered when a new Account object reference is detected
        /// in <see cref="TrySubscribeAccount"/> without a prior Disconnect event
        /// (e.g. Market Replay timeline scrub).
        ///
        /// Any AddOn state that was built from the "future" (pre-rewind fills) is now
        /// invalid — incoming fills from the rewound timeline will collide with it
        /// unless we clear it first ("Memory of the Future" guard).
        ///
        /// This method is the named, documented equivalent of the anonymous playback-rewind
        /// reset block in <see cref="OnExecutionUpdate"/> (lines ~998–1033).  Both paths
        /// must be kept in sync: any state added to one must be added to the other.
        ///
        /// Thread-safety: all operations are safe from any thread.  The ConcurrentDictionary
        /// clears are atomic.  Engine/clock methods use their own locks (_sync).
        /// _currentSession and _sessionPnl assignments are pointer-sized — atomic on .NET.
        /// The existing OnExecutionUpdate rewind block runs these same operations on the
        /// fill-processing background thread, proving thread-safety at every call site.
        ///
        /// Called synchronously from TrySubscribeAccount AFTER old handlers are removed
        /// and BEFORE new handlers are wired — the only window in which no fill can
        /// arrive from either epoch (old object unsubscribed, new object not yet wired).
        /// </summary>
        private void ResetForNewEpoch(string accountName)
        {
            Log(string.Format(
                "[TradeMonitor] Epoch reset for '{0}' — clearing stale state from prior timeline ('Memory of the Future' guard).",
                accountName), LogLevel.Warning);

            // 1. Clear all position-tracking tables and lifecycle state.
            //    Matches ClearAllPositionTrackingState: 7 posKey dicts, lifecycle tables,
            //    OnPositionTrackingCorrection, _lastSessionDate, gate dicts.
            ClearAllPositionTrackingState("epoch-rewind:" + accountName);

            // 2. Reset clock anchors and mode.  Returning the clock to Unknown
            //    allows the next fill to re-establish the mode cleanly.  This
            //    is the ONLY legitimate place to leave Live mode — fills alone
            //    must not downgrade it (prevents Replikanto Sim-copy oscillation).
            _engine?.ResetClockAnchor();
            _clock.ClearFillAnchor();
            _clock.ResetMode();
            _prevPollHadOpenPosition = false;   // session reset — domain reset

            // 3. Clear fill-dedup, RPL snapshots, PnL drift gates, and inter-trade-gap
            //    anchor.  Same as the playback-rewind block in OnExecutionUpdate.
            _fillDedup.Clear();
            _lastRoundTripCloseTime = DateTime.MinValue;

            // 4. Start a fresh session on all session-stateful components.
            double currentPsi = _engine?.CurrentPsi ?? 100.0;
            _engine?.StartNewSession(currentPsi);
            ResetCommitAttributionTracking();
            if (!_baselineRecordingSuspended)
                _baseline?.StartNewSession(currentPsi, LogWarning);
            _currentSession = new SessionData
            {
                Date         = DateTime.MinValue,
                PrevFinalPsi = currentPsi,
            };
            _sessionPnl = 0.0;

            Log(string.Format(
                "[TradeMonitor] Epoch reset complete for '{0}'. PSI={1:F1}.",
                accountName, currentPsi), LogLevel.Information);
        }

        // =====================================================================
        // [M2 — Axiom A2] Position-lifecycle edge routing (log-only in M2)
        // =====================================================================
        // Derives edges (Add / Update / Remove / Reversal) from the state
        // diff between our stored _lifecycles entry and NT8's authoritative
        // post-event position — NOT from e.Operation.  This is deliberate
        // because NT8 legitimately collapses a Remove+Add reversal into a
        // single Operation=Update event "when there is no flat state between"
        // (see NT8 PositionUpdate docs).  Deriving edges from state diff
        // makes the edge set complete regardless of how NT8 packages them.
        //
        // In M2 this routine ONLY updates _lifecycles and emits diagnostic
        // logs.  It does NOT modify _sessionPnl, _positionDirections,
        // _sessionEntryCount, or call the engine.  M4 is the cutover that
        // replaces RecordTrade/RecordEntry invocation with this edge stream.
        //
        // Axiom A3 — observed-origin gating:
        //   Add edges arriving within BootstrapReplayWindow of the account
        //   subscription are considered "observed orphans" (NT8 is replaying
        //   already-open positions on subscription bootstrap, post-restart or
        //   post-replay-rewind).  These lifecycles carry OriginObserved=false;
        //   M4 will gate RecordTrade on OriginObserved=true, ensuring such
        //   orphan lifecycles never inflate the session trade count.
        // =====================================================================

        private void ProcessLifecycleEdge(
            string posKey,
            Account account,
            PositionEventArgs e)
        {
            // ── ROOT-FIX (2026-04-24): event snapshot, not mutable reference ────
            // PositionEventArgs.MarketPosition / .Quantity are immutable snapshots
            // of the position state at event-firing time (i.e. what NT8 logs in
            // the CSV trace).  e.Position is a reference to the live, mutable
            // Position object owned by Account.Positions[i] — it can be torn
            // mid-update when our callback runs, returning a half-old half-new
            // mix (e.g. dir=Long but qty=0).  All edge classification MUST go
            // through the event snapshot.  See ARCHITECTURE.md §15 / IntegrityCheck.
            ReconcileLifecycleEdgeAtomic(posKey, account, e.MarketPosition, e.Quantity,
                                         source: "PositionUpdate");
        }

        /// <summary>
        /// Atomic-input edge reconciler.  All lifecycle edge classification flows
        /// through this single method, regardless of whether the trigger was a
        /// real <see cref="PositionEventArgs"/> (live runtime) or a synthetic
        /// "what NT8 says now" reading from the IntegrityCheck repair path.
        /// </summary>
        /// <remarks>
        /// Inputs are required to be a coherent snapshot — both <paramref name="postDir"/>
        /// and <paramref name="postQty"/> describe the same instant.  This is
        /// guaranteed by:
        ///   • PositionEventArgs.MarketPosition / .Quantity (event-firing snapshot)
        ///   • IntegrityCheck.Run reading account.Positions atomically
        /// </remarks>
        private void ReconcileLifecycleEdgeAtomic(
            string         posKey,
            Account        account,
            MarketPosition postDir,
            double         postQty,
            string         source)
        {
            PositionLifecycle existing;
            bool hadLife = _lifecycles.TryGetValue(posKey, out existing);

            // (1) no lifecycle & flat  → idle, nothing to do
            if (!hadLife && postDir == MarketPosition.Flat) return;

            // (2) no lifecycle & non-flat  → ADD edge
            if (!hadLife)
            {
                bool observed = IsPostBootstrap(account);
                MintLifecycle(posKey, postDir, postQty, observed,
                              cause: "ADD [" + source + "]");
                // Fire entry-decision signals (D1/D6/D7) exactly once per
                // position open.  Only for observed lifetimes — bootstrap
                // ghost positions must not inflate session counters.
                if (observed)
                    _engine.OnLifecycleAdd(_lifecycles[posKey].EntryTime);
                return;
            }

            // (3) lifecycle exists & flat  → REMOVE edge
            if (postDir == MarketPosition.Flat)
            {
                // Mark the lifecycle as removed and move it to the retiring table.
                // Close fills arriving AFTER this point will find it there and accumulate
                // PnL into lifecycle.AccumulatedPnl / PostLastScaleInCloseQty.
                // Close fills that arrived BEFORE this point already accumulated into the
                // lifecycle while it was in _lifecycles; TryRecordTrade will gate on
                // PostLastScaleInCloseQty >= QtyAtLastScaleIn AND IsRemoved=true.
                existing.IsRemoved = true;
                _retiringLifecycles[posKey] = existing;

                // RetireLifecycle removes from _lifecycles (active-position table).
                RetireLifecycle(posKey, existing, cause: "REMOVE [" + source + "]");

                // Attempt immediate recording.  Succeeds when all fills arrived before
                // Remove (fills-first path: PostLastScaleInCloseQty is already populated).
                TryRecordTrade(existing);

                // Liveness-only safety net: fires 500 ms later to catch the rare case
                // where NT8's execution stream is delayed.  NOT a correctness gate —
                // TryRecordTrade's PostLastScaleInCloseQty gate prevents premature
                // recording.  If TryRecordTrade already recorded, the call is a no-op.
                PositionLifecycle capturedLc = existing;
                System.Threading.Tasks.Task.Delay(500).ContinueWith(_ =>
                {
                    var d = _uiDispatcher;
                    if (d != null && !d.HasShutdownStarted && !d.HasShutdownFinished)
                        d.BeginInvoke((Action)(() => TryRecordTrade(capturedLc)));
                    else
                        TryRecordTrade(capturedLc); // fallback: call direct if dispatcher gone
                });
                return;
            }

            // (4) lifecycle exists & non-flat & opposite direction  → REVERSAL
            //     (NT8 delivered the transition as a single Operation.Update
            //      with no flat state between.)
            if (postDir != existing.Direction)
            {
                // Mark the old leg as removed and move to retiring table.
                existing.IsRemoved = true;
                _retiringLifecycles[posKey] = existing;

                RetireLifecycle(posKey, existing,
                                cause: "REMOVE (reversal leg A) [" + source + "]");

                // Attempt immediate recording (handles fills-before-Remove ordering).
                TryRecordTrade(existing);

                // Liveness safety net for the reversal closing leg.
                PositionLifecycle capturedRevLc = existing;
                System.Threading.Tasks.Task.Delay(500).ContinueWith(_ =>
                {
                    var d = _uiDispatcher;
                    if (d != null && !d.HasShutdownStarted && !d.HasShutdownFinished)
                        d.BeginInvoke((Action)(() => TryRecordTrade(capturedRevLc)));
                    else
                        TryRecordTrade(capturedRevLc);
                });

                // Mint the new opening leg.
                bool newObserved = IsPostBootstrap(account);
                MintLifecycle(posKey, postDir, postQty, newObserved,
                              cause: "ADD (reversal leg B) [" + source + "]");
                // Fire entry-decision signals for the new position leg.
                if (newObserved)
                    _engine.OnLifecycleAdd(_lifecycles[posKey].EntryTime);
                return;
            }

            // (5) lifecycle exists & non-flat & same direction  → UPDATE
            double oldMax = existing.MaxQtySeen;
            if (postQty > existing.MaxQtySeen)
            {
                // Scale-in: position grew.  Reset close-qty accumulator so that the
                // new close batch (filling the now-larger position) is correctly gated.
                existing.MaxQtySeen              = postQty;
                existing.QtyAtLastScaleIn        = (int)postQty;
                existing.PostLastScaleInCloseQty = 0;
            }
            // scale-OUT (postQty < existing.MaxQtySeen): do NOT reset PostLastScaleInCloseQty.
            // The closing fills have already been accumulating; keep running total.
            existing.MaxQtySeen = Math.Max(existing.MaxQtySeen, postQty);
            Log(string.Format(
                "[Lifecycle][M2] UPDATE [{6}] posKey={0} dir={1} qty={2} maxSeen={3} (was {4}) life={5:N}",
                posKey, postDir, postQty, existing.MaxQtySeen, oldMax,
                existing.LifecycleId, source), LogLevel.Information);
        }

        private bool IsPostBootstrap(Account account)
        {
            DateTime subscribedAt;
            if (!_accountSubscribedAt.TryGetValue(account.Name, out subscribedAt))
                return false; // Should not happen — we stamp on every subscribe path
            return (DateTime.UtcNow - subscribedAt) > BootstrapReplayWindow;
        }

        private void MintLifecycle(
            string posKey,
            MarketPosition dir,
            double qty,
            bool observed,
            string cause)
        {
            // EntryTime: if we've already recorded an entry-fill time for this
            // posKey via the execution stream (which may arrive before or
            // after the PositionUpdate depending on NT8 ordering — see
            // elsewhere in this file for the race notes), use it.  Else fall
            // back to the current engine time.  This detail is only used for
            // hold-seconds / D5 telemetry and does not affect trade counting.
            DateTime entryTime;
            if (!_positionEntryTimes.TryGetValue(posKey, out entryTime))
                entryTime = _clock != null ? _clock.FillAlignedTime : DateTime.UtcNow;

            var life = new PositionLifecycle
            {
                LifecycleId    = Guid.NewGuid(),
                EntryTime      = entryTime,
                MaxQtySeen     = qty,
                OriginObserved = observed,
                Direction      = dir,
                PosKey         = posKey,
                QtyAtLastScaleIn = (int)qty,
                PostLastScaleInCloseQty = 0,
                MintedAt       = DateTime.UtcNow,
            };
            _lifecycles[posKey] = life;

            // Clear any stale retiring entry for this posKey so that a rapid
            // back-to-back trade on the same instrument finds the fresh lifecycle,
            // not a remnant from the previous trade's recording window.
            _retiringLifecycles.TryRemove(posKey, out _);

            Log(string.Format(
                "[Lifecycle][M2] {0} posKey={1} dir={2} qty={3} observed={4} life={5:N} entry={6:HH:mm:ss.fff}",
                cause, posKey, dir, qty, observed, life.LifecycleId, entryTime),
                LogLevel.Information);
        }

        private void RetireLifecycle(string posKey, PositionLifecycle life, string cause)
        {
            _lifecycles.TryRemove(posKey, out _);

            Log(string.Format(
                "[Lifecycle][M2] {0} posKey={1} dir={2} maxSeen={3} observed={4} life={5:N}",
                cause, posKey, life.Direction, life.MaxQtySeen, life.OriginObserved,
                life.LifecycleId), LogLevel.Information);
        }

        // =====================================================================
        // TryRecordTrade — the single recording function (Phase 3 refactor).
        //
        // Gates:
        //   (A) lc.Recorded — idempotent; any subsequent call is a no-op.
        //   (B) lc.IsRemoved — NT8 must have confirmed flat (REMOVE fired).
        //   (C) lc.PostLastScaleInCloseQty >= lc.QtyAtLastScaleIn — all closing
        //       fills received (partial fills accumulate; gate unlocks at full qty).
        //
        // This is the ONLY function that calls _currentSession.RecordTrade.
        // In-memory update is synchronous and thread-safe (SessionData lock).
        // XML persistence is queued (QueueSessionDetailSave) — no disk I/O here.
        //
        // External-flat detection: if REMOVE fired but no close fills ever arrived
        // (PostLastScaleInCloseQty == 0 AND lc.OriginObserved), then after the 5s
        // IntegrityCheck B3 grace window fires ForceComplete, recording with PnL=0
        // and flagging it as an external flat in the log.
        // =====================================================================
        private void TryRecordTrade(PositionLifecycle lc)
        {
            try
            {
                if (lc == null)    return;
                if (lc.Recorded)   return;  // (A) idempotent
                if (!lc.IsRemoved) return;  // (B) NT8 not yet confirmed flat
                if (lc.PostLastScaleInCloseQty < lc.QtyAtLastScaleIn) return; // (C) fills still arriving

                // Atomically claim the recording slot.  If another thread somehow
                // reached this line simultaneously (500ms timer + IntegrityCheck),
                // only one will see Recorded flip from false → true.
                lc.Recorded = true;

                // Remove from the retiring table (no longer needed after recording).
                string posKey = lc.PosKey ?? string.Empty;
                _retiringLifecycles.TryRemove(posKey, out _);

                if (!lc.OriginObserved)
                {
                    Log(string.Format(
                        "[M4] RecordTrade SKIPPED {0} — OriginObserved=false (bootstrap ghost). AccumulatedPnl={1:F2}",
                        posKey, lc.AccumulatedPnl), LogLevel.Information);
                    return;
                }

                if (_engine == null || _currentSession == null) return;

                double pnl      = lc.AccumulatedPnl;
                bool   isWin    = pnl > 0;
                double holdSecs = lc.LastCloseFillTime > lc.EntryTime
                    ? Math.Max(0, (lc.LastCloseFillTime - lc.EntryTime).TotalSeconds)
                    : 0.0;

                double   closePsi  = _engine.CurrentPsi;
                double   scoreD1   = _engine.ScoreD1;
                double   scoreD2   = _engine.ScoreD2;
                double   scoreD3   = _engine.ScoreD3;
                double   scoreD4   = _engine.ScoreD4;
                double   scoreD5   = _engine.ScoreD5;
                double   scoreD6   = _engine.ScoreD6;
                double   scoreD7   = _engine.ScoreD7;
                DateTime tradeTime = lc.LastCloseFillTime != default(DateTime)
                    ? lc.LastCloseFillTime
                    : (_clock?.FillAlignedTime ?? DateTime.UtcNow);

                // Record directly — no dispatcher hop required.
                // SessionData.RecordTrade is guarded by an internal lock, making it
                // safe to call from any thread (OnPositionUpdate, timer, or integrity
                // check).  The previous InvokeAsync dispatch was silently dropping the
                // callback (proven by: DESYNC-REPAIR fires via BeginInvoke on the same
                // dispatcher, but [M4] never appears from InvokeAsync on the same
                // dispatcher — NT8's Dispatcher.CurrentDispatcher captured from
                // State.Configure may not pump InvokeAsync work items reliably).
                _currentSession.RecordTrade(tradeTime, isWin, pnl, holdSecs, closePsi,
                    scoreD1, scoreD2, scoreD3, scoreD4, scoreD5, scoreD6, scoreD7);
                _lastTradePnl = pnl;
                QueueSessionDetailSave(_currentSession);
                Log(string.Format(
                    "[M4] RecordTrade (lifecycle-gate) {0} pnl={1:F2} isWin={2} hold={3:F0}s trades={4}",
                    posKey, pnl, isWin, holdSecs, _currentSession.TotalTrades), LogLevel.Information);

                // HUD refresh — TryRecordTrade can fire from OnPositionUpdate (NT8
                // account thread) or IntegrityCheck (UI thread). PushPsiToHud must
                // run on the UI thread.  Use the same _uiDispatcher that was captured
                // on the main thread during State.Configure — the only reliable target
                // in NT8 (Application.Current?.Dispatcher resolves to null on NT8's
                // account/event threads and cannot be used here).
                // If the dispatcher is gone (shutdown race) the HUD skip is harmless
                // — State.Terminated has already stopped monitoring at that point.
                double capturedPsi   = closePsi;
                DateTime capturedTime = tradeTime;
                var disp = _uiDispatcher;
                if (disp != null && !disp.HasShutdownStarted && !disp.HasShutdownFinished)
                {
                    try
                    {
                        disp.BeginInvoke(
                            (Action)(() => PushPsiToHud(capturedPsi, fromFill: false,
                                                        eventTime: capturedTime)));
                    }
                    catch (InvalidOperationException) { /* dispatcher shut down between check and call */ }
                    catch (TaskCanceledException)     { /* dispatcher work item cancelled during teardown */ }
                }

                // Clean up aux state for this posKey — only if no new lifecycle has
                // started here (guards against wiping a live trade's state).
                // Also clear the stale direction so the NEXT trade's first fill is not
                // misclassified as a close (root cause of the EXIT-on-entry bug).
                if (!_lifecycles.ContainsKey(posKey))
                {
            _positionDirections.TryRemove(posKey, out _);
            _positionEntryTimes.TryRemove(posKey, out _);
            _positionEntryPrices.TryRemove(posKey, out _);
            _positionMinPnl.TryRemove(posKey, out _);
                }
            }
            catch (Exception ex) { LogMonitorException("TryRecordTrade", ex); }
        }

        /// <summary>
        /// Queues an XML save of the current session detail WITHOUT blocking the
        /// NT8 execution thread.
        ///
        /// Correctness guarantees:
        ///   (1) Snapshot is built SYNCHRONOUSLY on the calling thread via
        ///       SessionDetailStore.BuildSnapshot, which reads SessionData only
        ///       through its internal-lock accessors (GetTradesSnapshot,
        ///       GetPsiHistorySnapshot, GetPeakDebts).  The resulting SessionDetail
        ///       is a value-complete, fully-immutable frozen copy.  The background
        ///       worker never touches the live SessionData reference.
        ///   (2) At most one ThreadPool worker runs DrainSaveQueue at a time
        ///       (enforced by Interlocked CAS on _saveWorkerRunning).  Concurrent
        ///       calls here only enqueue; they never open the file.
        ///   (3) If rapid fills produce N snapshots before the worker fires, the
        ///       worker drains all N, keeps only the LATEST per date (each is a
        ///       full replacement write), and discards earlier stale ones — correct
        ///       because every snapshot supersedes the previous for the same file.
        /// </summary>
        private void QueueSessionDetailSave(SessionData session)
        {
            if (session == null) return;
            // Drop silently during shutdown — State.Terminated will do a final
            // synchronous write after the background worker has stopped.
            if (Volatile.Read(ref _isShuttingDown) != 0) return;

            // Build immutable snapshot on the calling thread, under SessionData's lock.
            SessionDetail snapshot = SessionDetailStore.BuildSnapshot(session);
            if (snapshot == null) return;

            _pendingSaves.Enqueue((session.Date, snapshot));

            // CAS: only one worker runs at a time.
            if (Interlocked.CompareExchange(ref _saveWorkerRunning, 1, 0) == 0)
                ThreadPool.QueueUserWorkItem(_ => DrainSaveQueue());
        }

        private void DrainSaveQueue()
        {
            try
            {
                // Drain the whole queue, keeping only the latest snapshot per date.
                // Each snapshot for a given date fully supersedes all earlier ones.
                var latest = new Dictionary<DateTime, SessionDetail>();
                (DateTime Date, SessionDetail Detail) item;
                while (_pendingSaves.TryDequeue(out item))
                    latest[item.Date] = item.Detail;

                foreach (var kv in latest)
                    SessionDetailStore.SaveDetail(kv.Key, kv.Value, LogWarning);
            }
            catch (Exception ex)
            {
                LogWarning("[TradeMonitor] Session detail save queue: " + ex.Message);
            }
            finally
            {
                // Release BEFORE the re-arm check to close the arrival race: a new
                // item enqueued between the drain loop ending and this CAS will be
                // caught by the IsEmpty check below.
                Interlocked.Exchange(ref _saveWorkerRunning, 0);

                // Do not re-arm during shutdown — Terminated will write synchronously.
                if (Volatile.Read(ref _isShuttingDown) == 0 &&
                    !_pendingSaves.IsEmpty &&
                    Interlocked.CompareExchange(ref _saveWorkerRunning, 1, 0) == 0)
                    ThreadPool.QueueUserWorkItem(_ => DrainSaveQueue());
            }
        }

        private void OnPositionUpdate(object sender, PositionEventArgs e)
        {
            if (e?.Position == null || e.Position.Instrument?.MasterInstrument == null) return;
            if (!_monitoringEnabled) return;

            var account = sender as Account;
            if (account == null) return;

            string posKey = PositionKey(account.Name, e.Position.Instrument.MasterInstrument.Name);

            // M4 lifecycle edge routing — sole owner of flat-event resolution.
            // TryRecordTrade (called synchronously from ReconcileLifecycleEdgeAtomic REMOVE case,
            // and via a 500ms liveness timer) handles all close recording.  No legacy
            // flat-cleanup or TryFallbackRecordTrade — those have been removed.
            try
            {
                ProcessLifecycleEdge(posKey, account, e);
            }
            catch (Exception lifecycleEx)
            {
                LogMonitorException("OnPositionUpdate (M2 lifecycle)", lifecycleEx);
            }
        }

        // =====================================================================
        // D5 position-hold timer  (fires on the ThreadPool every 5 seconds,
        // but marshals its body onto the UI dispatcher — Axiom A5 / M6).
        // =====================================================================
        //
        // Pre-M6 this callback ran its entire body on the System.Timers
        // ThreadPool thread.  In Playback that triggers NT8 LANDMINE 7:
        // Globals.Now returns wall-clock time off-main, so the engine
        // would accumulate a "pollTime" that kept advancing at wall-clock
        // rate even when the replay was paused — hence Bug #5 in
        // REMEDIATION_PLAN_v1.2.md.
        //
        // M6 splits the handler into two halves:
        //   (1) Timer-thread entry  — cheap dispatch onto the UI thread.
        //   (2) UI-thread body      — all clock reads + engine calls.
        //
        // _uiDispatcher is captured from State.Configure (guaranteed
        // main-thread context) so BeginInvoke has a definite target even
        // on the very first tick.  If the dispatcher is null (teardown
        // race) the tick is silently skipped.
        // =====================================================================

        private void OnPsiPollTimerElapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (!_monitoringEnabled) return;

            var dispatcher = _uiDispatcher;
            if (dispatcher == null) return;
            if (dispatcher.HasShutdownStarted || dispatcher.HasShutdownFinished) return;

            try
            {
                dispatcher.BeginInvoke((Action)PsiPollTick_OnUiThread);
            }
            catch (Exception ex)
            {
                LogMonitorException("OnPsiPollTimerElapsed (marshal)", ex);
            }
        }

        /// <summary>
        /// The engine-facing body of the PSI poll timer, always invoked on
        /// the UI (main) thread via <see cref="_uiDispatcher"/>.  This is
        /// where <c>_clock.EngineTime</c> is safe to read in Playback /
        /// Simulation modes.
        /// </summary>
        private void PsiPollTick_OnUiThread()
        {
            try
            {
                if (!_monitoringEnabled) return;

                bool hasOpenPosition = _positionDirections.Any(
                    kv => kv.Value != MarketPosition.Flat);

                TradingMode currentMode = _clock.Mode;
                bool isNonLive = currentMode == TradingMode.Playback
                              || currentMode == TradingMode.Simulation;

                // ── Open→flat domain transition (non-live only) ─────────────────
                // When a position closes in non-live mode, _lastTick is anchored
                // in the fill-time domain (historical replay timestamps).  We call
                // ResetClockAnchor() so the D5/D2 position-tracking state is cleared
                // and the NEXT AdvanceTime call re-anchors _lastTick cleanly to
                // FillAlignedTime (= LastFillPlatformTime) instead of computing a
                // large dt from a stale open-position entry time.
                //
                // NOTE: we do NOT switch to wall-clock here.  After going flat,
                // ATM bracket close-fills continue arriving via ProcessExecution and
                // keep setting _lastTick back to the replay fill-time domain.  The
                // pollTime selection below uses FillAlignedTime in all non-live cases
                // (Landmine 14 fix, 2026-04-26) so the two callers always stay in the
                // same domain.  Wall-clock is only ever used in Live mode.
                if (isNonLive && _prevPollHadOpenPosition && !hasOpenPosition)
                {
                    Log("[TradeMonitor] Non-live open→flat: re-anchoring engine clock to wall-clock domain.",
                        LogLevel.Information);
                    _engine.ResetClockAnchor();
                }
                _prevPollHadOpenPosition = hasOpenPosition;

                // ── Pre-fill early return (Axiom 5) ─────────────────────────────
                // In non-live mode, until the first fill of the session is
                // received, there is no time-domain anchor to poll in: Globals.Now
                // is wall-clock (current real time) but _positionEntryTimes will
                // store historical timestamps once trading begins.  Without a fill
                // anchor we cannot tell which domain to use, so we skip
                // PollPositions entirely and only push the static PSI to the HUD.
                // _clock.LastFillPlatformTime is the unambiguous signal: it is
                // set in OnExecutionUpdate (RecordFillAnchor) on the first fill
                // and only cleared by session reset / rewind / mode change —
                // NOT by going flat.
                if (isNonLive && _clock.LastFillPlatformTime == DateTime.MinValue)
                {
                    PushPsiToHud(_engine.CurrentPsi, eventTime: _clock.EngineTime);
                    return;
                }

                // ── pollTime selection ──────────────────────────────────────────
                // Live: wall-clock (EngineTime = DateTime.Now). Fills and clock are
                //   in the same domain so both ProcessExecution and PollPositions
                //   feed AdvanceTime compatible timestamps.
                //
                // Non-live (Playback / Simulation): ALWAYS use FillAlignedTime
                //   (= LastFillPlatformTime), regardless of whether a position is
                //   open.  This is the ONLY correct domain choice.
                //
                //   Root cause of Landmine 14 (confirmed 2026-04-26 via [PSI v2
                //   trace]): after going flat the previous code fell back to
                //   EngineTime (wall-clock) for the "flat" case.  However, ATM
                //   bracket close-fills continue arriving AFTER the position flags
                //   flat, each one calling ProcessExecution(fill.Time = historical
                //   replay timestamp) which sets _lastTick back to the replay
                //   domain.  The very next PollPositions then computed:
                //     dtRaw = Globals.Now(18:26 PM today) − fill.Time(06:30 AM Apr 16)
                //           = 906 929 s  (≈ 10.5 days)
                //   → clamped to MaxDeltaSec=600 s, gate=1.00 → all E_i wiped in
                //   one tick → PSI teleported to ~100 while the trader was still
                //   breaking rules mid-session.
                //
                //   Fix: non-live always uses FillAlignedTime = fill-time domain.
                //   The early-return above guarantees LastFillPlatformTime != MinValue
                //   when we reach this line, so FillAlignedTime returns the fill
                //   timestamp unconditionally.  Between fills dt=0 (no spurious
                //   decay); decay advances at the correct fill.Time delta on the
                //   next ProcessExecution.  Live trading is unaffected.
                DateTime pollTime;
                if (!isNonLive) pollTime = _clock.EngineTime;
                else            pollTime = _clock.FillAlignedTime;

                var snapshots = BuildPositionSnapshots(pollTime);

                bool nakedDetected;
                double newPsi = _engine.PollPositions(
                    snapshots, pollTime, out nakedDetected);

                if (!_baselineRecordingSuspended)
                {
                    _baseline.TotalPositionPolls++;
                    if (nakedDetected) _baseline.NakedPositionCount++;
                }

                if (nakedDetected)
                {
                    _currentSession.IncrementNakedPositionDetections();
                    FireNakedPositionAlert();
                }

                PushPsiToHud(newPsi, eventTime: pollTime);
            }
            catch (Exception ex)
            {
                LogMonitorException("PsiPollTick_OnUiThread", ex);
            }
        }

        // =====================================================================
        // Admin timer (thread-pool thread, every 30 seconds)
        // Account discovery / mode refresh / P&L reconciliation / Hub refresh.
        // Does NOT call PollPositions — that runs on the faster _psiPollTimer.
        // =====================================================================

        private void OnAdminTimerElapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (!_monitoringEnabled) return;

            var dispatcher = _uiDispatcher;
            if (dispatcher == null) return;
            if (dispatcher.HasShutdownStarted || dispatcher.HasShutdownFinished) return;

            try
            {
                dispatcher.BeginInvoke((Action)AdminTick_OnUiThread);
            }
            catch (Exception ex)
            {
                LogMonitorException("OnAdminTimerElapsed (marshal)", ex);
            }
        }

        /// <summary>
        /// The engine-facing body of the admin timer, always invoked on the
        /// UI (main) thread via <see cref="_uiDispatcher"/> — see the
        /// symmetric <see cref="PsiPollTick_OnUiThread"/> for the rationale.
        /// </summary>
        private void AdminTick_OnUiThread()
        {
            try
            {
                if (!_monitoringEnabled) return;

                // Refresh sim/playback/test detection so account reconnects
                // and TestMode expiry are picked up within 30 seconds.
                string oldReason = _baselineSuspendReason;
                RefreshBaselineSuspendStatus();
                if (_baselineSuspendReason != oldReason)
                {
                    string badge = GetHudBadgeText();
                    _overlayWindow?.UpdateBaselineStatus(badge);
                }

                DateTime pollTime = _clock.EngineTime;

                // Refresh Hub Session tab on the 30-second timer tick so it stays live
                _hubWindow?.UpdateSessionData(_currentSession);

                // [M3] Lifecycle parity observability — compare _lifecycles (NT8-edge
                // source of truth) against _positionDirections (legacy shadow state).
                // Any mismatch here is direct evidence that the shadow state has
                // drifted from NT8 — exactly the bug A1 is designed to eliminate.
                EmitLifecycleParityLog();
            }
            catch (Exception ex)
            {
                LogMonitorException("AdminTick_OnUiThread", ex);
            }
        }

        // =====================================================================
        // [M3 — Axiom A1] Lifecycle parity observability
        // =====================================================================
        // Emits one log per admin tick (30 s) comparing the M2 lifecycle view
        // against the legacy shadow state.  Discrepancies are logged at
        // Warning level; consistent state at Information level (so we can
        // see the healthy baseline during replay testing).  No behaviour
        // change — purely a validation probe for the M4 cutover.
        // =====================================================================
        private void EmitLifecycleParityLog()
        {
            int lifeCount     = _lifecycles.Count;
            int lifeObserved  = _lifecycles.Values.Count(l => l.OriginObserved);
            int lifeOrphan    = lifeCount - lifeObserved;

            int shadowOpen    = _positionDirections.Count(
                    kv => kv.Value != MarketPosition.Flat);

            var lifeKeys   = new HashSet<string>(_lifecycles.Keys);
            var shadowKeys = new HashSet<string>(
                _positionDirections
                    .Where(kv => kv.Value != MarketPosition.Flat)
                    .Select(kv => kv.Key));

            var onlyInLife   = lifeKeys.Except(shadowKeys).ToList();
            var onlyInShadow = shadowKeys.Except(lifeKeys).ToList();

            bool inParity = onlyInLife.Count == 0 && onlyInShadow.Count == 0
                            && lifeCount == shadowOpen;

            // M4 bridge state: posOriginObserved should hold at most one entry per
            // open lifecycle (it's the "pending gate flag" between OnPositionUpdate
            // and OnExecutionUpdate for closing fills).
            int bridgeCount = _retiringLifecycles.Count;
            int bridgeObs   = _retiringLifecycles.Count(kv => kv.Value?.OriginObserved == true);

            if (inParity && lifeCount == 0 && bridgeCount == 0) return; // idle

            string summary = string.Format(
                "[Lifecycle][M3] parity life={0} (obs={1}, orphan={2})  shadow={3}  match={4}  bridge={5}/{6}",
                lifeCount, lifeObserved, lifeOrphan, shadowOpen, inParity, bridgeObs, bridgeCount);

            if (inParity)
            {
                Log(summary, LogLevel.Information);
                }
                else
                {
                string extra = "";
                if (onlyInLife.Count   > 0) extra += "  onlyInLife=["   + string.Join(",", onlyInLife)   + "]";
                if (onlyInShadow.Count > 0) extra += "  onlyInShadow=[" + string.Join(",", onlyInShadow) + "]";
                Log(summary + extra, LogLevel.Warning);
            }
        }

        // =====================================================================
        // IntegrityCheck timer body — runs every 1 s on UI thread.
        //
        // Builds an immutable IntegritySnapshot, runs IntegrityCheck.Run, logs
        // every violation, and applies repairs that have persisted past the
        // grace window.  See IntegrityCheck.cs for the design contract.
        // =====================================================================
        private void OnIntegrityTimerElapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (!_monitoringEnabled) return;

            var dispatcher = _uiDispatcher;
            if (dispatcher == null) return;
            if (dispatcher.HasShutdownStarted || dispatcher.HasShutdownFinished) return;

            try
            {
                dispatcher.BeginInvoke((Action)IntegrityTick_OnUiThread);
            }
            catch (Exception ex)
            {
                LogMonitorException("OnIntegrityTimerElapsed (marshal)", ex);
            }
        }

        private void IntegrityTick_OnUiThread()
        {
            try
            {
                if (!_monitoringEnabled) return;

                IntegritySnapshot snap = BuildIntegritySnapshot();
                List<IntegrityViolation> violations = IntegrityCheck.Run(snap);

                if (violations.Count == 0)
                {
                    // Healthy — clear the persistence tracker so a recovered
                    // (Code, PosKey) pair doesn't carry a stale firstSeen if
                    // it reappears later.
                    _integrityFirstSeen.Clear();
                    return;
                }

                // Stable iteration order
                violations.Sort((a, b) =>
                {
                    int c = ((int)a.Severity).CompareTo((int)b.Severity);
                    if (c != 0) return -c; // Critical first
                    c = ((int)a.Code).CompareTo((int)b.Code);
                    if (c != 0) return c;
                    return string.Compare(a.PosKey, b.PosKey, StringComparison.Ordinal);
                });

                DateTime now = DateTime.UtcNow;
                var seenThisTick = new HashSet<string>(StringComparer.Ordinal);
                int repaired = 0;

                foreach (var v in violations)
                {
                    string key = ((int)v.Code).ToString() + "|" + (v.PosKey ?? "");
                    seenThisTick.Add(key);

                    Log(string.Format(
                        "[INTEGRITY VIOLATION] {0}", v),
                        v.Severity == IntegritySeverity.Info ? LogLevel.Information :
                        v.Severity == IntegritySeverity.Warning ? LogLevel.Warning :
                                                                  LogLevel.Error);

                    // Info-level: never repair (cosmetic / transient).
                    if (v.Severity == IntegritySeverity.Info) continue;

                    // Critical: repair immediately.
                    // Warning: repair after the grace window.
                    bool eligible;
                    if (v.Severity == IntegritySeverity.Critical)
                    {
                        eligible = true;
                }
                else
                {
                        DateTime firstSeen = _integrityFirstSeen.GetOrAdd(key, now);
                        eligible = (now - firstSeen) >= IntegrityRepairGrace;
                    }

                    if (!eligible) continue;

                    if (v.RepairKind == IntegrityRepairKind.None) continue;

                    try
                    {
                        if (RepairViolation(v, snap))
                        {
                            repaired++;
                            Log(string.Format(
                                "[INTEGRITY REPAIRED] code={0} posKey={1} action={2}",
                                v.Code, v.PosKey, v.RepairKind), LogLevel.Warning);
                            _integrityFirstSeen.TryRemove(key, out _);
                        }
                    }
                    catch (Exception ex)
                    {
                        LogMonitorException("IntegrityRepair " + v.Code, ex);
                    }
                }

                // Drop tracker entries for codes that have cleared themselves.
                foreach (var oldKey in _integrityFirstSeen.Keys.ToArray())
                {
                    if (!seenThisTick.Contains(oldKey))
                        _integrityFirstSeen.TryRemove(oldKey, out _);
                }

                if (repaired > 0)
                {
                    Log(string.Format(
                        "[INTEGRITY] Tick complete — {0} violation(s) detected, {1} repaired.",
                        violations.Count, repaired), LogLevel.Warning);
                }
            }
            catch (Exception ex)
            {
                LogMonitorException("IntegrityTick_OnUiThread", ex);
            }
        }

        /// <summary>
        /// Build an immutable IntegritySnapshot capturing every TradeMonitor
        /// dictionary, the engine + session counters, and the NT8 ground truth
        /// for every subscribed account's positions, all at one instant.
        /// Read-only — IntegrityCheck cannot mutate state.
        /// </summary>
        internal IntegritySnapshot BuildIntegritySnapshot()
        {
            // NT8 ground truth — atomic per-position read.
            var nt8Positions = new Dictionary<string, Nt8PositionSnap>();
            try
            {
                lock (_accountsLock)
                {
                    foreach (var acctName in _accountSubscribedAt.Keys.ToArray())
                    {
                        Account acct = NinjaTrader.Cbi.Account.All
                            .FirstOrDefault(a => a != null && a.Name == acctName);
                        if (acct == null) continue;

                        IEnumerable<Position> positions;
                        try { positions = acct.Positions.ToArray(); }
                        catch { continue; }

                        foreach (var pos in positions)
                        {
                            if (pos == null || pos.Instrument?.MasterInstrument == null) continue;

                            // Atomic snapshot — read each field exactly once into a local
                            // before storing.  This is the same defence-in-depth pattern
                            // that the e.MarketPosition / e.Quantity event-snapshot fix
                            // uses on the OnPositionUpdate side.
                            var snapDir = pos.MarketPosition;
                            var snapQty = pos.Quantity;
                            var snapPx  = pos.AveragePrice;
                            var instr   = pos.Instrument.MasterInstrument.Name;

                            string key = PositionKey(acctName, instr);
                            nt8Positions[key] = new Nt8PositionSnap
                            {
                                AccountName    = acctName,
                                InstrumentName = instr,
                                Direction      = snapDir,
                                Quantity       = snapQty,
                                AveragePrice   = snapPx,
                            };
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                LogMonitorException("BuildIntegritySnapshot.Nt8Read", ex);
            }

            // Lifecycle snap (decoupled from internal PositionLifecycle type)
            var lifeSnaps = new Dictionary<string, LifecycleSnap>();
            foreach (var kv in _lifecycles)
            {
                var l = kv.Value;
                if (l == null) continue;
                lifeSnaps[kv.Key] = new LifecycleSnap
                {
                    LifecycleId    = l.LifecycleId,
                    EntryTime      = l.EntryTime,
                    MaxQtySeen     = l.MaxQtySeen,
                    OriginObserved = l.OriginObserved,
                    Direction      = l.Direction,
                    MintedAt       = l.MintedAt,
                };
            }

            bool inBootstrap = false;
            try
            {
                DateTime nowUtc = DateTime.UtcNow;
                foreach (var kv in _accountSubscribedAt)
                {
                    if ((nowUtc - kv.Value) <= BootstrapReplayWindow)
                    {
                        inBootstrap = true;
                        break;
                    }
                }
            }
            catch { /* bootstrap window detection is advisory only */ }

            // Retiring lifecycle snap (between REMOVE and TryRecordTrade completing)
            var retiringLifeSnaps = new Dictionary<string, RetiringLifecycleSnap>();
            foreach (var kv in _retiringLifecycles)
            {
                var l = kv.Value;
                if (l == null) continue;
                retiringLifeSnaps[kv.Key] = new RetiringLifecycleSnap
                {
                    LifecycleId             = l.LifecycleId,
                    EntryTime               = l.EntryTime,
                    Direction               = l.Direction,
                    OriginObserved          = l.OriginObserved,
                    IsRemoved               = l.IsRemoved,
                    Recorded                = l.Recorded,
                    AccumulatedPnl          = l.AccumulatedPnl,
                    QtyAtLastScaleIn        = l.QtyAtLastScaleIn,
                    PostLastScaleInCloseQty = l.PostLastScaleInCloseQty,
                    LastCloseFillTime       = l.LastCloseFillTime,
                    MintedAt                = l.MintedAt,
                };
            }

            return new IntegritySnapshot
            {
                SnapshotTime                = DateTime.UtcNow,
                PositionQuantities          = new Dictionary<string, double>(_positionQuantities),
                PositionDirections          = new Dictionary<string, MarketPosition>(_positionDirections),
                Lifecycles                  = lifeSnaps,
                RetiringLifecycles          = retiringLifeSnaps,
                PosOriginObserved           = new Dictionary<string, bool>(),
                ReversalCloseOriginObserved = new Dictionary<string, bool>(),
                FlatPending                 = new Dictionary<string, bool>(),
                PendingPartialPnl           = new Dictionary<string, double>(),
                PendingPartialQty           = new Dictionary<string, double>(),
                PositionEntryTimes          = new Dictionary<string, DateTime>(_positionEntryTimes),
                PositionEntryPrices         = new Dictionary<string, double>(_positionEntryPrices),
                PositionMinPnl              = new Dictionary<string, double>(_positionMinPnl),
                Nt8Positions                = nt8Positions,
                AccountSubscribedAt         = new Dictionary<string, DateTime>(_accountSubscribedAt),
                TotalTrades                 = _currentSession?.TotalTrades ?? 0,
                SessionEntryCount           = _engine?.SessionEntryCount  ?? 0,
                InBootstrapWindow           = inBootstrap,
            };
        }

        /// <summary>
        /// Apply the repair indicated by <paramref name="v"/>.  Returns true if
        /// any state was mutated.  NT8 truth always wins; engine commits and
        /// session counters are NEVER rolled back (an integrity repair is
        /// metadata-only and cannot synthesise commits the trader didn't
        /// produce).
        /// </summary>
        private bool RepairViolation(IntegrityViolation v, IntegritySnapshot snap)
        {
            string posKey = v.PosKey;

            switch (v.RepairKind)
            {
                case IntegrityRepairKind.ClearShadowKey:
                    {
                        bool any = false;
                        any |= _positionQuantities.TryRemove(posKey, out _);
                        any |= _positionDirections.TryRemove(posKey, out _);
                        // Aux state for a now-flat position is also stale
                        _positionEntryTimes.TryRemove(posKey, out _);
                        _positionEntryPrices.TryRemove(posKey, out _);
                        _positionMinPnl.TryRemove(posKey, out _);
                        return any;
                    }

                case IntegrityRepairKind.SetShadowFromNt8:
                    {
                        Nt8PositionSnap nt8;
                        if (!snap.Nt8Positions.TryGetValue(posKey, out nt8)) return false;
                        if (nt8.Direction == MarketPosition.Flat)
                        {
                            _positionQuantities.TryRemove(posKey, out _);
                            _positionDirections.TryRemove(posKey, out _);
                        }
                        else
                        {
                            _positionDirections[posKey] = nt8.Direction;
                            _positionQuantities[posKey] = nt8.Quantity;
                        }
                        return true;
                    }

                case IntegrityRepairKind.ClearLifecycleAndBridges:
                    {
                        bool any = false;
                        if (_lifecycles.TryRemove(posKey, out var stale))
                        {
                            Log(string.Format(
                                "[INTEGRITY] retiring stuck lifecycle posKey={0} dir={1} life={2:N}",
                                posKey, stale?.Direction, stale?.LifecycleId ?? Guid.Empty),
                                LogLevel.Warning);
                            any = true;
                        }
                        // Bridge dicts removed — no-op retained for ABI compat with old snapshots.
                        return any;
                    }

                case IntegrityRepairKind.ClearReversalBridge:
                    return false; // bridge dict removed — always a no-op

                case IntegrityRepairKind.ClearFlatPending:
                    return false; // _flatPending removed — always a no-op

                case IntegrityRepairKind.ClearPendingPnlAndQty:
                    return false; // _pendingPartialPnl/Qty removed — always a no-op

                case IntegrityRepairKind.ClearAuxStateForPosKey:
                    {
                        bool any = false;
                        any |= _positionEntryTimes.TryRemove(posKey, out _);
                        any |= _positionEntryPrices.TryRemove(posKey, out _);
                        any |= _positionMinPnl.TryRemove(posKey, out _);
                        return any;
                    }

                case IntegrityRepairKind.ReconcileLifecycleFromNt8:
                    {
                        // Re-fire the lifecycle edge router with NT8 truth as
                        // the synthetic event.  This handles ALL three drift
                        // shapes (lifecycle stuck open, lifecycle direction
                        // mismatch, NT8 has position we missed) through the
                        // same code path used by live PositionUpdate.
                        Account acct;
                        try
                        {
                            string acctName = posKey.Split(new[] { "::" }, StringSplitOptions.None)[0];
                            acct = NinjaTrader.Cbi.Account.All
                                .FirstOrDefault(a => a != null && a.Name == acctName);
                        }
                        catch { acct = null; }
                        if (acct == null) return false;

                        Nt8PositionSnap nt8;
                        if (!snap.Nt8Positions.TryGetValue(posKey, out nt8))
                        {
                            // NT8 says nothing about this posKey → it's flat.
                            ReconcileLifecycleEdgeAtomic(posKey, acct,
                                MarketPosition.Flat, 0.0, source: "IntegrityRepair");
                        }
                        else
                        {
                            ReconcileLifecycleEdgeAtomic(posKey, acct,
                                nt8.Direction, nt8.Quantity, source: "IntegrityRepair");
                        }
                        return true;
                    }

                case IntegrityRepairKind.TryRecordRetiringLifecycle:
                    {
                        // B1-enhanced: missed Remove or TryRecordTrade gate stalled.
                        // Set IsRemoved on any lifecycle we still see in the active dict
                        // (the Remove edge was missed), then call TryRecordTrade.
                        PositionLifecycle activeLc;
                        if (_lifecycles.TryGetValue(posKey, out activeLc) && activeLc != null)
                        {
                            activeLc.IsRemoved = true;
                            _retiringLifecycles[posKey] = activeLc;
                            _lifecycles.TryRemove(posKey, out _);
                            Log(string.Format(
                                "[INTEGRITY-B1] Missed Remove recovered — set IsRemoved, moved to retiring. posKey={0}", posKey),
                                LogLevel.Warning);
                        }
                        PositionLifecycle retiringLc;
                        if (_retiringLifecycles.TryGetValue(posKey, out retiringLc) && retiringLc != null)
                        {
                            TryRecordTrade(retiringLc);
                        }
                        return true;
                    }

                case IntegrityRepairKind.ForceCompleteRetiringLifecycle:
                    {
                        // B3: stuck retiring lifecycle — fills never arrived or partially arrived.
                        // Accept whatever PnL has accumulated and force-complete.
                        PositionLifecycle retiringLc;
                        if (!_retiringLifecycles.TryGetValue(posKey, out retiringLc) || retiringLc == null)
                            return false;

                        // Attempt normal record first (maybe fills arrived between snapshot and now)
                        TryRecordTrade(retiringLc);
                        if (retiringLc.Recorded) return true;

                        // Force-complete: adjust the gate to accept partial fills
                        Log(string.Format(
                            "[INTEGRITY-B3] Force-completing stuck lifecycle posKey={0} closeQty={1} expected={2} pnl={3:F2}",
                            posKey, retiringLc.PostLastScaleInCloseQty, retiringLc.QtyAtLastScaleIn, retiringLc.AccumulatedPnl),
                            LogLevel.Warning);
                        retiringLc.QtyAtLastScaleIn = retiringLc.PostLastScaleInCloseQty;
                        TryRecordTrade(retiringLc);
                        return retiringLc.Recorded;
                    }

                case IntegrityRepairKind.SetOriginObservedAndRetry:
                    {
                        // C2a/C2b repair: lifecycle was minted after the bootstrap window closed
                        // but has OriginObserved=false (wrongly tagged as a bootstrap ghost,
                        // typically from the pre-2026-04-25 bootstrap-reset bug).
                        // Set OriginObserved=true on the live lifecycle object so TryRecordTrade
                        // will record it instead of silently discarding it.
                        bool repaired = false;

                        PositionLifecycle activeLc;
                        if (_lifecycles.TryGetValue(posKey, out activeLc) && activeLc != null
                            && !activeLc.OriginObserved)
                        {
                            activeLc.OriginObserved = true;
                            Log(string.Format(
                                "[INTEGRITY-C2a] Set OriginObserved=true on active lifecycle posKey={0} life={1:N}",
                                posKey, activeLc.LifecycleId), LogLevel.Warning);
                            repaired = true;
                        }

                        PositionLifecycle retiringLc;
                        if (_retiringLifecycles.TryGetValue(posKey, out retiringLc) && retiringLc != null
                            && !retiringLc.OriginObserved && !retiringLc.Recorded)
                        {
                            retiringLc.OriginObserved = true;
                            Log(string.Format(
                                "[INTEGRITY-C2b] Set OriginObserved=true on retiring lifecycle posKey={0} life={1:N}; retrying TryRecordTrade.",
                                posKey, retiringLc.LifecycleId), LogLevel.Warning);
                            TryRecordTrade(retiringLc);
                            repaired = true;
                        }

                        return repaired;
                    }
            }
            return false;
        }


        // Cooldown gate for the naked-position alert (wall-clock; this alert is
        // about live risk and must fire even during playback pauses).
        private WallClockGate _nakedAlertGate = new WallClockGate(120.0); // 2 min

        private void FireNakedPositionAlert()
        {
            // Rate-limit to once per 2 minutes to avoid repeated voice spam
            // while the user is still in the naked position.
            if (_nakedAlertGate.IsActive()) return;
            _nakedAlertGate.Set();

            _currentSession.IncrementAlertsFired();
            TryPlayVoiceAlert("Warning. No stop-loss on your position. Add one now.");
            var disp2879 = _uiDispatcher;
            if (disp2879 != null && !disp2879.HasShutdownStarted && !disp2879.HasShutdownFinished)
                try { disp2879.BeginInvoke((Action)(() =>
                new AlertToastWindow(
                    "⚠ No stop-loss on your position — add one now",
                        isCritical: true).Show())); }
                catch (InvalidOperationException) { } catch (TaskCanceledException) { }
        }

        // =====================================================================
        // Helpers
        // =====================================================================

        /// <summary>
        /// Builds a snapshot of all currently open positions across all monitored accounts,
        /// AND performs self-healing position-tracking reconciliation as a side effect.
        ///
        /// Reconciliation rules (run every 5 s, independent of fill events):
        ///   1. Quantity / direction mismatch → fix from NT8 truth; log [DESYNC REPAIRED].
        ///   2. Always sync _positionEntryPrices to pos.AveragePrice so scale-in PnL is
        ///      correct (NT8 recomputes the average on every additional fill).
        ///   3. Ghost tracking (we think open; NT8 says flat) → clear internal state; log.
        ///   4. Unknown open position (NT8 has one we never tracked) → bootstrap from NT8.
        ///
        /// Entry TIME is not available from NT8, so it is never overwritten if already set.
        /// </summary>
        // =====================================================================
        // Guard action handler
        // =====================================================================

        // ── Journal public API (v1.2 — consumed by TradeMonitorHub) ───────────

        /// <summary>
        /// Append a journal entry with automatically injected context
        /// (current PSI, dominant dimension, session PnL).  UI only needs
        /// to supply the user's note + emotion + kind.  Safe to call from any thread.
        /// </summary>
        internal bool RecordJournalEntry(JournalKind kind,
                                         JournalEmotion emotion,
                                         string note)
        {
            try
            {
                double psi = _engine != null ? _engine.CurrentPsi : 100.0;
                double pnl = _currentSession != null ? _currentSession.TotalPnl : 0.0;
                string dom = GetDominantDimLabel();

                var entry = new JournalEntry
                {
                    Timestamp    = DateTime.Now,
                    SessionDate  = (_currentSession != null) ? _currentSession.Date : DateTime.Today,
                    Kind         = kind.ToStored(),
                    Emotion      = emotion,
                    Psi          = psi,
                    DominantDim  = dom,
                    SessionPnl   = pnl,
                    Note         = note ?? string.Empty,
                };

                JournalStore.Append(entry, LogWarning);
                Log(string.Format("[Journal] {0} ({1}) psi={2:F1} dom={3} pnl={4:F2} note='{5}'",
                                  kind, emotion, psi, dom ?? "-", pnl,
                                  (note ?? "").Replace("\n", " ")),
                    LogLevel.Information);
                return true;
            }
            catch (Exception ex)
            {
                LogWarning("[Journal] RecordJournalEntry failed: " + ex.Message);
                return false;
            }
        }

        /// <summary>
        /// Return the label ("D1 Revenge Entry", etc.) of the dimension with the
        /// highest cumulative raw score in the current session, or null if none.
        /// </summary>
        internal string GetDominantDimLabel()
        {
            if (_currentSession == null) return null;
            double[] scores = _currentSession.DimCumScore;
            if (scores == null || scores.Length == 0) return null;
            int topIdx = -1;
            double topVal = 0.0;
            for (int i = 0; i < scores.Length; i++)
            {
                if (scores[i] > topVal) { topVal = scores[i]; topIdx = i; }
            }
            if (topIdx < 0 || topVal <= 1e-9) return null;
            string[] labels = { "D1 Revenge", "D2 StopMgmt", "D3 Oversize",
                                "D4 Hold",    "D5 Overstay", "D6 RuleViol",
                                "D7 Overtrade" };
            return (topIdx < labels.Length) ? labels[topIdx] : ("D" + (topIdx + 1));
        }

        // ── Guard public API (consumed by TradeMonitorHub) ────────────────────

        /// <summary>
        /// Emergency override: clears all Guard runtime state without deleting rules.
        /// Called from the Guard settings UI via TradeMonitorHub.
        /// Logs the action so it appears in the session record.
        /// </summary>
        internal void ForceResetGuard()
        {
            _guardEngine?.ForceReset();
            LogWarning(string.Format("[GUARD OVERRIDE] {0:yyyy-MM-dd HH:mm:ss} — User manually cleared all Guard states via Emergency Override.",
                DateTime.Now));
            // Clear the HUD risk-alert banner immediately.
            var disp2984 = _uiDispatcher;
            if (disp2984 != null && !disp2984.HasShutdownStarted && !disp2984.HasShutdownFinished)
                try { disp2984.BeginInvoke((Action)(() => _overlayWindow?.UpdateRiskAlertBanner(null))); }
                catch (InvalidOperationException) { } catch (TaskCanceledException) { }
        }

        private void OnGuardTriggered(GuardTrigger trigger)
        {
            // Called on NT8 event thread — dispatch to the UI thread via the
            // reliable cached dispatcher (Application.Current?.Dispatcher.InvokeAsync
            // proved to silently drop on NT8's event thread).
            var disp = _uiDispatcher;
            if (disp != null && !disp.HasShutdownStarted && !disp.HasShutdownFinished)
                try { disp.BeginInvoke((Action)(() => HandleGuardAction(trigger))); }
                catch (InvalidOperationException) { } catch (TaskCanceledException) { }
        }

        private void HandleGuardAction(GuardTrigger trigger)
        {
            switch (trigger.Action)
            {
                case GuardActionType.Toast:
                    new AlertToastWindow(trigger.Message, isCritical: false,
                        title: "Guard: " + trigger.Rule.Name,
                        holdSeconds: 12).Show();
                    break;

                case GuardActionType.Acknowledge:
                    ShowGuardAcknowledge(trigger);
                    break;

                case GuardActionType.Countdown:
                    ShowGuardCountdown(trigger);
                    break;

                case GuardActionType.RiskAlert:
                    // Initial trigger: the HUD banner is already managed in PushPsiToHud
                    // via _guardEngine.IsRiskAlertActive polling.  Here we just show a
                    // one-time toast so the trader knows which rule activated.
                    new AlertToastWindow(
                        string.Format("⚠ Risk Alert active: {0}", trigger.Rule.Name),
                        isCritical: false).Show();
                    break;

                case GuardActionType.Disconnect:
                    ShowGuardDisconnectPreflight(trigger);
                    break;
            }
        }

        // ── Guard window shared builder ─────────────────────────────────────────
        // Creates a chromeless dark card window styled to match the PSI HUD/Hub.
        // isEmergency=true uses a red accent (Disconnect guard); false = amber.
        // Height auto-sizes to content (SizeToContent.Height) — never clips.
        // Position: remembered from last drag, or defaults to upper-centre of screen.
        private Window BuildGuardCard(string title, double width,
                                      bool isEmergency, out StackPanel body)
        {
            var win = new Window
            {
                WindowStyle           = WindowStyle.None,
                AllowsTransparency    = true,
                Background            = Brushes.Transparent,
                Width                 = width,
                SizeToContent         = SizeToContent.Height,
                WindowStartupLocation = WindowStartupLocation.Manual,
                ResizeMode            = ResizeMode.NoResize,
                Topmost               = true,
                ShowInTaskbar         = false,
            };

            // Position: remember last drag, or default to upper-centre of work area.
            double posLeft = _guardWinLeft ?? (SystemParameters.WorkArea.Left
                             + (SystemParameters.WorkArea.Width - width) / 2.0);
            double posTop  = _guardWinTop  ?? (SystemParameters.WorkArea.Top + 70);
            win.Left = posLeft;
            win.Top  = posTop;

            // Persist position when user drags the window.
            win.LocationChanged += (_, __) =>
            {
                _guardWinLeft = win.Left;
                _guardWinTop  = win.Top;
            };

            Color accent = isEmergency
                ? Color.FromRgb(200, 60, 50)    // red
                : Color.FromRgb(186, 140, 54);  // dark gold

            var card = new Border
            {
                CornerRadius    = new CornerRadius(10),
                Background      = new SolidColorBrush(Color.FromRgb(24, 24, 26)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(120, accent.R, accent.G, accent.B)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };

            var outerGrid = new Grid();
            outerGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(44) });
            outerGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            // ── Header strip ────────────────────────────────────────────────────
            var hdrBorder = new Border
            {
                Background = new SolidColorBrush(Color.FromArgb(200, accent.R, accent.G, accent.B)),
            };
            var hdrGrid = new Grid();
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var iconLbl = new Label
            {
                Content           = isEmergency ? "\uD83D\uDEAB" : "\u26A0",
                FontSize          = 14,
                Foreground        = Brushes.White,
                VerticalAlignment = VerticalAlignment.Center,
                Padding           = new Thickness(14, 0, 4, 0),
            };
            var titleLbl = new Label
            {
                Content           = title,
                FontSize          = 13,
                FontWeight        = FontWeights.SemiBold,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = Brushes.White,
                VerticalAlignment = VerticalAlignment.Center,
                Padding           = new Thickness(0, 0, 8, 0),
            };

            // Dashboard — always reachable even when this Guard card covers the HUD ☰
            var hubLinkLbl = new Label
            {
                Content                    = "\u2630 Dashboard",
                FontSize                   = 10,
                FontWeight                  = FontWeights.SemiBold,
                Foreground                 = new SolidColorBrush(Color.FromArgb(230, 255, 255, 255)),
                VerticalAlignment          = VerticalAlignment.Center,
                Padding                    = new Thickness(4, 0, 6, 0),
                Cursor                     = System.Windows.Input.Cursors.Hand,
                ToolTip                    = "Open Meridian Dashboard",
                VerticalContentAlignment   = VerticalAlignment.Center,
            };
            hubLinkLbl.MouseEnter += (_, __) =>
                hubLinkLbl.Foreground = new SolidColorBrush(Color.FromRgb(120, 220, 160));
            hubLinkLbl.MouseLeave += (_, __) =>
                hubLinkLbl.Foreground = new SolidColorBrush(Color.FromArgb(230, 255, 255, 255));
            hubLinkLbl.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                ShowOrActivateHub(HubPage.Session);
            };

            // Collapse toggle button (—/＋) anchored to header right
            var collapseBtn = new Label
            {
                Content           = "\u2014",   // em-dash = "collapse"
                FontSize          = 15,
                FontWeight        = FontWeights.Bold,
                Foreground        = new SolidColorBrush(Color.FromArgb(200, 255, 255, 255)),
                VerticalAlignment = VerticalAlignment.Center,
                Padding           = new Thickness(8, 0, 12, 0),
                Cursor            = System.Windows.Input.Cursors.Hand,
                ToolTip           = "Collapse / expand",
            };

            Grid.SetColumn(iconLbl,     0); hdrGrid.Children.Add(iconLbl);
            Grid.SetColumn(titleLbl,    1); hdrGrid.Children.Add(titleLbl);
            Grid.SetColumn(hubLinkLbl,  2); hdrGrid.Children.Add(hubLinkLbl);
            Grid.SetColumn(collapseBtn, 3); hdrGrid.Children.Add(collapseBtn);
            hdrBorder.Child = hdrGrid;
            Grid.SetRow(hdrBorder, 0); outerGrid.Children.Add(hdrBorder);

            // ── Body area (auto-height) ──────────────────────────────────────────
            // Local copy: `out` parameter `body` cannot be closed over (CS1628).
            var bodyPanel = new StackPanel { Margin = new Thickness(22, 18, 22, 22) };
            body = bodyPanel;
            Grid.SetRow(bodyPanel, 1); outerGrid.Children.Add(bodyPanel);

            // Collapse: hide body, window shrinks to header only.
            bool collapsed = false;
            collapseBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                collapsed = !collapsed;
                bodyPanel.Visibility  = collapsed ? Visibility.Collapsed : Visibility.Visible;
                collapseBtn.Content   = collapsed ? "\u002B" : "\u2014"; // + / —
            };

            card.Child  = outerGrid;
            win.Content = card;

            // Allow dragging by clicking anywhere on the header — always, even when collapsed.
            hdrBorder.MouseLeftButtonDown += (_, e) =>
            {
                if (e.ButtonState == MouseButtonState.Pressed)
                    win.DragMove();
            };

            return win;
        }

        private static Button BuildGuardButton(string text, bool isPrimary, bool isEnabled = true)
        {
            Color bg = isPrimary
                ? (isEnabled ? Color.FromRgb(30, 110, 55) : Color.FromRgb(50, 50, 55))
                : Color.FromRgb(42, 42, 46);
            return new Button
            {
                Content             = text,
                IsEnabled           = isEnabled,
                Padding             = new Thickness(18, 9, 18, 9),
                Background          = new SolidColorBrush(bg),
                Foreground          = new SolidColorBrush(isEnabled ? Colors.White : Color.FromRgb(110, 110, 115)),
                BorderThickness     = new Thickness(0),
                FontFamily          = new FontFamily("Segoe UI"),
                FontSize            = 13,
                FontWeight          = isPrimary ? FontWeights.SemiBold : FontWeights.Normal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
        }

        private void ShowGuardAcknowledge(GuardTrigger trigger)
        {
            bool hasPhrase = !string.IsNullOrWhiteSpace(trigger.Rule.OverridePhrase);
            string expectedPhrase = hasPhrase ? trigger.Rule.OverridePhrase.Trim() : "";

            StackPanel body;
            var win = BuildGuardCard("Guard Rule Triggered",
                width: 460,
                isEmergency: false, body: out body);

            body.Children.Add(new TextBlock
            {
                Text         = trigger.Message,
                Foreground   = new SolidColorBrush(Color.FromRgb(230, 230, 230)),
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 13,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 16),
                LineHeight   = 20,
            });

            Button confirmBtn;
            if (hasPhrase)
            {
                body.Children.Add(new TextBlock
                {
                    Text       = "Type the following to continue:",
                    Foreground = new SolidColorBrush(Color.FromRgb(140, 140, 148)),
                    FontFamily = new FontFamily("Segoe UI"),
                    FontSize   = 11,
                    Margin     = new Thickness(0, 0, 0, 5),
                });
                body.Children.Add(new TextBlock
                {
                    Text         = "\u201c" + expectedPhrase + "\u201d",
                    Foreground   = new SolidColorBrush(Color.FromRgb(186, 140, 54)),
                    FontFamily   = new FontFamily("Segoe UI"),
                    FontSize     = 12,
                    FontStyle    = FontStyles.Italic,
                    TextWrapping = TextWrapping.Wrap,
                    Margin       = new Thickness(0, 0, 0, 10),
                });
                var phraseBox = new System.Windows.Controls.TextBox
                {
                    Background      = new SolidColorBrush(Color.FromRgb(36, 36, 40)),
                    Foreground      = new SolidColorBrush(Colors.White),
                    CaretBrush      = new SolidColorBrush(Colors.White),
                    BorderBrush     = new SolidColorBrush(Color.FromRgb(65, 65, 75)),
                    BorderThickness = new Thickness(1),
                    FontFamily      = new FontFamily("Segoe UI"),
                    FontSize        = 13,
                    Padding         = new Thickness(10, 7, 10, 7),
                    Margin          = new Thickness(0, 0, 0, 14),
                };
                body.Children.Add(phraseBox);

                confirmBtn = BuildGuardButton("I acknowledge", isPrimary: true, isEnabled: false);
                phraseBox.TextChanged += (_, __) =>
                {
                    bool match = string.Equals(phraseBox.Text.Trim(), expectedPhrase,
                                               StringComparison.OrdinalIgnoreCase);
                    confirmBtn.IsEnabled  = match;
                    confirmBtn.Background = new SolidColorBrush(
                        match ? Color.FromRgb(30, 110, 55) : Color.FromRgb(50, 50, 55));
                    confirmBtn.Foreground = new SolidColorBrush(
                        match ? Colors.White : Color.FromRgb(110, 110, 115));
                };
            }
            else
            {
                confirmBtn = BuildGuardButton("I acknowledge", isPrimary: true);
            }

            confirmBtn.Click += (_, __) => win.Close();
            body.Children.Add(confirmBtn);
            win.Show();
        }

        private void ShowGuardCountdown(GuardTrigger trigger)
        {
            int totalSec = Math.Max(5, trigger.Rule.CountdownSeconds);

            StackPanel body;
            var win = BuildGuardCard("Cooling Down", width: 420,
                                     isEmergency: false, body: out body);

            body.Children.Add(new TextBlock
            {
                Text         = trigger.Message,
                Foreground   = new SolidColorBrush(Color.FromRgb(230, 230, 230)),
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 13,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 12),
                LineHeight   = 20,
            });

            var countdownLbl = new TextBlock
            {
                Text                = $"{totalSec}",
                FontSize            = 44,
                FontWeight          = FontWeights.Bold,
                Foreground          = new SolidColorBrush(Color.FromRgb(186, 140, 54)),
                FontFamily          = new FontFamily("Segoe UI"),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 16),
            };
            body.Children.Add(countdownLbl);

            var btn = BuildGuardButton($"Wait… ({totalSec}s)", isPrimary: true, isEnabled: false);
            btn.Click += (_, __) => win.Close();
            body.Children.Add(btn);
            win.Show();

            int remaining = totalSec;
            var timer = new System.Windows.Threading.DispatcherTimer
                { Interval = TimeSpan.FromSeconds(1) };
            timer.Tick += (_, __) =>
            {
                remaining--;
                countdownLbl.Text = $"{remaining}";
                if (remaining <= 0)
                {
                    timer.Stop();
                    btn.IsEnabled  = true;
                    btn.Content    = "I acknowledge — Continue Trading";
                    btn.Background = new SolidColorBrush(Color.FromRgb(30, 110, 55));
                    btn.Foreground = new SolidColorBrush(Colors.White);
                    countdownLbl.Foreground = new SolidColorBrush(Color.FromRgb(55, 200, 90));
                }
                else
                {
                    btn.Content = $"Wait… ({remaining}s)";
                }
            };
            timer.Start();
        }

        private void ShowGuardDisconnectPreflight(GuardTrigger trigger)
        {
            int lockMins = Math.Max(1, trigger.Rule.LockMinutes);

            // ── Check for open positions ───────────────────────────────────────
            int openContracts = 0;
            List<Account> acctSnap;
            lock (_accountsLock) acctSnap = new List<Account>(_subscribedAccounts);
            foreach (var acct in acctSnap)
            {
                try
                {
                    foreach (Position pos in acct.Positions)
                        if (pos != null && pos.MarketPosition != MarketPosition.Flat)
                            openContracts += pos.Quantity;
                }
                catch { }
            }

            if (openContracts == 0)
            {
                // Flat — disconnect immediately.
                DoExecuteDisconnect(lockMins, trigger.Message, trigger.Rule.Name);
                return;
            }

            // ── Position safety window (60 seconds) ───────────────────────────
            int countdownSec = 60;
            StackPanel stack;
            var win = BuildGuardCard("Guard — Disconnect Pending",
                width: 500, isEmergency: true, body: out stack);

            stack.Children.Add(new TextBlock
            {
                Text         = trigger.Message,
                Foreground   = new SolidColorBrush(Color.FromRgb(230, 230, 230)),
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 13,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 10),
                LineHeight   = 20,
            });

            var posWarning = new TextBlock
            {
                Text       = string.Format("You have {0} open contract{1}. Disconnecting in:",
                                 openContracts, openContracts == 1 ? "" : "s"),
                Foreground = new SolidColorBrush(Color.FromRgb(255, 140, 60)),
                FontFamily = new FontFamily("Segoe UI"),
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                Margin     = new Thickness(0, 0, 0, 4),
            };
            stack.Children.Add(posWarning);

            var countdownLbl = new TextBlock
            {
                Text                = countdownSec.ToString(),
                FontSize            = 40,
                FontWeight          = FontWeights.Bold,
                Foreground          = new SolidColorBrush(Color.FromRgb(255, 100, 60)),
                FontFamily          = new FontFamily("Segoe UI"),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 2, 0, 10),
            };
            stack.Children.Add(countdownLbl);

            stack.Children.Add(new TextBlock
            {
                Text         = "Close your position now, or use Flatten All to exit immediately.",
                Foreground   = new SolidColorBrush(Color.FromRgb(160, 160, 168)),
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 11,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 14),
            });

            var btnRow = new StackPanel
            {
                Orientation         = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
            };

            var flattenBtn = new Button
            {
                Content         = "Flatten All",
                Padding         = new Thickness(16, 9, 16, 9),
                Background      = new SolidColorBrush(Color.FromRgb(180, 50, 30)),
                Foreground      = new SolidColorBrush(Colors.White),
                BorderThickness = new Thickness(0),
                FontFamily      = new FontFamily("Segoe UI"),
                FontSize        = 13,
                FontWeight      = FontWeights.SemiBold,
                Margin          = new Thickness(0, 0, 8, 0),
                Cursor          = System.Windows.Input.Cursors.Hand,
            };

            var manualBtn = BuildGuardButton("I'll manage manually", isPrimary: false);

            btnRow.Children.Add(flattenBtn);
            btnRow.Children.Add(manualBtn);
            stack.Children.Add(btnRow);
            // Note: win.Content is set by BuildGuardCard; do not reassign here.

            bool disconnectFired = false;
            Action fireDisconnect = () =>
            {
                if (disconnectFired) return;
                disconnectFired = true;
                win.Close();
                DoExecuteDisconnect(lockMins, trigger.Message, trigger.Rule.Name);
            };

            // Flatten All: submit market flatten for every open position.
            flattenBtn.Click += (_, __) =>
            {
                try
                {
                    foreach (var acct in acctSnap)
                    {
                        // Collect all instruments with open positions, then flatten each.
                        var instruments = new List<NinjaTrader.Cbi.Instrument>();
                        try
                        {
                            foreach (Position pos in acct.Positions)
                                if (pos != null && pos.MarketPosition != MarketPosition.Flat
                                    && pos.Instrument != null)
                                    instruments.Add(pos.Instrument);
                        }
                        catch { }
                        if (instruments.Count > 0)
                            acct.Flatten(instruments.ToArray());
                    }
                }
                catch (Exception ex)
                {
                    LogWarning($"[Guard] Flatten failed: {ex.Message}");
                }
                fireDisconnect();
            };

            // Manual: window stays open for manual management; timer continues.
            manualBtn.Click += (_, __) =>
            {
                manualBtn.IsEnabled = false;
                manualBtn.Content   = "Managing manually...";
            };

            win.Show();

            // Countdown timer — ticks every second.
            int remaining = countdownSec;
            var timer = new System.Windows.Threading.DispatcherTimer
                { Interval = TimeSpan.FromSeconds(1) };
            timer.Tick += (_, __) =>
            {
                if (disconnectFired) { timer.Stop(); return; }

                // Re-check open positions — if user already closed, disconnect cleanly.
                int stillOpen = 0;
                foreach (var acct in acctSnap)
                {
                    try
                    {
                        foreach (Position pos in acct.Positions)
                            if (pos != null && pos.MarketPosition != MarketPosition.Flat)
                                stillOpen += pos.Quantity;
                    }
                    catch { }
                }
                if (stillOpen == 0) { timer.Stop(); fireDisconnect(); return; }

                remaining--;
                countdownLbl.Text = remaining.ToString();
                posWarning.Text = string.Format(
                    "You have {0} open contract{1}. Guard will disconnect in:",
                    stillOpen, stillOpen == 1 ? "" : "s");

                if (remaining <= 0)
                {
                    timer.Stop();
                    // Time expired with open positions — require secondary confirmation.
                    win.Close();
                    ShowDisconnectSecondaryConfirm(lockMins, trigger.Message, stillOpen, trigger.Rule.Name);
                }
            };
            timer.Start();
        }

        private void ShowDisconnectSecondaryConfirm(int lockMins, string message, int openContracts, string ruleName = "")
        {
            var win = new Window
            {
                Title                 = "Guard — Confirm Disconnect with Open Positions",
                Width                 = 500,
                Height                = 310,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                Background            = new SolidColorBrush(Color.FromRgb(70, 15, 15)),
                ResizeMode            = ResizeMode.NoResize,
                Topmost               = true,
            };
            var stack = new StackPanel { Margin = new Thickness(28) };

            stack.Children.Add(new TextBlock
            {
                Text         = string.Format(
                    "WARNING: You still have {0} open contract{1}.\n\n" +
                    "Disconnecting now means NinjaTrader can no longer monitor or manage this position.\n\n" +
                    "• Native exchange stops will remain active at the broker.\n" +
                    "• Simulated / ATM stops may be cancelled when the connection drops.",
                    openContracts, openContracts == 1 ? "" : "s"),
                Foreground   = new SolidColorBrush(Color.FromRgb(255, 180, 60)),
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 13,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 20),
            });

            var btnRow = new StackPanel
            {
                Orientation         = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
            };

            var cancelBtn = new Button
            {
                Content         = "Cancel Disconnect",
                Padding         = new Thickness(16, 8, 16, 8),
                Background      = new SolidColorBrush(Color.FromRgb(50, 50, 60)),
                Foreground      = new SolidColorBrush(Colors.White),
                BorderThickness = new Thickness(0),
                FontFamily      = new FontFamily("Segoe UI"),
                FontSize        = 13,
                Margin          = new Thickness(0, 0, 8, 0),
            };
            var proceedBtn = new Button
            {
                Content         = "Disconnect Anyway — I accept the risk",
                Padding         = new Thickness(16, 8, 16, 8),
                Background      = new SolidColorBrush(Color.FromRgb(150, 30, 30)),
                Foreground      = new SolidColorBrush(Colors.White),
                BorderThickness = new Thickness(0),
                FontFamily      = new FontFamily("Segoe UI"),
                FontSize        = 13,
            };

            cancelBtn.Click  += (_, __) => win.Close();
            proceedBtn.Click += (_, __) => { win.Close(); DoExecuteDisconnect(lockMins, message, ruleName); };

            btnRow.Children.Add(cancelBtn);
            btnRow.Children.Add(proceedBtn);
            stack.Children.Add(btnRow);
            win.Content = stack;
            win.Show();
        }

        private void DoExecuteDisconnect(int lockMins, string message, string ruleName = "")
        {
            // Parse condition bullets from the structured message body.
            var msgLines   = message.Split(new[] { '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries);
            var conditions = msgLines.Where(l => l.TrimStart().StartsWith("•")).ToList();

            // Fallback: extract rule name from first line if not supplied.
            if (string.IsNullOrWhiteSpace(ruleName))
            {
                var firstLine = msgLines.FirstOrDefault(l => !string.IsNullOrWhiteSpace(l)) ?? "";
                ruleName = firstLine.StartsWith("Guard: ")
                    ? firstLine.Substring(7)
                    : firstLine;
            }

            // ── Chromeless card (matches our guard card design) ────────────────
            StackPanel stack;
            var win = BuildGuardCard("Guard — Disconnected", width: 520, isEmergency: true, body: out stack);

            // Two-column layout: left = orange icon circle, right = content
            var bodyGrid = new Grid();
            bodyGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            bodyGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Left — orange circle with warning icon
            var iconRing = new Border
            {
                Width             = 64,
                Height            = 64,
                CornerRadius      = new CornerRadius(32),
                Background        = new SolidColorBrush(Color.FromRgb(55, 25, 8)),
                BorderBrush       = new SolidColorBrush(Color.FromRgb(220, 95, 20)),
                BorderThickness   = new Thickness(2),
                Margin            = new Thickness(0, 0, 20, 0),
                VerticalAlignment = VerticalAlignment.Top,
            };
            iconRing.Child = new TextBlock
            {
                Text                = "\u26A0",
                FontFamily          = new FontFamily("Segoe UI Symbol"),
                FontSize            = 28,
                Foreground          = new SolidColorBrush(Color.FromRgb(220, 95, 20)),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
            };
            Grid.SetColumn(iconRing, 0);

            // Right — content stack
            var rightStack = new StackPanel();
            Grid.SetColumn(rightStack, 1);

            // Rule name
            rightStack.Children.Add(new TextBlock
            {
                Text         = string.IsNullOrWhiteSpace(ruleName) ? "Guard" : ("Guard: " + ruleName),
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 16,
                FontWeight   = FontWeights.Bold,
                Foreground   = new SolidColorBrush(Color.FromRgb(238, 238, 245)),
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 8),
            });

            // Condition bullets — orange dot + text
            foreach (var cond in conditions)
            {
                var condRow = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin      = new Thickness(0, 2, 0, 2),
                };
                condRow.Children.Add(new Ellipse
                {
                    Width             = 8,
                    Height            = 8,
                    Fill              = new SolidColorBrush(Color.FromRgb(220, 110, 30)),
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin            = new Thickness(0, 0, 8, 0),
                });
                condRow.Children.Add(new TextBlock
                {
                    Text             = cond.TrimStart('•', ' '),
                    FontFamily       = new FontFamily("Segoe UI"),
                    FontSize         = 13,
                    Foreground       = new SolidColorBrush(Color.FromRgb(222, 222, 232)),
                    TextWrapping     = TextWrapping.Wrap,
                    VerticalAlignment = VerticalAlignment.Center,
                });
                rightStack.Children.Add(condRow);
            }

            // "This is a rule you set for yourself."
            rightStack.Children.Add(new TextBlock
            {
                Text       = "This is a rule you set for yourself.",
                FontFamily = new FontFamily("Segoe UI"),
                FontSize   = 12,
                FontStyle  = FontStyles.Italic,
                Foreground = new SolidColorBrush(Color.FromRgb(130, 130, 148)),
                Margin     = new Thickness(0, 8, 0, 14),
            });

            // Orange info box — lock message + reconnect instruction
            var infoBox = new Border
            {
                CornerRadius    = new CornerRadius(8),
                Background      = new SolidColorBrush(Color.FromRgb(48, 23, 7)),
                BorderBrush     = new SolidColorBrush(Color.FromRgb(190, 85, 20)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(14, 10, 14, 10),
                Margin          = new Thickness(0, 0, 0, 18),
            };
            var infoStack = new StackPanel();
            infoStack.Children.Add(new TextBlock
            {
                Text         = string.Format("Broker disconnected. Locked for {0} minute{1}.",
                                   lockMins, lockMins == 1 ? "" : "s"),
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 13,
                FontWeight   = FontWeights.SemiBold,
                Foreground   = new SolidColorBrush(Color.FromRgb(230, 110, 30)),
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 4),
            });
            infoStack.Children.Add(new TextBlock
            {
                Text         = "To resume trading, reconnect manually via NinjaTrader's connection menu.",
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 11,
                Foreground   = new SolidColorBrush(Color.FromRgb(175, 140, 115)),
                TextWrapping = TextWrapping.Wrap,
            });
            infoBox.Child = infoStack;
            rightStack.Children.Add(infoBox);

            // Close button — orange, right-aligned
            var closeBtn = new Button
            {
                Content             = "Close",
                Padding             = new Thickness(28, 10, 28, 10),
                Background          = new SolidColorBrush(Color.FromRgb(210, 80, 20)),
                Foreground          = new SolidColorBrush(Colors.White),
                BorderThickness     = new Thickness(0),
                FontFamily          = new FontFamily("Segoe UI"),
                FontSize            = 13,
                FontWeight          = FontWeights.SemiBold,
                HorizontalAlignment = HorizontalAlignment.Right,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            closeBtn.Click += (_, __) => win.Close();
            rightStack.Children.Add(closeBtn);

            bodyGrid.Children.Add(iconRing);
            bodyGrid.Children.Add(rightStack);
            stack.Children.Add(bodyGrid);

            win.Show();

            // Execute the broker disconnect.
            try
            {
                foreach (var conn in NinjaTrader.Cbi.Connection.Connections)
                    conn.Disconnect();
            }
            catch (Exception ex)
            {
                LogWarning($"[Guard] Disconnect failed: {ex.Message}");
            }
        }

        // TIME DOMAIN CONTRACT (ARCHITECTURE.md §11 Landmine 10):
        //   `platformNow` MUST be in the same domain as `_positionEntryTimes[key]`
        //   — i.e. replay-platform time in Playback, wall-clock in Live.
        //   Callers obtain it from either `fill.Time` (for the snapshot taken
        //   immediately after a fill) or `_clock.EngineTime` (for timer ticks
        //   / order-change snapshots — must be read on the main thread; see
        //   Axiom A5 in REMEDIATION_PLAN_v1.2.md).  Passing `Globals.Now` or
        //   `DateTime.Now` directly is a LANDMINE — in Playback those return wall-clock
        //   on the background thread and produce fake multi-day `HoldSeconds`.
        //   The parameter is non-optional by design to prevent silent leaks.
        private List<PositionSnapshot> BuildPositionSnapshots(DateTime platformNow)
        {
            if (platformNow == default)
                throw new ArgumentException(
                    "BuildPositionSnapshots requires an explicit TradingClock-derived timestamp " +
                    "(fill.Time or _clock.EngineTime) — see ARCHITECTURE.md §11 Landmine 10.",
                    "platformNow");
            var snapshots = new List<PositionSnapshot>();

            // Instrument deduplication: Replikanto (and other copy-trading tools)
            // replicate positions across follower accounts.  PSI should measure ONE
            // trader's behavior, so we keep at most one snapshot per instrument.
            // Priority: the first account that owns a position wins.
            var seenInstruments = new System.Collections.Generic.HashSet<string>();

            List<Account> accountsCopy;
            lock (_accountsLock)
                accountsCopy = new List<Account>(_subscribedAccounts);

            // Partial-close grace: after an ATM partial fill the broker may
            // briefly cancel and re-submit the stop order.  During this window,
            // the position appears "naked" even though protection is being
            // reconfigured.  Wall-clock based so it works even when Globals.Now
            // is unreliable during Market Replay.
            bool inPartialCloseGrace = _partialCloseGate.IsActive();
            bool inDesyncGrace       = _desyncRepairGate.IsActive();

            foreach (Account account in accountsCopy)
            {
                try
                {
                    // ── Self-Healing: collect every NT8 position key for this account ──
                    var ntOpenKeys = new System.Collections.Generic.HashSet<string>();

                    foreach (Position pos in account.Positions)
                    {
                        if (pos.Instrument?.MasterInstrument == null) continue;
                        if (pos.MarketPosition == MarketPosition.Flat) continue;

                        string instrName = pos.Instrument.MasterInstrument.Name;
                        string key = PositionKey(account.Name, instrName);
                        ntOpenKeys.Add(key);

                        // ── Rule 1 & 4: direction sync only (NOT quantity) ────────
                        // IMPORTANT: We intentionally do NOT sync _positionQuantities here
                        // when the key already exists.
                        // NT8's Position event fires BEFORE the corresponding Execution event
                        // for the same fill.  If the timer polls between those two events it
                        // would see a reduced NT8 quantity (post-Position-update) while our
                        // tracking still holds the pre-fill value — causing a false desync that
                        // turns a partial close into a full close, wiping entry tracking and
                        // crashing PSI.
                        // Quantity tracking stays fully event-sourced from OnExecutionUpdate,
                        // which is correct and race-condition-free.  We bootstrap qty from NT8
                        // ONLY when the key is completely absent (lost after phantom-exit depletion)
                        // — in that case event-sourced tracking was already broken and NT8 is the
                        // only available source of truth.
                        _positionDirections.TryGetValue(key, out MarketPosition trackedDir);
                        bool dirMismatch       = trackedDir != pos.MarketPosition;
                        bool positionUntracked = dirMismatch && trackedDir == MarketPosition.Flat;

                        if (dirMismatch)
                        {
                            // Guard: if we have NO lifecycle for this position, the NT8 position
                            // may be stale (e.g., from a prior Playback/Sim session that left a
                            // residual position in the simulated account after ClearAllPositionTrackingState).
                            // Repopulating _positionDirections from such a stale position causes the
                            // next real entry fill to read that direction and be misclassified as a
                            // closing fill → EXIT logged, lifecycle never receives the fill,
                            // TryRecordTrade never fires → trades silently lost.
                            // When there is no lifecycle, the fill event handlers (OnExecutionUpdate +
                            // OnPositionUpdate) will mint the lifecycle and set the direction correctly
                            // the moment the real entry fill arrives.  We must NOT pre-populate here.
                            if (positionUntracked &&
                                !_lifecycles.ContainsKey(key) &&
                                !_retiringLifecycles.ContainsKey(key))
                            {
                                Log(string.Format(
                                    "[TradeMonitor] DESYNC rule1 SKIPPED {0}: NT8 dir={1} but no lifecycle " +
                                    "— stale position from prior session, ignoring.",
                                    key, pos.MarketPosition), LogLevel.Warning);
                                continue; // skip snapshot build for this stale position
                            }

                            Log(string.Format(
                                "[TradeMonitor] DESYNC REPAIRED {0}: tracked dir={1} NT8 dir={2}.",
                                key, trackedDir, pos.MarketPosition),
                                LogLevel.Warning);

                            _desyncRepairGate.Set();
                            _positionDirections[key] = pos.MarketPosition;
                            Log(string.Format("[TradeMonitor] DIRSET {0}={1} [site=DESYNC-rule1 prevTracked={2}]",
                                key, pos.MarketPosition, trackedDir), LogLevel.Warning);

                            // Always re-anchor qty from NT8 when the key is absent.
                            // A direction-only DESYNC repair (positionUntracked=false) leaves
                            // _positionQuantities empty when the previous phantom-exit sequence
                            // depleted it to zero and removed the key.  The missing key then
                            // triggers the isFullClose=true fallback on the very next partial
                            // close fill, clearing the direction prematurely and creating ghost state.
                            if (!_positionQuantities.ContainsKey(key))
                                _positionQuantities[key] = pos.Quantity;

                            if (positionUntracked)
                            {
                                if (!_positionEntryPrices.ContainsKey(key))
                                    _positionEntryPrices[key] = pos.AveragePrice;
                        // When the entry time is unknown (position discovered through
                        // BuildPositionSnapshots without having observed the entry fill),
                        // anchor the entry time to the current platform time so HoldSeconds
                        // starts at 0.  Using DateTime.MinValue here would cause
                        // (platformNow - DateTime.MinValue).TotalSeconds ≈ 2,027 years,
                        // which instantly triggers D5 Class A — a sentinel value leaking
                        // into time arithmetic (ARCHITECTURE.md §10 2026-04-23).
                                if (!_positionEntryTimes.ContainsKey(key))
                            _positionEntryTimes[key] = platformNow;
                            }
                        }

                        // ── Rule 2: always sync entry price to NT8 AveragePrice ───
                        _positionEntryPrices[key] = pos.AveragePrice;

                        // ── Instrument dedup: skip if another account already owns
                        // a snapshot for this instrument (Replikanto follower) ──────
                        if (!seenInstruments.Add(instrName))
                            continue;

                        // ── Build snapshot ────────────────────────────────────────
                        DateTime entryTime = _positionEntryTimes.TryGetValue(key, out DateTime et)
                            ? et
                            : platformNow;

                        double unrealizedPnl = pos.GetUnrealizedProfitLoss(
                            PerformanceUnit.Currency, 0);

                        bool hasStop = _profile.NoStopLossTrader || inPartialCloseGrace || inDesyncGrace;
                        if (!hasStop)
                        {
                            foreach (Order order in account.Orders)
                            {
                                if (order.Instrument?.MasterInstrument != pos.Instrument.MasterInstrument)
                                    continue;
                                if (order.OrderState != OrderState.Working &&
                                    order.OrderState != OrderState.Accepted) continue;
                                if (order.OrderType != OrderType.StopMarket &&
                                    order.OrderType != OrderType.StopLimit)
                                    continue;

                                bool coveringDirection =
                                    (pos.MarketPosition == MarketPosition.Long  &&
                                     (order.OrderAction == OrderAction.Sell ||
                                      order.OrderAction == OrderAction.SellShort)) ||
                                    (pos.MarketPosition == MarketPosition.Short &&
                                     (order.OrderAction == OrderAction.Buy ||
                                      order.OrderAction == OrderAction.BuyToCover));

                                if (coveringDirection) { hasStop = true; break; }
                            }
                        }

                        snapshots.Add(PositionSnapshot.Create(
                            key, unrealizedPnl, entryTime, platformNow, hasStop,
                            quantity: pos.Quantity,
                            minPnl:  _positionMinPnl.AddOrUpdate(
                                         key,
                                         Math.Min(unrealizedPnl, 0.0),
                                         (k, prev) => Math.Min(prev, unrealizedPnl))));
                    }

                    // ── Rule 3: remove ghost tracking for positions NT8 says are flat ──
                    string accountPrefix = account.Name + "::";
                    bool anyGhostRemoved = false;
                    foreach (string trackedKey in new System.Collections.Generic.List<string>(
                                 _positionDirections.Keys))
                    {
                        if (!trackedKey.StartsWith(accountPrefix)) continue;
                        if (ntOpenKeys.Contains(trackedKey)) continue;

                        Log(string.Format(
                            "[TradeMonitor] DESYNC REPAIRED {0}: tracked as open but NT8 is flat — clearing ghost.",
                            trackedKey),
                            LogLevel.Warning);

                        // Retire the lifecycle through the proper REMOVE path FIRST so that
                        // observed=True lifecycles are recorded before ghost state is wiped.
                        ReconcileLifecycleEdgeAtomic(trackedKey, account,
                            MarketPosition.Flat, 0.0, source: "Rule3-DESYNC");

                        _positionDirections.TryRemove(trackedKey, out _);
                        _positionQuantities.TryRemove(trackedKey, out _);
                        _positionEntryTimes.TryRemove(trackedKey, out _);
                        _positionEntryPrices.TryRemove(trackedKey, out _);
                        _positionMinPnl.TryRemove(trackedKey, out _);
                        anyGhostRemoved = true;
                    }

                    // Rule 3 is a position-tracking correction (same semantic class
                    // as Fix A / OnPositionUpdate).  Notify the engine so position-
                    // derived flags (overexposure, naked-exposure timer, D2/D5 raws,
                    // sustained violation streaks built on the ghost position) are
                    // cleared before the next poll applies EWMA — otherwise the
                    // ghost's residual state would keep attacking C_i.
                    if (anyGhostRemoved && _engine != null)
                        _engine.OnPositionTrackingCorrection();
                }
                catch (Exception ex)
                {
                    LogMonitorException("BuildPositionSnapshots account=" + account.Name, ex);
                }
            }

            return snapshots;
        }

        private static string PositionKey(string accountName, string instrumentName)
            => accountName + "::" + instrumentName;

        // =====================================================================
        // InferExitKind — classify a closing fill's exit intent (v1.1.1, E1)
        //
        // The ONLY objective fact NT8 gives us is the OrderType of the order
        // that produced this fill.  That fact — not order-creation timestamps,
        // not Name-string matching — is what we use, so the classification is
        // uniform across ATM brackets, SuperDOM-style post-entry stop placement,
        // Chart Trader right-click exits, and one-click flatten:
        //
        //   StopMarket / StopLimit  → ProtectiveStop   (disciplined exit)
        //   Limit                   → Target           (disciplined exit)
        //   Market / MIT            → Manual           (trader-initiated)
        //   anything else           → Unknown          (engine falls back to
        //                                               conservative pre-v1.1.1
        //                                               behaviour)
        //
        // For SuperDOM workflows where the stop is placed *after* entry, this
        // still classifies the eventual stop-triggered fill as ProtectiveStop
        // because at the moment of the fill the order IS an active Stop — the
        // discipline lens we want is "was this exit pre-committed vs hand-
        // pulled in the moment", and a Stop order (whenever placed) is the
        // trader's pre-committed answer.
        //
        // ExitKind is NOT derived from isClosingFill alone; opening fills,
        // reversal excess legs, and system-close conditions are flagged
        // explicitly by the caller.
        // =====================================================================
        private static ExitKind InferExitKind(Execution fill, bool isClosingFill, bool isReversal)
        {
            if (!isClosingFill) return ExitKind.Unknown;
            if (isReversal)     return ExitKind.Reversal;

            Order o = fill?.Order;
            if (o == null) return ExitKind.Unknown;

            switch (o.OrderType)
            {
                case OrderType.StopMarket:
                case OrderType.StopLimit:
                    return ExitKind.ProtectiveStop;

                case OrderType.Limit:
                    return ExitKind.Target;

                case OrderType.Market:
                case OrderType.MIT:
                    return ExitKind.Manual;

                default:
                    return ExitKind.Unknown;
            }
        }

        /// <summary>
        /// Maps an event timestamp to a session anchor date.
        /// The day boundary is calendar midnight — not <see cref="StrategyProfile.SessionStart"/>.
        /// SessionStart is a D6 trading-window boundary (penalty concept); it is not a
        /// session-reset boundary.  Decoupling them means a 6:28 AM pre-market fill
        /// (SessionStart = 6:30 AM) is correctly attributed to today, not yesterday.
        /// </summary>
        private static DateTime GetSessionAnchorDate(DateTime eventTime)
            => eventTime.Date;

        /// <summary>
        /// Records PSI to the session accumulator, checks alert thresholds,
        /// then forwards the value to the HUD window on the UI thread.
        /// Called from the NT8 event thread.
        /// </summary>
        /// <param name="fromFill">True when triggered by an execution fill (not timer/order).</param>
        /// <param name="eventTime">
        /// The platform/playback time of the triggering event (from a fill or
        /// `_clock.EngineTime`).  Stamps the PSI history record so the timeline
        /// chart shows platform/replay time, NOT wall-clock time.  Required —
        /// a wall-clock fallback would record today's date for replay events
        /// and invert the history chart in Market Replay sessions (see
        /// ARCHITECTURE.md §11 Landmine 10).
        /// </param>
        private void PushPsiToHud(double psi, bool fromFill = false,
                                  DateTime eventTime = default)
        {
            if (eventTime == default)
                eventTime = _clock != null ? _clock.EngineTime : DateTime.Now;
            // ── License gate ──────────────────────────────────────────────────────
            // When the trial has expired or the license is invalid/revoked, block
            // PSI output so the product cannot be used without a valid subscription.
            // Trial_Active, Licensed, and Offline_Grace all pass through normally.
            if (!_licenseManager.IsFunctional)
            {
                Application.Current?.Dispatcher.InvokeAsync(() =>
                    _overlayWindow?.UpdateBaselineStatus(GetHudBadgeText()));
                return;
            }

            // ── Session history (called on NT8 event thread — no UI access here)
            // eventTime is guaranteed non-default by the guard at the top of
            // the method; record directly.
            _currentSession.RecordPsi(eventTime, psi, fromFill);

            // ── Dimension debt values (read once; used by alerts, peak tracking, and HUD)
            // HUD bars show EWMA PSI-debt per dimension (unit: PSI points, 0-100).
            // Session recording (RecordTrade/RecordEntry) uses ScoreD1-D7
            // (instantaneous 0-1 signals) — those calls are not changed here.
            double d1 = _engine != null ? _engine.DebtD1 : 0;
            double d2 = _engine != null ? _engine.DebtD2 : 0;
            double d3 = _engine != null ? _engine.DebtD3 : 0;
            double d4 = _engine != null ? _engine.DebtD4 : 0;
            double d5 = _engine != null ? _engine.DebtD5 : 0;
            double d6 = _engine != null ? _engine.DebtD6 : 0;
            double d7 = _engine != null ? _engine.DebtD7 : 0;

            // ── Session peak debt tracking for Composure score ────────────────
            // D2, D3, D5 are the three structural rule dimensions.  D3 fires at
            // entry time (not close), D2/D5 are timer-driven.  All three need peak
            // EWMA debt tracked here so the Composure formula can use them.
            _currentSession.UpdatePeakDebts(d2, d3, d5, d6);

            // ── Alerts
            if (_monitoringEnabled)
                CheckAndFireAlerts(psi, d1, d2, d3, d4, d5, d6, d7);

            // ── HUD display
            //   Derive the OVERSIZE alarm directly from the authoritative
            //   position tracker — no cached flag in the engine — so the HUD
            //   banner clears the instant the position is reduced below
            //   SizeMax and mirrors what the engine now uses to choose the
            //   recovery tau (see PsiEngine.ApplyDecomposedEwma).
            bool overExposed = _profile != null && _positionQuantities
                .Any(kv => kv.Value > _profile.SizeMax);
            double carryDebt = _engine != null ? _engine.CarryDebt : 0;
            _currentSession.CopyHudStats(out int totalTrades, out int winTrades, out int alertsFired);
            double[] debts = { d1, d2, d3, d4, d5, d6, d7 };

            // v2 telemetry pulled once per push — pressure drives the mini-bar
            // and the per-dim last-commit-class tags the dominant-dim label +
            // each bar-row name with red [A] / amber [B] / muted [none].
            double pressureNow = _engine != null ? _engine.PressureDisplay : 0.0;
            CommitClass[] dimClasses = new CommitClass[8];
            if (_engine != null)
                for (int i = 1; i <= 7; i++) dimClasses[i] = _engine.GetDimLastClass(i);

            // ── PSI-drop attribution log ────────────────────────────────────
            //
            // If RecentCommits has grown since the last push, emit one
            // "[PSI v2] commit" line per new event and, when PSI also
            // materially dropped (≥ 5 pts), an "[PSI v2] drop" summary.
            // Gives the trader — and post-session review — a deterministic
            // explanation of every material PSI move.
            LogCommitAttribution(psi);

            // ── Drop notification ────────────────────────────────────────────
            // Only fires for Class A (hard rule breaks) — Class B signals are
            // already visible on the HUD dimension bars and a pop-up on top of
            // them is redundant noise while actively trading.
            // Fires whenever PSI drops ≥ 5 pts relative to the last anchor.
            string notifMsg   = null;
            bool   notifClass = false;
            if (psi < _lastNotifPsi - 4.0 && _engine != null && _profile != null)
            {
                CommitEvent[] commits  = _engine.RecentCommits;
                CommitEvent?  bestEvt  = null;
                double        bestScore = -1.0;
                for (int ci = commits.Length - 1; ci >= 0; ci--)
                {
                    double ageSec = (eventTime - commits[ci].Time).TotalSeconds;
                    if (ageSec > 20.0) break;
                    // Only consider Class A events for notification
                    if (commits[ci].Kind != CommitClass.A) continue;
                    double score = commits[ci].Amount;
                    if (bestEvt == null || score > bestScore)
                    {
                        bestEvt   = commits[ci];
                        bestScore = score;
                    }
                }
                // Only show banner if a Class A commit drove the drop
                if (bestEvt.HasValue && bestEvt.Value.Kind == CommitClass.A)
                {
                    notifMsg   = BuildDropNotif(bestEvt.Value, _lastNotifPsi - psi,
                                               _engine.LastD6ViolationDetail, totalTrades);
                    notifClass = true;

                    // Increment Alerts counter — one per violation episode.
                    // A 5 s wall-clock window groups all partial fills of the
                    // same entry decision into one count so that a 3-lot entry
                    // at SizeMax=1 (three separate ProcessExecution calls)
                    // registers as 1 alert, not 3.
                    // Class B signals (e.g. normal stop-loss hits) never reach
                    // here, so only genuine rule breaks are counted.
                    DateTime nowUtc = DateTime.UtcNow;
                    if ((nowUtc - _lastAlertCountUtc).TotalSeconds >= 5.0)
                    {
                        _currentSession.IncrementAlertsFired();
                        _lastAlertCountUtc = nowUtc;
                    }
                }
                _lastNotifPsi = psi;
            }
            else if (psi > _lastNotifPsi + 5.0)
            {
                _lastNotifPsi = psi;  // reset anchor on meaningful recovery
            }

            // ── Approach-state: status bar shows only SIZE overshoot ─────────────
            // Trades/Losses are already covered by the context line below the gauge
            // (⚠ Trade 4/3, P high, etc.).  Showing them here too creates duplicate
            // display.  Status bar is reserved for Size (because that has no other
            // display slot when the gauge just says "OVERSIZE" without a count).
            string approachText  = null;
            Color  approachColor = Color.FromRgb(180, 70, 70);
            if (_profile != null && _engine != null)
            {
                int    sizeCur = _positionQuantities.Count > 0
                    ? (int)_positionQuantities.Values.Max() : 0;
                double sizeMax = _profile.SizeMax;

                if (sizeMax > 0 && sizeCur > sizeMax)
                    approachText = string.Format("Size  {0} / {1:0}", sizeCur, sizeMax);
            }


            var dispPsi = _uiDispatcher;
            if (dispPsi != null && !dispPsi.HasShutdownStarted && !dispPsi.HasShutdownFinished)
            {
                try
                {
                    dispPsi.BeginInvoke(
                        (Action)(() =>
                {
                    if (_overlayWindow != null)
                    {
                                _overlayWindow.UpdatePsi(psi, fromFill, pressureNow);
                        _overlayWindow.UpdateOverExposed(overExposed);
                        _overlayWindow.UpdateDScores(d1, d2, d3, d4, d5, d6, d7);
                        _overlayWindow.UpdateSessionStats(totalTrades, winTrades, alertsFired);
                                _overlayWindow.UpdateSessionLimits(_profile?.TradesPerSessionMax ?? 0);
                        _overlayWindow.UpdateCarryDebt(carryDebt);
                                _overlayWindow.UpdatePeakDimLabel(debts, dimClasses,
                                    d6Detail: _engine.LastD6ViolationDetail);
                                _overlayWindow.UpdatePressure(pressureNow);
                                _overlayWindow.UpdateDimClasses(dimClasses);
                                if (notifMsg != null)
                                    _overlayWindow.ShowPsiDropNotif(notifMsg, notifClass);
                                _overlayWindow.UpdateApproachStatus(approachText, approachColor);
                            }
                        }));
                }
                catch (InvalidOperationException) { }
                catch (TaskCanceledException)     { }
            }

            // ── Guard evaluation ──────────────────────────────────────────────
            // Guard rules only execute when the user holds a Guard-tier licence
            // (or is in an active trial, which always has full access).
            // Core subscribers get PSI monitoring but no rule enforcement.
            if (_guardEngine != null && _licenseManager.HasGuard)
            {
                // Compute current unrealised P&L directly from NT8 account positions
                // (ground truth) rather than internal tracking to avoid desync errors.
                double unrealizedPnl = 0.0;
                List<Account> acctSnap;
                lock (_accountsLock) acctSnap = new List<Account>(_subscribedAccounts);
                foreach (var acct in acctSnap)
                {
                    try
                    {
                        foreach (Position pos in acct.Positions)
                            if (pos != null && pos.MarketPosition != MarketPosition.Flat)
                                unrealizedPnl += pos.GetUnrealizedProfitLoss(
                                    PerformanceUnit.Currency, 1.0);
                    }
                    catch { }
                }

                _guardEngine.Evaluate(new GuardContext
                {
                    Psi               = psi,
                    ConsecutiveLosses = _engine?.ConsecutiveLosses ?? 0.0,
                    SessionPnl        = _sessionPnl,
                    SessionMinutes    = _currentSession?.TotalMinutes ?? 0.0,
                    UnrealizedPnl     = unrealizedPnl,
                    LastTradePnl      = _lastTradePnl,
                });

                // Update HUD Risk Alert banner based on current active alert state.
                bool riskAlertNow = _guardEngine.IsRiskAlertActive;
                if (riskAlertNow)
                {
                    var names = _guardEngine.ActiveRiskAlertNames;
                    string banner = "⚠ RISK ALERT — " + string.Join(", ", names);
                    var dispRA = _uiDispatcher;
                    if (dispRA != null && !dispRA.HasShutdownStarted && !dispRA.HasShutdownFinished)
                        try { dispRA.BeginInvoke((Action)(() => _overlayWindow?.UpdateRiskAlertBanner(banner))); }
                        catch (InvalidOperationException) { } catch (TaskCanceledException) { }
                }
                else
                {
                    var dispRA = _uiDispatcher;
                    if (dispRA != null && !dispRA.HasShutdownStarted && !dispRA.HasShutdownFinished)
                        try { dispRA.BeginInvoke((Action)(() => _overlayWindow?.UpdateRiskAlertBanner(null))); }
                        catch (InvalidOperationException) { } catch (TaskCanceledException) { }
                }
            }
        }

        // =====================================================================
        // LogCommitAttribution
        //
        // Called on every HUD push with the current PSI.  If the engine's
        // RecentCommits array has grown since the previous push, emit one
        // line per new CommitEvent plus — when PSI has also dropped ≥ 5
        // pts since the previous push — a rollup "drop" line that
        // attributes the move to the events that fired during the window.
        //
        // This is the primary forensic trail for post-session review.
        // =====================================================================
        /// <summary>
        /// Clears the per-push attribution cursors so the first HUD push of
        /// a new session doesn't compare against the previous session's PSI
        /// or commit-count (which would emit spurious "drop" rollup lines).
        /// Called alongside every _engine.StartNewSession(...).
        /// </summary>
        private void ResetCommitAttributionTracking()
        {
            _lastSeenCommitCount = 0;
            _lastSeenPsi         = _engine != null ? _engine.CurrentPsi : 100.0;
        }

        // ─────────────────────────────────────────────────────────────────────
        // PSI-drop notification builder
        // ─────────────────────────────────────────────────────────────────────
        // Called from PushPsiToHud when PSI drops ≥ 5 pts. Picks the most
        // impactful recent commit (Class A first) and converts it to a plain-
        // English sentence that tells the trader EXACTLY which rule fired and
        // what their profile setting is — so "I forgot I set 2 lots max" is
        // never a mystery again.
        // ─────────────────────────────────────────────────────────────────────
        private string BuildDropNotif(CommitEvent ev, double psiDrop, string d6Detail, int sessionTrades)
        {
            // Banner copy rules:
            // • Behavioral label first — 1-3 words, lowercase, describes what happened
            // • PSI impact second — "−Npts" right-aligned after two spaces
            // • No ALL-CAPS, no punctuation, no explanations
            // • Matches Settings field names so the user can find the relevant setting
            string pts = string.Format("  −{0:F0}pts", psiDrop);
            bool classA = ev.Kind == CommitClass.A;
            switch (ev.Dim)
            {
                case 1: return classA
                    ? "Consecutive loss limit" + pts
                    : "Re-entered too fast" + pts;

                case 2: return "No stop-loss" + pts;

                case 3: return "Oversizing" + pts;

                case 4: return "Loss hold bias" + pts;

                case 5: return "Holding too long" + pts;

                case 6:
                    if (!string.IsNullOrEmpty(d6Detail) &&
                        (d6Detail.StartsWith("Session ended") || d6Detail.StartsWith("Session starts")))
                        return "Outside trading hours" + pts;
                    return "Daily loss limit" + pts;

                case 7: return classA
                    ? "Trade limit reached" + pts
                    : "Near trade limit" + pts;

                default: return "PSI drop" + pts;
            }
        }

        private void LogCommitAttribution(double psiNow)
        {
            if (_engine == null) return;
            CommitEvent[] events;
            try { events = _engine.RecentCommits; }
            catch { return; }
            if (events == null) return;

            int newCount = events.Length;
            int seen     = _lastSeenCommitCount;

            // If the ring buffer wrapped (pruned older entries) the absolute
            // index is lost; only process events at the tail that we haven't
            // seen yet.  The engine caps RecentCommits at 64, so for any
            // realistic tick rate this is correct.
            int start = (newCount > seen) ? seen : newCount;
            // Guard against out-of-order state (e.g. after StartNewSession
            // resets the queue): if newCount < seen, restart from 0.
            if (newCount < seen) start = 0;

            double psiBefore = _lastSeenPsi;

            for (int i = start; i < newCount; i++)
            {
                var ev = events[i];
                if (ev.Dim < 1 || ev.Dim > 7) continue;
                string dimName = (ev.Dim - 1 >= 0 && ev.Dim - 1 < PsiOverlayWindow.DimNamesStatic.Length)
                    ? PsiOverlayWindow.DimNamesStatic[ev.Dim - 1]
                    : ("D" + ev.Dim);
                string kindStr = ev.Kind == CommitClass.A ? "A" : "B";
                Log(string.Format(
                        "[PSI v2] commit {0:HH:mm:ss}  D{1}·{2} [{3}]  E+={4:F3}  P={5:F2}",
                        ev.Time, ev.Dim, dimName, kindStr, ev.Amount, ev.Pressure),
                    LogLevel.Information);
            }

            double psiDrop = psiBefore - psiNow;
            if (psiDrop >= 5.0 && newCount > seen)
            {
                Log(string.Format(
                        "[PSI v2] drop  PSI {0:F1} → {1:F1}  (−{2:F1})  attributed to {3} commit(s)",
                        psiBefore, psiNow, psiDrop, newCount - seen),
                    LogLevel.Information);
            }

            _lastSeenCommitCount = newCount;
            _lastSeenPsi         = psiNow;
        }

        private void OnOpenHudMenuItemClick(object sender, RoutedEventArgs e)
        {
            ShowOrActivateHud();
        }

        private void OnOpenDashMenuItemClick(object sender, RoutedEventArgs e)
        {
            ShowOrActivateHub();
        }

        private void ShowOrActivateHub(HubPage page = HubPage.Session)
        {
            if (Application.Current == null) return;
            Application.Current.Dispatcher.InvokeAsync(() =>
            {
                try
                {
                    if (_hubWindow == null)
                    {
                        _hubWindow = new MeridianDashboard(
                            _baseline, _profile, _historyStore,
                            _currentSession, GetActiveAccountNames(), LogWarning,
                            _licenseManager,
                            updateVersion:    _updateVersion,
                            updateNotes:      _updateNotes,
                            guardEngine:      _guardEngine,
                            monitor:          this,
                            accountsProvider: GetActiveAccountNames);
                        _hubWindow.BaselineResetRequested += OnHubBaselineReset;
                        _hubWindow.HistoryClearRequested  += OnHubHistoryClear;
                        _hubWindow.Closed += (s, ev) =>
                        {
                            if (_hubWindow != null)
                            {
                                _hubWindow.BaselineResetRequested -= OnHubBaselineReset;
                                _hubWindow.HistoryClearRequested  -= OnHubHistoryClear;
                            }
                            _hubWindow = null;
                        };
                        _hubWindow.Show();
                        _hubWindow.NavigateTo(page);
                    }
                    else
                    {
                        if (!_hubWindow.IsVisible)
                            _hubWindow.Show();
                        if (_hubWindow.WindowState == WindowState.Minimized)
                            _hubWindow.WindowState = WindowState.Normal;
                        _hubWindow.Activate();
                        _hubWindow.NavigateTo(page);
                    }
                }
                catch (Exception ex)
                {
                    Log("[Hub] ShowOrActivateHub EXCEPTION: " + ex.GetType().Name +
                        " — " + ex.Message + "\n" + ex.StackTrace,
                        LogLevel.Error);
                    _hubWindow = null;  // reset so next click retries from scratch
                }
            });
        }

        private void OnHubBaselineReset()
        {
            _baseline = new TradeBaseline();
            _baseline.SaveToFile(LogWarning);
            _engine = new PsiEngineV2(_profile, _baseline,
                                     PsiEngineV2Config.FromProfile(_profile));
            _engine.SetDebugLogger(msg => Log(msg, LogLevel.Information));
            _engine.StartNewSession(100.0);
            ResetCommitAttributionTracking();

            Log("[TradeMonitor] Baseline RESET by user — all historical data cleared.",
                LogLevel.Warning);

            _overlayWindow?.UpdateBaselineStatus(GetHudBadgeText());
            _hubWindow?.UpdateDataRefs(_baseline, _profile);
        }

        private void OnHubHistoryClear()
        {
            // Clear sessions in-place so the Hub's existing reference sees the change.
            // (Replacing with a new object would orphan the Hub's copy.)
            _historyStore.Sessions.Clear();
            _historyStore.SaveToFile(LogWarning);

            Log("[TradeMonitor] Session history CLEARED by user.", LogLevel.Warning);
        }

        // =====================================================================
        // GetPsiInsightSnapshot
        //
        // Point-in-time read of the V2 engine's observability surface for the
        // Dashboard Session Insight panel.  All values are copies — the caller
        // can render them on the UI thread without holding any engine lock.
        // =====================================================================
        public PsiInsightSnapshot GetPsiInsightSnapshot()
        {
            var snap = new PsiInsightSnapshot(empty: true);
            if (_engine == null) return snap;
            snap.CurrentPsi         = _engine.CurrentPsi;
            snap.CurrentPressure    = _engine.Pressure;
            snap.PeakPressure       = _engine.PeakPressure;
            snap.ClassACommitCount  = _engine.ClassACommitCountThisSession;
            snap.PeakSeverityPerDim = _engine.PeakSeverityPerDim;
            snap.RecentCommits      = _engine.RecentCommits;
            for (int i = 1; i <= 7; i++)
                snap.DimLastClass[i] = _engine.GetDimLastClass(i);
            return snap;
        }

        // =====================================================================
        // GetDiagnosticsSnapshot
        //
        // Assembles a point-in-time copy of every piece of state useful for
        // a support report.  Must be called on the UI thread (same thread
        // that owns _currentSession, _engine, _guardEngine, etc.) so that
        // all reads are consistent.  The returned snapshot contains only
        // value-type copies and immutable strings; DiagnosticsExporter can
        // safely serialize it from a background Task thread.
        // =====================================================================
        internal DiagnosticsSnapshot GetDiagnosticsSnapshot()
        {
            var snap = new DiagnosticsSnapshot
            {
                ProductVersion = ProductVersion,
                ExportTimeUtc  = DateTime.UtcNow,
                MachineName    = Environment.MachineName,
                OsVersion      = Environment.OSVersion.ToString(),
                TradingMode    = _clock.Mode.ToString(),
                ActiveAccounts = GetActiveAccountNames().ToArray(),
            };

            // ── Profile ───────────────────────────────────────────────────────
            if (_profile != null)
            {
                snap.SessionStartHour               = _profile.SessionStartHour;
                snap.SessionStartMinute             = _profile.SessionStartMinute;
                snap.SessionEndHour                 = _profile.SessionEndHour;
                snap.SessionEndMinute               = _profile.SessionEndMinute;
                snap.SessionWindowEnabled           = _profile.SessionWindowEnabled;
                snap.SlTicksMax                     = _profile.SlTicksMax;
                snap.SizeMin                        = _profile.SizeMin;
                snap.SizeMax                        = _profile.SizeMax;
                snap.TradesPerSessionMin            = _profile.TradesPerSessionMin;
                snap.TradesPerSessionMax            = _profile.TradesPerSessionMax;
                snap.MaxHoldMinutes                 = _profile.MaxHoldMinutes;
                snap.NoStopLossTrader               = _profile.NoStopLossTrader;
                snap.NoStopGraceSeconds             = _profile.NoStopGraceSeconds;
                snap.MaxDailyLossUsd                = _profile.MaxDailyLossUsd;
                snap.PauseAfterNLosses              = _profile.PauseAfterNLosses;
                snap.ExcludeStrategyOrders          = _profile.ExcludeStrategyOrders;
                snap.Sensitivity                    = _profile.Sensitivity.ToString();
                snap.ColdStartInterTradeGapPriorSec = _profile.ColdStartInterTradeGapPriorSec;
                snap.ReversalPenaltyFactor          = _profile.ReversalPenaltyFactor;
            }

            // ── Engine state ──────────────────────────────────────────────────
            if (_engine != null)
            {
                snap.CurrentPsi        = _engine.CurrentPsi;
                snap.CurrentPressure   = _engine.Pressure;
                snap.PeakPressure      = _engine.PeakPressure;
                snap.ConsecutiveLosses = (int)_engine.ConsecutiveLosses;
                snap.ClassACommitCount = _engine.ClassACommitCountThisSession;

                snap.Evidence      = new double[8];
                snap.SeverityPct   = new double[8];
                snap.PeakSeverityPct = new double[8];
                snap.DimLastClass  = new string[8];
                var peak = _engine.PeakSeverityPerDim;

                snap.Evidence[1]  = _engine.EvidenceD1;
                snap.Evidence[2]  = _engine.EvidenceD2;
                snap.Evidence[3]  = _engine.EvidenceD3;
                snap.Evidence[4]  = _engine.EvidenceD4;
                snap.Evidence[5]  = _engine.EvidenceD5;
                snap.Evidence[6]  = _engine.EvidenceD6;
                snap.Evidence[7]  = _engine.EvidenceD7;

                snap.SeverityPct[1] = _engine.ScoreD1 * 100.0;
                snap.SeverityPct[2] = _engine.ScoreD2 * 100.0;
                snap.SeverityPct[3] = _engine.ScoreD3 * 100.0;
                snap.SeverityPct[4] = _engine.ScoreD4 * 100.0;
                snap.SeverityPct[5] = _engine.ScoreD5 * 100.0;
                snap.SeverityPct[6] = _engine.ScoreD6 * 100.0;
                snap.SeverityPct[7] = _engine.ScoreD7 * 100.0;

                for (int i = 1; i <= 7; i++)
                {
                    snap.PeakSeverityPct[i] = peak != null && peak.Length > i ? peak[i] : 0.0;
                    var cls = _engine.GetDimLastClass(i);
                    snap.DimLastClass[i] = cls == CommitClass.A ? "A" :
                                           cls == CommitClass.B ? "B" : "-";
                }

                // Recent commits — convert to serializable lines
                var commits = _engine.RecentCommits;
                if (commits != null && commits.Length > 0)
                {
                    int start = Math.Max(0, commits.Length - 20);
                    var lines = new List<CommitEventLine>();
                    for (int k = start; k < commits.Length; k++)
                    {
                        var c = commits[k];
                        lines.Add(new CommitEventLine
                        {
                            TimeLocal = c.Time.ToLocalTime().ToString("HH:mm:ss.fff"),
                            Dim       = c.Dim,
                            Class     = c.Kind == CommitClass.A ? "A" : "B",
                            Amount    = c.Amount,
                            Pressure  = c.Pressure,
                        });
                    }
                    snap.RecentCommits = lines.ToArray();
                }
            }

            // ── Session summary ───────────────────────────────────────────────
            if (_currentSession != null)
            {
                snap.SessionDate              = _currentSession.Date;
                snap.TotalTrades              = _currentSession.TotalTrades;
                snap.WinTrades                = _currentSession.WinTrades;
                snap.TotalPnl                 = _currentSession.TotalPnl;
                snap.AlertsFired              = _currentSession.AlertsFired;
                snap.NakedPositionDetections  = _currentSession.NakedPositionDetections;
                snap.MinPsi                   = _currentSession.MinPsi;
                snap.StartPsi                 = _currentSession.StartPsi;
                snap.TimeInCautionMin         = _currentSession.TimeInCaution.TotalMinutes;
                snap.TimeInCriticalMin        = _currentSession.TimeInCritical.TotalMinutes;
            }
            snap.SessionPnlLive = _sessionPnl;

            // ── Baseline ──────────────────────────────────────────────────────
            if (_baseline != null)
            {
                snap.BaselineSessionCount  = _baseline.SessionCount;
                snap.BaselineMuLoss        = _baseline.MuLoss.Mean;
                snap.BaselineSigmaLoss     = _baseline.MuLoss.StdDev;
                snap.BaselineMuGapSec      = _baseline.InterTradeGapSec.Mean;
                snap.BaselineGapSampleCount= _baseline.InterTradeGapSamples?.Count ?? 0;
            }

            // ── Guard rules ───────────────────────────────────────────────────
            if (_guardEngine != null)
            {
                var rules = _guardEngine.Rules;
                var ruleLines = new List<GuardRuleLine>();
                foreach (var r in rules)
                {
                    var line = new GuardRuleLine
                    {
                        Enabled = r.Enabled,
                        Name    = string.IsNullOrWhiteSpace(r.Name) ? "(unnamed)" : r.Name,
                        Action  = r.Action.ToString(),
                        LastTriggeredThisSession = false,
                    };
                    var condParts = new List<string>();
                    if (r.Conditions != null)
                    {
                        foreach (var cond in r.Conditions)
                            condParts.Add($"{cond.Type} >= {cond.Threshold}");
                    }
                    string logic = r.Logic == GuardConditionLogic.Any ? "ANY" : "ALL";
                    line.Conditions = condParts.Count > 0
                        ? $"[{logic}] " + string.Join("; ", condParts)
                        : "(none)";
                    line.LastTriggeredThisSession =
                        r.LastTriggeredUtc != DateTime.MinValue &&
                        r.LastTriggeredUtc.Date == DateTime.Today;
                    ruleLines.Add(line);
                }
                snap.GuardRules = ruleLines.ToArray();
            }

            // ── Integrity ─────────────────────────────────────────────────────
            try
            {
                var intSnap = BuildIntegritySnapshot();
                var violations = IntegrityCheck.Run(intSnap);
                snap.IntegrityStatus = violations.Count == 0
                    ? "OK — no violations"
                    : IntegrityCheck.FormatReport(violations, DateTime.Now);
            }
            catch (Exception ex)
            {
                snap.IntegrityStatus = "Check failed: " + ex.Message;
            }

            return snap;
        }

        private List<string> GetActiveAccountNames()
        {
            var names = new List<string>();
            lock (_accountsLock)
            {
                foreach (var acct in _subscribedAccounts)
                {
                    if (!string.IsNullOrEmpty(acct.Name))
                        names.Add(acct.Name);
                }
            }
            if (names.Count == 0)
            {
                try
                {
                    foreach (Account acct in Account.All)
                    {
                        if (string.IsNullOrEmpty(acct.Name)) continue;
                        if (!IsAccountActive(acct)) continue;
                        names.Add(acct.Name);
                    }
                }
                catch (Exception ex)
                {
                    LogMonitorException("GetActiveAccountNames (Account.All scan)", ex);
                }
            }
            return names;
        }

        // ── Display settings public API (called from Dashboard) ──────────────

        private static string DisplaySettingsPath => System.IO.Path.Combine(
            NinjaTrader.Core.Globals.UserDataDir,
            "AddOns", "PsiMonitorDisplay.xml");

        /// <summary>Current display settings; read by the Dashboard to populate UI.</summary>
        internal DisplaySettings CurrentDisplaySettings => _displaySettings;

        /// <summary>
        /// Persists new display settings and applies them to the live HUD
        /// immediately if it is open.  Safe to call from any thread.
        /// </summary>
        internal void UpdateDisplaySettings(DisplaySettings s)
        {
            if (s == null) return;
            _displaySettings = s;
            s.Save(DisplaySettingsPath);
            if (Application.Current != null)
                Application.Current.Dispatcher.InvokeAsync(
                    () => _overlayWindow?.ApplyDisplaySettings(s));
        }

        private void ShowOrActivateHud()
        {

            Application.Current.Dispatcher.InvokeAsync(() =>
            {
                if (_overlayWindow == null)
                {
                    _overlayWindow = new PsiOverlayWindow(_monitoringEnabled);
                    _overlayWindow.Closed                  += OnHudClosed;
                    _overlayWindow.DashboardRequested      += OnHudDashboardRequested;
                    _overlayWindow.MonitoringToggled       += OnHudMonitoringToggled;
                    _overlayWindow.MonitoringStopRequested += OnHudMonitoringStopRequested;
                    _overlayWindow.TestModeToggleRequested += OnHudTestModeToggle;
                    _overlayWindow.JournalEntryRequested   += OnHudJournalEntry;
                    _overlayWindow.Show();
                }
                else
                {
                    if (!_overlayWindow.IsVisible)
                        _overlayWindow.Show();
                    if (_overlayWindow.WindowState == WindowState.Minimized)
                        _overlayWindow.WindowState = WindowState.Normal;
                    // Note: deliberately not calling Activate() — the HUD must never
                    // steal focus from SuperDOM or other trading windows.
                }

                // Apply current display preferences and session limits first so
                // the window is fully configured before data arrives.
                _overlayWindow.ApplyDisplaySettings(_displaySettings);
                _overlayWindow.UpdateSessionLimits(_profile?.TradesPerSessionMax ?? 0);

                // Refresh from subscribed accounts (catches reconnects since startup).
                RefreshBaselineSuspendStatus();
                _overlayWindow.UpdateBaselineStatus(GetHudBadgeText());

                // Force an immediate full PSI poll so the window shows all current
                // state (PSI, trades, signals, timeline, pressure) the instant it
                // opens — without waiting up to 5 s for the next timer tick.
                // PsiPollTick_OnUiThread is safe here: we ARE on the UI thread.
                PsiPollTick_OnUiThread();
            });
        }

        private void OnHudClosed(object sender, EventArgs e)
        {
            if (_overlayWindow != null)
            {
                _overlayWindow.Closed                  -= OnHudClosed;
                _overlayWindow.DashboardRequested      -= OnHudDashboardRequested;
                _overlayWindow.MonitoringToggled       -= OnHudMonitoringToggled;
                _overlayWindow.MonitoringStopRequested -= OnHudMonitoringStopRequested;
                _overlayWindow.TestModeToggleRequested -= OnHudTestModeToggle;
                _overlayWindow.JournalEntryRequested   -= OnHudJournalEntry;
            }
            _overlayWindow = null;
        }

        private void OnHudDashboardRequested()
        {
            ShowOrActivateHub(HubPage.Session);
        }

        private void OnHudTestModeToggle()
        {
            if (_profile == null) return;

            if (_profile.IsTestModeActive)
                _profile.DeactivateTestMode();
            else
                _profile.ActivateTestMode();

            _profile.SaveToFile(LogWarning);
            RefreshBaselineSuspendStatus();

            if (_overlayWindow != null)
                _overlayWindow.UpdateBaselineStatus(GetHudBadgeText());
        }

        private void OnHudJournalEntry(JournalKind kind, JournalEmotion emotion, string note)
        {
            // Called on WPF thread from PsiOverlayWindow; RecordJournalEntry is thread-safe.
            RecordJournalEntry(kind, emotion, note);
        }

        /// <summary>
        /// Scans Account.All for accounts that should be monitored but haven't
        /// been subscribed yet (e.g. Playback101 was Disconnected when
        /// State.Configure ran, but has since reconnected).
        /// Called every 30 seconds from the position timer.
        /// </summary>
        // =====================================================================
        // Account subscription — event-driven primary path
        // =====================================================================
        // NT8 raises Account.AccountStatusUpdate (static event) whenever any
        // account's connection status changes.  Subscribing here means Playback101
        // and Sim101 are wired the instant the user starts Market Replay / connects
        // the simulator — zero latency, no polling required.
        //
        // Epoch detection uses OBJECT REFERENCE identity, not string name.
        // NT8 can create a brand-new Account instance on a timeline scrub without
        // firing a clean Disconnect event first.  String-keyed timestamps would
        // treat this silently-replaced object as the same epoch, locking the
        // bootstrap window at the old T0 and causing C2 to promote every new ghost
        // into a real trade (the reference-identity paradox fixed here).
        //
        // Thread-safety: NT8 fires this on a background thread.  All mutations are
        // protected by _accountsLock.
        // =====================================================================

        private void OnAccountStatusUpdate(object sender, AccountStatusEventArgs e)
        {
            try
            {
                var account = sender as Account;
                if (account == null) return;

                if (IsAccountActive(account))
                {
                    // Account is Connected/Connecting.
                    // TrySubscribeAccount handles both new-epoch detection (new object
                    // reference) and same-epoch deduplication (same reference, no-op).
                    TrySubscribeAccount(account);
                }
                else
                {
                    // Account is Disconnected/ConnectionLost.
                    // Clean disconnects still clear state explicitly so the next Connect
                    // starts fresh.  (New-object reconnects without a prior Disconnect
                    // are handled by the reference guard in TrySubscribeAccount.)
                lock (_accountsLock)
                {
                        Account cachedRef;
                        if (_activeAccountRefs.TryGetValue(account.Name, out cachedRef)
                            && cachedRef != null)
                        {
                            cachedRef.ExecutionUpdate -= OnExecutionUpdate;
                            cachedRef.OrderUpdate     -= OnOrderUpdate;
                            cachedRef.PositionUpdate  -= OnPositionUpdate;
                            _subscribedAccounts.Remove(cachedRef);
                        }
                        _activeAccountRefs.Remove(account.Name);
                        _accountSubscribedAt.TryRemove(account.Name, out _);

                        Log(string.Format(
                            "[TradeMonitor] Account {0} disconnected — subscription and bootstrap window cleared.",
                            account.Name), LogLevel.Information);
                    }
                }
            }
            catch (Exception ex) { LogMonitorException("OnAccountStatusUpdate", ex); }
        }

        /// <summary>
        /// Idempotent, thread-safe helper that subscribes <paramref name="account"/>
        /// to the three PSI event handlers.  Safe to call from any thread and from
        /// any code path that discovers an account (State.Active initial loop,
        /// OnAccountStatusUpdate Connected event).
        ///
        /// Epoch detection uses object-reference identity: a new Account instance
        /// is always treated as a new connection epoch even when NT8 skips the
        /// Disconnect event (e.g. Market Replay timeline scrub).  The bootstrap
        /// timestamp is force-overwritten for new epochs and left unchanged for
        /// same-epoch duplicate Connected events.
        /// </summary>
        private void TrySubscribeAccount(Account account)
        {
            if (account == null) return;
            if (_profile == null || !_profile.ShouldMonitor(account.Name)) return;
            if (!IsAccountActive(account)) return;

            lock (_accountsLock)
            {
                // Epoch boundary: either (a) first connection for this name, or (b) NT8
                // created a new Account object — even without a prior Disconnect this is
                // a new replay/simulator epoch requiring a fresh bootstrap window.
                Account cachedRef;
                bool isNewEpoch = !_activeAccountRefs.TryGetValue(account.Name, out cachedRef)
                                  || !ReferenceEquals(cachedRef, account);

                if (isNewEpoch)
                {
                    // Step 1 — Remove old handlers.
                    // After this point no fill from the OLD epoch's Account object can
                    // enter the engine, even if NT8 queued one concurrently.
                    if (cachedRef != null)
                    {
                        cachedRef.ExecutionUpdate -= OnExecutionUpdate;
                        cachedRef.OrderUpdate     -= OnOrderUpdate;
                        cachedRef.PositionUpdate  -= OnPositionUpdate;
                        _subscribedAccounts.Remove(cachedRef);
                    }

                    // Step 2 — Reset all session state SYNCHRONOUSLY.
                    // This is the only window in which no fill can arrive from EITHER
                    // epoch: old object is unsubscribed (Step 1), new object is not yet
                    // wired (Step 3).  The reset is therefore completely race-free.
                    // All operations are thread-safe from a background thread — the
                    // identical block runs on the fill-processing thread in
                    // OnExecutionUpdate's rewind path today.
                    ResetForNewEpoch(account.Name);

                    // Step 3 — Wire new handlers.  Fills from the NEW epoch can now
                    // arrive, and they land on the clean state established in Step 2.
                    account.ExecutionUpdate -= OnExecutionUpdate;
                    account.OrderUpdate     -= OnOrderUpdate;
                    account.PositionUpdate  -= OnPositionUpdate;
                        account.ExecutionUpdate += OnExecutionUpdate;
                        account.OrderUpdate     += OnOrderUpdate;
                        account.PositionUpdate  += OnPositionUpdate;
                        _subscribedAccounts.Add(account);

                    // Step 4 — Anchor references and bootstrap window.
                    _activeAccountRefs[account.Name]   = account;
                    _accountSubscribedAt[account.Name] = DateTime.UtcNow;

                    Log("[TradeMonitor] Subscribed account: " + account.Name +
                        " — PSI monitoring active.", LogLevel.Information);
                }
                else
                {
                    // Same Account object reference, same epoch — duplicate Connected event.
                    // Defensive -=, += keeps exactly one handler registered, but the bootstrap
                    // timestamp is NOT updated (overwriting it pushes the window forward again).
                    account.ExecutionUpdate -= OnExecutionUpdate;
                    account.OrderUpdate     -= OnOrderUpdate;
                    account.PositionUpdate  -= OnPositionUpdate;
                    account.ExecutionUpdate += OnExecutionUpdate;
                    account.OrderUpdate     += OnOrderUpdate;
                    account.PositionUpdate  += OnPositionUpdate;
                }
            }
        }

        /// <summary>
        /// Returns true if the account has an active (connected or connecting) link.
        /// Failed, expired, or disconnected prop-firm accounts return false.
        /// </summary>
        private bool IsAccountActive(Account acct)
        {
            try
            {
                if (acct?.Connection == null) return false;
                var status = acct.Connection.Status;
                return status == ConnectionStatus.Connected ||
                       status == ConnectionStatus.Connecting;
            }
            catch (Exception ex)
            {
                LogMonitorException("IsAccountActive(" + (acct?.Name ?? "?") + ")", ex);
                return false;
            }
        }

        // Simulation / Playback detection lives in TradingClock.InferMode.
        // The private DetectSimPlaybackForAccount wrapper that used to live
        // here has been removed — see TradingClock.cs.

        /// <summary>
        /// Re-evaluates baseline suspension by scanning all subscribed accounts
        /// and the TestMode flag.  Called at startup, on HUD open, and from the
        /// 30-second position timer so account reconnects are caught promptly.
        ///
        /// Also mirrors the observed mode onto the authoritative
        /// <see cref="TradingClock"/>, which raises ModeChanged on transitions
        /// and triggers the engine's ResetClockAnchor via OnTradingModeChanged.
        /// </summary>
        private void RefreshBaselineSuspendStatus()
        {
            TradingMode observed = TradingMode.Unknown;
            lock (_accountsLock)
            {
                foreach (var acct in _subscribedAccounts)
                {
                    TradingMode m = TradingClock.InferMode(acct);
                    // Prefer the strongest observed mode: Playback > Simulation > Live.
                    if (m == TradingMode.Playback) { observed = TradingMode.Playback; break; }
                    if (m == TradingMode.Simulation) observed = TradingMode.Simulation;
                    else if (observed == TradingMode.Unknown && m == TradingMode.Live)
                        observed = TradingMode.Live;
                }
            }

            _clock.UpdateMode(observed);

            string reason = observed == TradingMode.Playback ? "PLAYBACK"
                          : observed == TradingMode.Simulation ? "SIM"
                          : (_profile != null && _profile.IsTestModeActive) ? "TEST"
                          : null;

            _baselineRecordingSuspended = reason != null;
            _baselineSuspendReason      = reason;
        }

        /// <summary>
        /// Returns the badge string to show on the HUD: the suspend reason
        /// if recording is paused, "LEARNING" if the baseline is immature, or null.
        /// </summary>
        private string GetHudBadgeText()
        {
            // License status overrides all other badge messages.
            // Default to Trial_Expired (fail-closed) when no license manager is
            // present so a missing manager surfaces as "needs activation" rather
            // than a phantom trial-active badge.
            var ls = _licenseManager?.Status ?? LicenseStatus.Trial_Expired;

            if (ls == LicenseStatus.Trial_Active)
            {
                int d = _licenseManager?.TrialDaysRemaining ?? LicenseManager.TrialDays;
                return $"TRIAL — {d}d left";
            }
            if (ls == LicenseStatus.Trial_Expired)
            {
                // The local 7-day countdown has been removed (TrialDays == 0):
                // the trial period is administered by Whop on the subscription itself.
                // A user in Trial_Expired with TrialDays==0 has never had a local
                // trial — they just need to enter their key.  Showing "TRIAL EXPIRED"
                // would be misleading and increase support load.
                return LicenseManager.TrialDays == 0 ? "ACTIVATE LICENSE" : "TRIAL EXPIRED";
            }
            if (ls == LicenseStatus.Expired)       return "LICENSE EXPIRED";
            if (ls == LicenseStatus.Invalid)       return "INVALID KEY";
            if (ls == LicenseStatus.Offline_Grace) return "OFFLINE";

            // Plan C: surface remaining Guard-sampling days for Core users so they
            // know when the preview window ends — drives the upgrade decision.
            int sampleDays = _licenseManager?.CoreGuardSamplingDaysRemaining ?? 0;
            if (sampleDays > 0)
            {
                if (_baselineSuspendReason != null) return _baselineSuspendReason;
                if (_baseline != null && _baseline.SessionCount < 5) return "LEARNING";
                return $"GUARD PREVIEW — {sampleDays}d left";
            }

            if (_baselineSuspendReason != null) return _baselineSuspendReason;
            if (_baseline != null && _baseline.SessionCount < 5) return "LEARNING";

            // Update available — lowest priority badge, shown only when the system
            // is otherwise healthy so it doesn't compete with important warnings.
            if (_updateVersion != null) return $"⬆ UPDATE {_updateVersion}";

            return null;
        }

        // ── Version check ─────────────────────────────────────────────────────

        /// <summary>
        /// Fetches the hosted version.json and compares with ProductVersion.
        /// Silently ignored on any network error — never blocks or crashes NT8.
        /// Sets _updateVersion and _updateNotes when a newer version is found.
        /// </summary>
        private async System.Threading.Tasks.Task CheckForUpdateAsync()
        {
            try
            {
                using (var http = new System.Net.Http.HttpClient
                       { Timeout = System.TimeSpan.FromSeconds(8) })
                {
                    string json = await http.GetStringAsync(LicenseManager.VersionCheckUrl);

                    string latest = ExtractJsonField(json, "version");
                    string notes  = ExtractJsonField(json, "notes");

                    if (!string.IsNullOrEmpty(latest) && IsNewerVersion(latest, ProductVersion))
                    {
                        _updateVersion = latest;
                        _updateNotes   = notes ?? "";
                        // Refresh the HUD badge to show the update notification.
                        Application.Current?.Dispatcher.InvokeAsync(() =>
                            _overlayWindow?.UpdateBaselineStatus(GetHudBadgeText()));
                    }
                }
            }
            catch { /* network unavailable — silently ignored */ }
        }

        /// <summary>Compares semantic version strings "major.minor.patch".</summary>
        private static bool IsNewerVersion(string candidate, string current)
        {
            try
            {
                int[] Parse(string v)
                {
                    var parts = v.Split('.');
                    return new int[]
                    {
                        parts.Length > 0 ? int.Parse(parts[0]) : 0,
                        parts.Length > 1 ? int.Parse(parts[1]) : 0,
                        parts.Length > 2 ? int.Parse(parts[2]) : 0,
                    };
                }
                int[] a = Parse(candidate), b = Parse(current);
                for (int i = 0; i < 3; i++)
                {
                    if (a[i] > b[i]) return true;
                    if (a[i] < b[i]) return false;
                }
                return false;
            }
            catch { return false; }
        }

        /// <summary>Minimal JSON string field extractor (no external dependencies).</summary>
        private static string ExtractJsonField(string json, string field)
        {
            if (string.IsNullOrEmpty(json)) return null;
            string key = $"\"{field}\":";
            int pos = json.IndexOf(key, StringComparison.OrdinalIgnoreCase);
            if (pos < 0) return null;
            int start = pos + key.Length;
            while (start < json.Length && (json[start] == ' ' || json[start] == '\t')) start++;
            if (start >= json.Length || json[start] != '"') return null;
            start++;
            int end = json.IndexOf('"', start);
            return end < 0 ? null : json.Substring(start, end - start);
        }

        // ── Monitoring enable / disable ───────────────────────────────────────

        /// <summary>
        /// Enables or disables all PSI data processing.  Called from the HUD
        /// pill-toggle and from the ✕ close button on the HUD window.
        /// </summary>
        private void SetMonitoring(bool enabled)
        {
            _monitoringEnabled = enabled;
            if (enabled)
            {
                _psiPollTimer?.Start();
                _adminTimer?.Start();
                _integrityTimer?.Start();
            }
            else
            {
                _psiPollTimer?.Stop();
                _adminTimer?.Stop();
                _integrityTimer?.Stop();
            }

            // Sync the HUD pill visual (window may already be closed — guard).
            Application.Current?.Dispatcher.InvokeAsync(
                () => _overlayWindow?.SetMonitoringState(enabled));
        }

        private void OnHudMonitoringToggled(bool enabled)
        {
            SetMonitoring(enabled);
        }

        private void OnHudMonitoringStopRequested()
        {
            SetMonitoring(false);
            // The HUD window closes itself after firing this event.
        }

        /// <summary>
        /// NT8 Log() wrapper used as a callback for profile/baseline persistence errors.
        /// </summary>
        private void LogWarning(string message)
        {
            Log(message, LogLevel.Warning);
        }

        /// <summary>
        /// Logs swallowed exceptions from defensive catch blocks so diagnostics
        /// appear in the NinjaScript Output window instead of failing silently.
        /// </summary>
        private void LogMonitorException(string context, Exception ex)
        {
            if (ex == null) return;
            Log("[TradeMonitor] " + context + ": " + ex.GetType().Name + " — " + ex.Message,
                LogLevel.Warning);
        }

        // ── Alert helpers ─────────────────────────────────────────────────────

        /// <summary>
        /// Compares the current PSI zone against the last alerted zone.
        /// Fires a voice + toast alert on downward transitions.
        /// Cooldowns prevent spam: Critical ≥3 min, Caution ≥5 min.
        /// The latch resets to Stable when PSI recovers, allowing fresh alerts
        /// on the next drop.
        /// </summary>
        private void CheckAndFireAlerts(double psi,
                                        double d1, double d2, double d3,
                                        double d4, double d5, double d6, double d7)
        {
            PsiZone zone = SessionData.ZoneOf(psi);

            // Reset latch when PSI returns to Stable so the next drop can alert again.
            if (zone == PsiZone.Stable)
            {
                _prevAlertZone = PsiZone.Stable;
                return;
            }

            // Identify the dominant dimension (highest EWMA debt) for the alert text.
            // Using EWMA debt (not instantaneous raw) gives the sustained driver, not
            // a momentary spike — more useful for the trader to act on.
            string[] dimLabels = { "Revenge Trading", "No Stop-Loss", "Oversizing",
                                   "Loss Hold Bias", "Holding Too Long", "Rule Violation", "Overtrading" };
            double[] debts = { d1, d2, d3, d4, d5, d6, d7 };
            int maxIdx = 0;
            for (int i = 1; i < 7; i++) if (debts[i] > debts[maxIdx]) maxIdx = i;

            // Build a plain-English culprit phrase that maps directly to Settings field names.
            // D6 gets a context-specific label (trading hours vs. daily loss limit).
            string culpritPlain = "";
            if (debts[maxIdx] > 1.0)
            {
                if (maxIdx == 5)
                {
                    string d6Detail = _engine.LastD6ViolationDetail;
                    if (!string.IsNullOrEmpty(d6Detail) &&
                        (d6Detail.StartsWith("Session ended") || d6Detail.StartsWith("Session starts")))
                        culpritPlain = "Outside Trading Hours";
                    else
                        culpritPlain = "Daily Loss Limit Hit";
                }
                else
                {
                    culpritPlain = dimLabels[maxIdx];
                }
            }
            string culpritSuffix = culpritPlain.Length > 0 ? " \u00b7 " + culpritPlain : "";

            // Alert-cooldown time source: wall-clock (Globals.Now). INTENTIONAL —
            // see psi-debug-protocol.mdc Step 5: voice-alert / toast cooldowns
            // measure "how long since the user last heard this alert" in REAL
            // seconds, not replay-simulated seconds.  An accelerated Market
            // Replay session must not spam the user with one voice alert per
            // wall-clock-second.  `now` here never flows into the engine.
            DateTime now = NinjaTrader.Core.Globals.Now;

            // CRITICAL transition (any zone → Critical, cooldown 3 min)
            if (zone == PsiZone.Critical &&
                _prevAlertZone != PsiZone.Critical &&
                (now - _lastCritAlert).TotalMinutes >= 3.0)
            {
                _lastCritAlert = now;
                _prevAlertZone = PsiZone.Critical;
                // NOTE: IncrementAlertsFired() is NOT called here.
                // Alerts counter is driven by Class A commit drops in PushPsiToHud
                // (5 s dedup window) so every genuine rule break is counted, not
                // just zone-transition notification events.
                TryPlayVoiceAlert("Composure critical. Stop trading now.");
                var dispCrit = _uiDispatcher;
                if (dispCrit != null && !dispCrit.HasShutdownStarted && !dispCrit.HasShutdownFinished)
                    try { dispCrit.BeginInvoke((Action)(() =>
                        new AlertToastWindow(
                            string.Format("PSI at {0}{1}", (int)psi, culpritSuffix),
                            isCritical: true,
                            title: "\ud83d\udd34  Stop Trading Now").Show())); }
                    catch (InvalidOperationException) { } catch (TaskCanceledException) { }
                return;
            }

            // WARNING transition (Stable/Caution → Warning, cooldown 5 min)
            if (zone == PsiZone.Warning &&
                _prevAlertZone != PsiZone.Warning && _prevAlertZone != PsiZone.Critical &&
                (now - _lastWarnAlert).TotalMinutes >= 5.0)
            {
                _lastWarnAlert = now;
                _prevAlertZone = PsiZone.Warning;
                TryPlayVoiceAlert("Composure warning. Slow down.");
                var dispWarn = _uiDispatcher;
                if (dispWarn != null && !dispWarn.HasShutdownStarted && !dispWarn.HasShutdownFinished)
                    try { dispWarn.BeginInvoke((Action)(() =>
                        new AlertToastWindow(
                            string.Format("PSI at {0}{1}", (int)psi, culpritSuffix),
                            isCritical: false,
                            title: "\u26a0  Composure Warning").Show())); }
                    catch (InvalidOperationException) { } catch (TaskCanceledException) { }
                return;
            }

            // CAUTION transition (from Stable only; don't re-alert if already in Caution/Warning)
            if (zone == PsiZone.Caution &&
                _prevAlertZone == PsiZone.Stable &&
                (now - _lastCautAlert).TotalMinutes >= 5.0)
            {
                _lastCautAlert = now;
                _prevAlertZone = PsiZone.Caution;
                TryPlayVoiceAlert("Composure dropping. Check your behavior.");
                var dispCaut = _uiDispatcher;
                if (dispCaut != null && !dispCaut.HasShutdownStarted && !dispCaut.HasShutdownFinished)
                    try { dispCaut.BeginInvoke((Action)(() =>
                        new AlertToastWindow(
                            string.Format("PSI at {0}{1}", (int)psi, culpritSuffix),
                            isCritical: false,
                            title: "\u26a1  Composure Dropping").Show())); }
                    catch (InvalidOperationException) { } catch (TaskCanceledException) { }
            }
        }

        /// <summary>
        /// Speaks text via System.Speech.Synthesis (loaded dynamically to avoid
        /// hard assembly dependency).  Falls back to a system exclamation beep.
        /// Runs on a background thread so the NT8 event thread is not blocked.
        /// </summary>
        // Prevents multiple TTS instances from overlapping (causes garbled/incomprehensible audio).
        private static volatile bool _voiceAlertPlaying = false;

        private void TryPlayVoiceAlert(string text)
        {
            // If a voice alert is already playing, don't queue another one on top of it.
            // Overlapping synthesis produces garbled audio that is impossible to understand.
            if (_voiceAlertPlaying) { PlayBeep(); return; }
            _voiceAlertPlaying = true;

            System.Threading.Tasks.Task.Run(() =>
            {
                try
                {
                    var asm = System.Reflection.Assembly.Load(
                        "System.Speech, Version=4.0.0.0, Culture=neutral, " +
                        "PublicKeyToken=31bf3856ad364e35");
                    var t = asm?.GetType("System.Speech.Synthesis.SpeechSynthesizer");
                    if (t == null) { PlayBeep(); return; }
                    using (var synth = (IDisposable)Activator.CreateInstance(t))
                    {
                        t.GetProperty("Volume")?.SetValue(synth, 100);
                        t.GetProperty("Rate")?.SetValue(synth, -2);
                        t.GetMethod("Speak", new[] { typeof(string) })
                         ?.Invoke(synth, new object[] { text });
                    }
                }
                catch (Exception ex)
                {
                    LogMonitorException("Voice alert (System.Speech)", ex);
                    PlayBeep();
                }
                finally { _voiceAlertPlaying = false; }
            });
        }

        private static void PlayBeep()
        {
            try { System.Media.SystemSounds.Exclamation.Play(); } catch { }
        }

    }

    // =========================================================================
    // PSI HUD overlay window  —  two-panel dashboard, Apple dark, animated
    // =========================================================================

    internal sealed class PsiOverlayWindow : Window
    {
        // ── Win32: z-order + selective keyboard activation ───────────────────
        // Default: WS_EX_NOACTIVATE — clicking the HUD never steals keyboard
        // focus from SuperDOM / hotkeys / Chart Trader.
        // Exception: when the user explicitly clicks the journal note TextBox,
        // we temporarily remove WS_EX_NOACTIVATE and call Activate() so the OS
        // routes keyboard input to this window.  On TextBox LostFocus the flag
        // is restored, returning the window to its passive state.
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hwnd, int nIndex);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hwnd, int nIndex, int dwNewLong);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter,
                                                int X, int Y, int cx, int cy, uint uFlags);
        // HWND_TOP (0): brings window to top of the non-topmost z-tier on click
        //              without making it permanently above all other windows.
        private static readonly IntPtr HWND_TOP = new IntPtr(0);

        private IntPtr _hwnd = IntPtr.Zero;   // set in OnSourceInitialized
        private bool   _noteBoxActive = false; // true while the note TextBox has keyboard focus

        internal void EnableNoteBoxTyping()
        {
            if (_hwnd == IntPtr.Zero || _noteBoxActive) return;
            _noteBoxActive = true;
            // Remove WS_EX_NOACTIVATE so the OS will route keyboard events here.
            SetWindowLong(_hwnd, -20, GetWindowLong(_hwnd, -20) & ~0x08000000);
            Activate();
            _hudNoteBox?.Focus();
        }

        internal void DisableNoteBoxTyping()
        {
            if (!_noteBoxActive) return;
            _noteBoxActive = false;
            // Restore WS_EX_NOACTIVATE — buttons / chips no longer steal focus.
            if (_hwnd != IntPtr.Zero)
                SetWindowLong(_hwnd, -20, GetWindowLong(_hwnd, -20) | 0x08000000);
        }

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            _hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
            SetWindowLong(_hwnd, -20 /*GWL_EXSTYLE*/,
                GetWindowLong(_hwnd, -20) | 0x08000000 /*WS_EX_NOACTIVATE*/);
            System.Windows.Interop.HwndSource.FromHwnd(_hwnd)?.AddHook(NoActivateHook);
        }

        private IntPtr NoActivateHook(IntPtr hwnd, int msg, IntPtr wParam,
                                              IntPtr lParam, ref bool handled)
        {
            if (msg == 0x0021 /*WM_MOUSEACTIVATE*/)
            {
                if (_noteBoxActive)
                {
                    // Note box is being typed in — allow normal activation this tick.
                    return IntPtr.Zero;
                }
                // Re-assert topmost on every click so we stay above all NT8 windows
                // (including those that are themselves topmost, e.g. "Always on top"
                // SuperDOM).  Only fires when Topmost==true; when the user unpins we
                // skip the SetWindowPos so normal z-order applies.
                if (Topmost)
                {
                    SetWindowPos(hwnd, new IntPtr(-1) /*HWND_TOPMOST*/, 0, 0, 0, 0,
                                 0x0001 | 0x0002 /*SWP_NOSIZE | SWP_NOMOVE*/);
                }
                handled = true;
                return new IntPtr(3 /*MA_NOACTIVATE*/);
            }
            return IntPtr.Zero;
        }

        // ── Public events ────────────────────────────────────────────────────
        public event Action        DashboardRequested;
        public event Action<bool>  MonitoringToggled;
        public event Action        MonitoringStopRequested;
        public event Action        TestModeToggleRequested;

        // ── Animation state ──────────────────────────────────────────────────
        private double           _displayedPsi = 100.0;
        private double           _targetPsi    = 100.0;
        private double           _pulseIntensity = 0.0; // 1→0 flash on sharp PSI drop
        private bool             _isPaused;
        private readonly DispatcherTimer _animTimer;
        private          DispatcherTimer _layoutSaveTimer;   // debounce for SizeChanged / LocationChanged

        // ── Arc tip "live sensor" dot ─────────────────────────────────────────
        // White dot at the arc's moving end with a color halo (DropShadow ShadowDepth=0).
        // Opacity pulses so it reads as a live "needle tip" indicator.
        private readonly Ellipse           _arcTipDot;
        private readonly DropShadowEffect  _arcTipGlow;  // halo color tracks PSI color
        private double                     _tipPhase = 0.0;
        private double                     _tipRate  = 0.070; // rad/frame ≈ 3.0 s at 30 fps

        // ── Radar pulse ring (smoky breath) ───────────────────────────────────
        // A thick blurred ring emits from the gauge center and expands outward,
        // fading like smoke.  BlurEffect makes it diffuse/smoky (not a sharp line).
        // Speed tracks PSI zone: slow/calm at STABLE, fast at CRITICAL.
        private readonly Ellipse          _pulseRing;
        private readonly SolidColorBrush  _pulseRingBrush;
        private double                    _ringPhase = 0.5; // start mid-cycle (ring hidden)
        private double                    _ringRate  = 1.0 / (4.0 * 30.0); // fraction/frame

        // ── Circular gauge (zero-allocation per-frame updates) ────────────────
        private readonly Path[]           _zoneTracks = new Path[4];   // segmented zone arcs

        // Gradient progress arc — 24 equal-sweep segments, Opacity ramps from
        // dim at the start of the arc to full brightness at the active tip.
        // Replaces the former single _gaugeProgress path; the former single-arc
        // fields (_progressArc, _progressFigure, _gaugeProgress) are gone.
        private const int                GradArcN = 24;
        private readonly Path[]          _gradArcSegs    = new Path[GradArcN];
        private readonly SolidColorBrush[] _gradArcBrushes = new SolidColorBrush[GradArcN];
        private readonly DropShadowEffect _progressGlow;   // reused for tip glow
        private          SolidColorBrush  _progressStroke; // colour tracker (no longer painted directly)

        private const double GaugeCx       = 75.0;
        private const double GaugeCy       = 75.0;
        private const double GaugeR        = 56.0;
        private const double GaugeStroke   = 12.0;
        private const double GaugeStartDeg = 135.0;
        private const double GaugeSweepDeg = 270.0;

        // ── Center text ──────────────────────────────────────────────────────
        private readonly Label            _valueLabel;
        private readonly Label            _statusLabel;
        private          StackPanel       _textStack;
        private readonly SolidColorBrush  _valueFgBrush;
        private readonly SolidColorBrush  _statusFgBrush;
        private readonly DropShadowEffect _statusGlow;     // mirrors gauge glow colour

        // ── Oversize alarm banner ────────────────────────────────────────────
        private readonly Border           _oversizeBanner;
        private bool                      _overExposed = false;
        private static readonly Color     ColOversize = Color.FromRgb(255, 69, 58);

        // ── Header controls ──────────────────────────────────────────────────
        private readonly Border           _monitorPill;
        private readonly Ellipse          _pillDot;
        private readonly Label            _panelToggleBtn;
        private          Label            _pinBtn;          // always-on-top toggle

        // ── Baseline status badge (SIM / PLAYBACK / TEST / LEARNING / REC) ──
        private readonly Border           _baselineBadge;
        private readonly TextBlock        _baselineBadgeText;
        private bool                      _badgeIsAutoDetected;

        // ── Risk Alert banner (Guard persistent warning) ──────────────────────
        private readonly Border           _riskAlertBanner;
        private readonly TextBlock        _riskAlertBannerText;

        // ── PSI-drop notification banner (auto-dismisses) ─────────────────────
        // Shows a plain-English sentence explaining what rule just fired and
        // what the trader's profile setting is.  Auto-fades after ~4 seconds.
        private          Border           _notifBanner;
        private          TextBlock        _notifBannerText;
        private System.Windows.Threading.DispatcherTimer _notifHoldTimer;
        // Persistent approach-state label — shows "Trades  2 / 3" style status.
        // Visible when no event banner is active.  Cached so the fade-completion
        // callback can restore the last computed state after an event fades.
        private          TextBlock        _approachLabel;
        private          string           _pendingApproachText  = "";
        private          Color            _pendingApproachColor = Color.FromRgb(200, 140, 30);

        // ── PSI Timeline chart ───────────────────────────────────────────────
        private struct PsiPoint { public DateTime T; public double V; public float P; }
        private readonly Queue<PsiPoint>  _psiHistory = new Queue<PsiPoint>();
        private const int                 TimelineMaxPts = 300;
        private readonly Canvas           _timelineCanvas;
        private readonly Polyline         _timelineLine;
        private readonly Polygon          _pressureShadow;    // EWMA-smoothed P fill behind PSI line
        private readonly Rectangle        _zoneBandStable;
        private readonly Rectangle        _zoneBandCaution;
        private readonly Rectangle        _zoneBandCritical;
        private readonly System.Windows.Shapes.Line _gridLine80;
        private readonly System.Windows.Shapes.Line _gridLine50;
        private readonly System.Windows.Shapes.Line _nowLine;    // "now" cursor at right edge
        private int                       _heartbeatCounter = 0;
        private const int                 HeartbeatInterval = 60; // redraw every ~2 s at 30 fps
        private readonly TextBlock        _timeLblStart;
        private readonly TextBlock        _timeLblMid;
        private readonly TextBlock        _timeLblEnd;

        // ── Adaptive Y-axis ──────────────────────────────────────────────────
        // _chartFloor is the lowest PSI value displayed at the bottom of the
        // chart (0 = full range).  It expands (lower floor) the instant PSI
        // drops to a new low, and contracts back slowly (≥30 s idle, 10-pt
        // steps) once PSI recovers above the floor.
        private double   _chartFloor           = 0.0;
        private DateTime _chartFloorExpandedAt = DateTime.MinValue;
        private const double ChartFloorContractDelaySec = 30.0;

        // ── Pressure sub-pane (removed from timeline in redesign) ────────────
        // Fields retained so existing Visibility.Collapsed assignments compile.
        private readonly Polygon                     _pressurePaneFill;
        private readonly Polyline                    _pressurePaneLine;
        private readonly SolidColorBrush             _pressurePaneFillBrush = new SolidColorBrush(Colors.Transparent);
        private readonly SolidColorBrush             _pressurePaneLineBrush = new SolidColorBrush(Colors.Transparent);
        private readonly System.Windows.Shapes.Line  _pressureSepLine;

        // ── PSI area fill (semi-transparent zone under PSI line) ──────────────
        private readonly Polygon                     _psiAreaFill;

        // ── Timeframe zoom (1m / 5m / 15m / 1h / full session) ──────────────
        private int?     _timeframeSec = null;  // null = full session window
        private Border[] _tfBtns;               // the 5 toggle buttons

        // ── Timeline Y-axis labels ────────────────────────────────────────────
        private readonly TextBlock[] _yAxisLabels = new TextBlock[4];  // 25/50/75/100

        // ── Timeline hover crosshair ──────────────────────────────────────────
        private System.Windows.Shapes.Line _crosshairLine;
        private Border                     _hoverBubble;
        private TextBlock                  _hoverBubbleText;

        // Cached X→time mapping updated by RedrawTimeline for hover lookups.
        private DateTime _tlRenderStart;
        private double   _tlRenderSpanSec;

        // ── Timeline "now" breathing dot ─────────────────────────────────────
        // 5 px dot at the right end of the PSI line.  Pulsing opacity signals
        // "system live".  Color tracks PSI zone.
        private readonly Ellipse           _timelineDot;
        private readonly SolidColorBrush   _timelineDotBrush = new SolidColorBrush(Colors.White);
        private double                     _dotPhase         = 0.0;

        // ── D-Score bars ─────────────────────────────────────────────────────
        private static readonly string[] DimNames =
            { "Revenge", "No Stop", "Oversize", "Loss Hold Bias", "Holding Long", "Rule Break", "Overtrade" };
        // Same labels, exposed for callers outside the WPF window (attribution
        // logger, dashboard, etc.) without a dependency on an overlay instance.
        public  static readonly string[] DimNamesStatic = DimNames;
        // Prescriptive tooltips for each behavioural dimension.
        //
        // Format, per v2 evidence-accumulator model:
        //   line 1 — what the signal is
        //   line 2 — Class A (hard rule break) / Class B (pattern) mapping
        //   line 3 — bar meaning (severity C_i, 0-100 PSI-points cost)
        //   line 4 — what to do now
        //
        // The label colour is what carries "A vs B NOW" — red = the most
        // recent commit on this dim was a Class A, amber = Class B.
        private static readonly string[] DimTooltips =
        {
            "Revenge Trading — re-entering after a loss before you've had time to reset.\nAccrues when your streak exceeds \"Pause after N losses\" in Settings.",
            "No Stop-Loss — open position with no protective stop order.\nAccrues while no stop is detected, past your ATM grace period in Settings.",
            "Oversizing — position size above your declared maximum.\nAccrues whenever size exceeds \"Position size Max\" in Settings.",
            "Loss Hold Bias — holding losing trades longer than winning ones, on average.\nBuilds across multiple trades in the session; no single trade alone triggers this.",
            "Holding Too Long — position held past your declared maximum hold time.\nAccrues continuously while open past \"Max hold time\" in Settings.",
            "Rule Violation — a declared risk boundary was crossed.\nTriggers on \"Max daily loss\" breach or trading outside your session hours.",
            "Overtrading — entry count or pace exceeds your declared session parameters.\nAccrues when entries exceed \"Trade frequency Max\", or pace exceeds your baseline.",
        };
        private readonly Border[]          _dBarFills   = new Border[7];
        private readonly Label[]           _dBarValues  = new Label[7];
        private readonly SolidColorBrush[] _dBarBrushes = new SolidColorBrush[7];
        private readonly Grid[]            _dBarTracks  = new Grid[7];
        private readonly Ellipse[]         _dBarDots    = new Ellipse[7]; // knob at fill edge
        private readonly double[]          _curD        = new double[7];
        private readonly double[]          _dBarTargets = new double[7]; // animation targets
        // Dim-name labels on each bar row.  Their foreground is used to tag the
        // most recent commit class: red = A (commitment break), amber = B
        // (behavioural pattern), muted grey = no commit this session.  Lets
        // the trader answer "is this dim a RULE violation or a PATTERN?" at
        // a glance without clicking anything.
        private readonly Label[]           _dBarDimLabels = new Label[7];

        // ── Session stats ────────────────────────────────────────────────────
        private readonly Label _statTrades;
        private readonly Label _statWinRate;
        private readonly Label _statAlerts;
        private readonly Label _statDuration;
        private DateTime       _sessionStartTime = DateTime.MinValue;

        // ── Carry-debt indicator ──────────────────────────────────────────────
        // Appears below the STABLE/CAUTION/WARNING label when previous-session
        // debt is non-negligible (≥ 3 PSI points).  Lets the trader distinguish
        // "PSI recovering because I traded calmly" from "PSI recovering because
        // yesterday's debt is dissolving."
        private readonly Label _carryDebtLabel;

        // ── Collapsed-HUD peak dimension indicator ────────────────────────────
        // When the right panel is collapsed, the D-score bars are hidden.
        // This label shows the highest-active dimension name so the trader knows
        // what is driving the current PSI drop even without opening the panel.
        // Only visible when collapsed and at least one dimension has debt > 1 PSI pt.
        private readonly Label _peakDimLabel;

        // ── Pressure P(t) indicator (v2.0) ────────────────────────────────────
        // P(t) is derived CONTEXT (Axiom 4): it amplifies Class B commits and
        // gates decay — it is NOT part of the PSI composure reading.  Keeping
        // it inside the gauge ring made traders read it as a sub-label of
        // STABLE/CAUTION.  It lives in the SESSION stack (first row) so it
        // stays visible when the right panel is collapsed and sits with other
        // session-at-a-glance facts instead of competing with the arc.
        private Grid   _pressureStatRow; // key + mini-bar row; always visible in SESSION
        private Grid   _pressurePanel;
        private Border _pressureFill;
        private Label  _pressureValueLbl;
        private double _curPressure;   // last value, 0..1

        // ── Display settings ─────────────────────────────────────────────────
        private DisplaySettings _settings = new DisplaySettings();

        // ── Intensity-encoded D-bar rows ──────────────────────────────────────
        // Each row is always present; opacity is 0.25 when inactive (debt < 5 pts)
        // and 1.0 when the dimension is carrying meaningful evidence.
        // This prevents the "pop in / pop out" attention trap while still
        // communicating which dimensions are currently relevant.
        private readonly Grid[] _dBarRows = new Grid[7];

        // ── Context line ──────────────────────────────────────────────────────
        // Single fixed-position line below the gauge; content changes with state
        // (never appears/disappears — only the text and colour update).
        private          TextBlock  _contextLine;
        private          int        _ctxTotalTrades = 0;
        private          int        _ctxMaxTrades   = 0;  // 0 = no declared limit

        // ── Pressure corner chip (title-bar, intensity-encoded) ──────────────
        // Small pill displayed in the header next to the title.  Shows the
        // current pressure P(t) as a numeric value with an intensity-encoded
        // background colour (green → amber → red).  Hidden entirely when
        // P ≤ PressureChipMinP so it never competes for attention during
        // calm periods.  Replaces the full-gauge pressure ring that
        // accidentally monopolised the trader's peripheral vision —
        // see REMEDIATION_PLAN_v1.2.md Part 7 "Pressure HUD indicator 7.A
        // (corner chip)."  The old `_pressureRing` Ellipse and its brush
        // have been deleted together with the radius constant that sized
        // them; the chip lives in the header StackPanel and does not
        // consume any gauge real estate.
        private          Border           _pressureChip;
        private          TextBlock        _pressureChipText;
        private readonly SolidColorBrush  _pressureChipBg    = new SolidColorBrush(Colors.Transparent);
        private readonly SolidColorBrush  _pressureChipBorder = new SolidColorBrush(Colors.Transparent);
        private readonly SolidColorBrush  _pressureChipFg    = new SolidColorBrush(Colors.White);
        private const    double           PressureChipMinP   = 0.05;

        // ── D-bars section ref (for show/hide in Minimal mode) ────────────────
        private          FrameworkElement _dBarsSection;
        // Pressure number row ref (for hide in Minimal / GaugeRing mode)
        // already declared as _pressureStatRow above ↑

        // ── Layout / expand-collapse ─────────────────────────────────────────
        private readonly Grid             _rightPanel;
        private readonly Border           _separator;
        private readonly ColumnDefinition _rightCol;
        private bool   _expanded      = true;
        private double _expandedWidth = ExpandedW;
        private const double LeftPanelW = 220.0;
        private const double ExpandedW    = 860.0;
        private const double CollapsedW   = 220.0;
        // Minimum width when the right panel is visible: left rail + separator + a
        // usable right area (D-bars 80 + v-splitter 4 + journal 120 = 204 → round up).
        private const double ExpandedMinW = 440.0;

        // ── HUD Journal quick-capture section ────────────────────────────────
        // In the new wide layout the journal lives in the bottom-right column
        // next to the D-bars.  The ✎ button toggles column width between 0
        // (hidden) and JournalColW (visible).
        private const double JournalColW = 240.0;
        private ColumnDefinition _journalColDef;          // width 0 or JournalColW
        private ColumnDefinition _journalSplitterColDef;  // 4px divider; hidden with journal
        private RowDefinition    _bottomRowDef;           // D-bars+journal row height (resizable)
        private          TextBox       _hudNoteBox;
        private          TextBlock     _lastTradeContextLbl;
        private          bool          _journalVisible  = false;
        // Selected emotion — set by chip tap, consumed + cleared by SubmitHudNote.
        private          JournalEmotion _selectedEmotion = JournalEmotion.None;
        private          Border[]       _chipBorders;   // indexed 0=Calm 1=Neutral 2=Stressed
        public  event Action<JournalKind, JournalEmotion, string> JournalEntryRequested;

        // ── Apple-style palette ──────────────────────────────────────────────
        private static readonly Color ColStable   = Color.FromRgb( 48, 209,  88);
        private static readonly Color ColCaution  = Color.FromRgb(255, 214,  10);  // yellow
        private static readonly Color ColWarning  = Color.FromRgb(255, 149,   0);  // orange
        private static readonly Color ColCritical = Color.FromRgb(255,  69,  58);  // red

        // ── Zone thresholds — delegate to SessionData (single source of truth) ─
        // STABLE  ≥ 88 (green):   trading within declared limits
        // CAUTION ≥ 72 (yellow):  minor violations — pay attention
        // WARNING ≥ 55 (orange):  significant violations — consider stopping
        // CRITICAL < 55 (red):    stop trading
        private const double ZoneStable   = SessionData.ZoneStableThreshold;   // 88
        private const double ZoneCaution  = 72.0;  // visual-only midpoint (no logical zone)
        private const double ZoneWarning  = SessionData.ZoneCriticalThreshold; // 55
        private static readonly Color ColPaused   = Color.FromRgb( 72,  72,  74);
        private static readonly Brush BgCard       = new SolidColorBrush(Color.FromArgb(253, 22, 22, 24));
        private static readonly Brush BgHeader     = new SolidColorBrush(Color.FromArgb(38, 255, 255, 255));
        private static readonly Brush PillOnBrush  = new SolidColorBrush(Color.FromRgb( 48, 209,  88));
        private static readonly Brush PillOffBrush = new SolidColorBrush(Color.FromRgb( 72,  72,  74));
        private static readonly Brush FgMuted      = new SolidColorBrush(Color.FromRgb(136, 136, 136));
        private static readonly Brush FgDim        = new SolidColorBrush(Color.FromRgb(100, 100, 100));
        private static readonly Brush FgBright     = new SolidColorBrush(Color.FromRgb(220, 220, 224));

        static PsiOverlayWindow()
        {
            ((SolidColorBrush)BgCard      ).Freeze();
            ((SolidColorBrush)BgHeader    ).Freeze();
            ((SolidColorBrush)PillOnBrush ).Freeze();
            ((SolidColorBrush)PillOffBrush).Freeze();
            ((SolidColorBrush)FgMuted     ).Freeze();
            ((SolidColorBrush)FgDim       ).Freeze();
            ((SolidColorBrush)FgBright    ).Freeze();
        }

        // ═════════════════════════════════════════════════════════════════════
        // Constructor
        // ═════════════════════════════════════════════════════════════════════

        public PsiOverlayWindow(bool monitoringEnabled = true)
        {
            WindowStyle        = WindowStyle.None;
            AllowsTransparency = false;
            Background         = BgCard;
            Topmost            = true;    // always-on-top by default; pin button toggles
            ShowActivated      = false;   // never steal keyboard focus from hotkeys / SuperDOM
            ResizeMode         = ResizeMode.CanResize;
            ShowInTaskbar      = true;
            Title              = "PSI Monitor";
            Width              = ExpandedW;
            Height             = 480;
            MinWidth           = ExpandedMinW;  // right panel is visible at startup
            MinHeight          = 340;

            Left = SystemParameters.WorkArea.Right - Width - 20;
            Top  = SystemParameters.WorkArea.Top   + 20;

            WindowChrome.SetWindowChrome(this, new WindowChrome
            {
                CaptionHeight         = 30,
                ResizeBorderThickness = new Thickness(5),
                CornerRadius          = new CornerRadius(0),
                GlassFrameThickness   = new Thickness(0),
                UseAeroCaptionButtons = false,
            });

            _isPaused = !monitoringEnabled;
            Color initCol    = _isPaused ? ColPaused : ColStable;
            _progressStroke  = new SolidColorBrush(initCol);
            _valueFgBrush    = new SolidColorBrush(initCol);
            _statusFgBrush   = new SolidColorBrush(initCol);
            _statusGlow      = new DropShadowEffect
            {
                Color         = initCol,
                BlurRadius    = 6.0,
                ShadowDepth   = 0.0,
                Opacity       = 0.60,
                Direction     = 0,
                RenderingBias = RenderingBias.Performance,
            };

            // ── Root grid ────────────────────────────────────────────────────
            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(30) });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // ── HEADER ───────────────────────────────────────────────────────
            var headerBg = new Border { Background = BgHeader };
            var hCols = new Grid();
            hCols.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            for (int ci = 0; ci < 7; ci++)
                hCols.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var titleLbl = new Label
            {
                Content           = "PSI MONITOR",
                FontSize          = 9,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.SemiBold,
                Foreground        = new SolidColorBrush(Color.FromRgb(134, 134, 139)),
                VerticalAlignment = VerticalAlignment.Center,
                Padding           = new Thickness(10, 0, 0, 0),
            };

            _baselineBadgeText = new TextBlock
            {
                Text              = "",
                FontSize          = 8,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.Bold,
                Foreground        = Brushes.Black,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(2, 0, 2, 0),
            };
            _baselineBadge = new Border
            {
                Background        = new SolidColorBrush(Color.FromRgb(255, 179, 64)),
                CornerRadius      = new CornerRadius(3),
                Padding           = new Thickness(4, 1, 4, 1),
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(4, 0, 0, 0),
                Child             = _baselineBadgeText,
                Cursor            = Cursors.Hand,
                Visibility        = Visibility.Visible,
            };
            _baselineBadge.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                if (!_badgeIsAutoDetected) TestModeToggleRequested?.Invoke();
            };

            // Pressure corner chip — removed; the SESSION Pressure bar below the
            // gauge carries this information.  Field kept so UpdatePressure compiles.
            _pressureChipText = new TextBlock();
            _pressureChip = new Border { Visibility = Visibility.Collapsed };

            var titlePanel = new StackPanel
            {
                Orientation       = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
            };
            titlePanel.Children.Add(titleLbl);
            titlePanel.Children.Add(_baselineBadge);

            _panelToggleBtn = MakeHdrBtn("\u25C0", "Collapse panel");
            _panelToggleBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; TogglePanel(); };

            var dashBtn = MakeHdrBtn("\u2630", "Open dashboard");
            dashBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; DashboardRequested?.Invoke(); };

            var journalToggleBtn = MakeHdrBtn("\u270E", "Show/hide quick journal");
            journalToggleBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; ToggleJournalSection(); };

            // Pin button — toggles always-on-top.
            // Default: pinned (Topmost=true) so the HUD is always visible while trading.
            // Click to unpin if you want other windows to cover it.
            _pinBtn = MakeHdrBtn("\uD83D\uDCCC", "Always on top: ON  (click to unpin)");
            _pinBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                Topmost = !Topmost;
                _pinBtn.Content  = Topmost ? "\uD83D\uDCCC" : "\uD83D\uDCCD";
                _pinBtn.ToolTip  = Topmost
                    ? "Always on top: ON  (click to unpin)"
                    : "Always on top: OFF  (click to pin)";
                _pinBtn.Foreground = Topmost
                    ? new SolidColorBrush(Color.FromRgb(255, 214, 10))  // gold when pinned
                    : FgDim;
            };

            _pillDot = new Ellipse
            {
                Width = 12, Height = 12,
                Fill  = Brushes.White,
                VerticalAlignment = VerticalAlignment.Center,
            };
            _monitorPill = new Border
            {
                Width = 32, Height = 16,
                CornerRadius      = new CornerRadius(8),
                Child             = _pillDot,
                Cursor            = Cursors.Hand,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(4, 0, 4, 0),
            };
            _monitorPill.MouseLeftButtonDown += OnPillClicked;
            UpdatePillVisuals();

            var minBtn = MakeHdrBtn("\u2500", "Minimize  (monitoring continues)");
            var clsBtn = MakeHdrBtn("\u2715", "Stop monitoring and close");
            minBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; WindowState = WindowState.Minimized; };
            clsBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                MonitoringStopRequested?.Invoke();
                Close();
            };

            Grid.SetColumn(titlePanel,       0); hCols.Children.Add(titlePanel);
            Grid.SetColumn(_panelToggleBtn,  1); hCols.Children.Add(_panelToggleBtn);
            Grid.SetColumn(dashBtn,          2); hCols.Children.Add(dashBtn);
            Grid.SetColumn(journalToggleBtn, 3); hCols.Children.Add(journalToggleBtn);
            Grid.SetColumn(_pinBtn,          4); hCols.Children.Add(_pinBtn);
            Grid.SetColumn(_monitorPill,     5); hCols.Children.Add(_monitorPill);
            Grid.SetColumn(minBtn,           6); hCols.Children.Add(minBtn);
            Grid.SetColumn(clsBtn,           7); hCols.Children.Add(clsBtn);
            headerBg.Child = hCols;

            foreach (UIElement el in new UIElement[]
                { _panelToggleBtn, dashBtn, journalToggleBtn, _pinBtn, _monitorPill, minBtn, clsBtn })
                WindowChrome.SetIsHitTestVisibleInChrome(el, true);

            // Pin button starts gold (topmost is on by default).
            _pinBtn.Foreground = new SolidColorBrush(Color.FromRgb(255, 214, 10));

            titlePanel.Cursor = Cursors.SizeAll;
            titlePanel.MouseLeftButtonDown += (_, e) =>
            {
                if (e.LeftButton == System.Windows.Input.MouseButtonState.Pressed)
                { Activate(); DragMove(); }
            };
            headerBg.MouseLeftButtonDown += (_, e) =>
            {
                if (!e.Handled &&
                    e.LeftButton == System.Windows.Input.MouseButtonState.Pressed)
                { Activate(); DragMove(); }
            };

            Grid.SetRow(headerBg, 0);
            root.Children.Add(headerBg);

            // ── BODY (two-column layout) ─────────────────────────────────────
            var body = new Grid();
            body.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(LeftPanelW) });
            _rightCol = new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) };
            body.ColumnDefinitions.Add(_rightCol);
            Grid.SetRow(body, 1);
            root.Children.Add(body);

            // ═════════════════════════════════════════════════════════════════
            // LEFT PANEL — Gauge + Oversize Banner + Session Stats
            // ═════════════════════════════════════════════════════════════════

            // Left panel wrapped in a Border to give it a subtly elevated card feel:
            // slightly lighter background + right-side divider line.
            var leftPanelCard = new Border
            {
                Background      = new SolidColorBrush(Color.FromArgb(18, 255, 255, 255)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                BorderThickness = new Thickness(0, 0, 1, 0),
            };
            Grid.SetColumn(leftPanelCard, 0);
            body.Children.Add(leftPanelCard);

            var leftPanel = new Grid();
            leftPanel.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) }); // row 0: gauge
            leftPanel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });  // row 1: context line
            leftPanel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });  // row 2: banners (collapsed by default)
            leftPanel.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });  // row 3: session stats
            leftPanelCard.Child = leftPanel;

            // ── Circular gauge ───────────────────────────────────────────────
            // Zone track: 4 colored arcs at low opacity (CRITICAL→WARNING→CAUTION→STABLE)
            Color[] zoneColors = { ColCritical, ColWarning, ColCaution, ColStable };
            double[] zoneBounds = { 0, SessionData.ZoneCriticalThreshold, ZoneCaution,
                                    SessionData.ZoneStableThreshold, 100 };
            for (int zi = 0; zi < 4; zi++)
                _zoneTracks[zi] = BuildZoneArc(zoneBounds[zi], zoneBounds[zi + 1], zoneColors[zi]);

            _progressStroke = new SolidColorBrush(initCol);   // colour tracking only
            _progressGlow = new DropShadowEffect
            {
                Color         = initCol,
                BlurRadius    = 10.0,
                ShadowDepth   = 0.0,
                Opacity       = 0.60,
                Direction     = 0,
                RenderingBias = RenderingBias.Performance,
            };

            // Build 24 gradient arc segments.  Each segment spans
            // GaugeSweepDeg/GradArcN degrees; Opacity ramps 0.12→1.0 from
            // start to end.  The last (tip) segment receives the glow effect.
            double segSweep = GaugeSweepDeg / GradArcN;
            for (int gi = 0; gi < GradArcN; gi++)
            {
                double opacity = 0.12 + 0.88 * ((double)gi / (GradArcN - 1));
                var    brush   = new SolidColorBrush(initCol) { Opacity = opacity };
                _gradArcBrushes[gi] = brush;
                _gradArcSegs[gi]    = BuildGradArcSeg(gi, segSweep, brush,
                                          gi == GradArcN - 1 ? _progressGlow : null);
            }
            UpdateGradArc(100.0, initCol);

            // Arc tip dot — hollow ring (dark fill + white stroke + color glow).
            // Sits centered on the arc track like a gauge needle indicator.
            _arcTipGlow = new DropShadowEffect
            {
                Color         = initCol,
                BlurRadius    = 7.0,
                ShadowDepth   = 0.0,
                Opacity       = 0.55,
                Direction     = 0,
                RenderingBias = RenderingBias.Performance,
            };
            _arcTipDot = new Ellipse
            {
                Width            = 13,
                Height           = 13,
                Fill             = Brushes.Transparent,          // hollow center
                Stroke           = new SolidColorBrush(Color.FromArgb(220, 10, 10, 12)),
                StrokeThickness  = 1.5,
                Effect           = _arcTipGlow,
                IsHitTestVisible = false,
                Opacity          = 0.85,
            };

            // Smoky pulse ring — wide blurred stroke that radiates from center.
            // BlurEffect makes it look like diffuse glowing smoke, not a hard line.
            _pulseRingBrush = new SolidColorBrush(initCol);
            _pulseRing = new Ellipse
            {
                Width            = 2 * GaugeR,
                Height           = 2 * GaugeR,
                Stroke           = _pulseRingBrush,
                StrokeThickness  = 9.0,
                Fill             = Brushes.Transparent,
                IsHitTestVisible = false,
                Opacity          = 0.0,
                Effect           = new BlurEffect
                {
                    Radius        = 12.0,
                    RenderingBias = RenderingBias.Performance,
                },
            };
            Canvas.SetLeft(_pulseRing, GaugeCx - GaugeR);
            Canvas.SetTop (_pulseRing, GaugeCy - GaugeR);

            // [REMOVED 2026-04-23] Full-gauge pressure ring.  Replaced by
            // the compact _pressureChip in the HUD header so Pressure has
            // a dedicated, peripherally-visible but non-monopolising
            // indicator.  See REMEDIATION_PLAN_v1.2.md Part 7.
            var gaugeCanvas = new Canvas { Width = 150, Height = 150 };
            foreach (var zt in _zoneTracks) gaugeCanvas.Children.Add(zt);
            gaugeCanvas.Children.Add(_pulseRing);   // behind the arc
            foreach (var seg in _gradArcSegs) gaugeCanvas.Children.Add(seg);
            gaugeCanvas.Children.Add(_arcTipDot);

            // PSI number hidden: the "staircase" artefact on discrete PSI updates
            // makes a large centre number look jarring.  The arc colour + status
            // label communicate zone/severity without the number.
            _valueLabel = new Label
            {
                Content                    = _isPaused ? "\u2014" : "100",
                FontSize                   = 26,
                FontFamily                 = new FontFamily("Segoe UI"),
                FontWeight                 = FontWeights.Bold,
                Foreground                 = _valueFgBrush,
                HorizontalAlignment        = HorizontalAlignment.Center,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Padding                    = new Thickness(0),
                Visibility                 = Visibility.Collapsed,
            };
            _statusLabel = new Label
            {
                Content                    = _isPaused ? "PAUSED" : "STABLE",
                FontSize                   = 10,
                FontFamily                 = new FontFamily("Segoe UI"),
                FontWeight                 = FontWeights.Bold,
                Foreground                 = _statusFgBrush,
                HorizontalAlignment        = HorizontalAlignment.Center,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Padding                    = new Thickness(0),
                Effect                     = _statusGlow,
            };

            var textStack = new StackPanel
            {
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
                Margin              = new Thickness(0, -6, 0, 0),
            };
            _textStack = textStack;
            textStack.Children.Add(_valueLabel);
            textStack.Children.Add(_statusLabel);

            // Carry-debt indicator: shows when previous-session debt is still
            // dissolving (≥ 3 pts).  Font is intentionally small and warm-dim so
            // it does not compete with the primary PSI number.
            _carryDebtLabel = new Label
            {
                Content                    = "",
                FontSize                   = 7,
                FontFamily                 = new FontFamily("Segoe UI"),
                Foreground                 = new SolidColorBrush(Color.FromArgb(200, 255, 200, 100)),
                HorizontalAlignment        = HorizontalAlignment.Center,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Padding                    = new Thickness(0, 1, 0, 0),
                Visibility                 = Visibility.Collapsed,
            };
            textStack.Children.Add(_carryDebtLabel);

            // Peak-dimension indicator: visible only when collapsed and a signal is active.
            _peakDimLabel = new Label
            {
                Content                    = "",
                FontSize                   = 7,
                FontFamily                 = new FontFamily("Segoe UI"),
                Foreground                 = new SolidColorBrush(Color.FromArgb(200, 255, 149, 0)),
                HorizontalAlignment        = HorizontalAlignment.Center,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Padding                    = new Thickness(0, 1, 0, 0),
                Visibility                 = Visibility.Collapsed,
            };
            textStack.Children.Add(_peakDimLabel);

            var gaugeHost = new Grid { Width = 150, Height = 150 };
            gaugeHost.Children.Add(gaugeCanvas);
            gaugeHost.Children.Add(textStack);

            var gaugeViewBox = new Viewbox
            {
                Child               = gaugeHost,
                Stretch             = System.Windows.Media.Stretch.Uniform,
                Margin              = new Thickness(8),
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment   = VerticalAlignment.Stretch,
            };
            Grid.SetRow(gaugeViewBox, 0);
            leftPanel.Children.Add(gaugeViewBox);

            // ── Context line (row 1) ─────────────────────────────────────────
            // Always present; content updates with session state.
            // Never appears / disappears — only text and colour change.
            _contextLine = new TextBlock
            {
                Text                = "\u2014",          // em-dash = "ready / nothing yet"
                FontSize            = 9,
                FontFamily          = new FontFamily("Segoe UI"),
                Foreground          = FgDim,
                TextAlignment       = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                TextTrimming        = TextTrimming.CharacterEllipsis,
            };
            var ctxBorder = new Border
            {
                Child  = _contextLine,
                Margin = new Thickness(8, 2, 8, 3),
            };
            Grid.SetRow(ctxBorder, 1);
            leftPanel.Children.Add(ctxBorder);

            // ── Oversize alarm banner ────────────────────────────────────────
            // Removed: the PSI gauge already shows "OVERSIZE" in red directly on
            // the gauge face when overexposed — a separate banner is redundant and
            // distracting.  The field is kept so UpdateOverExposed still compiles.
            _oversizeBanner = new Border { Visibility = Visibility.Collapsed };

            // ── Risk Alert banner (Guard) ────────────────────────────────────
            _riskAlertBannerText = new TextBlock
            {
                Text                       = "",
                FontSize                   = 10,
                FontFamily                 = new FontFamily("Segoe UI"),
                FontWeight                 = FontWeights.SemiBold,
                Foreground                 = new SolidColorBrush(Colors.White),
                HorizontalAlignment        = HorizontalAlignment.Stretch,
                TextAlignment              = TextAlignment.Center,
                Padding                    = new Thickness(0, 3, 0, 3),
                TextWrapping               = TextWrapping.Wrap,
            };
            _riskAlertBanner = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(180, 100, 20)),
                Visibility = Visibility.Collapsed,
                Child      = _riskAlertBannerText,
            };
            Grid.SetRow(_riskAlertBanner, 2);
            leftPanel.Children.Add(_riskAlertBanner);

            // ── PSI-drop notification banner ─────────────────────────────────
            // Occupies the same row-2 slot as the other banners.
            // Auto-fades after 4 s; a new drop replaces it immediately.
            // Only shown for Class A (hard rule breaks); Class B behavioral signals
            // are already visible on the HUD dimension bars — a separate banner is
            // redundant noise while actively trading.
            _notifBannerText = new TextBlock
            {
                Text             = "",
                FontSize         = 11,
                FontFamily       = new FontFamily("Segoe UI"),
                FontWeight       = FontWeights.SemiBold,
                Foreground       = new SolidColorBrush(Color.FromRgb(230, 160, 30)),
                TextAlignment    = TextAlignment.Center,
                TextWrapping     = TextWrapping.Wrap,
                Padding          = new Thickness(8, 5, 8, 5),
            };
            _notifBanner = new Border
            {
                Background   = Brushes.Transparent,
                CornerRadius = new CornerRadius(0),
                Visibility   = Visibility.Collapsed,
                Child        = _notifBannerText,
            };
            Grid.SetRow(_notifBanner, 2);
            leftPanel.Children.Add(_notifBanner);

            // ── Approach-state label (Row 2, behind notif banner) ────────────────
            // Persistent, no fade.  Shows "Trades  2 / 3", "Size  4 / 3" etc.
            // Hidden while event banner is visible; restored in fade-completion.
            _approachLabel = new TextBlock
            {
                Text              = "",
                FontSize          = 9,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.Normal,
                TextAlignment     = TextAlignment.Center,
                Padding           = new Thickness(8, 5, 8, 5),
                Visibility        = Visibility.Collapsed,
            };
            Grid.SetRow(_approachLabel, 2);
            leftPanel.Children.Add(_approachLabel);

            // ── Session stats ────────────────────────────────────────────────
            var statsStack = new StackPanel { Margin = new Thickness(14, 4, 8, 8) };
            statsStack.Children.Add(new Label
            {
                Content    = "SESSION",
                FontSize   = 8,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = FgDim,
                Padding    = new Thickness(0, 0, 0, 2),
            });
            statsStack.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 0, 0, 4),
            });

            // Pressure row — same grid rhythm as other SESSION lines; bar + 0–100
            // readout sit in the value column (row label is the word "Pressure").
            _pressureStatRow = new Grid { Visibility = Visibility.Visible };
            _pressureStatRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            _pressureStatRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var pressureKeyLbl = new Label
            {
                Content                    = "Pressure",
                FontSize                   = 10,
                FontFamily                 = new FontFamily("Segoe UI"),
                Foreground                 = FgMuted,
                Padding                    = new Thickness(0, 1, 0, 1),
                VerticalAlignment          = VerticalAlignment.Center,
                ToolTip =
                    "Emotional Pressure — how charged this moment feels.\n" +
                    "Rises when holding a losing trade, on a loss streak,\n" +
                    "near your daily loss limit, or trading faster than usual.\n" +
                    "High pressure slows composure recovery.",
            };
            Grid.SetColumn(pressureKeyLbl, 0);
            _pressureStatRow.Children.Add(pressureKeyLbl);

            _pressurePanel = new Grid
            {
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment   = VerticalAlignment.Center,
                MinWidth            = 72,
                MaxWidth            = 130,
                Margin              = new Thickness(4, 0, 0, 0),
            };
            _pressurePanel.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            _pressurePanel.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(32) });

            var pTrack = new Grid { Margin = new Thickness(0, 0, 4, 0) };
            pTrack.Children.Add(new Border
            {
                Height            = 3,
                CornerRadius      = new CornerRadius(1.5),
                Background        = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                VerticalAlignment = VerticalAlignment.Center,
            });
            _pressureFill = new Border
            {
                Height              = 3,
                CornerRadius        = new CornerRadius(1.5),
                Background          = new SolidColorBrush(ColStable),
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment   = VerticalAlignment.Center,
                Width               = 0,
            };
            pTrack.Children.Add(_pressureFill);
            Grid.SetColumn(pTrack, 0);
            _pressurePanel.Children.Add(pTrack);

            _pressureValueLbl = new Label
            {
                Content                    = "Low",
                FontSize                   = 9,
                FontFamily                 = new FontFamily("Segoe UI"),
                Foreground                 = FgMuted,
                Padding                    = new Thickness(0),
                HorizontalContentAlignment = HorizontalAlignment.Right,
                VerticalAlignment          = VerticalAlignment.Center,
            };
            Grid.SetColumn(_pressureValueLbl, 1);
            _pressurePanel.Children.Add(_pressureValueLbl);

            Grid.SetColumn(_pressurePanel, 1);
            _pressureStatRow.Children.Add(_pressurePanel);
            statsStack.Children.Add(_pressureStatRow);

            string[] statKeys = { "Trades", "Win Rate", "Alerts", "Duration" };
            _statTrades   = MakeStatValue("\u2014");
            _statWinRate  = MakeStatValue("\u2014");
            _statAlerts   = MakeStatValue("0");
            _statDuration = MakeStatValue("\u2014");
            Label[] statVals = { _statTrades, _statWinRate, _statAlerts, _statDuration };

            for (int si = 0; si < 4; si++)
            {
                var sRow = new Grid();
                sRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                sRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                var kLbl = new Label
                {
                    Content    = statKeys[si],
                    FontSize   = 10,
                    FontFamily = new FontFamily("Segoe UI"),
                    Foreground = FgMuted,
                    Padding    = new Thickness(0, 1, 0, 1),
                };
                Grid.SetColumn(kLbl, 0);         sRow.Children.Add(kLbl);
                Grid.SetColumn(statVals[si], 1); sRow.Children.Add(statVals[si]);
                statsStack.Children.Add(sRow);
            }

            Grid.SetRow(statsStack, 3);
            leftPanel.Children.Add(statsStack);

            // ═════════════════════════════════════════════════════════════════
            // RIGHT PANEL — Timeline Chart + D-Score Bars
            // ═════════════════════════════════════════════════════════════════

            _separator = new Border
            {
                Width               = 1,
                Background          = new SolidColorBrush(Color.FromArgb(25, 255, 255, 255)),
                HorizontalAlignment = HorizontalAlignment.Left,
            };
            Grid.SetColumn(_separator, 1);
            body.Children.Add(_separator);

            // Right panel: 2 rows.
            //   Row 0 (*):    PSI Timeline chart.
            //   Row 1 (195px): Bottom area — D-bars (left *) + Journal (right, toggleable).
            _rightPanel = new Grid { Margin = new Thickness(1, 0, 0, 0) };
            _rightPanel.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star), MinHeight = 80 }); // row 0: chart
            _rightPanel.RowDefinitions.Add(new RowDefinition { Height = new GridLength(4) });                                    // row 1: splitter
            // MinHeight = 190: enough to render all 7 D-bar rows (≈24 px each) + section header.
            // A ScrollViewer on the D-bars column handles cases where the user drags smaller.
            _bottomRowDef = new RowDefinition { Height = new GridLength(195), MinHeight = 190 };
            _rightPanel.RowDefinitions.Add(_bottomRowDef);                                                                       // row 2: D-bars + journal
            Grid.SetColumn(_rightPanel, 1);
            body.Children.Add(_rightPanel);

            // ── Timeline chart ───────────────────────────────────────────────
            // Wrapped in a card border for visual elevation.
            // Layout:
            //   Row 0 (Auto): section header (title + zoom buttons)
            //   Row 1 (*):    chart area — Y-axis canvas (30px) + main canvas (*)
            //   Row 2 (14px): time-axis labels
            var tlSection = new Grid { Margin = new Thickness(6, 6, 6, 4) };
            tlSection.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            tlSection.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            tlSection.RowDefinitions.Add(new RowDefinition { Height = new GridLength(14) });

            // ── Row 0: title + timeframe buttons ──────────────────────────────
            var tlHeaderGrid = new Grid();
            tlHeaderGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            tlHeaderGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            tlHeaderGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            Grid.SetRow(tlHeaderGrid, 0);
            tlSection.Children.Add(tlHeaderGrid);

            var tlTitleLbl = new Label
            {
                Content    = "PSI TIMELINE",
                FontSize   = 8,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = FgDim,
                Padding    = new Thickness(2, 0, 0, 2),
            };
            Grid.SetColumn(tlTitleLbl, 0);
            tlHeaderGrid.Children.Add(tlTitleLbl);

            // Timeframe toggle buttons: [1m][5m][15m][1h][Session]
            int[]    tfSeconds = { 60, 300, 900, 3600, 0 };  // 0 = full session
            string[] tfLabels  = { "1m", "5m", "15m", "1h", "Session" };
            _tfBtns = new Border[5];
            var tfRow = new StackPanel
            {
                Orientation       = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
            };
            for (int ti = 0; ti < 5; ti++)
            {
                int idx = ti;
                int sec = tfSeconds[ti];
                bool   isSelected = (sec == 0 && _timeframeSec == null) ||
                                    (sec != 0 && _timeframeSec == sec);
                var tfLbl = new TextBlock
                {
                    Text              = tfLabels[ti],
                    FontSize          = 8,
                    FontFamily        = new FontFamily("Segoe UI"),
                    Foreground        = isSelected
                                            ? new SolidColorBrush(Color.FromRgb(100, 220, 100))
                                            : FgDim,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin            = new Thickness(0),
                };
                var tfBtn = new Border
                {
                    Background        = new SolidColorBrush(isSelected
                                            ? Color.FromArgb(40, 100, 210, 100)
                                            : Color.FromArgb(0, 0, 0, 0)),
                    CornerRadius      = new CornerRadius(3),
                    Padding           = new Thickness(5, 1, 5, 2),
                    Margin            = new Thickness(2, 0, 0, 0),
                    Cursor            = Cursors.Hand,
                    Child             = tfLbl,
                    VerticalAlignment = VerticalAlignment.Center,
                };
                _tfBtns[idx] = tfBtn;
                tfBtn.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    _timeframeSec = sec == 0 ? (int?)null : sec;
                    UpdateTimeframeBtnStyles();
                    RedrawTimeline();
                };
                tfRow.Children.Add(tfBtn);
            }
            Grid.SetColumn(tfRow, 2);
            tlHeaderGrid.Children.Add(tfRow);

            // ── Row 1: Y-axis canvas (30px) + main timeline canvas (*) ────────
            var chartRow = new Grid();
            chartRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(30) });  // Y-axis
            chartRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); // chart
            Grid.SetRow(chartRow, 1);
            tlSection.Children.Add(chartRow);

            // Y-axis Canvas — contains 4 TextBlock labels (25/50/75/100)
            var yAxisCanvas = new Canvas { ClipToBounds = true };
            Grid.SetColumn(yAxisCanvas, 0);
            chartRow.Children.Add(yAxisCanvas);
            string[] yLabelValues = { "25", "50", "75", "100" };
            for (int yi = 0; yi < 4; yi++)
            {
                _yAxisLabels[yi] = new TextBlock
                {
                    Text              = yLabelValues[yi],
                    FontSize          = 7.5,
                    FontFamily        = new FontFamily("Consolas"),
                    Foreground        = new SolidColorBrush(Color.FromArgb(100, 180, 180, 185)),
                    TextAlignment     = TextAlignment.Right,
                    Width             = 26,
                    IsHitTestVisible  = false,
                };
                yAxisCanvas.Children.Add(_yAxisLabels[yi]);
            }
            yAxisCanvas.SizeChanged += (_, __) => RedrawTimeline();

            _timelineCanvas = new Canvas
            {
                Background   = new SolidColorBrush(Color.FromArgb(12, 255, 255, 255)),
                ClipToBounds = true,
            };
            Grid.SetColumn(_timelineCanvas, 1);
            chartRow.Children.Add(_timelineCanvas);

            _zoneBandStable   = new Rectangle { Fill = new SolidColorBrush(Color.FromArgb(20,  48, 209,  88)) };
            _zoneBandCaution  = new Rectangle { Fill = new SolidColorBrush(Color.FromArgb(15, 255, 179,  64)) };
            _zoneBandCritical = new Rectangle { Fill = new SolidColorBrush(Color.FromArgb(15, 255,  69,  58)) };
            _timelineCanvas.Children.Add(_zoneBandCritical);
            _timelineCanvas.Children.Add(_zoneBandCaution);
            _timelineCanvas.Children.Add(_zoneBandStable);

            _gridLine80 = new System.Windows.Shapes.Line
            {
                Stroke          = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                StrokeThickness = 0.5,
                StrokeDashArray = new DoubleCollection { 4, 3 },
            };
            _gridLine50 = new System.Windows.Shapes.Line
            {
                Stroke          = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                StrokeThickness = 0.5,
                StrokeDashArray = new DoubleCollection { 4, 3 },
            };
            _timelineCanvas.Children.Add(_gridLine80);
            _timelineCanvas.Children.Add(_gridLine50);

            _pressureShadow = new Polygon { Visibility = Visibility.Collapsed, IsHitTestVisible = false };
            _timelineCanvas.Children.Add(_pressureShadow);

            // PSI area fill — semi-transparent gradient polygon under the PSI line.
            // Uses a LinearGradientBrush (top opacity → transparent at bottom) so it
            // fades naturally toward the baseline, matching the reference chart style.
            _psiAreaFill = new Polygon
            {
                Fill = new LinearGradientBrush
                {
                    StartPoint = new Point(0, 0),
                    EndPoint   = new Point(0, 1),
                    GradientStops = new GradientStopCollection
                    {
                        new GradientStop(Color.FromArgb(55, 48, 209, 88), 0.0),
                        new GradientStop(Color.FromArgb( 0, 48, 209, 88), 1.0),
                    },
                },
                IsHitTestVisible = false,
            };
            _timelineCanvas.Children.Add(_psiAreaFill);

            _timelineLine = new Polyline
            {
                Stroke             = new SolidColorBrush(Color.FromRgb(200, 200, 204)),
                StrokeThickness    = 1.5,
                StrokeLineJoin     = PenLineJoin.Round,
                StrokeStartLineCap = PenLineCap.Round,
                StrokeEndLineCap   = PenLineCap.Round,
            };
            _timelineCanvas.Children.Add(_timelineLine);

            // "Now" cursor — subtle dashed vertical line always pinned to right edge.
            _nowLine = new System.Windows.Shapes.Line
            {
                Stroke           = new SolidColorBrush(Color.FromArgb(90, 255, 255, 255)),
                StrokeThickness  = 1.0,
                StrokeDashArray  = new DoubleCollection { 3, 3 },
                IsHitTestVisible = false,
                Visibility       = Visibility.Collapsed,
            };
            _timelineCanvas.Children.Add(_nowLine);

            // ── Pressure sub-pane ────────────────────────────────────────────────
            _pressureSepLine = new System.Windows.Shapes.Line
            {
                Stroke           = new SolidColorBrush(Color.FromArgb(35, 255, 255, 255)),
                StrokeThickness  = 0.5,
                IsHitTestVisible = false,
            };
            _timelineCanvas.Children.Add(_pressureSepLine);

            _pressurePaneFill = new Polygon
            {
                Fill             = _pressurePaneFillBrush,
                IsHitTestVisible = false,
                Opacity          = 0.40,
            };
            _timelineCanvas.Children.Add(_pressurePaneFill);

            _pressurePaneLine = new Polyline
            {
                Stroke             = _pressurePaneLineBrush,
                StrokeThickness    = 1.0,
                StrokeLineJoin     = PenLineJoin.Round,
                StrokeStartLineCap = PenLineCap.Round,
                StrokeEndLineCap   = PenLineCap.Round,
                IsHitTestVisible   = false,
                Opacity            = 0.85,
            };
            _timelineCanvas.Children.Add(_pressurePaneLine);

            // ── Breathing dot ────────────────────────────────────────────────────
            _timelineDot = new Ellipse
            {
                Width            = 6,
                Height           = 6,
                Fill             = _timelineDotBrush,
                IsHitTestVisible = false,
                Visibility       = Visibility.Collapsed,
            };
            _timelineCanvas.Children.Add(_timelineDot);

            // ── Hover crosshair + value bubble ───────────────────────────────────
            _crosshairLine = new System.Windows.Shapes.Line
            {
                Stroke           = new SolidColorBrush(Color.FromArgb(100, 200, 200, 210)),
                StrokeThickness  = 1.0,
                StrokeDashArray  = new DoubleCollection { 3, 3 },
                IsHitTestVisible = false,
                Visibility       = Visibility.Collapsed,
            };
            _timelineCanvas.Children.Add(_crosshairLine);

            _hoverBubbleText = new TextBlock
            {
                FontSize   = 8.5,
                FontFamily = new FontFamily("Consolas"),
                Foreground = new SolidColorBrush(Color.FromRgb(220, 220, 228)),
            };
            _hoverBubble = new Border
            {
                Background        = new SolidColorBrush(Color.FromArgb(200, 28, 30, 38)),
                BorderBrush       = new SolidColorBrush(Color.FromArgb(60, 200, 200, 210)),
                BorderThickness   = new Thickness(1),
                CornerRadius      = new CornerRadius(4),
                Padding           = new Thickness(6, 3, 6, 3),
                IsHitTestVisible  = false,
                Visibility        = Visibility.Collapsed,
                Child             = _hoverBubbleText,
            };
            _timelineCanvas.Children.Add(_hoverBubble);

            _timelineCanvas.SizeChanged += (_, __) => RedrawTimeline();
            _timelineCanvas.MouseMove   += OnTimelineMouseMove;
            _timelineCanvas.MouseLeave  += OnTimelineMouseLeave;

            var timeAxisGrid = new Grid();
            timeAxisGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            timeAxisGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            timeAxisGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            _timeLblStart = new TextBlock { FontSize = 8, Foreground = FgDim,
                FontFamily = new FontFamily("Segoe UI"), Margin = new Thickness(2, 0, 0, 0) };
            _timeLblMid = new TextBlock { FontSize = 8, Foreground = FgDim,
                FontFamily = new FontFamily("Segoe UI"), HorizontalAlignment = HorizontalAlignment.Center };
            _timeLblEnd = new TextBlock { FontSize = 8, Foreground = FgDim,
                FontFamily = new FontFamily("Segoe UI"), Margin = new Thickness(0, 0, 2, 0) };

            Grid.SetColumn(_timeLblStart, 0); timeAxisGrid.Children.Add(_timeLblStart);
            Grid.SetColumn(_timeLblMid,   1); timeAxisGrid.Children.Add(_timeLblMid);
            Grid.SetColumn(_timeLblEnd,   2); timeAxisGrid.Children.Add(_timeLblEnd);

            Grid.SetRow(timeAxisGrid, 2);
            tlSection.Children.Add(timeAxisGrid);

            // Wrap timeline section in an elevated card.
            var tlCard = new Border
            {
                Background      = new SolidColorBrush(Color.FromArgb(14, 255, 255, 255)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(22, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(4),
                Margin          = new Thickness(6, 6, 6, 3),
                Child           = tlSection,
            };
            Grid.SetRow(tlCard, 0);
            _rightPanel.Children.Add(tlCard);

            // ── Chart ↕ Bottom splitter ──────────────────────────────────────
            var chartBottomSplitter = new GridSplitter
            {
                Height              = 4,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment   = VerticalAlignment.Stretch,
                Background          = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                ResizeDirection     = GridResizeDirection.Rows,
                ResizeBehavior      = GridResizeBehavior.PreviousAndNext,
                Cursor              = System.Windows.Input.Cursors.SizeNS,
            };
            Grid.SetRow(chartBottomSplitter, 1);
            _rightPanel.Children.Add(chartBottomSplitter);

            // ── D-Score bars ─────────────────────────────────────────────────
            var dSection = new StackPanel { Margin = new Thickness(8, 4, 8, 6) };
            dSection.Children.Add(new Label
            {
                Content    = "BEHAVIORAL SIGNALS",
                FontSize   = 8,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = FgDim,
                Padding    = new Thickness(2, 0, 0, 4),
            });

            for (int di = 0; di < 7; di++)
            {
                _dBarBrushes[di] = new SolidColorBrush(ColStable);

                var barRow = new Grid
                {
                    Margin  = new Thickness(0, 3, 0, 3),
                    ToolTip = DimTooltips[di],
                };
                _dBarRows[di] = barRow;
                barRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(72) });
                barRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                barRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(38) });

                var dimLbl = new Label
                {
                    Content           = DimNames[di],
                    FontSize          = 9,
                    FontFamily        = new FontFamily("Segoe UI"),
                    Foreground        = FgMuted,
                    Padding           = new Thickness(0),
                    VerticalAlignment = VerticalAlignment.Center,
                };
                _dBarDimLabels[di] = dimLbl;

                var track = new Grid { Margin = new Thickness(4, 0, 4, 0) };
                _dBarTracks[di] = track;

                track.Children.Add(new Border
                {
                    Height            = 10,
                    CornerRadius      = new CornerRadius(5),
                    Background        = new SolidColorBrush(Color.FromArgb(25, 255, 255, 255)),
                    VerticalAlignment = VerticalAlignment.Center,
                });

                var fill = new Border
                {
                    Height              = 10,
                    CornerRadius        = new CornerRadius(5),
                    Background          = _dBarBrushes[di],
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment   = VerticalAlignment.Center,
                    Width               = 0,
                };
                _dBarFills[di] = fill;
                track.Children.Add(fill);

                // Knob dot — white circle that sits at the right edge of the fill,
                // like a scrubber handle.  Hidden when the bar is empty.
                var dot = new Ellipse
                {
                    Width               = 10,
                    Height              = 10,
                    Fill                = new SolidColorBrush(Color.FromArgb(220, 255, 255, 255)),
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment   = VerticalAlignment.Center,
                    IsHitTestVisible    = false,
                    Visibility          = Visibility.Collapsed,
                };
                _dBarDots[di] = dot;
                track.Children.Add(dot);

                var valLbl = new Label
                {
                    Content                    = "0.00",
                    FontSize                   = 9,
                    FontFamily                 = new FontFamily("Segoe UI"),
                    Foreground                 = FgMuted,
                    Padding                    = new Thickness(0),
                    HorizontalContentAlignment = HorizontalAlignment.Right,
                    VerticalAlignment          = VerticalAlignment.Center,
                };
                _dBarValues[di] = valLbl;

                Grid.SetColumn(dimLbl,  0); barRow.Children.Add(dimLbl);
                Grid.SetColumn(track,   1); barRow.Children.Add(track);
                Grid.SetColumn(valLbl,  2); barRow.Children.Add(valLbl);

                dSection.Children.Add(barRow);
            }

            var dScrollViewer = new ScrollViewer
            {
                Content                       = dSection,
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };
            var dBorder = new Border
            {
                Child           = dScrollViewer,
                Background      = new SolidColorBrush(Color.FromArgb(10, 255, 255, 255)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(20, 255, 255, 255)),
                BorderThickness = new Thickness(1, 1, 0, 1),
                CornerRadius    = new CornerRadius(4, 0, 0, 4),
                Margin          = new Thickness(6, 0, 0, 6),
            };
            _dBarsSection = dBorder;

            // ── Bottom area: D-bars (left) + Journal (right, toggleable) ────────
            // Journal column starts at JournalColW (visible). The ✎ button toggles
            // it between JournalColW and 0 via _journalColDef.
            var bottomGrid = new Grid();
            bottomGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star), MinWidth = 80 }); // col 0: D-bars
            _journalSplitterColDef = new ColumnDefinition { Width = new GridLength(4) };
            bottomGrid.ColumnDefinitions.Add(_journalSplitterColDef);                                                              // col 1: splitter
            _journalColDef = new ColumnDefinition { Width = new GridLength(JournalColW), MinWidth = 120 };
            bottomGrid.ColumnDefinitions.Add(_journalColDef);                                                                      // col 2: Journal
            _journalVisible = true;   // journal is shown by default in new layout

            // D-bars ↔ Journal splitter
            var journalSplitter = new GridSplitter
            {
                Width               = 4,
                HorizontalAlignment = HorizontalAlignment.Stretch,
                VerticalAlignment   = VerticalAlignment.Stretch,
                Background          = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                ResizeDirection     = GridResizeDirection.Columns,
                ResizeBehavior      = GridResizeBehavior.PreviousAndNext,
                Cursor              = System.Windows.Input.Cursors.SizeWE,
            };
            Grid.SetColumn(journalSplitter, 1);
            bottomGrid.Children.Add(journalSplitter);

            Grid.SetColumn(dBorder, 0);
            bottomGrid.Children.Add(dBorder);

            Grid.SetRow(bottomGrid, 2);
            _rightPanel.Children.Add(bottomGrid);

            // ── HUD Journal section (right column of bottom Grid) ────────────────
            // Redesign after reference:
            //   Row 0: QUICK JOURNAL header + trade context
            //   Row 1: 3 emotion chips (Great / Neutral / Frustrated) — matches Dashboard Journal
            //   Row 2: multi-line note TextBox with placeholder text
            //   Row 3: "+ Add Tag" (UI placeholder, no function) + "Save Note" green button

            // ── Header: title (left) + trade context (right) ──────────────────
            var jHeaderRow = new Grid { Margin = new Thickness(10, 8, 10, 4) };
            jHeaderRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            jHeaderRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var jTitleLbl = new TextBlock
            {
                Text              = "QUICK JOURNAL",
                FontSize          = 8,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgDim,
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(jTitleLbl, 0);
            jHeaderRow.Children.Add(jTitleLbl);

            _lastTradeContextLbl = new TextBlock
            {
                Text                = "No trades yet today.",
                FontSize            = 8,
                FontFamily          = new FontFamily("Segoe UI"),
                Foreground          = new SolidColorBrush(Color.FromArgb(110, 255, 255, 255)),
                TextAlignment       = TextAlignment.Right,
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment   = VerticalAlignment.Center,
                TextTrimming        = TextTrimming.CharacterEllipsis,
            };
            Grid.SetColumn(_lastTradeContextLbl, 1);
            jHeaderRow.Children.Add(_lastTradeContextLbl);

            // ── 3 emotion chips ────────────────────────────────────────────────
            // Great / Neutral / Frustrated — matches Dashboard Journal exactly.
            string[]       chipEmoji   = { "\uD83D\uDE0A", "\uD83D\uDE10", "\uD83D\uDE24" };
            string[]       chipLabels  = { "Great", "Neutral", "Frustrated" };
            string[]       chipTip     = { "Feeling great, in the zone", "Neutral / steady", "Frustrated or tense" };
            JournalEmotion[] chipEmo   = { JournalEmotion.Calm, JournalEmotion.Neutral, JournalEmotion.Stressed };
            var chipBgIdle     = Color.FromArgb(22, 255, 255, 255);
            var chipBgHover    = Color.FromArgb(50, 255, 255, 255);
            var chipBgSelected = Color.FromArgb(70, 100, 200, 120);

            _chipBorders = new Border[3];
            var jChipsWrap = new WrapPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(8, 0, 8, 6),
            };
            for (int ci = 0; ci < 3; ci++)
            {
                int idx = ci;
                var chipContent = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    VerticalAlignment = VerticalAlignment.Center,
                };
                chipContent.Children.Add(new TextBlock
                {
                    Text              = chipEmoji[ci],
                    FontSize          = 12,
                    Margin            = new Thickness(0, 0, 3, 0),
                    VerticalAlignment = VerticalAlignment.Center,
                });
                chipContent.Children.Add(new TextBlock
                {
                    Text              = chipLabels[ci],
                    FontSize          = 9,
                    FontFamily        = new FontFamily("Segoe UI"),
                    Foreground        = new SolidColorBrush(Color.FromArgb(200, 200, 200, 205)),
                    VerticalAlignment = VerticalAlignment.Center,
                });

                var chip = new Border
                {
                    Padding           = new Thickness(6, 4, 6, 4),
                    Background        = new SolidColorBrush(chipBgIdle),
                    CornerRadius      = new CornerRadius(5),
                    Margin            = new Thickness(0, 0, 5, 5),
                    Cursor            = Cursors.Hand,
                    Child             = chipContent,
                    VerticalAlignment = VerticalAlignment.Center,
                    ToolTip           = chipTip[ci],
                };
                _chipBorders[ci] = chip;

                chip.MouseEnter += (_, __) =>
                {
                    if (_selectedEmotion != chipEmo[idx])
                        chip.Background = new SolidColorBrush(chipBgHover);
                };
                chip.MouseLeave += (_, __) =>
                {
                    chip.Background = new SolidColorBrush(
                        _selectedEmotion == chipEmo[idx] ? chipBgSelected : chipBgIdle);
                };
                chip.MouseLeftButtonUp += (_, __) =>
                {
                    if (_selectedEmotion == chipEmo[idx])
                    {
                        _selectedEmotion = JournalEmotion.None;
                        chip.Background = new SolidColorBrush(chipBgIdle);
                    }
                    else
                    {
                        _selectedEmotion = chipEmo[idx];
                        for (int k = 0; k < 3; k++)
                            _chipBorders[k].Background = new SolidColorBrush(
                                k == idx ? chipBgSelected : chipBgIdle);
                    }
                };
                jChipsWrap.Children.Add(chip);
            }

            // ── Note text area ─────────────────────────────────────────────────
            var noteBorderBrushNormal  = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255));
            var noteBorderBrushFocused = new SolidColorBrush(Color.FromArgb(80, 180, 200, 180));
            _hudNoteBox = new TextBox
            {
                MinHeight        = 32,
                Background       = new SolidColorBrush(Color.FromArgb(18, 255, 255, 255)),
                Foreground       = FgBright,
                CaretBrush       = new SolidColorBrush(Color.FromArgb(180, 220, 220, 224)),
                BorderBrush      = noteBorderBrushNormal,
                BorderThickness  = new Thickness(1),
                Padding          = new Thickness(8, 6, 8, 6),
                FontFamily       = new FontFamily("Segoe UI"),
                FontSize         = 10,
                AcceptsReturn    = true,
                TextWrapping     = TextWrapping.Wrap,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                Margin           = new Thickness(8, 0, 8, 6),
                FocusVisualStyle = null,
            };
            _hudNoteBox.PreviewMouseLeftButtonDown += (_, __) => EnableNoteBoxTyping();
            _hudNoteBox.GotFocus  += (_, __) => _hudNoteBox.BorderBrush = noteBorderBrushFocused;
            _hudNoteBox.LostFocus += (_, __) =>
            {
                _hudNoteBox.BorderBrush = noteBorderBrushNormal;
                DisableNoteBoxTyping();
            };
            _hudNoteBox.KeyDown += (s, e) =>
            {
                if (e.Key == System.Windows.Input.Key.Enter &&
                    (System.Windows.Input.Keyboard.Modifiers & System.Windows.Input.ModifierKeys.Shift) == 0)
                {
                    e.Handled = true;
                    SubmitHudNote();
                    DisableNoteBoxTyping();
                    Keyboard.ClearFocus();
                }
            };

            // ── Bottom action row: + Add Tag (UI placeholder) + Save Note ─────
            var jBottomRow = new Grid { Margin = new Thickness(8, 0, 8, 8) };
            jBottomRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            jBottomRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            jBottomRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var addTagLbl = new TextBlock
            {
                Text              = "+ Add Tag",
                FontSize          = 9,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = new SolidColorBrush(Color.FromArgb(130, 180, 210, 180)),
                VerticalAlignment = VerticalAlignment.Center,
                Cursor            = Cursors.Hand,
                ToolTip           = "Tag this entry (coming soon)",
            };
            Grid.SetColumn(addTagLbl, 0);
            jBottomRow.Children.Add(addTagLbl);

            var jSaveBtn = new Border
            {
                Background        = new SolidColorBrush(Color.FromRgb(36, 160, 70)),
                CornerRadius      = new CornerRadius(5),
                Padding           = new Thickness(14, 5, 14, 5),
                Cursor            = Cursors.Hand,
                VerticalAlignment = VerticalAlignment.Center,
                Child             = new TextBlock
                {
                    Text                = "Save Note",
                    FontSize            = 9,
                    FontFamily          = new FontFamily("Segoe UI"),
                    FontWeight          = FontWeights.SemiBold,
                    Foreground          = new SolidColorBrush(Colors.White),
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                },
            };
            jSaveBtn.MouseEnter += (_, __) =>
                jSaveBtn.Background = new SolidColorBrush(Color.FromRgb(50, 180, 85));
            jSaveBtn.MouseLeave += (_, __) =>
                jSaveBtn.Background = new SolidColorBrush(Color.FromRgb(36, 160, 70));
            jSaveBtn.MouseLeftButtonUp += (_, __) =>
            {
                SubmitHudNote();
                DisableNoteBoxTyping();
                Keyboard.ClearFocus();
            };
            Grid.SetColumn(jSaveBtn, 2);
            jBottomRow.Children.Add(jSaveBtn);

            // ── Section wrapper ───────────────────────────────────────────────
            // DockPanel instead of StackPanel: header + chips dock to Top, Save Note
            // row docks to Bottom, and the note TextBox fills whatever space remains.
            // This keeps Save Note always visible even when the panel is short.
            var jInner = new DockPanel { LastChildFill = true };
            DockPanel.SetDock(jHeaderRow,  Dock.Top);
            DockPanel.SetDock(jChipsWrap,  Dock.Top);
            DockPanel.SetDock(jBottomRow,  Dock.Bottom);
            jInner.Children.Add(jHeaderRow);
            jInner.Children.Add(jChipsWrap);
            jInner.Children.Add(jBottomRow);
            jInner.Children.Add(_hudNoteBox);  // last child fills remaining space

            var jSectionBorder = new Border
            {
                Background      = new SolidColorBrush(Color.FromArgb(16, 255, 255, 255)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(22, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(0, 4, 4, 0),
                Margin          = new Thickness(0, 0, 6, 6),
                Child           = jInner,
                ClipToBounds    = true,
            };
            Grid.SetColumn(jSectionBorder, 2);
            bottomGrid.Children.Add(jSectionBorder);

            _rightPanel.SizeChanged += (_, __) => RedrawDScoreBars();

            Content = root;

            // ── Animation timer (30 fps) ─────────────────────────────────────
            _animTimer       = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(33) };
            _animTimer.Tick += OnAnimTick;
            _animTimer.Start();
            Closed          += (_, __) => { _layoutSaveTimer?.Stop(); _animTimer.Stop(); SaveLayout(); };
            Loaded          += (_, __) => LoadLayout();
            SizeChanged     += (_, __) => ScheduleLayoutSave();
            LocationChanged += (_, __) => ScheduleLayoutSave();
        }

        // ── Gradient arc helpers ──────────────────────────────────────────────

        /// <summary>
        /// Builds one of the 24 gradient arc segments.  The segment spans
        /// [segIndex * segSweep … (segIndex+1) * segSweep] degrees from GaugeStartDeg.
        /// The tip segment receives <paramref name="glow"/> (other segments pass null).
        /// </summary>
        private static Path BuildGradArcSeg(int segIndex, double segSweep,
                                            SolidColorBrush brush, DropShadowEffect glow)
        {
            double startDeg = GaugeStartDeg + segIndex       * segSweep;
            double endDeg   = GaugeStartDeg + (segIndex + 1) * segSweep;

            double sRad = startDeg * Math.PI / 180.0;
            double eRad = endDeg   * Math.PI / 180.0;

            var sPt = new Point(GaugeCx + GaugeR * Math.Cos(sRad), GaugeCy + GaugeR * Math.Sin(sRad));
            var ePt = new Point(GaugeCx + GaugeR * Math.Cos(eRad), GaugeCy + GaugeR * Math.Sin(eRad));

            var seg = new ArcSegment
            {
                Point          = ePt,
                Size           = new Size(GaugeR, GaugeR),
                IsLargeArc     = segSweep > 180.0,
                SweepDirection = SweepDirection.Clockwise,
            };
            var fig = new PathFigure { StartPoint = sPt, IsClosed = false };
            fig.Segments.Add(seg);
            var geo = new PathGeometry();
            geo.Figures.Add(fig);

            // Flat caps on both ends so adjacent segments share exact edge pixels and
            // appear as a continuous smooth colour band (Round caps create hemispheric
            // bumps that make the arc look like a chain of individual circles).
            return new Path
            {
                Stroke             = brush,
                StrokeThickness    = GaugeStroke,
                StrokeStartLineCap = PenLineCap.Flat,
                StrokeEndLineCap   = PenLineCap.Flat,
                StrokeLineJoin     = PenLineJoin.Round,
                Fill               = Brushes.Transparent,
                Data               = geo,
                Effect             = glow,
                Visibility         = Visibility.Collapsed,
            };
        }

        /// <summary>
        /// Updates all gradient arc segments so the active portion covers
        /// [0 … psi/100 × GaugeSweepDeg] with the given colour.
        /// Segments past the active sweep are hidden; the tip segment glows.
        /// </summary>
        private void UpdateGradArc(double psi, Color color)
        {
            double sweep     = GaugeSweepDeg * Math.Max(0.0, Math.Min(100.0, psi)) / 100.0;
            double segSweep  = GaugeSweepDeg / GradArcN;
            // Index of the last fully-covered segment.
            int    lastFull  = (int)(sweep / segSweep) - 1;
            // Fractional coverage in the partial leading segment.
            double partial   = (sweep % segSweep) / segSweep;

            for (int gi = 0; gi < GradArcN; gi++)
            {
                if (gi < lastFull || (gi == lastFull && lastFull >= 0))
                {
                    _gradArcBrushes[gi].Color = color;
                    _gradArcSegs[gi].Visibility = Visibility.Visible;
                }
                else if (gi == lastFull + 1 && partial > 0.01)
                {
                    // Partial leading segment — show but at reduced opacity.
                    _gradArcBrushes[gi].Color   = color;
                    _gradArcBrushes[gi].Opacity = 0.12 + 0.88 * ((double)gi / (GradArcN - 1)) * partial;
                    _gradArcSegs[gi].Visibility = Visibility.Visible;
                }
                else
                {
                    _gradArcSegs[gi].Visibility = Visibility.Collapsed;
                }
            }

            // Update tip glow colour.
            _progressGlow.Color = color;

            // Arc tip dot — find actual pixel tip position.
            double eRad = (GaugeStartDeg + sweep) * Math.PI / 180.0;
            double tipX = GaugeCx + GaugeR * Math.Cos(eRad);
            double tipY = GaugeCy + GaugeR * Math.Sin(eRad);
            if (_arcTipDot != null)
            {
                Canvas.SetLeft(_arcTipDot, tipX - 6.5);
                Canvas.SetTop (_arcTipDot, tipY - 6.5);
                _arcTipDot.Visibility = sweep >= 0.5 ? Visibility.Visible : Visibility.Collapsed;
            }
        }

        private void UpdateTimeframeBtnStyles()
        {
            if (_tfBtns == null) return;
            int[]   tfSeconds = { 60, 300, 900, 3600, 0 };
            for (int ti = 0; ti < 5; ti++)
            {
                int  sec     = tfSeconds[ti];
                bool sel     = (sec == 0 && _timeframeSec == null) ||
                               (sec != 0 && _timeframeSec == sec);
                var lbl = _tfBtns[ti].Child as TextBlock;
                if (lbl != null)
                    lbl.Foreground = sel
                        ? new SolidColorBrush(Color.FromRgb(100, 220, 100))
                        : FgDim;
                _tfBtns[ti].Background = new SolidColorBrush(sel
                    ? Color.FromArgb(40, 100, 210, 100)
                    : Color.FromArgb(0, 0, 0, 0));
            }
        }

        // ── Timeline hover crosshair ──────────────────────────────────────────

        private void OnTimelineMouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (_psiHistory.Count == 0 || _tlRenderSpanSec < 1) return;

            double cw = _timelineCanvas.ActualWidth;
            double ch = _timelineCanvas.ActualHeight;
            if (cw < 10 || ch < 10) return;

            var pos   = e.GetPosition(_timelineCanvas);
            double mx = pos.X;

            // Map mouse X → time using the same window as the rendered chart.
            double mouseSec  = mx / cw * _tlRenderSpanSec;
            DateTime mouseT  = _tlRenderStart + TimeSpan.FromSeconds(mouseSec);

            // Use the same filtered window that RedrawTimeline rendered (matches zoom).
            var all = _psiHistory.ToArray();
            PsiPoint[] arr;
            if (_timeframeSec.HasValue && all.Length > 0)
            {
                DateTime cutoff = DateTime.Now - TimeSpan.FromSeconds(_timeframeSec.Value);
                int si = 0;
                while (si < all.Length - 1 && all[si].T < cutoff) si++;
                arr = new PsiPoint[all.Length - si];
                Array.Copy(all, si, arr, 0, arr.Length);
            }
            else
            {
                arr = all;
            }
            if (arr.Length == 0) return;

            // Find nearest point in the visible window.
            int best = 0;
            double bestDist = double.MaxValue;
            for (int i = 0; i < arr.Length; i++)
            {
                double d = Math.Abs((arr[i].T - mouseT).TotalSeconds);
                if (d < bestDist) { bestDist = d; best = i; }
            }

            double psiVal     = arr[best].V;
            double floor      = _chartFloor;
            double chartRange = Math.Max(1.0, 100.0 - floor);
            double psiH       = ch;
            double yPsi       = (1.0 - Math.Max(0, Math.Min(1, (psiVal - floor) / chartRange))) * psiH;

            // Vertical crosshair line.
            _crosshairLine.X1 = mx; _crosshairLine.X2 = mx;
            _crosshairLine.Y1 = 0;  _crosshairLine.Y2 = ch;
            _crosshairLine.Visibility = Visibility.Visible;

            // Bubble content.
            _hoverBubbleText.Text = string.Format("{0:F1}  {1}", psiVal, arr[best].T.ToString("HH:mm"));

            // Position bubble — right of crosshair if < midpoint, else left.
            _hoverBubble.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            double bw = _hoverBubble.DesiredSize.Width;
            double bh = _hoverBubble.DesiredSize.Height;
            double bx = mx + 8;
            if (bx + bw > cw) bx = mx - bw - 8;
            double by = Math.Max(2, Math.Min(ch - bh - 2, yPsi - bh / 2));
            Canvas.SetLeft(_hoverBubble, bx);
            Canvas.SetTop (_hoverBubble, by);
            _hoverBubble.Visibility = Visibility.Visible;
        }

        private void OnTimelineMouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (_crosshairLine != null) _crosshairLine.Visibility = Visibility.Collapsed;
            if (_hoverBubble   != null) _hoverBubble.Visibility   = Visibility.Collapsed;
        }

        // ── Arc geometry helpers ─────────────────────────────────────────────

        /// <summary>
        /// Builds a coloured background arc spanning the PSI range [startPsi, endPsi]
        /// at low opacity.  Used to render the four zone bands on the gauge track.
        /// </summary>
        private static Path BuildZoneArc(double startPsi, double endPsi, Color zoneColor)
        {
            double startSweep = GaugeSweepDeg * startPsi / 100.0;
            double endSweep   = GaugeSweepDeg * endPsi   / 100.0;
            double arcSweep   = endSweep - startSweep;
            if (arcSweep < 0.1) arcSweep = 0.1;

            double sRad = (GaugeStartDeg + startSweep) * Math.PI / 180.0;
            double eRad = (GaugeStartDeg + endSweep - 0.01) * Math.PI / 180.0;

            var sPt = new Point(GaugeCx + GaugeR * Math.Cos(sRad), GaugeCy + GaugeR * Math.Sin(sRad));
            var ePt = new Point(GaugeCx + GaugeR * Math.Cos(eRad), GaugeCy + GaugeR * Math.Sin(eRad));
            var seg = new ArcSegment
            {
                Point           = ePt,
                Size            = new Size(GaugeR, GaugeR),
                IsLargeArc      = arcSweep > 180.0,
                SweepDirection  = SweepDirection.Clockwise,
            };
            var fig = new PathFigure { StartPoint = sPt, IsClosed = false };
            fig.Segments.Add(seg);
            var geo = new PathGeometry();
            geo.Figures.Add(fig);

            return new Path
            {
                Stroke             = new SolidColorBrush(Color.FromArgb(0x22, zoneColor.R, zoneColor.G, zoneColor.B)),
                StrokeThickness    = GaugeStroke,
                StrokeStartLineCap = PenLineCap.Flat,
                StrokeEndLineCap   = PenLineCap.Flat,
                Fill               = Brushes.Transparent,
                Data               = geo,
            };
        }

        // SetProgressArc is superseded by UpdateGradArc; kept as a no-op shim
        // so any call-site that references it still compiles during transition.
        private void SetProgressArc(double psi) { UpdateGradArc(psi, _progressStroke.Color); }

        // ── Public API ───────────────────────────────────────────────────────

        /// <summary>
        /// Called when the backend starts a new trading session (new calendar day, or
        /// replay rewind to a new date).  Clears the timeline history and resets the
        /// adaptive Y-axis so the chart starts fresh for the new session.
        /// </summary>
        public void ResetHudSession()
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(ResetHudSession);
                return;
            }
            _psiHistory.Clear();
            _sessionStartTime      = DateTime.MinValue;
            _chartFloor            = 0.0;
            _chartFloorExpandedAt  = DateTime.MinValue;
            if (_timelineDot != null) _timelineDot.Visibility = Visibility.Collapsed;
            RedrawTimeline();
        }

        public void UpdatePsi(double value, bool isFromFill = false, double pDisplay = 0.0)
        {
            value = Math.Max(0, Math.Min(100, value));
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdatePsi(value, isFromFill, pDisplay));
                return;
            }
            if (_isPaused) return;
            // Only start the session clock on the first real fill (entry or exit).
            // Timer-driven PSI updates (PollPositions every 30 s) must not start
            // the clock — the user hasn't started trading yet and Duration should
            // show "--" until the first actual fill arrives.
            if (_sessionStartTime == DateTime.MinValue && isFromFill)
                _sessionStartTime = DateTime.Now;
            if (value < _targetPsi - 5.0)
                _pulseIntensity = 1.0;
            _targetPsi = value;
            AddToHistory(DateTime.Now, value, pDisplay);
        }

        public void UpdateOverExposed(bool overExposed)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateOverExposed(overExposed));
                return;
            }
            if (_overExposed == overExposed) return;
            _overExposed = overExposed;
            _oversizeBanner.Visibility = overExposed ? Visibility.Visible : Visibility.Collapsed;
            if (overExposed && !_isPaused)
            {
                _statusLabel.Content  = "OVERSIZE";
                _statusFgBrush.Color  = ColOversize;
            }
            else if (!_isPaused)
            {
                ApplyDisplay(_displayedPsi);
            }
        }

        /// <summary>
        /// Shows or clears the persistent Risk Alert banner on the HUD.
        /// Pass a non-null message to show; null to hide.
        /// Called from TradeMonitor.PushPsiToHud on every evaluation cycle.
        /// </summary>
        public void UpdateRiskAlertBanner(string message)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateRiskAlertBanner(message));
                return;
            }
            bool show = !string.IsNullOrEmpty(message);
            _riskAlertBannerText.Text   = message ?? "";
            _riskAlertBanner.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
        }

        public void UpdateDScores(double d1, double d2, double d3,
                                   double d4, double d5, double d6, double d7)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateDScores(d1, d2, d3, d4, d5, d6, d7));
                return;
            }
            // Values are EWMA PSI-debt in PSI points (0-100).
            _dBarTargets[0] = d1; _dBarTargets[1] = d2; _dBarTargets[2] = d3;
            _dBarTargets[3] = d4; _dBarTargets[4] = d5; _dBarTargets[5] = d6;
            _dBarTargets[6] = d7;
        }

        /// <summary>
        /// Colour-tag each dim-bar row's name label with the most recent
        /// commit class on that dimension.  Red = A (commitment break),
        /// amber = B (behavioural signal), muted grey = no commit.  Called
        /// by TradeMonitor on every HUD push with the engine's per-dim
        /// last-commit-class array (index 1..7 → 0..6 here).
        /// </summary>
        public void UpdateDimClasses(CommitClass[] dimClasses)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateDimClasses(dimClasses));
                return;
            }
            if (dimClasses == null) return;
            for (int di = 0; di < 7; di++)
            {
                var lbl = _dBarDimLabels[di];
                if (lbl == null) continue;
                CommitClass cls = (dimClasses.Length > di + 1) ? dimClasses[di + 1] : CommitClass.None;
                Brush fg;
                if      (cls == CommitClass.A) fg = new SolidColorBrush(ColCritical);   // red
                else if (cls == CommitClass.B) fg = new SolidColorBrush(ColWarning);    // amber
                else                           fg = FgMuted;
                lbl.Foreground = fg;
            }
        }

        // ── PSI-drop notification ─────────────────────────────────────────────
        // Shows a plain-English "why did PSI just drop?" banner for 4 seconds,
        // then fades out over 1.5 seconds.  Class A commits (rule breaks) use a
        // deep-red background; Class B (behavioural patterns) use amber.
        // A new notification instantly replaces any still-visible previous one.
        public void ShowPsiDropNotif(string text, bool isClassA)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => ShowPsiDropNotif(text, isClassA));
                return;
            }

            // Stop any in-progress hold or fade
            _notifHoldTimer?.Stop();
            _notifBanner.BeginAnimation(UIElement.OpacityProperty, null);

            // Amber text only — no colored background.
            // Severity communicated by the pts number, not the colour.
            _notifBannerText.Text = text;
            _notifBanner.Opacity    = 1.0;
            _notifBanner.Visibility = Visibility.Visible;

            // Suppress approach label while event is visible
            if (_approachLabel != null) _approachLabel.Visibility = Visibility.Collapsed;

            // Hold for 4 s, then fade out over 1.5 s
            _notifHoldTimer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromSeconds(4.0)
            };
            _notifHoldTimer.Tick += (_, __) =>
            {
                _notifHoldTimer.Stop();
                var fade = new System.Windows.Media.Animation.DoubleAnimation(
                    1.0, 0.0, TimeSpan.FromSeconds(1.5))
                {
                    FillBehavior = System.Windows.Media.Animation.FillBehavior.Stop
                };
                fade.Completed += (s, e) =>
                {
                    _notifBanner.Opacity    = 0.0;
                    _notifBanner.Visibility = Visibility.Collapsed;
                    // Restore approach label if there is pending state to show
                    if (_approachLabel != null && !string.IsNullOrEmpty(_pendingApproachText))
                    {
                        _approachLabel.Text       = _pendingApproachText;
                        _approachLabel.Foreground = new SolidColorBrush(_pendingApproachColor);
                        _approachLabel.Visibility = Visibility.Visible;
                    }
                };
                _notifBanner.BeginAnimation(UIElement.OpacityProperty, fade);
            };
            _notifHoldTimer.Start();
        }

        public void UpdateSessionStats(int totalTrades, int winTrades, int alertsFired)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateSessionStats(totalTrades, winTrades, alertsFired));
                return;
            }
            _ctxTotalTrades = totalTrades;
            _statTrades.Content  = totalTrades > 0 ? totalTrades.ToString() : "\u2014";
            _statWinRate.Content = totalTrades > 0
                ? ((int)(100.0 * winTrades / totalTrades)).ToString() + "%"
                : "\u2014";
            _statAlerts.Content = alertsFired.ToString();

            if (_sessionStartTime != DateTime.MinValue)
            {
                var dur = DateTime.Now - _sessionStartTime;
                _statDuration.Content = dur.TotalHours >= 1.0
                    ? string.Format("{0}h{1:D2}m", (int)dur.TotalHours, dur.Minutes)
                    : string.Format("{0}m", Math.Max(1, (int)dur.TotalMinutes));
            }
            else
            {
                _statDuration.Content = "\u2014";
            }
            RefreshContextLine();
        }

        /// <summary>
        /// Shows or hides the carry-debt indicator below the STABLE/CAUTION label.
        /// Only visible when the previous session's debt is still non-negligible
        /// (≥ 3 PSI points), letting the trader distinguish behavioral recovery
        /// from passive overnight-debt dissolution.
        /// </summary>
        public void UpdateCarryDebt(double carryDebt)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateCarryDebt(carryDebt));
                return;
            }
            if (carryDebt >= 3.0)
            {
                // Plain-language label: "−72pt debt (yesterday)" so the trader
                // immediately understands the number is a deduction carry-forward,
                // not a current-session measurement.
                _carryDebtLabel.Content    = string.Format("-{0:F0}pt debt (yest.)", carryDebt);
                _carryDebtLabel.ToolTip    = string.Format(
                    "Carry debt: {0:F0} PSI points carried forward from yesterday's session.\n" +
                    "Violations from yesterday mean your session starts below 100.\n" +
                    "Trades cleanly today and this dissolves over 30–60 minutes.",
                    carryDebt);
                _carryDebtLabel.Visibility = Visibility.Visible;
            }
            else
            {
                _carryDebtLabel.Visibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Update the trade-context line in the Quick Journal header so the trader
        /// can see which trade their next entry will be anchored to.
        /// Format: "Trade N · Long/Short · +$X.XX"
        /// </summary>
        public void UpdateLastTradeContext(int tradeNum, string direction, double pnl)
        {
            if (_lastTradeContextLbl == null) return;
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateLastTradeContext(tradeNum, direction, pnl));
                return;
            }
            string sign = pnl >= 0 ? "+" : "";
            _lastTradeContextLbl.Text = string.Format("Trade {0} \u00B7 {1} \u00B7 {2}{3:F2}",
                                                       tradeNum, direction, sign, pnl);
            _lastTradeContextLbl.Foreground = new SolidColorBrush(
                pnl >= 0
                    ? Color.FromArgb(140,  48, 209,  88)   // green-tinted for wins
                    : Color.FromArgb(140, 255,  69,  58));  // red-tinted for losses
        }

        /// <summary>
        /// Update the Pressure P(t) mini-bar in the SESSION panel.
        /// <paramref name="pressure"/> is the v2 engine's scalar in [0, 1].
        /// The row stays visible at all times (including P ≈ 0) so the slot does
        /// not pop in/out during the session.
        /// Colour ramp:  green ≤ 0.30 → amber ≤ 0.70 → red  > 0.70.
        /// </summary>
        /// <summary>
        /// Updates the persistent approach-state label below the PSI gauge.
        /// Shows e.g. "Trades  2 / 3" or "Size  4 / 3" when dimensions approach
        /// or cross their declared limits.  Hidden while an event banner is active.
        /// Pass null/empty to clear.
        /// </summary>
        public void UpdateApproachStatus(string text, Color color)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateApproachStatus(text, color));
                return;
            }
            _pendingApproachText  = text  ?? "";
            _pendingApproachColor = color;

            if (_approachLabel == null) return;

            // Event banner in progress — don't interrupt; cached values will be
            // applied in ShowPsiDropNotif's fade-completion callback.
            if (_notifBanner != null && _notifBanner.Visibility == Visibility.Visible) return;

            if (string.IsNullOrEmpty(_pendingApproachText))
            {
                _approachLabel.Visibility = Visibility.Collapsed;
            }
            else
            {
                _approachLabel.Text       = _pendingApproachText;
                _approachLabel.Foreground = new SolidColorBrush(_pendingApproachColor);
                _approachLabel.Visibility = Visibility.Visible;
            }
        }

        public void UpdatePressure(double pressure)        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdatePressure(pressure));
                return;
            }
            if (_pressureStatRow == null || _pressurePanel == null) return;

            _curPressure = Math.Max(0.0, Math.Min(1.0, pressure));

            // ── Pressure corner chip: colour + visibility driven by P ────────
            // P < 0.05 → chip hidden entirely (calm, zero chrome)
            // P 0.05–0.35 → green chip (elevated but benign)
            // P 0.35–0.65 → amber chip (Class B amplification kicking in)
            // P > 0.65 → red chip (decay gated, evidence builds fast)
            // A single compact pill in the header replaces the old gauge-
            // sized ring that monopolised peripheral vision.
            if (_pressureChip != null && _pressureChipText != null)
            {
                if (_curPressure < PressureChipMinP)
                {
                    _pressureChip.Visibility = Visibility.Collapsed;
                }
                else
                {
                    Color chipColor;
                    string chipLabel;
                    if      (_curPressure < 0.35) { chipColor = ColStable;   chipLabel = "Low";  }
                    else if (_curPressure < 0.65) { chipColor = ColWarning;  chipLabel = "Med";  }
                    else                          { chipColor = ColCritical; chipLabel = "High"; }

                    // Dim-translucent fill + vivid border so the chip reads
                    // clearly on both the dark header and any user theme
                    // without overwhelming the title beside it.
                    _pressureChipBg.Color     = Color.FromArgb( 60,
                                                 chipColor.R, chipColor.G, chipColor.B);
                    _pressureChipBorder.Color = chipColor;
                    _pressureChipText.Text    = "";   // no text — pill color conveys the level
                    _pressureChip.Visibility  = Visibility.Visible;
                }
            }

            // ── Pressure number row: visible only when PressureDisplay != GaugeRing ─
            bool showNumber = _settings.PressureDisplay != HudPressureDisplay.GaugeRing
                           && _settings.Mode != HudDisplayMode.Minimal;
            _pressureStatRow.Visibility = showNumber ? Visibility.Visible : Visibility.Collapsed;

            if (showNumber)
            {
                double trackWidth = 60.0; // fallback
                var track = _pressureFill.Parent as Grid;
                if (track != null && track.ActualWidth > 2.0)
                trackWidth = track.ActualWidth;
                _pressureFill.Width = trackWidth * _curPressure;

                Color c;
                if      (_curPressure <= 0.30) c = ColStable;
                else if (_curPressure <= 0.70) c = ColCaution;
                else                           c = ColCritical;
                _pressureFill.Background = new SolidColorBrush(c);
                if (_pressureValueLbl != null)
                    _pressureValueLbl.Visibility = Visibility.Collapsed;
            }

            RefreshContextLine();
        }

        /// <summary>
        /// Shows the name of the highest-active behavioral dimension below the
        /// PSI value when the right panel is collapsed.  Hidden when expanded
        /// (the full D-score bars are visible) or when all debts are negligible.
        /// Threshold: 1 PSI point — any visible bar should show a label hint.
        /// </summary>
        public void UpdatePeakDimLabel(double[] debts, CommitClass[] dimClasses = null,
                                       string d6Detail = null)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdatePeakDimLabel(debts, dimClasses, d6Detail));
                return;
            }
            if (_expanded)
            {
                _peakDimLabel.Visibility = Visibility.Collapsed;
                return;
            }
            int maxIdx = 0;
            for (int i = 1; i < 7; i++)
                if (debts[i] > debts[maxIdx]) maxIdx = i;
            if (debts[maxIdx] >= 1.0)
            {
                // Append [A] / [B] class-tag when the engine has recorded a
                // commit on this dim: Class A (commitment break) is rendered
                // in red, Class B (behavioural signal) in amber, untagged in
                // the existing orange colour.  Gives the trader immediate
                // "am I violating a rule or showing a pattern?" context.
                string tag  = "";
                Color  col  = Color.FromArgb(200, 255, 149, 0);   // default amber-orange
                if (dimClasses != null && dimClasses.Length > maxIdx + 1)
                {
                    var cls = dimClasses[maxIdx + 1];   // 1-based in engine
                    if (cls == CommitClass.A) { tag = " [A]"; col = ColCritical; }
                    else if (cls == CommitClass.B) { tag = " [B]"; col = ColWarning; }
                }

                // When D6 (Rules / Session Window) is the dominant dimension,
                // surface the specific violation reason directly in the label so
                // the trader knows immediately which rule was breached rather than
                // just seeing "▲ Rules [A]" without context.
                string dimName = DimNames[maxIdx];
                if (maxIdx == 5 && !string.IsNullOrEmpty(d6Detail))
                {
                    // Compact label for the tiny peak-dim indicator (font 7, gauge 150px).
                    // Full reason lives in the tooltip for hover inspection.
                    dimName = d6Detail.StartsWith("Session ended")   ? "After trading hours"
                            : d6Detail.StartsWith("Session starts")  ? "Before trading hours"
                            : "Daily loss limit";
                    _peakDimLabel.ToolTip = d6Detail;
                }
                else
                {
                    _peakDimLabel.ToolTip = null;
                }

                _peakDimLabel.Content    = string.Format("\u25b2 {0}{1}", dimName, tag);
                _peakDimLabel.Foreground = new SolidColorBrush(col);
                _peakDimLabel.Visibility = Visibility.Visible;
            }
            else
            {
                _peakDimLabel.Visibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// Updates the header badge to reflect baseline recording status.
        /// Pass the suspend reason ("SIM", "PLAYBACK", "TEST") or null for live.
        /// When live and baseline is still immature, pass "LEARNING" from the caller.
        /// </summary>
        public void UpdateBaselineStatus(string reason)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateBaselineStatus(reason));
                return;
            }

            _baselineBadge.Visibility = Visibility.Visible;

            Color bg, fg;
            string text;
            bool autoDetected;

            switch (reason)
            {
                case "SIM":
                    bg = Color.FromRgb(255, 214, 10);
                    fg = Color.FromRgb(30, 30, 30);
                    text = "SIM"; autoDetected = true;
                    break;
                case "PLAYBACK":
                    bg = Color.FromRgb(10, 132, 255);
                    fg = Color.FromRgb(255, 255, 255);
                    text = "PLAYBACK"; autoDetected = true;
                    break;
                case "TEST":
                    bg = Color.FromRgb(255, 159, 10);
                    fg = Color.FromRgb(30, 30, 30);
                    text = "TEST"; autoDetected = false;
                    break;
                case "LEARNING":
                    bg = Color.FromRgb(100, 100, 105);
                    fg = Color.FromRgb(200, 200, 200);
                    text = "LEARNING"; autoDetected = false;
                    break;
                default:
                    bg = Color.FromRgb(48, 209, 88);
                    fg = Color.FromRgb(20, 20, 20);
                    text = "REC"; autoDetected = false;
                    break;
            }

            _badgeIsAutoDetected        = autoDetected;
            _baselineBadgeText.Text     = text;
            _baselineBadge.Background   = new SolidColorBrush(bg);
            _baselineBadgeText.Foreground = new SolidColorBrush(fg);
            _baselineBadge.Cursor       = (autoDetected || text == "LEARNING") ? Cursors.Arrow : Cursors.Hand;
            _baselineBadge.ToolTip      = autoDetected
                ? "Auto-detected — recording paused"
                : (text == "TEST"
                    ? "Test mode active — click to resume recording"
                    : text == "LEARNING"
                        ? "Building your baseline — needs 5+ live sessions"
                        : "Recording your baseline — click to pause");
        }

        // ── Timeline helpers ─────────────────────────────────────────────────

        private void AddToHistory(DateTime time, double psi, double pDisplay = 0.0)
        {
            while (_psiHistory.Count >= TimelineMaxPts) _psiHistory.Dequeue();
            _psiHistory.Enqueue(new PsiPoint { T = time, V = psi, P = (float)pDisplay });
            if (_expanded) RedrawTimeline();
        }

        private void RedrawTimeline()
        {
            if (_timelineCanvas == null || _timelineLine == null) return;
            double w = _timelineCanvas.ActualWidth;
            double h = _timelineCanvas.ActualHeight;
            if (w < 10 || h < 10) return;

            // ── Timeframe filtering ──────────────────────────────────────────────
            // When a timeframe is selected, only show the most recent _timeframeSec
            // seconds of history.  null = full session.
            var all = _psiHistory.ToArray();
            PsiPoint[] arr;
            if (_timeframeSec.HasValue && all.Length > 0)
            {
                DateTime cutoff = DateTime.Now - TimeSpan.FromSeconds(_timeframeSec.Value);
                // Find first index >= cutoff.
                int startIdx = 0;
                while (startIdx < all.Length - 1 && all[startIdx].T < cutoff)
                    startIdx++;
                int len = all.Length - startIdx;
                arr = new PsiPoint[len];
                Array.Copy(all, startIdx, arr, 0, len);
            }
            else
            {
                arr = all;
            }
            int n = arr.Length;

            // ── Adaptive Y-axis floor (based on filtered window) ────────────────
            double minPsi = 100.0;
            for (int i = 0; i < n; i++)
                if (arr[i].V < minPsi) minPsi = arr[i].V;
            double targetFloor = Math.Floor(Math.Max(0.0, minPsi - 5.0) / 10.0) * 10.0;
            if (targetFloor < _chartFloor)
            {
                _chartFloor           = targetFloor;
                _chartFloorExpandedAt = DateTime.Now;
            }
            else if (targetFloor > _chartFloor)
            {
                if (_chartFloorExpandedAt == DateTime.MinValue)
                    _chartFloor = targetFloor;
                else if ((DateTime.Now - _chartFloorExpandedAt).TotalSeconds > ChartFloorContractDelaySec)
                    _chartFloor = Math.Min(targetFloor, _chartFloor + 10.0);
            }
            double floor      = _chartFloor;
            double chartRange = Math.Max(1.0, 100.0 - floor);

            // PSI → Y mapping (full canvas height; pressure pane removed).
            double psiH = h;
            Func<double, double> psiToY = psi =>
                (1.0 - Math.Max(0.0, Math.Min(1.0, (psi - floor) / chartRange))) * psiH;

            // ── Zone bands ───────────────────────────────────────────────────────
            double y80 = Math.Max(0.0, Math.Min(psiH, psiToY(ZoneStable)));
            double y50 = Math.Max(0.0, Math.Min(psiH, psiToY(ZoneWarning)));
            Canvas.SetLeft(_zoneBandStable,   0); Canvas.SetTop(_zoneBandStable,   0);
            _zoneBandStable.Width   = w; _zoneBandStable.Height   = Math.Max(0, y80);
            Canvas.SetLeft(_zoneBandCaution,  0); Canvas.SetTop(_zoneBandCaution,  y80);
            _zoneBandCaution.Width  = w; _zoneBandCaution.Height  = Math.Max(0, y50 - y80);
            Canvas.SetLeft(_zoneBandCritical, 0); Canvas.SetTop(_zoneBandCritical, y50);
            _zoneBandCritical.Width = w; _zoneBandCritical.Height = Math.Max(0, psiH - y50);

            _gridLine80.Visibility = (ZoneStable  > floor) ? Visibility.Visible : Visibility.Collapsed;
            _gridLine50.Visibility = (ZoneWarning > floor) ? Visibility.Visible : Visibility.Collapsed;
            _gridLine80.X1 = 0; _gridLine80.X2 = w; _gridLine80.Y1 = y80; _gridLine80.Y2 = y80;
            _gridLine50.X1 = 0; _gridLine50.X2 = w; _gridLine50.Y1 = y50; _gridLine50.Y2 = y50;

            // Pressure subpane elements are hidden — pressure is shown in the
            // left SESSION stats row; the timeline canvas shows PSI only.
            _pressureSepLine.Visibility  = Visibility.Collapsed;
            _pressurePaneFill.Visibility = Visibility.Collapsed;
            _pressurePaneLine.Visibility = Visibility.Collapsed;
            if (_pressureShadow != null) _pressureShadow.Visibility = Visibility.Collapsed;

            if (n < 1)
            {
                _timelineLine.Points    = new PointCollection();
                _nowLine.Visibility     = Visibility.Collapsed;
                _timelineDot.Visibility = Visibility.Collapsed;
                if (_psiAreaFill != null) _psiAreaFill.Visibility = Visibility.Collapsed;
                UpdateYAxisLabels(psiToY, floor);
                return;
            }

            // ── Time-mapped X axis ───────────────────────────────────────────────
            DateTime tNow = DateTime.Now;
            DateTime tStart;
            if (_timeframeSec.HasValue)
                tStart = tNow - TimeSpan.FromSeconds(_timeframeSec.Value);
            else
                tStart = _sessionStartTime != DateTime.MinValue
                    ? _sessionStartTime
                    : arr[0].T;
            double spanSec = Math.Max(60.0, (tNow - tStart).TotalSeconds);

            // Cache mapping for hover crosshair lookups.
            _tlRenderStart   = tStart;
            _tlRenderSpanSec = spanSec;

            Func<DateTime, double> tToX = t =>
                Math.Max(0.0, Math.Min(w, (t - tStart).TotalSeconds / spanSec * w));

            // ── PSI Polyline ─────────────────────────────────────────────────────
            var psiPts = new PointCollection(n + 1);
            for (int i = 0; i < n; i++)
                psiPts.Add(new Point(tToX(arr[i].T), psiToY(arr[i].V)));
            psiPts.Add(new Point(w, psiToY(arr[n - 1].V)));   // extend flat to right
            _timelineLine.Points = psiPts;

            // ── PSI area fill — closed polygon (line points + bottom corners) ──────
            if (_psiAreaFill != null)
            {
                // Tint the gradient with the current PSI colour.
                Color areaCol = PsiColor(_displayedPsi);
                if (_psiAreaFill.Fill is LinearGradientBrush lgb && lgb.GradientStops.Count >= 2)
                {
                    lgb.GradientStops[0].Color = Color.FromArgb(55, areaCol.R, areaCol.G, areaCol.B);
                    lgb.GradientStops[1].Color = Color.FromArgb( 0, areaCol.R, areaCol.G, areaCol.B);
                }
                var fillPts = new PointCollection(psiPts.Count + 2);
                foreach (var pt in psiPts) fillPts.Add(pt);
                fillPts.Add(new Point(w, psiH));
                fillPts.Add(new Point(tToX(arr[0].T), psiH));
                _psiAreaFill.Points     = fillPts;
                _psiAreaFill.Visibility = Visibility.Visible;
            }

            // ── "Now" cursor ─────────────────────────────────────────────────────
            _nowLine.X1 = w - 0.5; _nowLine.X2 = w - 0.5;
            _nowLine.Y1 = 0;       _nowLine.Y2 = psiH;
            _nowLine.Visibility = Visibility.Visible;

            // ── Breathing dot ─────────────────────────────────────────────────────
            double dotX = w - _timelineDot.Width / 2.0;
            double dotY = psiToY(arr[n - 1].V) - _timelineDot.Height / 2.0;
            Canvas.SetLeft(_timelineDot, dotX);
            Canvas.SetTop (_timelineDot, dotY);
            _timelineDotBrush.Color = PsiColor(_displayedPsi);
            _timelineDot.Visibility = Visibility.Visible;

            // ── Y-axis labels ─────────────────────────────────────────────────────
            UpdateYAxisLabels(psiToY, floor);

            // ── Time labels ───────────────────────────────────────────────────────
            string lblStart = tStart.ToString("HH:mm");
            string lblMid   = (tStart + TimeSpan.FromSeconds(spanSec / 2)).ToString("HH:mm");
            string lblEnd   = tNow.ToString("HH:mm");
            _timeLblEnd.Text        = lblEnd;
            _timeLblStart.Text      = lblStart;
            _timeLblStart.Visibility = lblStart == lblEnd ? Visibility.Hidden : Visibility.Visible;
            _timeLblMid.Text        = lblMid;
            _timeLblMid.Visibility  = lblMid == lblEnd || lblMid == lblStart
                ? Visibility.Hidden : Visibility.Visible;
        }

        private void UpdateYAxisLabels(Func<double, double> psiToY, double floor)
        {
            if (_yAxisLabels == null) return;
            double canvasH = _timelineCanvas?.ActualHeight ?? 0;
            if (canvasH < 10) return;

            // Y-axis canvas is to the LEFT of _timelineCanvas; its ActualHeight
            // should match the chart canvas height via the Grid row.
            double[] yValues = { 25.0, 50.0, 75.0, 100.0 };
            for (int yi = 0; yi < 4; yi++)
            {
                double psi = yValues[yi];
                double yPx = psiToY(psi);
                double labelH = 10.0;  // approximate TextBlock height

                // Only show the label if the Y position is within the visible range.
                bool inRange = psi >= floor - 5;
                _yAxisLabels[yi].Visibility = inRange ? Visibility.Visible : Visibility.Collapsed;
                if (inRange)
                {
                    Canvas.SetLeft(_yAxisLabels[yi], 0);
                    Canvas.SetTop (_yAxisLabels[yi], Math.Max(0, yPx - labelH / 2));
                }
            }
        }

        /// <summary>
        /// Catmull-Rom spline through <paramref name="pts"/>.
        /// Returns a dense list of interpolated (x, y) points for smooth curves.
        /// </summary>
        private static List<Point> CatmullRomSpline(Point[] pts, int stepsPerSeg = 4)
        {
            int n = pts.Length;
            var result = new List<Point>(n * stepsPerSeg);
            if (n < 2) { if (n == 1) result.Add(pts[0]); return result; }

            for (int i = 0; i < n - 1; i++)
            {
                Point p0 = pts[Math.Max(0,   i - 1)];
                Point p1 = pts[i];
                Point p2 = pts[Math.Min(n-1, i + 1)];
                Point p3 = pts[Math.Min(n-1, i + 2)];

                for (int s = 0; s < stepsPerSeg; s++)
                {
                    double t  = (double)s / stepsPerSeg;
                    double t2 = t * t;
                    double t3 = t2 * t;
                    double x  = 0.5 * ((2*p1.X) + (-p0.X + p2.X)*t + (2*p0.X - 5*p1.X + 4*p2.X - p3.X)*t2 + (-p0.X + 3*p1.X - 3*p2.X + p3.X)*t3);
                    double y  = 0.5 * ((2*p1.Y) + (-p0.Y + p2.Y)*t + (2*p0.Y - 5*p1.Y + 4*p2.Y - p3.Y)*t2 + (-p0.Y + 3*p1.Y - 3*p2.Y + p3.Y)*t3);
                    result.Add(new Point(x, y));
                }
            }
            result.Add(pts[n - 1]);
            return result;
        }

        // ── D-Score bar helpers ──────────────────────────────────────────────

        private void RedrawDScoreBars()
        {
            bool fullOpacity = _settings.Mode == HudDisplayMode.Full;

            for (int i = 0; i < 7; i++)
            {
                // _curD[i] is in PSI-point units (0–100).
                double debt   = Math.Max(0.0, Math.Min(100.0, _curD[i]));
                double trackW = _dBarTracks[i].ActualWidth;

                // Intensity encoding: inactive bars (debt < 5 pts) fade to 25%
                // opacity so they are always present but visually recede.
                // Full mode bypasses this and always renders at full opacity.
                if (_dBarRows[i] != null)
                    _dBarRows[i].Opacity = (fullOpacity || debt >= 5.0) ? 1.0 : 0.25;

                // Bar fill: fraction of the 100-pt PSI scale.
                double fillW = 0;
                if (trackW > 1)
                {
                    fillW = (debt / 100.0) * trackW;
                    _dBarFills[i].Width = fillW;
                }

                // Label: PSI-point cost of this dimension (always positive).
                // The bar fill and bar colour already communicate "this is bad",
                // so showing a positive number is clearer than a signed one.
                _dBarValues[i].Content = debt < 0.05 ? "0"
                    : string.Format("{0:F1}", debt);

                // Color: same PsiColor function as the gauge, mapping the
                // equivalent PSI value if this dimension alone were the cause.
                // debt=0 → PsiColor(100)=green; debt=30 → PsiColor(70)=yellow;
                // debt=50 → PsiColor(50)=orange-red.
                _dBarBrushes[i].Color = PsiColor(100.0 - debt);

                // Knob dot — pinned to the right edge of the fill.
                if (debt < 0.05 || trackW < 1)
                {
                    _dBarDots[i].Visibility = Visibility.Collapsed;
                }
                else
                {
                    _dBarDots[i].Margin     = new Thickness(fillW - 5.0, 0, 0, 0);
                    _dBarDots[i].Visibility = Visibility.Visible;
                }
            }
        }

        // ── Session limits (for context line) ────────────────────────────────

        /// <summary>
        /// Tells the HUD the trader's declared max-trades-per-session so the
        /// context line can show "Trade 4/5" style proximity warnings.
        /// Pass 0 to indicate no declared limit.
        /// </summary>
        public void UpdateSessionLimits(int maxTrades)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => UpdateSessionLimits(maxTrades));
                return;
            }
            _ctxMaxTrades = maxTrades;
            RefreshContextLine();
        }

        // ── Display settings ──────────────────────────────────────────────────

        /// <summary>
        /// Applies a new set of display preferences without rebuilding the UI.
        /// Safe to call at any time from any thread.
        /// </summary>
        public void ApplyDisplaySettings(DisplaySettings s)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => ApplyDisplaySettings(s));
                return;
            }
            if (s == null) s = new DisplaySettings();
            _settings = s;

            // D-bars section visibility (Minimal hides it entirely)
            if (_dBarsSection != null)
                _dBarsSection.Visibility = (s.Mode == HudDisplayMode.Minimal)
                    ? Visibility.Collapsed : Visibility.Visible;

            // Pressure number row
            if (_pressureStatRow != null)
            {
                bool showNumber = s.PressureDisplay != HudPressureDisplay.GaugeRing
                               && s.Mode            != HudDisplayMode.Minimal;
                _pressureStatRow.Visibility = showNumber
                    ? Visibility.Visible : Visibility.Collapsed;
            }

            // Re-render bars so opacity encoding picks up the new mode immediately.
            RedrawDScoreBars();
            RefreshContextLine();
        }

        // ── Context line ──────────────────────────────────────────────────────

        /// <summary>
        /// Recomputes and updates the single fixed-position context line below
        /// the gauge.  Priority order: critical dimension → approaching trade
        /// limit → high pressure → calm summary.  Call on every state change.
        /// </summary>
        private void RefreshContextLine()
        {
            if (_contextLine == null || _isPaused)
            {
                if (_contextLine != null) _contextLine.Text = "\u2014";
                return;
            }

            // Find worst active dimension.
            int    worstDim   = -1;
            double worstScore = 0.0;
            for (int i = 0; i < 7; i++)
            {
                if (_dBarTargets[i] > worstScore)
                { worstScore = _dBarTargets[i]; worstDim = i; }
            }

            // Priority 1: approaching declared trade budget (within 1 trade)
            if (_ctxMaxTrades > 0 && _ctxTotalTrades >= _ctxMaxTrades - 1 && _ctxTotalTrades > 0)
            {
                _contextLine.Text = string.Format("\u26a0 Trade {0}/{1}",
                    _ctxTotalTrades, _ctxMaxTrades);
                _contextLine.Foreground = new SolidColorBrush(ColCaution);
                return;
            }

            // Priority 2: high pressure
            if (_curPressure >= 0.70)
            {
                _contextLine.Text       = "Slow down";
                _contextLine.Foreground = new SolidColorBrush(ColWarning);
                return;
            }

            // Priority 3: calm summary
            if (_ctxTotalTrades > 0)
            {
                string text = _ctxMaxTrades > 0
                    ? string.Format("Trade {0}/{1}", _ctxTotalTrades, _ctxMaxTrades)
                    : string.Format("Trade {0}", _ctxTotalTrades);
                _contextLine.Text       = text;
                _contextLine.Foreground = FgDim;
            }
            else
            {
                _contextLine.Text       = "ready";
                _contextLine.Foreground = FgDim;
            }
        }

        // ── Panel toggle ─────────────────────────────────────────────────────

        private void TogglePanel()
        {
            _expanded = !_expanded;
            _rightPanel.Visibility = _expanded ? Visibility.Visible : Visibility.Collapsed;
            _separator.Visibility  = _expanded ? Visibility.Visible : Visibility.Collapsed;

            if (_expanded)
            {
                _rightCol.Width = new GridLength(1, GridUnitType.Star);
                Width    = Math.Max(_expandedWidth, ExpandedMinW);
                MinWidth = ExpandedMinW;
                _panelToggleBtn.Content  = "\u25C0";
                _panelToggleBtn.ToolTip  = "Collapse panel";
                _peakDimLabel.Visibility = Visibility.Collapsed;
                RedrawTimeline();
                RedrawDScoreBars();
            }
            else
            {
                _expandedWidth = Width;
                _rightCol.Width = new GridLength(0);
                Width    = CollapsedW;
                MinWidth = CollapsedW;
                _panelToggleBtn.Content = "\u25B6";
                _panelToggleBtn.ToolTip = "Expand panel";
            }
        }

        private void ToggleJournalSection()
        {
            // Auto-expand the right panel if collapsed.
            if (!_expanded) TogglePanel();

            _journalVisible = !_journalVisible;
            if (_journalColDef != null)
                _journalColDef.Width = _journalVisible ? new GridLength(JournalColW) : new GridLength(0);
            if (_journalSplitterColDef != null)
                _journalSplitterColDef.Width = _journalVisible ? new GridLength(4) : new GridLength(0);
        }

        private void SubmitHudNote()
        {
            if (_hudNoteBox == null) return;
            string text    = (_hudNoteBox.Text ?? "").Trim();
            var    emotion = _selectedEmotion;

            // Only fire if there's something to record.
            if (emotion == JournalEmotion.None && string.IsNullOrEmpty(text)) return;

            var kind = emotion != JournalEmotion.None ? JournalKind.EmotionTag : JournalKind.QuickNote;
            JournalEntryRequested?.Invoke(kind, emotion, string.IsNullOrEmpty(text) ? null : text);

            // Reset state and visual selection.
            _hudNoteBox.Text  = "";
            _selectedEmotion  = JournalEmotion.None;
            if (_chipBorders != null)
                foreach (var b in _chipBorders)
                    b.Background = new SolidColorBrush(Color.FromArgb(22, 255, 255, 255));
        }

        // ── Monitoring state ─────────────────────────────────────────────────

        public void SetMonitoringState(bool isOn)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => SetMonitoringState(isOn));
                return;
            }
            _isPaused = !isOn;
            UpdatePillVisuals();
            if (_isPaused)
                ApplyPausedDisplay();
            else
                ApplyDisplay(_displayedPsi);
        }

        private void OnPillClicked(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true;
            _isPaused = !_isPaused;
            UpdatePillVisuals();
            if (_isPaused)
                ApplyPausedDisplay();
            else
                ApplyDisplay(_displayedPsi);
            MonitoringToggled?.Invoke(!_isPaused);
        }

        private void UpdatePillVisuals()
        {
            bool isOn                      = !_isPaused;
            _monitorPill.Background        = isOn ? PillOnBrush : PillOffBrush;
            _pillDot.HorizontalAlignment   = isOn ? HorizontalAlignment.Right : HorizontalAlignment.Left;
            _pillDot.Margin                = isOn ? new Thickness(0, 0, 2, 0) : new Thickness(2, 0, 0, 0);
            _monitorPill.ToolTip           = isOn
                ? "Monitoring ON \u2014 click to pause"
                : "Monitoring PAUSED \u2014 click to resume";
        }

        // ── Layout persistence ────────────────────────────────────────────────

        // Called from SizeChanged / LocationChanged; resets an 800 ms one-shot timer so
        // we don't thrash the file during a live drag resize, but the disk state is
        // always current within less than a second of the user finishing a resize/move.
        private void ScheduleLayoutSave()
        {
            if (_layoutSaveTimer == null)
            {
                _layoutSaveTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(800) };
                _layoutSaveTimer.Tick += (_, __) => { _layoutSaveTimer.Stop(); SaveLayout(); };
            }
            _layoutSaveTimer.Stop();
            _layoutSaveTimer.Start();
        }

        // Exposed so the TradeMonitor AddOn can call it synchronously from
        // State.Terminated before the async dispatcher-close path runs.
        internal void PersistLayout() => SaveLayout();

        private static string LayoutFilePath => System.IO.Path.Combine(
            NinjaTrader.Core.Globals.UserDataDir,
            "AddOns", "PsiMonitorLayout.dat");

        private void SaveLayout()
        {
            try
            {
                System.IO.Directory.CreateDirectory(
                    System.IO.Path.GetDirectoryName(LayoutFilePath));
                // Field 6 (expandedWidth): saves the intended expanded-panel width.
                // Use the actual current Width when expanded — _expandedWidth is only
                // updated when the user clicks the collapse toggle, so if they resized
                // the window without ever collapsing it, _expandedWidth would still hold
                // the constructor default (860) and the wrong value would be persisted.
                double expandedW = _expanded ? Width : _expandedWidth;
                double bottomH  = _bottomRowDef  != null ? _bottomRowDef.Height.Value  : 195;
                double journalW = _journalColDef != null && _journalColDef.Width.Value > 0
                    ? _journalColDef.Width.Value : JournalColW;
                System.IO.File.WriteAllText(LayoutFilePath,
                    string.Format(
                        System.Globalization.CultureInfo.InvariantCulture,
                        "{0} {1} {2} {3} {4} {5} {6} {7}",
                        (int)Left, (int)Top, (int)Width, (int)Height, _expanded,
                        (int)expandedW, (int)bottomH, (int)journalW));
            }
            catch { /* non-critical — silent fail */ }
        }

        private void LoadLayout()
        {
            try
            {
                if (!System.IO.File.Exists(LayoutFilePath)) return;
                var parts = System.IO.File.ReadAllText(LayoutFilePath)
                    .Trim().Split(' ');
                if (parts.Length < 5) return;

                var ci = System.Globalization.CultureInfo.InvariantCulture;
                double left     = double.Parse(parts[0], ci);
                double top      = double.Parse(parts[1], ci);
                double width    = double.Parse(parts[2], ci);
                double height   = double.Parse(parts[3], ci);
                bool   expanded = bool.Parse(parts[4]);

                // Field 6: expanded-panel width (added later; fall back to ExpandedW
                // for layouts saved by an older build that omits this field).
                double savedExpandedW = parts.Length >= 6
                    ? double.Parse(parts[5], ci)
                    : ExpandedW;

                // Field 7: bottom-section height (chart↕D-bars splitter).
                double savedBottomH = parts.Length >= 7
                    ? double.Parse(parts[6], ci)
                    : 195.0;

                // Field 8: journal column width (D-bars↔Journal splitter).
                double savedJournalW = parts.Length >= 8
                    ? double.Parse(parts[7], ci)
                    : JournalColW;

                // Clamp so the window is visible on the virtual screen (spans all monitors).
                // Using VirtualScreen instead of WorkArea prevents a HUD saved on a secondary
                // monitor from being snapped to the primary monitor after a display change.
                double vsLeft   = SystemParameters.VirtualScreenLeft;
                double vsTop    = SystemParameters.VirtualScreenTop;
                double vsRight  = vsLeft + SystemParameters.VirtualScreenWidth;
                double vsBottom = vsTop  + SystemParameters.VirtualScreenHeight;
                left          = Math.Max(vsLeft,    Math.Min(left,          vsRight  - 80));
                top           = Math.Max(vsTop,     Math.Min(top,           vsBottom - 40));
                width         = Math.Max(CollapsedW, Math.Min(width,        SystemParameters.VirtualScreenWidth));
                height        = Math.Max(200,        Math.Min(height,       SystemParameters.VirtualScreenHeight));
                savedExpandedW = Math.Max(400.0,    Math.Min(savedExpandedW, SystemParameters.VirtualScreenWidth));
                savedBottomH   = Math.Max(80.0,     Math.Min(savedBottomH,  600.0));
                savedJournalW  = Math.Max(120.0,    Math.Min(savedJournalW, 500.0));

                Left   = left;
                Top    = top;
                Height = height;

                // Restore splitter positions.
                if (_bottomRowDef != null)
                    _bottomRowDef.Height = new GridLength(savedBottomH);
                if (_journalColDef != null && _journalVisible)
                    _journalColDef.Width = new GridLength(savedJournalW);

                // Restore _expandedWidth BEFORE touching Width or calling TogglePanel.
                // Without this, TogglePanel's "_expandedWidth = Width" capture would
                // record CollapsedW (220) as the expanded width when loading a collapsed
                // layout, causing every subsequent expand to produce a 220 px window.
                _expandedWidth = savedExpandedW;

                if (expanded != _expanded)
                {
                    // Put Width at the correct expanded value so TogglePanel's
                    // "_expandedWidth = Width" read returns the right number,
                    // then let TogglePanel set Width to CollapsedW itself.
                    Width = _expandedWidth;
                    TogglePanel();
                }
                else
                {
                    Width = expanded ? savedExpandedW : CollapsedW;
                }
            }
            catch { /* non-critical — silent fail */ }
        }

        // ── Animation ────────────────────────────────────────────────────────

        private void OnAnimTick(object sender, EventArgs e)
        {
            if (_isPaused) return;

            // Smooth PSI number toward target.
            // Drop: ~250ms to 90% of the way (coefficient 0.25 at 30fps).
            // Rise: ~400ms to 90% of the way (coefficient 0.14 at 30fps).
            // Both directions get a smooth slide — drops are fast, recoveries
            // are slightly slower, both look physical rather than teleporting.
            double diff = _targetPsi - _displayedPsi;
            if (Math.Abs(diff) < 0.05)
                _displayedPsi = _targetPsi;
            else
                _displayedPsi += diff * (diff < 0 ? 0.25 : 0.14);

            // Decay violation pulse (τ ≈ 8 frames ≈ 265ms).
            if (_pulseIntensity > 0.005)
                _pulseIntensity *= 0.88;
            else
                _pulseIntensity = 0.0;

            // ── Arc tip dot pulse (A) ─────────────────────────────────────────
            // Opacity only — no blur, no geometry shift → zero eye strain.
            // Rate tracks PSI zone: slow=calm, faster=stressed.
            double targetTipRate = _displayedPsi >= ZoneStable  ? 0.070   // ~3.0 s
                                 : _displayedPsi >= ZoneCaution ? 0.084   // ~2.5 s
                                 : _displayedPsi >= ZoneWarning ? 0.105   // ~2.0 s
                                 : 0.126;                                  // ~1.7 s
            _tipRate  = _tipRate  + (targetTipRate - _tipRate) * 0.01;
            _tipPhase = (_tipPhase + _tipRate) % (2.0 * Math.PI);
            _arcTipDot.Opacity = 0.72 + ((Math.Sin(_tipPhase) + 1.0) * 0.5) * 0.23; // 0.72..0.95

            // ── Timeline breathing dot pulse ──────────────────────────────────────
            // Gentle 2.5 s opacity sine; speed tracks PSI zone.
            if (_timelineDot != null && _timelineDot.Visibility == Visibility.Visible)
            {
                double dotRate = _displayedPsi >= ZoneStable  ? 0.050   // ~2.5 s
                               : _displayedPsi >= ZoneCaution ? 0.063   // ~2.0 s
                               : 0.083;                                  // ~1.5 s
                _dotPhase = (_dotPhase + dotRate) % (2.0 * Math.PI);
                _timelineDot.Opacity    = 0.65 + ((Math.Sin(_dotPhase) + 1.0) * 0.5) * 0.35; // 0.65..1.0
                _timelineDotBrush.Color = PsiColor(_displayedPsi);
            }

            // ── Radar pulse ring ──────────────────────────────────────────────
            // _ringPhase ∈ [0..1).  First 35% = ring expands and fades.
            // Remaining 65% = silence (ring hidden) — gives a heartbeat-pause rhythm.
            // Cycle rate tracks PSI zone: 4 s at STABLE → 1.5 s at CRITICAL.
            double targetRingRate = _displayedPsi >= ZoneStable  ? 1.0 / (4.0 * 30.0)
                                  : _displayedPsi >= ZoneCaution ? 1.0 / (3.0 * 30.0)
                                  : _displayedPsi >= ZoneWarning ? 1.0 / (2.2 * 30.0)
                                  : 1.0 / (1.5 * 30.0);
            _ringRate  = _ringRate + (targetRingRate - _ringRate) * 0.01;
            _ringPhase = (_ringPhase + _ringRate) % 1.0;

            const double ActiveFraction = 0.38;    // 38% of cycle = ring visible
            const double RingStartR     = 8.0;     // ring emits from the PSI number area
            const double RingEndR       = GaugeR + 30.0; // expands well past the arc edge
            if (_ringPhase < ActiveFraction)
            {
                double t = _ringPhase / ActiveFraction;          // 0 → 1 within active phase
                double r = RingStartR + t * (RingEndR - RingStartR);
                _pulseRing.Width   = 2.0 * r;
                _pulseRing.Height  = 2.0 * r;
                Canvas.SetLeft(_pulseRing, GaugeCx - r);
                Canvas.SetTop (_pulseRing, GaugeCy - r);
                _pulseRing.Opacity = (1.0 - t) * 0.70;          // 0.70 → 0  (blur eats some opacity)
            }
            else
            {
                _pulseRing.Opacity = 0.0;
            }

            // ── Timeline heartbeat (B) ────────────────────────────────────────
            // Periodically redraw so the time axis and "now" line advance even
            // when PSI hasn't changed (right edge = now, always).
            if (_expanded)
            {
                _heartbeatCounter++;
                if (_heartbeatCounter >= HeartbeatInterval)
                {
                    _heartbeatCounter = 0;
                    RedrawTimeline();
                }
            }

            // Lerp D-score bars toward their targets (τ ≈ 6 frames ≈ 200ms).
            // Targets are now in PSI-point units (0–100); threshold scaled accordingly.
            bool anyBarChanged = false;
            for (int i = 0; i < 7; i++)
            {
                double bd = _dBarTargets[i] - _curD[i];
                if (Math.Abs(bd) < 0.2)
                    _curD[i] = _dBarTargets[i];
                else
                {
                    _curD[i] += bd * 0.15;
                    anyBarChanged = true;
                }
            }
            if (anyBarChanged || _pulseIntensity > 0.0)
                RedrawDScoreBars();

            ApplyDisplay(_displayedPsi);
        }

        private void ApplyDisplay(double psi)
        {
            Color  c = PsiColor(psi);
            string status;
            Color  statusColor;
            if (_overExposed)
            {
                status      = "OVERSIZE";
                statusColor = ColOversize;
            }
            else
            {
                status      = psi >= ZoneStable  ? "STABLE"
                            : psi >= ZoneCaution ? "CAUTION"
                            : psi >= ZoneWarning ? "WARNING"
                            : "CRITICAL";
                statusColor = c;
            }

            // PSI number permanently hidden — status label + arc colour convey zone.
            _valueLabel.Visibility = Visibility.Collapsed;
            _textStack.Margin      = new Thickness(0, 0, 0, 0);

            _valueFgBrush.Color   = c;
            _statusLabel.Content  = status;
            _statusFgBrush.Color  = statusColor;
            _progressStroke.Color = c;   // keep in sync for SetProgressArc shim
            _arcTipGlow.Color     = c;   // dot halo tracks arc color
            _pulseRingBrush.Color = c;   // ring tracks arc color

            // Dynamic glow: intensity scales with PSI severity + violation pulse.
            double baseBlur, baseOpacity;
            if      (psi >= ZoneStable)  { baseBlur = 10; baseOpacity = 0.60; }
            else if (psi >= ZoneCaution) { baseBlur = 14; baseOpacity = 0.75; }
            else if (psi >= ZoneWarning) { baseBlur = 20; baseOpacity = 0.90; }
            else                         { baseBlur = 26; baseOpacity = 1.00; }

            _progressGlow.BlurRadius = baseBlur   + _pulseIntensity * 14.0;
            _progressGlow.Opacity    = Math.Min(1.0, baseOpacity + _pulseIntensity * 0.25);
            _statusGlow.Color        = c;
            _statusGlow.BlurRadius   = baseBlur * 0.55;
            _statusGlow.Opacity      = Math.Min(1.0, baseOpacity + _pulseIntensity * 0.15);

            UpdateGradArc(psi, c);
        }

        private void ApplyPausedDisplay()
        {
            _valueLabel.Content    = "\u2014";
            _valueFgBrush.Color    = ColPaused;
            _statusLabel.Content   = "PAUSED";
            _statusFgBrush.Color   = ColPaused;
            _progressStroke.Color  = ColPaused;
            _progressGlow.Color    = ColPaused;
            UpdateGradArc(100, ColPaused);
        }

        // ── Colour helpers ───────────────────────────────────────────────────

        private static Color PsiColor(double psi)
        {
            // 4-zone gradient matching the label thresholds above.
            // Each zone blends smoothly into the next.
            if (psi >= ZoneStable)  return LerpColor(ColCaution,  ColStable,  (psi - ZoneStable)  / (100.0 - ZoneStable));
            if (psi >= ZoneCaution) return LerpColor(ColWarning,  ColCaution, (psi - ZoneCaution) / (ZoneStable  - ZoneCaution));
            if (psi >= ZoneWarning) return LerpColor(ColCritical, ColWarning, (psi - ZoneWarning) / (ZoneCaution - ZoneWarning));
            return ColCritical;
        }

        private static Color LerpColor(Color a, Color b, double t)
        {
            t = t < 0 ? 0 : t > 1 ? 1 : t;
            return Color.FromRgb(
                (byte)(a.R + (b.R - a.R) * t),
                (byte)(a.G + (b.G - a.G) * t),
                (byte)(a.B + (b.B - a.B) * t));
        }

        // DScoreColor(score) has been removed.  The D-bar brushes now use
        // PsiColor(100 - debt) so that bar color and PSI gauge color share
        // a single, consistent colour function.  No independent colour scale.

        // ── Factory helpers ──────────────────────────────────────────────────

        private static Label MakeHdrBtn(string text, string tip)
        {
            var lbl = new Label
            {
                Content                    = text,
                FontSize                   = 12,
                Width                      = 24,
                Foreground                 = new SolidColorBrush(Color.FromRgb(142, 142, 147)),
                HorizontalContentAlignment = HorizontalAlignment.Center,
                VerticalContentAlignment   = VerticalAlignment.Center,
                Padding                    = new Thickness(0),
                Cursor                     = Cursors.Hand,
                ToolTip                    = tip,
            };
            lbl.MouseEnter += (_, __) => lbl.Foreground = new SolidColorBrush(Color.FromRgb(188, 188, 192));
            lbl.MouseLeave += (_, __) => lbl.Foreground = new SolidColorBrush(Color.FromRgb(142, 142, 147));
            return lbl;
        }

        private static Label MakeStatValue(string initial)
        {
            return new Label
            {
                Content                    = initial,
                FontSize                   = 10,
                FontFamily                 = new FontFamily("Segoe UI"),
                FontWeight                 = FontWeights.SemiBold,
                Foreground                 = FgBright,
                Padding                    = new Thickness(0, 1, 0, 1),
                HorizontalContentAlignment = HorizontalAlignment.Right,
            };
        }
    }

    // =========================================================================
    // Alert toast  —  small transient popup, auto-dismisses after 7 seconds
    // =========================================================================

    internal sealed class AlertToastWindow : Window
    {
        // ── Win32: prevent this window from stealing focus ────────────────────
        // WS_EX_NOACTIVATE ensures the toast never becomes the active window,
        // so SuperDOM hotkeys keep working even when an alert fires.
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int GetWindowLong(IntPtr hwnd, int nIndex);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern int SetWindowLong(IntPtr hwnd, int nIndex, int dwNewLong);

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);
            var hwnd = new System.Windows.Interop.WindowInteropHelper(this).Handle;
            // Add WS_EX_NOACTIVATE (0x08000000) so Windows never activates this window.
            SetWindowLong(hwnd, -20 /*GWL_EXSTYLE*/,
                GetWindowLong(hwnd, -20) | 0x08000000);
            // Also intercept WM_MOUSEACTIVATE so clicking the toast doesn't activate it.
            System.Windows.Interop.HwndSource.FromHwnd(hwnd)?.AddHook(NoActivateHook);
        }

        private static IntPtr NoActivateHook(IntPtr hwnd, int msg, IntPtr wParam,
                                              IntPtr lParam, ref bool handled)
        {
            if (msg == 0x0021 /*WM_MOUSEACTIVATE*/)
            {
                handled = true;
                return new IntPtr(3 /*MA_NOACTIVATE*/);
            }
            return IntPtr.Zero;
        }

        private readonly DispatcherTimer _timer;

        public AlertToastWindow(string message, bool isCritical,
                                string title = null, int holdSeconds = 7)
        {
            WindowStyle        = WindowStyle.None;
            AllowsTransparency = true;
            Background         = Brushes.Transparent;
            Topmost            = true;
            ShowInTaskbar      = false;
            ShowActivated      = false;   // never steal focus from SuperDOM / hotkeys
            ResizeMode         = ResizeMode.NoResize;
            Width              = 270;
            Height             = 72;

            // Position: top-right corner, above HUD (which sits at WorkArea.Top + 20)
            Left = SystemParameters.WorkArea.Right - Width - 20;
            Top  = SystemParameters.WorkArea.Top   + 20;

            Color accent = isCritical
                ? Color.FromRgb(255, 69, 58)
                : Color.FromRgb(255, 214, 0);

            var card = new Border
            {
                CornerRadius    = new CornerRadius(10),
                Background      = new SolidColorBrush(Color.FromArgb(245, 28, 28, 30)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(160, accent.R, accent.G, accent.B)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(26) });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // ── Coloured header strip ──────────────────────────────────────────
            var hdr     = new Border { Background = new SolidColorBrush(Color.FromArgb(200, accent.R, accent.G, accent.B)) };
            var hdrRow  = new Grid();
            hdrRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            hdrRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var titleLbl = new Label
            {
                Content                  = title ?? (isCritical ? "⚠  PSI CRITICAL" : "⚡  PSI CAUTION"),
                FontSize                 = 10,
                FontFamily               = new FontFamily("Segoe UI"),
                FontWeight               = FontWeights.SemiBold,
                Foreground               = Brushes.White,
                VerticalContentAlignment = VerticalAlignment.Center,
                Padding                  = new Thickness(10, 0, 0, 0),
            };
            var clsBtn = new Label
            {
                Content                    = "✕",
                FontSize                   = 10,
                Width                      = 26,
                Foreground                 = new SolidColorBrush(Color.FromArgb(180, 255, 255, 255)),
                HorizontalContentAlignment = HorizontalAlignment.Center,
                VerticalContentAlignment   = VerticalAlignment.Center,
                Padding                    = new Thickness(0),
                Cursor                     = Cursors.Hand,
            };
            clsBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; Close(); };
            clsBtn.MouseEnter += (_, __) => clsBtn.Foreground = Brushes.White;
            clsBtn.MouseLeave += (_, __) => clsBtn.Foreground = new SolidColorBrush(Color.FromArgb(180, 255, 255, 255));

            Grid.SetColumn(titleLbl, 0); hdrRow.Children.Add(titleLbl);
            Grid.SetColumn(clsBtn,   1); hdrRow.Children.Add(clsBtn);
            hdr.Child = hdrRow;

            hdrRow.MouseLeftButtonDown += (_, e) => { if (!e.Handled) DragMove(); };
            Grid.SetRow(hdr, 0); root.Children.Add(hdr);

            // ── Message body ───────────────────────────────────────────────────
            var body = new Label
            {
                Content                  = message,
                FontSize                 = 11,
                FontFamily               = new FontFamily("Segoe UI"),
                Foreground               = new SolidColorBrush(Color.FromRgb(245, 245, 247)),
                VerticalContentAlignment = VerticalAlignment.Center,
                Padding                  = new Thickness(12, 0, 12, 0),
            };
            Grid.SetRow(body, 1); root.Children.Add(body);

            card.Child = root;
            Content    = card;

            // Auto-dismiss — duration is caller-configurable (user-set Guard toasts stay longer)
            _timer          = new DispatcherTimer { Interval = TimeSpan.FromSeconds(holdSeconds) };
            _timer.Tick    += (_, __) => { _timer.Stop(); Close(); };
            _timer.Start();
            Closed         += (_, __) => _timer.Stop();
        }
    }
}
