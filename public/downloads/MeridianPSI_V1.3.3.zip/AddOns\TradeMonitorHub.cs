﻿// TradeMonitorHub.cs
//
// Unified dashboard window that consolidates Session Report, History,
// Trading Profile, and Settings into a single tabbed interface with
// a sidebar navigation panel.
//
// Content for each page is produced by the existing standalone Window
// classes (SessionReportWindow, HistoryWindow, BaselineWindow) via a
// "content transplant" pattern: the window is instantiated but never
// shown, its body content is extracted and placed into the Hub's
// content area.  This eliminates code duplication while keeping
// all existing visual and behavioral code intact.

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal enum HubPage { Session, History, Profile, Settings, License, Guard, Intelligence, Journal }

    internal sealed class MeridianDashboard : Window
    {
        // ── Window layout persistence ──────────────────────────────────────────
        // Saves/restores Left, Top, Width, Height across NT8 restarts.
        // Stored as a tiny XML file in TradeMonitorData/ (same data directory
        // as other add-on files; injected via SetDataDir at startup).

        private static string _hubDataDir;
        internal static void SetDataDir(string path)
        {
            if (!string.IsNullOrEmpty(path)) _hubDataDir = path;
        }

        private static string LayoutFilePath =>
            System.IO.Path.Combine(_hubDataDir ?? "", "layout.xml");

        private static bool TryLoadLayout(out double left, out double top,
                                          out double width, out double height)
        {
            left = top = width = height = double.NaN;
            try
            {
                if (string.IsNullOrEmpty(_hubDataDir) || !File.Exists(LayoutFilePath))
                    return false;

                var text = File.ReadAllText(LayoutFilePath);
                // Parse minimal XML: <Layout Left="…" Top="…" Width="…" Height="…" />
                left   = ParseAttr(text, "Left");
                top    = ParseAttr(text, "Top");
                width  = ParseAttr(text, "Width");
                height = ParseAttr(text, "Height");

                // Sanity-check: must be on-screen and a reasonable size.
                var area = SystemParameters.VirtualScreenWidth;
                if (double.IsNaN(left) || double.IsNaN(top) ||
                    double.IsNaN(width) || double.IsNaN(height)) return false;
                if (width < 400 || height < 380) return false;
                if (left < -200 || top < -200) return false;
                if (left > SystemParameters.VirtualScreenWidth  - 100) return false;
                if (top  > SystemParameters.VirtualScreenHeight - 60)  return false;
                return true;
            }
            catch { return false; }
        }

        private static double ParseAttr(string xml, string attr)
        {
            string marker = attr + "=\"";
            int start = xml.IndexOf(marker, StringComparison.Ordinal);
            if (start < 0) return double.NaN;
            start += marker.Length;
            int end = xml.IndexOf('"', start);
            if (end < 0) return double.NaN;
            double v;
            return double.TryParse(xml.Substring(start, end - start),
                System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture, out v) ? v : double.NaN;
        }

        private static void SaveLayout(double left, double top, double width, double height)
        {
            try
            {
                if (string.IsNullOrEmpty(_hubDataDir)) return;
                Directory.CreateDirectory(_hubDataDir);
                var ic = System.Globalization.CultureInfo.InvariantCulture;
                string xml = string.Format(ic,
                    "<Layout Left=\"{0:F1}\" Top=\"{1:F1}\" Width=\"{2:F1}\" Height=\"{3:F1}\" />",
                    left, top, width, height);
                File.WriteAllText(LayoutFilePath, xml);
            }
            catch { }
        }

        // ── Events ───────────────────────────────────────────────────────────
        public event Action        BaselineResetRequested;
        public event Action        HistoryClearRequested;
        public event Action        SettingsRequested;

        // ── Data references (shared with TradeMonitor) ───────────────────────
        private TradeBaseline       _baseline;
        private StrategyProfile     _profile;
        private SessionHistoryStore _historyStore;
        private SessionData         _sessionData;
        private List<string>        _availableAccounts;
        private Func<List<string>>  _accountsProvider;
        private Action<string>      _onError;
        private LicenseManager      _licenseManager;
        private string              _updateVersion;
        private string              _updateNotes;
        private GuardEngine         _guardEngine;
        private MeridianPSI         _monitor;   // for Emergency Override callback

        // ── Page state ───────────────────────────────────────────────────────
        private HubPage  _currentPage = HubPage.Session;
        private readonly Grid       _contentArea;
        private readonly Border[]    _navBorders = new Border[8];
        private readonly TextBlock[] _navLabels  = new TextBlock[8];
        private readonly TextBlock[] _navIcons   = new TextBlock[8];

        /// <summary>
        /// True when the current license grants access to Guard-tier features
        /// (PSI Intelligence and Guard Rules).
        ///
        /// FAIL-CLOSED: when _licenseManager is null (only possible in tests /
        /// dev harnesses), Guard-tier features are LOCKED.  Production never
        /// passes a null license manager.  See LicenseManager.HasGuard for the
        /// authoritative tier-resolution logic, including the Plan C 7-day
        /// Core→Guard sampling window for new subscribers.
        /// </summary>
        private bool HasGuardAccess => _licenseManager?.HasGuard ?? false;

        // Keep reference to BaselineWindow for ResetRequested event
        private BaselineWindow _embeddedBaselineWindow;

        // ── Palette ──────────────────────────────────────────────────────────
        private static readonly Brush BgWindow     = new SolidColorBrush(Color.FromRgb( 28,  28,  30));
        private static readonly Brush BgSidebar    = new SolidColorBrush(Color.FromRgb( 22,  22,  24));
        private static readonly Brush BgHeader     = new SolidColorBrush(Color.FromRgb( 44,  44,  46));
        private static readonly Brush BgNavActive  = new SolidColorBrush(Color.FromArgb( 30, 255, 255, 255));
        private static readonly Brush BgNavHover   = new SolidColorBrush(Color.FromArgb( 18, 255, 255, 255));
        private static readonly Brush FgPrimary    = new SolidColorBrush(Color.FromRgb(245, 245, 247));
        private static readonly Brush FgSecondary  = new SolidColorBrush(Color.FromRgb(174, 174, 178));
        private static readonly Brush FgHint       = new SolidColorBrush(Color.FromRgb( 99,  99, 102));
        private static readonly Brush FgAccent     = new SolidColorBrush(Color.FromRgb( 10, 132, 255));
        private static readonly Brush BgCard       = new SolidColorBrush(Color.FromRgb( 38,  38,  40));

        // Freeze all static brushes so they can be used from any thread.
        // NT8 may call State.Active (which accesses TradeMonitorHub.SetDataDir) on a
        // worker thread, triggering the static initializer there.  Unfrozen WPF
        // Freezables created on a worker thread cannot be used on the UI thread.
        static MeridianDashboard()
        {
            ((SolidColorBrush)BgWindow  ).Freeze();
            ((SolidColorBrush)BgSidebar ).Freeze();
            ((SolidColorBrush)BgHeader  ).Freeze();
            ((SolidColorBrush)BgNavActive).Freeze();
            ((SolidColorBrush)BgNavHover).Freeze();
            ((SolidColorBrush)FgPrimary ).Freeze();
            ((SolidColorBrush)FgSecondary).Freeze();
            ((SolidColorBrush)FgHint    ).Freeze();
            ((SolidColorBrush)FgAccent  ).Freeze();
            ((SolidColorBrush)BgCard    ).Freeze();
        }

        // Nav item labels and icons (Unicode glyphs)
        private static readonly string[] NavIcons  = { "\u2261", "\u2637", "\u2616", "\u2699", "\u26BF", "\u26E8", "\u25C6", "\u270E" };
        private static readonly string[] NavLabels = { "Session", "History", "Profile", "Settings", "License", "Guard", "Intel", "Journal" };

        // =====================================================================
        // Constructor
        // =====================================================================

        public MeridianDashboard(TradeBaseline baseline,
                               StrategyProfile profile,
                               SessionHistoryStore historyStore,
                               SessionData sessionData,
                               List<string> availableAccounts,
                               Action<string> onError,
                               LicenseManager licenseManager = null,
                               string updateVersion = null,
                               string updateNotes   = null,
                               GuardEngine guardEngine = null,
                               MeridianPSI monitor = null,
                               Func<List<string>> accountsProvider = null)
        {
            _baseline          = baseline      ?? new TradeBaseline();
            _profile           = profile       ?? new StrategyProfile();
            _historyStore      = historyStore  ?? new SessionHistoryStore();
            _sessionData       = sessionData;
            _availableAccounts = availableAccounts ?? new List<string>();
            _accountsProvider  = accountsProvider;
            _onError           = onError;
            _licenseManager    = licenseManager;
            _updateVersion     = updateVersion;
            _updateNotes       = updateNotes;
            _guardEngine       = guardEngine;
            _monitor           = monitor;

            WindowStyle        = WindowStyle.None;
            AllowsTransparency = true;
            Background         = Brushes.Transparent;
            ResizeMode         = ResizeMode.CanResizeWithGrip;
            ShowInTaskbar      = true;
            Title              = "Meridian Dashboard";
            Width    = 640;
            Height   = 720;
            MinWidth = 500;
            MinHeight= 480;

            // Restore last position/size if available; otherwise centre on screen.
            double savedL, savedT, savedW, savedH;
            if (TryLoadLayout(out savedL, out savedT, out savedW, out savedH))
            {
                Left   = savedL;
                Top    = savedT;
                Width  = savedW;
                Height = savedH;
            }
            else
            {
                Left = (SystemParameters.WorkArea.Width  - Width)  / 2;
                Top  = (SystemParameters.WorkArea.Height - Height) / 2;
            }

            // ── Outer card ─────────────────────────────────────────────────────
            var card = new Border
            {
                CornerRadius    = new CornerRadius(14),
                Background      = BgWindow,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };

            var rootGrid = new Grid();
            rootGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(44) });
            rootGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // ── Header ─────────────────────────────────────────────────────────
            var header = BuildHeader();
            Grid.SetRow(header, 0);
            rootGrid.Children.Add(header);

            // ── Body: sidebar + content ────────────────────────────────────────
            var bodyGrid = new Grid();
            bodyGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(140) });
            bodyGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1) });
            bodyGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Sidebar
            var sidebar = BuildSidebar();
            Grid.SetColumn(sidebar, 0);
            bodyGrid.Children.Add(sidebar);

            // Separator line
            var sep = new Border
            {
                Width      = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
            };
            Grid.SetColumn(sep, 1);
            bodyGrid.Children.Add(sep);

            // Content area
            _contentArea = new Grid { Background = Brushes.Transparent };
            Grid.SetColumn(_contentArea, 2);
            bodyGrid.Children.Add(_contentArea);

            Grid.SetRow(bodyGrid, 1);
            rootGrid.Children.Add(bodyGrid);

            card.Child = rootGrid;
            Content    = card;

            // ── Show initial page ──────────────────────────────────────────────
            Closed += OnHubWindowClosed;

            // Open to Session page always; NavigateTo handles the license gate
            // (non-activated users see the Activate gate page on Session).
            NavigateTo(HubPage.Session);
        }

        private void OnHubWindowClosed(object sender, EventArgs e)
        {
            // Persist window geometry for next session.
            SaveLayout(Left, Top, Width, Height);
            TeardownEmbeddedBaseline();
            _contentArea?.Children.Clear();
        }

        /// <summary>
        /// Unhook embedded page objects so they are not leaked after the visual tree
        /// is torn down.  BaselineWindow subscribes to <see cref="BaselineResetRequested"/>.
        /// </summary>
        private void TeardownEmbeddedBaseline()
        {
            if (_embeddedBaselineWindow == null) return;
            _embeddedBaselineWindow.ResetRequested -= OnEmbeddedBaselineReset;
            _embeddedBaselineWindow = null;
        }

        // =====================================================================
        // Header
        // =====================================================================

        private Border BuildHeader()
        {
            var bg = new Border { Background = BgHeader };
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var title = new TextBlock
            {
                Text              = "MeridianPSI",
                FontSize          = 12,
                FontWeight        = FontWeights.SemiBold,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(16, 0, 0, 0),
            };
            Grid.SetColumn(title, 0);
            grid.Children.Add(title);

            var closeBtn = MakeHeaderBtn("\u2715", "Close dashboard");
            closeBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; Close(); };
            Grid.SetColumn(closeBtn, 1);
            grid.Children.Add(closeBtn);

            bg.Child = grid;

            bg.MouseLeftButtonDown += (_, e) =>
            {
                if (!e.Handled && e.ButtonState == MouseButtonState.Pressed)
                    DragMove();
            };

            return bg;
        }

        private static Border MakeHeaderBtn(string glyph, string tooltip)
        {
            var lbl = new TextBlock
            {
                Text                = glyph,
                FontSize            = 14,
                Foreground          = FgSecondary,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Width     = 40,
                Height    = 40,
                Background = Brushes.Transparent,
                Cursor    = Cursors.Hand,
                Child     = lbl,
                ToolTip   = tooltip,
                VerticalAlignment = VerticalAlignment.Center,
            };
            btn.MouseEnter += (_, __) => btn.Background = BgNavHover;
            btn.MouseLeave += (_, __) => btn.Background = Brushes.Transparent;
            return btn;
        }

        // =====================================================================
        // Sidebar
        // =====================================================================

        private Border BuildSidebar()
        {
            var bg    = new Border { Background = BgSidebar };
            var stack = new StackPanel { Margin = new Thickness(0, 6, 0, 0) };

            // Group 1 — daily trading use
            AddNavGroup(stack, "TRADING",         new[] { 0, 5, 7 }, isFirst: true);
            // Group 2 — review, analytics, configuration
            AddNavGroup(stack, "REVIEW & CONFIG", new[] { 1, 6, 2, 3, 4 }, isFirst: false);

            bg.Child = stack;
            return bg;
        }

        // Builds a labelled group of nav items inside the sidebar.
        // pageIndices contains HubPage int values in desired display order.
        private void AddNavGroup(StackPanel stack, string groupLabel, int[] pageIndices, bool isFirst)
        {
            if (!isFirst)
            {
                stack.Children.Add(new Border
                {
                    Height     = 1,
                    Background = new SolidColorBrush(Color.FromArgb(25, 255, 255, 255)),
                    Margin     = new Thickness(12, 8, 12, 0),
                });
            }

            stack.Children.Add(new TextBlock
            {
                Text       = groupLabel,
                FontSize   = 8,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.Bold,
                Foreground = FgHint,
                Margin     = new Thickness(16, isFirst ? 6 : 10, 0, 2),
            });

            foreach (int i in pageIndices)
            {
                int idx = i;
                var navItem = BuildNavItem(NavIcons[i], NavLabels[i], (HubPage)i,
                                           out var border, out var icon, out var lbl);
                _navBorders[i] = border;
                _navIcons[i]   = icon;
                _navLabels[i]  = lbl;

                bool isGated = !(_licenseManager?.IsFunctional ?? true) && (HubPage)i != HubPage.License
                    || ((i == 5 || i == 6) && !HasGuardAccess);
                if (isGated)
                {
                    var badge = new Border
                    {
                        Background    = (i == 5 || i == 6) && !HasGuardAccess
                            ? new SolidColorBrush(Color.FromArgb(180, 255, 149, 0))   // amber GUARD badge
                            : new SolidColorBrush(Color.FromArgb(160, 120, 120, 120)), // grey LOCK badge
                        CornerRadius  = new CornerRadius(3),
                        Padding       = new Thickness(3, 1, 3, 1),
                        Margin        = new Thickness(4, 0, 0, 0),
                        VerticalAlignment = VerticalAlignment.Center,
                        Child         = new TextBlock
                        {
                            Text       = (i == 5 || i == 6) && !HasGuardAccess ? "GUARD" : "🔒",
                            FontSize   = 7,
                            FontFamily = new System.Windows.Media.FontFamily("Segoe UI"),
                            FontWeight = FontWeights.Bold,
                            Foreground = new SolidColorBrush(Color.FromRgb(28, 28, 30)),
                        },
                    };
                    var row = (StackPanel)((Border)navItem).Child;
                    row.Children.Add(badge);
                }

                navItem.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    NavigateTo((HubPage)idx);
                };
                stack.Children.Add(navItem);
            }
        }

        private static Border BuildNavItem(string icon, string label, HubPage page,
                                           out Border borderRef, out TextBlock iconRef, out TextBlock labelRef)
        {
            var iconTb = new TextBlock
            {
                Text                = icon,
                FontSize            = 16,
                Foreground          = FgHint,
                VerticalAlignment   = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Width               = 28,
            };

            var labelTb = new TextBlock
            {
                Text              = label,
                FontSize          = 12,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(8, 0, 0, 0),
            };

            var row = new StackPanel
            {
                Orientation       = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(12, 0, 8, 0),
            };
            row.Children.Add(iconTb);
            row.Children.Add(labelTb);

            var border = new Border
            {
                Height          = 40,
                Background      = Brushes.Transparent,
                Cursor          = Cursors.Hand,
                Child           = row,
                Margin          = new Thickness(6, 1, 6, 1),
                CornerRadius    = new CornerRadius(6),
            };
            border.MouseEnter += (_, __) =>
            {
                if (border.Tag as string != "active")
                    border.Background = BgNavHover;
            };
            border.MouseLeave += (_, __) =>
            {
                if (border.Tag as string != "active")
                    border.Background = Brushes.Transparent;
            };

            borderRef = border;
            iconRef   = iconTb;
            labelRef  = labelTb;
            return border;
        }

        private void UpdateNavHighlight(HubPage page)
        {
            int idx = (int)page;
            for (int i = 0; i < 8; i++)
            {
                bool active = i == idx;
                _navBorders[i].Background = active ? BgNavActive : Brushes.Transparent;
                _navBorders[i].Tag        = active ? "active" : null;
                _navIcons[i].Foreground   = active ? FgAccent : FgHint;
                _navLabels[i].Foreground  = active ? FgPrimary : FgSecondary;

                _navLabels[i].FontWeight  = active ? FontWeights.SemiBold : FontWeights.Normal;
            }
        }

        // Removes stale 🔒 lock badges from nav items after activation.
        // Called whenever license status changes to Licensed.
        private void RefreshNavBadges()
        {
            bool licensed = _licenseManager?.IsFunctional ?? true;
            for (int i = 0; i < 8; i++)
            {
                if ((HubPage)i == HubPage.License) continue;
                bool isGuardGated = (i == 5 || i == 6) && !HasGuardAccess;
                if (isGuardGated) continue; // GUARD badge stays

                var row = _navBorders[i]?.Child as StackPanel;
                if (row == null) continue;

                // Remove any grey 🔒 lock badge (Badge has a Border child with TextBlock "🔒").
                if (licensed)
                {
                    for (int j = row.Children.Count - 1; j >= 0; j--)
                    {
                        if (row.Children[j] is Border badge
                            && badge.Child is TextBlock tb
                            && tb.Text == "🔒")
                        {
                            row.Children.RemoveAt(j);
                        }
                    }
                }
            }
        }

        // =====================================================================
        // Navigation
        // =====================================================================

        /// <summary>
        /// Reloads the shared SessionHistoryStore from disk in-place.
        /// Updates Sessions on the existing object so the Hub and TradeMonitor
        /// (which share the same reference) both see the new data immediately.
        /// Must be called on the UI thread.
        /// </summary>
        private void ReloadHistoryStore()
        {
            var fresh = SessionHistoryStore.LoadFromFile(_onError);
            _historyStore.Sessions.Clear();
            _historyStore.Sessions.AddRange(fresh.Sessions);
        }

        public void NavigateTo(HubPage page)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => NavigateTo(page));
                return;
            }

            bool isFunctional = _licenseManager?.IsFunctional ?? true;

            TeardownEmbeddedBaseline();
            _currentPage = page;
            UpdateNavHighlight(page);

            _contentArea.Children.Clear();

            FrameworkElement content;
            switch (page)
            {
                case HubPage.Session:
                    content = isFunctional ? CreateSessionPage() : BuildActivateGatePage();
                    break;
                case HubPage.History:
                    content = isFunctional ? CreateHistoryPage() : BuildActivateGatePage();
                    break;
                case HubPage.Profile:
                    content = isFunctional ? CreateProfilePage() : BuildActivateGatePage();
                    break;
                case HubPage.Settings:
                    content = isFunctional ? CreateSettingsPage() : BuildActivateGatePage();
                    break;
                case HubPage.License:
                    content = CreateLicensePage();
                    break;
                case HubPage.Guard:
                    content = !isFunctional ? BuildActivateGatePage()
                            : HasGuardAccess  ? CreateGuardPage()
                                              : BuildGuardUpgradePage();
                    break;
                case HubPage.Intelligence:
                    content = !isFunctional ? BuildActivateGatePage()
                            : HasGuardAccess  ? CreateIntelligencePage()
                                              : BuildGuardUpgradePage();
                    break;
                case HubPage.Journal:
                    content = isFunctional ? CreateJournalPage() : BuildActivateGatePage();
                    break;
                default:
                    content = new TextBlock { Text = "Unknown page", Foreground = FgPrimary };
                    break;
            }

            _contentArea.Children.Add(content);
        }

        // =====================================================================
        // Public API — called from TradeMonitor
        // =====================================================================

        /// <summary>
        /// Refresh session data and rebuild the Session page if it's visible.
        /// </summary>
        public void UpdateSessionData(SessionData data)
        {
            _sessionData = data;
            if (_currentPage == HubPage.Session)
                NavigateTo(HubPage.Session);
        }

        /// <summary>
        /// Update data references after a baseline reset.
        /// </summary>
        public void UpdateDataRefs(TradeBaseline baseline, StrategyProfile profile)
        {
            _baseline = baseline;
            _profile  = profile;
            if (_currentPage == HubPage.Profile)
                NavigateTo(HubPage.Profile);
        }

        // =====================================================================
        // Page: Session Report
        // =====================================================================

        private FrameworkElement CreateSessionPage()
        {
            if (_sessionData == null || !_sessionData.HasRecordedTrades())
                return BuildSessionEmptyPage();

            try
            {
                // Point-in-time copy: timer + execution threads mutate live SessionData.
                SessionData snap = _sessionData.CreateSnapshot();
                // Commit the current zone's pending time slice into the snapshot so
                // Time-in-State is accurate when the report is opened mid-session.
                snap.Flush(DateTime.Now);
                var source = new SessionReportWindow(snap);
                var body   = TransplantWindowBody(source);

                var dock = new DockPanel { LastChildFill = true };
                var bar  = BuildPageActionBar("⎘  Copy Session Report",
                    () => source.CopySummaryToClipboard(),
                    "Intel →",
                    () => NavigateTo(HubPage.Intelligence));
                DockPanel.SetDock(bar, Dock.Top);
                dock.Children.Add(bar);

                // ── PSI Insight — scrolls WITH the session report body ────────
                // SessionReportWindow's body still contains an inner ScrollViewer.
                // Disabling its scrollbars is not enough: WPF's ScrollViewer still
                // handles PreviewMouseWheel and swallows the bubble, so the outer
                // Hub ScrollViewer only reacted when the cursor was on the scrollbar.
                // Hoist the inner Content (StackPanel) directly into the Grid so one
                // outer ScrollViewer owns all vertical mouse-wheel scrolling.
                if (body is Border bodyCard && bodyCard.Child is Grid bodyGrid)
                {
                    for (int i = 0; i < bodyGrid.Children.Count; i++)
                    {
                        if (bodyGrid.Children[i] is ScrollViewer sv &&
                            sv.Content is UIElement innerContent)
                        {
                            int row = Grid.GetRow(sv);
                            sv.Content = null;
                            bodyGrid.Children.RemoveAt(i);
                            bodyGrid.Children.Add(innerContent);
                            Grid.SetRow(innerContent, row);
                            break;
                        }
                    }
                }

                var outerScroll = new ScrollViewer
                {
                    VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                    HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                };
                var scrollContent = new StackPanel();
                if (_monitor != null)
                    scrollContent.Children.Add(BuildPsiInsightSection(_monitor.GetPsiInsightSnapshot()));
                scrollContent.Children.Add(body);
                outerScroll.Content = scrollContent;

                dock.Children.Add(outerScroll);
                return dock;
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load session report.");
            }
        }

        // =====================================================================
        // BuildPsiInsightSection — v2 engine observability, rendered compactly
        // at the top of the Session page.  All data is passed in; no engine
        // references held.  Layout:
        //
        //   ┌─ PSI INSIGHT ─────────────────────────────────────────────┐
        //   │  PSI 82.4    P 0.34 (peak 0.71)    Class A events: 2      │
        //   │                                                          │
        //   │  Peak severity per dim (cumulative PSI-points cost):     │
        //   │    Revenge 0.0   SL Move 12.3  Size 0.0   Hold 4.1 ...   │
        //   │                                                          │
        //   │  Rule events (newest at bottom):                         │
        //   │    09:31:22  D2·SL Move [A]  E+=3.00  P=0.42             │
        //   │    09:32:05  D6·Rules   [A]  E+=3.50  P=0.55             │
        //   └──────────────────────────────────────────────────────────┘
        // =====================================================================
        private FrameworkElement BuildPsiInsightSection(PsiInsightSnapshot s)
        {
            var card = new Border
            {
                Background    = BgCard,
                CornerRadius  = new CornerRadius(8),
                Margin        = new Thickness(14, 4, 14, 6),
                Padding       = new Thickness(14, 10, 14, 12),
            };
            var stack = new StackPanel();
            card.Child = stack;

            var header = new StackPanel { Orientation = Orientation.Horizontal };
            header.Children.Add(new TextBlock
            {
                Text       = "PSI INSIGHT",
                FontSize   = 10,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.Bold,
                Foreground = FgSecondary,
                Margin     = new Thickness(0, 0, 6, 0),
            });
            stack.Children.Add(header);

            // KPI row — single horizontal panel, three groups.
            var kpiRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 8, 0, 2),
            };
            kpiRow.Children.Add(MakeKpi("PSI",
                string.Format("{0:F1}", s.CurrentPsi), FgPrimary,
                "Psychological Stability Index (0–100)."));
            kpiRow.Children.Add(MakeKpi("Pressure",
                string.Format("{0:F2}", s.CurrentPressure),
                PressureBrush(s.CurrentPressure),
                "Stress context (0–1). Amplifies behaviour evidence and slows PSI recovery while high."));
            kpiRow.Children.Add(MakeKpi("Peak P",
                string.Format("{0:F2}", s.PeakPressure),
                PressureBrush(s.PeakPressure),
                "Highest Pressure reached this session (0–1)."));
            kpiRow.Children.Add(MakeKpi("Class A",
                s.ClassACommitCount.ToString(),
                s.ClassACommitCount > 0
                    ? (Brush)new SolidColorBrush(Color.FromRgb(255, 69, 58))
                    : FgPrimary,
                "Count of hard rule breaks you declared (Class A commits) this session."));
            stack.Children.Add(kpiRow);

            // Peak severity per dim — a compact grid of dim name + peak C_i.
            stack.Children.Add(new TextBlock
            {
                Text       = "Highest stress per rule (this session, PSI points):",
                FontSize   = 10,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgSecondary,
                Margin     = new Thickness(0, 10, 0, 2),
            });
            stack.Children.Add(new TextBlock
            {
                Text       = "Higher = that rule cost you more composure this session.",
                FontSize   = 9,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgHint,
                Margin     = new Thickness(0, 0, 0, 4),
                TextWrapping = TextWrapping.Wrap,
            });
            var sevGrid = new Grid();
            for (int c = 0; c < 7; c++)
                sevGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            string[] dimNames = PsiOverlayWindow.DimNamesStatic;
            for (int di = 0; di < 7; di++)
            {
                double peak = (s.PeakSeverityPerDim != null && s.PeakSeverityPerDim.Length > di + 1)
                    ? s.PeakSeverityPerDim[di + 1] : 0.0;
                CommitClass cls = (s.DimLastClass != null && s.DimLastClass.Length > di + 1)
                    ? s.DimLastClass[di + 1] : CommitClass.None;
                var cell = new StackPanel { Margin = new Thickness(2, 0, 2, 0) };
                cell.Children.Add(new TextBlock
                {
                    Text                = dimNames[di],
                    FontSize            = 9,
                    FontFamily          = new FontFamily("Segoe UI"),
                    Foreground          = DimNameBrush(cls),
                    HorizontalAlignment = HorizontalAlignment.Center,
                });
                cell.Children.Add(new TextBlock
                {
                    Text                = string.Format("{0:F1}", peak),
                    FontSize            = 12,
                    FontFamily          = new FontFamily("Segoe UI"),
                    FontWeight          = FontWeights.SemiBold,
                    Foreground          = peak >= 20.0
                                            ? new SolidColorBrush(Color.FromRgb(255, 149, 0))
                                            : FgPrimary,
                    HorizontalAlignment = HorizontalAlignment.Center,
                });
                Grid.SetColumn(cell, di);
                sevGrid.Children.Add(cell);
            }
            stack.Children.Add(sevGrid);

            // Recent commit log — last N events.
            stack.Children.Add(new TextBlock
            {
                Text       = s.RecentCommits != null && s.RecentCommits.Length > 0
                                ? string.Format("Rule events ({0}) — newest at bottom:", s.RecentCommits.Length)
                                : "No rule events logged this session yet.",
                FontSize   = 10,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgSecondary,
                Margin     = new Thickness(0, 10, 0, 2),
            });
            stack.Children.Add(new TextBlock
            {
                Text       = "[A] = hard rule break · [B] = behaviour pattern · E+ = evidence added · P = Pressure (0–1)",
                FontSize   = 9,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgHint,
                Margin     = new Thickness(0, 0, 0, 4),
                TextWrapping = TextWrapping.Wrap,
            });

            if (s.RecentCommits != null && s.RecentCommits.Length > 0)
            {
                var logBox = new Border
                {
                    Background   = new SolidColorBrush(Color.FromRgb(28, 28, 30)),
                    CornerRadius = new CornerRadius(4),
                    Padding      = new Thickness(8, 6, 8, 6),
                    MaxHeight    = 140,
                };
                var scroll = new ScrollViewer
                {
                    VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                };
                var logStack = new StackPanel();
                scroll.Content = logStack;
                logBox.Child   = scroll;

                int show = Math.Min(s.RecentCommits.Length, 20);
                int from = s.RecentCommits.Length - show;
                for (int i = from; i < s.RecentCommits.Length; i++)
                {
                    var ev = s.RecentCommits[i];
                    string dimName = (ev.Dim - 1 >= 0 && ev.Dim - 1 < dimNames.Length)
                        ? dimNames[ev.Dim - 1] : ("D" + ev.Dim);
                    string kindStr = ev.Kind == CommitClass.A ? "A" : "B";
                    Brush  kindBr  = ev.Kind == CommitClass.A
                                        ? (Brush)new SolidColorBrush(Color.FromRgb(255,  69,  58))
                                        : (Brush)new SolidColorBrush(Color.FromRgb(255, 149,   0));
                    var line = new TextBlock
                    {
                        FontSize   = 11,
                        FontFamily = new FontFamily("Consolas"),
                        Foreground = FgPrimary,
                    };
                    line.Inlines.Add(new System.Windows.Documents.Run(
                        string.Format("{0:HH:mm:ss}  ", ev.Time)) { Foreground = FgHint });
                    line.Inlines.Add(new System.Windows.Documents.Run(
                        string.Format("D{0}·{1,-9} ", ev.Dim, dimName)));
                    line.Inlines.Add(new System.Windows.Documents.Run("[" + kindStr + "]")
                        { Foreground = kindBr, FontWeight = FontWeights.Bold });
                    line.Inlines.Add(new System.Windows.Documents.Run(
                        string.Format("  E+={0:F2}  P={1:F2}", ev.Amount, ev.Pressure)));
                    logStack.Children.Add(line);
                }
                stack.Children.Add(logBox);
            }
            return card;
        }

        private static Brush PressureBrush(double p)
        {
            if (p <= 0.30) return new SolidColorBrush(Color.FromRgb( 48, 209,  88));
            if (p <= 0.70) return new SolidColorBrush(Color.FromRgb(255, 214,  10));
            return               new SolidColorBrush(Color.FromRgb(255,  69,  58));
        }

        private static Brush DimNameBrush(CommitClass cls)
        {
            switch (cls)
            {
                case CommitClass.A: return new SolidColorBrush(Color.FromRgb(255,  69,  58));
                case CommitClass.B: return new SolidColorBrush(Color.FromRgb(255, 149,   0));
                default:            return new SolidColorBrush(Color.FromRgb(136, 136, 136));
            }
        }

        private FrameworkElement MakeKpi(string label, string value, Brush valueBrush, string toolTip = null)
        {
            var panel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin      = new Thickness(0, 0, 22, 0),
            };
            if (!string.IsNullOrEmpty(toolTip))
                panel.ToolTip = toolTip;
            panel.Children.Add(new TextBlock
            {
                Text       = label.ToUpperInvariant(),
                FontSize   = 9,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgHint,
            });
            panel.Children.Add(new TextBlock
            {
                Text       = value,
                FontSize   = 18,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = valueBrush,
            });
            return panel;
        }

        // =====================================================================
        // Guard Upgrade page — shown when a Core-tier user clicks a Guard feature
        // =====================================================================

        private FrameworkElement BuildGuardUpgradePage()
        {
            var outer = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(28, 28, 30)),
            };

            var center = new StackPanel
            {
                Orientation         = Orientation.Vertical,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
                MaxWidth            = 340,
                Margin              = new Thickness(32),
            };

            // Lock icon
            center.Children.Add(new TextBlock
            {
                Text                = "🔒",
                FontSize            = 40,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 16),
            });

            // Headline
            center.Children.Add(new TextBlock
            {
                Text                = "Guard Tier Required",
                FontSize            = 18,
                FontFamily          = new System.Windows.Media.FontFamily("Segoe UI"),
                FontWeight          = FontWeights.Bold,
                Foreground          = new SolidColorBrush(Color.FromRgb(245, 245, 247)),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 8),
            });

            // Sub-headline
            center.Children.Add(new TextBlock
            {
                Text         = "Upgrade to Guard to unlock these features:",
                FontSize     = 12,
                FontFamily   = new System.Windows.Media.FontFamily("Segoe UI"),
                Foreground   = new SolidColorBrush(Color.FromRgb(174, 174, 178)),
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                Margin       = new Thickness(0, 0, 0, 20),
            });

            // Feature list
            string[] features =
            {
                "🧠  Intel Layer — monthly digest, weekday patterns,\n      crash-trigger analysis & Composure progress",
                "🛡  Guard System — rules that enforce themselves\n      (6 triggers · 5 action levels)",
            };
            foreach (var f in features)
            {
                center.Children.Add(new TextBlock
                {
                    Text         = f,
                    FontSize     = 11,
                    FontFamily   = new System.Windows.Media.FontFamily("Segoe UI"),
                    Foreground   = new SolidColorBrush(Color.FromRgb(220, 220, 224)),
                    TextWrapping = TextWrapping.Wrap,
                    Margin       = new Thickness(0, 0, 0, 10),
                });
            }

            // Divider
            center.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                Margin     = new Thickness(0, 12, 0, 16),
            });

            // Price line
            center.Children.Add(new TextBlock
            {
                Text                = "$69.99 / month",
                FontSize            = 22,
                FontFamily          = new System.Windows.Media.FontFamily("Segoe UI"),
                FontWeight          = FontWeights.Bold,
                Foreground          = new SolidColorBrush(Color.FromRgb(48, 209, 88)),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 4),
            });
            center.Children.Add(new TextBlock
            {
                Text                = "Cancel any time · Instant activation",
                FontSize            = 10,
                FontFamily          = new System.Windows.Media.FontFamily("Segoe UI"),
                Foreground          = new SolidColorBrush(Color.FromRgb(99, 99, 102)),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 20),
            });

            // Upgrade button
            var upgradeBtn = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(10, 132, 255)),
                CornerRadius    = new CornerRadius(8),
                Padding         = new Thickness(28, 12, 28, 12),
                Cursor          = Cursors.Hand,
                HorizontalAlignment = HorizontalAlignment.Center,
                Child = new TextBlock
                {
                    Text       = "Upgrade to Guard  →",
                    FontSize   = 13,
                    FontFamily = new System.Windows.Media.FontFamily("Segoe UI"),
                    FontWeight = FontWeights.SemiBold,
                    Foreground = new SolidColorBrush(Color.FromRgb(245, 245, 247)),
                },
            };
            upgradeBtn.MouseEnter += (_, __) =>
                upgradeBtn.Background = new SolidColorBrush(Color.FromRgb(40, 155, 255));
            upgradeBtn.MouseLeave += (_, __) =>
                upgradeBtn.Background = new SolidColorBrush(Color.FromRgb(10, 132, 255));
            upgradeBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                try { System.Diagnostics.Process.Start(LicenseManager.GuardStoreUrl); } catch { }
            };
            center.Children.Add(upgradeBtn);

            // Already have a Guard key? → go to License tab
            var alreadyHaveKey = new Border
            {
                Padding = new Thickness(0, 14, 0, 0),
                Cursor  = Cursors.Hand,
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            var alreadyTb = new TextBlock
            {
                Text      = "Already purchased? Activate your key →",
                FontSize  = 10,
                FontFamily = new System.Windows.Media.FontFamily("Segoe UI"),
                Foreground = new SolidColorBrush(Color.FromRgb(10, 132, 255)),
            };
            alreadyHaveKey.Child = alreadyTb;
            alreadyHaveKey.MouseEnter += (_, __) => alreadyTb.TextDecorations = TextDecorations.Underline;
            alreadyHaveKey.MouseLeave += (_, __) => alreadyTb.TextDecorations = null;
            alreadyHaveKey.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                NavigateTo(HubPage.License);
            };
            center.Children.Add(alreadyHaveKey);

            outer.Child = center;
            return outer;
        }

        // =====================================================================
        // Activate Gate page — shown for ALL pages when no valid license exists
        // =====================================================================

        private FrameworkElement BuildActivateGatePage()
        {
            var outer = new Border
            {
                Background  = BgCard,
                CornerRadius = new CornerRadius(10),
                Margin      = new Thickness(16),
            };

            var center = new StackPanel
            {
                VerticalAlignment   = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(32, 40, 32, 40),
            };

            // Lock icon
            center.Children.Add(new TextBlock
            {
                Text                = "🔒",
                FontSize            = 48,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 16),
            });

            // Heading
            center.Children.Add(new TextBlock
            {
                Text                = "Activate to Unlock",
                FontSize            = 18,
                FontFamily          = new System.Windows.Media.FontFamily("Segoe UI"),
                FontWeight          = FontWeights.Bold,
                Foreground          = FgPrimary,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 8),
            });

            center.Children.Add(new TextBlock
            {
                Text         = "Subscribe to access all features:",
                FontSize     = 12,
                FontFamily   = new System.Windows.Media.FontFamily("Segoe UI"),
                Foreground   = FgSecondary,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin       = new Thickness(0, 0, 0, 20),
                TextWrapping = TextWrapping.Wrap,
            });

            // Feature list
            string[] features =
            {
                "📊  Session Report — real-time PSI composure score",
                "📅  History — calendar view of every session",
                "✏️  Journal — emotion tags + trade notes",
                "⚙️  Profile & Settings — strategy configuration",
                "🛡  Guard — automated protection rules  (Guard tier)",
                "🧠  Intel — monthly digest, weekday patterns & crash-trigger analysis  (Guard tier)",
            };
            foreach (var f in features)
            {
                center.Children.Add(new TextBlock
                {
                    Text         = f,
                    FontSize     = 12,
                    FontFamily   = new System.Windows.Media.FontFamily("Segoe UI"),
                    Foreground   = FgSecondary,
                    Margin       = new Thickness(0, 0, 0, 6),
                    TextWrapping = TextWrapping.Wrap,
                });
            }

            // Divider
            center.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 20, 0, 20),
            });

            // Price
            center.Children.Add(new TextBlock
            {
                Text                = "From $49.99 / month",
                FontSize            = 22,
                FontFamily          = new System.Windows.Media.FontFamily("Segoe UI"),
                FontWeight          = FontWeights.Bold,
                Foreground          = new SolidColorBrush(Color.FromRgb(80, 200, 120)),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 4),
            });
            center.Children.Add(new TextBlock
            {
                Text                = "Cancel any time · 7-day free trial",
                FontSize            = 11,
                FontFamily          = new System.Windows.Media.FontFamily("Segoe UI"),
                Foreground          = FgHint,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 20),
            });

            // CTA button
            var ctaBtn = new Border
            {
                Background    = new SolidColorBrush(Color.FromRgb(30, 120, 220)),
                CornerRadius  = new CornerRadius(8),
                Padding       = new Thickness(24, 12, 24, 12),
                Cursor        = System.Windows.Input.Cursors.Hand,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin        = new Thickness(0, 0, 0, 16),
                Child         = new TextBlock
                {
                    Text       = "Get Started  →",
                    FontSize   = 14,
                    FontFamily = new System.Windows.Media.FontFamily("Segoe UI"),
                    FontWeight = FontWeights.SemiBold,
                    Foreground = FgPrimary,
                },
            };
            ctaBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                try { System.Diagnostics.Process.Start(LicenseManager.StoreUrl); } catch { }
            };
            center.Children.Add(ctaBtn);

            // Already purchased link
            var alreadyHaveKey = new Border
            {
                Cursor              = System.Windows.Input.Cursors.Hand,
                HorizontalAlignment = HorizontalAlignment.Center,
                Child = new TextBlock
                {
                    Text            = "Already purchased? Activate your key  →",
                    FontSize        = 12,
                    FontFamily      = new System.Windows.Media.FontFamily("Segoe UI"),
                    Foreground      = FgAccent,
                    TextDecorations = TextDecorations.Underline,
                },
            };
            alreadyHaveKey.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                NavigateTo(HubPage.License);
            };
            center.Children.Add(alreadyHaveKey);

            outer.Child = center;
            return outer;
        }

        // =====================================================================
        // Page: History
        // =====================================================================

        private FrameworkElement CreateHistoryPage()
        {
            try
            {
                var source = new HistoryWindow(_historyStore);
                source.ViewTodayRequested    += () => NavigateTo(HubPage.Session);
                source.ViewJournalRequested  += date =>
                {
                    _journalDateShown = date.Date;
                    NavigateTo(HubPage.Journal);
                };
                source.ClearHistoryRequested += () =>
                {
                    ShowCountdownConfirmDialog(
                        "Clear All Session History",
                        "This permanently deletes every session record.\n\n" +
                        "Your trading baseline is separate and will not be affected.\n" +
                        "This action cannot be undone.",
                        20,
                        () =>
                        {
                            HistoryClearRequested?.Invoke();
                            NavigateTo(HubPage.History);
                        });
                };

                var dock = new DockPanel { LastChildFill = true };

                var bar = BuildPageActionBar(
                    "⎘  Copy Month Summary",
                    () => source.CopySummary(),
                    "Intel →",
                    () => NavigateTo(HubPage.Intelligence));
                DockPanel.SetDock(bar, Dock.Top);
                dock.Children.Add(bar);

                dock.Children.Add(TransplantWindowBody(source));

                return dock;
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load history.");
            }
        }

        // ── Thin action bar docked to the top of Session/History pages ─────────
        // Provides Copy actions that were lost when TransplantWindowBody stripped
        // the original window header.  Optional rightLabel/rightAction adds a
        // cross-navigation link on the right side.
        private static Border BuildPageActionBar(string label, Action onClick,
                                                  string rightLabel = null, Action rightAction = null)
        {
            var bar = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(38, 38, 40)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                BorderThickness = new Thickness(0, 0, 0, 1),
                Padding         = new Thickness(14, 6, 14, 6),
            };

            var barGrid = new Grid();
            barGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            barGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            // Left: copy button (optional — if label is null, left side is empty)
            if (label != null && onClick != null)
            {
                var btn = new Border
                {
                    Background        = Brushes.Transparent,
                    Cursor            = Cursors.Hand,
                    VerticalAlignment = VerticalAlignment.Center,
                };
                var lbl = new TextBlock
                {
                    Text              = label,
                    FontSize          = 11,
                    FontFamily        = new FontFamily("Segoe UI"),
                    Foreground        = FgSecondary,
                    VerticalAlignment = VerticalAlignment.Center,
                };
                btn.Child = lbl;
                btn.MouseEnter += (_, __) => lbl.Foreground = FgPrimary;
                btn.MouseLeave += (_, __) => lbl.Foreground = FgSecondary;
                btn.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    onClick?.Invoke();
                    string orig = lbl.Text;
                    lbl.Text = "✓  Copied!";
                    lbl.Foreground = new SolidColorBrush(Color.FromRgb(48, 209, 88));
                    var t = new System.Windows.Threading.DispatcherTimer
                        { Interval = TimeSpan.FromSeconds(2) };
                    t.Tick += (__, ___) =>
                    {
                        lbl.Text = orig;
                        lbl.Foreground = FgSecondary;
                        t.Stop();
                    };
                    t.Start();
                };
                Grid.SetColumn(btn, 0);
                barGrid.Children.Add(btn);
            }

            // Right: cross-nav link (optional)
            if (rightLabel != null && rightAction != null)
            {
                var linkTb = new TextBlock
                {
                    Text              = rightLabel,
                    FontSize          = 11,
                    FontFamily        = new FontFamily("Segoe UI"),
                    Foreground        = FgAccent,
                    VerticalAlignment = VerticalAlignment.Center,
                    Cursor            = Cursors.Hand,
                };
                var linkBorder = new Border
                {
                    Background        = Brushes.Transparent,
                    Cursor            = Cursors.Hand,
                    VerticalAlignment = VerticalAlignment.Center,
                    Child             = linkTb,
                };
                linkBorder.MouseEnter += (_, __) => linkTb.TextDecorations = TextDecorations.Underline;
                linkBorder.MouseLeave += (_, __) => linkTb.TextDecorations = null;
                linkBorder.MouseLeftButtonDown += (_, e) => { e.Handled = true; rightAction?.Invoke(); };
                Grid.SetColumn(linkBorder, 1);
                barGrid.Children.Add(linkBorder);
            }

            bar.Child = barGrid;
            return bar;
        }

        // ── Session page empty state: shows last recorded session summary ──────
        private FrameworkElement BuildSessionEmptyPage()
        {
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };

            var stack = new StackPanel
            {
                Margin              = new Thickness(20, 20, 20, 28),
                HorizontalAlignment = HorizontalAlignment.Stretch,
            };

            // ── Monitor-active status line ────────────────────────────────────
            var statusRow = new StackPanel
            {
                Orientation         = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 20),
            };
            var pulseDot = new System.Windows.Shapes.Ellipse
            {
                Width  = 7, Height = 7,
                Fill   = new SolidColorBrush(Color.FromRgb(48, 209, 88)),
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 7, 0),
            };
            statusRow.Children.Add(pulseDot);
            statusRow.Children.Add(new TextBlock
            {
                Text              = "Monitor active — waiting for today's first trade",
                FontSize          = 11,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            });
            stack.Children.Add(statusRow);

            // ── Today's Risk Brief (inline from Intel engine) ─────────────────
            try
            {
                var sessions = _historyStore?.Sessions
                    .Where(s => s.TotalTrades > 0).ToList()
                    ?? new System.Collections.Generic.List<SessionHistoryEntry>();
                var brief = IntelligenceEngine.ComputeRiskBrief(sessions);

                var briefCard = new Border
                {
                    Background      = BgCard,
                    CornerRadius    = new CornerRadius(10),
                    Padding         = new Thickness(16, 12, 16, 14),
                    Margin          = new Thickness(0, 0, 0, 16),
                    BorderBrush     = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                    BorderThickness = new Thickness(1),
                };
                var briefStack = new StackPanel();

                // Header row: "TODAY'S RISK BRIEF" + risk badge
                var briefHeader = new Grid { Margin = new Thickness(0, 0, 0, 8) };
                briefHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                briefHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                briefHeader.Children.Add(new TextBlock
                {
                    Text              = "TODAY'S RISK BRIEF",
                    FontSize          = 9,
                    FontFamily        = new FontFamily("Segoe UI"),
                    FontWeight        = FontWeights.Bold,
                    Foreground        = FgSecondary,
                    VerticalAlignment = VerticalAlignment.Center,
                });

                if (brief.HasEnoughData)
                {
                    Color riskColor = brief.RiskScore >= 70 ? Color.FromRgb(255, 69, 58)
                                    : brief.RiskScore >= 50 ? Color.FromRgb(255, 214, 0)
                                    : brief.RiskScore >= 30 ? Color.FromRgb(90, 200, 250)
                                    : Color.FromRgb(48, 209, 88);
                    var riskBadge = new Border
                    {
                        Background    = new SolidColorBrush(Color.FromArgb(40, riskColor.R, riskColor.G, riskColor.B)),
                        CornerRadius  = new CornerRadius(6),
                        Padding       = new Thickness(8, 3, 8, 3),
                        VerticalAlignment = VerticalAlignment.Center,
                        Child = new TextBlock
                        {
                            Text       = $"{brief.RiskLabel} Risk",
                            FontSize   = 10,
                            FontFamily = new FontFamily("Segoe UI"),
                            FontWeight = FontWeights.SemiBold,
                            Foreground = new SolidColorBrush(riskColor),
                        },
                    };
                    Grid.SetColumn(riskBadge, 1);
                    briefHeader.Children.Add(riskBadge);

                    // Risk factors
                    foreach (var f in brief.Factors)
                    {
                        Color fc   = f.IsGood ? Color.FromRgb(48, 209, 88)
                                   : f.Delta >= 15 ? Color.FromRgb(255, 69, 58)
                                   : Color.FromRgb(255, 214, 0);
                        string ico = f.IsGood ? "✓" : f.Delta >= 15 ? "⚠" : "·";
                        briefStack.Children.Add(new TextBlock
                        {
                            Text         = $"{ico}  {f.Reason}",
                            FontSize     = 11,
                            FontFamily   = new FontFamily("Segoe UI"),
                            Foreground   = new SolidColorBrush(fc),
                            TextWrapping = TextWrapping.Wrap,
                            Margin       = new Thickness(0, 3, 0, 0),
                        });
                    }

                    briefStack.Children.Add(new Border
                    {
                        Height     = 1,
                        Background = new SolidColorBrush(Color.FromArgb(22, 255, 255, 255)),
                        Margin     = new Thickness(0, 8, 0, 8),
                    });
                    briefStack.Children.Add(new TextBlock
                    {
                        Text         = brief.RecommendationText,
                        FontSize     = 11,
                        FontFamily   = new FontFamily("Segoe UI"),
                        Foreground   = FgSecondary,
                        TextWrapping = TextWrapping.Wrap,
                        FontStyle    = FontStyles.Italic,
                    });
                }
                else
                {
                    briefStack.Children.Add(new TextBlock
                    {
                        Text         = brief.RecommendationText,
                        FontSize     = 11,
                        FontFamily   = new FontFamily("Segoe UI"),
                        Foreground   = FgHint,
                        TextWrapping = TextWrapping.Wrap,
                        FontStyle    = FontStyles.Italic,
                    });
                }

                // "View full Intel →" link
                var intelLink = new Border
                {
                    Background = Brushes.Transparent,
                    Cursor     = Cursors.Hand,
                    Margin     = new Thickness(0, 10, 0, 0),
                    HorizontalAlignment = HorizontalAlignment.Right,
                };
                var intelTb = new TextBlock
                {
                    Text       = "Full analysis in Intel →",
                    FontSize   = 10,
                    FontFamily = new FontFamily("Segoe UI"),
                    Foreground = FgAccent,
                };
                intelLink.Child = intelTb;
                intelLink.MouseEnter += (_, __) => intelTb.TextDecorations = TextDecorations.Underline;
                intelLink.MouseLeave += (_, __) => intelTb.TextDecorations = null;
                intelLink.MouseLeftButtonDown += (_, e) => { e.Handled = true; NavigateTo(HubPage.Intelligence); };
                briefStack.Children.Add(intelLink);

                var briefInner = new StackPanel();
                briefInner.Children.Add(briefHeader);
                foreach (UIElement child in briefStack.Children)
                    briefInner.Children.Add(child);
                briefCard.Child = briefInner;
                stack.Children.Add(briefCard);
            }
            catch { /* If Intel data unavailable, skip Risk Brief silently */ }

            // ── Last session card ─────────────────────────────────────────────
            var lastEntry = _historyStore?.ByDateDescending.FirstOrDefault();
            if (lastEntry != null)
            {
                stack.Children.Add(new TextBlock
                {
                    Text       = "LAST SESSION",
                    FontSize   = 9,
                    FontFamily = new FontFamily("Segoe UI"),
                    FontWeight = FontWeights.Bold,
                    Foreground = FgHint,
                    Margin     = new Thickness(0, 0, 0, 8),
                });

                var card = new Border
                {
                    Background      = BgCard,
                    CornerRadius    = new CornerRadius(10),
                    Padding         = new Thickness(16, 14, 16, 14),
                };

                Color zoneColor = lastEntry.FinalZone == PsiZone.Stable   ? Color.FromRgb( 48, 209,  88)
                                : lastEntry.FinalZone == PsiZone.Caution  ? Color.FromRgb(255, 214,   0)
                                :                                            Color.FromRgb(255,  69,  58);

                var cardStack = new StackPanel();

                // Date + zone badge row
                var dateRow = new Grid { Margin = new Thickness(0, 0, 0, 12) };
                dateRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                dateRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                dateRow.Children.Add(new TextBlock
                {
                    Text              = lastEntry.Date.ToString("dddd, MMMM d, yyyy"),
                    FontSize          = 13,
                    FontFamily        = new FontFamily("Segoe UI"),
                    FontWeight        = FontWeights.SemiBold,
                    Foreground        = FgPrimary,
                    VerticalAlignment = VerticalAlignment.Center,
                });

                var zoneBadge = new Border
                {
                    Background    = new SolidColorBrush(
                        Color.FromArgb(40, zoneColor.R, zoneColor.G, zoneColor.B)),
                    BorderBrush   = new SolidColorBrush(zoneColor),
                    BorderThickness = new Thickness(1),
                    CornerRadius  = new CornerRadius(10),
                    Padding       = new Thickness(8, 3, 8, 3),
                };
                zoneBadge.Child = new TextBlock
                {
                    Text       = lastEntry.FinalZone.ToString().ToUpper(),
                    FontSize   = 9,
                    FontFamily = new FontFamily("Segoe UI"),
                    FontWeight = FontWeights.SemiBold,
                    Foreground = new SolidColorBrush(zoneColor),
                };
                Grid.SetColumn(zoneBadge, 1);
                dateRow.Children.Add(zoneBadge);
                cardStack.Children.Add(dateRow);

                // Stat tiles: PSI, P&L, Trades, Composure
                var statsGrid = new Grid();
                for (int i = 0; i < 4; i++)
                    statsGrid.ColumnDefinitions.Add(
                        new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

                string pnlStr = (lastEntry.TotalPnl >= 0 ? "+" : "-") + "$" +
                                Math.Abs(lastEntry.TotalPnl).ToString("0");
                Color  pnlCol = lastEntry.TotalPnl >= 0
                    ? Color.FromRgb(48, 209, 88) : Color.FromRgb(255, 69, 58);

                AddLastSessionStat(statsGrid, 0, "FINAL PSI",
                    lastEntry.FinalPsi.ToString("0"), zoneColor);
                AddLastSessionStat(statsGrid, 1, "P&L",
                    pnlStr, pnlCol);
                AddLastSessionStat(statsGrid, 2, "TRADES",
                    lastEntry.TotalTrades.ToString(),
                    Color.FromRgb(245, 245, 247));
                AddLastSessionStat(statsGrid, 3, "COMPOSURE",
                    lastEntry.ComposurePct + "%",
                    lastEntry.ComposurePct >= 85 ? Color.FromRgb(48, 209, 88)
                    : lastEntry.ComposurePct >= SessionData.ComposureStableThreshold ? Color.FromRgb(163, 213, 72)
                    : lastEntry.ComposurePct >= 50 ? Color.FromRgb(255, 214, 0)
                    : Color.FromRgb(255, 69, 58));
                cardStack.Children.Add(statsGrid);

                card.Child = cardStack;
                stack.Children.Add(card);
            }

            scroll.Content = stack;
            return scroll;
        }

        private static void AddLastSessionStat(Grid grid, int col, string label, string value, Color valueColor)
        {
            var sp = new StackPanel
            {
                Margin = new Thickness(col == 0 ? 0 : 4, 0, 0, 0),
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            sp.Children.Add(new TextBlock
            {
                Text                = value,
                FontSize            = 18,
                FontFamily          = new FontFamily("Segoe UI"),
                FontWeight          = FontWeights.Bold,
                Foreground          = new SolidColorBrush(valueColor),
                HorizontalAlignment = HorizontalAlignment.Center,
            });
            sp.Children.Add(new TextBlock
            {
                Text                = label,
                FontSize            = 8.5,
                FontFamily          = new FontFamily("Segoe UI"),
                FontWeight          = FontWeights.SemiBold,
                Foreground          = FgHint,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 2, 0, 0),
            });
            Grid.SetColumn(sp, col);
            grid.Children.Add(sp);
        }

        private FrameworkElement BuildHistoryDangerZone()
        {
            var container = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(28, 28, 30)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                BorderThickness = new Thickness(0, 1, 0, 0),
                Padding         = new Thickness(20, 12, 20, 14),
            };

            var clearBtn = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(55, 30, 30)),
                CornerRadius    = new CornerRadius(6),
                Padding         = new Thickness(14, 8, 14, 8),
                Cursor          = Cursors.Hand,
                BorderBrush     = new SolidColorBrush(Color.FromRgb(255, 69, 58)),
                BorderThickness = new Thickness(1),
            };

            var btnStack = new StackPanel();
            btnStack.Children.Add(new TextBlock
            {
                Text       = "Clear Session History",
                FontSize   = 12,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(255, 69, 58)),
            });
            btnStack.Children.Add(new TextBlock
            {
                Text         = "Deletes all session log entries. Does not affect your statistical baseline.",
                FontSize     = 10,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = new SolidColorBrush(Color.FromRgb(174, 174, 178)),
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 3, 0, 0),
            });
            clearBtn.Child = btnStack;

            clearBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                var result = MessageBox.Show(
                    this,
                    "This will permanently delete all session history entries.\n\n" +
                    "Your statistical baseline is NOT affected — only the session log will be cleared.\n\n" +
                    "Are you sure?",
                    "Clear Session History",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning,
                    MessageBoxResult.No);

                if (result == MessageBoxResult.Yes)
                {
                    HistoryClearRequested?.Invoke();
                    NavigateTo(HubPage.History);
                }
            };

            container.Child = clearBtn;
            return container;
        }

        // =====================================================================
        // Page: Profile (Baseline)
        // =====================================================================

        private FrameworkElement CreateProfilePage()
        {
            try
            {
                if (_embeddedBaselineWindow != null)
                    _embeddedBaselineWindow.ResetRequested -= OnEmbeddedBaselineReset;

                _embeddedBaselineWindow = new BaselineWindow(_baseline, _profile);
                _embeddedBaselineWindow.ResetRequested         += OnEmbeddedBaselineReset;
                _embeddedBaselineWindow.ClearHistoryRequested  += () =>
                {
                    HistoryClearRequested?.Invoke();
                };

                return TransplantWindowBody(_embeddedBaselineWindow);
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load profile.");
            }
        }

        private void OnEmbeddedBaselineReset()
        {
            ShowCountdownConfirmDialog(
                "Reset Trading Baseline",
                "This clears your personal statistical baseline (inter-trade gap\n" +
                "distribution, μLoss).\n\n" +
                "PSI cold-start defaults apply until enough trades rebuild it.\n" +
                "Your session history is unaffected.",
                15,
                () => BaselineResetRequested?.Invoke());
        }

        // =====================================================================
        // Page: License
        // =====================================================================

        private FrameworkElement CreateLicensePage()
        {
            var lm = _licenseManager;

            // ── Status badge colours ─────────────────────────────────────────
            LicenseStatus status = lm?.Status ?? LicenseStatus.Trial_Active;
            string statusText;
            Brush  statusBg;
            switch (status)
            {
                case LicenseStatus.Trial_Active:
                    int days = lm?.TrialDaysRemaining ?? LicenseManager.TrialDays;
                    statusText = $"Trial Active — {days} day{(days == 1 ? "" : "s")} remaining";
                    statusBg   = new SolidColorBrush(Color.FromRgb(52, 120, 50));
                    break;
                case LicenseStatus.Trial_Expired:
                    statusText = "Trial Expired — Please activate";
                    statusBg   = new SolidColorBrush(Color.FromRgb(160, 60, 40));
                    break;
                case LicenseStatus.Licensed:
                    statusText = "Licensed  ✓";
                    statusBg   = new SolidColorBrush(Color.FromRgb(30, 100, 180));
                    break;
                case LicenseStatus.Offline_Grace:
                    statusText = $"Offline Grace — up to {LicenseManager.GraceDays} days";
                    statusBg   = new SolidColorBrush(Color.FromRgb(140, 100, 20));
                    break;
                case LicenseStatus.Expired:
                    statusText = "Subscription Expired — Please renew";
                    statusBg   = new SolidColorBrush(Color.FromRgb(160, 60, 40));
                    break;
                default:
                    statusText = "License Invalid — Please re-activate";
                    statusBg   = new SolidColorBrush(Color.FromRgb(160, 60, 40));
                    break;
            }

            // ── Root scroll ─────────────────────────────────────────────────
            var scroll = new System.Windows.Controls.ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };

            var stack = new StackPanel { Margin = new Thickness(28, 24, 28, 24) };

            // ── Update available banner (shown above everything else) ─────────
            if (_updateVersion != null)
            {
                var updateBorder = new Border
                {
                    Background   = new SolidColorBrush(Color.FromRgb(40, 80, 140)),
                    CornerRadius = new CornerRadius(6),
                    Padding      = new Thickness(16, 12, 16, 12),
                    Margin       = new Thickness(0, 0, 0, 20),
                };
                var updateInner = new StackPanel();
                updateInner.Children.Add(new TextBlock
                {
                    Text       = $"⬆  Update available — {_updateVersion}",
                    FontSize   = 14,
                    FontFamily = new FontFamily("Segoe UI"),
                    FontWeight = FontWeights.SemiBold,
                    Foreground = FgPrimary,
                    Margin     = new Thickness(0, 0, 0, 4),
                });
                if (!string.IsNullOrEmpty(_updateNotes))
                {
                    updateInner.Children.Add(new TextBlock
                    {
                        Text       = _updateNotes,
                        FontSize   = 12,
                        FontFamily = new FontFamily("Segoe UI"),
                        Foreground = FgSecondary,
                        TextWrapping = TextWrapping.Wrap,
                        Margin     = new Thickness(0, 0, 0, 8),
                    });
                }
                var dlBtn = new Button
                {
                    Content             = "Go to Download",
                    Padding             = new Thickness(14, 6, 14, 6),
                    Background          = new SolidColorBrush(Color.FromRgb(30, 120, 220)),
                    Foreground          = FgPrimary,
                    BorderThickness     = new Thickness(0),
                    FontFamily          = new FontFamily("Segoe UI"),
                    FontSize            = 12,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Cursor              = System.Windows.Input.Cursors.Hand,
                };
                dlBtn.Click += (s, e) =>
                {
                    try { System.Diagnostics.Process.Start(LicenseManager.StoreUrl); } catch { }
                };
                updateInner.Children.Add(dlBtn);
                updateBorder.Child = updateInner;
                stack.Children.Add(updateBorder);
            }

            // ── Status badge ────────────────────────────────────────────────
            var badge = new Border
            {
                Background    = statusBg,
                CornerRadius  = new CornerRadius(6),
                Padding       = new Thickness(14, 8, 14, 8),
                Margin        = new Thickness(0, 0, 0, 24),
                HorizontalAlignment = HorizontalAlignment.Left,
            };
            badge.Child = new TextBlock
            {
                Text       = statusText,
                FontSize   = 13,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = FgPrimary,
            };
            stack.Children.Add(badge);

            // ── Machine ID row ───────────────────────────────────────────────
            stack.Children.Add(MakeLicenseLabel("Machine ID"));
            string machineId = LicenseManager.GetMachineId();
            var midRow = new Grid { Margin = new Thickness(0, 4, 0, 20) };
            midRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            midRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var midBox = new TextBox
            {
                Text              = machineId,
                IsReadOnly        = true,
                FontFamily        = new FontFamily("Consolas"),
                FontSize          = 12,
                Foreground        = FgSecondary,
                Background        = BgCard,
                BorderBrush       = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness   = new Thickness(1),
                Padding           = new Thickness(10, 7, 10, 7),
            };
            Grid.SetColumn(midBox, 0);
            midRow.Children.Add(midBox);

            var copyBtn = MakeLicenseButton("Copy");
            copyBtn.Margin = new Thickness(8, 0, 0, 0);
            copyBtn.Click += (_, __) =>
            {
                try { System.Windows.Clipboard.SetText(machineId); } catch { }
            };
            Grid.SetColumn(copyBtn, 1);
            midRow.Children.Add(copyBtn);
            stack.Children.Add(midRow);

            // ── Key input (hidden when already licensed) ─────────────────────
            bool showActivate = status != LicenseStatus.Licensed &&
                                status != LicenseStatus.Offline_Grace;

            if (showActivate)
            {
                stack.Children.Add(MakeLicenseLabel("License Key"));
                var keyRow = new Grid { Margin = new Thickness(0, 4, 0, 8) };
                keyRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                keyRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                var keyBox = new TextBox
                {
                    FontFamily      = new FontFamily("Consolas"),
                    FontSize        = 12,
                    Foreground      = FgPrimary,
                    Background      = BgCard,
                    BorderBrush     = new SolidColorBrush(Color.FromArgb(80, 255, 255, 255)),
                    BorderThickness = new Thickness(1),
                    Padding         = new Thickness(10, 7, 10, 7),
                    ToolTip         = "Paste your Whop license key — find it at whop.com/hub after purchase",
                };
                // Pre-fill with existing key if we have one (invalid/expired case).
                if (!string.IsNullOrEmpty(lm?.LicenseKey)) keyBox.Text = lm.LicenseKey;
                Grid.SetColumn(keyBox, 0);
                keyRow.Children.Add(keyBox);

                var activateBtn = MakeLicenseButton("Activate", accent: true);
                activateBtn.Margin = new Thickness(8, 0, 0, 0);
                Grid.SetColumn(activateBtn, 1);
                keyRow.Children.Add(activateBtn);
                stack.Children.Add(keyRow);

                // Feedback label
                var feedbackLabel = new TextBlock
                {
                    FontSize   = 12,
                    FontFamily = new FontFamily("Segoe UI"),
                    Foreground = FgSecondary,
                    Margin     = new Thickness(0, 4, 0, 20),
                    TextWrapping = TextWrapping.Wrap,
                };
                stack.Children.Add(feedbackLabel);

                activateBtn.Click += async (_, __) =>
                {
                    if (lm == null) { feedbackLabel.Text = "License module not loaded."; return; }
                    activateBtn.IsEnabled = false;
                    feedbackLabel.Foreground = FgSecondary;
                    feedbackLabel.Text = "Connecting to server...";
                    NinjaTrader.Code.Output.Process("[Meridian] Activate clicked — key length=" + (keyBox.Text?.Trim().Length ?? 0), PrintTo.OutputTab1);

                    // async void handler: await captures the WPF SynchronizationContext so
                    // the continuation automatically returns to the UI thread — no Dispatcher
                    // wiring needed, Output.Process works, labels are safe to write directly.
                    (bool Success, string ErrorMessage) result;
                    try
                    {
                        // Belt-and-suspenders outer timeout in case HttpClient's own timeout
                        // fails (known .NET Framework bug with SSL/TLS hang on SendAsync).
                        var apiTask = lm.ActivateAsync(keyBox.Text);
                        var won = await Task.WhenAny(apiTask, Task.Delay(TimeSpan.FromSeconds(15)));
                        result = (won == apiTask)
                            ? await apiTask
                            : (false, "Activation timed out (15 s). Check your network connection.");
                    }
                    catch (Exception ex)
                    {
                        result = (false, $"Unexpected error: {ex.Message}");
                    }

                    NinjaTrader.Code.Output.Process(
                        $"[Meridian] Activate result: success={result.Success}  msg={result.ErrorMessage ?? "ok"}",
                        PrintTo.OutputTab1);

                    activateBtn.IsEnabled = true;
                    if (result.Success)
                    {
                        feedbackLabel.Foreground = new SolidColorBrush(Color.FromRgb(80, 200, 80));
                        feedbackLabel.Text = "Activated! MeridianPSI fully unlocked.";
                        RefreshNavBadges();
                        NavigateTo(HubPage.License);
                    }
                    else
                    {
                        feedbackLabel.Foreground = new SolidColorBrush(Color.FromRgb(220, 80, 60));
                        feedbackLabel.Text = result.ErrorMessage ?? "Activation failed.";
                    }
                };
            }
            else
            {
                // Already licensed — show masked key + deactivate option
                stack.Children.Add(MakeLicenseLabel("License Key"));
                string maskedKey = lm?.LicenseKey ?? "";
                if (maskedKey.Length > 8)
                    maskedKey = maskedKey.Substring(0, 4) + "-****-****-" + maskedKey.Substring(maskedKey.Length - 4);

                stack.Children.Add(new TextBlock
                {
                    Text         = maskedKey,
                    FontFamily   = new FontFamily("Consolas"),
                    FontSize     = 12,
                    Foreground   = FgSecondary,
                    Margin       = new Thickness(0, 4, 0, 20),
                });

                // Remove license button — clears local cache so key can be entered on another PC
                var deactBtn = MakeLicenseButton("Remove license from this machine (to move to another PC)");
                deactBtn.Margin = new Thickness(0, 0, 0, 8);

                var deactFeedback = new TextBlock
                {
                    FontSize   = 12,
                    FontFamily = new FontFamily("Segoe UI"),
                    Foreground = FgSecondary,
                    Margin     = new Thickness(0, 4, 0, 20),
                    TextWrapping = TextWrapping.Wrap,
                };
                stack.Children.Add(deactBtn);
                stack.Children.Add(deactFeedback);

                deactBtn.Click += (_, __) =>
                {
                    if (lm == null) return;
                    deactBtn.IsEnabled = false;
                    deactFeedback.Text = "Removing...";
                    Task.Run(async () =>
                    {
                        var result = await lm.DeactivateAsync();
                        Dispatcher.InvokeAsync(() =>
                        {
                            deactBtn.IsEnabled = true;
                            if (result.Success)
                                NavigateTo(HubPage.License);
                            else
                            {
                                deactFeedback.Foreground = new SolidColorBrush(Color.FromRgb(220, 80, 60));
                                deactFeedback.Text = result.ErrorMessage;
                            }
                        });
                    });
                };
            }

            // ── Divider ──────────────────────────────────────────────────────
            stack.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 8, 0, 20),
            });

            // ── Store link ───────────────────────────────────────────────────
            stack.Children.Add(new TextBlock
            {
                Text         = "Subscribe / Purchase",
                FontSize     = 11,
                FontFamily   = new FontFamily("Segoe UI"),
                FontWeight   = FontWeights.SemiBold,
                Foreground   = FgHint,
                Margin       = new Thickness(0, 0, 0, 4),
            });

            var storeLink = new TextBlock
            {
                Text            = LicenseManager.StoreUrl,
                FontSize        = 12,
                FontFamily      = new FontFamily("Segoe UI"),
                Foreground      = FgAccent,
                Cursor          = Cursors.Hand,
                TextDecorations = TextDecorations.Underline,
                Margin          = new Thickness(0, 0, 0, 0),
            };
            storeLink.MouseLeftButtonDown += (_, __) =>
            {
                try { System.Diagnostics.Process.Start(LicenseManager.StoreUrl); } catch { }
            };
            stack.Children.Add(storeLink);

            // ── Trial upgrade CTA (shown for trial / expired users) ──────────
            if (status == LicenseStatus.Trial_Active || status == LicenseStatus.Trial_Expired
                || status == LicenseStatus.Expired)
            {
                stack.Children.Add(new Border
                {
                    Height     = 1,
                    Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                    Margin     = new Thickness(0, 20, 0, 16),
                });
                stack.Children.Add(new TextBlock
                {
                    Text       = "Unlock with a full license",
                    FontSize   = 13,
                    FontFamily = new FontFamily("Segoe UI"),
                    FontWeight = FontWeights.SemiBold,
                    Foreground = FgPrimary,
                    Margin     = new Thickness(0, 0, 0, 8),
                });
                string[] features =
                {
                    "Guard — rules that enforce themselves (6 triggers · 5 action levels)",
                    "Intel — monthly digest, weekday patterns & crash-trigger analysis",
                    "PSI × P&L correlation — Stable vs Critical session averages",
                    "Today's Risk Brief — personalized pre-session summary",
                };
                foreach (var f in features)
                    stack.Children.Add(new TextBlock
                    {
                        Text         = "✓  " + f,
                        FontSize     = 11,
                        FontFamily   = new FontFamily("Segoe UI"),
                        Foreground   = FgSecondary,
                        TextWrapping = TextWrapping.Wrap,
                        Margin       = new Thickness(0, 0, 0, 5),
                    });
                var ctaBtn = new Border
                {
                    Background      = new SolidColorBrush(Color.FromRgb(10, 132, 255)),
                    CornerRadius    = new CornerRadius(8),
                    Padding         = new Thickness(0, 12, 0, 12),
                    Margin          = new Thickness(0, 12, 0, 0),
                    Cursor          = Cursors.Hand,
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                    Child = new TextBlock
                    {
                        Text                = "Upgrade — full access  →",
                        FontSize            = 13,
                        FontFamily          = new FontFamily("Segoe UI"),
                        FontWeight          = FontWeights.SemiBold,
                        Foreground          = FgPrimary,
                        HorizontalAlignment = HorizontalAlignment.Center,
                    },
                };
                ctaBtn.MouseEnter += (_, __) => ctaBtn.Background = new SolidColorBrush(Color.FromRgb(40, 155, 255));
                ctaBtn.MouseLeave += (_, __) => ctaBtn.Background = new SolidColorBrush(Color.FromRgb(10, 132, 255));
                ctaBtn.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    try { System.Diagnostics.Process.Start(LicenseManager.StoreUrl); } catch { }
                };
                stack.Children.Add(ctaBtn);
            }

            // ── Export Diagnostics ───────────────────────────────────────────
            stack.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(18, 255, 255, 255)),
                Margin     = new Thickness(0, 24, 0, 16),
            });
            stack.Children.Add(new TextBlock
            {
                Text         = "Having an issue? Export a diagnostics file and send it to support.",
                FontSize     = 10,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 8),
            });
            var diagStatusLbl = new TextBlock
            {
                FontSize     = 10,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 6, 0, 0),
            };
            var diagBtn = new Button
            {
                Content             = "Export Diagnostics File",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = BgCard,
                Foreground          = FgPrimary,
                BorderBrush         = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255)),
                BorderThickness     = new Thickness(1),
                FontFamily          = new FontFamily("Segoe UI"),
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            diagBtn.Click += (s, e) =>
            {
                diagBtn.IsEnabled   = false;
                diagStatusLbl.Text  = "Collecting...";
                diagStatusLbl.Foreground = FgSecondary;
                try
                {
                    // Snapshot must be captured on the UI thread (same thread as
                    // _currentSession, _engine, _guardEngine).  The write runs
                    // on a Task thread so the UI doesn't block.
                    var snap = _monitor.GetDiagnosticsSnapshot();
                    System.Threading.Tasks.Task.Run(() =>
                    {
                        string outPath = null; string summary;
                        bool   ok      = false;
                        try
                        {
                            outPath = DiagnosticsExporter.WriteToDesktop(snap);
                            summary = "Saved to Desktop: " + System.IO.Path.GetFileName(outPath);
                            ok      = true;
                        }
                        catch (Exception ex)
                        {
                            summary = "Export failed: " + ex.Message;
                        }
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            diagBtn.IsEnabled        = true;
                            diagStatusLbl.Text       = summary;
                            diagStatusLbl.Foreground = ok
                                ? new SolidColorBrush(Color.FromRgb(120, 200, 130))
                                : new SolidColorBrush(Color.FromRgb(220, 120, 110));
                            if (outPath != null)
                                try { System.Diagnostics.Process.Start(outPath); } catch { }
                        }));
                    });
                }
                catch (Exception ex)
                {
                    diagBtn.IsEnabled        = true;
                    diagStatusLbl.Text       = "Snapshot failed: " + ex.Message;
                    diagStatusLbl.Foreground = new SolidColorBrush(Color.FromRgb(220, 120, 110));
                }
            };
            stack.Children.Add(diagBtn);
            stack.Children.Add(diagStatusLbl);

            // ── Version footer (click 5× to reveal developer tools) ──────────
            stack.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(18, 255, 255, 255)),
                Margin     = new Thickness(0, 24, 0, 12),
            });

            // ── Help / documentation link ────────────────────────────────────
            var docsRow = new StackPanel
            {
                Orientation         = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 10),
            };
            var docsTb = new TextBlock
            {
                Text              = "Documentation & User Guide",
                FontSize          = 10,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgAccent,
                TextDecorations   = null,
                Cursor            = System.Windows.Input.Cursors.Hand,
                VerticalAlignment = VerticalAlignment.Center,
            };
            docsTb.MouseEnter        += (_, __) => docsTb.TextDecorations = TextDecorations.Underline;
            docsTb.MouseLeave        += (_, __) => docsTb.TextDecorations = null;
            docsTb.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                try { System.Diagnostics.Process.Start(LicenseManager.DocsUrl); } catch { }
            };
            docsRow.Children.Add(docsTb);
            stack.Children.Add(docsRow);

            int devClicks = 0;
            var devPanel  = new StackPanel { Visibility = Visibility.Collapsed };

            var versionTb = new TextBlock
            {
                Text      = $"MeridianPSI v{MeridianPSI.ProductVersion}",
                FontSize  = 10,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgHint,
                Cursor     = Cursors.Hand,
                Margin     = new Thickness(0, 0, 0, 16),
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            versionTb.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                devClicks++;
                if (devClicks >= 5)
                    devPanel.Visibility = Visibility.Visible;
            };
            stack.Children.Add(versionTb);

            // ── Developer Tools (hidden; reveal by clicking version 5 times) ──
            devPanel.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 0, 0, 12),
            });
            devPanel.Children.Add(new TextBlock
            {
                Text       = "Developer Tools",
                FontSize   = 11,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = FgHint,
                Margin     = new Thickness(0, 0, 0, 6),
            });

            // ── Demo Data ──────────────────────────────────────────────────────
            devPanel.Children.Add(new TextBlock
            {
                Text         = "Seed 5 months of story-driven demo history (Dec 2025 – Apr 2026). ⚠ This overwrites your real history.xml. Back up TradeMonitorData\\history.xml first.",
                FontSize     = 10,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 8),
            });

            var demoStatusLbl = new TextBlock
            {
                FontSize     = 10,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 6, 0, 0),
            };

            var seedBtn = new Button
            {
                Content             = "Seed Demo Data (Dec 2025 – Apr 2026)",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(80, 60, 120)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = new FontFamily("Segoe UI"),
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            seedBtn.Click += (s, e) =>
            {
                seedBtn.IsEnabled  = false;
                demoStatusLbl.Text = "Seeding — writing history.xml + 3 session-detail files…";
                demoStatusLbl.Foreground = FgSecondary;

                System.Threading.Tasks.Task.Run(() =>
                {
                    string result;
                    bool   ok = false;
                    try
                    {
                        result = DemoDataSeeder.Seed(msg =>
                            Dispatcher.BeginInvoke(new Action(() => demoStatusLbl.Text = msg)));
                        ok = result != null && !result.StartsWith("[Demo");
                    }
                    catch (Exception ex)
                    {
                        result = "Seed failed: " + ex.Message;
                    }

                    string captured = result;
                    bool   capturedOk = ok;
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        seedBtn.IsEnabled        = true;
                        demoStatusLbl.Text       = captured ?? "(no output)";
                        demoStatusLbl.Foreground = capturedOk
                            ? new SolidColorBrush(Color.FromRgb(120, 200, 130))
                            : new SolidColorBrush(Color.FromRgb(220, 120, 110));
                        // Reload history in memory so History / Intelligence pages
                        // update immediately without an NT8 restart.
                        if (capturedOk) ReloadHistoryStore();
                    }));
                });
            };
            devPanel.Children.Add(seedBtn);
            devPanel.Children.Add(demoStatusLbl);

            devPanel.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 16, 0, 12),
            });

            // ── V2 Engine Test Suite ──────────────────────────────────────────
            devPanel.Children.Add(new TextBlock
            {
                Text         = "Runs PsiEngineV2 against all acceptance scenarios. Does NOT touch the live engine, HUD, or baseline. Results written to Desktop\\PsiV2TestResults.txt.",
                FontSize     = 10,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 10),
            });

            var v2StatusLbl = new TextBlock
            {
                FontSize   = 11,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin     = new Thickness(0, 8, 0, 0),
            };

            var v2RunBtn = new Button
            {
                Content             = "Run V2 Engine Test Suite (S201–S255)",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(60, 80, 120)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = new FontFamily("Segoe UI"),
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            v2RunBtn.Click += (s, e) =>
            {
                v2RunBtn.IsEnabled = false;
                v2StatusLbl.Text = "Running — this may take a few seconds…";
                v2StatusLbl.Foreground = FgSecondary;

                System.Threading.Tasks.Task.Run(() =>
                {
                    string summary;
                    bool ok = false;
                    try
                    {
                        summary = PsiTestRunnerV2.RunAll();
                        ok = summary != null && summary.IndexOf("FAIL", StringComparison.OrdinalIgnoreCase) < 0;
                    }
                    catch (Exception ex)
                    {
                        summary = "V2 test runner threw: " + ex.Message;
                    }

                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        v2RunBtn.IsEnabled = true;
                        v2StatusLbl.Text   = summary ?? "(no output)";
                        v2StatusLbl.Foreground = ok
                            ? new SolidColorBrush(Color.FromRgb(120, 200, 130))
                            : new SolidColorBrush(Color.FromRgb(220, 120, 110));
                    }));
                });
            };
            devPanel.Children.Add(v2RunBtn);

            var v2OpenBtn = new Button
            {
                Content             = "Open PsiV2TestResults.txt",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(70, 70, 80)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = new FontFamily("Segoe UI"),
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
                Margin              = new Thickness(0, 8, 0, 0),
            };
            v2OpenBtn.Click += (s, e) =>
            {
                try
                {
                    string path = System.IO.Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                        "PsiV2TestResults.txt");
                    if (System.IO.File.Exists(path))
                        System.Diagnostics.Process.Start(path);
                    else
                        v2StatusLbl.Text = "No results file yet — run the suite first.";
                }
                catch (Exception ex)
                {
                    v2StatusLbl.Text = "Open failed: " + ex.Message;
                }
            };
            devPanel.Children.Add(v2OpenBtn);
            devPanel.Children.Add(v2StatusLbl);

            // ── Integrity / Replay / Fuzzer tools ─────────────────────────
            // Architecturally these belong to the same "Developer Tools"
            // section, but their job is to verify the state-machine fabric
            // (TradeMonitor lifecycle dictionaries + IntegrityCheck), not
            // the engine math.  See ARCHITECTURE.md §15 (Self-Healing State).
            devPanel.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 16, 0, 12),
            });
            devPanel.Children.Add(new TextBlock
            {
                Text       = "State Integrity Tools",
                FontSize   = 11,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = FgHint,
                Margin     = new Thickness(0, 0, 0, 6),
            });
            devPanel.Children.Add(new TextBlock
            {
                Text         = "Replay diagnoses any past CSV log against the current build to surface state-tearing / lifecycle bugs that happened in that session. Fuzzer generates 1000 random NT8 event scenarios and asserts our state-machine invariants always hold. Both write detailed reports to your Desktop.",
                FontSize     = 10,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 10),
            });

            var integrityStatusLbl = new TextBlock
            {
                FontSize   = 11,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin     = new Thickness(0, 8, 0, 0),
            };

            var replayBtn = new Button
            {
                Content             = "Run Replay Harness on CSV log(s)…",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(60, 80, 120)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = new FontFamily("Segoe UI"),
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            replayBtn.Click += (s, e) =>
            {
                try
                {
                    var dlg = new Microsoft.Win32.OpenFileDialog
                    {
                        Title       = "Choose NinjaTrader Grid CSV log(s) — hold Ctrl / Shift to select multiple",
                        Filter      = "NinjaTrader Grid CSV (*.csv)|*.csv|All files (*.*)|*.*",
                        InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
                                           + System.IO.Path.DirectorySeparatorChar + "Downloads",
                        Multiselect = true,
                    };
                    if (dlg.ShowDialog() != true) return;

                    string[] csvPaths = dlg.FileNames;
                    replayBtn.IsEnabled = false;
                    integrityStatusLbl.Text = string.Format(
                        "Replaying {0} file(s)…", csvPaths.Length);
                    integrityStatusLbl.Foreground = FgSecondary;

                    System.Threading.Tasks.Task.Run(() =>
                    {
                        string outDir  = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                        int    totalV  = 0;
                        int    totalS  = 0;
                        bool   allOk   = true;
                        string lastOut = null;

                        // Batch: run each file, accumulate totals.
                        // Individual report files are written as usual.
                        // When more than one file is selected, also write a
                        // single-page batch-summary file.
                        var batchLines = new System.Collections.Generic.List<string>();
                        batchLines.Add("==================== BATCH REPLAY SUMMARY ====================");
                        batchLines.Add(string.Format("Run:   {0:u}", DateTime.UtcNow));
                        batchLines.Add(string.Format("Files: {0}", csvPaths.Length));
                        batchLines.Add("");

                        foreach (string csvPath in csvPaths)
                        {
                            string fname = System.IO.Path.GetFileName(csvPath);
                            try
                            {
                                var (rep, path) = LogReplayHarness.RunFile(csvPath, outDir);
                                lastOut = path;
                                totalV += rep.TotalViolations;
                                totalS += rep.TotalSteps;
                                if (rep.TotalViolations > 0) allOk = false;

                                string status = rep.TotalViolations == 0 ? "CLEAN" : "VIOLATIONS=" + rep.TotalViolations;
                                batchLines.Add(string.Format("  [{0}]  steps={1}  {2}  →  {3}",
                                    status, rep.TotalSteps, fname,
                                    System.IO.Path.GetFileName(path)));
                            }
                            catch (Exception ex)
                            {
                                allOk = false;
                                batchLines.Add(string.Format("  [ERROR]  {0}  →  {1}", fname, ex.Message));
                            }
                        }

                        batchLines.Add("");
                        batchLines.Add(string.Format("TOTAL  steps={0}  violations={1}  {2}",
                            totalS, totalV, allOk ? "ALL CLEAN" : "NEEDS REVIEW"));
                        batchLines.Add("=============================================================");

                        // Write batch summary only when multiple files were selected.
                        string batchPath = null;
                        if (csvPaths.Length > 1)
                        {
                            batchPath = System.IO.Path.Combine(outDir,
                                string.Format("ReplayBatchSummary_{0:yyyy-MM-dd_HH-mm-ss}.txt",
                                    DateTime.Now));
                            System.IO.File.WriteAllLines(batchPath, batchLines,
                                System.Text.Encoding.UTF8);
                        }

                        string openFile = batchPath ?? lastOut;
                        string summary  = csvPaths.Length == 1
                            ? string.Format("Replay complete · steps={0} · violations={1} · written to Desktop", totalS, totalV)
                            : string.Format("Batch done · {0} files · {1} total violations · summary on Desktop",
                                csvPaths.Length, totalV);

                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            replayBtn.IsEnabled = true;
                            integrityStatusLbl.Text       = summary;
                            integrityStatusLbl.Foreground = allOk
                                ? new SolidColorBrush(Color.FromRgb(120, 200, 130))
                                : new SolidColorBrush(Color.FromRgb(220, 180, 110));
                            if (openFile != null)
                            {
                                try { System.Diagnostics.Process.Start(openFile); } catch { }
                            }
                        }));
                    });
                }
                catch (Exception ex)
                {
                    integrityStatusLbl.Text       = "Replay launch failed: " + ex.Message;
                    integrityStatusLbl.Foreground = new SolidColorBrush(Color.FromRgb(220, 120, 110));
                }
            };
            devPanel.Children.Add(replayBtn);

            var fuzzBtn = new Button
            {
                Content             = "Run Property Fuzzer (1000 scenarios)",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(70, 70, 80)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = new FontFamily("Segoe UI"),
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
                Margin              = new Thickness(0, 8, 0, 0),
            };
            fuzzBtn.Click += (s, e) =>
            {
                fuzzBtn.IsEnabled = false;
                integrityStatusLbl.Text = "Fuzzing 1000 scenarios…";
                integrityStatusLbl.Foreground = FgSecondary;

                System.Threading.Tasks.Task.Run(() =>
                {
                    string summary; bool ok = false; string outPath = null;
                    try
                    {
                        string outDir = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                        var (rep, path) = PropertyFuzzer.RunAndWrite(1000, outDir);
                        outPath = path;
                        summary = string.Format(
                            "Fuzz complete · pass={0} · fail={1} · seed={2} · written to Desktop\\{3}",
                            rep.PassCount, rep.FailCount, rep.MasterSeed,
                            System.IO.Path.GetFileName(path));
                        ok = rep.FailCount == 0;
                    }
                    catch (Exception ex)
                    {
                        summary = "Fuzz failed: " + ex.Message;
                    }

                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        fuzzBtn.IsEnabled = true;
                        integrityStatusLbl.Text       = summary;
                        integrityStatusLbl.Foreground = ok
                            ? new SolidColorBrush(Color.FromRgb(120, 200, 130))
                            : new SolidColorBrush(Color.FromRgb(220, 120, 110));
                        if (outPath != null)
                        {
                            try { System.Diagnostics.Process.Start(outPath); } catch { }
                        }
                    }));
                });
            };
            devPanel.Children.Add(fuzzBtn);

            devPanel.Children.Add(integrityStatusLbl);
            stack.Children.Add(devPanel);

            scroll.Content = stack;
            return scroll;
        }

        // ── License page helpers ──────────────────────────────────────────────

        private static TextBlock MakeLicenseLabel(string text) => new TextBlock
        {
            Text       = text,
            FontSize   = 11,
            FontFamily = new FontFamily("Segoe UI"),
            FontWeight = FontWeights.SemiBold,
            Foreground = FgHint,
            Margin     = new Thickness(0, 0, 0, 2),
        };

        private static System.Windows.Controls.Button MakeLicenseButton(string label, bool accent = false)
        {
            return new System.Windows.Controls.Button
            {
                Content    = label,
                FontSize   = 12,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgPrimary,
                Background = accent
                    ? new SolidColorBrush(Color.FromRgb(10, 132, 255))
                    : BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(14, 7, 14, 7),
                Cursor          = Cursors.Hand,
            };
        }

        // =====================================================================
        // Page: Intelligence
        // =====================================================================

        private FrameworkElement CreateIntelligencePage()
        {
            try
            {
                var sessions = _historyStore?.Sessions
                    ?? new System.Collections.Generic.List<SessionHistoryEntry>();
                var source = new IntelligenceWindow(sessions);
                var body   = TransplantWindowBody(source);

                var dock = new DockPanel { LastChildFill = true };
                var bar  = BuildPageActionBar(
                    null, null,
                    "History →",
                    () => NavigateTo(HubPage.History));
                DockPanel.SetDock(bar, Dock.Top);
                dock.Children.Add(bar);
                dock.Children.Add(body);
                return dock;
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load PSI Intelligence.");
            }
        }

        // =====================================================================
        // Page: Journal (v1.2)
        // =====================================================================
        //
        // Design: passive, non-intrusive, zero mandatory input.  Every entry
        // is stamped with the current PSI / dominant dim / session P&L so the
        // trader cannot fully retcon their state later (evidence-anchored
        // recall — ARCHITECTURE.md §14.3).

        private TextBox    _journalNoteBox;
        private TextBox    _journalDayNoteBox;
        private StackPanel _journalEntriesList;
        private TextBlock  _journalDateLabel;
        private DateTime   _journalDateShown = DateTime.Today;

        // Reflection panel fields
        private TextBox    _reflWentWellBox;
        private TextBox    _reflImproveBox;
        private TextBox    _reflFocusBox;
        private Border     _reflectionPanel;

        private FrameworkElement CreateJournalPage()
        {
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };

            var root = new StackPanel { Margin = new Thickness(20, 20, 20, 20) };
            scroll.Content = root;

            // ── Title row ─────────────────────────────────────────────────────
            root.Children.Add(new TextBlock
            {
                Text       = "Journal",
                FontSize   = 18,
                FontWeight = FontWeights.Bold,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgPrimary,
            });
            root.Children.Add(new TextBlock
            {
                Text         = "Quick notes and emotion tags captured during the session are compiled here.  Nothing is mandatory.",
                FontSize     = 11,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 2, 0, 16),
            });

            // ── Date navigation row ───────────────────────────────────────────
            var dateNavRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 0, 0, 14),
            };

            var prevDayBtn = new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(5),
                Padding         = new Thickness(10, 5, 10, 5),
                Cursor          = Cursors.Hand,
                Child           = new TextBlock { Text = "◀", FontSize = 12, Foreground = FgSecondary,
                                                  FontFamily = new FontFamily("Segoe UI") },
            };

            _journalDateLabel = new TextBlock
            {
                FontSize            = 13,
                FontWeight          = FontWeights.SemiBold,
                FontFamily          = new FontFamily("Segoe UI"),
                Foreground          = FgPrimary,
                VerticalAlignment   = VerticalAlignment.Center,
                Margin              = new Thickness(10, 0, 10, 0),
                MinWidth            = 180,
                TextAlignment       = TextAlignment.Center,
            };

            var nextDayBtn = new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(5),
                Padding         = new Thickness(10, 5, 10, 5),
                Cursor          = Cursors.Hand,
                Child           = new TextBlock { Text = "▶", FontSize = 12, Foreground = FgSecondary,
                                                  FontFamily = new FontFamily("Segoe UI") },
            };

            var todayBtn = new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(5),
                Padding         = new Thickness(10, 5, 10, 5),
                Cursor          = Cursors.Hand,
                Margin          = new Thickness(8, 0, 0, 0),
                Child           = new TextBlock { Text = "Today", FontSize = 11, Foreground = FgSecondary,
                                                  FontFamily = new FontFamily("Segoe UI") },
            };

            dateNavRow.Children.Add(prevDayBtn);
            dateNavRow.Children.Add(_journalDateLabel);
            dateNavRow.Children.Add(nextDayBtn);
            dateNavRow.Children.Add(todayBtn);
            root.Children.Add(dateNavRow);

            // ── Day note area ─────────────────────────────────────────────────
            var dayNoteHeader = new Grid();
            dayNoteHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            dayNoteHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var dayNoteLabel = new TextBlock
            {
                Text              = "Day journal",
                FontSize          = 13,
                FontWeight        = FontWeights.SemiBold,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(0, 0, 0, 0),
            };
            Grid.SetColumn(dayNoteLabel, 0);
            dayNoteHeader.Children.Add(dayNoteLabel);

            // "Complete Journal" (auto-compile) button
            var compileBtn = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(30, 80, 50)),
                BorderBrush     = new SolidColorBrush(Color.FromRgb(48, 200, 100)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(5),
                Padding         = new Thickness(10, 4, 10, 4),
                Cursor          = Cursors.Hand,
                ToolTip         = "Auto-compile all today's quick notes, emotion tags and session stats into a draft journal. Review, edit, then save.",
                Child           = new TextBlock
                {
                    Text       = "✦ Complete Journal",
                    FontSize   = 11,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = new SolidColorBrush(Color.FromRgb(80, 230, 130)),
                    FontFamily = new FontFamily("Segoe UI"),
                },
            };
            Grid.SetColumn(compileBtn, 1);
            dayNoteHeader.Children.Add(compileBtn);

            dayNoteHeader.Margin = new Thickness(0, 0, 0, 6);
            root.Children.Add(dayNoteHeader);

            root.Children.Add(new TextBlock
            {
                Text         = "Compiled automatically or write freely. Saved per trading day — visible in History.",
                FontSize     = 10,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = FgHint,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 8),
            });

            _journalDayNoteBox = new TextBox
            {
                Background      = BgCard,
                Foreground      = FgPrimary,
                CaretBrush      = FgPrimary,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(10, 8, 10, 8),
                FontFamily      = new FontFamily("Consolas"),
                FontSize        = 11,
                AcceptsReturn   = true,
                TextWrapping    = TextWrapping.Wrap,
                MinHeight       = 130,
                MaxHeight       = 380,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            };
            root.Children.Add(_journalDayNoteBox);

            var saveDayBtn = BuildSimpleButton("Save journal", accent: true);
            saveDayBtn.Margin = new Thickness(0, 8, 0, 20);
            saveDayBtn.Click += (s, e) =>
            {
                if (_journalDayNoteBox == null) return;
                string txt  = _journalDayNoteBox.Text ?? "";
                DateTime dt = _journalDateShown;
                try { JournalStore.SaveDayNote(dt, txt); }
                catch { }
                saveDayBtn.Content   = "Saved ✓";
                saveDayBtn.IsEnabled = false;
                var t = new System.Windows.Threading.DispatcherTimer
                    { Interval = TimeSpan.FromMilliseconds(1200) };
                t.Tick += (_, __) =>
                {
                    saveDayBtn.Content   = "Save journal";
                    saveDayBtn.IsEnabled = true;
                    t.Stop();
                };
                t.Start();
            };
            root.Children.Add(saveDayBtn);

            // ── Divider ───────────────────────────────────────────────────────
            root.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 0, 0, 18),
            });

            // ── Quick emotion tags (live — always for today) ───────────────────
            root.Children.Add(new TextBlock
            {
                Text       = "Tag your mood",
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgPrimary,
                Margin     = new Thickness(0, 0, 0, 8),
            });
            var emotionRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 0, 0, 14),
            };
            emotionRow.Children.Add(BuildEmotionButton("😊 Great",     JournalEmotion.Calm));
            emotionRow.Children.Add(BuildEmotionButton("😐 Neutral",   JournalEmotion.Neutral));
            emotionRow.Children.Add(BuildEmotionButton("😤 Frustrated", JournalEmotion.Stressed));
            root.Children.Add(emotionRow);

            // ── Quick note input ──────────────────────────────────────────────
            root.Children.Add(new TextBlock
            {
                Text       = "Quick note",
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgPrimary,
                Margin     = new Thickness(0, 0, 0, 6),
            });

            _journalNoteBox = new TextBox
            {
                Background      = BgCard,
                Foreground      = FgPrimary,
                CaretBrush      = FgPrimary,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(10, 8, 10, 8),
                FontFamily      = new FontFamily("Segoe UI"),
                FontSize        = 12,
                AcceptsReturn   = false,
                MinHeight       = 34,
            };
            _journalNoteBox.KeyDown += (s, e) =>
            {
                if (e.Key == Key.Enter)
                {
                    e.Handled = true;
                    SubmitQuickNote();
                }
            };
            root.Children.Add(_journalNoteBox);

            var actionRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 8, 0, 16),
            };
            var addBtn = BuildSimpleButton("Add note", accent: true);
            addBtn.Click += (s, e) => SubmitQuickNote();
            actionRow.Children.Add(addBtn);
            root.Children.Add(actionRow);

            // ── Session Reflection (collapsible) ──────────────────────────────
            var reflToggleRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 0, 0, 8),
                Cursor      = Cursors.Hand,
            };
            var reflChevron = new TextBlock
            {
                Text       = "▼",
                FontSize   = 9,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgHint,
                VerticalAlignment = VerticalAlignment.Center,
                Margin     = new Thickness(0, 0, 6, 0),
            };
            reflToggleRow.Children.Add(reflChevron);
            reflToggleRow.Children.Add(new TextBlock
            {
                Text       = "Session reflection",
                FontSize   = 11,
                FontWeight = FontWeights.SemiBold,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            });
            root.Children.Add(reflToggleRow);

            // Build the expandable reflection panel — styling matches _journalNoteBox exactly
            TextBox MakeReflBox() => new TextBox
            {
                Background      = BgCard,
                Foreground      = FgPrimary,
                CaretBrush      = FgPrimary,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(10, 8, 10, 8),
                FontFamily      = new FontFamily("Segoe UI"),
                FontSize        = 12,
                AcceptsReturn   = true,
                TextWrapping    = TextWrapping.Wrap,
                MinHeight       = 46,
                MaxHeight       = 120,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            };
            _reflWentWellBox = MakeReflBox();
            _reflImproveBox  = MakeReflBox();
            _reflFocusBox    = MakeReflBox();

            TextBlock ReflLabel(string text, bool first = false) => new TextBlock
            {
                Text       = text,
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgPrimary,
                Margin     = new Thickness(0, first ? 0 : 12, 0, 6),
            };

            var reflInner = new StackPanel();
            reflInner.Children.Add(ReflLabel("What went well:", first: true));
            reflInner.Children.Add(_reflWentWellBox);
            reflInner.Children.Add(ReflLabel("What to improve:"));
            reflInner.Children.Add(_reflImproveBox);
            reflInner.Children.Add(ReflLabel("Focus for next session:"));
            reflInner.Children.Add(_reflFocusBox);

            var saveReflBtn = BuildSimpleButton("Save reflection", accent: false);
            saveReflBtn.Margin = new Thickness(0, 10, 0, 0);
            saveReflBtn.Click += (s, e) =>
            {
                try
                {
                    JournalStore.SaveReflection(
                        _journalDateShown,
                        _reflWentWellBox?.Text ?? "",
                        _reflImproveBox?.Text  ?? "",
                        _reflFocusBox?.Text    ?? "");
                }
                catch { }
                saveReflBtn.Content   = "Saved ✓";
                saveReflBtn.IsEnabled = false;
                var t2 = new System.Windows.Threading.DispatcherTimer
                    { Interval = TimeSpan.FromMilliseconds(1200) };
                t2.Tick += (__, ___) =>
                {
                    saveReflBtn.Content   = "Save reflection";
                    saveReflBtn.IsEnabled = true;
                    t2.Stop();
                };
                t2.Start();
            };
            reflInner.Children.Add(saveReflBtn);

            _reflectionPanel = new Border
            {
                Visibility      = Visibility.Visible,
                Background      = Brushes.Transparent,
                BorderThickness = new Thickness(0),
                Margin          = new Thickness(0, 0, 0, 16),
                Child           = reflInner,
            };
            root.Children.Add(_reflectionPanel);

            // Toggle expand/collapse
            reflToggleRow.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                bool show = _reflectionPanel.Visibility != Visibility.Visible;
                _reflectionPanel.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
                reflChevron.Text = show ? "▼" : "▶";
            };

            // ── Entries for selected date ──────────────────────────────────────
            root.Children.Add(new TextBlock
            {
                Text       = "Session entries",
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgPrimary,
                Margin     = new Thickness(0, 18, 0, 8),
            });

            _journalEntriesList = new StackPanel();
            root.Children.Add(_journalEntriesList);

            // ── Wire date navigation ──────────────────────────────────────────
            Action refreshJournalDate = () =>
            {
                // Update date label
                bool isToday = _journalDateShown.Date == DateTime.Today.Date;
                _journalDateLabel.Text = isToday
                    ? "Today  ·  " + _journalDateShown.ToString("MMM d")
                    : _journalDateShown.ToString("ddd, MMM d, yyyy");

                // Load day note for selected date
                string existing = "";
                try { existing = JournalStore.LoadDayNote(_journalDateShown); } catch { }
                if (_journalDayNoteBox != null)
                    _journalDayNoteBox.Text = existing ?? "";

                // Load reflection fields for selected date
                try
                {
                    var (well, improve, focus) = JournalStore.LoadReflection(_journalDateShown);
                    if (_reflWentWellBox != null) _reflWentWellBox.Text = well    ?? "";
                    if (_reflImproveBox  != null) _reflImproveBox.Text  = improve ?? "";
                    if (_reflFocusBox    != null) _reflFocusBox.Text    = focus   ?? "";
                }
                catch { }

                // Refresh entries list for selected date
                RefreshJournalEntries(_journalDateShown);

                // Disable "next" when already at today
                ((TextBlock)nextDayBtn.Child).Foreground =
                    _journalDateShown.Date >= DateTime.Today.Date ? FgHint : FgSecondary;
                nextDayBtn.Cursor =
                    _journalDateShown.Date >= DateTime.Today.Date
                    ? Cursors.Arrow : Cursors.Hand;
            };

            prevDayBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                _journalDateShown = _journalDateShown.AddDays(-1);
                refreshJournalDate();
            };
            nextDayBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                if (_journalDateShown.Date < DateTime.Today.Date)
                {
                    _journalDateShown = _journalDateShown.AddDays(1);
                    refreshJournalDate();
                }
            };
            todayBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                _journalDateShown = DateTime.Today;
                refreshJournalDate();
            };

            // ── Wire Complete Journal (auto-compile) ──────────────────────────
            compileBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                DateTime dt = _journalDateShown;

                double psi       = _sessionData != null ? _sessionData.FinalPsi    : 100.0;
                int    trades    = _sessionData != null ? _sessionData.TotalTrades  : 0;
                double pnl       = _sessionData != null ? _sessionData.TotalPnl     : 0.0;
                double winRate   = (_sessionData != null && _sessionData.TotalTrades > 0)
                                   ? (double)_sessionData.WinTrades / _sessionData.TotalTrades
                                   : -1.0;
                string dominantDim = _monitor != null ? (_monitor.GetDominantDimLabel() ?? "") : "";

                string compiled = JournalStore.CompileSessionJournal(
                    dt, psi, trades, pnl, winRate, dominantDim);

                if (_journalDayNoteBox != null)
                    _journalDayNoteBox.Text = compiled;

                // Visual feedback on the button
                var lbl = (TextBlock)compileBtn.Child;
                string origText = lbl.Text;
                lbl.Text = "✓ Draft ready — review & save";
                var t = new System.Windows.Threading.DispatcherTimer
                    { Interval = TimeSpan.FromSeconds(3) };
                t.Tick += (__, ___) => { lbl.Text = origText; t.Stop(); };
                t.Start();
            };

            // Initial population
            refreshJournalDate();

            return scroll;
        }

        private Border BuildEmotionButton(string label, JournalEmotion em)
        {
            var textBlock = new TextBlock
            {
                Text              = label,
                FontSize          = 12,
                FontFamily        = new FontFamily("Segoe UI"),
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            };

            var border = new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(16),
                Padding         = new Thickness(12, 6, 14, 6),
                Margin          = new Thickness(0, 0, 8, 0),
                Cursor          = Cursors.Hand,
                Child           = textBlock,
            };
            border.MouseEnter += (_, __) => border.Background = BgNavHover;
            border.MouseLeave += (_, __) => border.Background = BgCard;
            border.MouseLeftButtonUp += (_, __) =>
            {
                if (_monitor == null) return;
                _monitor.RecordJournalEntry(JournalKind.EmotionTag, em, null);
                RefreshJournalEntries();
            };
            return border;
        }

        private Border BuildSnapshotCard()
        {
            double psi = _sessionData != null ? _sessionData.FinalPsi : 100.0;
            double pnl = _sessionData != null ? _sessionData.TotalPnl : 0.0;
            string dom = _monitor != null ? (_monitor.GetDominantDimLabel() ?? "none") : "-";

            var panel = new StackPanel { Orientation = Orientation.Horizontal };
            panel.Children.Add(MakeKv("PSI",      psi.ToString("F1")));
            panel.Children.Add(MakeKv("Dominant", dom));
            panel.Children.Add(MakeKv("Session P&L", (pnl >= 0 ? "+" : "") + pnl.ToString("F2")));

            return new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(8),
                Padding         = new Thickness(12, 8, 12, 8),
                Child           = panel,
            };
        }

        private static UIElement MakeKv(string key, string value)
        {
            var stack = new StackPanel { Margin = new Thickness(0, 0, 18, 0) };
            stack.Children.Add(new TextBlock
            {
                Text       = key,
                FontSize   = 10,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgHint,
            });
            stack.Children.Add(new TextBlock
            {
                Text       = value,
                FontSize   = 13,
                FontWeight = FontWeights.SemiBold,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgPrimary,
            });
            return stack;
        }

        private void SubmitQuickNote()
        {
            if (_journalNoteBox == null || _monitor == null) return;
            string text = (_journalNoteBox.Text ?? "").Trim();
            if (string.IsNullOrEmpty(text)) return;

            _monitor.RecordJournalEntry(JournalKind.QuickNote, JournalEmotion.None, text);
            _journalNoteBox.Text = "";
            RefreshJournalEntries(_journalDateShown);
        }


        // date parameter: show entries for that specific date (null = recent 40 across all dates)
        private void RefreshJournalEntries(DateTime? date = null)
        {
            if (_journalEntriesList == null) return;
            _journalEntriesList.Children.Clear();

            List<JournalEntry> entries;
            try
            {
                entries = date.HasValue
                    ? JournalStore.Recent(limit: 200, sessionDate: date.Value)
                    : JournalStore.Recent(limit: 40);
            }
            catch { entries = new List<JournalEntry>(); }

            if (entries.Count == 0)
            {
                _journalEntriesList.Children.Add(new TextBlock
                {
                    Text       = date.HasValue
                                 ? "No quick notes or emotion tags recorded for this session."
                                 : "No entries yet.  Tag an emotion or write one line above.",
                    FontSize   = 11,
                    FontFamily = new FontFamily("Segoe UI"),
                    Foreground = FgHint,
                    FontStyle  = FontStyles.Italic,
                });
                return;
            }

            for (int i = entries.Count - 1; i >= 0; i--)
                _journalEntriesList.Children.Add(BuildJournalRow(entries[i]));
        }

        private Border BuildJournalRow(JournalEntry e)
        {
            bool isSystem = string.Equals(e.Kind, "SessionSummary", StringComparison.OrdinalIgnoreCase);

            // User-friendly kind label
            string kindLabel;
            if (isSystem)
                kindLabel = "End of session";
            else if (string.Equals(e.Kind, "QuickNote", StringComparison.OrdinalIgnoreCase))
                kindLabel = "Note";
            else if (string.Equals(e.Kind, "EmotionTag", StringComparison.OrdinalIgnoreCase))
            {
                string em = e.EmotionString ?? "";
                if (string.Equals(em, "Calm",     StringComparison.OrdinalIgnoreCase)) kindLabel = "Calm";
                else if (string.Equals(em, "Neutral",  StringComparison.OrdinalIgnoreCase)) kindLabel = "Neutral";
                else if (string.Equals(em, "Stressed", StringComparison.OrdinalIgnoreCase)) kindLabel = "Stressed";
                else kindLabel = em;
            }
            else
                kindLabel = e.Kind ?? "";

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(96) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Time + kind (left col)
            var leftStack = new StackPanel();
            leftStack.Children.Add(new TextBlock
            {
                Text       = e.Timestamp.ToString("HH:mm:ss"),
                FontSize   = 11,
                FontFamily = new FontFamily("Consolas"),
                Foreground = isSystem ? FgHint : FgSecondary,
            });
            leftStack.Children.Add(new TextBlock
            {
                Text       = kindLabel,
                FontSize   = 10,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = isSystem ? FgHint : FgSecondary,
            });
            Grid.SetColumn(leftStack, 0);
            grid.Children.Add(leftStack);

            // Note + context (right col)
            var midStack = new StackPanel();
            midStack.Children.Add(new TextBlock
            {
                Text         = isSystem && string.IsNullOrWhiteSpace(e.Note)
                                   ? "(auto)"
                                   : string.IsNullOrWhiteSpace(e.Note) ? "(no note)" : e.Note,
                FontSize     = isSystem ? 11 : 12,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = isSystem ? FgHint
                             : string.IsNullOrWhiteSpace(e.Note) ? FgHint : FgPrimary,
                TextWrapping = TextWrapping.Wrap,
                FontStyle    = isSystem ? FontStyles.Italic : FontStyles.Normal,
            });
            midStack.Children.Add(new TextBlock
            {
                Text = string.Format("PSI {0:F0}  ·  {1}  ·  {2}{3:F2}",
                                     e.Psi,
                                     string.IsNullOrEmpty(e.DominantDim) ? "—" : e.DominantDim,
                                     e.SessionPnl >= 0 ? "+" : "",
                                     e.SessionPnl),
                FontSize   = 9,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgHint,
                Margin     = new Thickness(0, 2, 0, 0),
            });
            Grid.SetColumn(midStack, 1);
            grid.Children.Add(midStack);

            return new Border
            {
                Background      = isSystem
                    ? new SolidColorBrush(Color.FromArgb(15, 255, 255, 255))
                    : BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb((byte)(isSystem ? 15 : 30), 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(6),
                Padding         = new Thickness(10, 7, 10, 7),
                Margin          = new Thickness(0, 0, 0, 5),
                Child           = grid,
            };
        }

        private Button BuildSimpleButton(string label, bool accent)
        {
            return new Button
            {
                Content         = label,
                FontSize        = 12,
                FontFamily      = new FontFamily("Segoe UI"),
                Foreground      = FgPrimary,
                Background      = accent
                    ? new SolidColorBrush(Color.FromRgb(10, 132, 255))
                    : BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(14, 7, 14, 7),
                Cursor          = Cursors.Hand,
            };
        }

        // =====================================================================
        // Page: Guard
        // =====================================================================

        private FrameworkElement CreateGuardPage()
        {
            var ge = _guardEngine;

            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };
            var root = new StackPanel { Margin = new Thickness(20, 20, 20, 20) };
            scroll.Content = root;

            // ── Header row: title + master toggle ─────────────────────────────
            var headerRow = new Grid();
            headerRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            headerRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var titleStack = new StackPanel();
            titleStack.Children.Add(new TextBlock
            {
                Text       = "Guard",
                FontSize   = 18,
                FontWeight = FontWeights.Bold,
                FontFamily = new FontFamily("Segoe UI"),
                Foreground = FgPrimary,
            });
            titleStack.Children.Add(new TextBlock
            {
                Text         = "Rules you set when calm, enforced when you're not.",
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 11,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 3, 0, 0),
            });
            Grid.SetColumn(titleStack, 0);

            bool masterOn = ge?.MasterEnabled ?? true;
            var masterToggle = MakeToggleBtn(masterOn, "Guard ON", "Guard OFF");
            masterToggle.Margin = new Thickness(8, 0, 0, 0);
            Grid.SetColumn(masterToggle, 1);
            masterToggle.Tag = (bool?)masterOn;
            masterToggle.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                bool next = !(bool)(masterToggle.Tag ?? false);
                masterToggle.Tag = (bool?)next;
                UpdateToggleBtn(masterToggle, next, "Guard ON", "Guard OFF");
                if (ge != null) ge.MasterEnabled = next;
            };

            headerRow.Children.Add(titleStack);
            headerRow.Children.Add(masterToggle);
            root.Children.Add(headerRow);

            // Divider
            root.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromRgb(50, 50, 54)),
                Margin     = new Thickness(0, 16, 0, 16),
            });

            // ── My Commitments label ──────────────────────────────────────────
            root.Children.Add(new TextBlock
            {
                Text       = "My Rules",
                FontFamily = new FontFamily("Segoe UI"),
                FontSize   = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgPrimary,
                Margin     = new Thickness(0, 0, 0, 10),
            });

            // ── Rules list ────────────────────────────────────────────────────
            var rulesPanel = new StackPanel();
            root.Children.Add(rulesPanel);

            Action refreshList = null;
            refreshList = () =>
            {
                rulesPanel.Children.Clear();
                var rules = ge?.Rules ?? new List<GuardRule>().AsReadOnly();
                if (rules.Count == 0)
                {
                    // First-run guidance card
                    var guideCard = new Border
                    {
                        Background      = new SolidColorBrush(Color.FromArgb(30, 10, 132, 255)),
                        CornerRadius    = new CornerRadius(8),
                        Padding         = new Thickness(14, 12, 14, 14),
                        BorderBrush     = new SolidColorBrush(Color.FromArgb(60, 10, 132, 255)),
                        BorderThickness = new Thickness(1),
                        Margin          = new Thickness(0, 0, 0, 16),
                    };
                    var guideStack = new StackPanel();
                    guideStack.Children.Add(new TextBlock
                    {
                        Text         = "No rules yet",
                        FontSize     = 12,
                        FontFamily   = new FontFamily("Segoe UI"),
                        FontWeight   = FontWeights.SemiBold,
                        Foreground   = FgPrimary,
                        Margin       = new Thickness(0, 0, 0, 6),
                    });
                    guideStack.Children.Add(new TextBlock
                    {
                        Text         = "Add a rule to protect yourself when emotion takes over. Example:",
                        FontSize     = 11,
                        FontFamily   = new FontFamily("Segoe UI"),
                        Foreground   = FgSecondary,
                        TextWrapping = TextWrapping.Wrap,
                        Margin       = new Thickness(0, 0, 0, 6),
                    });
                    guideStack.Children.Add(new TextBlock
                    {
                        Text         = "  When PSI < 70  →  Notify me in the HUD",
                        FontSize     = 11,
                        FontFamily   = new FontFamily("Consolas"),
                        Foreground   = FgAccent,
                        Margin       = new Thickness(0, 0, 0, 0),
                    });
                    guideCard.Child = guideStack;
                    rulesPanel.Children.Add(guideCard);
                }
                else
                {
                    foreach (var r in rules)
                    {
                        var ruleCopy = r;
                        rulesPanel.Children.Add(BuildRuleCard(ruleCopy, ge, refreshList));
                    }
                }
            };
            refreshList();

            // ── Add commitment button ─────────────────────────────────────────
            var addBtn = MakeActionBtn("＋  Add Commitment", FgAccent);
            addBtn.Margin = new Thickness(0, 10, 0, 0);
            addBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                var newRule = new GuardRule { ConfirmationSeconds = 90 };
                var editor = new GuardRuleEditorWindow(newRule, isNew: true, ge, refreshList);
                editor.Show();
            };
            root.Children.Add(addBtn);

            // ── Emergency Override section ────────────────────────────────────
            root.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromRgb(50, 50, 54)),
                Margin     = new Thickness(0, 28, 0, 16),
            });

            var emergencyCard = new Border
            {
                Background    = new SolidColorBrush(Color.FromRgb(50, 22, 22)),
                CornerRadius  = new CornerRadius(8),
                Padding       = new Thickness(16, 14, 16, 14),
                BorderBrush   = new SolidColorBrush(Color.FromRgb(100, 40, 40)),
                BorderThickness = new Thickness(1),
            };
            var emergStack = new StackPanel();

            emergStack.Children.Add(new TextBlock
            {
                Text       = "⚠  Emergency Override",
                FontFamily = new FontFamily("Segoe UI"),
                FontSize   = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(255, 120, 80)),
                Margin     = new Thickness(0, 0, 0, 6),
            });
            emergStack.Children.Add(new TextBlock
            {
                Text         = "Use only if Guard is malfunctioning while you have open positions. " +
                               "Clears all active Guard states without deleting your rules. This action is logged.",
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 11,
                Foreground   = new SolidColorBrush(Color.FromRgb(190, 140, 130)),
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 12),
            });

            var overrideBtn = MakeActionBtn("Force Reset Guard", new SolidColorBrush(Color.FromRgb(180, 60, 40)));
            overrideBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                ShowEmergencyOverrideDialog();
            };
            emergStack.Children.Add(overrideBtn);
            emergencyCard.Child = emergStack;
            root.Children.Add(emergencyCard);

            return scroll;
        }

        private void ShowEmergencyOverrideDialog()
        {
            ShowCountdownConfirmDialog(
                "⚠  Emergency Override",
                "This will clear all active Guard states.\n\n" +
                "You set these rules to protect yourself.\n" +
                "Take a moment — the reset will apply automatically.",
                20,
                () =>
                {
                    _monitor?.ForceResetGuard();
                    NinjaTrader.NinjaScript.NinjaScript.Log(
                        "[Guard] Emergency Override applied by user.", NinjaTrader.Cbi.LogLevel.Warning);
                });
        }

        // ── Reusable countdown-confirm dialog ─────────────────────────────────
        // Shows a modal-ish (Topmost) chromeless dark window with a large countdown
        // number and a Cancel button.  If the user does nothing, `onConfirm` fires
        // after `countdownSec` seconds.  Cancelling closes the window silently.
        //
        // Used for all high-risk destructive actions (Emergency Override, Clear
        // History, Reset Baseline) to introduce a mandatory cooling-off pause that
        // cannot be bypassed by mindlessly clicking through a confirmation dialog.
        private void ShowCountdownConfirmDialog(string title, string description,
                                                int countdownSec, Action onConfirm)
        {
            var win = new Window
            {
                WindowStyle           = WindowStyle.None,
                AllowsTransparency    = true,
                Background            = Brushes.Transparent,
                SizeToContent         = SizeToContent.Height,
                Width                 = 440,
                ResizeMode            = ResizeMode.NoResize,
                Topmost               = true,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
            };

            var card = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(22, 14, 14)),
                CornerRadius    = new CornerRadius(12),
                BorderBrush     = new SolidColorBrush(Color.FromRgb(120, 38, 38)),
                BorderThickness = new Thickness(1),
                Margin          = new Thickness(8),
            };

            var stack = new StackPanel { Margin = new Thickness(28, 24, 28, 24) };

            stack.Children.Add(new TextBlock
            {
                Text       = title,
                Foreground = new SolidColorBrush(Color.FromRgb(255, 100, 60)),
                FontFamily = new FontFamily("Segoe UI"),
                FontSize   = 15,
                FontWeight = FontWeights.SemiBold,
                Margin     = new Thickness(0, 0, 0, 12),
            });

            stack.Children.Add(new TextBlock
            {
                Text         = description,
                Foreground   = new SolidColorBrush(Color.FromRgb(200, 150, 140)),
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 12,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 22),
            });

            var countdownBlock = new TextBlock
            {
                Text                = countdownSec.ToString(),
                Foreground          = new SolidColorBrush(Color.FromRgb(255, 140, 60)),
                FontFamily          = new FontFamily("Consolas"),
                FontSize            = 56,
                FontWeight          = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 6),
            };
            stack.Children.Add(countdownBlock);

            stack.Children.Add(new TextBlock
            {
                Text                = "Taking effect automatically…",
                Foreground          = new SolidColorBrush(Color.FromRgb(130, 100, 90)),
                FontFamily          = new FontFamily("Segoe UI"),
                FontSize            = 11,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 22),
            });

            var cancelBorder = new Border
            {
                Background          = new SolidColorBrush(Color.FromRgb(38, 34, 34)),
                CornerRadius        = new CornerRadius(6),
                Padding             = new Thickness(20, 8, 20, 8),
                Cursor              = Cursors.Hand,
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            cancelBorder.Child = new TextBlock
            {
                Text       = "Cancel",
                Foreground = new SolidColorBrush(Color.FromRgb(180, 155, 150)),
                FontFamily = new FontFamily("Segoe UI"),
                FontSize   = 12,
            };
            stack.Children.Add(cancelBorder);

            card.Child  = stack;
            win.Content = card;

            bool cancelled = false;
            cancelBorder.MouseLeftButtonDown += (_, __) => { cancelled = true; win.Close(); };

            int remaining = countdownSec;
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            timer.Tick += (_, __) =>
            {
                remaining--;
                if (remaining <= 0)
                {
                    timer.Stop();
                    if (!cancelled)
                    {
                        win.Close();
                        onConfirm?.Invoke();
                    }
                    return;
                }
                countdownBlock.Text = remaining.ToString();
            };

            win.Closed += (_, __) => timer.Stop();
            win.Show();
            timer.Start();
        }

        private Border BuildRuleCard(GuardRule rule, GuardEngine ge, Action refresh)
        {
            // ── Card background ───────────────────────────────────────────────
            var card = new Border
            {
                Background    = BgCard,
                CornerRadius  = new CornerRadius(8),
                Margin        = new Thickness(0, 0, 0, 10),
                Padding       = new Thickness(16, 12, 16, 12),
            };
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            card.Child = grid;

            // ── Left: rule summary ────────────────────────────────────────────
            var left = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            Grid.SetColumn(left, 0);

            // Name
            left.Children.Add(new TextBlock
            {
                Text       = rule.Name,
                FontFamily = new FontFamily("Segoe UI"),
                FontSize   = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = rule.Enabled ? FgPrimary : FgHint,
            });

            // Condition summary
            var condSummary = BuildConditionSummary(rule);
            left.Children.Add(new TextBlock
            {
                Text         = condSummary,
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 11,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 3, 0, 0),
            });

            // Action badge
            left.Children.Add(new TextBlock
            {
                Text       = "→  " + FormatAction(rule),
                FontFamily = new FontFamily("Segoe UI"),
                FontSize   = 11,
                Foreground = new SolidColorBrush(Color.FromRgb(10, 132, 255)),
                Margin     = new Thickness(0, 3, 0, 0),
            });

            grid.Children.Add(left);

            // ── Right: buttons ────────────────────────────────────────────────
            var btnStack = new StackPanel
            {
                Orientation       = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(12, 0, 0, 0),
            };
            Grid.SetColumn(btnStack, 1);

            // ON/OFF toggle
            var toggle = MakeToggleBtn(rule.Enabled, "ON", "OFF");
            toggle.Margin = new Thickness(0, 0, 8, 0);
            toggle.Tag = (bool?)rule.Enabled;
            toggle.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                rule.Enabled = !rule.Enabled;
                toggle.Tag = (bool?)rule.Enabled;
                UpdateToggleBtn(toggle, rule.Enabled, "ON", "OFF");
                ge?.UpdateRule(rule);
                // Update name colour
                if (left.Children.Count > 0 && left.Children[0] is TextBlock nameTb)
                    nameTb.Foreground = rule.Enabled ? FgPrimary : FgHint;
            };
            btnStack.Children.Add(toggle);

            // Edit button
            var editBtn = MakeIconBtn("✎", "Edit");
            editBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                var editor = new GuardRuleEditorWindow(rule, isNew: false, ge, refresh);
                editor.Show();
            };
            btnStack.Children.Add(editBtn);

            // Delete button
            var delBtn = MakeIconBtn("✕", "Delete");
            delBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                ge?.DeleteRule(rule.Id);
                refresh?.Invoke();
            };
            btnStack.Children.Add(delBtn);

            grid.Children.Add(btnStack);
            return card;
        }

        private static string BuildConditionSummary(GuardRule rule)
        {
            if (rule.Conditions.Count == 0) return "(no conditions)";
            string logic = rule.Logic == GuardConditionLogic.All ? " AND " : " OR ";
            var parts = new List<string>();
            foreach (var c in rule.Conditions)
            {
                switch (c.Type)
                {
                    case GuardConditionType.PsiBelow:
                        parts.Add(string.Format("PSI < {0}", c.Threshold)); break;
                    case GuardConditionType.ConsecutiveLossesAtLeast:
                        parts.Add(string.Format("Consecutive losses \u2265 {0}", c.Threshold)); break;
                    case GuardConditionType.SessionPnlBelow:
                        parts.Add(string.Format("Session P&L below \u2212${0}", c.Threshold)); break;
                    case GuardConditionType.SessionMinutesOver:
                        parts.Add(string.Format("Session time > {0} min", c.Threshold)); break;
                    case GuardConditionType.UnrealizedPnlBelow:
                        parts.Add(string.Format("Floating loss > ${0}", c.Threshold)); break;
                    case GuardConditionType.SingleTradeLossExceeds:
                        parts.Add(string.Format("Single trade loss > ${0}", c.Threshold)); break;
                    default:
                        parts.Add("?"); break;
                }
            }
            return string.Join(logic, parts);
        }

        private static string FormatAction(GuardRule rule)
        {
            switch (rule.Action)
            {
                case GuardActionType.Toast:
                    return "Notify";
                case GuardActionType.Acknowledge:
                    return string.IsNullOrWhiteSpace(rule.OverridePhrase)
                        ? "Acknowledge"
                        : "Acknowledge (phrase required)";
                case GuardActionType.Countdown:
                    return string.Format("Wait {0}s", rule.CountdownSeconds);
                case GuardActionType.RiskAlert:
                    return "Risk Alert (persistent)";
                case GuardActionType.Disconnect:
                {
                    int sec = rule.EffectiveConfirmationSeconds;
                    return sec > 0
                        ? string.Format("Disconnect {0} min (after {1} s)", rule.LockMinutes, sec)
                        : string.Format("Disconnect {0} min", rule.LockMinutes);
                }
                default:
                    return "?";
            }
        }

        private static Border MakeToggleBtn(bool isOn, string onText, string offText)
        {
            var tb = new TextBlock
            {
                Text              = isOn ? onText : offText,
                FontFamily        = new FontFamily("Segoe UI"),
                FontSize          = 11,
                FontWeight        = FontWeights.SemiBold,
                Foreground        = isOn
                                        ? new SolidColorBrush(Color.FromRgb(50, 220, 80))
                                        : new SolidColorBrush(Color.FromRgb(150, 150, 155)),
                VerticalAlignment = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Background    = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                CornerRadius  = new CornerRadius(4),
                Padding       = new Thickness(8, 3, 8, 3),
                Cursor        = Cursors.Hand,
                Child         = tb,
            };
            btn.MouseEnter += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255));
            btn.MouseLeave += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255));
            return btn;
        }

        private static void UpdateToggleBtn(Border btn, bool isOn, string onText, string offText)
        {
            if (btn.Child is TextBlock tb)
            {
                tb.Text       = isOn ? onText : offText;
                tb.Foreground = isOn
                                    ? new SolidColorBrush(Color.FromRgb(50, 220, 80))
                                    : new SolidColorBrush(Color.FromRgb(150, 150, 155));
            }
        }

        private static Border MakeIconBtn(string glyph, string tip)
        {
            var tb = new TextBlock
            {
                Text              = glyph,
                FontSize          = 14,
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Width         = 32,
                Height        = 28,
                Background    = Brushes.Transparent,
                CornerRadius  = new CornerRadius(4),
                Cursor        = Cursors.Hand,
                Child         = tb,
                ToolTip       = tip,
                Margin        = new Thickness(4, 0, 0, 0),
            };
            btn.MouseEnter += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255));
            btn.MouseLeave += (_, __) =>
                btn.Background = Brushes.Transparent;
            return btn;
        }

        private static Border MakeActionBtn(string text, Brush fg)
        {
            var tb = new TextBlock
            {
                Text              = text,
                FontFamily        = new FontFamily("Segoe UI"),
                FontSize          = 13,
                Foreground        = fg,
                VerticalAlignment = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Background   = new SolidColorBrush(Color.FromArgb(25, 10, 132, 255)),
                CornerRadius = new CornerRadius(6),
                Padding      = new Thickness(16, 8, 16, 8),
                Cursor       = Cursors.Hand,
                Child        = tb,
            };
            btn.MouseEnter += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(50, 10, 132, 255));
            btn.MouseLeave += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(25, 10, 132, 255));
            return btn;
        }

        // =====================================================================
        // Page: Settings
        // =====================================================================

        private FrameworkElement CreateSettingsPage()
        {
            // Refresh every time the page renders — accounts may have connected
            // or changed after the Hub was first opened.
            if (_accountsProvider != null)
                _availableAccounts = _accountsProvider() ?? _availableAccounts;

            try
            {
                var source = new ProfileSettingsWindow(_profile, _availableAccounts, _onError,
                                                       accountsProvider: _accountsProvider);
                var card   = TransplantSettingsBody(source);

                // Inject the Display section at the BOTTOM of the profile form StackPanel
                // (after ADVANCED) — display preferences are lowest-priority; users open
                // Settings to configure their trading parameters first.
                // Structure after transplant: Border → DockPanel → [bottomStack (Dock.Bottom),
                //                            ScrollViewer (Fill)] → form (StackPanel).
                var dock   = (card as Border)?.Child as DockPanel;
                var scroll = dock?.Children.OfType<ScrollViewer>().FirstOrDefault();
                var form   = scroll?.Content as StackPanel;
                if (form != null)
                    form.Children.Add(BuildDisplaySettingsSection());

                return card;
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load settings.");
            }
        }

        // ── Display Settings inline section ──────────────────────────────────
        // Visual style matches the ProfileSettingsWindow sections exactly:
        // same fonts, same muted secondary header, same field sizes.

        private FrameworkElement BuildDisplaySettingsSection()
        {
            var current = _monitor?.CurrentDisplaySettings ?? new DisplaySettings();

            // ── Reuse same palette as ProfileSettingsWindow ──────────────────
            var fgSecondary = new SolidColorBrush(Color.FromRgb(174, 174, 178));
            var fgPrimary   = new SolidColorBrush(Color.FromRgb(245, 245, 247));
            var fgHint      = new SolidColorBrush(Color.FromRgb( 99,  99, 102));
            var bgAccent    = Color.FromRgb(10, 132, 255);

            // Section header (same style as SectionRow in ProfileSettingsWindow)
            var header = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 20, 0, 8),
            };
            header.Children.Add(new TextBlock
            {
                Text              = "DISPLAY",
                FontSize          = 10,
                FontFamily        = new FontFamily("Segoe UI"),
                FontWeight        = FontWeights.SemiBold,
                Foreground        = fgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            });

            var section = new StackPanel();
            section.Children.Add(header);

            // ── Mode row ─────────────────────────────────────────────────────
            section.Children.Add(MakeDisplayLabel("Display Mode", fgSecondary));

            var modeOptions = new[]
            {
                (HudDisplayMode.Minimal,  "Minimal",  "Composure gauge only — no signal bars"),
                (HudDisplayMode.Standard, "Standard", "Gauge + dimmed signal bars (default)"),
                (HudDisplayMode.Full,     "Full",     "Gauge + all signal bars at full brightness"),
            };
            var selMode     = current.Mode;
            var modePills   = new Border[3];
            var modeRow     = MakeOptionRow();
            for (int i = 0; i < 3; i++)
            {
                int   idx = i;
                var   opt = modeOptions[i];
                var   pill = MakeOptionPill(opt.Item2, opt.Item3, opt.Item1 == selMode, bgAccent, fgPrimary, fgHint);
                modePills[i] = pill;
                pill.MouseLeftButtonDown += (_, __) =>
                {
                    selMode = opt.Item1;
                    for (int k = 0; k < 3; k++) SetPillSelected(modePills[k], k == idx, bgAccent);
                };
                modeRow.Children.Add(pill);
            }
            section.Children.Add(modeRow);

            // ── Pressure row ─────────────────────────────────────────────────
            section.Children.Add(MakeDisplayLabel("Stress indicator", fgSecondary));

            // The corner stress badge auto-shows when emotional pressure is high.
            // This selector controls whether a numeric readout also appears in the
            // SESSION stats row for traders who want a precise value.
            var pressureOptions = new[]
            {
                (HudPressureDisplay.GaugeRing, "Badge only",     "Small colored badge in the corner (default)"),
                (HudPressureDisplay.Both,      "Badge + number", "Badge + exact stress value in the stats row"),
                (HudPressureDisplay.Number,    "Number only",    "Stats row number only, no corner badge"),
            };
            var selPressure   = current.PressureDisplay;
            var pressurePills = new Border[3];
            var pressureRow   = MakeOptionRow();
            for (int i = 0; i < 3; i++)
            {
                int  idx = i;
                var  opt = pressureOptions[i];
                var  pill = MakeOptionPill(opt.Item2, opt.Item3, opt.Item1 == selPressure, bgAccent, fgPrimary, fgHint);
                pressurePills[i] = pill;
                pill.MouseLeftButtonDown += (_, __) =>
                {
                    selPressure = opt.Item1;
                    for (int k = 0; k < 3; k++) SetPillSelected(pressurePills[k], k == idx, bgAccent);
                };
                pressureRow.Children.Add(pill);
            }
            section.Children.Add(pressureRow);

            // ── Save button ───────────────────────────────────────────────────
            var saveLbl = new TextBlock
            {
                Text       = "Save",
                FontSize   = 10,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = Brushes.White,
                Padding    = new Thickness(0),
            };
            var saveBtn = new Border
            {
                Background        = new SolidColorBrush(bgAccent),
                CornerRadius      = new CornerRadius(5),
                Padding           = new Thickness(14, 5, 14, 5),
                Cursor            = Cursors.Hand,
                Margin            = new Thickness(0, 10, 0, 0),
                HorizontalAlignment = HorizontalAlignment.Left,
                Child             = saveLbl,
            };
            saveBtn.MouseLeftButtonDown += (_, __) =>
            {
                _monitor?.UpdateDisplaySettings(new DisplaySettings
                {
                    Mode            = selMode,
                    PressureDisplay = selPressure,
                });
                saveLbl.Text = "Saved \u2713";
                var t = new System.Windows.Threading.DispatcherTimer
                    { Interval = TimeSpan.FromSeconds(1.5) };
                t.Tick += (tt, ___) => { saveLbl.Text = "Save"; (tt as System.Windows.Threading.DispatcherTimer)?.Stop(); };
                t.Start();
            };
            section.Children.Add(saveBtn);

            // Bottom separator — same as between other sections
            section.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 16, 0, 0),
            });

            return section;
        }

        private static TextBlock MakeDisplayLabel(string text, Brush fg) => new TextBlock
        {
            Text       = text,
            FontSize   = 10,
            FontFamily = new FontFamily("Segoe UI"),
            Foreground = fg,
            Margin     = new Thickness(0, 6, 0, 5),
        };

        private static WrapPanel MakeOptionRow() => new WrapPanel
        {
            Orientation = Orientation.Horizontal,
            Margin      = new Thickness(0, 0, 0, 2),
        };

        private static Border MakeOptionPill(string title, string tip, bool selected,
                                             Color accent, Brush fgPrimary, Brush fgHint)
        {
            var inner = new StackPanel { Margin = new Thickness(10, 6, 10, 6) };
            inner.Children.Add(new TextBlock
            {
                Text       = title,
                FontSize   = 10,
                FontFamily = new FontFamily("Segoe UI"),
                FontWeight = FontWeights.SemiBold,
                Foreground = fgPrimary,
            });
            inner.Children.Add(new TextBlock
            {
                Text         = tip,
                FontSize     = 9,
                FontFamily   = new FontFamily("Segoe UI"),
                Foreground   = fgHint,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 1, 0, 0),
            });
            var pill = new Border
            {
                Child           = inner,
                Width           = 158,
                Margin          = new Thickness(0, 0, 8, 0),
                CornerRadius    = new CornerRadius(6),
                BorderThickness = new Thickness(1.5),
                Cursor          = Cursors.Hand,
                ToolTip         = tip,
            };
            SetPillSelected(pill, selected, accent);
            return pill;
        }

        private static void SetPillSelected(Border pill, bool selected, Color accent)
        {
            pill.Background  = selected
                ? new SolidColorBrush(Color.FromArgb(45, accent.R, accent.G, accent.B))
                : new SolidColorBrush(Color.FromArgb(18, 255, 255, 255));
            pill.BorderBrush = selected
                ? new SolidColorBrush(accent)
                : new SolidColorBrush(Color.FromArgb(35, 255, 255, 255));
        }

        /// <summary>
        /// ProfileSettingsWindow has a different structure:
        /// Content = Grid(outer) → [Border(card, col0 row0), resize zones]
        /// card → DockPanel → [titleBar(top), bottomStack(bottom), scroll(fill)]
        /// We extract the card, strip the title bar, and return it.
        /// </summary>
        private static FrameworkElement TransplantSettingsBody(ProfileSettingsWindow source)
        {
            var outer = source.Content as Grid;
            source.Content = null;
            if (outer == null) return MakeErrorBlock();

            // The card Border is the first child (column 0, row 0)
            Border card = null;
            foreach (UIElement child in outer.Children)
            {
                if (child is Border b && b.Child is DockPanel)
                {
                    card = b;
                    break;
                }
            }
            if (card == null) return MakeErrorBlock();

            outer.Children.Remove(card);

            var dock = card.Child as DockPanel;
            if (dock != null && dock.Children.Count > 0)
            {
                // Remove the title bar (first DockPanel.Top child)
                dock.Children.RemoveAt(0);
            }

            card.CornerRadius    = new CornerRadius(0);
            card.BorderThickness = new Thickness(0);
            card.Background      = Brushes.Transparent;

            return card;
        }

        // =====================================================================
        // Content transplant helper
        // =====================================================================

        /// <summary>
        /// Extracts the scrollable body from a standard-pattern window:
        ///   Content = Border(card) → Grid(root) → [header(row 0), scroll(row 1)]
        /// Strips the header and card styling, returning the body content.
        /// </summary>
        private static FrameworkElement TransplantWindowBody(Window source)
        {
            var card = source.Content as Border;
            source.Content = null;
            if (card == null) return MakeErrorBlock();

            var root = card.Child as Grid;
            if (root == null) return card;

            // Remove the header (first child, row 0)
            if (root.Children.Count >= 2 && root.RowDefinitions.Count >= 2)
            {
                root.Children.RemoveAt(0);
                root.RowDefinitions.RemoveAt(0);

                // Fix remaining children's row indices
                for (int i = 0; i < root.Children.Count; i++)
                    Grid.SetRow(root.Children[i], i);
            }

            card.CornerRadius    = new CornerRadius(0);
            card.BorderThickness = new Thickness(0);
            card.Background      = Brushes.Transparent;

            return card;
        }

        // =====================================================================
        // Placeholder / error helpers
        // =====================================================================

        private static FrameworkElement BuildEmptyPage(string icon, string title, string message)
        {
            var stack = new StackPanel
            {
                VerticalAlignment   = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(40),
            };

            stack.Children.Add(new TextBlock
            {
                Text                = icon,
                FontSize            = 40,
                Foreground          = FgHint,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 12),
            });

            stack.Children.Add(new TextBlock
            {
                Text                = title,
                FontSize            = 16,
                FontWeight          = FontWeights.SemiBold,
                Foreground          = FgPrimary,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 8),
            });

            stack.Children.Add(new TextBlock
            {
                Text                = message,
                FontSize            = 12,
                Foreground          = FgSecondary,
                TextWrapping        = TextWrapping.Wrap,
                TextAlignment       = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                MaxWidth            = 300,
            });

            return stack;
        }

        private static TextBlock MakeErrorBlock()
        {
            return new TextBlock
            {
                Text       = "Error loading page content.",
                Foreground = FgSecondary,
                FontSize   = 12,
                Margin     = new Thickness(20),
            };
        }
    }

    // =========================================================================
    // Guard Rule Editor Window
    // =========================================================================

    internal sealed class GuardRuleEditorWindow : Window
    {
        private readonly GuardRule   _rule;
        private readonly bool        _isNew;
        private readonly GuardEngine _engine;
        private readonly Action      _onSaved;

        // ── Palette (mirrors TradeMonitorHub exactly) ─────────────────────────
        private static readonly SolidColorBrush BgWin    = new SolidColorBrush(Color.FromRgb( 28,  28,  30));
        private static readonly SolidColorBrush BgCard   = new SolidColorBrush(Color.FromRgb( 38,  38,  40));
        private static readonly SolidColorBrush BgInput  = new SolidColorBrush(Color.FromRgb( 48,  48,  50));
        private static readonly SolidColorBrush BgHdr    = new SolidColorBrush(Color.FromRgb( 44,  44,  46));
        private static readonly SolidColorBrush BgSelOn  = new SolidColorBrush(Color.FromArgb( 40,  10, 132, 255));
        private static readonly SolidColorBrush BgSelOff = new SolidColorBrush(Color.FromArgb( 25, 255, 255, 255));
        private static readonly SolidColorBrush BdInput  = new SolidColorBrush(Color.FromRgb( 70,  70,  73));
        private static readonly SolidColorBrush FgPri    = new SolidColorBrush(Color.FromRgb(245, 245, 247));
        private static readonly SolidColorBrush FgSec    = new SolidColorBrush(Color.FromRgb(174, 174, 178));
        private static readonly SolidColorBrush FgHint   = new SolidColorBrush(Color.FromRgb( 99,  99, 102));
        private static readonly SolidColorBrush FgAcc    = new SolidColorBrush(Color.FromRgb( 10, 132, 255));
        private static readonly SolidColorBrush FgSelOn  = new SolidColorBrush(Color.FromRgb( 10, 132, 255));

        static GuardRuleEditorWindow()
        {
            BgWin.Freeze(); BgCard.Freeze(); BgInput.Freeze(); BgHdr.Freeze();
            BgSelOn.Freeze(); BgSelOff.Freeze(); BdInput.Freeze();
            FgPri.Freeze(); FgSec.Freeze(); FgHint.Freeze(); FgAcc.Freeze(); FgSelOn.Freeze();
        }

        private StackPanel _conditionsPanel;
        private string     _windowTitle;

        public GuardRuleEditorWindow(GuardRule rule, bool isNew, GuardEngine engine, Action onSaved)
        {
            _rule    = new GuardRule
            {
                Id               = rule.Id,
                Name             = rule.Name,
                Enabled          = rule.Enabled,
                Logic            = rule.Logic,
                Action           = rule.Action,
                CountdownSeconds = rule.CountdownSeconds,
                LockMinutes      = rule.LockMinutes,
                CustomMessage    = rule.CustomMessage,
                CooldownMinutes  = rule.CooldownMinutes,
                OverridePhrase   = rule.OverridePhrase,
                ConfirmationTicks   = rule.ConfirmationTicks,
                ConfirmationSeconds = rule.ConfirmationSeconds,
                Conditions       = new List<GuardCondition>(),
            };
            foreach (var c in rule.Conditions)
                _rule.Conditions.Add(new GuardCondition { Type = c.Type, Threshold = c.Threshold });

            _isNew       = isNew;
            _engine      = engine;
            _onSaved     = onSaved;
            _windowTitle = isNew ? "Guard — New Rule" : "Guard — Edit Rule";

            WindowStyle           = WindowStyle.None;
            AllowsTransparency    = false;
            Background            = new SolidColorBrush(Color.FromRgb(28, 28, 30));
            Width                 = 520;
            Height                = 700;
            MinWidth              = 440;
            MinHeight             = 500;
            ResizeMode            = ResizeMode.CanResize;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Topmost               = true;

            // WindowChrome removes the 1-px DWM border that Windows adds to all
            // non-transparent frameless windows, while still giving us OS-level
            // resize hit-testing on all four edges.
            System.Windows.Shell.WindowChrome.SetWindowChrome(this,
                new System.Windows.Shell.WindowChrome
                {
                    CaptionHeight         = 0,
                    ResizeBorderThickness = new Thickness(5),
                    GlassFrameThickness   = new Thickness(0),
                });

            Content = BuildShell();
        }

        // ── Outer shell: custom title bar + scrollable content ───────────────
        private FrameworkElement BuildShell()
        {
            var dock = new DockPanel { Background = BgWin };

            // Title bar
            var header = new Border
            {
                Background   = BgHdr,
                BorderBrush  = new SolidColorBrush(Color.FromRgb(55, 55, 58)),
                BorderThickness = new Thickness(0, 0, 0, 1),
                Padding      = new Thickness(16, 10, 10, 10),
            };
            DockPanel.SetDock(header, Dock.Top);

            var headerRow = new Grid();
            headerRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            headerRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var titleTb = new TextBlock
            {
                Text       = _windowTitle,
                FontFamily = new FontFamily("Segoe UI"),
                FontSize   = 14,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgPri,
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(titleTb, 0);

            // Drag support
            header.MouseLeftButtonDown += (_, e) =>
            {
                if (e.ButtonState == System.Windows.Input.MouseButtonState.Pressed)
                    DragMove();
            };

            var closeBtn = new Border
            {
                Width        = 28,
                Height       = 28,
                CornerRadius = new CornerRadius(4),
                Background   = Brushes.Transparent,
                Cursor       = Cursors.Hand,
                Child        = new TextBlock
                {
                    Text              = "✕",
                    FontSize          = 12,
                    Foreground        = FgSec,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                },
            };
            closeBtn.MouseEnter += (_, __) =>
                closeBtn.Background = new SolidColorBrush(Color.FromRgb(180, 50, 50));
            closeBtn.MouseLeave += (_, __) =>
                closeBtn.Background = Brushes.Transparent;
            closeBtn.MouseLeftButtonDown += (_, __) => Close();
            Grid.SetColumn(closeBtn, 1);

            headerRow.Children.Add(titleTb);
            headerRow.Children.Add(closeBtn);
            header.Child = headerRow;
            dock.Children.Add(header);

            // Scrollable content
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Background = BgWin,
            };
            dock.Children.Add(scroll);

            var root = new StackPanel { Margin = new Thickness(20, 16, 20, 20) };
            scroll.Content = root;
            BuildContent(root);
            return dock;
        }

        private void BuildContent(StackPanel root)
        {
            // ── Rule name ─────────────────────────────────────────────────────
            root.Children.Add(SectionLabel("Rule Name"));
            var nameBox = InputBox(_rule.Name);
            nameBox.TextChanged += (_, __) => _rule.Name = nameBox.Text;
            root.Children.Add(nameBox);

            // ── Condition logic ───────────────────────────────────────────────
            root.Children.Add(SectionLabel("Condition Logic", top: 16));

            var logicRow  = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 6, 0, 0) };
            Border allBtn = null, anyBtn = null;
            Action<GuardConditionLogic> selectLogic = chosen =>
            {
                _rule.Logic = chosen;
                UpdateSelBtn(allBtn, chosen == GuardConditionLogic.All);
                UpdateSelBtn(anyBtn, chosen == GuardConditionLogic.Any);
            };
            allBtn = SelBtn("ALL  (every condition must match)", _rule.Logic == GuardConditionLogic.All);
            anyBtn = SelBtn("ANY  (at least one must match)",    _rule.Logic == GuardConditionLogic.Any);
            allBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; selectLogic(GuardConditionLogic.All); };
            anyBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; selectLogic(GuardConditionLogic.Any); };
            logicRow.Children.Add(allBtn);
            logicRow.Children.Add(anyBtn);
            root.Children.Add(logicRow);

            // ── Conditions ────────────────────────────────────────────────────
            root.Children.Add(SectionLabel("Trigger Conditions", top: 16));
            _conditionsPanel = new StackPanel { Margin = new Thickness(0, 6, 0, 0) };
            root.Children.Add(_conditionsPanel);
            RefreshConditionsPanel();

            var addCondBtn = MiniBtn("＋  Add Condition");
            addCondBtn.Margin = new Thickness(0, 6, 0, 0);
            addCondBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                _rule.Conditions.Add(new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 60 });
                RefreshConditionsPanel();
            };
            root.Children.Add(addCondBtn);

            // ── Action ────────────────────────────────────────────────────────
            root.Children.Add(SectionLabel("Action  (choose one response when the rule fires)", top: 16));

            var actionDefs = new[]
            {
                (GuardActionType.Toast,
                 "Notify",
                 "Brief banner in the HUD corner. Informational only — no interruption."),
                (GuardActionType.Acknowledge,
                 "Acknowledge",
                 "Blocking dialog. You must type your commitment phrase (or click Acknowledged) to continue."),
                (GuardActionType.RiskAlert,
                 "Risk Alert",
                 "Persistent HUD warning banner until the condition clears. New entry fills trigger a one-click reminder."),
                (GuardActionType.Countdown,
                 "Forced Wait",
                 "Mandatory countdown timer. You cannot dismiss it early — the timer runs in full."),
                (GuardActionType.Disconnect,
                 "Disconnect Broker",
                 "Severs broker connection for the duration you set. Checks for open positions first — you can flatten before disconnect fires."),
            };

            var cdPanel   = new StackPanel { Visibility = _rule.Action == GuardActionType.Countdown   ? Visibility.Visible : Visibility.Collapsed };
            var discPanel = new StackPanel { Visibility = _rule.Action == GuardActionType.Disconnect  ? Visibility.Visible : Visibility.Collapsed };
            var ackPanel  = new StackPanel { Visibility = _rule.Action == GuardActionType.Acknowledge ? Visibility.Visible : Visibility.Collapsed };

            var actionRows = new Border[actionDefs.Length];
            Action<GuardActionType> selectAction = chosen =>
            {
                _rule.Action = chosen;
                for (int i = 0; i < actionDefs.Length; i++)
                    UpdateActionRow(actionRows[i], actionDefs[i].Item1 == chosen);
                cdPanel.Visibility   = chosen == GuardActionType.Countdown   ? Visibility.Visible : Visibility.Collapsed;
                discPanel.Visibility = chosen == GuardActionType.Disconnect  ? Visibility.Visible : Visibility.Collapsed;
                ackPanel.Visibility  = chosen == GuardActionType.Acknowledge ? Visibility.Visible : Visibility.Collapsed;
            };

            var actionStack = new StackPanel { Margin = new Thickness(0, 8, 0, 0) };
            for (int i = 0; i < actionDefs.Length; i++)
            {
                int ii  = i;
                var row = ActionRadioRow(actionDefs[i].Item2, actionDefs[i].Item3,
                                         _rule.Action == actionDefs[i].Item1);
                row.MouseLeftButtonDown += (_, e) => { e.Handled = true; selectAction(actionDefs[ii].Item1); };
                actionRows[i] = row;
                actionStack.Children.Add(row);
            }
            root.Children.Add(actionStack);

            // Acknowledge params
            ackPanel.Children.Add(SectionLabel("Commitment Phrase  (you must type this to dismiss)", top: 4));
            ackPanel.Children.Add(new TextBlock
            {
                Text         = "Write something meaningful — what would calm-you say to tilt-you?",
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 11,
                Foreground   = FgSec,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 2, 0, 4),
            });
            var phraseBox = new System.Windows.Controls.TextBox
            {
                Text            = _rule.OverridePhrase,
                AcceptsReturn   = false,
                TextWrapping    = TextWrapping.Wrap,
                Background      = BgInput,
                Foreground      = FgPri,
                CaretBrush      = FgPri,
                BorderThickness = new Thickness(1),
                BorderBrush     = BdInput,
                Padding         = new Thickness(8, 6, 8, 6),
                FontFamily      = new FontFamily("Segoe UI"),
                FontSize        = 12,
                Margin          = new Thickness(0, 0, 0, 2),
            };
            phraseBox.TextChanged += (_, __) => _rule.OverridePhrase = phraseBox.Text;
            ackPanel.Children.Add(phraseBox);
            ackPanel.Children.Add(new TextBlock
            {
                Text       = "Leave blank for a simple Acknowledged button.",
                FontFamily = new FontFamily("Segoe UI"),
                FontSize   = 10,
                Foreground = FgHint,
                Margin     = new Thickness(0, 2, 0, 0),
            });
            root.Children.Add(ackPanel);

            // Countdown params
            cdPanel.Children.Add(SectionLabel("Wait Duration (seconds)", top: 4));
            var cdBox = InputBox(_rule.CountdownSeconds.ToString());
            cdBox.TextChanged += (_, __) => { if (int.TryParse(cdBox.Text, out int v)) _rule.CountdownSeconds = Math.Max(5, v); };
            cdPanel.Children.Add(cdBox);
            root.Children.Add(cdPanel);

            // Disconnect params
            discPanel.Children.Add(SectionLabel("Disconnect duration (minutes)", top: 4));
            discPanel.Children.Add(new TextBlock
            {
                Text         = "How long the broker connection stays locked after this rule fires.",
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 11,
                Foreground   = FgSec,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 2, 0, 4),
            });
            var lockBox = InputBox(_rule.LockMinutes.ToString());
            lockBox.TextChanged += (_, __) => { if (int.TryParse(lockBox.Text, out int v)) _rule.LockMinutes = Math.Max(1, v); };
            discPanel.Children.Add(lockBox);
            discPanel.Children.Add(SectionLabel("Confirmation window (seconds)", top: 8));
            discPanel.Children.Add(new TextBlock
            {
                Text         = "The condition must stay continuously true for this many seconds before the Disconnect fires — prevents a single brief PSI dip from triggering a full disconnect. 90 seconds is the recommended default; 0 fires immediately.",
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 11,
                Foreground   = FgSec,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 2, 0, 4),
            });
            // Migrate the displayed value: prefer ConfirmationSeconds if set,
            // otherwise convert legacy ConfirmationTicks (×30 s) so users editing
            // an old rule see the equivalent seconds value, not the raw tick count.
            int initialSeconds = _rule.ConfirmationSeconds > 0
                ? _rule.ConfirmationSeconds
                : (_rule.ConfirmationTicks > 1 ? _rule.ConfirmationTicks * 30 : 90);
            var secondsBox = InputBox(initialSeconds.ToString());
            secondsBox.TextChanged += (_, __) =>
            {
                if (int.TryParse(secondsBox.Text, out int v))
                {
                    _rule.ConfirmationSeconds = Math.Max(0, v);
                    // Keep the legacy field in sync so older builds that still
                    // read ConfirmationTicks degrade gracefully (round up to ticks).
                    _rule.ConfirmationTicks = v <= 0 ? 1 : Math.Max(1, (v + 29) / 30);
                }
            };
            discPanel.Children.Add(secondsBox);
            root.Children.Add(discPanel);

            // ── Custom message ────────────────────────────────────────────────
            root.Children.Add(SectionLabel("Custom Message  (leave blank for default)", top: 16));
            var msgBox = new System.Windows.Controls.TextBox
            {
                Text            = _rule.CustomMessage,
                AcceptsReturn   = true,
                TextWrapping    = TextWrapping.Wrap,
                Height          = 56,
                Background      = BgInput,
                Foreground      = FgPri,
                CaretBrush      = FgPri,
                BorderThickness = new Thickness(1),
                BorderBrush     = BdInput,
                Padding         = new Thickness(8, 6, 8, 6),
                FontFamily      = new FontFamily("Segoe UI"),
                FontSize        = 12,
                Margin          = new Thickness(0, 6, 0, 0),
            };
            msgBox.TextChanged += (_, __) => _rule.CustomMessage = msgBox.Text;
            root.Children.Add(msgBox);

            // ── Cooldown ──────────────────────────────────────────────────────
            root.Children.Add(SectionLabel("Rule cooldown (minutes)  — minimum time before this rule can fire again", top: 16));
            var coolBox = InputBox(_rule.CooldownMinutes.ToString());
            coolBox.TextChanged += (_, __) => { if (int.TryParse(coolBox.Text, out int v)) _rule.CooldownMinutes = Math.Max(0, v); };
            root.Children.Add(coolBox);

            // ── Divider ───────────────────────────────────────────────────────
            root.Children.Add(new Border
            {
                Height          = 1,
                Background      = new SolidColorBrush(Color.FromRgb(55, 55, 58)),
                Margin          = new Thickness(0, 20, 0, 0),
            });

            // ── Save / Cancel ─────────────────────────────────────────────────
            var btns = new StackPanel
            {
                Orientation         = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin              = new Thickness(0, 14, 0, 0),
            };

            var cancelBtn = ActionBtn("Cancel", Color.FromRgb(55, 55, 58));
            cancelBtn.Click += (_, __) => Close();

            var saveBtn = ActionBtn("Save", Color.FromRgb(10, 132, 255));
            saveBtn.Click += (_, __) =>
            {
                if (_rule.Conditions.Count == 0)
                {
                    System.Windows.MessageBox.Show(
                        "Please add at least one condition.", "Guard",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                if (string.IsNullOrWhiteSpace(_rule.Name))
                    _rule.Name = "Unnamed Rule";

                if (_isNew) _engine?.AddRule(_rule);
                else        _engine?.UpdateRule(_rule);

                _onSaved?.Invoke();
                Close();
            };

            btns.Children.Add(cancelBtn);
            btns.Children.Add(saveBtn);
            root.Children.Add(btns);
        }

        private void RefreshConditionsPanel()
        {
            _conditionsPanel.Children.Clear();
            if (_rule.Conditions.Count == 0)
            {
                _conditionsPanel.Children.Add(new TextBlock
                {
                    Text       = "No conditions yet.",
                    FontFamily = new FontFamily("Segoe UI"),
                    FontSize   = 11,
                    Foreground = FgHint,
                    Margin     = new Thickness(0, 2, 0, 4),
                });
                return;
            }

            for (int i = 0; i < _rule.Conditions.Count; i++)
            {
                int idx  = i;
                var cond = _rule.Conditions[i];

                var row = new Border
                {
                    Background    = BgCard,
                    CornerRadius  = new CornerRadius(6),
                    Padding       = new Thickness(10, 8, 8, 8),
                    Margin        = new Thickness(0, 0, 0, 6),
                };
                var rowGrid = new Grid();
                rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(110) });
                rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(28) });
                row.Child = rowGrid;

                // Condition type picker (styled ComboBox)
                var typePicker = new ComboBox
                {
                    Background      = BgInput,
                    Foreground      = FgPri,
                    BorderThickness = new Thickness(1),
                    BorderBrush     = BdInput,
                    FontFamily      = new FontFamily("Segoe UI"),
                    FontSize        = 12,
                    Padding         = new Thickness(6, 4, 6, 4),
                    Margin          = new Thickness(0, 0, 8, 0),
                    VerticalContentAlignment = VerticalAlignment.Center,
                };
                typePicker.Items.Add("PSI below");
                typePicker.Items.Add("Consecutive losses \u2265");
                typePicker.Items.Add("Session P&L below \u2212$");
                typePicker.Items.Add("Session time >");
                typePicker.Items.Add("Floating loss exceeds $");
                typePicker.Items.Add("Single trade loss exceeds $");
                typePicker.SelectedIndex = (int)cond.Type;
                typePicker.SelectionChanged += (_, __) =>
                    _rule.Conditions[idx].Type = (GuardConditionType)typePicker.SelectedIndex;
                Grid.SetColumn(typePicker, 0);
                rowGrid.Children.Add(typePicker);

                // Threshold box
                var threshBox = new System.Windows.Controls.TextBox
                {
                    Text            = cond.Threshold.ToString("G"),
                    Background      = BgInput,
                    Foreground      = FgPri,
                    CaretBrush      = FgPri,
                    BorderThickness = new Thickness(1),
                    BorderBrush     = BdInput,
                    Padding         = new Thickness(6, 4, 6, 4),
                    FontFamily      = new FontFamily("Segoe UI"),
                    FontSize        = 12,
                    VerticalContentAlignment = VerticalAlignment.Center,
                };
                threshBox.TextChanged += (_, __) =>
                {
                    if (double.TryParse(threshBox.Text, out double v))
                        _rule.Conditions[idx].Threshold = v;
                };
                Grid.SetColumn(threshBox, 1);
                rowGrid.Children.Add(threshBox);

                // Remove button
                var remBtn = new Border
                {
                    Width         = 24,
                    Height        = 24,
                    Background    = Brushes.Transparent,
                    CornerRadius  = new CornerRadius(4),
                    Cursor        = Cursors.Hand,
                    Child         = new TextBlock
                    {
                        Text              = "✕",
                        FontSize          = 11,
                        Foreground        = FgHint,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment   = VerticalAlignment.Center,
                    },
                    VerticalAlignment   = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    Margin = new Thickness(4, 0, 0, 0),
                };
                remBtn.MouseEnter += (_, __) =>
                {
                    remBtn.Background = new SolidColorBrush(Color.FromRgb(120, 40, 40));
                    if (remBtn.Child is TextBlock t) t.Foreground = FgPri;
                };
                remBtn.MouseLeave += (_, __) =>
                {
                    remBtn.Background = Brushes.Transparent;
                    if (remBtn.Child is TextBlock t) t.Foreground = FgHint;
                };
                remBtn.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    _rule.Conditions.RemoveAt(idx);
                    RefreshConditionsPanel();
                };
                Grid.SetColumn(remBtn, 2);
                rowGrid.Children.Add(remBtn);

                _conditionsPanel.Children.Add(row);
            }
        }

        // ── Widget helpers ────────────────────────────────────────────────────

        private static TextBlock SectionLabel(string text, double top = 0) =>
            new TextBlock
            {
                Text       = text,
                FontFamily = new FontFamily("Segoe UI"),
                FontSize   = 11,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgSec,
                Margin     = new Thickness(0, top, 0, 0),
            };

        private static System.Windows.Controls.TextBox InputBox(string value) =>
            new System.Windows.Controls.TextBox
            {
                Text            = value,
                Background      = BgInput,
                Foreground      = FgPri,
                CaretBrush      = FgPri,
                BorderThickness = new Thickness(1),
                BorderBrush     = BdInput,
                Padding         = new Thickness(8, 6, 8, 6),
                FontFamily      = new FontFamily("Segoe UI"),
                FontSize        = 12,
                Margin          = new Thickness(0, 6, 0, 0),
            };

        // "Radio-style" selector button — rounded chip, no OS chrome
        private static Border SelBtn(string text, bool selected)
        {
            var tb = new TextBlock
            {
                Text       = text,
                FontFamily = new FontFamily("Segoe UI"),
                FontSize   = 12,
                Foreground = selected ? FgSelOn : FgSec,
            };
            var btn = new Border
            {
                Background    = selected ? BgSelOn : BgSelOff,
                CornerRadius  = new CornerRadius(6),
                Padding       = new Thickness(12, 6, 12, 6),
                Margin        = new Thickness(0, 0, 8, 0),
                Cursor        = Cursors.Hand,
                Child         = tb,
                BorderThickness = new Thickness(1),
                BorderBrush     = selected
                                      ? new SolidColorBrush(Color.FromArgb(80, 10, 132, 255))
                                      : new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
            };
            return btn;
        }

        private static void UpdateSelBtn(Border btn, bool selected)
        {
            if (btn == null) return;
            btn.Background   = selected ? BgSelOn : BgSelOff;
            btn.BorderBrush  = selected
                                   ? new SolidColorBrush(Color.FromArgb(80, 10, 132, 255))
                                   : new SolidColorBrush(Color.FromArgb(30, 255, 255, 255));
            if (btn.Child is TextBlock tb)
                tb.Foreground = selected ? FgSelOn : FgSec;
        }

        // ── Radio-row for action selection ────────────────────────────────────
        // Layout: [circle indicator] [title / description]
        private static Border ActionRadioRow(string title, string description, bool selected)
        {
            var innerDot = new Border
            {
                Width               = 8,
                Height              = 8,
                CornerRadius        = new CornerRadius(4),
                Background          = FgAcc,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
                Visibility          = selected ? Visibility.Visible : Visibility.Collapsed,
            };
            var circle = new Border
            {
                Width           = 16,
                Height          = 16,
                CornerRadius    = new CornerRadius(8),
                BorderThickness = new Thickness(2),
                BorderBrush     = selected ? FgAcc : FgHint,
                Background      = Brushes.Transparent,
                Margin          = new Thickness(0, 2, 12, 0),
                VerticalAlignment = VerticalAlignment.Top,
                Child           = innerDot,
            };

            var titleTb = new TextBlock
            {
                Text       = title,
                FontFamily = new FontFamily("Segoe UI"),
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = selected ? FgPri : FgSec,
            };
            var descTb = new TextBlock
            {
                Text         = description,
                FontFamily   = new FontFamily("Segoe UI"),
                FontSize     = 11,
                Foreground   = FgHint,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 3, 0, 0),
            };
            var textStack = new StackPanel();
            textStack.Children.Add(titleTb);
            textStack.Children.Add(descTb);

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            Grid.SetColumn(circle,    0);
            Grid.SetColumn(textStack, 1);
            grid.Children.Add(circle);
            grid.Children.Add(textStack);

            var row = new Border
            {
                Background      = selected ? BgSelOn : Brushes.Transparent,
                BorderThickness = new Thickness(1),
                BorderBrush     = selected
                                      ? new SolidColorBrush(Color.FromArgb(80, 10, 132, 255))
                                      : new SolidColorBrush(Color.FromRgb(55, 55, 58)),
                CornerRadius    = new CornerRadius(6),
                Padding         = new Thickness(12, 10, 12, 10),
                Margin          = new Thickness(0, 0, 0, 4),
                Cursor          = Cursors.Hand,
                Child           = grid,
                // Tag stores refs for UpdateActionRow: [circle, innerDot, titleTb, row itself]
                Tag             = new object[] { circle, innerDot, titleTb },
            };
            row.MouseEnter += (_, __) =>
            {
                if (row.Tag is object[] t2 && t2[1] is Border d && d.Visibility != Visibility.Visible)
                    row.Background = new SolidColorBrush(Color.FromArgb(15, 255, 255, 255));
            };
            row.MouseLeave += (_, __) =>
            {
                if (row.Tag is object[] t2 && t2[1] is Border d && d.Visibility != Visibility.Visible)
                    row.Background = Brushes.Transparent;
            };
            return row;
        }

        private static void UpdateActionRow(Border row, bool selected)
        {
            if (row?.Tag is object[] refs)
            {
                var circle  = refs[0] as Border;
                var dot     = refs[1] as Border;
                var titleTb = refs[2] as TextBlock;

                row.Background  = selected ? BgSelOn : Brushes.Transparent;
                row.BorderBrush = selected
                                      ? new SolidColorBrush(Color.FromArgb(80, 10, 132, 255))
                                      : new SolidColorBrush(Color.FromRgb(55, 55, 58));
                if (circle  != null) circle.BorderBrush = selected ? FgAcc : FgHint;
                if (dot     != null) dot.Visibility     = selected ? Visibility.Visible : Visibility.Collapsed;
                if (titleTb != null) titleTb.Foreground = selected ? FgPri : FgSec;
            }
        }

        private static Border MiniBtn(string text)
        {
            var btn = new Border
            {
                Background    = new SolidColorBrush(Color.FromArgb(25, 10, 132, 255)),
                CornerRadius  = new CornerRadius(5),
                Padding       = new Thickness(12, 5, 12, 5),
                Cursor        = Cursors.Hand,
                Child         = new TextBlock
                {
                    Text       = text,
                    FontFamily = new FontFamily("Segoe UI"),
                    FontSize   = 11,
                    Foreground = FgAcc,
                },
            };
            btn.MouseEnter += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(50, 10, 132, 255));
            btn.MouseLeave += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(25, 10, 132, 255));
            return btn;
        }

        private static Button ActionBtn(string text, Color bg)
        {
            return new Button
            {
                Content         = text,
                Background      = new SolidColorBrush(bg),
                Foreground      = FgPri,
                BorderThickness = new Thickness(0),
                Padding         = new Thickness(22, 8, 22, 8),
                Margin          = new Thickness(8, 0, 0, 0),
                FontFamily      = new FontFamily("Segoe UI"),
                FontSize        = 13,
                Cursor          = Cursors.Hand,
            };
        }
    }
}


