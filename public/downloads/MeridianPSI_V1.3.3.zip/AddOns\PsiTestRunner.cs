﻿// PsiTestRunner.cs
//
// Offline automated test harness for PsiEngine + GuardEngine.
//
// Architecture:
//   Zero NinjaTrader API dependencies.  All classes live in the same namespace
//   (NinjaTrader.NinjaScript.AddOns) so PsiEngine, TradeBaseline, StrategyProfile,
//   GuardEngine, GuardRule, GuardContext, and PositionSnapshot can be instantiated
//   directly without NT8 running.
//
// HOW TO RUN:
//   Option A — via MeridianPSI property (recommended):
//     1. In NT8, open Control Center → Tools → Options → AddOns.
//     2. Edit the "Meridian PSI Monitor" AddOn.
//     3. Set "Run PSI Tests" to true.
//     4. Click OK.  Results are written immediately to Desktop.
//
//   Option B — manual call:
//     Add the line  PsiTestRunner.RunAll();  anywhere in MeridianPSI.cs
//     (e.g. top of OnStateChange Configure block), compile, and load the AddOn.
//
// OUTPUT:
//   C:\Users\<you>\Desktop\PsiTestResults.txt   — all 38 scenario PASS/FAIL lines
//   C:\Users\<you>\Desktop\PsiPersonas.csv      — PSI time-series for 3 personas
//     (open in Excel and plot the PSI column to validate curve shape visually)
//
// DATA SAFETY:
//   Redirects all file I/O (baseline.xml, profile.xml, guard.xml) to a temp
//   directory so live data is never touched.

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================================
    // PsiTestRunner
    // =========================================================================

    internal static class PsiTestRunner
    {
        // ── PRODUCTION GATE ───────────────────────────────────────────────────
        // Set this to true to automatically run all tests when the AddOn loads.
        // Results are written to Desktop/PsiTestResults.txt and Desktop/PsiPersonas.csv.
        // KEEP FALSE for normal use — flipping to true and recompiling in NT8 is all
        // you need to trigger a full test run.
        public static bool RunOnStartup = false;

        // ── Accumulator state ─────────────────────────────────────────────────
        private static int          _passed;
        private static int          _failed;
        private static StringBuilder _log;

        // ── I/O paths ─────────────────────────────────────────────────────────
        private static readonly string DesktopDir =
            Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);

        private static string ResultsFile  => Path.Combine(DesktopDir, "PsiTestResults.txt");
        private static string PersonaCsv   => Path.Combine(DesktopDir, "PsiPersonas.csv");

        // ── Temp data dir (keeps live baseline.xml / profile.xml intact) ─────
        // Unique per run so parallel launches don't collide.
        private static string TempDir =>
            Path.Combine(Path.GetTempPath(), "PsiTests_" + DateTime.Now.ToString("yyyyMMddHHmmss"));

        // =====================================================================
        // Public entry point
        // =====================================================================

        /// <summary>
        /// Runs all 38 unit scenarios and 3 persona trajectories.
        /// Returns the full report as a string (also written to Desktop).
        /// Safe to call on any thread; uses a fresh engine per scenario.
        /// </summary>
        public static string RunAll()
        {
            _passed = 0;
            _failed = 0;
            _log    = new StringBuilder();

            // Redirect data file I/O to temp folder so we never touch live data.
            string tmp = TempDir;
            try { Directory.CreateDirectory(tmp); } catch { }
            StrategyProfile.SetDataDir(tmp);
            TradeBaseline.SetDataDir(tmp);
            GuardEngine.SetDataDir(tmp);

            Banner("PSI Monitor — Automated Test Suite");
            Banner(string.Format("Started: {0}", DateTime.Now));

            // ─── 38 Unit Scenarios ────────────────────────────────────────────
            Section("UNIT SCENARIOS  (38)");

            S01_DisciplinedSession();
            S02_FirstAverageLoss();
            S03_ConsecutiveSL_x3();
            S04_ConsecutiveSL_x5();
            S05_OversizeEntry();
            S06_GradualOversize();
            S07_StopWidening_x1();
            S08_StopWidening_x3();
            S09_VelocityBurst();
            S10_TiltSpiral();
            S11_SessionWindowViolation();
            S12_CorrectionNotPenalized();
            S13_RecoveryPause();
            S14_OvernightDecay();
            S15_NewSessionColdStart();
            S16_D2_ClearsOnFlat();
            S17_Guard_PsiBelow();
            S18_Guard_Cooldown();
            S19_Guard_PnlLimit();
            S20_Guard_AllVsAny();
            S21_Guard_EdgeTriggerReset();
            S22_Guard_ConfirmationTicks();
            S23_Guard_RiskAlert();
            S24_Guard_ForceReset();
            S25_Guard_UnrealizedPnl();
            S26_Guard_SingleTradeLoss();
            S27_Guard_MasterDisabled();
            S28_Guard_RuleDisabled();
            S29_Guard_EmptyConditions();
            S30_Guard_DisconnectBlocksCascade();
            S31_Guard_CooldownLatchReset();
            S32_Guard_RiskAlertCooldownFlag();

            // ─── v1.1 refactor regression tests (S33–S37) ────────────────────
            S33_SnapUpSingleEvent();
            S34_PNormSuperLinear();
            S35_EmptySnapshotsClearDerivedState();
            S36_SessionSummaryContent();
            S37_ClampAndRangeSafety();

            // ─── v1.1.1 ExitKind + round-trip regression tests (S38–S41) ─────
            S38_ExitKindSuppressesD4OnBracketExit();
            S39_RoundTripConsecutiveLossCount();
            S40_ManualQuickExitSingleSampleCap();
            S41_ExitKindGatesRevengeClock();

            // ─── v1.1.3 Path-coverage regression tests (S42–S43) ─────────────
            S42_ChartTraderNoBracketManualClose();
            S43_SuperDomLateStopThenStopOut();

            // ─── v1.1.4 D3 unified-E(t) regression tests (S44–S48) ───────────
            S44_D3CommitJumpOnZeroDurationOversize();
            S45_D3ZeroInProfileRegardlessOfLosses();
            S46_D3EvidenceMonotonicDuringOversize();
            S47_D3EvidenceDecaysAfterFlatten();
            S48_D3PNLFlipNeutral();
            S49_D1_NoDebtOnStopLossWithoutReEntry();

            // ─── 3 Persona Trajectories ───────────────────────────────────────
            Section("PERSONA TRAJECTORIES  (3)");

            var csvLines = new List<string>();
            csvLines.Add("Persona,Trade,PSI," +
                "D1,D2,D3,D4,D5,D6,D7,ConsecLosses," +
                "C1,C2,C3,C4,C5,C6,C7,FSdebt,Fatigue,SumDebt,Event");

            Persona_Disciplined(csvLines);
            Persona_Revenge(csvLines);
            Persona_TiltSpiral(csvLines);

            try   { File.WriteAllLines(PersonaCsv, csvLines); }
            catch (Exception ex) { Log("  [WARN] Could not write persona CSV: " + ex.Message); }

            // ─── Summary ──────────────────────────────────────────────────────
            Section("SUMMARY");
            Log(string.Format("  PASSED : {0}", _passed));
            Log(string.Format("  FAILED : {0}", _failed));
            Log(string.Format("  TOTAL  : {0}", _passed + _failed));
            Log("");
            if (_failed == 0)
                Log("  ALL SCENARIOS PASSED — engine behaviour matches specification.");
            else
                Log(string.Format("  {0} SCENARIO(S) FAILED — review lines marked [FAIL] above.", _failed));
            Log("");
            Log("  Results file : " + ResultsFile);
            Log("  Persona CSV  : " + PersonaCsv);
            Log("  (Open PsiPersonas.csv in Excel; plot the PSI column for each persona.)");

            string report = _log.ToString();
            try   { File.WriteAllText(ResultsFile, report); }
            catch { /* If Desktop is read-only the test still ran; caller has return value. */ }

            // Clean up temp dir (best-effort)
            try { Directory.Delete(tmp, true); } catch { }

            return report;
        }

        // =====================================================================
        // ── S01 ─ Disciplined session (10 trades, normal size, well-spaced)
        // Expected: PSI stays healthy (75–100) throughout a calm session.
        // =====================================================================
        private static void S01_DisciplinedSession()
        {
            Title("S01 — Disciplined session (10 trades, 2 contracts, 5-min spacing)");
            var (eng, bl, _) = NewEngine();
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            double psi = 100;
            for (int i = 0; i < 10; i++)
            {
                bool win = (i % 2 == 0);
                t   = t.AddMinutes(5);
                psi = Close(eng, bl, win ? 150.0 : -120.0, 2, t, win, 90);
            }
            AssertRange("S01 final PSI", psi, 75, 100,
                "10 disciplined trades should leave PSI in a healthy range");
        }

        // =====================================================================
        // ── S02 ─ First average loss
        // Expected: single normal SL hit with NO re-entry causes near-zero D1 drop.
        // After Fix A (v1.1.5), CalcD1 returns 0.0 on close fills — streak is
        // recorded but no debt is created until the trader actually re-enters.
        // So a disciplined stop hit alone must NOT crater PSI.
        // =====================================================================
        private static void S02_FirstAverageLoss()
        {
            Title("S02 — First average loss (no re-entry): D1 must be 0, PSI drop < 4 pts");
            var (eng, bl, _) = NewEngine();
            var t    = new DateTime(2026, 4, 13, 9, 35, 0);
            double before = eng.CurrentPsi;
            double after  = Close(eng, bl, -120, 2, t, false, 60);
            double drop   = before - after;
            double d1     = eng.ScoreD1;
            Log(string.Format("  PSI before={0:F1}  after={1:F1}  drop={2:F1}  D1={3:F3}", before, after, drop, d1));
            AssertLess("S02 D1 = 0 after close-only loss", d1, 0.001,
                "stop hit with no re-entry must not create D1 debt");
            AssertLess("S02 PSI drop < 4 pts", drop, 4,
                "first average loss (no re-entry) should barely move PSI");
        }

        // =====================================================================
        // ── S03 ─ Consecutive SL × 3 with fast re-entry
        // Expected: D1 streak pressure is non-zero; PSI drops > 5 pts from baseline.
        // D1 only fires at ENTRY time (not at close time) — the urgency comes from
        // the re-entry itself, which must be inside MaxReentrySeconds after the loss.
        // =====================================================================
        private static void S03_ConsecutiveSL_x3()
        {
            Title("S03 — Consecutive SL x3 (re-entry < 60 s each): D1 streak must fire");
            var (eng, bl, _) = NewEngine();
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            // Prime Welford stats with 5 normal Entry→Close pairs (wide spacing, D1 silent).
            for (int i = 0; i < 5; i++)
            {
                t = t.AddMinutes(5);
                EntryFill(eng, 2, t, 2, 1);
                t = t.AddSeconds(90);
                Close(eng, bl, i % 2 == 0 ? 150.0 : -120.0, 2, t, i % 2 == 0, 90);
            }
            double psiBefore = eng.CurrentPsi;

            // 3 SL trades: Entry 45 s after previous close → within MaxReentrySeconds (180 s).
            // D1 evaluates on the Entry fill, not the Close fill.
            for (int i = 0; i < 3; i++)
            {
                t = t.AddSeconds(45);        // fast re-entry after loss
                EntryFill(eng, 2, t, 2, 1);  // D1 fires here
                t = t.AddSeconds(40);        // SL hit 40 s later
                Close(eng, bl, -150, 2, t, false, 40, 0, -1);
            }
            double psiAfter = eng.CurrentPsi;
            double drop     = psiBefore - psiAfter;
            Log(string.Format("  PSI before={0:F1}  after={1:F1}  drop={2:F1}  D1={3:F3}  streak={4:F0}",
                psiBefore, psiAfter, drop, eng.ScoreD1, eng.ConsecutiveLosses));

            AssertGreater("S03 PSI drop",            drop,                  5.0,  "3 fast re-entries after SLs must move PSI via D1");
            AssertGreater("S03 D1 score",             eng.ScoreD1,           0.05, "D1 must be non-zero after fast re-entry");
            AssertGreater("S03 ConsecutiveLosses",    eng.ConsecutiveLosses, 0.5,  "streak counter must register");
        }

        // =====================================================================
        // ── S04 ─ Consecutive SL × 5 (heavy D1 streak pressure)
        // Expected: PSI drops > 12 pts; streak > 2.
        // =====================================================================
        private static void S04_ConsecutiveSL_x5()
        {
            Title("S04 — Consecutive SL x5 (30 s pace): heavy D1 + streak pressure");
            var (eng, bl, _) = NewEngine();
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            // Prime baseline with Entry→Close pairs.
            for (int i = 0; i < 5; i++)
            {
                t = t.AddMinutes(5);
                EntryFill(eng, 2, t, 2, 1);
                t = t.AddSeconds(90);
                Close(eng, bl, i % 2 == 0 ? 150.0 : -120.0, 2, t, i % 2 == 0, 90);
            }
            double psiBefore = eng.CurrentPsi;

            // 5 SL trades: Entry 30 s after previous close (aggressive revenge pace).
            for (int i = 0; i < 5; i++)
            {
                t = t.AddSeconds(30);        // aggressive 30-s re-entry
                EntryFill(eng, 2, t, 2, 1);  // D1 fires + streak amplifies
                t = t.AddSeconds(35);        // SL hit after 35 s
                Close(eng, bl, -150, 2, t, false, 35, 0, -1);
            }
            double psiAfter = eng.CurrentPsi;
            double drop     = psiBefore - psiAfter;
            Log(string.Format("  PSI before={0:F1}  after={1:F1}  drop={2:F1}  streak={3:F1}",
                psiBefore, psiAfter, drop, eng.ConsecutiveLosses));

            AssertGreater("S04 PSI drop",          drop,                  12.0, "5 fast re-entries after SLs must noticeably depress PSI");
            AssertGreater("S04 ConsecutiveLosses", eng.ConsecutiveLosses,  2.0,  "streak must exceed 2");
        }

        // =====================================================================
        // ── S05 ─ Oversize entry (2× SizeMax = 4 contracts)
        // Expected: D3 fires from the commit jump alone, IsOverExposed = true,
        // PSI drops > 3 pts.  The entry fill itself (via
        // RecomputeContinuousStateFromPositions) increments E(t) by
        // D3CommitEquivalentSec × excess — no poll required.
        // =====================================================================
        private static void S05_OversizeEntry()
        {
            Title("S05 — Oversize entry: 4 contracts when SizeMax=2 → D3 + IsOverExposed");
            var (eng, bl, _) = NewEngine(sizeMax: 2);
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            for (int i = 0; i < 4; i++)
            {
                t = t.AddMinutes(5);
                Close(eng, bl, i % 2 == 0 ? 150.0 : -120.0, 2, t, i % 2 == 0, 90);
            }
            double psiBefore = eng.CurrentPsi;

            t = t.AddMinutes(2);
            EntryFill(eng, 4, t, netPosition: 4, fillDirection: 1);

            double psiAfter = eng.CurrentPsi;
            double drop     = psiBefore - psiAfter;
            Log(string.Format("  PSI drop={0:F1}  D3={1:F3}  IsOverExposed={2}",
                drop, eng.ScoreD3, eng.IsOverExposed));

            AssertGreater("S05 PSI drop",      drop,        3.0,  "oversize entry must deduct PSI");
            AssertGreater("S05 D3 score",      eng.ScoreD3, 0.10, "D3 must register");
            AssertTrue(   "S05 IsOverExposed", eng.IsOverExposed,  "IsOverExposed flag must be set");
        }

        // =====================================================================
        // ── S06 ─ Gradual oversize (scale-in to 1.2×, 1.5×, 2× SizeMax)
        // Expected: D3 monotonically rises as net position grows.  Under the
        // snap-up update law, each poll with a larger size produces a larger
        // target → C_3 snaps up to that target (or holds if target is lower).
        // This replaces the old `_sustainedViolationCount` escalation patch.
        // =====================================================================
        private static void S06_GradualOversize()
        {
            Title("S06 — Gradual oversize (scale-in): D3 escalates proportionally");
            var (eng, bl, _) = NewEngine(sizeMax: 2);
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            for (int i = 0; i < 4; i++)
            {
                t = t.AddMinutes(5);
                Close(eng, bl, i % 2 == 0 ? 150.0 : -120.0, 2, t, i % 2 == 0, 90);
            }

            double[] sizes = { 2.4, 3.0, 4.0 };   // 1.2×, 1.5×, 2.0× SizeMax
            double   prevD3 = eng.ScoreD3;
            bool     escalating = true;

            foreach (double qty in sizes)
            {
                t = t.AddMinutes(2);
                EntryFill(eng, qty, t, netPosition: qty, fillDirection: 1);
                var s = new List<PositionSnapshot>
                    { PositionSnapshot.Create("NQ", -50, t, t, true, qty) };
                bool naked;
                eng.PollPositions(s, t, out naked);
                double d3 = eng.ScoreD3;
                Log(string.Format("  qty={0:F1}  D3={1:F3}  (prev={2:F3}  escalating={3})",
                    qty, d3, prevD3, d3 >= prevD3 - 0.01));
                if (d3 < prevD3 - 0.02) escalating = false;
                prevD3 = d3;
            }
            AssertTrue("S06 D3 escalation", escalating,
                "D3 must not decrease as size grows larger");
        }

        // =====================================================================
        // ── S07 ─ Stop widening × 1 (single adverse move)
        // Expected: D2 rises after the widening.
        // =====================================================================
        private static void S07_StopWidening_x1()
        {
            Title("S07 — Stop widening x1: D2 must rise after a single adverse move");
            var (eng, bl, _) = NewEngine(slMax: 20);
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            eng.ProcessOrderChange("ORD1", 20, t, Snaps(2));    // original stop at max
            double d2Before = eng.ScoreD2;

            t = t.AddMinutes(2);
            eng.ProcessOrderChange("ORD1", 32, t, Snaps(2));    // widened to 1.6× max
            double d2After = eng.ScoreD2;

            Log(string.Format("  D2 before={0:F3}  after={1:F3}", d2Before, d2After));
            AssertGreater("S07 D2 increase", d2After, d2Before + 0.01,
                "widening stop must raise D2");
        }

        // =====================================================================
        // ── S08 ─ Stop widening × 3 (accumulating moves)
        // Expected: D2 accumulates; final D2 score > 0.15.
        // =====================================================================
        private static void S08_StopWidening_x3()
        {
            Title("S08 — Stop widening x3: D2 accumulates across successive moves");
            var (eng, bl, _) = NewEngine(slMax: 20);
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            eng.ProcessOrderChange("ORD1", 20, t, Snaps(2));
            double prevD2     = eng.ScoreD2;
            bool   increasing = true;

            foreach (double sl in new[] { 26.0, 33.0, 42.0 })
            {
                t = t.AddMinutes(3);
                eng.ProcessOrderChange("ORD1", sl, t, Snaps(2));
                double d2 = eng.ScoreD2;
                Log(string.Format("  SL→{0} ticks  D2={1:F3}", sl, d2));
                if (d2 < prevD2 - 0.005) increasing = false;
                prevD2 = d2;
            }
            AssertTrue(    "S08 D2 never decreases",  increasing, "D2 must not drop between adverse moves");
            AssertGreater( "S08 D2 total",             eng.ScoreD2, 0.15, "3 widening moves → substantial D2");
        }

        // =====================================================================
        // ── S09 ─ Velocity burst (8 entries in ~10 min)
        // Expected: D7 score rises significantly.
        // =====================================================================
        private static void S09_VelocityBurst()
        {
            Title("S09 — Velocity burst: 8 entries in 10 min → D7 fires");
            var (eng, bl, _) = NewEngine();
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            // Establish a moderate pace so D7 has a reference rate to compare against.
            for (int i = 0; i < 4; i++)
            {
                t = t.AddMinutes(6);
                Close(eng, bl, i % 2 == 0 ? 120.0 : -100.0, 2, t, i % 2 == 0, 90);
            }
            double d7Before = eng.ScoreD7;

            // Burst: 8 entries ~75 s apart (total ~10 min vs. ~6-min session average)
            for (int i = 0; i < 8; i++)
            {
                t = t.AddSeconds(75);
                EntryFill(eng, 2, t, netPosition: 2, fillDirection: 1);
            }
            double d7After = eng.ScoreD7;
            Log(string.Format("  D7 before={0:F3}  after={1:F3}  delta={2:F3}",
                d7Before, d7After, d7After - d7Before));

            AssertGreater("S09 D7 increase", d7After, d7Before + 0.05,
                "velocity burst must raise D7");
        }

        // =====================================================================
        // ── S10 ─ Tilt spiral (5× SL + oversize + velocity)
        // Expected: PSI reaches critical zone (< 65).
        // =====================================================================
        private static void S10_TiltSpiral()
        {
            Title("S10 — Tilt spiral: 5 fast SLs + oversize + velocity → PSI < 65");
            var (eng, bl, _) = NewEngine(sizeMax: 2);
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            // Baseline priming
            for (int i = 0; i < 5; i++)
            {
                t = t.AddMinutes(5);
                Close(eng, bl, i % 2 == 0 ? 150.0 : -120.0, 2, t, i % 2 == 0, 90);
            }

            // Phase 1: 5 fast SLs
            for (int i = 0; i < 5; i++)
            {
                t = t.AddSeconds(30);
                Close(eng, bl, -160, 2, t, false, 28, 0, -1);
            }

            // Phase 2: oversize entry (5 contracts = 2.5× SizeMax)
            t = t.AddSeconds(20);
            EntryFill(eng, 5, t, netPosition: 5, fillDirection: 1);
            var snaps = new List<PositionSnapshot>
                { PositionSnapshot.Create("NQ", -200, t, t, true, 5.0, -200) };
            bool naked;
            eng.PollPositions(snaps, t, out naked);

            // Phase 3: velocity burst (5 more entries in 4 min)
            for (int i = 0; i < 5; i++)
            {
                t = t.AddSeconds(48);
                EntryFill(eng, 5, t, netPosition: 5, fillDirection: 1);
            }

            double psi = eng.CurrentPsi;
            Log(string.Format("  PSI after tilt spiral = {0:F1}  D1={1:F3}  D3={2:F3}  D7={3:F3}",
                psi, eng.ScoreD1, eng.ScoreD3, eng.ScoreD7));
            AssertLess("S10 PSI in critical zone", psi, 65,
                "combined tilt triggers must collapse PSI well below 65");
        }

        // =====================================================================
        // ── S11 ─ Session window violation → D6 continuous signal
        // Expected (post-2026-04-21 refactor): D6 is a continuous raw score, not
        // a 20-point hard deduction. First out-of-session entry produces a
        // visible PSI drop; the drop magnitude comes from the p=2 norm over the
        // D6 target shaped by magnitude(minutesOver) × recency(violationCount).
        // Successive violations continue to raise D6 (recency grows) but the
        // per-event drop cap + already-suppressed PSI prevent runaway damage.
        // =====================================================================
        private static void S11_SessionWindowViolation()
        {
            Title("S11 — Session window violation: D6 continuous signal fires on entry");
            var (eng, bl, _) = NewEngine(sessionEndHour: 12);

            // EntryFill outside session window raises D6.
            // D6 is suppressed on Close fills by design — we penalise the decision to enter
            // outside hours, not the act of exiting a position.
            var t = new DateTime(2026, 4, 13, 12, 5, 0);

            double psiBefore = eng.CurrentPsi;
            double d6Before  = eng.ScoreD6;
            EntryFill(eng, 2, t, 2, 1);
            double psiAfter1 = eng.CurrentPsi;
            double d6After1  = eng.ScoreD6;
            double drop1     = psiBefore - psiAfter1;
            Log(string.Format("  1st violation  D6 {0:F3}→{1:F3}  PSI drop={2:F1} pts",
                d6Before, d6After1, drop1));

            // Second entry immediately after: recency factor compounds.
            double snap = psiAfter1;
            double d6Snap = d6After1;
            t = t.AddSeconds(30);
            EntryFill(eng, 2, t, 2, 1);
            double psiAfter2 = eng.CurrentPsi;
            double d6After2  = eng.ScoreD6;
            double drop2     = snap - psiAfter2;
            Log(string.Format("  2nd violation  D6 {0:F3}→{1:F3}  PSI drop={2:F1} pts",
                d6Snap, d6After2, drop2));

            AssertGreater("S11 first violation raises D6",    d6After1, d6Before + 0.01,
                "out-of-session entry must produce positive D6 raw score");
            AssertGreater("S11 first violation drops PSI",    drop1,    1.0,
                "D6 continuous signal must produce a visible PSI drop on first out-of-session entry");
            AssertGreater("S11 second violation compounds D6", d6After2, d6After1 - 0.01,
                "recency factor must not shrink on immediate re-fire");
            AssertLess(   "S11 per-event cap bounds drop2",    drop2,    40.0,
                "per-event drop cap must prevent runaway PSI crash on repeated violations");
        }

        // =====================================================================
        // ── S12 ─ Closing an oversize position must NOT add D3/D6 penalty
        // Expected: PSI may drop (it's a losing trade) but D3 score must not spike
        // above what it was after the oversize entry — corrective exit is not penalised.
        // =====================================================================
        private static void S12_CorrectionNotPenalized()
        {
            Title("S12 — Closing oversize: D3 must not spike on exit fill");
            var (eng, bl, _) = NewEngine(sizeMax: 2);
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            for (int i = 0; i < 4; i++)
            {
                t = t.AddMinutes(5);
                Close(eng, bl, i % 2 == 0 ? 150.0 : -120.0, 2, t, i % 2 == 0, 90);
            }

            // Open oversize position (4 contracts).
            t = t.AddMinutes(2);
            EntryFill(eng, 4, t, netPosition: 4, fillDirection: 1);
            var snaps = new List<PositionSnapshot>
                { PositionSnapshot.Create("NQ", -100, t, t, true, 4.0) };
            bool naked;
            eng.PollPositions(snaps, t, out naked);
            double d3AfterEntry = eng.ScoreD3;

            // Close position — corrective action.
            t = t.AddSeconds(30);
            Close(eng, bl, -200, 4, t, false, 30, 0, -1);
            double d3AfterClose = eng.ScoreD3;

            Log(string.Format("  D3 after entry={0:F3}  D3 after close={1:F3}",
                d3AfterEntry, d3AfterClose));
            AssertLess("S12 D3 does not spike on close", d3AfterClose, d3AfterEntry + 0.10,
                "closing an oversize position must not add D3 penalty");
        }

        // =====================================================================
        // ── S13 ─ Recovery pause (30 min flat → EWMA decays debt)
        // Expected: PSI rises from depressed level; does NOT snap instantly to 100.
        // =====================================================================
        private static void S13_RecoveryPause()
        {
            Title("S13 — Recovery pause: 30-min flat position → PSI rises via EWMA");
            var (eng, bl, _) = NewEngine();
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            // Drive PSI down using Entry→Close pairs so D1 accumulates from fast re-entries.
            for (int i = 0; i < 5; i++)
            {
                t = t.AddSeconds(45);        // fast re-entry (within MaxReentrySeconds)
                EntryFill(eng, 2, t, 2, 1);  // D1 fires on entries 2–5
                t = t.AddSeconds(40);        // SL hit
                Close(eng, bl, -150, 2, t, false, 40, 0, -1);
            }
            double psiLow = eng.CurrentPsi;

            // 30 min × 2 ticks/min = 60 poll ticks with empty position list.
            for (int tick = 0; tick < 60; tick++)
            {
                t = t.AddSeconds(30);
                bool naked;
                eng.PollPositions(new List<PositionSnapshot>(), t, out naked);
            }
            double psiRecovered = eng.CurrentPsi;
            Log(string.Format("  PSI depressed={0:F1}  PSI after 30-min pause={1:F1}",
                psiLow, psiRecovered));

            AssertGreater("S13 PSI recovery",       psiRecovered, psiLow + 0.5, "EWMA must recover PSI during quiet period");
            AssertLess(   "S13 no instant full reset", psiRecovered, 99.0,       "PSI must not snap instantly to 100");
        }

        // =====================================================================
        // ── S14 ─ Overnight decay (ApplyOvernightDecay 8 h)
        // Expected: PSI rises from bad session; does NOT fully reset to 100.
        // =====================================================================
        private static void S14_OvernightDecay()
        {
            Title("S14 — Overnight decay: 8-hour gap partially but not fully clears debt");
            var (eng, bl, _) = NewEngine();
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            for (int i = 0; i < 8; i++)
            {
                t = t.AddMinutes(2);
                Close(eng, bl, -150, 2, t, false, 40, 0, -1);
            }
            double psiEOD = eng.CurrentPsi;
            eng.ApplyOvernightDecay(8.0);
            double psiOpen = eng.CurrentPsi;

            Log(string.Format("  PSI EOD={0:F1}  PSI next open (after 8 h)={1:F1}", psiEOD, psiOpen));

            AssertGreater("S14 overnight recovery",    psiOpen, psiEOD,    "8-hour gap must partially recover PSI");
            AssertLess(   "S14 debt not fully cleared", psiOpen, 100.0,    "8 hours is insufficient for full recovery from a bad session");
        }

        // =====================================================================
        // ── S15 ─ New session cold start with carry debt
        // Expected: StartNewSession(75) opens between 75 and 95 (overnight partial recovery).
        // =====================================================================
        private static void S15_NewSessionColdStart()
        {
            Title("S15 — Cold start: StartNewSession(75) carries yesterday's debt forward");
            var (eng, bl, _) = NewEngine();

            eng.StartNewSession(75.0);   // previous session ended at 75
            double openPsi = eng.CurrentPsi;

            // tau=48h, estimated overnight=16h → decayFactor ≈ e^(-16/48) ≈ 0.716
            // Expected: 100 − (100−75)×0.716 ≈ 82.1
            Log(string.Format("  Open PSI after prevFinal=75 : {0:F1}  (expected ≈82)", openPsi));

            AssertRange("S15 carry debt open PSI", openPsi, 75, 95,
                "should start in 75-95 range, reflecting overnight partial recovery from 75");
            AssertLess("S15 not a fresh 100", openPsi, 99.0,
                "must not open at 100 when yesterday's session ended at 75");
        }

        // =====================================================================
        // ── S16 ─ D2 score drops after position closes flat
        // Expected: D2 raw score (not EWMA debt) falls once the position is closed.
        // =====================================================================
        private static void S16_D2_ClearsOnFlat()
        {
            Title("S16 — D2 clears on full close: stop-manipulation raw score must drop");
            var (eng, bl, _) = NewEngine(slMax: 20);
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            eng.ProcessOrderChange("ORD1", 20, t, Snaps(2));
            t = t.AddMinutes(2); eng.ProcessOrderChange("ORD1", 30, t, Snaps(2));
            t = t.AddMinutes(2); eng.ProcessOrderChange("ORD1", 40, t, Snaps(2));
            double d2Score = eng.ScoreD2;
            double d2Debt  = eng.DebtD2;

            // Close the position — ProcessExecution with pnl != 0 clears the stop dict.
            t = t.AddMinutes(2);
            Close(eng, bl, -200, 2, t, false, 120, 0, -1);

            double d2ScoreAfter = eng.ScoreD2;
            Log(string.Format("  D2 score before={0:F3}  after close={1:F3}  debt before={2:F3}",
                d2Score, d2ScoreAfter, d2Debt));

            // Raw score should be zero (no open orders) after close.
            // EWMA debt persists but diminishes — check that score is lower than peak.
            AssertLess("S16 D2 score drops after close", d2ScoreAfter, d2Score + 0.10,
                "D2 instantaneous score must not stay at peak after position closes");
        }

        // =====================================================================
        // ── S17 ─ Guard rule fires (Toast) when PSI < 60
        // Expected: fires once at PSI=55, does NOT fire at PSI=75.
        // =====================================================================
        private static void S17_Guard_PsiBelow()
        {
            Title("S17 — Guard: Toast fires at PSI<60 and is suppressed above threshold");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;
            guard.AddRule(new GuardRule
            {
                Id              = "s17",
                Name            = "PSI Alert",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.Toast,
                CooldownMinutes = 0,   // no cooldown so both evals are independent
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 60 } }
            });

            int count = 0;
            guard.Triggered += (_) => { count++; };

            guard.Evaluate(new GuardContext { Psi = 75 });
            AssertTrue("S17 no fire at PSI=75", count == 0, "must not fire when PSI=75 >= threshold 60");

            guard.Evaluate(new GuardContext { Psi = 55 });
            AssertTrue("S17 fires at PSI=55",   count == 1,
                string.Format("must fire when PSI=55 < threshold 60 (count={0})", count));
        }

        // =====================================================================
        // ── S18 ─ Guard cooldown suppresses re-trigger
        // Expected: fire once, then 2 more evaluations within cooldown → no second trigger.
        // =====================================================================
        private static void S18_Guard_Cooldown()
        {
            Title("S18 — Guard cooldown: re-trigger within window must NOT fire");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;
            guard.AddRule(new GuardRule
            {
                Id              = "s18",
                Name            = "Cooldown Test",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.Toast,
                CooldownMinutes = 60,   // 60-min cooldown
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 70 } }
            });

            int count = 0;
            guard.Triggered += (_) => { count++; };

            var ctx = new GuardContext { Psi = 65 };
            guard.Evaluate(ctx);   // first fire
            guard.Evaluate(ctx);   // within cooldown — must NOT fire
            guard.Evaluate(ctx);   // within cooldown — must NOT fire

            AssertTrue("S18 exactly one trigger in cooldown window", count == 1,
                string.Format("expected 1 trigger, got {0}", count));
        }

        // =====================================================================
        // ── S19 ─ P&L guard rule
        // Expected: fires when session P&L < -$500; does not fire at -$400.
        // =====================================================================
        private static void S19_Guard_PnlLimit()
        {
            Title("S19 — Guard: daily loss limit (SessionPnlBelow $500)");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;
            guard.AddRule(new GuardRule
            {
                Id              = "s19",
                Name            = "Daily Loss Limit",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.Acknowledge,
                CooldownMinutes = 0,
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.SessionPnlBelow, Threshold = 500 } }
            });

            int count = 0;
            guard.Triggered += (_) => { count++; };

            guard.Evaluate(new GuardContext { Psi = 80, SessionPnl = -400 });
            AssertTrue("S19 no fire at -$400", count == 0, "P&L=-400 must not fire when limit is -500");

            guard.Evaluate(new GuardContext { Psi = 80, SessionPnl = -600 });
            AssertTrue("S19 fires at -$600",   count == 1,
                string.Format("P&L=-600 must fire (threshold -500), count={0}", count));
        }

        // =====================================================================
        // ── S20 ─ ALL vs ANY condition logic
        // Expected:
        //   ALL: fires only when BOTH PSI<70 AND streak≥3 are simultaneously true.
        //   ANY: fires when EITHER PSI<70 OR streak≥3 is first met.
        // =====================================================================
        private static void S20_Guard_AllVsAny()
        {
            Title("S20 — Guard ALL vs ANY logic");

            // ── ALL ─────────────────────────────────────────────────────────
            {
                var guard = new GuardEngine();
                guard.MasterEnabled = true;
                guard.AddRule(new GuardRule
                {
                    Id = "s20-all", Enabled = true,
                    Logic = GuardConditionLogic.All, Action = GuardActionType.Toast, CooldownMinutes = 0,
                    Conditions = new List<GuardCondition>
                    {
                        new GuardCondition { Type = GuardConditionType.PsiBelow,                   Threshold = 70 },
                        new GuardCondition { Type = GuardConditionType.ConsecutiveLossesAtLeast, Threshold = 3  },
                    }
                });
                int count = 0;
                guard.Triggered += (_) => { count++; };

                // PSI<70 but only 1 loss → should NOT fire (streak condition missing)
                guard.Evaluate(new GuardContext { Psi = 65, ConsecutiveLosses = 1 });
                AssertTrue("S20 ALL: no fire when only PSI condition met", count == 0,
                    "ALL rule must require BOTH conditions");

                // PSI<70 AND streak≥3 → SHOULD fire
                guard.Evaluate(new GuardContext { Psi = 65, ConsecutiveLosses = 3 });
                AssertTrue("S20 ALL: fires when both conditions met", count == 1,
                    string.Format("count={0}", count));
            }

            // ── ANY ─────────────────────────────────────────────────────────
            {
                var guard = new GuardEngine();
                guard.MasterEnabled = true;
                guard.AddRule(new GuardRule
                {
                    Id = "s20-any", Enabled = true,
                    Logic = GuardConditionLogic.Any, Action = GuardActionType.Toast, CooldownMinutes = 0,
                    Conditions = new List<GuardCondition>
                    {
                        new GuardCondition { Type = GuardConditionType.PsiBelow,                   Threshold = 70 },
                        new GuardCondition { Type = GuardConditionType.ConsecutiveLossesAtLeast, Threshold = 3  },
                    }
                });
                int count = 0;
                guard.Triggered += (_) => { count++; };

                // Neither condition met → should NOT fire
                guard.Evaluate(new GuardContext { Psi = 80, ConsecutiveLosses = 1 });
                AssertTrue("S20 ANY: no fire when neither condition met", count == 0);

                // PSI<70 (first condition alone) → SHOULD fire
                guard.Evaluate(new GuardContext { Psi = 65, ConsecutiveLosses = 1 });
                AssertTrue("S20 ANY: fires on first matching condition",  count == 1,
                    string.Format("count={0}", count));
            }
        }

        // =====================================================================
        // ── S21 ─ Edge-trigger latch resets when condition clears
        // Expected:
        //   tick 1 PSI=55 → fires (count=1)
        //   tick 2 PSI=55 → latched, no fire (count=1)
        //   tick 3 PSI=80 → condition clears, latch resets
        //   tick 4 PSI=55 → fires again (count=2)
        // =====================================================================
        private static void S21_Guard_EdgeTriggerReset()
        {
            Title("S21 — Guard edge-trigger: fires once, resets on condition clear, refires on re-entry");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;
            guard.AddRule(new GuardRule
            {
                Id              = "s21",
                Name            = "Edge Trigger",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.Toast,
                CooldownMinutes = 0,
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 70 } }
            });

            int count = 0;
            guard.Triggered += (_) => { count++; };

            guard.Evaluate(new GuardContext { Psi = 55 });   // enter condition
            AssertTrue("S21 fires on first entry",    count == 1, string.Format("count={0}", count));

            guard.Evaluate(new GuardContext { Psi = 55 });   // still in condition — latched
            AssertTrue("S21 latched: no re-fire",     count == 1, string.Format("count={0}", count));

            guard.Evaluate(new GuardContext { Psi = 80 });   // condition clears — latch resets
            guard.Evaluate(new GuardContext { Psi = 55 });   // re-enter — must fire again
            AssertTrue("S21 refires after clear",     count == 2, string.Format("count={0}", count));
        }

        // =====================================================================
        // ── S22 ─ ConfirmationSeconds: Disconnect waits for N wall-clock seconds
        // Expected:
        //   ConfirmationSeconds=2; rapid evaluations within 2 s → no fire even
        //   if many evaluations have occurred; after 2+ s of continuous condition
        //   met → fires exactly once.  A clear in the middle resets the timer.
        //
        // Note: This test exercises the v1.3.0 wall-clock confirmation logic.
        // The legacy ConfirmationTicks counter no longer gates firing — only
        // elapsed time matters — so flooding evaluations cannot shortcut the
        // confirmation window the way the old per-tick counter could.
        // =====================================================================
        private static void S22_Guard_ConfirmationTicks()
        {
            Title("S22 — Guard ConfirmationSeconds: Disconnect fires only after wall-clock window elapses");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;
            guard.AddRule(new GuardRule
            {
                Id                  = "s22",
                Name                = "Disconnect Confirm",
                Enabled             = true,
                Logic               = GuardConditionLogic.All,
                Action              = GuardActionType.Disconnect,
                CooldownMinutes     = 0,
                LockMinutes         = 1,
                ConfirmationSeconds = 2,
                Conditions          = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 60 } }
            });

            int count = 0;
            guard.Triggered += (_) => { count++; };

            // Hammer the rule with 10 evaluations within a few ms — the old
            // tick-based logic would have fired immediately; the new wall-clock
            // logic must NOT fire because the 2 s window has not elapsed.
            for (int i = 0; i < 10; i++)
                guard.Evaluate(new GuardContext { Psi = 50 });
            AssertTrue("S22 immediate burst: no fire", count == 0,
                "wall-clock confirmation must not be satisfied by burst evaluations");

            // Condition clears, then re-enters — the elapsed timer must reset.
            guard.Evaluate(new GuardContext { Psi = 80 });
            guard.Evaluate(new GuardContext { Psi = 50 });
            AssertTrue("S22 timer reset on clear", count == 0, "re-entry restarts the wall-clock window");

            // Wait past the confirmation window then evaluate once more.
            System.Threading.Thread.Sleep(2200);
            guard.Evaluate(new GuardContext { Psi = 50 });
            AssertTrue("S22 fires after window elapsed", count == 1, string.Format("count={0}", count));
        }

        // =====================================================================
        // ── S23 ─ RiskAlert: persistent flag on/off, event fires once per entry
        // Expected:
        //   Entry: IsRiskAlertActive=true + event fires (count=1)
        //   Still met: IsRiskAlertActive=true, no further event
        //   Clear: IsRiskAlertActive=false
        //   Re-entry: IsRiskAlertActive=true + event fires again (count=2)
        // =====================================================================
        private static void S23_Guard_RiskAlert()
        {
            Title("S23 — Guard RiskAlert: flag active while condition met, re-fires on re-entry");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;
            guard.AddRule(new GuardRule
            {
                Id              = "s23",
                Name            = "Risk Alert",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.RiskAlert,
                CooldownMinutes = 0,
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 65 } }
            });

            int count = 0;
            guard.Triggered += (_) => { count++; };

            guard.Evaluate(new GuardContext { Psi = 60 });   // entry
            AssertTrue("S23 fires on entry",        count == 1, string.Format("count={0}", count));
            AssertTrue("S23 IsRiskAlertActive",     guard.IsRiskAlertActive, "flag must be true while condition met");

            guard.Evaluate(new GuardContext { Psi = 60 });   // still in condition
            AssertTrue("S23 no re-fire while met",  count == 1, "RiskAlert must not spam events");

            guard.Evaluate(new GuardContext { Psi = 80 });   // condition clears
            AssertTrue("S23 flag deactivates",      !guard.IsRiskAlertActive, "flag must clear when condition unmet");

            guard.Evaluate(new GuardContext { Psi = 60 });   // re-entry
            AssertTrue("S23 re-fires on re-entry",  count == 2, string.Format("count={0}", count));
        }

        // =====================================================================
        // ── S24 ─ ForceReset clears all latches so a rule can re-trigger
        // Expected:
        //   After firing (latch set) + ForceReset() + same condition still met
        //   → rule fires again on the very next evaluation.
        // =====================================================================
        private static void S24_Guard_ForceReset()
        {
            Title("S24 — Guard ForceReset: clears runtime state, rule re-triggers immediately");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;
            guard.AddRule(new GuardRule
            {
                Id              = "s24",
                Name            = "Reset Test",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.Toast,
                CooldownMinutes = 0,
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 70 } }
            });

            int count = 0;
            guard.Triggered += (_) => { count++; };

            var lowCtx = new GuardContext { Psi = 60 };
            guard.Evaluate(lowCtx);   // fires, latch set
            AssertTrue("S24 initial fire",          count == 1, string.Format("count={0}", count));

            guard.Evaluate(lowCtx);   // latched — no fire
            AssertTrue("S24 latched no fire",       count == 1, string.Format("count={0}", count));

            guard.ForceReset();
            guard.Evaluate(lowCtx);   // latch cleared — must fire again
            AssertTrue("S24 re-fires after reset",  count == 2, string.Format("count={0}", count));
        }

        // =====================================================================
        // ── S25 ─ UnrealizedPnlBelow condition (floating loss threshold)
        // Expected: no fire at -$300; fires at -$600 (threshold $500).
        // =====================================================================
        private static void S25_Guard_UnrealizedPnl()
        {
            Title("S25 — Guard UnrealizedPnlBelow: fires on floating loss exceeding threshold");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;
            guard.AddRule(new GuardRule
            {
                Id              = "s25",
                Name            = "Float Loss",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.Toast,
                CooldownMinutes = 0,
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.UnrealizedPnlBelow, Threshold = 500 } }
            });

            int count = 0;
            guard.Triggered += (_) => { count++; };

            guard.Evaluate(new GuardContext { UnrealizedPnl = -300 });
            AssertTrue("S25 no fire at -$300", count == 0, "floating -300 within threshold -500");

            guard.Evaluate(new GuardContext { UnrealizedPnl = -600 });
            AssertTrue("S25 fires at -$600",   count == 1,
                string.Format("floating -600 must fire (threshold -500), count={0}", count));
        }

        // =====================================================================
        // ── S26 ─ SingleTradeLossExceeds condition (per-trade loss)
        // Expected:
        //   win (+100)   → no fire
        //   loss (-200)  → no fire  (threshold $300)
        //   loss (-400)  → fires
        // =====================================================================
        private static void S26_Guard_SingleTradeLoss()
        {
            Title("S26 — Guard SingleTradeLossExceeds: fires only on large single-trade loss");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;
            guard.AddRule(new GuardRule
            {
                Id              = "s26",
                Name            = "Single Trade Loss",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.Toast,
                CooldownMinutes = 0,
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.SingleTradeLossExceeds, Threshold = 300 } }
            });

            int count = 0;
            guard.Triggered += (_) => { count++; };

            guard.Evaluate(new GuardContext { LastTradePnl = 100 });    // win
            AssertTrue("S26 no fire on win",        count == 0, "winning trade must not trigger loss guard");

            guard.Evaluate(new GuardContext { LastTradePnl = -200 });   // small loss
            AssertTrue("S26 no fire on small loss", count == 0, "-200 must not exceed threshold 300");

            guard.Evaluate(new GuardContext { LastTradePnl = -400 });   // large loss
            AssertTrue("S26 fires on large loss",   count == 1,
                string.Format("-400 must fire (threshold 300), count={0}", count));
        }

        // =====================================================================
        // ── S27 ─ MasterEnabled=false gates all evaluation
        // Expected: no rule fires when the master switch is off.
        // =====================================================================
        private static void S27_Guard_MasterDisabled()
        {
            Title("S27 — Guard MasterEnabled=false: no rules fire regardless of conditions");
            var guard = new GuardEngine();
            guard.MasterEnabled = false;  // master off
            guard.AddRule(new GuardRule
            {
                Id              = "s27",
                Name            = "Should Never Fire",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.Toast,
                CooldownMinutes = 0,
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 99 } }
            });

            int count = 0;
            guard.Triggered += (_) => { count++; };

            guard.Evaluate(new GuardContext { Psi = 50 });
            guard.Evaluate(new GuardContext { Psi = 30 });
            AssertTrue("S27 no fire when master disabled", count == 0,
                "MasterEnabled=false must silence all rules");
        }

        // =====================================================================
        // ── S28 ─ Individual rule Enabled=false
        // Expected: the disabled rule never fires even when conditions are met.
        // =====================================================================
        private static void S28_Guard_RuleDisabled()
        {
            Title("S28 — Guard rule Enabled=false: disabled rule does not fire");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;
            guard.AddRule(new GuardRule
            {
                Id              = "s28",
                Name            = "Disabled Rule",
                Enabled         = false,   // rule-level off
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.Toast,
                CooldownMinutes = 0,
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 99 } }
            });

            int count = 0;
            guard.Triggered += (_) => { count++; };

            guard.Evaluate(new GuardContext { Psi = 10 });
            AssertTrue("S28 disabled rule never fires", count == 0,
                "Enabled=false must prevent evaluation");
        }

        // =====================================================================
        // ── S29 ─ Empty conditions list always returns false
        // Expected: a rule with no conditions configured never fires.
        // =====================================================================
        private static void S29_Guard_EmptyConditions()
        {
            Title("S29 — Guard empty conditions: rule with no conditions never fires");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;
            guard.AddRule(new GuardRule
            {
                Id              = "s29",
                Name            = "No Conditions",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.Toast,
                CooldownMinutes = 0,
                Conditions      = new List<GuardCondition>()   // empty
            });

            int count = 0;
            guard.Triggered += (_) => { count++; };

            guard.Evaluate(new GuardContext { Psi = 10 });
            AssertTrue("S29 empty conditions never fires", count == 0,
                "Conditions.Count=0 must return false silently");
        }

        // =====================================================================
        // ── S30 ─ Disconnect blocks subsequent rules in the same evaluation tick
        // Expected: when a Disconnect rule fires, any Toast rule that would also
        // have fired in the same tick is suppressed.
        // =====================================================================
        private static void S30_Guard_DisconnectBlocksCascade()
        {
            Title("S30 — Guard Disconnect blocks subsequent rules in same evaluation tick");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;

            // Rule 1: Disconnect (fires first — added first)
            guard.AddRule(new GuardRule
            {
                Id              = "s30-disconnect",
                Name            = "Disconnect",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.Disconnect,
                CooldownMinutes = 0,
                LockMinutes     = 1,
                ConfirmationTicks = 1,
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 70 } }
            });

            // Rule 2: Toast that would also fire at PSI<70
            guard.AddRule(new GuardRule
            {
                Id              = "s30-toast",
                Name            = "Toast",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.Toast,
                CooldownMinutes = 0,
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 70 } }
            });

            int disconnectFires = 0;
            int toastFires      = 0;
            guard.Triggered += (t) =>
            {
                if (t.Action == GuardActionType.Disconnect) disconnectFires++;
                if (t.Action == GuardActionType.Toast)      toastFires++;
            };

            guard.Evaluate(new GuardContext { Psi = 50 });
            AssertTrue("S30 Disconnect fires",         disconnectFires == 1,
                string.Format("disconnect={0}", disconnectFires));
            AssertTrue("S30 Toast blocked by Disconnect", toastFires == 0,
                string.Format("toast must be 0 when disconnect fires first, got {0}", toastFires));
        }

        // =====================================================================
        // ── S31 ─ Cooldown + edge-trigger latch: condition clears during cooldown,
        //         latch resets, rule re-fires after cooldown expires  (validates F1 fix)
        //
        // Old (buggy) behaviour: latch would NOT reset during cooldown, causing
        // the rule to be silenced permanently after the first fire.
        // Fixed behaviour: latch resets as soon as condition clears, even inside
        // the cooldown window; rule re-fires on the first post-cooldown evaluation
        // where the condition is met again.
        // =====================================================================
        private static void S31_Guard_CooldownLatchReset()
        {
            Title("S31 — Guard cooldown+latch: condition clears during cooldown → re-fires after cooldown (F1 fix)");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;
            var rule = new GuardRule
            {
                Id              = "s31",
                Name            = "Cooldown Latch",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.Toast,
                CooldownMinutes = 60,  // 60-minute cooldown
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 70 } }
            };
            guard.AddRule(rule);

            int count = 0;
            guard.Triggered += (_) => { count++; };

            // Tick 1: condition met → fires, cooldown starts
            guard.Evaluate(new GuardContext { Psi = 60 });
            AssertTrue("S31 initial fire",           count == 1, string.Format("count={0}", count));
            AssertTrue("S31 WasConditionMet=true",   rule.WasConditionMet,  "latch set after fire");

            // Tick 2: condition CLEARS during cooldown — latch must reset
            guard.Evaluate(new GuardContext { Psi = 80 });
            AssertTrue("S31 latch resets on clear",  !rule.WasConditionMet, "latch must be false after condition clears");
            AssertTrue("S31 no extra fire on clear", count == 1,            "clearing must not fire");

            // Tick 3: condition re-enters while still in cooldown — should NOT fire yet
            guard.Evaluate(new GuardContext { Psi = 60 });
            AssertTrue("S31 no re-fire inside cooldown", count == 1,
                "cooldown still active — must not fire even though latch was reset");

            // Simulate cooldown expiry by zeroing LastTriggeredUtc
            rule.LastTriggeredUtc = DateTime.MinValue;

            // Tick 4: post-cooldown, condition still met → must fire again
            guard.Evaluate(new GuardContext { Psi = 60 });
            AssertTrue("S31 re-fires after cooldown + latch reset", count == 2,
                string.Format("must fire again after cooldown expires (count={0})", count));
        }

        // =====================================================================
        // ── S32 ─ RiskAlert flag stays active inside cooldown; clears when
        //         condition clears even during cooldown  (validates F1 RiskAlert path)
        // =====================================================================
        private static void S32_Guard_RiskAlertCooldownFlag()
        {
            Title("S32 — Guard RiskAlert: flag stays live during cooldown, clears on condition clear");
            var guard = new GuardEngine();
            guard.MasterEnabled = true;
            var rule = new GuardRule
            {
                Id              = "s32",
                Name            = "RiskAlert Cooldown",
                Enabled         = true,
                Logic           = GuardConditionLogic.All,
                Action          = GuardActionType.RiskAlert,
                CooldownMinutes = 60,
                Conditions      = new List<GuardCondition>
                    { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 70 } }
            };
            guard.AddRule(rule);

            int count = 0;
            guard.Triggered += (_) => { count++; };

            // Condition enters — fires event, flag goes live
            guard.Evaluate(new GuardContext { Psi = 60 });
            AssertTrue("S32 fires on entry",         count == 1, string.Format("count={0}", count));
            AssertTrue("S32 flag active",            guard.IsRiskAlertActive, "RiskAlertActive must be true");

            // Condition still met inside cooldown — flag stays live, no new event
            guard.Evaluate(new GuardContext { Psi = 60 });
            AssertTrue("S32 flag stays during cooldown", guard.IsRiskAlertActive, "flag must stay while condition met");
            AssertTrue("S32 no re-fire during cooldown", count == 1, "no duplicate event during cooldown");

            // Condition clears inside cooldown — flag must deactivate
            guard.Evaluate(new GuardContext { Psi = 80 });
            AssertTrue("S32 flag clears when condition clears", !guard.IsRiskAlertActive,
                "flag must go false when condition unmet, even inside cooldown");
        }

        // =====================================================================
        // ── S33 ─ Snap-up update law (single-event oversize)
        // v1.1 refactor: ApplyDecomposedEwma no longer averages a new raw
        // signal toward its target — worsening dimensions SNAP UP on the
        // first event carrying the high target.  This test verifies a single
        // severe oversize entry produces a material PSI drop on one call,
        // rather than needing 3–5 polls to accumulate.
        // =====================================================================
        private static void S33_SnapUpSingleEvent()
        {
            Title("S33 — Snap-up law: one severe oversize entry drops PSI on a single event");
            var (eng, bl, _) = NewEngine(sizeMax: 2);

            // Prime baseline with a few normal trades so muSize is meaningful.
            var t = new DateTime(2026, 4, 13, 9, 35, 0);
            for (int i = 0; i < 5; i++)
            {
                t = t.AddMinutes(4);
                Close(eng, bl, i % 2 == 0 ? 120.0 : -100.0, 2, t, i % 2 == 0, 90);
            }
            double psiBefore = eng.CurrentPsi;
            double c3Before  = eng.DebtD3;

            // One oversize entry at 3× SizeMax.
            t = t.AddMinutes(3);
            EntryFill(eng, 6, t, netPosition: 6, fillDirection: 1);
            double psiAfter = eng.CurrentPsi;
            double c3After  = eng.DebtD3;
            double drop     = psiBefore - psiAfter;

            Log(string.Format("  PSI {0:F1} → {1:F1}  drop={2:F1}   C3 {3:F1} → {4:F1}",
                psiBefore, psiAfter, drop, c3Before, c3After));

            AssertGreater("S33 C3 snaps up on first event", c3After, c3Before + 5.0,
                "single severe oversize entry must push C3 up materially in one pass (snap-up law)");
            AssertGreater("S33 PSI drops on first event", drop, 3.0,
                "PSI must react in real time; no multi-poll averaging delay is permitted");
        }

        // =====================================================================
        // ── S34 ─ p=2 Euclidean aggregation super-linearity
        // v1.1 refactor: PSI = 100 − √(Σ C_i²) instead of 100 − Σ w_i·C_i.
        // Two moderate problems must compound MORE than either one alone.
        // Specifically: norm(30, 30) = √1800 ≈ 42.4 > 30 (either single dim).
        // This also forbids the old "ceiling effect" where one dimension's
        // weight clamped its contribution below the full 100 − C_i range.
        // =====================================================================
        private static void S34_PNormSuperLinear()
        {
            Title("S34 — p=2 norm: two moderate dimensions compound beyond any single one");
            var (engOneDim, bl1, _) = NewEngine(sizeMax: 2);
            var (engTwoDim, bl2, _) = NewEngine(sizeMax: 2);

            // Prime baselines symmetrically.
            var t = new DateTime(2026, 4, 13, 9, 35, 0);
            for (int i = 0; i < 5; i++)
            {
                t = t.AddMinutes(4);
                Close(engOneDim, bl1, i % 2 == 0 ? 120.0 : -100.0, 2, t, i % 2 == 0, 90);
                Close(engTwoDim, bl2, i % 2 == 0 ? 120.0 : -100.0, 2, t, i % 2 == 0, 90);
            }

            // Arm #1: oversize alone (D3 fires).
            t = t.AddMinutes(3);
            EntryFill(engOneDim, 4, t, netPosition: 4, fillDirection: 1);

            // Arm #2: oversize AND a post-loss revenge entry (D1 + D3 compound).
            //   1) close a loss
            //   2) fast re-entry within MaxReentrySeconds at same direction and bigger size
            var t2 = new DateTime(2026, 4, 13, 9, 35, 0).AddMinutes(25);
            Close(engTwoDim, bl2, -200.0, 2, t2, false, 60, 0, 1);
            t2 = t2.AddSeconds(30);
            EntryFill(engTwoDim, 4, t2, netPosition: 4, fillDirection: 1);

            double psiOne = engOneDim.CurrentPsi;
            double psiTwo = engTwoDim.CurrentPsi;
            Log(string.Format("  single-dim PSI={0:F1}   two-dim PSI={1:F1}   delta={2:F1}",
                psiOne, psiTwo, psiOne - psiTwo));

            AssertLess("S34 two-dim PSI < single-dim PSI", psiTwo, psiOne - 2.0,
                "compound violations must drop PSI more than any single violation alone");
        }

        // =====================================================================
        // ── S35 ─ Empty snapshots clear derived continuous state
        // v1.1 refactor: D3 live size, D2 naked, D5 hold are DERIVED from the
        // current position snapshot set at every poll — there is no cached
        // _liveOverExposed flag.  Polling with an empty list must immediately
        // drop the engine's internal overExposed derivation to false so the
        // oversize alert clears when the position is closed (log-reported bug
        // 2026-04-21 in NT8 Grid: oversize alert persisted after flatten).
        // =====================================================================
        private static void S35_EmptySnapshotsClearDerivedState()
        {
            Title("S35 — Empty snapshots: oversize alert must clear when position flattens");
            var (eng, bl, _) = NewEngine(sizeMax: 2);
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            // Establish oversize state via PollPositions.
            bool naked1;
            eng.PollPositions(
                new List<PositionSnapshot>
                    { PositionSnapshot.Create("NQ", -100, t, t, true, 5.0, -100) },
                t, out naked1);
            double c3HighFromDebt = eng.DebtD3;
            AssertGreater("S35 oversize poll raises C3", c3HighFromDebt, 5.0,
                "5× size position must meaningfully raise D3 debt");

            // Flatten 10 s later with EMPTY snapshot set.  This sample closes
            // out the prior over-limit persistence window (ZOH using the
            // previously-held excess).  _prevSizeOverLimit is now 0, so the
            // NEXT sample will begin decaying E(t).
            t = t.AddSeconds(10);
            bool naked2;
            eng.PollPositions(new List<PositionSnapshot>(), t, out naked2);

            AssertTrue("S35 naked=false after empty snapshot", !naked2,
                "empty position set must derive nakedDetected = false");
            AssertTrue("S35 IsOverExposed clears after flatten", !eng.IsOverExposed,
                "flattened position must derive IsOverExposed = false");

            // Poll again 5 minutes later (clamped to 300 s).  Now both
            // exPrev=0 and exNow=0 so E(t) decays on D3ExcessDecayTauSec
            // and C3 recovers on EwmaNormalRecoveryTau.  5 min is long
            // enough that the composed decay materially lowers C3.
            t = t.AddMinutes(5);
            bool naked3;
            eng.PollPositions(new List<PositionSnapshot>(), t, out naked3);
            double c3AfterRecover = eng.DebtD3;

            Log(string.Format("  C3 oversize={0:F1}  C3 +5m flat={1:F1}",
                c3HighFromDebt, c3AfterRecover));
            AssertLess("S35 D3 recovers after flatten", c3AfterRecover, c3HighFromDebt,
                "once back within profile, D3 debt must recover (E decays, then C3 EWMA toward 0)");
        }

        // =====================================================================
        // ── S36 ─ Session summary (B2): BuildSessionSummary content
        // Ensures the diagnostic string actually captures peaks and durations
        // so the log line is useful in the field.
        // =====================================================================
        private static void S36_SessionSummaryContent()
        {
            Title("S36 — Session summary: BuildSessionSummary reports peaks and durations");
            var (eng, bl, _) = NewEngine(sizeMax: 2);
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            // Create some history: a loss, an oversize entry, naked-exposure window.
            Close(eng, bl, -150, 2, t, false, 60);
            t = t.AddSeconds(30);
            EntryFill(eng, 4, t, netPosition: 4, fillDirection: 1);

            // Two polls spanning a 60-s window with the oversize + naked state live
            // so overExposureTotalSec and nakedTotalSec both accumulate.
            bool naked;
            eng.PollPositions(
                new List<PositionSnapshot>
                    { PositionSnapshot.Create("NQ", -80, t, t, false /* naked */, 4.0, -80) },
                t, out naked);
            t = t.AddSeconds(60);
            eng.PollPositions(
                new List<PositionSnapshot>
                    { PositionSnapshot.Create("NQ", -80, t, t, false, 4.0, -80) },
                t, out naked);

            string summary = eng.BuildSessionSummary();
            Log("  " + summary);

            AssertTrue("S36 summary is non-empty",
                !string.IsNullOrEmpty(summary) && summary.Length > 40,
                "BuildSessionSummary must produce a meaningful string");
            AssertTrue("S36 summary includes peak_dimNorm",
                summary.IndexOf("peak_dimNorm", StringComparison.Ordinal) >= 0,
                "summary must report the peak Euclidean norm");
            AssertTrue("S36 summary includes overExp_sec",
                summary.IndexOf("overExp_sec", StringComparison.Ordinal) >= 0,
                "summary must report total overexposure seconds");
            AssertTrue("S36 summary includes naked_sec",
                summary.IndexOf("naked_sec", StringComparison.Ordinal) >= 0,
                "summary must report total naked seconds");
        }

        // =====================================================================
        // ── S37 ─ B3 sanity clamps: PSI must stay in [0,100]
        // Hammer the engine with extreme pathological inputs and verify PSI
        // never escapes its declared range, C_i values stay non-negative, and
        // the engine doesn't throw.  This covers the defensive clamps added
        // at the tail of ApplyDecomposedEwma.
        // =====================================================================
        private static void S37_ClampAndRangeSafety()
        {
            Title("S37 — Sanity clamps: PSI stays in [0,100] under extreme input");
            var (eng, bl, _) = NewEngine(sizeMax: 2);
            var t = new DateTime(2026, 4, 13, 9, 35, 0);

            // Bombard with many oversize entries and losses in quick succession.
            for (int i = 0; i < 20; i++)
            {
                t = t.AddSeconds(5);
                Close(eng, bl, -500, 10, t, false, 10);
                t = t.AddSeconds(5);
                EntryFill(eng, 20, t, netPosition: 20, fillDirection: 1);
                bool naked;
                eng.PollPositions(
                    new List<PositionSnapshot>
                        { PositionSnapshot.Create("NQ", -2000, t, t, false, 20.0, -2000) },
                    t, out naked);

                AssertRange("S37 PSI in range after pathological event " + i,
                    eng.CurrentPsi, 0.0, 100.0,
                    "PSI must remain in [0,100] regardless of input pathology");
            }
        }

        // =====================================================================
        // ── S38 ─ ExitKind.ProtectiveStop suppresses D4 panic-exit per-trade
        //   Regression for v1.1.0 50-point PSI drop on a disciplined SL hit.
        //   A bracket-triggered stop-loss fill with short hold time must NOT
        //   produce a meaningful D4 raw signal (per-trade is suppressed; only
        //   session-level d4Session may contribute, and with 1 trade sessionConf
        //   is tiny, so overall D4 impact is minimal).
        // =====================================================================
        private static void S38_ExitKindSuppressesD4OnBracketExit()
        {
            Title("S38 — ExitKind.ProtectiveStop suppresses D4 per-trade panic signal");
            var (eng, bl, _) = NewEngine(sizeMax: 3);

            // Seed baseline with 20 historical LOSS holds around ~120 s so the
            // per-trade D4 signal has the required histN ≥ 10 to activate.
            for (int i = 0; i < 20; i++) bl.LossHold.Update(120.0);
            for (int i = 0; i < 20; i++) bl.WinHold.Update(180.0);

            var t = new DateTime(2026, 4, 22, 9, 35, 0);

            // Open a 3-lot long.
            EntryFill(eng, 3, t, netPosition: 3, fillDirection: 1);
            double psiAfterEntry = eng.CurrentPsi;

            // 5-second stop-out — this is precisely the v1.1.0 scenario.
            // Same aggregate hold seconds as the log that reproduced the bug.
            t = t.AddSeconds(5);
            double psiAfterStop = CloseEx(eng, bl,
                pnl: -450, size: 3, fillTime: t,
                holdSeconds: 5,
                exitKind: ExitKind.ProtectiveStop,
                isRoundTripFinal: true,
                roundTripPnl: -450,
                netPositionAfter: 0,
                fillDirection: 1);

            double drop = psiAfterEntry - psiAfterStop;

            AssertLess("S38 D4 raw stays near zero", eng.ScoreD4, 0.10,
                "bracket-triggered stop must NOT fire per-trade D4 panic signal");
            AssertLess("S38 PSI drop < 15 pts (was ~50 in v1.1.0)", drop, 15.0,
                "regression: disciplined SL hit must not collapse PSI");
            AssertGreater("S38 PSI remains >= 85", psiAfterStop, 85.0,
                "single disciplined loss should leave PSI in the calm range");
        }

        // =====================================================================
        // ── S39 ─ Round-trip consecutive-loss counting (E2)
        //   A 3-contract stop-out firing as 3 partial fills must count as
        //   ONE consecutive loss, not three.  This mirrors the ATM bracket
        //   pattern where Stop1/Stop2/Stop3 each fire independently.
        // =====================================================================
        private static void S39_RoundTripConsecutiveLossCount()
        {
            Title("S39 — Multi-partial stop-out counts as ONE consecutive loss");
            var (eng, bl, _) = NewEngine(sizeMax: 3);
            var t = new DateTime(2026, 4, 22, 9, 35, 0);

            EntryFill(eng, 3, t, netPosition: 3, fillDirection: 1);

            double streakBefore = eng.ConsecutiveLosses;

            // Partial 1 of 3 — position still open (2 left).
            t = t.AddSeconds(5);
            CloseEx(eng, bl, pnl: -150, size: 1, fillTime: t, holdSeconds: 5,
                exitKind: ExitKind.ProtectiveStop,
                isRoundTripFinal: false, roundTripPnl: -150,
                netPositionAfter: 2, fillDirection: 1,
                updateBaseline: false);

            // Partial 2 of 3 — still open (1 left).
            t = t.AddSeconds(1);
            CloseEx(eng, bl, pnl: -150, size: 1, fillTime: t, holdSeconds: 6,
                exitKind: ExitKind.ProtectiveStop,
                isRoundTripFinal: false, roundTripPnl: -300,
                netPositionAfter: 1, fillDirection: 1,
                updateBaseline: false);

            // Partial 3 of 3 — final; position flat.  isRoundTripFinal=true
            // is what triggers the single consecutive-loss increment.
            t = t.AddSeconds(1);
            CloseEx(eng, bl, pnl: -150, size: 1, fillTime: t, holdSeconds: 7,
                exitKind: ExitKind.ProtectiveStop,
                isRoundTripFinal: true, roundTripPnl: -450,
                netPositionAfter: 0, fillDirection: 1);

            double streakAfter = eng.ConsecutiveLosses;
            double streakDelta = streakAfter - streakBefore;

            AssertTrue("S39 streak increments exactly 1",
                Math.Abs(streakDelta - 1.0) < 1e-9,
                string.Format("expected +1, got +{0:F2}", streakDelta));
        }

        // =====================================================================
        // ── S40 ─ Manual quick exit capped by single-sample rule (E4)
        //   Even when the trader hand-closes quickly (panic OR re-evaluation),
        //   a SINGLE event must not saturate D4.  This preserves statistical
        //   honesty: one sample is insufficient evidence.
        // =====================================================================
        private static void S40_ManualQuickExitSingleSampleCap()
        {
            Title("S40 — Manual quick exit: single-sample D4 cap holds (E4)");
            var (eng, bl, _) = NewEngine(sizeMax: 2);

            // Seed with 30 historical loss holds at 200 s so per-trade path is
            // firmly active (histN=30 → histConf ≈ 0.82).
            for (int i = 0; i < 30; i++) bl.LossHold.Update(200.0);
            for (int i = 0; i < 30; i++) bl.WinHold.Update(300.0);

            var t = new DateTime(2026, 4, 22, 10, 5, 0);
            EntryFill(eng, 1, t, netPosition: 1, fillDirection: 1);

            t = t.AddSeconds(8);   // hold=8 s vs mu=200 s → extreme panicZ
            double psi = CloseEx(eng, bl,
                pnl: -50, size: 1, fillTime: t, holdSeconds: 8,
                exitKind: ExitKind.Manual,
                isRoundTripFinal: true, roundTripPnl: -50);

            AssertLess("S40 D4 raw ≤ SingleSampleCap", eng.ScoreD4, 0.20,
                "single manual quick exit must not saturate D4 (cap at 0.15 Balanced)");
            AssertGreater("S40 PSI ≥ 80 after 1 manual quick exit", psi, 80.0,
                "weak evidence accumulation: one ambiguous event ≠ major drop");
        }

        // =====================================================================
        // ── S41 ─ ExitKind.Manual fires D1 revenge clock; ProtectiveStop does not
        //   Verifies E5 — the revenge-urgency timer is updated only on manual
        //   exits.  A rapid re-entry after a bracket-triggered SL should see
        //   only streak-background pressure (floor), NOT the full urgency spike.
        // =====================================================================
        private static void S41_ExitKindGatesRevengeClock()
        {
            Title("S41 — D1 revenge clock updated only on ExitKind.Manual (E5)");

            // ── Arm 1: bracket exit → no revenge urgency on quick re-entry.
            var (engA, blA, _) = NewEngine(sizeMax: 3);
            var tA = new DateTime(2026, 4, 22, 9, 35, 0);
            EntryFill(engA, 1, tA, netPosition: 1, fillDirection: 1);
            tA = tA.AddSeconds(30);
            CloseEx(engA, blA, pnl: -100, size: 1, fillTime: tA, holdSeconds: 30,
                exitKind: ExitKind.ProtectiveStop,
                isRoundTripFinal: true, roundTripPnl: -100,
                netPositionAfter: 0, fillDirection: 1);

            tA = tA.AddSeconds(10);                    // quick re-entry
            EntryFill(engA, 1, tA, netPosition: 1, fillDirection: 1);
            double d1AfterBracketExit = engA.ScoreD1;

            // ── Arm 2: manual exit → revenge urgency fires on quick re-entry.
            var (engB, blB, _) = NewEngine(sizeMax: 3);
            var tB = new DateTime(2026, 4, 22, 9, 35, 0);
            EntryFill(engB, 1, tB, netPosition: 1, fillDirection: 1);
            tB = tB.AddSeconds(30);
            CloseEx(engB, blB, pnl: -100, size: 1, fillTime: tB, holdSeconds: 30,
                exitKind: ExitKind.Manual,
                isRoundTripFinal: true, roundTripPnl: -100,
                netPositionAfter: 0, fillDirection: 1);

            tB = tB.AddSeconds(10);                    // quick re-entry
            EntryFill(engB, 1, tB, netPosition: 1, fillDirection: 1);
            double d1AfterManualExit = engB.ScoreD1;

            AssertGreater("S41 manual-exit re-entry D1 > bracket-exit re-entry D1",
                d1AfterManualExit, d1AfterBracketExit + 0.05,
                string.Format("manual={0:F3}  bracket={1:F3}", d1AfterManualExit, d1AfterBracketExit));
        }

        // =====================================================================
        // ── S42 ─ Chart Trader path: manual close with no bracket
        //   Chart Trader right-click "Close Position" produces a Market order
        //   with no pre-existing bracket.  MeridianPSI infers ExitKind.Manual;
        //   D4 single-sample cap keeps PSI drop bounded even for quick hold.
        // =====================================================================
        private static void S42_ChartTraderNoBracketManualClose()
        {
            Title("S42 — Chart Trader manual close (no bracket): ExitKind.Manual + E4 cap");
            var (eng, bl, _) = NewEngine(sizeMax: 2);

            // Seed baseline sufficient for per-trade D4 path.
            for (int i = 0; i < 25; i++) bl.LossHold.Update(240.0);
            for (int i = 0; i < 25; i++) bl.WinHold.Update(360.0);

            var t = new DateTime(2026, 4, 22, 10, 15, 0);
            EntryFill(eng, 1, t, netPosition: 1, fillDirection: 1);

            // User right-clicks and closes manually after 12 s — quick hold,
            // no bracket existed.  ExitKind.Manual applies; the single-sample
            // cap limits D4 to ≤ 0.15 (Balanced).
            t = t.AddSeconds(12);
            double psi = CloseEx(eng, bl,
                pnl: -60, size: 1, fillTime: t, holdSeconds: 12,
                exitKind: ExitKind.Manual,
                isRoundTripFinal: true, roundTripPnl: -60);

            AssertLess("S42 D4 raw ≤ cap",   eng.ScoreD4, 0.20,
                "manual quick exit single-sample cap must hold");
            AssertGreater("S42 PSI ≥ 75",    psi, 75.0,
                "one Chart Trader flatten is weak evidence; PSI should stay calm");
        }

        // =====================================================================
        // ── S43 ─ SuperDOM path: enter, then later place SL, then stop hits
        //   Even though the stop was created AFTER the entry, at the moment
        //   of the fill it was an active Stop order — this is still a
        //   disciplined execution and ExitKind.ProtectiveStop applies.
        //   Verifies E3 does not regress for the SuperDOM late-stop workflow.
        // =====================================================================
        private static void S43_SuperDomLateStopThenStopOut()
        {
            Title("S43 — SuperDOM late-stop-placement: ProtectiveStop still applies");
            var (eng, bl, _) = NewEngine(sizeMax: 2);
            for (int i = 0; i < 20; i++) bl.LossHold.Update(180.0);
            for (int i = 0; i < 20; i++) bl.WinHold.Update(240.0);

            var t = new DateTime(2026, 4, 22, 10, 30, 0);

            // Entry via SuperDOM click (no bracket placed yet).
            EntryFill(eng, 1, t, netPosition: 1, fillDirection: 1);

            // 8 seconds later the user places a stop.  Three seconds after
            // that the market hits the stop.  Total hold = 11 s (well below
            // the 180 s mean loss hold).  Classifier: OrderType=StopMarket
            // → ExitKind.ProtectiveStop.  D4 per-trade must NOT fire.
            t = t.AddSeconds(11);
            double psi = CloseEx(eng, bl,
                pnl: -80, size: 1, fillTime: t, holdSeconds: 11,
                exitKind: ExitKind.ProtectiveStop,
                isRoundTripFinal: true, roundTripPnl: -80);

            AssertLess("S43 D4 raw near zero (bracket exit)", eng.ScoreD4, 0.10,
                "bracket-triggered exit, late-placed or not, must suppress D4 per-trade");
            AssertGreater("S43 PSI ≥ 88", psi, 88.0,
                "a late-placed stop hitting is still a disciplined outcome");
        }

        // =====================================================================
        // ── S44 ─ D3 commit jump: scalper zero-duration oversize still fires
        //   Regression for the v1.1.4 unified-E(t) refactor.  A trader who
        //   sizes above SizeMax and closes immediately (0 seconds oversize)
        //   must still see a material D3 reaction — the DECISION itself is
        //   the psychological signal, independent of hold time.  This is the
        //   test that distinguishes the unified model from the previous
        //   "pure time-integration" proposal (rejected as scalper loophole).
        // =====================================================================
        private static void S44_D3CommitJumpOnZeroDurationOversize()
        {
            Title("S44 — D3 commit jump: zero-duration oversize still registers a material hit");
            var (eng, bl, _) = NewEngine(sizeMax: 3);
            var t = new DateTime(2026, 4, 22, 10, 0, 0);

            // Prime baseline.
            for (int i = 0; i < 5; i++)
            {
                t = t.AddMinutes(4);
                Close(eng, bl, i % 2 == 0 ? 120.0 : -100.0, 3, t, i % 2 == 0, 90);
            }
            double psiBefore = eng.CurrentPsi;

            // Trader enters 6 when plan says 3 (excess = 3).  Commit jump alone
            // credits E ≈ 3 × D3CommitEquivalentSec(30) = 90 contract·seconds.
            // raw ≈ 1 − exp(−90 / D3ExcessIntegralTau(60)) ≈ 0.78.
            t = t.AddMinutes(3);
            EntryFill(eng, 6, t, netPosition: 6, fillDirection: 1);
            double d3Entry = eng.ScoreD3;
            double c3Entry = eng.DebtD3;

            // Close to flat in the SAME instant (zero-duration over limit).
            double psi = CloseEx(eng, bl,
                pnl: 60, size: 6, fillTime: t, holdSeconds: 0.0,
                exitKind: ExitKind.Manual,
                isRoundTripFinal: true, roundTripPnl: 60,
                netPositionAfter: 0, fillDirection: -1);

            double drop = psiBefore - psi;
            Log(string.Format(
                "  psi {0:F1} → {1:F1}  drop={2:F1}   D3 raw(entry)={3:F2}  C3(entry)={4:F1}",
                psiBefore, psi, drop, d3Entry, c3Entry));

            AssertGreater("S44 D3 raw fires on zero-duration oversize", d3Entry, 0.50,
                "commit jump must push D3 raw materially even before any hold accrues");
            AssertGreater("S44 C3 debt registers on commit", c3Entry, 40.0,
                "snap-up must pin C3 to the commit-driven raw target on the fill itself");
            AssertGreater("S44 PSI drops on zero-duration oversize", drop, 15.0,
                "a trader who oversizes and scalps out instantly must still see a PSI reaction");
        }

        // =====================================================================
        // ── S45 ─ D3 remains zero for in-profile sizing regardless of losses
        //   Discipline-over-outcome check: consecutive losses must not move
        //   D3 when the size itself never crosses SizeMax.  The legacy
        //   D3ConsecutiveLossGain / DampenBase / DampenRampPerLoss stack
        //   coupled D3 to outcome; the unified-E(t) model removes that
        //   coupling by construction (D3 reads only excess(t)).
        // =====================================================================
        private static void S45_D3ZeroInProfileRegardlessOfLosses()
        {
            Title("S45 — D3 never fires in-profile, even after a loss streak");
            var (eng, bl, _) = NewEngine(sizeMax: 5);
            var t = new DateTime(2026, 4, 22, 10, 0, 0);

            // Five quick losses at size=3 (well within profile).  Under the
            // legacy model, _consecutiveLosses × D3ConsecutiveLossGain
            // shifted the z-score enough to show a non-zero D3 on the next
            // in-profile entry.  Under the unified model this must stay 0.
            for (int i = 0; i < 5; i++)
            {
                t = t.AddSeconds(60);
                EntryFill(eng, 3, t, netPosition: 3, fillDirection: 1);
                t = t.AddSeconds(45);
                Close(eng, bl, -120, 3, t, false, 45, 0, -1);
            }

            // Next entry at max profile size.
            t = t.AddMinutes(2);
            EntryFill(eng, 5, t, netPosition: 5, fillDirection: 1);

            Log(string.Format(
                "  D3 raw after 5 losses + in-profile entry = {0:F3}  (streak={1:F1})",
                eng.ScoreD3, eng.ConsecutiveLosses));

            AssertLess("S45 D3 raw stays 0 for in-profile size", eng.ScoreD3, 1e-6,
                "D3 must not read outcome state; sizing within SizeMax is not a violation");
            AssertLess("S45 D3 debt stays 0 for in-profile size", eng.DebtD3, 0.5,
                "C3 must remain at noise floor when no profile violation has occurred");
        }

        // =====================================================================
        // ── S46 ─ E(t) monotonic non-decreasing during sustained oversize
        //   While |q| > SizeMax, E must never decrease.  Persistence integral
        //   accumulates contract·seconds; any additional commit jump only
        //   adds.  Protects against a future regression where someone adds
        //   a decay branch that fires during the over-limit phase.
        // =====================================================================
        private static void S46_D3EvidenceMonotonicDuringOversize()
        {
            Title("S46 — E(t) monotonic non-decreasing while oversize");
            var (eng, bl, _) = NewEngine(sizeMax: 2);
            var t = new DateTime(2026, 4, 22, 10, 0, 0);

            EntryFill(eng, 5, t, netPosition: 5, fillDirection: 1);
            double ePrev = eng.SizeExcessIntegral;
            bool   monotonic = true;

            for (int i = 1; i <= 6; i++)
            {
                t = t.AddSeconds(15);
                bool naked;
                eng.PollPositions(
                    new List<PositionSnapshot>
                        { PositionSnapshot.Create("NQ", -250, t, t, true, 5.0, -250) },
                    t, out naked);
                double eNow = eng.SizeExcessIntegral;
                if (eNow < ePrev - 1e-9) monotonic = false;
                Log(string.Format("  +{0,3} s  E(t) = {1:F1} cs   Δ={2:+0.0;-0.0}",
                    i * 15, eNow, eNow - ePrev));
                ePrev = eNow;
            }

            AssertTrue("S46 E(t) monotonic non-decreasing while oversize", monotonic,
                "E must not decrease while |q| > SizeMax");
        }

        // =====================================================================
        // ── S47 ─ E(t) decays to ≈0 after back within profile for long enough
        //   Verifies the natural-decay branch of UpdateSizeExcessIntegral.
        //   No frozen-τ / cooldown-window machine — plain first-order decay
        //   on D3ExcessDecayTauSec.  After 10 minutes back within profile, E
        //   must be essentially zero (exp(−600/90) ≈ 0.001).
        // =====================================================================
        private static void S47_D3EvidenceDecaysAfterFlatten()
        {
            Title("S47 — E(t) decays to ≈0 after sufficient time within profile");
            var (eng, bl, _) = NewEngine(sizeMax: 2);
            var t = new DateTime(2026, 4, 22, 10, 0, 0);

            EntryFill(eng, 5, t, netPosition: 5, fillDirection: 1);
            double ePeak = eng.SizeExcessIntegral;
            AssertGreater("S47 E(t) rises on oversize entry", ePeak, 1.0,
                "commit jump must push E above 1 contract·sec on oversize entry");

            // Flatten.
            t = t.AddSeconds(5);
            CloseEx(eng, bl,
                pnl: -80, size: 5, fillTime: t, holdSeconds: 5.0,
                exitKind: ExitKind.Manual,
                isRoundTripFinal: true, roundTripPnl: -80,
                netPositionAfter: 0, fillDirection: -1);

            // Poll periodically over 10 minutes to let E(t) decay.
            for (int i = 0; i < 20; i++)
            {
                t = t.AddSeconds(30);
                bool naked;
                eng.PollPositions(new List<PositionSnapshot>(), t, out naked);
            }
            double eTail = eng.SizeExcessIntegral;
            Log(string.Format("  E peak={0:F1} cs   E after 10 min flat={1:F4} cs", ePeak, eTail));

            AssertLess("S47 E decays toward zero", eTail, ePeak * 0.05,
                "after 10 minutes within profile, E should have relaxed to <5% of its peak");
        }

        // =====================================================================
        // ── S48 ─ D3 is P&L-neutral: flip the round-trip sign, get identical E/raw
        //   Enforces the core psi-discipline-over-outcome.mdc invariant on D3.
        //   Same position trajectory, opposite pnl sign, must produce bit-
        //   identical D3 raw at every step.  Guards against future regressions
        //   that accidentally couple D3 to outcome (as the legacy
        //   D3ConsecutiveLossGain pathway did).
        // =====================================================================
        private static void S48_D3PNLFlipNeutral()
        {
            Title("S48 — D3 P&L-flip neutrality: same trajectory, opposite pnl → identical D3");
            var (engWin,  _, _) = NewEngine(sizeMax: 2);
            var (engLose, _, _) = NewEngine(sizeMax: 2);
            var t = new DateTime(2026, 4, 22, 10, 0, 0);

            // Entry at 4 contracts (excess=2).
            EntryFill(engWin,  4, t, netPosition: 4, fillDirection: 1);
            EntryFill(engLose, 4, t, netPosition: 4, fillDirection: 1);

            // Hold 20 s oversize.
            t = t.AddSeconds(20);
            bool nA, nB;
            engWin.PollPositions(
                new List<PositionSnapshot>
                    { PositionSnapshot.Create("NQ", 50, t, t, true, 4.0, 50) },
                t, out nA);
            engLose.PollPositions(
                new List<PositionSnapshot>
                    { PositionSnapshot.Create("NQ", -50, t, t, true, 4.0, -50) },
                t, out nB);

            // Close: one wins, one loses.  Manual exit in both cases.
            t = t.AddSeconds(5);
            engWin.ProcessExecution(
                +200, 4, t, true, 25, new List<PositionSnapshot>(), -1,
                ExitKind.Manual, true, +200);
            engLose.ProcessExecution(
                -200, 4, t, false, 25, new List<PositionSnapshot>(), -1,
                ExitKind.Manual, true, -200);

            double d3W = engWin.ScoreD3, d3L = engLose.ScoreD3;
            double eW  = engWin.SizeExcessIntegral, eL = engLose.SizeExcessIntegral;
            Log(string.Format("  WIN: D3_raw={0:F6}  E={1:F3}   LOSE: D3_raw={2:F6}  E={3:F3}",
                d3W, eW, d3L, eL));

            AssertTrue("S48 D3 raw identical under P&L flip",
                Math.Abs(d3W - d3L) < 1e-9,
                "D3 must be bit-identical for same trajectory under pnl sign flip");
            AssertTrue("S48 E identical under P&L flip",
                Math.Abs(eW - eL) < 1e-9,
                "E(t) must depend only on excess(t), not on outcome");
        }

        // =====================================================================
        // ── S49 ─ D1 does NOT fire on disciplined stop-loss (no re-entry)
        // Fix A (v1.1.5): CalcD1 returns 0.0 on close fills.  An ATM bracket
        // stop being hit — even three times in a row — must not generate any
        // D1 debt if the trader does NOT re-enter.
        // =====================================================================
        private static void S49_D1_NoDebtOnStopLossWithoutReEntry()
        {
            Title("S49 — D1 = 0 after 3 ATM bracket stops with no re-entry");
            var (eng, bl, _) = NewEngine();
            var t = new DateTime(2026, 4, 22, 9, 35, 0);

            // Prime baseline with 5 normal trades.
            for (int i = 0; i < 5; i++)
            {
                t = t.AddMinutes(5);
                EntryFill(eng, 2, t, 2, 1);
                t = t.AddSeconds(90);
                Close(eng, bl, i % 2 == 0 ? 150.0 : -120.0, 2, t, i % 2 == 0, 90);
            }
            double psiBefore = eng.CurrentPsi;

            // 3 ATM bracket stops hit in quick succession — no re-entry after each.
            for (int i = 0; i < 3; i++)
            {
                t = t.AddMinutes(3);
                EntryFill(eng, 2, t, 2, 1);
                t = t.AddSeconds(10);
                CloseEx(eng, bl, pnl: -120, size: 2, fillTime: t, holdSeconds: 10,
                    exitKind: ExitKind.ProtectiveStop,
                    isRoundTripFinal: true, roundTripPnl: -120,
                    netPositionAfter: 0, fillDirection: 1);
                // No re-entry — 5 minutes of quiet before checking.
            }
            t = t.AddMinutes(5);
            eng.PollPositions(new System.Collections.Generic.List<PositionSnapshot>(), t, out _);

            double d1     = eng.ScoreD1;
            double c1     = eng.DebtD1;
            double streak = eng.ConsecutiveLosses;
            double psiAfter = eng.CurrentPsi;
            double drop     = psiBefore - psiAfter;

            Log(string.Format(
                "  PSI before={0:F1}  after={1:F1}  drop={2:F1}  D1={3:F3}  C1={4:F1}  streak={5:F1}",
                psiBefore, psiAfter, drop, d1, c1, streak));

            AssertLess("S49 D1 = 0 after stop-only sequence", d1, 0.001,
                "stop hits with no re-entry must not produce D1 raw score");
            AssertLess("S49 C1 debt minimal after stop-only", c1, 5.0,
                "C1 must not accumulate from disciplined stop-loss hits alone");
            AssertGreater("S49 streak recorded correctly", streak, 0.5,
                "_consecutiveLosses must still increment even if D1 = 0");
        }

        // =====================================================================
        // ── PERSONA 1 — Disciplined Trader
        // 50 trades, 3–7 min spacing, 2 contracts, ~45% win rate.
        // Expected: PSI stays above 65; no sharp drops.
        // =====================================================================
        private static void Persona_Disciplined(List<string> csv)
        {
            Title("PERSONA-1 — Disciplined Trader (50 trades, 5-min avg spacing, 2 contracts)");
            // 50 trades × ~490 s avg (gap 200-420 + hold 60-300) ≈ 6.8 h from 09:30 → ends ~16:20.
            // Use sessionEndHour=17 so D6 session-window violations don't fire during normal trading
            // (D6 compliance is tested independently in S11).
            // Use tradesMax=60 so the declared session profile matches the persona's actual pace
            // (~6.7 trades/hr over 7.5 h). Without this, D7 fires as "overtrading" even though the
            // disciplined trader is behaving consistently with their own declared profile.
            var (eng, bl, _) = NewEngine(sizeMax: 4, sessionEndHour: 17, tradesMin: 5, tradesMax: 60);
            var t   = new DateTime(2026, 4, 13, 9, 30, 0);
            var rng = new Random(42);

            double minPsi = 100;
            for (int i = 0; i < 50; i++)
            {
                // Gap from previous close to this entry: 200-420 s (> MaxReentrySeconds=180s).
                // D1 must NOT fire for a disciplined trader who spaces entries correctly.
                t = t.AddSeconds(rng.Next(200, 420));
                bool   win  = rng.NextDouble() < 0.45;
                double pnl  = win ? rng.Next(100, 250) : -rng.Next(80, 160);
                double hold = rng.Next(60, 300);

                EntryFill(eng, 2, t, 2, win ? 1 : -1);   // entry decision
                t = t.AddSeconds(hold);
                double psi  = Close(eng, bl, pnl, 2, t, win, hold);
                if (psi < minPsi) minPsi = psi;
                csv.Add(Row(eng, "Disciplined", i + 1, win ? "win" : "loss"));
            }
            Log(string.Format("  Final PSI={0:F1}  Min PSI={1:F1}", eng.CurrentPsi, minPsi));
            AssertGreater("PERSONA-1 final PSI", eng.CurrentPsi, 65,
                "disciplined trader should finish above 65");
            AssertRange("PERSONA-1 min PSI reasonable floor", minPsi, 50, 100,
                "even disciplined traders have rough patches but not below 50");
        }

        // =====================================================================
        // ── PERSONA 2 — Revenge Trader
        // 20 trades, re-enters within 45–90 s after every loss, 35% win rate.
        // Expected: PSI ends below 75; hits < 65 at some point during session.
        // =====================================================================
        private static void Persona_Revenge(List<string> csv)
        {
            Title("PERSONA-2 — Revenge Trader (20 trades, fast re-entry after every loss, 35% win)");
            var (eng, bl, _) = NewEngine(sizeMax: 4);
            var t   = new DateTime(2026, 4, 13, 9, 30, 0);
            var rng = new Random(77);

            double minPsi = 100;
            for (int i = 0; i < 20; i++)
            {
                bool   win  = rng.NextDouble() < 0.35;
                double pnl  = win  ? rng.Next(80, 150)  : -rng.Next(120, 200);
                double hold = win  ? rng.Next(60, 180)  :  rng.Next(20, 50);
                double gap  = win  ? rng.Next(180, 360) :  rng.Next(45, 90);  // revenge pace on losses

                // Entry fill: D1 evaluates the re-entry speed here, not on the close fill.
                t = t.AddSeconds(gap);
                EntryFill(eng, 2, t, 2, win ? 1 : -1);

                // Close the trade (SL or TP).
                t = t.AddSeconds(hold);
                double psi = Close(eng, bl, pnl, 2, t, win, hold, 0, win ? 1 : -1);
                if (psi < minPsi) minPsi = psi;
                csv.Add(Row(eng, "Revenge", i + 1, win ? "win" : "fast_reentry"));
            }
            Log(string.Format("  Final PSI={0:F1}  Min PSI={1:F1}", eng.CurrentPsi, minPsi));
            AssertLess("PERSONA-2 final PSI",  eng.CurrentPsi, 80, "revenge trader should end below 80");
            AssertLess("PERSONA-2 min PSI hit", minPsi,         75, "revenge trader must hit < 75 at some point");
        }

        // =====================================================================
        // ── PERSONA 3 — Tilt Spiral
        // Classic blowup: 3 normal trades → 4 fast SLs → oversize → velocity.
        // Expected: PSI collapses to < 55.
        // =====================================================================
        private static void Persona_TiltSpiral(List<string> csv)
        {
            Title("PERSONA-3 — Tilt Spiral (3 normal → 4 fast SLs → oversize → velocity)");
            var (eng, bl, _) = NewEngine(sizeMax: 2);
            var t   = new DateTime(2026, 4, 13, 9, 30, 0);
            int row = 0;

            // Phase 1: 3 normal trades (establish baseline)
            for (int i = 0; i < 3; i++, row++)
            {
                t = t.AddMinutes(5);
                bool win = (i == 0);
                EntryFill(eng, 2, t, 2, win ? 1 : -1);
                t = t.AddSeconds(90);
                Close(eng, bl, win ? 150.0 : -120.0, 2, t, win, 90);
                csv.Add(Row(eng, "TiltSpiral", row + 1, "normal"));
            }

            // Phase 2: 4 fast SLs (Entry + immediate SL close, 35 s re-entry each)
            for (int i = 0; i < 4; i++, row++)
            {
                t = t.AddSeconds(35);
                EntryFill(eng, 2, t, 2, 1);  // D1 fires on re-entries
                t = t.AddSeconds(28);
                Close(eng, bl, -180, 2, t, false, 28, 0, -1);
                csv.Add(Row(eng, "TiltSpiral", row + 1, "fast_sl"));
            }

            // Phase 3: 4 oversize entries (5 contracts = 2.5× SizeMax)
            for (int i = 0; i < 4; i++, row++)
            {
                t = t.AddSeconds(25);
                EntryFill(eng, 5, t, netPosition: 5, fillDirection: 1);
                var s = new List<PositionSnapshot>
                    { PositionSnapshot.Create("NQ", -(i + 1) * 80, t, t, true, 5.0, -(i + 1) * 80) };
                bool naked;
                eng.PollPositions(s, t, out naked);
                csv.Add(Row(eng, "TiltSpiral", row + 1, "oversize"));
            }

            // Phase 4: velocity burst (4 entries, 45 s each)
            for (int i = 0; i < 4; i++, row++)
            {
                t = t.AddSeconds(45);
                EntryFill(eng, 5, t, netPosition: 5, fillDirection: 1);
                csv.Add(Row(eng, "TiltSpiral", row + 1, "velocity"));
            }

            double finalPsi = eng.CurrentPsi;
            Log(string.Format("  Final PSI={0:F1}  (D1={1:F3}  D3={2:F3}  D7={3:F3})",
                finalPsi, eng.ScoreD1, eng.ScoreD3, eng.ScoreD7));
            AssertLess("PERSONA-3 tilt collapse", finalPsi, 55,
                "tilt spiral should collapse PSI well below 55");
        }

        // =====================================================================
        // Engine factory helpers
        // =====================================================================

        private static (PsiEngine eng, TradeBaseline bl, StrategyProfile prof) NewEngine(
            double sizeMax          = 2.0,
            int    slMax            = 20,
            bool   noStop           = false,
            int    sessionEndHour   = 12,
            int    tradesMin        = 3,
            int    tradesMax        = 15)
        {
            var prof = new StrategyProfile
            {
                SizeMin               = 1.0,
                SizeMax               = sizeMax,
                SlTicksMax            = slMax,
                MaxReentrySeconds     = 180,
                ReversalPenaltyFactor = 0.25,
                MaxHoldMinutes        = 30,
                NoStopLossTrader      = noStop,
                TradesPerSessionMin   = tradesMin,
                TradesPerSessionMax   = tradesMax,
                SessionStartHour      = 9,
                SessionStartMinute    = 30,
                SessionEndHour        = sessionEndHour,
                SessionEndMinute      = 0,
                WeightRevengeEntry      = 0.18,
                WeightStopManipulation  = 0.23,
                WeightSizeOutlier       = 0.16,
                WeightHoldTimeCollapse  = 0.11,
                WeightPositionHold      = 0.14,
                WeightRuleCompliance    = 0.08,
                WeightOvertrading       = 0.10,
                Sensitivity             = PsiSensitivity.Balanced,
            };
            var bl  = new TradeBaseline();
            var eng = new PsiEngine(prof, bl);
            eng.StartNewSession(100.0);   // fresh session, full PSI
            return (eng, bl, prof);
        }

        /// <summary>
        /// Build a minimal in-memory position-snapshot set for engine calls.
        /// The engine reads Quantity (for D3 live size), HasStopOrder (for D2
        /// naked signal), HoldSeconds (for D5 hold signal) and PnL fields;
        /// tests that don't exercise D5/D2 can pass the default values.
        /// </summary>
        private static System.Collections.Generic.List<PositionSnapshot> Snaps(
            double netPosition, bool hasStop = true, double holdSeconds = 0)
        {
            var list = new System.Collections.Generic.List<PositionSnapshot>();
            if (netPosition > 0)
                list.Add(new PositionSnapshot
                {
                    Key          = "TEST::INSTR",
                    Quantity     = netPosition,
                    HasStopOrder = hasStop,
                    HoldSeconds  = holdSeconds,
                });
            return list;
        }

        /// <summary>Record a closing fill (has realised outcome).</summary>
        private static double Close(PsiEngine eng, TradeBaseline bl,
            double pnl, double size, DateTime fillTime,
            bool isWin = false, double holdSeconds = 60,
            double netPositionAfter = 0, int fillDirection = -1)
        {
            bl.UpdateOnExecution(pnl, size, holdSeconds, isWin);
            return eng.ProcessExecution(pnl, size, fillTime, isWin, holdSeconds,
                Snaps(netPositionAfter), fillDirection);
        }

        /// <summary>
        /// v1.1.1 closing-fill helper with explicit ExitKind + round-trip flags.
        /// Mirrors the full-signature overload on PsiEngine.ProcessExecution.
        ///
        ///   isRoundTripFinal=true  + roundTripPnl=pnl            → simple 1-fill close
        ///   isRoundTripFinal=false + roundTripPnl=(accumulated)  → partial of an ATM bracket
        ///   isRoundTripFinal=true  + roundTripPnl=(sum of parts) → final fill of an ATM bracket
        ///
        /// updateBaseline=false skips Welford updates — used when the same
        /// test simulates multiple partial fills within a single round-trip
        /// (baseline updates are round-trip-grained elsewhere in this harness).
        /// </summary>
        private static double CloseEx(PsiEngine eng, TradeBaseline bl,
            double pnl, double size, DateTime fillTime,
            double holdSeconds,
            ExitKind exitKind,
            bool   isRoundTripFinal,
            double roundTripPnl,
            double netPositionAfter = 0,
            int    fillDirection    = -1,
            bool   updateBaseline   = true)
        {
            bool roundTripWin = roundTripPnl > 0;
            if (updateBaseline && isRoundTripFinal)
                bl.UpdateOnExecution(roundTripPnl, size, holdSeconds, roundTripWin);

            return eng.ProcessExecution(
                pnl, size, fillTime, pnl > 0, holdSeconds,
                Snaps(netPositionAfter), fillDirection,
                exitKind, isRoundTripFinal, roundTripPnl);
        }

        /// <summary>Record an entry fill (no realised outcome).</summary>
        private static double EntryFill(PsiEngine eng,
            double size, DateTime fillTime,
            double netPosition = 0, int fillDirection = 1)
        {
            // pnl=0, holdSeconds=0 → hasRealizedOutcome = false inside the engine.
            return eng.ProcessExecution(0, size, fillTime, false, 0,
                Snaps(netPosition), fillDirection);
        }

        /// <summary>Build a CSV row string for persona output.</summary>
        private static string Row(PsiEngine eng, string persona, int tradeNum, string evt)
        {
            double sumDebt = eng.CurrentPsi + eng.DebtD1 + eng.DebtD2 + eng.DebtD3 + eng.DebtD4
                           + eng.DebtD5 + eng.DebtD6 + eng.DebtD7
                           + eng.FinancialStressDebt + eng.FatigueDebt;
            return string.Format(
                "{0},{1},{2:F2}," +
                "{3:F3},{4:F3},{5:F3},{6:F3},{7:F3},{8:F3},{9:F3},{10:F1}," +
                "{11:F3},{12:F3},{13:F3},{14:F3},{15:F3},{16:F3},{17:F3},{18:F3},{19:F3},{20:F3},{21}",
                persona, tradeNum, eng.CurrentPsi,
                // D-scores
                eng.ScoreD1, eng.ScoreD2, eng.ScoreD3, eng.ScoreD4,
                eng.ScoreD5, eng.ScoreD6, eng.ScoreD7,
                eng.ConsecutiveLosses,
                // C_i debt (all 7 dimensions)
                eng.DebtD1, eng.DebtD2, eng.DebtD3, eng.DebtD4,
                eng.DebtD5, eng.DebtD6, eng.DebtD7,
                // Hidden session debts
                eng.FinancialStressDebt, eng.FatigueDebt,
                sumDebt, evt);
        }

        // =====================================================================
        // Assertion helpers
        // =====================================================================

        private static void AssertRange(string tag, double actual, double min, double max,
            string extra = "")
        {
            bool   pass = actual >= min && actual <= max;
            string line = string.Format("  {0} {1}: value={2:F2}  expected [{3}–{4}]{5}",
                pass ? "[PASS]" : "[FAIL]", tag, actual, min, max,
                string.IsNullOrEmpty(extra) ? "" : "   # " + extra);
            Log(line);
            if (pass) _passed++; else _failed++;
        }

        private static void AssertLess(string tag, double actual, double max,
            string extra = "")
        {
            bool   pass = actual < max;
            string line = string.Format("  {0} {1}: value={2:F3}  expected < {3}{4}",
                pass ? "[PASS]" : "[FAIL]", tag, actual, max,
                string.IsNullOrEmpty(extra) ? "" : "   # " + extra);
            Log(line);
            if (pass) _passed++; else _failed++;
        }

        private static void AssertGreater(string tag, double actual, double min,
            string extra = "")
        {
            bool   pass = actual > min;
            string line = string.Format("  {0} {1}: value={2:F3}  expected > {3}{4}",
                pass ? "[PASS]" : "[FAIL]", tag, actual, min,
                string.IsNullOrEmpty(extra) ? "" : "   # " + extra);
            Log(line);
            if (pass) _passed++; else _failed++;
        }

        private static void AssertTrue(string tag, bool condition, string detail = "")
        {
            string line = string.Format("  {0} {1}{2}",
                condition ? "[PASS]" : "[FAIL]", tag,
                string.IsNullOrEmpty(detail) ? "" : "   # " + detail);
            Log(line);
            if (condition) _passed++; else _failed++;
        }

        // =====================================================================
        // Formatting helpers
        // =====================================================================

        private static void Log(string msg) { _log.AppendLine(msg); }

        private static void Banner(string title)
        {
            Log("");
            Log("=======================================================================");
            Log("  " + title);
            Log("=======================================================================");
        }

        private static void Section(string title)
        {
            Log("");
            Log("── " + title + " " + new string('─', Math.Max(0, 62 - title.Length)));
        }

        private static void Title(string title)
        {
            Log("");
            Log(title);
        }
    }
}
