﻿// SessionData.cs
//
// Per-session statistics accumulator + PSI history for alerts, the HUD
// sparkline, and the end-of-session report window.
//
// Thread-safety:
//   MeridianPSI updates session stats from the NT8 execution thread AND from
//   the 30-second System.Timers.Timer thread (PollPositions → PushPsiToHud).
//   The Hub opens SessionReportWindow on the UI thread.  All mutations and
//   ToHistoryEntry() are guarded by a single lock.  UI reads use
//   CreateSnapshot() so lists are not enumerated while another thread mutates.

using System;
using System.Collections.Generic;
using System.Linq;

namespace NinjaTrader.NinjaScript.AddOns
{
    // -------------------------------------------------------------------------
    public enum PsiZone { Stable = 0, Caution = 1, Warning = 2, Critical = 3 }

    // -------------------------------------------------------------------------
    /// <summary>
    /// Immutable record of a single execution fill (entry OR closing exit).
    /// Used to power two unique session report features:
    ///   1. Behavioral Quality Score  — was today's P&amp;L earned through disciplined
    ///      trading or through lucky reckless behaviour?
    ///   2. Tilt Cascade timeline     — second-level replay of how emotional state
    ///      evolved across the session.
    /// </summary>
    internal sealed class TradeRecord
    {
        public DateTime Time;
        /// <summary>False = opening/scale-in fill; true = closing fill.</summary>
        public bool     IsClosing;
        /// <summary>Meaningful only for closing fills.</summary>
        public bool     IsWin;
        /// <summary>Realised P&amp;L (closing fills) or 0 (entry fills).</summary>
        public double   Pnl;
        /// <summary>Seconds held; 0 for entry fills.</summary>
        public double   HoldSeconds;
        /// <summary>PSI value immediately after this fill was processed.</summary>
        public double   Psi;
        /// <summary>
        /// Instantaneous raw dimension signals at the moment of this fill (0–1 each).
        /// Populated from PsiEngine.ScoreD1-D6, NOT from DebtD1-D6.
        /// The raw signals are the correct metric for per-trade behavioural
        /// analysis (Tilt Cascade, Behavioral Quality Score) because they
        /// capture what fired at that specific fill, independent of decay.
        /// The live HUD bars use the EWMA debt (DebtD1-D6) instead.
        /// </summary>
        public double   D1, D2, D3, D4, D5, D6, D7;

        /// <summary>
        /// Highest single-dimension score at the moment of this fill.
        /// 0.0 = fully disciplined; 1.0 = maximum behavioural signal.
        /// </summary>
        public double MaxD =>
            Math.Max(D1, Math.Max(D2, Math.Max(D3, Math.Max(D4, Math.Max(D5, Math.Max(D6, D7))))));

        /// <summary>No significant behavioural signal (all D-scores below 30 %).</summary>
        public bool IsDisciplined => MaxD < 0.30;

        /// <summary>At least one D-score in the moderate range [30 %, 60 %).</summary>
        public bool IsCaution     => MaxD >= 0.30 && MaxD < 0.60;

        /// <summary>At least one D-score at or above 60 % — strong signal.</summary>
        public bool IsElevated    => MaxD >= 0.60;
    }

    // -------------------------------------------------------------------------
    internal sealed class PsiSnapshot
    {
        public DateTime Time;
        public double   Psi;
    }

    // -------------------------------------------------------------------------
    internal sealed class SessionData
    {
        private readonly object _sync = new object();

        // ── PSI zone thresholds — SINGLE SOURCE OF TRUTH ─────────────────────
        // These values are referenced by SessionData.ZoneOf(), PsiOverlayWindow
        // display logic, gauge zone tracks, and CheckAndFireAlerts.
        // Change them here and all consumers update automatically.
        internal const double ZoneStableThreshold      = 88.0;  // ≥ this → Stable (green)
        internal const double ZoneCriticalThreshold    = 55.0;  // < this → Critical (red)

        /// <summary>
        /// Minimum Composure % (0–100) for a session to be counted as a
        /// "stable/composed day" in streak counts, stable-days percentage,
        /// and Intelligence analytics.  Single source of truth; all
        /// consumers read this constant so changes propagate automatically.
        /// </summary>
        internal const double ComposureStableThreshold = 70.0;  // ≥ this → "stable day"

        // ── Identity ─────────────────────────────────────────────────────────
        public DateTime Date = DateTime.Today;

        // ── PSI timeline (bounded to avoid runaway memory during long sessions)
        public readonly List<PsiSnapshot> PsiHistory = new List<PsiSnapshot>(600);
        private const int MaxSnapshots = 600;

        // ── PSI aggregates ───────────────────────────────────────────────────
        public double StartPsi = 100.0;
        public double FinalPsi = 100.0;
        public double MinPsi   = 100.0;

        // ── Time-in-zone accounting ──────────────────────────────────────────
        public TimeSpan TimeInCaution  = TimeSpan.Zero;
        public TimeSpan TimeInCritical = TimeSpan.Zero;

        private PsiZone  _lastZone      = PsiZone.Stable;
        private DateTime _zoneEntryTime = DateTime.MinValue;

        // Zone-time accounting only starts once the FIRST actual trade fill
        // arrives.  Pre-market monitoring (timer ticks, order updates while
        // waiting for the session open) must not inflate the Stable bar.
        private bool     _tradeActivityStarted = false;

        // Timestamp of the first fill this session (same domain as
        // <see cref="TradeMonitor.PushPsiToHud"/>'s <c>eventTime</c> — fill time in
        // Playback/Replay, <c>TradingClock.EngineTime</c> in Live).
        // Used by ToHistoryEntry() for DurationMinutes so the history report is
        // consistent with the HUD Duration field (both start from first fill, not
        // from the first timer tick or PSI snapshot).
        private DateTime _firstFillTime = DateTime.MinValue;

        // Latest PSI push time (same domain as _firstFillTime).  Updated on every
        // RecordPsi while the session is active so TotalMinutes advances between fills.
        private DateTime _lastPsiEventTime = DateTime.MinValue;

        // PSI value and timestamp of the LAST fill this session.
        // ToHistoryEntry() uses these for FinalPsi and DurationMinutes instead of
        // the live (timer-updated) values.  This ensures the session record captures
        // "psychological state when you exited the market" rather than the partially
        // recovered state that accumulates during post-trading idle time.
        private DateTime _lastFillTime = DateTime.MinValue;
        private double   _lastFillPsi  = 100.0;

        // ── Trade statistics ─────────────────────────────────────────────────
        public int    TotalTrades;
        public int    WinTrades;
        /// <summary>Net realized P&amp;L accumulated across all closing fills.</summary>
        public double TotalPnl;

        // ── Alert count ──────────────────────────────────────────────────────
        public int AlertsFired;

        // ── Naked-position (no stop-loss) detections ─────────────────────────
        // Incremented once per timer poll that finds an unprotected open position.
        // Multiple consecutive polls in one episode all count; multiply by the
        // poll interval (~30 s) to approximate total naked exposure time.
        public int NakedPositionDetections;

        // ── Per-fill trade records (entries + exits) ──────────────────────────
        // Powers the Behavioral Quality Score and Tilt Cascade report sections.
        // Capped at MaxTradeRecords to bound memory during very active sessions.
        public readonly List<TradeRecord> Trades = new List<TradeRecord>(200);
        private const int MaxTradeRecords = 200;

        // ── Dimension cumulative raw scores D1-D6 (instantaneous ScoreD1-D6 per trade)
        // Summed over all closing trades; used to derive relative % contribution
        // per dimension in the session report Signal Breakdown section.
        public readonly double[] DimCumScore = new double[7];

        // ── Cross-session comparison (populated when the new session starts) ─
        public double PrevFinalPsi = 100.0;
        public int    PrevAlerts;

        /// <summary>
        /// PSI at the time of the last fill, or <see cref="FinalPsi"/> if no fills
        /// have occurred yet.  Used by <see cref="MeridianPSI"/> to set
        /// <c>PrevFinalPsi</c> on the incoming session so that "vs previous session"
        /// comparisons reflect trading-end state rather than the post-trade recovered value.
        /// </summary>
        public double LastFillPsi
        {
            get { lock (_sync) return _lastFillTime != DateTime.MinValue ? _lastFillPsi : FinalPsi; }
        }

        /// <summary>
        /// Minutes from the first fill to the latest <see cref="RecordPsi"/> timestamp
        /// (0 if no fills yet).  Matches the PSI timeline clock (fill/replay time or
        /// <c>TradingClock.EngineTime</c>), not <c>DateTime.Now</c>, so Guard
        /// <c>SessionMinutesOver</c> stays correct in Market Replay.
        /// </summary>
        public double TotalMinutes
        {
            get
            {
                lock (_sync)
                {
                    if (_firstFillTime == DateTime.MinValue) return 0.0;
                    if (_lastPsiEventTime == DateTime.MinValue) return 0.0;
                    return Math.Max(0.0, (_lastPsiEventTime - _firstFillTime).TotalMinutes);
                }
            }
        }

        // ── Session-peak EWMA debt for composure calculation ──────────────────
        // D3 (oversize), D5 (overstay), and D2 (stop manipulation) drive the
        // three-component Composure score.  D3 violations fire at *entry* time;
        // D2/D5 accumulate primarily during timer polls.  None are captured by
        // examining instantaneous D-scores at closing fills, so we track the
        // session peak of each EWMA debt independently.
        private double _maxDebtD3 = 0.0;
        private double _maxDebtD5 = 0.0;
        private double _maxDebtD2 = 0.0;
        private double _maxDebtD6 = 0.0; // Rule compliance (session-window violations)

        // Set by FromArchive() so GetZoneComposurePct() can compute stableMin for
        // historical sessions where _firstFillTime/_lastFillTime are not available.
        internal double ArchivedActiveMinutes = -1.0;

        // ═════════════════════════════════════════════════════════════════════
        // Mutation helpers — called from NT8 event thread
        // ═════════════════════════════════════════════════════════════════════

        /// <summary>
        /// Record a new PSI value.  Updates timeline history and zone-time accounting.
        /// </summary>
        /// <param name="t">Timestamp of this PSI reading.</param>
        /// <param name="psi">Current PSI value.</param>
        /// <param name="fromFill">
        /// True when this update was triggered by an actual execution fill.
        /// Zone-time accounting is suppressed until the first fill so that pre-market
        /// monitoring time (timer ticks while waiting for the session open) does not
        /// artificially inflate the STABLE bar in the session report.
        /// </param>
        public void RecordPsi(DateTime t, double psi, bool fromFill = false)
        {
            lock (_sync)
            {
                if (PsiHistory.Count == 0) StartPsi = psi;
                FinalPsi = psi;
                if (psi < MinPsi) MinPsi = psi;

                if (PsiHistory.Count < MaxSnapshots)
                    PsiHistory.Add(new PsiSnapshot { Time = t, Psi = psi });

                // Start zone-time accounting only after the first real fill arrives.
                if (fromFill && !_tradeActivityStarted)
                {
                    _tradeActivityStarted = true;
                    _firstFillTime        = t;          // anchor for DurationMinutes
                    _lastPsiEventTime     = t;
                    _lastFillTime         = t;
                    _lastFillPsi          = psi;
                    _lastZone      = ZoneOf(psi);
                    _zoneEntryTime = t;
                    return;
                }
                if (!_tradeActivityStarted) return;

                _lastPsiEventTime = t;

                // Capture the most recent fill's timestamp and PSI for accurate
                // session-end state (FinalPsi, duration) in ToHistoryEntry().
                if (fromFill)
                {
                    _lastFillTime = t;
                    _lastFillPsi  = psi;
                }

                // Zone-time accounting
                PsiZone z = ZoneOf(psi);
                if (_zoneEntryTime == DateTime.MinValue)
                {
                    _lastZone = z;
                    _zoneEntryTime = t;
                    return;
                }
                if (z != _lastZone)
                {
                    AccrueZone(_lastZone, t - _zoneEntryTime);
                    _lastZone = z;
                    _zoneEntryTime = t;
                }
            }
        }

        /// <summary>
        /// Call once when the session ends to flush the still-open zone slice.
        /// Safe to call multiple times — each call only accrues since the last.
        /// </summary>
        public void Flush(DateTime now)
        {
            lock (_sync)
            {
                if (_zoneEntryTime == DateTime.MinValue) return;
                var d = now - _zoneEntryTime;
                if (d > TimeSpan.Zero) AccrueZone(_lastZone, d);
                _zoneEntryTime = now; // reset so repeated flushes don't double-count
            }
        }

        /// <summary>
        /// Record a completed (closing) trade outcome, dimension signals, and
        /// the P&amp;L / PSI context needed for the Behavioral Quality analysis.
        /// </summary>
        public void RecordTrade(DateTime time, bool isWin, double pnl, double holdSeconds,
                                double psi,
                                double d1, double d2, double d3,
                                double d4, double d5, double d6, double d7)
        {
            lock (_sync)
            {
                TotalTrades++;
                if (isWin) WinTrades++;
                TotalPnl += pnl;
                DimCumScore[0] += d1;
                DimCumScore[1] += d2;
                DimCumScore[2] += d3;
                DimCumScore[3] += d4;
                DimCumScore[4] += d5;
                DimCumScore[5] += d6;
                DimCumScore[6] += d7;

                if (Trades.Count < MaxTradeRecords)
                    Trades.Add(new TradeRecord
                    {
                        Time        = time,
                        IsClosing   = true,
                        IsWin       = isWin,
                        Pnl         = pnl,
                        HoldSeconds = holdSeconds,
                        Psi         = psi,
                        D1 = d1, D2 = d2, D3 = d3, D4 = d4, D5 = d5, D6 = d6, D7 = d7,
                    });
            }
        }

        /// <summary>
        /// Record an opening or scale-in fill for the Tilt Cascade timeline.
        /// Does NOT update trade-count statistics (only closing fills count as trades).
        /// </summary>
        public void RecordEntry(DateTime time, double psi,
                                double d1, double d2, double d3,
                                double d4, double d5, double d6, double d7)
        {
            lock (_sync)
            {
                if (Trades.Count < MaxTradeRecords)
                    Trades.Add(new TradeRecord
                    {
                        Time      = time,
                        IsClosing = false,
                        Psi       = psi,
                        D1 = d1, D2 = d2, D3 = d3, D4 = d4, D5 = d5, D6 = d6, D7 = d7,
                    });
            }
        }

        /// <summary>
        /// Thread-safe copy for UI (Hub session report).  The live <see cref="SessionData"/>
        /// continues to receive timer + fill updates while the snapshot is rendered.
        /// </summary>
        internal void SetSessionDate(DateTime sessionAnchorDate)
        {
            lock (_sync) { Date = sessionAnchorDate; }
        }

        internal bool HasRecordedTrades()
        {
            lock (_sync) { return TotalTrades > 0; }
        }

        internal void IncrementNakedPositionDetections()
        {
            lock (_sync) { NakedPositionDetections++; }
        }

        internal void IncrementAlertsFired()
        {
            lock (_sync) { AlertsFired++; }
        }

        /// <summary>
        /// <summary>
        /// Records the current D2, D3, and D5 EWMA debt values so the Composure
        /// score can account for all three structural rule dimensions.  D3 (oversize)
        /// violations fire at entry time; D2/D5 accumulate on timer ticks.  Neither
        /// is reliably captured at closing-fill time, so we track session peaks here.
        /// Call once per <c>PushPsiToHud</c> cycle.
        /// </summary>
        internal void UpdatePeakDebts(double debtD2, double debtD3, double debtD5, double debtD6)
        {
            lock (_sync)
            {
                if (debtD3 > _maxDebtD3) _maxDebtD3 = debtD3;
                if (debtD5 > _maxDebtD5) _maxDebtD5 = debtD5;
                if (debtD2 > _maxDebtD2) _maxDebtD2 = debtD2;
                if (debtD6 > _maxDebtD6) _maxDebtD6 = debtD6;
            }
        }

        /// <summary>
        /// Returns the three normalised Composure components (each 0–1) derived from
        /// session-peak EWMA debts.  Used by <c>SessionReportWindow</c> to render the
        /// live Composure card with the same formula as <c>ToHistoryEntry()</c>.
        /// </summary>
        internal void GetComposureComponents(
            out double oversizeComp, out double holdComp, out double slComp, out double ruleComp)
        {
            lock (_sync)
            {
                oversizeComp = 1.0 - Math.Min(1.0, _maxDebtD3 / 100.0);
                holdComp     = 1.0 - Math.Min(1.0, _maxDebtD5 / 100.0);
                slComp       = 1.0 - Math.Min(1.0, _maxDebtD2 / 100.0);
                ruleComp     = 1.0 - Math.Min(1.0, _maxDebtD6 / 100.0);
            }
        }

        /// <summary>
        /// Returns the Composure score based on time spent in each PSI zone.
        /// Formula: (stableMin × 1.0 + cautionMin × 0.3 + criticalMin × 0.05) / totalMin × 100
        /// Caution carries only 0.3 weight (was 0.5) — entering the Caution zone is a
        /// warning signal, not half-credit.  Critical carries 0.05.  A session with 30%
        /// Caution time now scores ~78% rather than 84%, keeping the colour honest.
        /// </summary>
        internal int GetZoneComposurePct()
        {
            GetZoneTimes(out double stableMin, out double cautionMin, out double criticalMin);
            double totalMin = stableMin + cautionMin + criticalMin;
            if (totalMin < 0.1) return 100;
            double score = (stableMin * 1.0 + cautionMin * 0.3 + criticalMin * 0.05) / totalMin;
            return (int)(100.0 * Math.Max(0.0, Math.Min(1.0, score)));
        }

        /// <summary>
        /// Returns the three computed PSI zone times in minutes, correctly accounting
        /// for both live sessions (uses fill timestamps) and archived sessions
        /// (uses <see cref="ArchivedActiveMinutes"/>).
        /// </summary>
        internal void GetZoneTimes(out double stableMin, out double cautionMin, out double criticalMin)
        {
            lock (_sync)
            {
                cautionMin  = TimeInCaution.TotalMinutes;
                criticalMin = TimeInCritical.TotalMinutes;

                double activeMin;
                if (_firstFillTime != DateTime.MinValue)
                {
                    var end  = _lastFillTime != DateTime.MinValue ? _lastFillTime : DateTime.Now;
                    activeMin = Math.Max(0, (end - _firstFillTime).TotalMinutes);
                }
                else if (ArchivedActiveMinutes >= 0)
                {
                    activeMin = ArchivedActiveMinutes;
                }
                else
                {
                    activeMin = cautionMin + criticalMin;
                }

                stableMin = Math.Max(0, activeMin - cautionMin - criticalMin);
            }
        }

        /// <summary>
        /// Exposes the three session-peak EWMA debt values for persistence in
        /// <see cref="SessionDetailStore"/> so historical sessions can reconstruct
        /// the Composure component bars in <see cref="SessionReportWindow"/>.
        /// </summary>
        internal void GetPeakDebts(out double d2, out double d3, out double d5, out double d6)
        {
            lock (_sync)
            {
                d2 = _maxDebtD2;
                d3 = _maxDebtD3;
                d5 = _maxDebtD5;
                d6 = _maxDebtD6;
            }
        }

        /// <summary>
        /// Injects pre-computed peak EWMA debt values into the private fields.
        /// Used by <see cref="FromArchive"/> when reconstructing a historical session
        /// so <see cref="GetComposureComponents"/> returns the correct stored values.
        /// </summary>
        internal void SetPeakDebts(double d2, double d3, double d5, double d6)
        {
            lock (_sync)
            {
                _maxDebtD2 = d2;
                _maxDebtD3 = d3;
                _maxDebtD5 = d5;
                _maxDebtD6 = d6;
            }
        }

        /// <summary>
        /// Returns a thread-safe snapshot of the PSI history list.
        /// Used by <see cref="SessionDetailStore.Save"/> on the NT8 event thread.
        /// </summary>
        internal List<PsiSnapshot> GetPsiHistorySnapshot()
        {
            lock (_sync)
            {
                var copy = new List<PsiSnapshot>(PsiHistory.Count);
                foreach (var p in PsiHistory)
                    copy.Add(new PsiSnapshot { Time = p.Time, Psi = p.Psi });
                return copy;
            }
        }

        /// <summary>
        /// Returns a thread-safe snapshot of the trade record list.
        /// Used by <see cref="SessionDetailStore.Save"/> on the NT8 event thread.
        /// </summary>
        internal List<TradeRecord> GetTradesSnapshot()
        {
            lock (_sync)
            {
                var copy = new List<TradeRecord>(Trades.Count);
                foreach (var t in Trades)
                    copy.Add(new TradeRecord
                    {
                        Time        = t.Time,
                        IsClosing   = t.IsClosing,
                        IsWin       = t.IsWin,
                        Pnl         = t.Pnl,
                        HoldSeconds = t.HoldSeconds,
                        Psi         = t.Psi,
                        D1 = t.D1, D2 = t.D2, D3 = t.D3,
                        D4 = t.D4, D5 = t.D5, D6 = t.D6, D7 = t.D7,
                    });
                return copy;
            }
        }

        /// <summary>
        /// Reconstructs a <see cref="SessionData"/> from a persisted
        /// <see cref="SessionHistoryEntry"/> (Tier-1 summary) and a
        /// <see cref="SessionDetail"/> (Tier-2 detail file), producing an object
        /// that can be passed directly to <see cref="SessionReportWindow"/>.
        ///
        /// The reconstructed instance is read-only after creation; it must never
        /// be passed to <see cref="MeridianPSI"/> mutation paths.
        /// </summary>
        internal static SessionData FromArchive(SessionHistoryEntry summary,
                                                SessionDetail        detail)
        {
            var sd = new SessionData();

            // ── Identity and aggregates from Tier-1 summary ───────────────────
            sd.Date                    = summary.Date;
            sd.StartPsi                = summary.StartPsi;
            sd.FinalPsi                = summary.FinalPsi;
            sd.MinPsi                  = summary.MinPsi;
            sd.TotalTrades             = summary.TotalTrades;
            sd.WinTrades               = summary.WinTrades;
            sd.TotalPnl                = summary.TotalPnl;
            sd.AlertsFired             = summary.AlertsFired;
            sd.NakedPositionDetections = summary.NakedPositionDetections;

            // Zone times (convert stored minutes back to TimeSpan)
            sd.TimeInCaution  = TimeSpan.FromMinutes(summary.TimeInCautionMin);
            sd.TimeInCritical = TimeSpan.FromMinutes(summary.TimeInCriticalMin);

            // Supply the active session duration so GetZoneComposurePct() can
            // compute stableMin correctly for archived sessions (where _firstFillTime
            // and _lastFillTime are not populated).
            sd.ArchivedActiveMinutes = summary.DurationMinutes;

            // Cumulative dimension scores
            sd.DimCumScore[0] = summary.D1;
            sd.DimCumScore[1] = summary.D2;
            sd.DimCumScore[2] = summary.D3;
            sd.DimCumScore[3] = summary.D4;
            sd.DimCumScore[4] = summary.D5;
            sd.DimCumScore[5] = summary.D6;
            sd.DimCumScore[6] = summary.D7;

            // ── Comparison values and composure peaks from Tier-2 detail ─────
            sd.PrevFinalPsi = detail.PrevFinalPsi;
            sd.PrevAlerts   = detail.PrevAlerts;
            sd.SetPeakDebts(detail.PeakDebtD2, detail.PeakDebtD3, detail.PeakDebtD5, detail.PeakDebtD6);

            // ── PSI timeline ──────────────────────────────────────────────────
            foreach (var p in detail.PsiHistory)
                sd.PsiHistory.Add(new PsiSnapshot
                {
                    Time = new DateTime(p.Ticks, DateTimeKind.Local),
                    Psi  = p.V,
                });

            // ── Per-fill trade records ─────────────────────────────────────────
            foreach (var f in detail.Fills)
                sd.Trades.Add(new TradeRecord
                {
                    Time        = new DateTime(f.Ticks, DateTimeKind.Local),
                    IsClosing   = f.IsClosing,
                    IsWin       = f.IsWin,
                    Pnl         = f.Pnl,
                    HoldSeconds = f.HoldSeconds,
                    Psi         = f.Psi,
                    D1 = f.D1, D2 = f.D2, D3 = f.D3,
                    D4 = f.D4, D5 = f.D5, D6 = f.D6, D7 = f.D7,
                });

            return sd;
        }

        internal void CopyHudStats(out int totalTrades, out int winTrades, out int alertsFired)
        {
            lock (_sync)
            {
                totalTrades = TotalTrades;
                winTrades   = WinTrades;
                alertsFired = AlertsFired;
            }
        }

        internal SessionData CreateSnapshot()
        {
            lock (_sync)
            {
                var c = new SessionData();
                c.Date                    = Date;
                c.StartPsi                = StartPsi;
                c.FinalPsi                = FinalPsi;
                c.MinPsi                  = MinPsi;
                c.TimeInCaution           = TimeInCaution;
                c.TimeInCritical          = TimeInCritical;
                c._lastZone               = _lastZone;
                c._zoneEntryTime          = _zoneEntryTime;
                c._tradeActivityStarted   = _tradeActivityStarted;
                c._firstFillTime          = _firstFillTime;
                c._lastPsiEventTime       = _lastPsiEventTime;
                c._lastFillTime           = _lastFillTime;
                c._lastFillPsi            = _lastFillPsi;
                c.TotalTrades             = TotalTrades;
                c.WinTrades               = WinTrades;
                c.TotalPnl                = TotalPnl;
                c.AlertsFired             = AlertsFired;
                c.NakedPositionDetections = NakedPositionDetections;
                c.PrevFinalPsi            = PrevFinalPsi;
                c.PrevAlerts              = PrevAlerts;
                c._maxDebtD3              = _maxDebtD3;
                c._maxDebtD5              = _maxDebtD5;
                c._maxDebtD2              = _maxDebtD2;
                c._maxDebtD6              = _maxDebtD6;
                for (int i = 0; i < 7; i++)
                    c.DimCumScore[i] = DimCumScore[i];
                foreach (var p in PsiHistory)
                    c.PsiHistory.Add(new PsiSnapshot { Time = p.Time, Psi = p.Psi });
                foreach (var t in Trades)
                    c.Trades.Add(new TradeRecord
                    {
                        Time        = t.Time,
                        IsClosing   = t.IsClosing,
                        IsWin       = t.IsWin,
                        Pnl         = t.Pnl,
                        HoldSeconds = t.HoldSeconds,
                        Psi         = t.Psi,
                        D1 = t.D1, D2 = t.D2, D3 = t.D3, D4 = t.D4, D5 = t.D5, D6 = t.D6, D7 = t.D7,
                    });
                return c;
            }
        }

        // ═════════════════════════════════════════════════════════════════════
        // History export
        // ═════════════════════════════════════════════════════════════════════

        /// <summary>
        /// Produces a <see cref="SessionHistoryEntry"/> snapshot from the current
        /// session state.  Call after <see cref="Flush"/> so zone-time totals are
        /// complete.
        /// </summary>
        public SessionHistoryEntry ToHistoryEntry()
        {
            lock (_sync)
            {
                // Average PSI: mean of all recorded snapshots (captures intra-session
                // volatility better than a simple start/end midpoint).
                double avgPsi = PsiHistory.Count > 0
                    ? PsiHistory.Average(p => p.Psi)
                    : FinalPsi;

                // Active session duration: from first fill to LAST FILL (not to the
                // last PSI snapshot, which continues being written by the timer during
                // post-trading idle time and would inflate duration).
                int durationMin = 0;
                if (_firstFillTime != DateTime.MinValue && _lastFillTime != DateTime.MinValue)
                {
                    durationMin = (int)(_lastFillTime - _firstFillTime).TotalMinutes;
                    durationMin = Math.Max(0, durationMin);
                }

                // Stable time = total – caution – critical (clamp to zero if rounding
                // pushes it negative).
                double stableMin = Math.Max(0.0,
                    durationMin - TimeInCaution.TotalMinutes - TimeInCritical.TotalMinutes);

                // Composure score: time-weighted PSI zone distribution.
                // Each minute is scored by the PSI zone the trader was in:
                //   Stable   (PSI ≥ 75) → weight 1.0
                //   Caution  (55–74)    → weight 0.3  (warning signal, not half-credit)
                //   Critical (< 55)     → weight 0.05
                // Formula: (stableMin×1.0 + cautionMin×0.3 + criticalMin×0.05) / totalMin × 100
                // Caution receives only 30% credit so a session with significant Caution
                // time scores meaningfully lower, keeping the colour consistent with the
                // zone-time bar the user sees.
                double cautionMin2   = TimeInCaution.TotalMinutes;
                double criticalMin2  = TimeInCritical.TotalMinutes;
                double totalZoneMin  = stableMin + cautionMin2 + criticalMin2;
                int composurePct     = totalZoneMin > 0.1
                    ? (int)(100.0 * (stableMin * 1.0 + cautionMin2 * 0.3 + criticalMin2 * 0.05)
                            / totalZoneMin)
                    : 100;

                return new SessionHistoryEntry
                {
                    Date                    = Date,
                    StartPsi                = Math.Round(StartPsi, 1),
                    MinPsi                  = Math.Round(MinPsi,   1),
                    // Use last-fill PSI, not the live (timer-updated) value.
                    // FinalPsi continues recovering after trading stops; _lastFillPsi
                    // records "your psychological state when you exited the market."
                    FinalPsi                = Math.Round(
                        _lastFillTime != DateTime.MinValue ? _lastFillPsi : FinalPsi, 1),
                    AvgPsi                  = Math.Round(avgPsi,   1),
                    TotalTrades             = TotalTrades,
                    WinTrades               = WinTrades,
                    TotalPnl                = Math.Round(TotalPnl, 2),
                    DurationMinutes         = durationMin,
                    TimeInStableMin         = Math.Round(stableMin,                    1),
                    TimeInCautionMin        = Math.Round(TimeInCaution.TotalMinutes,   1),
                    TimeInCriticalMin       = Math.Round(TimeInCritical.TotalMinutes,  1),
                    AlertsFired             = AlertsFired,
                    NakedPositionDetections = NakedPositionDetections,
                    ComposurePct            = composurePct,
                    D1 = Math.Round(DimCumScore[0], 3),
                    D2 = Math.Round(DimCumScore[1], 3),
                    D3 = Math.Round(DimCumScore[2], 3),
                    D4 = Math.Round(DimCumScore[3], 3),
                    D5 = Math.Round(DimCumScore[4], 3),
                    D6 = Math.Round(DimCumScore[5], 3),
                    D7 = Math.Round(DimCumScore[6], 3),
                };
            }
        }

        // ═════════════════════════════════════════════════════════════════════
        // Static helpers
        // ═════════════════════════════════════════════════════════════════════

        internal static PsiZone ZoneOf(double psi) =>
            psi >= ZoneStableThreshold ? PsiZone.Stable
          : psi >= 72.0               ? PsiZone.Caution
          : psi >= ZoneCriticalThreshold ? PsiZone.Warning
          :                               PsiZone.Critical;

        private void AccrueZone(PsiZone z, TimeSpan d)
        {
            if (d <= TimeSpan.Zero) return;
            if (z == PsiZone.Caution)  TimeInCaution  += d;
            if (z == PsiZone.Warning)  TimeInCaution  += d; // Warning accrues to Caution bucket (backward-compat)
            if (z == PsiZone.Critical) TimeInCritical += d;
        }
    }
}
