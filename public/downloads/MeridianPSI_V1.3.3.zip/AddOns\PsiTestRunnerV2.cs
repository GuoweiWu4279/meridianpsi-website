﻿// PsiTestRunnerV2.cs
//
// Offline automated test harness for PsiEngineV2 (the v2.0 evidence-
// accumulator architecture).
//
// Scope: acceptance tests for the v2.0 design contract
//   (see ARCHITECTURE.md §15 and psi-v2-evidence-accumulator.mdc).
//
// This runner is INDEPENDENT of the v1 PsiTestRunner — v1 tests
// (S01–S49) continue to exercise PsiEngine unchanged.  V2 tests
// (S201–S220) exercise PsiEngineV2 in isolation.  Both can be run in
// the same session; results go to separate files.
//
// HOW TO RUN (once M1 wiring lands):
//   In MeridianPSI property panel, toggle "Run PSI V2 Tests" to true.
//   In Phase 0, call PsiTestRunnerV2.RunAll() from anywhere (no
//   MeridianPSI wiring yet — call directly to exercise the engine).
//
// OUTPUT:
//   Desktop\PsiV2TestResults.txt  — PASS/FAIL lines for every scenario
//   Desktop\PsiV2Calibration.csv  — key measurements for calibration
//                                    review (PSI / P / C_i / E_i)
//
// DATA SAFETY:
//   V2 engine has no disk I/O of its own.  StrategyProfile /
//   TradeBaseline constructed in-memory only — no existing baseline
//   or profile files are touched.

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal static class PsiTestRunnerV2
    {
        /// <summary>
        /// Flip to true to run V2 acceptance suite on AddOn startup.
        /// Kept false by default — results depend on V2 engine which is
        /// itself disabled in Phase 0.  Manual invocation (RunAll()) is
        /// the recommended workflow during Phase 0 calibration review.
        /// </summary>
        public static bool RunOnStartup = false;

        // ── State ─────────────────────────────────────────────────────────
        private static int           _passed;
        private static int           _failed;
        private static StringBuilder _log;
        private static StringBuilder _csv;

        private static readonly string DesktopDir =
            Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory);
        private static string ResultsFile => Path.Combine(DesktopDir, "PsiV2TestResults.txt");
        private static string CsvFile     => Path.Combine(DesktopDir, "PsiV2Calibration.csv");

        // =====================================================================
        // Entry point
        // =====================================================================

        public static string RunAll()
        {
            _passed = 0;
            _failed = 0;
            _log    = new StringBuilder();
            _csv    = new StringBuilder();
            _csv.AppendLine("Scenario,Stage,PSI,P,C1,C2,C3,C4,C5,C6,C7,E1,E2,E3,E4,E5,E6,E7,Streak,SessionPnL,Note");

            Banner("PSI v2.0 — Evidence-Accumulator Acceptance Suite");
            Banner("Started: " + DateTime.Now);

            Section("CALIBRATION TARGETS (S201–S206)");
            S201_SingleQuickManualExit();
            S202_FiveConsecutiveQuickExits();
            S203_MaxDailyLossBreach();
            S204_OversizeEntry();
            S205_SessionWindowFarOutside();
            S206_PauseRuleBroken();

            Section("INVARIANT & DISCIPLINE (S207–S212)");
            S207_BracketStopLossNotPenalised();
            S208_BracketTargetNotPenalised();
            S209_FlatIdleDecaysAllDims();
            S210_ReconcileDoesNotDoubleCount();
            S211_PressureAmplifiesClassBOnly();
            S212_CleanSessionPressureIsZero();

            Section("DYNAMICS (S213–S215)");
            S213_DecayGatedByOneMinusP();
            S214_PnLDoesNotDirectlyPenalisePsi();
            S215_ClassANotAmplifiedByPressure();

            Section("LIFECYCLE & IDENTITY (S216–S220)");
            S216_TrackingCorrectionPreservesE();
            S217_StartNewSessionCollapsesToCarry();
            S218_OvernightDecayReducesEAndCarry();
            S219_ResetClockAnchorPreventsJumpDecay();
            S220_AggregationIdentity();

            Section("TIER 1 — PSYCHOLOGY PATTERNS (S221–S231)");
            S221_RevengeEntryFiresD1ClassB();
            S222_MartingaleDoublingAfterLoss();
            S223_AveragingDownOnLosingPosition();
            S224_FlipFlopOverCadence();
            S225_PostWinOversizeStillPenalised();
            S226_EndOfSessionTilt();
            S227_HesitationFreezeDoesNotDrift();
            S228_CutWinnersShortLetLosersRun();
            S229_ThreeDisciplinedStopsNoReentry();
            S230_BracketExitDoesNotStartRevengeClock();
            S231_StopWideningAdverseSlMove();

            Section("TIER 2 — MULTI-DIMENSION INTERACTIONS (S232–S236)");
            S232_OversizePlusOverstay();
            S233_OversizePlusRevenge();
            S234_OutOfSessionPlusOversize();
            S235_MaxDailyLossBreachContinued();
            S236_All7DimsFiring();

            Section("TIER 3 — NUMERICAL SAFETY & EDGE CASES (S237–S242)");
            S237_BackwardFillTimeBounded();
            S238_ZeroHoldDurationSafe();
            S239_LongIdleDecaysBounded();
            S240_ColdBaselineFallback();
            S241_HugeOversizeStillBounded();
            S242_PsiFloorAtZero();

            Section("TIER 4 — PRESSURE DERIVATION (S243–S246)");
            S243_PressureIsMaxNotSum();
            S244_StreakFactorMonotonic();
            S245_OpenLoserSaturation();
            S246_DailyProxLinearToBreach();

            Section("TIER 5 — DETERMINISM & MONOTONICITY (S247–S249)");
            S247_DeterminismIdenticalInputs();
            S248_CommitMonotoneUp();
            S249_DecayMonotoneDown();

            Section("TIER 6 — HISTORICAL V1 BUG REGRESSION (S250–S252)");
            S250_D3PnlFlipNeutrality();
            S251_TimeDomainIndependence();
            S252_SnapUpNotRequired();

            Section("TIER 7 — NARRATIVE REALISTIC SESSIONS (S253–S255)");
            S253_FullTiltDay();
            S254_GoodDisciplinedSession();
            S255_RecoveryDayFromCarryDebt();

            Section("TIER 8 — INVARIANT CONTRACT I1–I6 (I301–I312)");
            I301_I1_D3_MildSeverityBounded();
            I302_I1_D6_SingleEventBounded();
            I303_I3_D3_ModerateSeverityCritical();
            I304_I3_D6_ModerateSingleEventCritical();
            I305_I4_D3_ExtremeSeveritySaturates();
            I306_I4_D3_ExtremeDoesNotTotalCollapse();
            I307_I5_D3_RecoveryAt30Min();
            I308_I5_D3_RecoveryAt120Min();
            I309_I6_D3_PersonalizationRelativeSeverity();
            I310_D7_PartialFillsCountAsOneDecision();
            I311_D7_SeparateOrdersCountSeparately();
            I312_D3_PartialFillsSumToSaturatingWhole();

            Section("TIER 8b — D5 OVERSTAY REDESIGN (I313–I315)");
            I313_D5_PnlDirectReadNeutrality();
            I314_D5_SaturatingClassA_Invariants();
            I315_D5_TimeDomainIndependence();

            Section("TIER 8c — D2/D6/D7 SATURATING-MARGINAL REDESIGN (I316–I320)");
            I316_I4_D6_ExtremeOvershootSaturates();
            I317_I6_D6_PersonalizationRelativeSeverity();
            I318_I1_D2_MildPastGraceBounded();
            I319_I3_D2_ModeratePastGraceCritical();
            I320_I6_D7_PersonalizationRelativeSeverity();

            Section("TIER 9 — NARRATIVE PSYCHOLOGICAL JOURNEY TESTS (S256–S261)");
            S256_OversizeIncident();
            S257_TiltArc();
            S258_OverconfidenceArc();
            S259_RevengeThenSelfCorrection();
            S260_GhostRecoveryDay();
            S261_CleanScalper();

            Banner(string.Format("Completed: passed={0}  failed={1}  total={2}",
                _passed, _failed, _passed + _failed));

            string report = _log.ToString();
            try
            {
                File.WriteAllText(ResultsFile, report);
                File.WriteAllText(CsvFile,     _csv.ToString());
            }
            catch { /* report returned to caller regardless */ }

            return report;
        }

        // =====================================================================
        // S201 — Single isolated quick manual exit on a flat baseline.
        // Acceptance: PSI remains ≥ 95 — a single Class B signal with P=0
        // should barely move PSI.  This is the "user's quick scalp" case the
        // v2.0 redesign was specifically built to stop over-penalising.
        // =====================================================================
        private static void S201_SingleQuickManualExit()
        {
            Title("S201 — Single quick manual exit (Class B only, P=0)");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            // Entry → 10 s manual exit.  Loss is small so no P pressure.
            EntryFill(eng, t, 1, fillDir: +1);
            t = t.AddSeconds(10);
            Close(eng, bl, -40, 1, t, isWin: false, holdSec: 10,
                  exitKind: ExitKind.Manual);

            Snapshot(eng, "S201", "after single quick manual exit");
            AssertGreater("S201 PSI ≥ 95", eng.CurrentPsi, 95.0,
                "one isolated quick manual exit with no pressure context " +
                "must earn only weak evidence (~3 PSI pts max)");
            AssertLess("S201 Pressure P = 0", eng.Pressure, 0.05,
                "no streak / open loser / daily-loss proximity → P ≈ 0");
        }

        // =====================================================================
        // S202 — Pattern of 5 losses each held MUCH LONGER than μWinHold.
        // Hold Bias: loss-aversion manifests as holding losers with the same
        // patience the trader normally reserves for winners ("it will come back").
        //
        // Profile: MaxHoldMinutes=2 → muWinHold_prior=30 s, D4 threshold=60 s.
        // Scenario: 5 manual losses held 120 s each (> 60 s).
        //
        // Acceptance: PSI drops into [70, 90] — the Class B pattern should
        // emerge and pressure-amplify subsequent commits, producing a
        // meaningful but not catastrophic signal.
        // =====================================================================
        private static void S202_FiveConsecutiveQuickExits()
        {
            Title("S202 — 5 losses held 2× longer than μWinHold → hold-bias pattern");
            // maxHoldMinutes=2 → muWinHold_prior = 2*60*0.25 = 30 s
            // D4HoldBiasRatio=2.0 → threshold = 60 s
            // holdSec=120 > 60 → fires each time.
            var (eng, bl, prof) = NewEngine(maxHoldMinutes: 2);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            for (int i = 0; i < 5; i++)
            {
                EntryFill(eng, t, 1, fillDir: +1);
                t = t.AddSeconds(120);  // hold 120 s > 60 s threshold → D4 fires
                Close(eng, bl, -30, 1, t, isWin: false, holdSec: 120,
                      exitKind: ExitKind.Manual);
                t = t.AddSeconds(60);
            }

            Snapshot(eng, "S202", "after 5 long-hold losses");
            AssertLess("S202 PSI < 90",   eng.CurrentPsi, 90.0,
                "5 repeated hold-bias exits must produce a meaningful pattern signal");
            AssertGreater("S202 PSI > 65", eng.CurrentPsi, 65.0,
                "pattern should hurt but not collapse PSI — it is Class B evidence");
            AssertGreater("S202 D4 evidence E4 > 8", eng.EvidenceD4, 8.0,
                "E4 accumulates across the 5 commits (some decay between each)");
        }

        // =====================================================================
        // S203 — MaxDailyLoss declared, then breached to I3 anchor.
        //
        // Post-2026-04-23 D6 redesign (ARCHITECTURE.md §15.15): Class A is
        // SATURATING-MARGINAL on overshootUsd / MaxDailyLossUsd, not a
        // step-function.  To reach the I3 "moderate critical" anchor
        // (r = 1 = "lost twice the declared max") we realize losses of
        // 2·MaxDailyLossUsd and then trigger the breach hook.  Acceptance
        // band now derives from I3 directly — [40, 55] PSI drop, E6 in
        // [30, 46] — not from a hand-picked post-hoc number.
        // =====================================================================
        private static void S203_MaxDailyLossBreach()
        {
            Title("S203 — Declared MaxDailyLoss breached to I3 anchor (r=1) → D6 critical");
            var cfg = PsiEngineV2Config.Default;
            cfg.MaxDailyLossUsd = 300.0;
            var (eng, bl, prof) = NewEngine(cfg: cfg);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            // Realize total loss = $600 = 2 × MaxDailyLossUsd → overshoot = $300
            // → r = overshoot / scale = 300 / 300 = 1.0 (I3 anchor).
            for (int i = 0; i < 4; i++)
            {
                EntryFill(eng, t, 1, fillDir: +1);
                t = t.AddSeconds(30);
                Close(eng, bl, -150, 1, t, isWin: false, holdSec: 30,
                      exitKind: ExitKind.ProtectiveStop);
                t = t.AddMinutes(2);
            }
            // sessionNetPnl is now -$600 = -2·MaxDailyLossUsd.
            double psiBefore = eng.CurrentPsi;
            eng.MarkMaxDailyLossBreach(t);

            Snapshot(eng, "S203", "after MaxDailyLoss breach at r=1 (I3 anchor)");
            // DERIVATION: E6 = CommitA_D6 · (1 − e^(−1)) = 60 · 0.632 = 37.9
            //            C6 = (1 − e^(−37.9/60)) · 100 = 46.9
            //            PSI drop ≈ C6 (D6 dominant) ≈ 47
            double drop = psiBefore - eng.CurrentPsi;
            AssertBetween("S203 PSI drop ∈ [30, 55] (I3 moderate-critical band)",
                drop, 30.0, 55.0,
                "r=1 breach ≡ I3 anchor — derived from InvariantContract, not tuned");
            AssertBetween("S203 D6 evidence E6 ∈ [30, 46] (saturating at r=1)",
                eng.EvidenceD6, 30.0, 46.0,
                "60·(1−e⁻¹) ≈ 37.9 per ARCHITECTURE.md §15.15 derivation");
        }

        // =====================================================================
        // S204 — Oversize entry (profile SizeMax=1, entry 2 lots).
        // Acceptance: PSI drops by 20–60 pts from the single entry decision.
        // The COMMITMENT BREAK (crossing your own declared size cap) is the
        // axis.  Duration-independent — a zero-duration oversize still fires.
        // =====================================================================
        private static void S204_OversizeEntry()
        {
            Title("S204 — Oversize 2-lot entry when SizeMax=1 → D3 Class A per-contract");
            var (eng, bl, prof) = NewEngine(sizeMax: 1);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            double psiBefore = eng.CurrentPsi;

            EntryFill(eng, t, 2, fillDir: +1);           // excess = 1 contract
            Snapshot(eng, "S204", "after 2-lot entry (SizeMax=1, excess=1)");

            double psiAfter = eng.CurrentPsi;
            double drop     = psiBefore - psiAfter;

            AssertGreater("S204 PSI drop > 15", drop, 15.0,
                "oversize commitment-break must move PSI meaningfully");
            AssertLess("S204 PSI drop < 65", drop, 65.0,
                "1-contract excess should not saturate PSI alone");
            AssertTrue("S204 IsOverExposed", eng.IsOverExposed,
                "engine must report live over-exposure");
        }

        // =====================================================================
        // S205 — Session-window rule: entry 45 minutes outside window.
        //
        // Post-2026-04-23 D6 redesign: Class A is SATURATING on
        // minutesOver / sessionLengthMinutes.  Session 09:30–12:00 = 150 min.
        // Entry at 12:45 → minutesOver = 46 → r = 46/150 = 0.31 (I1 mild
        // band — "30 % session overrun, concerning but not catastrophic").
        //
        // Acceptance band DERIVED from I1 (mild at r≈1/3 gives C ≤ 30):
        //   E6 = 60·(1 − e^(−0.31)) = 16.0
        //   C6 = (1 − e^(−16.0/60))·100 = 23.4
        //   PSI drop ≈ 23
        //
        // The old assertion "drop ≥ 25, E6 ≥ 59" was the symptom of the
        // step-function Class A that treated "1 min over" identically to
        // "59 min over" — both depositing CommitA=60.  That behaviour
        // violated Axiom 6 (severity gradedness) and Anti-pattern 10b
        // (step-function Class A).
        // =====================================================================
        private static void S205_SessionWindowFarOutside()
        {
            Title("S205 — Entry 45 min outside session window (r≈0.31, I1 mild band)");
            var (eng, bl, prof) = NewEngine();
            // Profile window 09:30–12:00 (length 150 min).  Fire at 12:45.
            var t = new DateTime(2026, 4, 23, 12, 45, 0);

            double psiBefore = eng.CurrentPsi;
            EntryFill(eng, t, 1, fillDir: +1);

            Snapshot(eng, "S205", "entry 46 min past session end, 150-min session");
            double drop = psiBefore - eng.CurrentPsi;

            AssertBetween("S205 PSI drop ∈ [12, 30] (I1 mild band at r≈0.31)",
                drop, 12.0, 30.0,
                "saturating curve gives 60·(1−e^(−46/150)) ≈ 16 evidence, ~23 pt PSI drop");
            AssertBetween("S205 D6 evidence E6 ∈ [10, 22] (saturating at r≈0.31)",
                eng.EvidenceD6, 10.0, 22.0,
                "E6 derived from minutesOver/sessionLength per §15.15");
        }

        // =====================================================================
        // S206 — PauseAfterNLosses declared = 2, trader re-enters after
        //        streak = 2.  Class A fires on the re-entry.
        // =====================================================================
        private static void S206_PauseRuleBroken()
        {
            Title("S206 — Streak hits PauseAfterN and trader re-enters → D1 Class A");
            var cfg = PsiEngineV2Config.Default;
            cfg.PauseAfterNLosses = 2;
            var (eng, bl, prof) = NewEngine(cfg: cfg);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            // 2 bracket stop-losses in a row.  No D1 Class A yet.
            for (int i = 0; i < 2; i++)
            {
                EntryFill(eng, t, 1, fillDir: +1);
                t = t.AddSeconds(60);
                Close(eng, bl, -100, 1, t, isWin: false, holdSec: 60,
                      exitKind: ExitKind.ProtectiveStop);
                t = t.AddSeconds(45);
            }
            double psiBeforeReentry = eng.CurrentPsi;

            // Re-entry while streak = 2 ≥ PauseAfterN.
            EntryFill(eng, t, 1, fillDir: +1);

            Snapshot(eng, "S206", "after breaking declared pause rule");
            double drop = psiBeforeReentry - eng.CurrentPsi;
            AssertGreater("S206 Re-entry drop > 25", drop, 25.0,
                "breaking the declared pause is a Class A commitment violation");
            AssertGreater("S206 Streak ≥ 2", eng.ConsecutiveLosses, 1.9, "");
        }

        // =====================================================================
        // S207 — Bracket protective stop taken, no other behaviour.
        // Acceptance: D4 commit is zero (bracket exit is disciplined);
        // PSI drop should be small and attributable solely to streak-P
        // amplification of ambient decay — NOT to D4.
        // =====================================================================
        private static void S207_BracketStopLossNotPenalised()
        {
            Title("S207 — Bracket protective-stop exit does NOT fire D4");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            EntryFill(eng, t, 1, fillDir: +1);
            t = t.AddSeconds(15);
            Close(eng, bl, -50, 1, t, isWin: false, holdSec: 15,
                  exitKind: ExitKind.ProtectiveStop);

            Snapshot(eng, "S207", "after disciplined bracket stop-loss");

            AssertLess("S207 D4 evidence ≈ 0", eng.EvidenceD4, 0.1,
                "bracket exit must NOT create D4 evidence (discipline over outcome)");
            AssertGreater("S207 PSI ≥ 97", eng.CurrentPsi, 97.0,
                "a lone bracket stop-loss with no re-entry should not noticeably " +
                "move PSI — this is exactly what the v1 engine got wrong");
        }

        // =====================================================================
        // S208 — Bracket target taken (profit).
        // Acceptance: no evidence added anywhere.  P&L outcome does not
        // bias the engine positively either.
        // =====================================================================
        private static void S208_BracketTargetNotPenalised()
        {
            Title("S208 — Bracket target (win) — no evidence added");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            EntryFill(eng, t, 1, fillDir: +1);
            t = t.AddSeconds(45);
            Close(eng, bl, +120, 1, t, isWin: true, holdSec: 45,
                  exitKind: ExitKind.Target);

            Snapshot(eng, "S208", "after bracket target hit");

            double totalE = eng.EvidenceD1 + eng.EvidenceD2 + eng.EvidenceD3
                          + eng.EvidenceD4 + eng.EvidenceD5 + eng.EvidenceD6
                          + eng.EvidenceD7;
            AssertLess("S208 total E ≈ 0", totalE, 0.1,
                "disciplined winning exit must not register evidence in any dimension");
        }

        // =====================================================================
        // S209 — Flat idle for 30 min after a Class A commit (I5 anchor).
        // Acceptance (v2.1 Axiom 7 retune): τ_decay_3 = 2000 s.  At t=30 min
        // (1800 s), I5 requires E retains ≥ 40% of peak; at t=120 min (7200 s)
        // I5 requires ≤ 5%.  This scenario verifies the 30-min anchor.
        //   exp(-1800/2000) ≈ 0.407 → target band ~[0.35, 0.50]
        // =====================================================================
        private static void S209_FlatIdleDecaysAllDims()
        {
            Title("S209 — Flat idle → E decays at τ_decay_i (P=0), I5-grounded");
            var (eng, bl, prof) = NewEngine(sizeMax: 1.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            EntryFill(eng, t, 2, fillDir: +1);
            t = t.AddSeconds(30);
            Close(eng, bl, -20, 2, t, isWin: false, holdSec: 30,
                  exitKind: ExitKind.Manual);
            double e3Before  = eng.EvidenceD3;
            double psiBefore = eng.CurrentPsi;

            for (int i = 1; i <= 60; i++)
            {
                t = t.AddSeconds(30);
                bool _naked;
                eng.PollPositions(new List<PositionSnapshot>(), t, out _naked);
            }
            Snapshot(eng, "S209", "after 30 min idle");

            AssertGreater("S209 E3 seed > 0", e3Before, 0.1,
                "oversize entry must have fired D3");
            AssertGreater("S209 E3(30min) ≥ 0.35·E3(0) [I5 lower]",
                eng.EvidenceD3, e3Before * 0.35,
                "τ_decay_3 = 2000 s → exp(-1800/2000) ≈ 0.41; floor 0.35 for jitter");
            AssertLess("S209 E3(30min) ≤ 0.50·E3(0) [I5 upper]",
                eng.EvidenceD3, e3Before * 0.50,
                "decay must have at least started: 30 min is ~half τ_decay");
            AssertGreater("S209 PSI recovered", eng.CurrentPsi, psiBefore + 1.0,
                "PSI must recover as E decays");
        }

        // =====================================================================
        // S210 — A single close event is reported twice (reconcile double-
        //        notification), engine must NOT double-commit.
        // This is the v2 counterpart of the v1.1.5 Fix B invariant.
        // The engine has no way to know a second fill is a duplicate —
        // the MeridianPSI tracking layer is responsible.  v2 relies on
        // isRoundTripFinal=false for tracking-side corrections (the
        // MeridianPSI contract).  This test verifies the engine honours
        // that contract: a close with isRoundTripFinal=false does not bump
        // the streak or fire D1 / D4 Class B commits.
        // =====================================================================
        private static void S210_ReconcileDoesNotDoubleCount()
        {
            Title("S210 — isRoundTripFinal=false close does not bump streak / fire commits");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            EntryFill(eng, t, 1, fillDir: +1);
            t = t.AddSeconds(60);

            // Real round-trip close.
            Close(eng, bl, -50, 1, t, isWin: false, holdSec: 60,
                  exitKind: ExitKind.ProtectiveStop);
            double streakAfterReal = eng.ConsecutiveLosses;

            // Reconcile correction — same trade, NOT round-trip final.
            t = t.AddMilliseconds(500);
            eng.ProcessExecution(
                pnl: 0, size: 1, fillTime: t,
                isWin: false, holdSeconds: 0,
                postFillPositions: new List<PositionSnapshot>(),
                fillDirection: -1,
                exitKind: ExitKind.Unknown,
                isRoundTripFinal: false,
                roundTripPnl: -50);

            Snapshot(eng, "S210", "after reconcile (non-final) notification");
            AssertTrue("S210 streak not bumped",
                Math.Abs(eng.ConsecutiveLosses - streakAfterReal) < 0.01,
                "non-final fills must not increment _consecutiveLosses");
        }

        // =====================================================================
        // S211 — Same D4 Class B commit fires under P=0 vs P≈0.8.
        // Acceptance: the E4 rise is 1+κP times larger when pressure is high.
        //
        // Uses maxHoldMinutes=2 so muWinHold_prior=30 s, threshold=60 s.
        // A loss held 120 s > 60 s fires D4.
        // =====================================================================
        private static void S211_PressureAmplifiesClassBOnly()
        {
            Title("S211 — Class B commit amplified by pressure (1+κP)");
            // Scenario A: P=0 — single long-hold loss on clean session.
            var (engA, blA, profA) = NewEngine(maxHoldMinutes: 2);
            var tA = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(engA, tA, 1, fillDir: +1);
            tA = tA.AddSeconds(120);
            Close(engA, blA, -30, 1, tA, isWin: false, holdSec: 120,
                  exitKind: ExitKind.Manual);
            double e4LowP = engA.EvidenceD4;
            double pLow   = engA.Pressure;

            // Scenario B: build streak=3 so P ≥ streak/StreakSaturationN ≈ 1.
            var cfgB = PsiEngineV2Config.Default;
            var (engB, blB, profB) = NewEngine(cfg: cfgB, maxHoldMinutes: 2);
            var tB = new DateTime(2026, 4, 23, 10, 0, 0);
            for (int i = 0; i < 3; i++)
            {
                EntryFill(engB, tB, 1, fillDir: +1);
                tB = tB.AddSeconds(60);
                Close(engB, blB, -50, 1, tB, isWin: false, holdSec: 60,
                      exitKind: ExitKind.ProtectiveStop);
                tB = tB.AddSeconds(45);
            }
            double pHighBefore = engB.Pressure;
            // Long-hold manual loss while pressure is fully engaged.
            EntryFill(engB, tB, 1, fillDir: +1);
            tB = tB.AddSeconds(120);
            Close(engB, blB, -30, 1, tB, isWin: false, holdSec: 120,
                  exitKind: ExitKind.Manual);

            Snapshot(engA, "S211A", "P=0 single long-hold loss");
            Snapshot(engB, "S211B", "P=1 after-streak long-hold loss");

            AssertLess("S211 low-P P ≈ 0",   pLow, 0.05, "");
            AssertGreater("S211 high-P P ≥ 0.9", pHighBefore, 0.9, "");
            AssertGreater("S211 E4 low-P > 0", e4LowP, 0.1,
                "long-hold loss must produce D4 evidence at P=0");
            // High-P commit should be ≥ 1.5× the low-P commit (κ default 1.0).
            AssertGreater("S211 E4 grows more under pressure",
                engB.EvidenceD4 / Math.Max(0.1, e4LowP), 1.5,
                "CommitB amplification by pressure");
        }

        // =====================================================================
        // S212 — Clean session (no loser, no streak, no daily-loss proximity)
        //        → P ≡ 0.  Any subsequent Class B commit should be unamplified.
        // =====================================================================
        private static void S212_CleanSessionPressureIsZero()
        {
            Title("S212 — Clean session baseline P = 0");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            bool _naked;
            eng.PollPositions(new List<PositionSnapshot>(), t, out _naked);
            AssertLess("S212 P = 0 at start", eng.Pressure, 1e-6,
                "no observable stressor present");
        }

        // =====================================================================
        // S213 — Decay rate halves when P = 0.5.
        // Accept: E_4 under continuous P≈1 should barely move — decay rate
        //         is gated by (1 − P), so at P=1 the gate closes.
        //
        // Seed uses maxHoldMinutes=2 (muWinHold_prior=30 s, threshold=60 s)
        // so a 120 s loss hold fires D4 at P=0.
        // =====================================================================
        private static void S213_DecayGatedByOneMinusP()
        {
            Title("S213 — Decay gated by (1 − P): P=1 means no recovery");
            // maxHoldMinutes=2 → muWinHold_prior=30 s → D4 fires at holdSec>60 s
            var (eng, bl, prof) = NewEngine(maxHoldMinutes: 2);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            // Fire a Class B commit on D4 (long-hold loss).
            EntryFill(eng, t, 1, fillDir: +1);
            t = t.AddSeconds(120);
            Close(eng, bl, -30, 1, t, isWin: false, holdSec: 120,
                  exitKind: ExitKind.Manual);
            double e4Start = eng.EvidenceD4;

            // Artificially force high P by holding an open loser that is
            // deeply underwater (MAE = −400 vs μLoss $100 → factor capped 1).
            for (int i = 1; i <= 10; i++)
            {
                t = t.AddSeconds(30);
                var snap = new PositionSnapshot
                {
                    Key              = "HOLDER",
                    Quantity         = 1,
                    HoldSeconds      = 30 * i,
                    HasStopOrder     = true,
                    UnrealizedPnl    = -400,
                    MinUnrealizedPnl = -400,
                    EntryTime        = new DateTime(2026, 4, 23, 10, 0, 0),
                };
                bool _naked;
                eng.PollPositions(new List<PositionSnapshot> { snap }, t, out _naked);
            }
            Snapshot(eng, "S213", "after 5 min under P≈1");

            AssertGreater("S213 E4 seed > 0", e4Start, 0.1,
                "120 s loss hold must fire D4 (> 60 s threshold)");
            AssertGreater("S213 P high", eng.Pressure, 0.9,
                "open loser MAE = 4× μLoss must saturate openLoserFactor");
            AssertGreater("S213 E4 retained under P=1",
                eng.EvidenceD4, e4Start * 0.9,
                "decay should be effectively suppressed while P ≈ 1");
        }

        // =====================================================================
        // S214 — A large positive or negative P&L (not tied to a declared
        //        limit) does NOT directly penalise PSI.
        // =====================================================================
        private static void S214_PnLDoesNotDirectlyPenalisePsi()
        {
            Title("S214 — Raw P&L does not directly penalise PSI");
            var (eng, bl, prof) = NewEngine();   // MaxDailyLossUsd = 0 ⇒ disabled
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            for (int i = 0; i < 3; i++)
            {
                EntryFill(eng, t, 1, fillDir: +1);
                t = t.AddSeconds(120);
                Close(eng, bl, -400, 1, t, isWin: false, holdSec: 120,
                      exitKind: ExitKind.ProtectiveStop);
                t = t.AddSeconds(90);
            }
            Snapshot(eng, "S214", "after -$1200 with no declared limit");

            AssertGreater("S214 PSI ≥ 80", eng.CurrentPsi, 80.0,
                "without declared MaxDailyLoss, raw pnl cannot drive PSI " +
                "directly — only streak-pressure-amplified Class B may register");
        }

        // =====================================================================
        // S215 — Class A commit magnitude is NOT modulated by P.
        // Fire the same MaxDailyLoss breach under P=0 and under P≈1;
        // C_6 jump should be identical within numerical tolerance.
        // =====================================================================
        private static void S215_ClassANotAmplifiedByPressure()
        {
            Title("S215 — Class A evidence magnitude is NOT amplified by pressure");
            // Post-2026-04-23 D6 redesign note: MarkMaxDailyLossBreach now
            // reads _sessionNetPnl and deposits SATURATING-MARGINAL evidence
            // on overshootUsd/MaxDailyLossUsd.  It will not fire without an
            // actual loss past the declared limit — so both scenarios must
            // realize the SAME overshoot before the breach call.  The P
            // difference must NOT change the resulting ΔE6.
            //
            // Scenario A: overshoot to r=1 (loss = 2 × max) with P≈0.
            //             We realize the loss slowly via a LONG gap between
            //             the setup loss and the breach call so streakFactor
            //             has fully decayed, ensuring P ≈ 0 at the breach
            //             moment.
            // Scenario B: overshoot to r=1 with P≈1 (streak fresh, no decay).
            //
            // Both scenarios deposit the same absolute ΔE6 because Class A
            // is not amplified by P (Axiom 4).  The difference, if any,
            // is decay over time — A's setup took longer so A's E6 will
            // have decayed slightly more between its commits; we compare
            // the INSTANTANEOUS Δ at the breach call.
            var cfg = PsiEngineV2Config.Default;
            cfg.MaxDailyLossUsd = 300.0;  // overshoot scale = $300

            // Both: realize 2 × $300 = $600 loss = r=1 overshoot = $300.
            double scenarioLoss = -600.0;

            // Scenario A: P ≈ 0 (loss realized minutes ago, streak decayed).
            var (engA, blA, _) = NewEngine(cfg: cfg);
            var tA = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(engA, tA, 1, fillDir: +1);
            tA = tA.AddSeconds(30);
            Close(engA, blA, scenarioLoss, 1, tA, isWin: false, holdSec: 30,
                  exitKind: ExitKind.ProtectiveStop);
            // Wait long enough for streakFactor to fully decay (τ = 3600 s,
            // 4 h → factor ≈ 0.02).
            Idle(engA, ref tA, totalSeconds: 4 * 3600);
            double e6AbeforeBreach = engA.EvidenceD6;
            double pA = engA.Pressure;
            engA.MarkMaxDailyLossBreach(tA);
            double e6ADelta = engA.EvidenceD6 - e6AbeforeBreach;

            // Scenario B: P ≈ 1 (fresh streak + deep hole).
            var (engB, blB, _) = NewEngine(cfg: cfg);
            var tB = new DateTime(2026, 4, 23, 10, 0, 0);
            // 5 × $120 losses = $600 total, fresh streak keeps P saturated.
            for (int i = 0; i < 5; i++)
            {
                EntryFill(engB, tB, 1, fillDir: +1);
                tB = tB.AddSeconds(30);
                Close(engB, blB, -120, 1, tB, isWin: false, holdSec: 30,
                      exitKind: ExitKind.ProtectiveStop);
                tB = tB.AddSeconds(30);
            }
            double e6BbeforeBreach = engB.EvidenceD6;
            double pB = engB.Pressure;
            engB.MarkMaxDailyLossBreach(tB);
            double e6BDelta = engB.EvidenceD6 - e6BbeforeBreach;

            Snapshot(engA, "S215A", string.Format("Class A fired at P≈{0:F2}", pA));
            Snapshot(engB, "S215B", string.Format("Class A fired at P≈{0:F2}", pB));

            AssertLess("S215 engA pressure ≈ 0", pA, 0.15,
                "long idle must dissipate streak pressure");
            AssertGreater("S215 engB pressure ≈ 1", pB, 0.80,
                "fresh streak + deep hole must keep pressure high");
            // Both scenarios may deposit ΔE through two channels (setup entry
            // fills and the explicit breach call).  What Axiom 4 guarantees is
            // that each INDIVIDUAL Class A deposit is P-independent.  We test
            // that by comparing the final MarkMaxDailyLossBreach delta, which
            // is an isolated Class A commit.
            AssertTrue("S215 Δ Class A P-independent",
                Math.Abs(e6ADelta - e6BDelta) < 1.0,
                "isolated Class A deposit must not depend on P");
        }

        // =====================================================================
        // S216 — OnPositionTrackingCorrection clears derived-from-positions
        //        state only; accumulated E[i] survive.
        // =====================================================================
        private static void S216_TrackingCorrectionPreservesE()
        {
            Title("S216 — Tracking correction preserves E[i] evidence");
            var (eng, bl, prof) = NewEngine(sizeMax: 1);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            EntryFill(eng, t, 2, fillDir: +1);        // oversize → E3 grows
            double e3Before = eng.EvidenceD3;
            AssertGreater("S216 E3 > 0 before correction", e3Before, 1.0, "");

            eng.OnPositionTrackingCorrection();

            Snapshot(eng, "S216", "after tracking correction");
            AssertTrue("S216 E3 preserved",
                Math.Abs(eng.EvidenceD3 - e3Before) < 1e-6,
                "real behavioural history is not nullified by a bookkeeping fix");
            AssertTrue("S216 IsOverExposed cleared",
                !eng.IsOverExposed,
                "the engine's believed-size state is reset");
        }

        // =====================================================================
        // S217 — StartNewSession collapses all E → 0 and the outstanding
        //        deficit moves into carryDebt.
        // =====================================================================
        private static void S217_StartNewSessionCollapsesToCarry()
        {
            Title("S217 — StartNewSession → E = 0, deficit → carryDebt");
            var (eng, bl, prof) = NewEngine(sizeMax: 1);
            var t = new DateTime(2026, 4, 23, 11, 0, 0);
            EntryFill(eng, t, 3, fillDir: +1);
            double prevFinal = eng.CurrentPsi;

            eng.StartNewSession(prevFinal);

            Snapshot(eng, "S217", "after StartNewSession");
            double sumE = eng.EvidenceD1 + eng.EvidenceD2 + eng.EvidenceD3
                        + eng.EvidenceD4 + eng.EvidenceD5 + eng.EvidenceD6
                        + eng.EvidenceD7;
            AssertLess("S217 all E cleared", sumE, 1e-6, "");
            AssertGreater("S217 carryDebt ≥ 0", eng.CarryDebt, -1e-6, "");
        }

        // =====================================================================
        // S218 — ApplyOvernightDecay shrinks E and carryDebt proportionally.
        // =====================================================================
        private static void S218_OvernightDecayReducesEAndCarry()
        {
            Title("S218 — ApplyOvernightDecay reduces E and carryDebt");
            var (eng, bl, prof) = NewEngine(sizeMax: 1);
            var t = new DateTime(2026, 4, 23, 11, 0, 0);
            EntryFill(eng, t, 3, fillDir: +1);
            double e3Before = eng.EvidenceD3;

            // 16 h at τ=48 h → decay factor ≈ 0.716.
            eng.ApplyOvernightDecay(16.0);

            Snapshot(eng, "S218", "after 16 h overnight decay");
            AssertLess("S218 E3 shrunk",
                eng.EvidenceD3, e3Before * 0.85,
                "decay factor exp(-16/48) ≈ 0.716");
        }

        // =====================================================================
        // S219 — ResetClockAnchor on a playback rewind must NOT apply a
        //        huge decay on the first tick of the new domain.
        // Seed: long-hold loss (maxHoldMinutes=2) so e4Before > 0.
        // =====================================================================
        private static void S219_ResetClockAnchorPreventsJumpDecay()
        {
            Title("S219 — ResetClockAnchor prevents cross-domain jump decay");
            // maxHoldMinutes=2 → muWinHold_prior=30 s → D4 fires at holdSec>60 s
            var (eng, bl, prof) = NewEngine(maxHoldMinutes: 2);
            var t1 = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t1, 1, fillDir: +1);
            t1 = t1.AddSeconds(120);
            Close(eng, bl, -30, 1, t1, isWin: false, holdSec: 120,
                  exitKind: ExitKind.Manual);
            double e4Before = eng.EvidenceD4;

            eng.ResetClockAnchor();

            // Jump to 3 days earlier (a playback rewind).
            var t2 = new DateTime(2026, 4, 20, 9, 0, 0);
            bool _naked;
            eng.PollPositions(new List<PositionSnapshot>(), t2, out _naked);

            Snapshot(eng, "S219", "after cross-domain jump");
            AssertTrue("S219 no jump decay",
                Math.Abs(eng.EvidenceD4 - e4Before) < 1e-6,
                "first tick after anchor reset establishes the new anchor " +
                "without applying any decay");
        }

        // =====================================================================
        // S220 — Numerical aggregation identity.
        //        PSI = 100 − √(Σ C_i²) − carryDebt (bounded).
        // =====================================================================
        private static void S220_AggregationIdentity()
        {
            Title("S220 — PSI = 100 − √(ΣC²) − carryDebt");
            var cfg = PsiEngineV2Config.Default;
            cfg.MaxDailyLossUsd = 500.0;
            var (eng, bl, prof) = NewEngine(cfg: cfg, sizeMax: 1);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            // Produce a messy state: oversize + window breach + breach.
            EntryFill(eng, t, 2, fillDir: +1);
            t = t.AddSeconds(30);
            Close(eng, bl, -600, 2, t, isWin: false, holdSec: 30,
                  exitKind: ExitKind.Manual);
            t = t.AddSeconds(60);
            eng.MarkMaxDailyLossBreach(t);

            Snapshot(eng, "S220", "messy composite state");

            double sumSq = 0.0;
            sumSq += eng.DebtD1 * eng.DebtD1;
            sumSq += eng.DebtD2 * eng.DebtD2;
            sumSq += eng.DebtD3 * eng.DebtD3;
            sumSq += eng.DebtD4 * eng.DebtD4;
            sumSq += eng.DebtD5 * eng.DebtD5;
            sumSq += eng.DebtD6 * eng.DebtD6;
            sumSq += eng.DebtD7 * eng.DebtD7;

            double expected = 100.0 - Math.Sqrt(sumSq) - eng.CarryDebt;
            if (expected < 0) expected = 0;
            if (expected > 100) expected = 100;

            AssertTrue("S220 aggregation identity",
                Math.Abs(expected - eng.CurrentPsi) < 1e-6,
                string.Format("expected={0:F4}, got={1:F4}", expected, eng.CurrentPsi));
        }

        // =====================================================================
        // TIER 1 — TRADING-PSYCHOLOGY PATTERNS (S221–S231)
        //
        // These scenarios encode observable behavioural archetypes drawn from
        // trader-psychology literature (revenge, martingale, averaging down,
        // chop/flip-flop, post-win overconfidence, end-of-session tilt,
        // hesitation freeze, loss aversion, etc.).  They are the realistic
        // patterns the engine must rate correctly — not synthetic unit
        // probes.  Each scenario asserts the V2 engine's RESPONSE to the
        // pattern, not the pattern itself.
        // =====================================================================

        // S221 — Revenge entry: manual loss > 0.8·μLoss, same direction, re-entry < 180 s.
        private static void S221_RevengeEntryFiresD1ClassB()
        {
            Title("S221 — Revenge entry within urgency window → D1 Class B");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 1, +1);
            t = t.AddSeconds(30);
            // Loss of $120 exceeds 0.8 × μLoss (0.8 × 100 = 80). Manual exit.
            Close(eng, bl, -120, 1, t, false, 30, ExitKind.Manual);
            double e1Before = eng.EvidenceD1;
            // Re-entry 45 s later — same direction (+1).
            t = t.AddSeconds(45);
            EntryFill(eng, t, 1, +1);
            Snapshot(eng, "S221", "after revenge re-entry");
            AssertGreater("S221 D1 Class B fired",
                eng.EvidenceD1 - e1Before, 0.5,
                "significant loss + fast same-dir re-entry is the revenge signature");
            AssertLess("S221 single revenge does not crater PSI",
                100 - eng.CurrentPsi, 15,
                "one Class B commit must stay weak — pattern accumulation is what punishes");
        }

        // S222 — Martingale (size doubling after each loss).  D3 fires each
        //        oversize entry; streak pressure compounds amplification.
        private static void S222_MartingaleDoublingAfterLoss()
        {
            Title("S222 — Martingale size doubling after each loss");
            var cfg = PsiEngineV2Config.Default;
            var (eng, bl, prof) = NewEngine(sizeMax: 1.0, cfg: cfg);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            int[] sizes = { 1, 2, 4 };  // 1→2→4 doubling
            foreach (int sz in sizes)
            {
                EntryFill(eng, t, sz, +1);
                t = t.AddSeconds(30);
                Close(eng, bl, -50.0 * sz, sz, t, false, 30, ExitKind.ProtectiveStop);
                t = t.AddSeconds(20);
            }
            Snapshot(eng, "S222", "after 3 doubling losses");
            AssertGreater("S222 D3 evidence > 10",
                eng.EvidenceD3, 10,
                "repeated oversize commitments must accumulate on D3");
            AssertLess("S222 PSI ≤ 55 after escalation",
                eng.CurrentPsi, 55,
                "martingale + streak pressure must drive PSI below caution band");
        }

        // S223 — Averaging down: scale INTO a losing position.  Quantity grows
        //        while MinUnrealizedPnl is negative — D3 (oversize if quantity
        //        crosses SizeMax) and D5 overstay both rise.
        private static void S223_AveragingDownOnLosingPosition()
        {
            Title("S223 — Averaging down into a losing position");
            var (eng, bl, prof) = NewEngine(sizeMax: 2.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            // First leg: 2 lots at T+0.
            EntryFill(eng, t, 2, +1);
            bool naked;
            // 60 s later, position has MAE −$150 (big open loser).
            t = t.AddSeconds(60);
            var snaps = new List<PositionSnapshot> {
                new PositionSnapshot {
                    Key = "TEST::INSTR", Quantity = 2, HasStopOrder = true,
                    HoldSeconds = 60, MinUnrealizedPnl = -150 } };
            eng.PollPositions(snaps, t, out naked);
            // Trader adds 2 more at T+60 (now 4 lots, double SizeMax).
            eng.ProcessExecution(0, 2, t, false, 0,
                new List<PositionSnapshot> {
                    new PositionSnapshot {
                        Key = "TEST::INSTR", Quantity = 4, HasStopOrder = true,
                        MinUnrealizedPnl = -150 } },
                +1, ExitKind.Unknown, false, 0);
            Snapshot(eng, "S223", "after averaging down");
            AssertGreater("S223 D3 fires",
                eng.EvidenceD3, 1,
                "growing size past SizeMax while MAE deep negative is a commitment break");
            AssertTrue("S223 IsOverExposed", eng.IsOverExposed);
        }

        // S224 — Flip-flop direction (long→short→long→short) 4× in 5 min.
        //        D7 pace signal (exceeds declared trades-per-session budget).
        private static void S224_FlipFlopOverCadence()
        {
            Title("S224 — Rapid flip-flop direction changes");
            var prof = new StrategyProfile {
                SizeMin = 1, SizeMax = 2, SlTicksMax = 20,
                MaxReentrySeconds = 180, MaxHoldMinutes = 30,
                NoStopGraceSeconds = 20,
                TradesPerSessionMin = 3, TradesPerSessionMax = 3,  // tight budget
                SessionStartHour = 9, SessionStartMinute = 30,
                SessionEndHour = 16, SessionEndMinute = 0,
                Sensitivity = PsiSensitivity.Balanced,
            };
            var bl = new TradeBaseline();
            var eng = new PsiEngineV2(prof, bl);
            eng.StartNewSession(100.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            int dir = +1;
            for (int i = 0; i < 5; i++)
            {
                EntryFill(eng, t, 1, dir);
                t = t.AddSeconds(30);
                Close(eng, bl, -20, 1, t, false, 30, ExitKind.Manual);
                t = t.AddSeconds(30);
                dir = -dir;
            }
            Snapshot(eng, "S224", "after 5 flip-flop entries in 5 min");
            AssertGreater("S224 D7 evidence rises",
                eng.EvidenceD7, 1,
                "exceeding TradesPerSessionMax must accumulate on D7");
        }

        // S225 — Post-win overconfidence: 3 disciplined wins then oversize entry.
        //        D3 Class A still fires identically — P&L outcome does not
        //        immunise a commitment break.
        private static void S225_PostWinOversizeStillPenalised()
        {
            Title("S225 — Oversize after winning streak (overconfidence)");
            var (eng, bl, prof) = NewEngine(sizeMax: 1.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            for (int i = 0; i < 3; i++)
            {
                EntryFill(eng, t, 1, +1);
                t = t.AddSeconds(60);
                Close(eng, bl, +40, 1, t, true, 60, ExitKind.Target);
                t = t.AddSeconds(120);
            }
            // Clean state: PSI ≈ 100, streak = 0.
            double psiBefore = eng.CurrentPsi;
            // Oversize: 3 lots vs SizeMax=1 (2 over).
            EntryFill(eng, t, 3, +1);
            Snapshot(eng, "S225", "after 3 wins then oversize entry");
            AssertGreater("S225 oversize commits D3",
                eng.EvidenceD3, 1,
                "winning P&L does NOT protect against a commitment break");
            AssertGreater("S225 PSI drops ≥ 10",
                psiBefore - eng.CurrentPsi, 10,
                "Class A D3 must move PSI regardless of preceding wins");
        }

        // S226 — End-of-session tilt: 3 entries past declared end.
        //
        // Post-2026-04-23 design: each entry past the declared end is a
        // fresh Class A event with saturating severity in
        // minutesOver / sessionLengthMinutes.  For the default 09:30–12:00
        // session (150 min) with entries at 13:00, 13:30, 14:00:
        //   minutesOver    = 61, 91, 121
        //   r              = 0.41, 0.61, 0.81
        //   ΔE per entry   ≈ 20.1, 27.3, 33.2
        // With τ_decay = 1800 s, E decays by e^(−1) ≈ 37 % between entries.
        // Cumulative E6 at final ≈ 46; C6 = 100·(1 − e^(−46/60)) ≈ 54.
        //
        // Psychological meaning: each additional entry deeper into the
        // out-of-hours window *does* add evidence, but diminishingly — a
        // 60-min-over entry and a 120-min-over entry are both "outside the
        // plan," and the second one does NOT count twice what the first
        // one did.  This mirrors the lived psychological reality ("I'm
        // already breaking my own rule, am I going deeper?") without any
        // step-function threshold or magic multiplier.
        private static void S226_EndOfSessionTilt()
        {
            Title("S226 — End-of-session tilt: 3 entries past declared end");
            var (eng, bl, prof) = NewEngine(sessionEndHour: 12);
            // 60, 90, 120 min past declared 12:00 close.
            DateTime[] times = {
                new DateTime(2026, 4, 23, 13, 0, 0),
                new DateTime(2026, 4, 23, 13, 30, 0),
                new DateTime(2026, 4, 23, 14, 0, 0) };
            foreach (var t in times)
            {
                EntryFill(eng, t, 1, +1);
                var close = t.AddSeconds(60);
                Close(eng, bl, -30, 1, close, false, 60, ExitKind.ProtectiveStop);
            }
            Snapshot(eng, "S226", "after 3 out-of-session entries");
            AssertGreater("S226 D6 fires cumulatively (C6 > 40)",
                eng.DebtD6, 40,
                "3 progressively deeper out-of-session entries must " +
                "cumulatively lift D6 severity past the I3 moderate band");
            AssertLess("S226 PSI ≤ 55 (compound end-of-day tilt)",
                eng.CurrentPsi, 55);
        }

        // S227 — Hesitation freeze: 3 stops, then 30-min idle pause.
        //
        //   Psychological claim encoded: "Walking away from the screen
        //   without closing trades does NOT by itself relieve streak-tilt
        //   pressure."  Streak is still 3 after the freeze, P stays high
        //   (streakFactor = 1.0 @ StreakSaturationN = 2), so decay is
        //   gated by (1 − P) ≈ 0 and PSI must not drift UP materially.
        //
        //   Conversely, the engine must also NOT drift DOWN during pure
        //   idle (no observation = no commit).  This asserts the pure
        //   "no unprovoked accrual" invariant.
        private static void S227_HesitationFreezeDoesNotDrift()
        {
            Title("S227 — Hesitation freeze: PSI stable during 30-min idle");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            for (int i = 0; i < 3; i++)
            {
                EntryFill(eng, t, 1, +1);
                t = t.AddSeconds(60);
                Close(eng, bl, -30, 1, t, false, 60, ExitKind.ProtectiveStop);
                t = t.AddSeconds(60);
            }
            double psiAtStreak = eng.CurrentPsi;
            double streakAtStart = eng.ConsecutiveLosses;
            bool _naked;
            for (int i = 0; i < 30; i++)
            {
                t = t.AddMinutes(1);
                eng.PollPositions(new List<PositionSnapshot>(), t, out _naked);
            }
            Snapshot(eng, "S227", "after 30-min idle");
            AssertLess("S227 PSI drift < 1 pt during idle",
                Math.Abs(eng.CurrentPsi - psiAtStreak), 1.0,
                "no observation = no commit; streak-held P gates decay");
            AssertTrue("S227 streak persists through break",
                Math.Abs(eng.ConsecutiveLosses - streakAtStart) < 1e-9,
                "taking a break does NOT reset a loss streak");
        }

        // S228 — Cut winner short + let loser run (loss aversion).
        //        Quick manual winning exit (NOT penalised — discipline-over-outcome),
        //        then a losing position held far past MaxHoldMinutes.
        //
        //        v2.1 D4 semantics: D4 fires when loss holdSec > D4HoldBiasRatio × μWinHold.
        //        MaxHoldMinutes=2 → muWinHold_prior=30 s → threshold=60 s.
        //        The 45-min loser is closed at the end to verify D4 fires on that long hold.
        private static void S228_CutWinnersShortLetLosersRun()
        {
            Title("S228 — Loss aversion: short-hold wins + long-hold losers");
            // maxHoldMinutes=2 → muWinHold_prior=30 s → D4 threshold=60 s
            var (eng, bl, prof) = NewEngine(maxHoldMinutes: 2);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            // Quick winner.
            EntryFill(eng, t, 1, +1);
            t = t.AddSeconds(5);
            Close(eng, bl, +20, 1, t, true, 5, ExitKind.Manual);
            double e4AfterWin = eng.EvidenceD4;
            // Now enter a loser and hold for 45 min (MaxHoldMinutes = 2).
            t = t.AddMinutes(5);
            EntryFill(eng, t, 1, +1);
            bool _naked;
            // Simulate the position worsening over 45 min.
            var tEntry = t;
            for (int m = 1; m <= 45; m++)
            {
                t = t.AddMinutes(1);
                var sn = new List<PositionSnapshot> {
                    new PositionSnapshot {
                        Key = "TEST::INSTR", Quantity = 1, HasStopOrder = true,
                        HoldSeconds = 60 * m, MinUnrealizedPnl = -100 } };
                eng.PollPositions(sn, t, out _naked);
            }
            // Close the loser — 45 min hold >> 60 s threshold → D4 fires.
            Close(eng, bl, -60, 1, t, false, 45 * 60, ExitKind.Manual);
            Snapshot(eng, "S228", "after winner-short + loser-long-hold");
            AssertLess("S228 winning short-hold does NOT register D4",
                e4AfterWin, 0.1,
                "winning manual exit is a disciplined outcome, not a hold-bias signal");
            AssertGreater("S228 D5 overstay fires",
                eng.EvidenceD5, 0.5,
                "holding a losing position past MaxHoldMinutes is the 扛单 pattern");
            AssertGreater("S228 D4 fires on long-hold loss",
                eng.EvidenceD4, 0.5,
                "loss held 45 min >> μWinHold 30 s threshold must register hold bias");
        }

        // S229 — Three disciplined bracket stops with NO re-entry.  This is
        //        the exact log pattern that exposed the v1.1.5 bug (50-pt
        //        drop on a single ATM stop).  V2 must NOT penalise.
        private static void S229_ThreeDisciplinedStopsNoReentry()
        {
            Title("S229 — 3 disciplined bracket stops, no re-entry");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            for (int i = 0; i < 3; i++)
            {
                EntryFill(eng, t, 1, +1);
                t = t.AddSeconds(120);
                Close(eng, bl, -50, 1, t, false, 120, ExitKind.ProtectiveStop);
                // Wait 10 min before considering the next entry (no re-entry).
                t = t.AddMinutes(10);
                bool _naked;
                eng.PollPositions(new List<PositionSnapshot>(), t, out _naked);
            }
            Snapshot(eng, "S229", "after 3 disciplined SLs, no re-entry");
            AssertLess("S229 D1 = 0 (no re-entry)",
                eng.EvidenceD1, 0.1,
                "without re-entry, bracket SLs must NOT create D1 debt — v1.1.5 regression guard");
            AssertLess("S229 D4 = 0 (bracket exits)",
                eng.EvidenceD4, 0.1,
                "ProtectiveStop must never accumulate D4");
            AssertGreater("S229 PSI ≥ 85",
                eng.CurrentPsi, 85,
                "three disciplined ATM stops with no behaviour violation must leave PSI high");
        }

        // S230 — Bracket SL → 10-min pause → fresh entry.  D1 Class B must
        //        NOT fire on the fresh entry (bracket exits do not start the
        //        revenge clock — v1.1.1 E5 invariant carried into V2).
        private static void S230_BracketExitDoesNotStartRevengeClock()
        {
            Title("S230 — Bracket SL then 10-min pause + fresh entry");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 1, +1);
            t = t.AddSeconds(60);
            Close(eng, bl, -100, 1, t, false, 60, ExitKind.ProtectiveStop);
            t = t.AddMinutes(10);
            EntryFill(eng, t, 1, +1);
            Snapshot(eng, "S230", "fresh entry after bracket SL + 10-min pause");
            AssertLess("S230 D1 = 0 (bracket did not set revenge anchor)",
                eng.EvidenceD1, 0.1,
                "ProtectiveStop must not advance _lastRealizedFillTime");
        }

        // S231 — Stop widening (adverse SL move).  D2 Class B fires.
        private static void S231_StopWideningAdverseSlMove()
        {
            Title("S231 — Adverse SL widening fires D2 Class B");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 1, +1);
            // Initial SL at 10 ticks.
            eng.ProcessOrderChange("SL1", 10.0);
            double e2Before = eng.EvidenceD2;
            // Trader widens SL to 18 ticks.
            eng.ProcessOrderChange("SL1", 18.0);
            Snapshot(eng, "S231", "after SL widening 10 → 18 ticks");
            AssertGreater("S231 D2 evidence rose",
                eng.EvidenceD2 - e2Before, 0.1,
                "adverse SL widening must fire D2 Class B");
        }

        // =====================================================================
        // TIER 2 — MULTI-DIMENSION INTERACTIONS (S232–S236)
        // =====================================================================

        // S232 — Oversize + overstay: 3-lot position held 45 min (SizeMax=1,
        //        MaxHoldMinutes=30).  D3 + D5 both rise; aggregated PSI lower
        //        than either alone.
        private static void S232_OversizePlusOverstay()
        {
            Title("S232 — Oversize + overstay compound");
            var (eng, bl, prof) = NewEngine(sizeMax: 1.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 3, +1);
            bool _naked;
            for (int m = 1; m <= 45; m++)
            {
                t = t.AddMinutes(1);
                var sn = new List<PositionSnapshot> {
                    new PositionSnapshot {
                        Key = "TEST::INSTR", Quantity = 3, HasStopOrder = true,
                        HoldSeconds = 60 * m, MinUnrealizedPnl = -80 } };
                eng.PollPositions(sn, t, out _naked);
            }
            Snapshot(eng, "S232", "3-lot oversize held 45 min");
            AssertGreater("S232 D3 fires", eng.EvidenceD3, 1);
            AssertGreater("S232 D5 fires", eng.EvidenceD5, 0.5);
            AssertLess("S232 PSI ≤ 50", eng.CurrentPsi, 50,
                "two compounding Class A/B signals must drive PSI well below 65");
        }

        // S233 — Oversize + revenge: loser exit, oversize re-entry within
        //        urgency window.  D1 Class B + D3 Class A both fire.
        private static void S233_OversizePlusRevenge()
        {
            Title("S233 — Oversize revenge re-entry");
            var (eng, bl, prof) = NewEngine(sizeMax: 1.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 1, +1);
            t = t.AddSeconds(30);
            Close(eng, bl, -120, 1, t, false, 30, ExitKind.Manual);
            // 30 s later: oversize same-direction re-entry.
            t = t.AddSeconds(30);
            EntryFill(eng, t, 3, +1);
            Snapshot(eng, "S233", "oversize revenge");
            AssertGreater("S233 D1 Class B fired", eng.EvidenceD1, 0.5);
            AssertGreater("S233 D3 Class A fired", eng.EvidenceD3, 5);
            AssertLess("S233 PSI materially lower", eng.CurrentPsi, 70);
        }

        // S234 — Out-of-session + oversize: D3 + D6 both fire at entry.
        //
        // Post-2026-04-23 D6 redesign: session-window Class A is saturating
        // on minutesOver / sessionLengthMinutes.  Session 09:30–12:00 = 150 min,
        // entry at 14:00 → minutesOver = 121 → r = 121/150 = 0.81.
        //   E6 = 60·(1 − e^(−0.81)) = 33.3
        // Compound psychological insult: D3 r=2 (oversize to 3 vs SizeMax 1)
        // plus D6 r≈0.81 → multi-dim p=2 aggregation produces meaningful
        // PSI collapse without any single-dim dominating.
        private static void S234_OutOfSessionPlusOversize()
        {
            Title("S234 — Out-of-session oversize entry (compound D3+D6)");
            var (eng, bl, prof) = NewEngine(sizeMax: 1.0, sessionEndHour: 12);
            var t = new DateTime(2026, 4, 23, 14, 0, 0);  // 121 min past end
            EntryFill(eng, t, 3, +1);
            Snapshot(eng, "S234", "out-of-session oversize, D3 r=2 + D6 r≈0.81");
            AssertGreater("S234 D3 Class A fires", eng.EvidenceD3, 5);
            AssertBetween("S234 D6 evidence E6 ∈ [25, 45] (saturating r≈0.81)",
                eng.EvidenceD6, 25.0, 45.0,
                "121 min over in 150-min session → 60·(1−e^(−0.81)) ≈ 33");
            AssertLess("S234 PSI ≤ 50 (compound multi-dim collapse)",
                eng.CurrentPsi, 50,
                "D3 + D6 via p=2 aggregation: √(C3² + C6²) drives PSI < 50");
        }

        // S235 — MaxDailyLoss breach, then MORE losing entries that deepen
        //        the hole.  The new D6 design is monotone-marginal: each
        //        NEW deepening of overshoot deposits additional marginal
        //        evidence, saturating at CommitA_D6.  A partial-recovery
        //        or constant-overshoot repetition does NOT add evidence
        //        (previous sticky-latch behaviour, re-expressed in
        //        saturating math instead of a boolean flag).
        //
        // Replaces pre-2026-04-23 "sticky-latch / fire-once" semantics that
        // treated a $1-over-limit as identical to a $1000-over-limit.
        private static void S235_MaxDailyLossBreachContinued()
        {
            Title("S235 — Deepening breach deposits marginal evidence, saturating");
            var cfg = PsiEngineV2Config.Default;
            cfg.MaxDailyLossUsd = 200.0;  // scale_d6loss = 200
            var (eng, bl, prof) = NewEngine(cfg: cfg);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            // Stage 1 — 5 × $50 losses = $250 total → overshoot = $50, r = 0.25
            // → target = 60·(1 − e^(−0.25)) = 13.3.
            for (int i = 0; i < 5; i++)
            {
                EntryFill(eng, t, 1, +1);
                t = t.AddSeconds(30);
                Close(eng, bl, -50, 1, t, false, 30, ExitKind.ProtectiveStop);
                t = t.AddSeconds(20);
            }
            double e6S1 = eng.EvidenceD6;

            // Stage 2 — 2 more × $30 = $60 deepening → overshoot = $110, r = 0.55
            // → target = 60·(1 − e^(−0.55)) = 25.3.  Marginal from e6S1 ≈ +12.
            for (int i = 0; i < 2; i++)
            {
                EntryFill(eng, t, 1, +1);
                t = t.AddSeconds(30);
                Close(eng, bl, -30, 1, t, false, 30, ExitKind.ProtectiveStop);
                t = t.AddSeconds(20);
            }
            double e6S2 = eng.EvidenceD6;

            // Stage 3 — another entry but WITHOUT a new close.  The overshoot
            // has not deepened; CommitD6MaxDailyLossMarginal should deposit 0.
            EntryFill(eng, t, 1, +1);
            t = t.AddSeconds(30);
            double e6S3 = eng.EvidenceD6;

            Snapshot(eng, "S235", "staged breach deepening");
            AssertBetween("S235 Stage 1 E6 ∈ [9, 16] (r=0.25, I1 mild)",
                e6S1, 9.0, 16.0,
                "small overshoot produces small D6 evidence — saturating");
            AssertGreater("S235 Stage 2 E6 > Stage 1 (monotone growth)",
                e6S2, e6S1 + 1.0,
                "deepening overshoot must add marginal evidence");
            AssertBetween("S235 Stage 2 E6 ∈ [18, 28] (r=0.55)",
                e6S2, 18.0, 28.0,
                "moderate overshoot approaches I3 band");
            AssertTrue("S235 Stage 3 E6 ≈ Stage 2 (no new overshoot = no commit)",
                e6S3 <= e6S2 + 0.1,
                "replay of same overshoot must not double-count; " +
                "only deepening deposits marginal evidence");
        }

        // S236 — All 7 dimensions firing near-simultaneously (stress test).
        //        Demonstrates p=2 Euclidean aggregation does not allow any
        //        one dim to dominate when multiple are mid-severity.
        private static void S236_All7DimsFiring()
        {
            Title("S236 — All 7 dimensions non-zero");
            var (eng, _, _) = NewEngine();
            // Inject synthetic evidence via the public breach hook (D6) and
            // by direct Commit-equivalent sequences isn't exposed — instead
            // we observe natural aggregation by running a compound scenario:
            var cfg = PsiEngineV2Config.Default;
            cfg.MaxDailyLossUsd = 100.0;
            cfg.PauseAfterNLosses = 2;
            var prof = new StrategyProfile {
                SizeMin = 1, SizeMax = 1, SlTicksMax = 20,
                MaxReentrySeconds = 180, MaxHoldMinutes = 30,
                NoStopGraceSeconds = 20,
                TradesPerSessionMin = 1, TradesPerSessionMax = 2,
                SessionStartHour = 9, SessionStartMinute = 30,
                SessionEndHour = 12, SessionEndMinute = 0,
                Sensitivity = PsiSensitivity.Balanced,
            };
            var bl = new TradeBaseline();
            var eng2 = new PsiEngineV2(prof, bl, cfg);
            eng2.StartNewSession(100.0);
            var t = new DateTime(2026, 4, 23, 13, 0, 0);  // past session end → D6
            // Two quick manual loss exits (streak build → pressure; D4 does NOT
            // fire on quick exits — that was a semantic inversion corrected in v2.1).
            for (int i = 0; i < 2; i++)
            {
                EntryFill(eng2, t, 1, +1);
                t = t.AddSeconds(10);
                Close(eng2, bl, -60, 1, t, false, 10, ExitKind.Manual);
                t = t.AddSeconds(20);
            }
            // Now streak=2 = PauseAfterN → next entry is D1 Class A.
            EntryFill(eng2, t, 1, +1);
            // Widen stop → D2.
            eng2.ProcessOrderChange("SL1", 10.0);
            eng2.ProcessOrderChange("SL1", 20.0);
            // Hold as a losing naked-ish position for 35 min → D5.
            bool _naked;
            for (int m = 1; m <= 35; m++)
            {
                t = t.AddMinutes(1);
                var sn = new List<PositionSnapshot> {
                    new PositionSnapshot {
                        Key = "TEST::INSTR", Quantity = 1, HasStopOrder = true,
                        HoldSeconds = 60 * m, MinUnrealizedPnl = -60 } };
                eng2.PollPositions(sn, t, out _naked);
            }
            Snapshot(eng2, "S236", "multi-dimensional stress");
            int nonZero = 0;
            if (eng2.EvidenceD1 > 0.1) nonZero++;
            if (eng2.EvidenceD2 > 0.1) nonZero++;
            if (eng2.EvidenceD4 > 0.1) nonZero++;
            if (eng2.EvidenceD5 > 0.1) nonZero++;
            if (eng2.EvidenceD6 > 0.1) nonZero++;
            AssertGreater("S236 ≥ 4 dims firing", nonZero, 3);
            AssertLess("S236 PSI ≤ 30", eng2.CurrentPsi, 30,
                "multi-dim compound is the true psychological-collapse signature");
        }

        // =====================================================================
        // TIER 3 — NUMERICAL SAFETY & EDGE CASES (S237–S242)
        // =====================================================================

        // S237 — Out-of-order fillTime (backward jump).  Decay must not go
        //        negative; E must remain bounded; no NaN.
        private static void S237_BackwardFillTimeBounded()
        {
            Title("S237 — Backward fillTime is bounded (no negative E / NaN)");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 1, +1);
            Close(eng, bl, -30, 1, t.AddSeconds(10), false, 10, ExitKind.Manual);
            // Inject a backwards-moving close.
            Close(eng, bl, -30, 1, t.AddSeconds(-5), false, 10, ExitKind.Manual);
            Snapshot(eng, "S237", "after backward fillTime");
            AssertTrue("S237 PSI is finite",
                !double.IsNaN(eng.CurrentPsi) && !double.IsInfinity(eng.CurrentPsi));
            AssertBetween("S237 PSI in [0, 100]",
                eng.CurrentPsi, 0, 100.01);
            AssertGreater("S237 E1 ≥ 0", eng.EvidenceD1, -1e-9);
            AssertGreater("S237 E4 ≥ 0", eng.EvidenceD4, -1e-9);
        }

        // S238 — Zero hold duration (entry+exit at identical timestamp).
        //        Must not crash: D4 guard (holdSec <= 0 → return) handles this.
        private static void S238_ZeroHoldDurationSafe()
        {
            Title("S238 — Zero-duration fill must not div-by-zero");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 1, +1);
            Close(eng, bl, -30, 1, t, false, 0, ExitKind.Manual);
            Snapshot(eng, "S238", "after zero-duration");
            AssertTrue("S238 PSI finite",
                !double.IsNaN(eng.CurrentPsi) && !double.IsInfinity(eng.CurrentPsi));
            AssertBetween("S238 PSI in [0, 100]", eng.CurrentPsi, 0, 100.01);
        }

        // S239 — 24-hour flat idle at P=0.  E decays bounded, never negative.
        //        PSI monotonically recovers toward 100 (or 100 − carryDebt).
        //        Seed: oversize entry (qty=2 with sizeMax=1) so E3 > 0.
        private static void S239_LongIdleDecaysBounded()
        {
            Title("S239 — 24-hour idle: E decays bounded, PSI monotone up");
            var (eng, bl, prof) = NewEngine(sizeMax: 1.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 2, fillDir: +1);    // qty=2 > sizeMax=1 → D3 Class A
            t = t.AddSeconds(30);
            Close(eng, bl, -20, 2, t, false, 30, ExitKind.Manual);
            double psiBefore = eng.CurrentPsi;
            double e3Before  = eng.EvidenceD3;
            bool _naked;
            for (int h = 1; h <= 24; h++)
            {
                t = t.AddHours(1);
                eng.PollPositions(new List<PositionSnapshot>(), t, out _naked);
            }
            Snapshot(eng, "S239", "after 24h idle");
            AssertLess("S239 E3 shrinks dramatically",
                eng.EvidenceD3, e3Before * 0.01,
                "24h is many τ_decay half-lives — E ≈ 0");
            AssertGreater("S239 PSI recovers toward 100",
                eng.CurrentPsi, psiBefore,
                "idle decay is monotone up under zero pressure");
            AssertGreater("S239 E3 ≥ 0", eng.EvidenceD3, -1e-9);
            AssertGreater("S239 E4 ≥ 0", eng.EvidenceD4, -1e-9);
        }

        // S240 — Cold baseline (N=0 → μLoss=100 fallback).  openLoserFactor
        //        uses the fallback; pressure must not NaN.
        private static void S240_ColdBaselineFallback()
        {
            Title("S240 — Cold baseline μLoss fallback path");
            var prof = new StrategyProfile {
                SizeMin = 1, SizeMax = 2, SlTicksMax = 20,
                MaxReentrySeconds = 180, MaxHoldMinutes = 30,
                NoStopGraceSeconds = 20,
                TradesPerSessionMin = 3, TradesPerSessionMax = 15,
                SessionStartHour = 9, SessionStartMinute = 30,
                SessionEndHour = 16, SessionEndMinute = 0,
                Sensitivity = PsiSensitivity.Balanced,
            };
            var bl = new TradeBaseline();   // N=0
            var eng = new PsiEngineV2(prof, bl);
            eng.StartNewSession(100.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            // Simulate a live loser snapshot without any baseline build-up.
            bool _naked;
            var sn = new List<PositionSnapshot> {
                new PositionSnapshot {
                    Key = "TEST::INSTR", Quantity = 1, HasStopOrder = true,
                    HoldSeconds = 60, MinUnrealizedPnl = -250 } };
            eng.PollPositions(sn, t, out _naked);
            Snapshot(eng, "S240", "cold baseline + $250 MAE");
            AssertTrue("S240 P finite",
                !double.IsNaN(eng.Pressure) && !double.IsInfinity(eng.Pressure));
            AssertBetween("S240 P in [0, 1]", eng.Pressure, 0, 1.0001);
        }

        // S241 — 20× oversize single entry.  C3 must be strictly bounded to
        //        ≤ 100 by the severity map (1 − exp).
        private static void S241_HugeOversizeStillBounded()
        {
            Title("S241 — 20× oversize single entry: C3 ≤ 100");
            var (eng, bl, prof) = NewEngine(sizeMax: 1.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 20, +1);
            Snapshot(eng, "S241", "20× oversize");
            AssertLess("S241 C3 ≤ 100 strictly", eng.DebtD3, 100.0001);
            AssertBetween("S241 PSI in [0, 100]", eng.CurrentPsi, -0.0001, 100.0001);
        }

        // S242 — Pathological extreme Class A deposit.  PSI is clamped to
        //        [0, 100] at aggregation; any internal evidence magnitude
        //        is safe.
        //
        // Post-2026-04-23 redesign: MarkMaxDailyLossBreach requires an
        // actual overshoot to deposit evidence.  We realize a massive
        // $2000 loss against a $100 MaxDailyLoss → overshoot = $1900,
        // r = 19 → targetE = CommitA_D6 · (1 − e^(−19)) ≈ CommitA_D6.
        // With CommitA_D6 = 5000 (absurd stress value), E6 is huge, but
        // the final PSI aggregation clamps to 0.
        private static void S242_PsiFloorAtZero()
        {
            Title("S242 — PSI never negative under extreme load");
            var cfg = PsiEngineV2Config.Default;
            cfg.MaxDailyLossUsd = 100.0;
            cfg.CommitA_D6 = 5000;  // absurdly large for stress
            var (eng, bl, prof) = NewEngine(cfg: cfg);
            var t = new DateTime(2026, 4, 23, 13, 0, 0);
            // Realize a $2000 loss (sessionNetPnl = −2000, overshoot = 1900).
            EntryFill(eng, t, 1, +1);
            t = t.AddSeconds(30);
            Close(eng, bl, -2000, 1, t, false, 30, ExitKind.ProtectiveStop);
            t = t.AddSeconds(5);
            eng.MarkMaxDailyLossBreach(t);
            Snapshot(eng, "S242", "extreme Class A");
            AssertGreater("S242 PSI ≥ 0", eng.CurrentPsi, -1e-9);
            AssertLess("S242 PSI ≤ 100", eng.CurrentPsi, 100.0 + 1e-9);
        }

        // =====================================================================
        // TIER 4 — PRESSURE DERIVATION (S243–S246)
        // =====================================================================

        // S243 — P = max of four factors, not sum.  Verify directly with
        //        openLoserFactor ≈ 0.6, streakFactor ≈ 0.4, daily/hour = 0.
        //        P should equal 0.6, not 1.0 or 1.2.
        private static void S243_PressureIsMaxNotSum()
        {
            Title("S243 — P = max(factors), not sum");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            // Build streak = 2 (streakFactor = (2-1)/2 = 0.5).
            for (int i = 0; i < 2; i++)
            {
                EntryFill(eng, t, 1, +1);
                t = t.AddSeconds(30);
                Close(eng, bl, -50, 1, t, false, 30, ExitKind.ProtectiveStop);
                t = t.AddSeconds(20);
            }
            // Now a snapshot with MAE = 0.6 × μLoss = 60.
            bool _naked;
            var sn = new List<PositionSnapshot> {
                new PositionSnapshot {
                    Key = "TEST::INSTR", Quantity = 1, HasStopOrder = true,
                    HoldSeconds = 10, MinUnrealizedPnl = -60 } };
            eng.PollPositions(sn, t, out _naked);
            Snapshot(eng, "S243", "max aggregation test");
            // P should be dominated by openLoserFactor (0.6) not the sum (1.1).
            AssertLess("S243 P ≤ 0.7",  eng.Pressure, 0.7,
                "max-aggregation prevents factor summation");
            AssertGreater("S243 P ≥ 0.5", eng.Pressure, 0.5);
        }

        // S244 — streakFactor is monotone non-decreasing in streak.
        private static void S244_StreakFactorMonotonic()
        {
            Title("S244 — streakFactor non-decreasing with streak");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            double prevP = 0;
            bool monotonic = true;
            for (int i = 1; i <= 8; i++)
            {
                EntryFill(eng, t, 1, +1);
                t = t.AddSeconds(30);
                Close(eng, bl, -50, 1, t, false, 30, ExitKind.ProtectiveStop);
                t = t.AddSeconds(20);
                // Pressure here is ≥ prior pressure (factors only grow under consecutive losses).
                if (eng.Pressure + 1e-6 < prevP) monotonic = false;
                prevP = eng.Pressure;
            }
            Snapshot(eng, "S244", "streak=8");
            AssertTrue("S244 P monotone non-decreasing across 8 losses", monotonic);
            AssertGreater("S244 P saturated at 1", eng.Pressure, 0.95);
        }

        // S245 — openLoserFactor saturates at MAE ≥ μLoss.
        private static void S245_OpenLoserSaturation()
        {
            Title("S245 — openLoserFactor saturates at MAE ≥ μLoss");
            var (eng, _, _) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            bool _naked;
            var sn = new List<PositionSnapshot> {
                new PositionSnapshot {
                    Key = "TEST::INSTR", Quantity = 1, HasStopOrder = true,
                    HoldSeconds = 10, MinUnrealizedPnl = -500 } };
            eng.PollPositions(sn, t, out _naked);
            Snapshot(eng, "S245", "MAE = 5× μLoss");
            AssertGreater("S245 P ≈ 1", eng.Pressure, 0.95);
            AssertLess("S245 P ≤ 1", eng.Pressure, 1.0 + 1e-6);
        }

        // S246 — dailyProxFactor = sessionLoss / MaxDailyLossUsd linearly
        //        until saturation at the breach.
        private static void S246_DailyProxLinearToBreach()
        {
            Title("S246 — dailyProxFactor rises linearly to 1 at breach");
            var cfg = PsiEngineV2Config.Default;
            cfg.MaxDailyLossUsd = 200.0;
            var (eng, bl, prof) = NewEngine(cfg: cfg);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            double[] expected = { 0.25, 0.5, 0.75, 1.0 };  // after each $50 loss
            int idx = 0;
            for (int i = 0; i < 4; i++)
            {
                EntryFill(eng, t, 1, +1);
                t = t.AddSeconds(30);
                Close(eng, bl, -50, 1, t, false, 30, ExitKind.ProtectiveStop);
                // Observe P after this fill (it has streak too; daily prox
                // may or may not dominate — we only require non-decreasing).
                t = t.AddSeconds(20);
                idx++;
            }
            Snapshot(eng, "S246", "sessionLoss = 200");
            AssertGreater("S246 P saturated at 1 on breach", eng.Pressure, 0.95);
        }

        // =====================================================================
        // TIER 5 — DETERMINISM & MONOTONICITY (S247–S249)
        // =====================================================================

        // S247 — Two identical input sequences must produce bit-identical
        //        output state.  Guards against hidden DateTime.Now reads.
        private static void S247_DeterminismIdenticalInputs()
        {
            Title("S247 — Bit-identical output on identical inputs");
            var (engA, blA, _) = NewEngine();
            var (engB, blB, _) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            for (int i = 0; i < 4; i++)
            {
                EntryFill(engA, t, 1, +1);
                EntryFill(engB, t, 1, +1);
                var tc = t.AddSeconds(30);
                Close(engA, blA, -30, 1, tc, false, 30, ExitKind.Manual);
                Close(engB, blB, -30, 1, tc, false, 30, ExitKind.Manual);
                t = tc.AddSeconds(20);
            }
            AssertTrue("S247 PSI identical",
                Math.Abs(engA.CurrentPsi - engB.CurrentPsi) < 1e-9,
                "V2 engine must be pure wrt inputs");
            AssertTrue("S247 all E_i identical",
                Math.Abs(engA.EvidenceD1 - engB.EvidenceD1) < 1e-9 &&
                Math.Abs(engA.EvidenceD4 - engB.EvidenceD4) < 1e-9);
        }

        // S248 — Commit is monotone-up: E never drops during a fill that
        //        only contains commits (no time advance).
        private static void S248_CommitMonotoneUp()
        {
            Title("S248 — Commit never decreases E");
            var (eng, bl, prof) = NewEngine(sizeMax: 1.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            double prev = 0;
            bool monotone = true;
            for (int i = 0; i < 3; i++)
            {
                EntryFill(eng, t, 2, +1);
                if (eng.EvidenceD3 + 1e-9 < prev) monotone = false;
                prev = eng.EvidenceD3;
                // Close immediately at same time — no decay interval.
                Close(eng, bl, -20, 2, t, false, 0, ExitKind.Manual);
                t = t.AddSeconds(1);  // minimal advance
            }
            AssertTrue("S248 E3 monotone up across commits", monotone);
        }

        // S249 — Decay is monotone-down: during pure-idle at P=0, E strictly
        //        non-increasing, PSI strictly non-decreasing.
        //
        //        Setup uses a D3 oversize entry so E3 > 0 at P=0, giving
        //        a real seed to verify monotone-down decay.  A single loss with
        //        no repeat entries keeps streak=1 → streakExcess=0 → P=0 (no
        //        open loser, no daily-prox, no pace factor with defaults).
        private static void S249_DecayMonotoneDown()
        {
            Title("S249 — Pure-idle decay is monotone at P=0");
            // SizeMax=1 so entry with qty=2 → D3 Class A fires (oversize seed).
            var (eng, bl, prof) = NewEngine(sizeMax: 1.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 2, fillDir: +1);   // qty=2 > sizeMax=1 → D3 Class A
            t = t.AddSeconds(30);
            Close(eng, bl, -20, 2, t, false, 30, ExitKind.Manual);
            AssertLess("S249 pre-idle P ≈ 0", eng.Pressure, 0.05,
                "single-loss setup must have zero streak pressure (streak=1, excess=0)");
            double prevE3  = eng.EvidenceD3;
            double prevPsi = eng.CurrentPsi;
            bool monotoneE = true, monotonePsi = true;
            bool _naked;
            for (int m = 1; m <= 60; m++)
            {
                t = t.AddMinutes(1);
                eng.PollPositions(new List<PositionSnapshot>(), t, out _naked);
                if (eng.EvidenceD3 > prevE3 + 1e-9) monotoneE = false;
                if (eng.CurrentPsi + 1e-9 < prevPsi) monotonePsi = false;
                prevE3  = eng.EvidenceD3;
                prevPsi = eng.CurrentPsi;
            }
            AssertTrue("S249 E3 monotone down during idle", monotoneE);
            AssertTrue("S249 PSI monotone up during idle", monotonePsi);
        }

        // =====================================================================
        // TIER 6 — HISTORICAL V1 BUG REGRESSION (S250–S252)
        // =====================================================================

        // S250 — v1.1.4 D3 P&L coupling bug — identical size trajectory under
        //        flipped P&L must produce IDENTICAL E3 / D3 debt in V2.
        //        This is the discipline-over-outcome invariant for D3.
        private static void S250_D3PnlFlipNeutrality()
        {
            Title("S250 — v1.1.4 regression: D3 is P&L-flip neutral");
            var (engA, blA, _) = NewEngine(sizeMax: 1.0);
            var (engB, blB, _) = NewEngine(sizeMax: 1.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            // Same trajectory: oversize 3-lot entry → 5 min hold → close.
            EntryFill(engA, t, 3, +1);
            EntryFill(engB, t, 3, +1);
            var tc = t.AddMinutes(5);
            Close(engA, blA, -180, 3, tc, false, 300, ExitKind.Manual);  // loser
            Close(engB, blB, +180, 3, tc, true,  300, ExitKind.Manual);  // winner
            Snapshot(engA, "S250A", "oversize loser");
            Snapshot(engB, "S250B", "oversize winner");
            AssertTrue("S250 D3 identical under P&L flip",
                Math.Abs(engA.EvidenceD3 - engB.EvidenceD3) < 0.1,
                "D3 must be driven by size-over-limit integral only, not P&L");
        }

        // S251 — v1.1 time-domain mismatch — wall-clock vs engine-time.
        //        V2 only uses caller-supplied engineTime, so a scenario that
        //        advances wall-clock but leaves engine time static must NOT
        //        cause any decay or fatigue accrual.  (In V2 this is
        //        structural: no DateTime.Now inside engine.)
        private static void S251_TimeDomainIndependence()
        {
            Title("S251 — Engine output invariant to wall-clock advance");
            var (engA, blA, _) = NewEngine();
            var (engB, blB, _) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(engA, t, 1, +1);
            EntryFill(engB, t, 1, +1);
            Close(engA, blA, -30, 1, t.AddSeconds(10), false, 10, ExitKind.Manual);
            Close(engB, blB, -30, 1, t.AddSeconds(10), false, 10, ExitKind.Manual);
            // engA continues with engine time; engB's wall clock advances
            // (no-op since V2 doesn't read it), engine time stays the same.
            double psiA = engA.CurrentPsi;
            double psiB = engB.CurrentPsi;
            AssertTrue("S251 PSI identical (no wall-clock leakage)",
                Math.Abs(psiA - psiB) < 1e-9,
                "if V2 ever reads DateTime.Now internally, this would diverge");
        }

        // S252 — v1 snap-up runaway on single large oversize.  V2 bounds it
        //        via the (1 − exp) severity map, not a cap.
        private static void S252_SnapUpNotRequired()
        {
            Title("S252 — Large single oversize stays bounded (no snap-up law)");
            var (eng, _, _) = NewEngine(sizeMax: 1.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 10, +1);
            Snapshot(eng, "S252", "10× oversize");
            // C3 < 100 strictly via severity map (no special cap needed).
            AssertLess("S252 C3 < 100", eng.DebtD3, 100.0);
            AssertBetween("S252 PSI in [0, 100]",
                eng.CurrentPsi, -0.0001, 100.0001);
        }

        // =====================================================================
        // TIER 7 — NARRATIVE REALISTIC SESSIONS (S253–S255)
        //
        // End-to-end "a day in the life" tests.  These are the user's
        // confidence-building scenarios: does PSI rate realistic sessions
        // correctly overall?
        // =====================================================================

        // S253 — Full tilt day: 10 trades, 7 losses, oversize mid-day,
        //        breached session window in the last 2 trades.  Expected
        //        PSI final < 45.
        private static void S253_FullTiltDay()
        {
            Title("S253 — Full tilt day (realistic collapse scenario)");
            var cfg = PsiEngineV2Config.Default;
            cfg.MaxDailyLossUsd = 300.0;
            var (eng, bl, prof) = NewEngine(sizeMax: 1.0, sessionEndHour: 12,
                cfg: cfg);
            var t = new DateTime(2026, 4, 23, 9, 30, 0);
            // 3 disciplined bracket SLs (−$40 each, −$120 total).
            for (int i = 0; i < 3; i++) {
                EntryFill(eng, t, 1, +1);
                t = t.AddMinutes(5);
                Close(eng, bl, -40, 1, t, false, 300, ExitKind.ProtectiveStop);
                t = t.AddMinutes(15);
            }
            // Oversize revenge after the third SL (−$80 manual).
            EntryFill(eng, t, 3, +1);
            t = t.AddMinutes(2);
            Close(eng, bl, -80, 3, t, false, 120, ExitKind.Manual);
            t = t.AddMinutes(5);
            // Two more quick manual losses (build streak + D4).
            for (int i = 0; i < 2; i++) {
                EntryFill(eng, t, 1, +1);
                t = t.AddSeconds(15);
                Close(eng, bl, -40, 1, t, false, 15, ExitKind.Manual);
                t = t.AddSeconds(45);
            }
            // Out-of-session tilt: 2 more entries past 12:00.
            t = new DateTime(2026, 4, 23, 12, 30, 0);
            for (int i = 0; i < 2; i++) {
                EntryFill(eng, t, 1, +1);
                t = t.AddMinutes(1);
                Close(eng, bl, -30, 1, t, false, 60, ExitKind.Manual);
                t = t.AddMinutes(4);
            }
            Snapshot(eng, "S253", "full tilt day");
            AssertLess("S253 PSI ≤ 45", eng.CurrentPsi, 45,
                "multi-dim cascade of real violations must land PSI in warning zone");
        }

        // S254 — Good session: 8 disciplined bracket exits, mixed wins/losses,
        //        all within session.  Expected PSI ≥ 90.
        private static void S254_GoodDisciplinedSession()
        {
            Title("S254 — Good disciplined session (4 TP + 4 SL, bracket)");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 9, 30, 0);
            // Alternating: TP, SL, TP, SL, ...
            for (int i = 0; i < 8; i++)
            {
                EntryFill(eng, t, 1, +1);
                t = t.AddMinutes(6);
                if (i % 2 == 0)
                    Close(eng, bl, +50, 1, t, true,  360, ExitKind.Target);
                else
                    Close(eng, bl, -30, 1, t, false, 360, ExitKind.ProtectiveStop);
                t = t.AddMinutes(10);
            }
            Snapshot(eng, "S254", "8 disciplined bracket exits");
            AssertGreater("S254 PSI ≥ 90", eng.CurrentPsi, 90,
                "perfectly disciplined trading must leave PSI high regardless of P&L mix");
        }

        // S255 — Recovery day: start from carryDebt = 30 (yesterday PSI 70),
        //        disciplined day of 5 bracket exits, PSI recovers to ≥ 80.
        private static void S255_RecoveryDayFromCarryDebt()
        {
            Title("S255 — Recovery day from prior-session carryDebt");
            var (eng, bl, prof) = NewEngine();
            eng.StartNewSession(70.0);  // yesterday ended at 70 → carry = 30
            eng.ApplyOvernightDecay(14.0);  // 14 h overnight decay
            var t = new DateTime(2026, 4, 24, 9, 30, 0);
            for (int i = 0; i < 5; i++)
            {
                EntryFill(eng, t, 1, +1);
                t = t.AddMinutes(8);
                // Alternate TP/SL.
                if (i % 2 == 0)
                    Close(eng, bl, +60, 1, t, true,  480, ExitKind.Target);
                else
                    Close(eng, bl, -30, 1, t, false, 480, ExitKind.ProtectiveStop);
                t = t.AddMinutes(15);
            }
            Snapshot(eng, "S255", "recovery day");
            AssertGreater("S255 PSI ≥ 80 after disciplined recovery",
                eng.CurrentPsi, 80,
                "carryDebt must drain on a disciplined day without re-accruing");
        }

        // =====================================================================
        // TIER 9 — NARRATIVE PSYCHOLOGICAL JOURNEY TESTS (S256–S261)
        //
        // End-to-end "a day in the trader's mind" tests.  Unlike the Tier 7
        // result-only checks (S253–S255), each scenario has CHECKPOINT
        // assertions at every psychological turning point so you can read the
        // PSI log and verify the story makes sense — not just the final number.
        //
        // These tests also validate the v2.1 calibration fixes:
        //   • D3 Class B formula is now scale-relative (Axiom 8 fix)
        //   • TauDecayD3 = 2000 s (no more "instant recovery" bug)
        //   • Saturating Class A prevents single-event total collapse
        // =====================================================================

        // S256 — The Oversize Incident (your live scenario from 2026-04-22)
        //
        // Narrative arc:
        //   1. One disciplined bracket SL          → PSI barely moves (≥ 96)
        //   2. 3× oversize entry (size=6, Max=2)   → PSI drops critically (≥ 35 pts)
        //   3. Quick manual TP close (5 s hold)    → PSI stays low (winning trade
        //                                            does NOT undo the commitment break)
        //   4. 30-min flat cooling period           → PSI partially recovers (~40 %
        //                                            decay per I5; TauDecay=2000 s)
        //
        // This test directly validates the Path-B fix: old TauDecayD3=120 s caused
        // "突然回升" after close; new TauDecayD3=2000 s keeps PSI low for ~30 min.
        private static void S256_OversizeIncident()
        {
            Title("S256 — The Oversize Incident (live scenario 2026-04-22, v2.1 calibration)");
            var (eng, bl, prof) = NewEngine(sizeMax: 2.0);
            var t = new DateTime(2026, 4, 23, 9, 30, 0);

            // ── Phase 1: disciplined bracket SL ──────────────────────────────
            EntryFill(eng, t, 1, +1);
            t = t.AddMinutes(5);
            Close(eng, bl, -40, 1, t, false, 300, ExitKind.ProtectiveStop);
            double psi1 = eng.CurrentPsi;
            Snapshot(eng, "S256a", "after 1 disciplined bracket SL");
            AssertGreater("S256a PSI ≥ 96 (planned stop = no penalty)",
                psi1, 96.0,
                "a single protective stop with no pressure context must leave PSI intact");

            // ── Phase 2: 3× oversize entry (excess=4, scale=2, r=2.0) ────────
            t = t.AddMinutes(2);
            EntryFill(eng, t, 6, +1);
            double psi2 = eng.CurrentPsi;
            double dropPhase2 = psi1 - psi2;
            Snapshot(eng, "S256b", "after 3× oversize entry (size=6, SizeMax=2)");
            // Class A: targetE = CommitA × (1−exp(−r)) = 60×(1−exp(−2)) ≈ 51.9
            // C3 = (1−exp(−51.9/TauSev=60))×100 ≈ 58 % → PSI drops ~58 pts from D3.
            AssertGreater("S256b PSI drop ≥ 35 pts (critical Class A for r=2)",
                dropPhase2, 35.0,
                "3× limit breach is between I3 and I4 severity — must hit warning zone");
            AssertLess("S256b PSI in warning zone (≤ 65)",
                psi2, 65.0);

            // ── Phase 3: quick manual TP close (5 s hold) ────────────────────
            t = t.AddSeconds(5);
            Close(eng, bl, 120, 6, t, true, 5, ExitKind.Manual);
            double psi3 = eng.CurrentPsi;
            Snapshot(eng, "S256c", "after manual TP close (5 s hold)");
            // 5 s of B: 0.5×(4/2)×5 = 5 evidence (negligible vs Class A ≈ 52).
            // Net psi3 ≈ psi2 (small decay + small B roughly cancel).
            AssertTrue("S256c TP close does not regenerate PSI (Axiom 1: PSI ≠ P&L)",
                psi3 <= psi2 + 3.0,
                "winning the trade does not undo the oversize commitment break");

            // ── Phase 4: 30-min flat cooling ─────────────────────────────────
            double e0 = eng.EvidenceD3;
            Idle(eng, ref t, 1800);   // 30 min = 1 × τ_decay (exp(-0.9) ≈ 0.407)
            double psi4 = eng.CurrentPsi;
            Snapshot(eng, "S256d", "after 30 min flat idle");
            AssertGreater("S256d PSI recovered ≥ 8 pts vs post-close",
                psi4 - psi3, 8.0,
                "TauDecay=2000 s gives ~40 % E3 reduction in 30 min → visible lift");
            AssertLess("S256d PSI still below psi1 − 5 (not fully recovered)",
                psi4, psi1 - 5.0,
                "oversize evidence persists at ~40 % of peak; full recovery takes ~2 h");
            AssertLess("S256d D3 evidence ≤ 55 % of peak",
                eng.EvidenceD3, e0 * 0.55,
                "exp(−1800/2000) ≈ 0.407 → evidence near 40 % of peak");
            AssertGreater("S256d D3 evidence ≥ 35 % of peak",
                eng.EvidenceD3, e0 * 0.35,
                "evidence hasn't vanished — this is the correct slow-recovery behavior");
        }

        // S257 — Tilt Arc
        //
        // Narrative arc:
        //   1. Two disciplined bracket SLs          → PSI ≥ 92 (normal session)
        //   2. Revenge re-entry within 30 s (D1)    → PSI starts dropping
        //   3. Oversize entry + 2-min manual loss   → D3 compounds D1
        //   4. Out-of-session trade (D6)            → PSI in danger zone (≤ 35)
        //   5. 4-hour cooling period                → PSI recovers substantially (≥ 75)
        //
        // Key insight: every τ_decay < 60 min, so 4 h ≈ 4+ half-lives.  The
        // severe acute signals from morning have substantially resolved.
        private static void S257_TiltArc()
        {
            Title("S257 — Tilt Arc (revenge + oversize + out-of-session → 4 h rest)");
            var cfg = PsiEngineV2Config.Default;
            cfg.PauseAfterNLosses = 99;   // isolate D1/D3/D6 for clarity
            var (eng, bl, prof) = NewEngine(sizeMax: 2.0, sessionEndHour: 11, cfg: cfg);
            var t = new DateTime(2026, 4, 23, 9, 30, 0);

            // ── Trades 1–2: two disciplined bracket SLs ──────────────────────
            for (int i = 0; i < 2; i++)
            {
                EntryFill(eng, t, 1, +1);
                t = t.AddMinutes(5);
                Close(eng, bl, -50, 1, t, false, 300, ExitKind.ProtectiveStop);
                t = t.AddSeconds(20);
            }
            double psi2SL = eng.CurrentPsi;
            Snapshot(eng, "S257a", "after 2 disciplined bracket SLs");
            AssertGreater("S257a PSI ≥ 92 (two clean SLs = normal session so far)",
                psi2SL, 92.0);

            // ── Trade 3: revenge re-entry 30 s after second SL ───────────────
            t = t.AddSeconds(30);  // 30 s < MaxReentrySeconds=180 → urgency clock fires
            EntryFill(eng, t, 1, +1);
            t = t.AddMinutes(5);
            Close(eng, bl, -50, 1, t, false, 300, ExitKind.ProtectiveStop);

            // ── Trade 4: oversize entry (size=3, SizeMax=2, excess=1) + 2-min loss ──
            t = t.AddSeconds(30);
            EntryFill(eng, t, 3, +1);   // r = 1/2 = 0.5
            t = t.AddMinutes(2);
            Close(eng, bl, -80, 3, t, false, 120, ExitKind.Manual);
            Snapshot(eng, "S257b", "after revenge + oversize + manual loss");

            // ── Out-of-session tilt: session ends 11:00, trade at 11:30 ──────
            t = new DateTime(2026, 4, 23, 11, 30, 0);
            EntryFill(eng, t, 1, +1);
            t = t.AddMinutes(5);
            Close(eng, bl, -30, 1, t, false, 300, ExitKind.Manual);
            double psiCascade = eng.CurrentPsi;
            Snapshot(eng, "S257c", "after out-of-session tilt trade");
            AssertLess("S257c PSI ≤ 35 (multi-dim D1+D3+D6 cascade = danger zone)",
                psiCascade, 35.0,
                "combined commitment breaks must put PSI well below the 40-pt line");

            // ── 4-hour cooling ────────────────────────────────────────────────
            Idle(eng, ref t, 14400);   // 4 h = 4+ τ_decay half-lives
            double psiAfterRest = eng.CurrentPsi;
            Snapshot(eng, "S257d", "after 4-hour cooling period");
            // TauDecayD3=2000 s: exp(-14400/2000)=0.0007 → E3 ≈ 0.
            // TauDecayD6=3000 s: exp(-14400/3000)=0.0082 → E6 trace only.
            // PSI recovers to near 100 (carryDebt=0 within-session).
            AssertGreater("S257d PSI > 75 (4 h rest = acute distress resolved)",
                psiAfterRest, 75.0,
                "all τ_decay < 60 min; after 4 h all evidence near zero");
        }

        // S258 — Overconfidence Arc
        //
        // Narrative arc:
        //   1. 3 consecutive bracket TP wins   → PSI ≥ 96 (disciplined, no inflation)
        //   2. 2× oversize entry (r=1.0)        → PSI drops ≥ 30 pts despite win streak
        //
        // Key assertion (Axiom 1): PSI measures behavior vs. commitment, NOT P&L.
        // A winning streak does NOT grant permission to oversize.
        private static void S258_OverconfidenceArc()
        {
            Title("S258 — Overconfidence Arc (3 wins then 2× oversize, Axiom 1)");
            var (eng, bl, prof) = NewEngine(sizeMax: 2.0);
            var t = new DateTime(2026, 4, 23, 9, 30, 0);

            // ── 3 consecutive bracket TP wins (all at SizeMax=2) ─────────────
            for (int i = 0; i < 3; i++)
            {
                EntryFill(eng, t, 2, +1);
                t = t.AddMinutes(6);
                Close(eng, bl, +50, 2, t, true, 360, ExitKind.Target);
                t = t.AddMinutes(10);
            }
            double psiWinStreak = eng.CurrentPsi;
            Snapshot(eng, "S258a", "after 3 bracket TP wins");
            AssertGreater("S258a PSI ≥ 96 (wins don't inflate PSI above discipline floor)",
                psiWinStreak, 96.0);

            // ── 2× oversize entry (size=4, SizeMax=2, excess=2, r=1.0) ───────
            EntryFill(eng, t, 4, +1);
            double psiAfterOS = eng.CurrentPsi;
            double drop = psiWinStreak - psiAfterOS;
            Snapshot(eng, "S258b", "after 2× oversize entry (r=1.0)");
            // Class A: targetE = 60×(1−e⁻¹) = 37.9 → C3 ≈ 47 % → PSI drop ~47 pts.
            AssertGreater("S258b PSI drops ≥ 30 pts despite win streak (Axiom 1)",
                drop, 30.0,
                "commitment break is commitment break regardless of prior P&L");
            AssertGreater("S258b D3 evidence > 20 (Class A r=1 fired)",
                eng.EvidenceD3, 20.0,
                "r=1 → CommitA×(1−e⁻¹) ≈ 37.9 evidence");
        }

        // S259 — Revenge then Self-Correction
        //
        // Narrative arc:
        //   1. SL + immediate re-entry (30 s) → D1 Class B fires (urgency detected)
        //   2. Second SL + wait 4 min         → beyond MaxReentrySeconds=180
        //   3. Disciplined re-entry (4 min)   → D1 does NOT fire again
        //
        // Key assertion: D1 is time-gated.  Self-correction (waiting the urgency
        // window) prevents the pattern from escalating.  E1 should not increase
        // meaningfully on the post-wait re-entry.
        // S259 — Revenge then Self-Correction
        //
        // Narrative arc:
        //   1. Manually-closed loss (NOT bracket): painful exit sets D1 urgency anchor
        //   2. Re-entry within 30 s (D1 urgency gate: OPEN)   → D1 Class B fires
        //   3. Second manual loss + wait 4 min (> MaxReentrySeconds=180)
        //   4. Disciplined re-entry after waiting               → D1 does NOT fire again
        //
        // Key insight: the revenge-trading signal requires the PREVIOUS exit to
        // have been a manual/forced close (not a pre-planned bracket stop).
        // A ProtectiveStop exit is the signature of DISCIPLINE — we explicitly do
        // not set the D1 urgency anchor for it (S230 guards this invariant).
        // Here, the trader manually closed (plan break or stop removed) — that
        // sets the anchor.  Waiting 4 min then re-entering is self-correction:
        // giving the urgency window time to expire before acting.
        private static void S259_RevengeThenSelfCorrection()
        {
            Title("S259 — Revenge then Self-Correction (D1 time gate)");
            var (eng, bl, prof) = NewEngine(sizeMax: 2.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            // ── Trade 1: manually-closed loss (sets D1 urgency anchor) ────────
            // ExitKind.Manual represents a non-bracket close (plan deviation,
            // removed SL, or panic exit) — this IS the D1 trigger event.
            // Loss must be ≥ D1SignificantLossFraction × μLoss to qualify as
            // "significant."  With a cold baseline, GetEffectiveMuLoss() returns
            // $100 (floor); threshold = 0.8 × 100 = $80.  We use -$100 so the
            // loss is clearly above the threshold regardless of baseline warmth.
            EntryFill(eng, t, 1, +1);
            t = t.AddMinutes(5);
            Close(eng, bl, -100, 1, t, false, 300, ExitKind.Manual);

            // ── Trade 2: revenge re-entry 30 s later (D1 urgency gate: OPEN) ─
            t = t.AddSeconds(30);   // 30 s < MaxReentrySeconds=180
            EntryFill(eng, t, 1, +1);
            double e1AfterRevenge = eng.EvidenceD1;
            t = t.AddMinutes(5);
            Close(eng, bl, -100, 1, t, false, 300, ExitKind.Manual);
            Snapshot(eng, "S259a", "after revenge re-entry (30 s after manual loss)");
            AssertGreater("S259a D1 evidence > 1 (urgency Class B fired)",
                e1AfterRevenge, 1.0,
                "re-entry 30 s after a manual loss is the canonical revenge-trading signal");

            // ── Wait 4 min: D1 urgency clock expires ──────────────────────────
            t = t.AddMinutes(4);   // 240 s >> MaxReentrySeconds=180

            // ── Trade 3: clean disciplined re-entry ───────────────────────────
            // E1 has been decaying during the 4-min wait.
            double e1BeforeClean = eng.EvidenceD1;
            EntryFill(eng, t, 1, +1);
            double e1AfterClean = eng.EvidenceD1;
            Snapshot(eng, "S259b", "after disciplined re-entry (4 min wait)");
            // D1 should NOT fire: re-entry is outside the urgency window.
            // Any increment must be negligible (< 1.5) vs the 30-s revenge signal.
            AssertLess("S259b D1 increment < 1.5 on clean late re-entry",
                e1AfterClean - e1BeforeClean, 1.5,
                "240 s > MaxReentrySeconds=180 → re-entry is below the D1 urgency threshold");
            AssertGreater("S259b D1 evidence has decayed since revenge",
                e1AfterRevenge - e1AfterClean, 0.0,
                "the 4-min wait + discipline lets D1 evidence decay, not accumulate");
        }

        // S260 — Ghost Recovery Day
        //
        // Narrative arc:
        //   Previous session ended at PSI=35 (severe tilt day).
        //   Today: overnight decay + 6 perfectly disciplined trades.
        //
        // Key assertion: yesterday's carryDebt persists as a PSI ceiling today.
        // The "ghost" of yesterday cannot be erased by today's discipline alone —
        // only time (overnight decay across sessions) resolves it.
        // PSI after overnight: ~60.  After 6 clean trades: stays near 60.
        private static void S260_GhostRecoveryDay()
        {
            Title("S260 — Ghost Recovery Day (PSI 35 yesterday, perfect today)");
            var (eng, bl, prof) = NewEngine();
            // StartNewSession applies assumed 16 h overnight decay internally.
            // OvernightEstimatedHours=16, TauHours=48:
            //   carry = 65 × exp(−16/48) = 65 × 0.717 = 46.6
            //   PSI after StartNewSession ≈ 53.4
            eng.StartNewSession(35.0);
            // Additional observed 8 h of real overnight rest.
            //   carry = 46.6 × exp(−8/48) = 46.6 × 0.846 ≈ 39.4
            //   PSI ≈ 60.6
            eng.ApplyOvernightDecay(8.0);
            double psiOvernight = eng.CurrentPsi;
            Snapshot(eng, "S260a", "after overnight decay from PSI=35 yesterday");
            AssertBetween("S260a PSI ∈ [50, 72] (ghost carry from yesterday)",
                psiOvernight, 50.0, 72.0,
                "24 h of decay leaves ~40 % of yesterday's deficit as today's carry");

            // 6 perfectly disciplined bracket trades.
            var t = new DateTime(2026, 4, 24, 9, 30, 0);
            for (int i = 0; i < 6; i++)
            {
                EntryFill(eng, t, 1, +1);
                t = t.AddMinutes(8);
                if (i % 2 == 0)
                    Close(eng, bl, +60, 1, t, true,  480, ExitKind.Target);
                else
                    Close(eng, bl, -30, 1, t, false, 480, ExitKind.ProtectiveStop);
                t = t.AddMinutes(15);
            }
            double psiFinal = eng.CurrentPsi;
            Snapshot(eng, "S260b", "after 6 disciplined trades on ghost day");
            // No new evidence → PSI = 100 − carryDebt ≈ 60.6 (unchanged by trades).
            // The ghost is the ceiling: you cannot earn your way above carryDebt
            // within the same session; only another overnight cycle clears it.
            AssertBetween("S260b PSI ∈ [50, 75] (ghost persists as ceiling)",
                psiFinal, 50.0, 75.0,
                "perfect today doesn't erase yesterday's carryDebt — only time does");
            AssertTrue("S260b PSI hasn't regressed from disciplined trades",
                psiFinal >= psiOvernight - 5.0,
                "clean trades add no new evidence; PSI must stay flat or improve");
        }

        // S261 — Clean Scalper
        //
        // Narrative arc:
        //   12 rapid disciplined bracket trades (6 TP + 6 SL), 5-min hold each,
        //   all within session, all at SizeMax.  PSI never leaves the safe zone.
        //
        // Key assertion: high-frequency trading is NOT penalized when every
        // decision is disciplined.  D7 budget is not exceeded (12 < max=15).
        // D1 does not fire (10-min entry spacing >> MaxReentrySeconds=180).
        private static void S261_CleanScalper()
        {
            Title("S261 — Clean Scalper (12 rapid disciplined bracket trades)");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 9, 30, 0);
            double minPsi = eng.CurrentPsi;

            for (int i = 0; i < 12; i++)
            {
                EntryFill(eng, t, 1, +1);
                t = t.AddMinutes(5);
                if (i % 2 == 0)
                    Close(eng, bl, +40, 1, t, true,  300, ExitKind.Target);
                else
                    Close(eng, bl, -25, 1, t, false, 300, ExitKind.ProtectiveStop);
                t = t.AddMinutes(5);   // 10-min total cycle: well above D1 window
                double psiNow = eng.CurrentPsi;
                if (psiNow < minPsi) minPsi = psiNow;
            }
            Snapshot(eng, "S261", "after 12 disciplined bracket trades");
            AssertGreater("S261 final PSI ≥ 88 (disciplined scalper stays safe)",
                eng.CurrentPsi, 88.0,
                "bracket exits at correct size with no violations must preserve PSI");
            AssertGreater("S261 min session PSI ≥ 85 (no unexpected drops)",
                minPsi, 85.0,
                "PSI must never drop below caution for a perfectly clean session");
        }

        // =====================================================================
        // Helpers
        // =====================================================================

        // =====================================================================
        // TIER 8 — INVARIANT CONTRACT I1–I6 (I301–I312)
        //
        // These scenarios DIRECTLY test the Invariant Contract defined in
        // ARCHITECTURE.md §15.11 and psi-v2-evidence-accumulator.mdc.  They
        // are not derived from a particular calibration target — they are
        // the targets themselves.  If these fail, either the engine math or
        // the parameter derivation is wrong; fix the root cause (Anti-pattern
        // 9 forbids "picking" a number to make these green).
        // =====================================================================

        // I301 — I1: Mild severity (s = scale/3) produces C_i ≤ 30.
        //        D3 with SizeMax = 3 (scale = 3) → mild = size 4 (excess 1).
        private static void I301_I1_D3_MildSeverityBounded()
        {
            Title("I301 [I1] — D3 mild severity (excess = scale/3) ⇒ C3 ≤ 30");
            var (eng, bl, prof) = NewEngine(sizeMax: 3.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 4, +1);   // excess = 1, scale = 3, r = 1/3
            Snapshot(eng, "I301", "mild oversize size 4 / SizeMax 3");
            AssertLess("I301 C3 ≤ 30 (I1 bound)", eng.DebtD3, 30.0,
                "one-event mild break must not cross the critical threshold");
            AssertGreater("I301 C3 > 0", eng.DebtD3, 0.0,
                "a mild break must still register some evidence");
        }

        // I302 — I1 for D6 (binary-trigger Class A).  D6 CommitA = 60, τ_sev=60 →
        //        C6 = (1 − exp(−60/60)) × 100 = 63.2.  D6 is binary, so a
        //        single event lands at CommitA regardless of severity — this
        //        test verifies the binary-trigger drop is within the I4 upper
        //        (≤ 70), not an I1 test per se.  Covered here for symmetry.
        // I302 [I1] — D6 MaxDailyLoss at MILD overshoot (r = 1/3) ⇒ C6 ≤ 30.
        //   Post-2026-04-23 D6 redesign: Class A is saturating-marginal on
        //   overshootUsd / MaxDailyLossUsd.  A $33 overshoot against a $100
        //   MaxDailyLoss (r = 0.33) is a MILD break — the I1 invariant says
        //   a single mild event cannot drop PSI by more than 30.
        private static void I302_I1_D6_SingleEventBounded()
        {
            Title("I302 [I1] — D6 mild overshoot (r=1/3) ⇒ C6 ≤ 30");
            var cfg = PsiEngineV2Config.Default;
            cfg.MaxDailyLossUsd = 100.0;              // scale_d6loss = 100
            var (eng, bl, _) = NewEngine(cfg: cfg);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            // Realize $133 of losses → overshoot = $33, r = 0.33 → I1 mild.
            EntryFill(eng, t, 1, +1);
            t = t.AddSeconds(30);
            Close(eng, bl, -133, 1, t, false, 30, ExitKind.ProtectiveStop);
            t = t.AddSeconds(5);
            eng.MarkMaxDailyLossBreach(t);
            Snapshot(eng, "I302", "mild MaxDailyLoss overshoot r=1/3");
            AssertLess("I302 C6 ≤ 30 (I1 mild-event bound)",
                eng.DebtD6, 30.0,
                "r=1/3 saturating: target ΔE = 60·(1−e⁻¹ᐟ³) ≈ 17 → C6 ≈ 24");
        }

        // I303 — I3: Moderate severity (s = scale) produces C_i ∈ [40, 55].
        //        D3 with SizeMax = 3, excess = 3 (size 6, "doubled limit").
        private static void I303_I3_D3_ModerateSeverityCritical()
        {
            Title("I303 [I3] — D3 moderate severity (excess = scale) ⇒ C3 ∈ [40, 55]");
            var (eng, bl, prof) = NewEngine(sizeMax: 3.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 6, +1);   // excess = 3, scale = 3, r = 1.0
            Snapshot(eng, "I303", "moderate oversize size 6 / SizeMax 3 (r=1)");
            AssertBetween("I303 C3 ∈ [40, 55] (I3 target band)",
                eng.DebtD3, 40.0, 55.0,
                "r=1 saturating: targetE = 60·(1−e⁻¹) = 37.9 → C3 = (1−e⁻ᵉ³⁷ˑ⁹⁄⁶⁰)·100 ≈ 47");
        }

        // I304 [I3] — D6 MaxDailyLoss at MODERATE overshoot (r = 1) ⇒
        //   C6 ∈ [40, 55].  Doubling the declared MaxDailyLoss (overshoot =
        //   MaxDailyLossUsd) is the canonical "moderate" commitment break.
        private static void I304_I3_D6_ModerateSingleEventCritical()
        {
            Title("I304 [I3] — D6 moderate overshoot (r=1) ⇒ C6 ∈ [40, 55]");
            var cfg = PsiEngineV2Config.Default;
            cfg.MaxDailyLossUsd = 100.0;
            var (eng, bl, _) = NewEngine(cfg: cfg);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            // Realize $200 loss → overshoot = $100, r = 1.0 → I3 moderate.
            EntryFill(eng, t, 1, +1);
            t = t.AddSeconds(30);
            Close(eng, bl, -200, 1, t, false, 30, ExitKind.ProtectiveStop);
            t = t.AddSeconds(5);
            double psiBefore = eng.CurrentPsi;
            eng.MarkMaxDailyLossBreach(t);
            double drop = psiBefore - eng.CurrentPsi;
            Snapshot(eng, "I304", "moderate MaxDailyLoss overshoot r=1");
            AssertBetween("I304 C6 ∈ [40, 55] (I3 moderate-critical band)",
                eng.DebtD6, 40.0, 55.0,
                "r=1 saturating: target ΔE = 60·(1−e⁻¹) ≈ 37.9 → C6 ≈ 47");
            AssertGreater("I304 PSI drop ≥ 30 (meaningful single-event impact)",
                drop, 30.0,
                "a moderate MaxDailyLoss break must register clearly");
        }

        // I305 — I4: Extreme severity (s = 5·scale) ⇒ C_i ≤ 70.
        //        D3 with SizeMax = 3, excess = 15 (size 18).
        private static void I305_I4_D3_ExtremeSeveritySaturates()
        {
            Title("I305 [I4] — D3 extreme severity (excess = 5·scale) ⇒ C3 ≤ 70");
            var (eng, bl, prof) = NewEngine(sizeMax: 3.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 18, +1);   // excess = 15, scale = 3, r = 5.0
            Snapshot(eng, "I305", "extreme oversize r=5");
            AssertLess("I305 C3 ≤ 70 (I4 saturation)",
                eng.DebtD3, 70.0,
                "saturating formula caps at CommitA=60 → C3 ≤ (1−e⁻¹)·100 = 63.2");
            AssertGreater("I305 C3 > 55", eng.DebtD3, 55.0,
                "extreme break still registers near-saturation");
        }

        // I306 — I4: at s = 10·scale, C_i must be no more than 5 above
        //        C_i(s = 5·scale).  Demonstrates saturation (diminishing).
        private static void I306_I4_D3_ExtremeDoesNotTotalCollapse()
        {
            Title("I306 [I4] — D3 saturation: C3(10·scale) − C3(5·scale) ≤ 5");
            var (engA, _, _) = NewEngine(sizeMax: 3.0);
            var (engB, _, _) = NewEngine(sizeMax: 3.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(engA, t, 18, +1);   // r = 5
            EntryFill(engB, t, 33, +1);   // r = 10
            Snapshot(engA, "I306a", "r=5");
            Snapshot(engB, "I306b", "r=10");
            double delta = engB.DebtD3 - engA.DebtD3;
            AssertLess("I306 ΔC3(5·→10·) ≤ 5", delta, 5.0,
                "severity saturation means further extremes add ≤ 5 pts");
            AssertGreater("I306 C3(10·scale) ≥ C3(5·scale)", delta, -0.01,
                "must still be monotone non-decreasing in severity");
        }

        // I307 — I5: at t = 30 min (1800 s) under P=0, E retains ≥ 40% of peak.
        //        τ_decay_3 = 2000 s → exp(-1800/2000) ≈ 0.41.
        //
        // Protocol (first-principles, see ARCHITECTURE.md §15.11 I5):
        //   I5 measures post-episode recovery.  An "episode" ends when the
        //   trader returns to compliance (flattens / within SizeMax).
        //   Peak E = Class A deposit + Class B persistence integral over the
        //   duration the episode was held.  The test MUST close the episode
        //   and capture peak BEFORE starting the idle measurement, otherwise
        //   the peak is an under-count (Class B persistence fires on the
        //   first empty-positions poll after entry and would be attributed
        //   to the "idle" phase rather than the "episode" phase).
        private static void I307_I5_D3_RecoveryAt30Min()
        {
            Title("I307 [I5] — D3 at t=30 min: E retains ≥ 40 % (cortisol regime)");
            var (eng, bl, prof) = NewEngine(sizeMax: 3.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 6, +1);
            t = t.AddSeconds(30);
            // Close the oversize episode — this lets Class B persistence
            // accrue during the hold phase (not the idle phase) and gives
            // a stable peak to measure recovery from.
            Close(eng, bl, -60, 6, t, isWin: false, holdSec: 30,
                  exitKind: ExitKind.Manual);
            double e0 = eng.EvidenceD3;
            AssertGreater("I307 E0 > 0", e0, 0.1, "D3 commit must seed evidence");

            for (int i = 1; i <= 60; i++)
            {
                t = t.AddSeconds(30);
                bool _naked;
                eng.PollPositions(new List<PositionSnapshot>(), t, out _naked);
            }
            Snapshot(eng, "I307", "after 30 min flat idle");
            AssertGreater("I307 E3(30 min) ≥ 0.40·E0", eng.EvidenceD3, e0 * 0.40,
                "I5 lower bound at t=30 min");
            AssertLess("I307 E3(30 min) ≤ 0.50·E0", eng.EvidenceD3, e0 * 0.50,
                "decay must have started by t=30 min");
        }

        // I308 — I5: at t = 120 min (7200 s) under P=0, E ≤ 5% of peak.
        private static void I308_I5_D3_RecoveryAt120Min()
        {
            Title("I308 [I5] — D3 at t=120 min: E ≤ 5 % (near full recovery)");
            var (eng, bl, prof) = NewEngine(sizeMax: 3.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng, t, 6, +1);
            t = t.AddSeconds(30);
            Close(eng, bl, -60, 6, t, isWin: false, holdSec: 30,
                  exitKind: ExitKind.Manual);
            double e0 = eng.EvidenceD3;
            for (int i = 1; i <= 240; i++)    // 240 × 30 s = 120 min
            {
                t = t.AddSeconds(30);
                bool _naked;
                eng.PollPositions(new List<PositionSnapshot>(), t, out _naked);
            }
            Snapshot(eng, "I308", "after 120 min flat idle");
            AssertLess("I308 E3(120 min) ≤ 0.05·E0", eng.EvidenceD3, e0 * 0.05,
                "I5 upper bound at t=120 min → near-full psychological recovery");
        }

        // I309 — I6 Personalization: two profiles breaching their own SizeMax
        //        by the same relative amount (r = s/scale = 1) produce the
        //        same C_3 within 2 pts.
        private static void I309_I6_D3_PersonalizationRelativeSeverity()
        {
            Title("I309 [I6] — Two traders at r=1 breach get the same C3");
            var (engSmall, _, _) = NewEngine(sizeMax: 3.0);
            var (engLarge, _, _) = NewEngine(sizeMax: 10.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(engSmall, t, 6, +1);     // excess=3, scale=3, r=1
            EntryFill(engLarge, t, 20, +1);    // excess=10, scale=10, r=1
            Snapshot(engSmall, "I309a", "SizeMax=3, size=6, r=1");
            Snapshot(engLarge, "I309b", "SizeMax=10, size=20, r=1");
            double diff = Math.Abs(engSmall.DebtD3 - engLarge.DebtD3);
            AssertLess("I309 |C3_small − C3_large| ≤ 2",
                diff, 2.0,
                "Axiom 8: personalisation maps absolute severity to relative, r=1 everywhere");
        }

        // I310 — Anti-pattern 10: 3 partial fills of the SAME orderId count
        //        as ONE entry decision.  Entry count increments once.
        private static void I310_D7_PartialFillsCountAsOneDecision()
        {
            Title("I310 [Anti-10] — 3 partial fills of same Order ⇒ 1 entry counted");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            // Same lifecycle ADD fires once (one entry decision),
            // then 3 partial fills update continuous-state only.
            eng.OnLifecycleAdd(t);
            for (int i = 1; i <= 3; i++)
            {
                eng.ProcessExecution(
                    pnl: 0, size: 1, fillTime: t.AddSeconds(i),
                    isWin: false, holdSeconds: 0,
                    postFillPositions: Snaps(i),
                    fillDirection: +1,
                    exitKind: ExitKind.Unknown,
                    isRoundTripFinal: false,
                    roundTripPnl: 0);
            }
            int entries = eng.BuildSessionSummary().Contains("entries=1") ? 1 : 99;
            Snapshot(eng, "I310", "3 partials, same orderId");
            AssertTrue("I310 entries==1",
                eng.BuildSessionSummary().Contains("entries=1"),
                "partial fills of one decision must not inflate _sessionEntryCount");
        }

        // I311 — Three DIFFERENT orders → 3 entries counted.
        private static void I311_D7_SeparateOrdersCountSeparately()
        {
            Title("I311 [Anti-10] — 3 separate Orders ⇒ 3 entries counted");
            var (eng, bl, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            for (int i = 1; i <= 3; i++)
            {
                // Each iteration is a separate position open → separate entry decision.
                eng.OnLifecycleAdd(t.AddSeconds(i * 60));
                eng.ProcessExecution(
                    pnl: 0, size: 1, fillTime: t.AddSeconds(i * 60),
                    isWin: false, holdSeconds: 0,
                    postFillPositions: Snaps(1),
                    fillDirection: +1,
                    exitKind: ExitKind.Unknown,
                    isRoundTripFinal: false,
                    roundTripPnl: 0);
                eng.ProcessExecution(
                    pnl: 0, size: 1, fillTime: t.AddSeconds(i * 60 + 30),
                    isWin: true, holdSeconds: 30,
                    postFillPositions: new List<PositionSnapshot>(),
                    fillDirection: -1,
                    exitKind: ExitKind.Manual,
                    isRoundTripFinal: true,
                    roundTripPnl: 10);
            }
            Snapshot(eng, "I311", "3 distinct orders");
            AssertTrue("I311 entries==3",
                eng.BuildSessionSummary().Contains("entries=3"),
                "distinct order decisions must each count");
        }

        // I312 — D3 saturation under partial fills: three step-ups (3→4→5→6)
        //        under a single order (same orderId, SAME fillTime) must
        //        deposit the SAME Class A evidence as one single-shot entry
        //        to size 6.
        //
        // Protocol (first-principles, see ARCHITECTURE.md §15.10 Axiom 6):
        //   Axiom 6 is about Class A telescoping: sum of marginal Class A
        //   commits over a step-up sequence equals the single-shot commit.
        //   Class B persistence is a separate time-integrated signal
        //   (Axiom 3) and is NOT part of Axiom 6.  For the Class A
        //   invariant to be observable in the E3 total, the step-ups must
        //   happen at the SAME fillTime (dt=0 between partials), which
        //   matches the physical reality of a broker reporting partial
        //   fills for a single order within one tick — the Class B
        //   persistence integral has zero width because the partials are
        //   simultaneous from the engine's clock's perspective.
        private static void I312_D3_PartialFillsSumToSaturatingWhole()
        {
            Title("I312 [Axiom 6] — D3 partials sum to saturating whole");
            var (engA, _, _) = NewEngine(sizeMax: 3.0);
            var (engB, _, _) = NewEngine(sizeMax: 3.0);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            var fillT = t.AddSeconds(1);

            // Engine A: partial fills 4, 5, 6 all reported at fillT
            // (simultaneous partials for one order — zero Class B time
            // accrual between them by construction).
            engA.OnLifecycleAdd(fillT);
            for (int q = 4; q <= 6; q++)
            {
                engA.ProcessExecution(
                    pnl: 0, size: 1, fillTime: fillT,
                    isWin: false, holdSeconds: 0,
                    postFillPositions: Snaps(q),
                    fillDirection: +1,
                    exitKind: ExitKind.Unknown,
                    isRoundTripFinal: false,
                    roundTripPnl: 0);
            }
            // Engine B: single fill size 6 at the same fillTime
            engB.OnLifecycleAdd(fillT);
            engB.ProcessExecution(
                pnl: 0, size: 6, fillTime: fillT,
                isWin: false, holdSeconds: 0,
                postFillPositions: Snaps(6),
                fillDirection: +1,
                exitKind: ExitKind.Unknown,
                isRoundTripFinal: false,
                roundTripPnl: 0);

            Snapshot(engA, "I312a", "3 simultaneous partials → size 6");
            Snapshot(engB, "I312b", "single-shot size 6");
            double delta = Math.Abs(engA.EvidenceD3 - engB.EvidenceD3);
            AssertLess("I312 |E3_partial − E3_single| ≤ 0.2",
                delta, 0.2,
                "Class A telescoping: Σ marginals(qᵢ) = single-shot(q_final)");
        }

        // =====================================================================
        // TIER 8b — D5 OVERSTAY REDESIGN (I313–I315)
        //
        // Covers the 2026-04-23 D5 rewrite (ARCHITECTURE.md §15.14).  Each of
        // these locks down a property whose violation in the prior design
        // produced the live-session "PSI 100 → 37 on a 91-second hold"
        // incident.  They are NOT optional — they're the regression guard
        // against re-introducing any of the three root causes.
        // =====================================================================

        // I313 — D5 P&L-direct-read neutrality.  Two identical overstay
        //        scenarios where the only difference is the position's
        //        CURRENT `UnrealizedPnl` (one up $200, one down $200) while
        //        holding `MinUnrealizedPnl` equal (both 0).  Because
        //        MinUnrealizedPnl drives Pressure (Axiom 4), keeping it
        //        equal isolates the question this test actually asks: does
        //        D5 read P&L as a DIRECT deduction signal?
        //
        //        Pre-redesign, D5 Class B had `weight = −MinUnrealizedPnl /
        //        (2×|μLoss|)` so even two traders with equal P would produce
        //        different D5 outputs if their open losers differed.  Post-
        //        redesign, D5 reads ONLY `overstaySec` and `scale_D5` — so
        //        the two engines must produce identical evidence.
        private static void I313_D5_PnlDirectReadNeutrality()
        {
            Title("I313 [Axiom 1 / discipline-over-outcome] — D5 does not read P&L as a direct signal");
            var (engWin,  _, _) = NewEngine(maxHoldMinutes: 5);
            var (engLose, _, _) = NewEngine(maxHoldMinutes: 5);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);

            EntryFill(engWin,  t, 1, +1);
            EntryFill(engLose, t, 1, +1);

            bool _naked;
            // Hold 10 min (2× declared max → r = 1.0).  Both engines see P=0
            // throughout (MinUnrealizedPnl = 0 on both) — only the spot
            // UnrealizedPnl differs, which the engine MUST NOT read.
            for (int m = 1; m <= 10; m++)
            {
                t = t.AddMinutes(1);
                engWin.PollPositions(new List<PositionSnapshot> {
                    new PositionSnapshot { Key = "TEST::INSTR", Quantity = 1,
                        HasStopOrder = true, HoldSeconds = 60 * m,
                        MinUnrealizedPnl = 0, UnrealizedPnl = +200 } }, t, out _naked);
                engLose.PollPositions(new List<PositionSnapshot> {
                    new PositionSnapshot { Key = "TEST::INSTR", Quantity = 1,
                        HasStopOrder = true, HoldSeconds = 60 * m,
                        MinUnrealizedPnl = 0, UnrealizedPnl = -200 } }, t, out _naked);
            }

            Snapshot(engWin,  "I313a", "10-min winning open (UnrlPnl +200, MinUnrl 0)");
            Snapshot(engLose, "I313b", "10-min losing open  (UnrlPnl −200, MinUnrl 0)");

            double delta = Math.Abs(engWin.EvidenceD5 - engLose.EvidenceD5);
            AssertLess("I313 |E5_win − E5_loss| ≤ 0.01 (bit-identical when P equal)",
                delta, 0.01,
                "D5 reads only (HoldSec, MaxHoldSec); same process & same P ⇒ identical D5");
            AssertGreater("I313 both holds registered D5",
                Math.Min(engWin.EvidenceD5, engLose.EvidenceD5), 1.0,
                "holding 2× declared max must fire D5 regardless of outcome");
        }

        // I314 — D5 saturating-marginal Class A, isolated from Class B.
        //
        //   Class A evidence = CommitA_D5 · (1 − e^(−overstaySec / scale_D5))
        //     Mild  (r = 1/3):  60·(1−e^(−1/3)) ≈ 17.0  →  C5 ≈ 24.7
        //     Mod   (r = 1.0):  60·(1−e^(−1.0)) ≈ 37.9  →  C5 ≈ 46.9
        //     Extr  (r = 5.0):  60·(1−e^(−5.0)) ≈ 59.6  →  C5 ≈ 63.1
        //     Extr2 (r = 10):   60·(1−e^(−10))  ≈ 59.997 → C5 ≈ 63.2 (Δ ≤ 0.1)
        //
        //   To isolate Class A from the persistence integral, each test seeds
        //   `_prevWorstOverstaySec = 0` via a "just-under-limit" poll, then
        //   jumps to the target overstay with a TINY dt (0.1 s) so the Class
        //   B persistence integral contributes < 0.01 evidence.  This is a
        //   physical scenario — the MaxHold boundary gets crossed on a tick
        //   where the next engine poll is essentially immediate.
        private static void I314_D5_SaturatingClassA_Invariants()
        {
            Title("I314 [Axiom 6, I1∩I3∩I4] — D5 saturating-marginal Class A invariants (Class B isolated)");

            // Helper scenario: seed → jump → read.
            Action<double, string, Action<PsiEngineV2>> scenario =
                (rRelative, tag, assertions) =>
            {
                var (eng, _, _) = NewEngine(maxHoldMinutes: 5);     // scale = 300 s
                var t = new DateTime(2026, 4, 23, 10, 0, 0);
                EntryFill(eng, t, 1, +1);

                bool _n;
                // (1) Seed: HoldSec = 299 → overstay = 0 → _prevWorstOverstaySec stays 0.
                t = t.AddSeconds(299);
                eng.PollPositions(new List<PositionSnapshot> {
                    new PositionSnapshot { Key = "TEST::INSTR", Quantity = 1,
                        HasStopOrder = true, HoldSeconds = 299,
                        MinUnrealizedPnl = 0 } }, t, out _n);

                // (2) Jump: tiny dt (0.1 s) carries snapshot from overstay=0
                //     to overstay = r·scale.  Class B ≈ CommitB(0.05)·r·0.1 ≤ 0.025
                //     even at r = 5 — negligible versus Class A's 37.9 – 59.6.
                double overstay = rRelative * 300.0;
                t = t.AddSeconds(0.1);
                eng.PollPositions(new List<PositionSnapshot> {
                    new PositionSnapshot { Key = "TEST::INSTR", Quantity = 1,
                        HasStopOrder = true, HoldSeconds = 300 + overstay,
                        MinUnrealizedPnl = 0 } }, t, out _n);

                Snapshot(eng, tag, string.Format("D5 Class A isolated r={0:0.##}", rRelative));
                assertions(eng);
            };

            // I1 mild (r = 1/3): C5 ≤ 30.
            scenario(1.0 / 3.0, "I314a", eng =>
                AssertLess("I314 I1: D5 C5 ≤ 30 at r=1/3 (single marginal)",
                    eng.DebtD5, 30.0,
                    "mild overstay must not cross critical threshold on single commit"));

            // I3 moderate (r = 1.0, doubled declared max): C5 ∈ [40, 55].
            scenario(1.0, "I314b", eng =>
                AssertBetween("I314 I3: D5 C5 ∈ [40, 55] at r=1.0",
                    eng.DebtD5, 40.0, 55.0,
                    "doubling declared max is the 'moderate critical' anchor per I3"));

            // I4a extreme (r = 5): C5 ≤ 70, no total collapse.
            PsiEngineV2 engExt5 = null;
            scenario(5.0, "I314c", eng => {
                engExt5 = eng;
                AssertLess("I314 I4: D5 C5 ≤ 70 at r=5 (single marginal saturates)",
                    eng.DebtD5, 70.0,
                    "saturating formula caps single-event contribution at CommitA=60");
            });

            // I4b second-order (r = 10): further severity barely moves C5.
            PsiEngineV2 engExt10 = null;
            scenario(10.0, "I314d", eng => { engExt10 = eng; });
            double deltaR5to10 = engExt10.DebtD5 - engExt5.DebtD5;
            AssertLess("I314 I4: D5 C5(r=10) − C5(r=5) ≤ 2",
                deltaR5to10, 2.0,
                "saturation: extreme → more-extreme adds near-zero Class A");
        }

        // I315 — D5 time-domain independence (Landmine 10 regression guard).
        //        Simulates the exact production bug: MeridianPSI fills
        //        `_positionEntryTimes[key]` at fill.Time (replay-domain), then
        //        a later `PollPositions` gets a wall-clock `engineTime` off by
        //        days.  Pre-fix, the engine would see HoldSeconds ≈ 8 days
        //        and instantly trigger D5 Class A.
        //
        //        Post-fix, the engine trusts the HoldSeconds field on the
        //        passed-in PositionSnapshot (which MeridianPSI now computes
        //        correctly using `_clock.PollTime`).  The engine MUST NOT
        //        recompute HoldSeconds from its own time state.
        //
        //        This test proves: two engines fed the SAME snapshot (same
        //        HoldSeconds) at two WILDLY different `engineTime` values
        //        produce the same D5 output.
        private static void I315_D5_TimeDomainIndependence()
        {
            Title("I315 [Landmine 10] — D5 output depends only on HoldSeconds, not engineTime magnitude");
            var (engA, _, _) = NewEngine(maxHoldMinutes: 5);
            var (engB, _, _) = NewEngine(maxHoldMinutes: 5);
            var tA = new DateTime(2026, 4, 23, 10, 0, 0);
            var tB = new DateTime(2026, 4, 23, 10, 0, 0);

            EntryFill(engA, tA, 1, +1);
            EntryFill(engB, tB, 1, +1);

            // Both engines get IDENTICAL HoldSeconds (600 s — 10 min on a
            // 5-min declared max) at IDENTICAL engineTime — control case.
            bool _n;
            var snap = new List<PositionSnapshot> {
                new PositionSnapshot { Key = "TEST::INSTR", Quantity = 1,
                    HasStopOrder = true, HoldSeconds = 600,
                    MinUnrealizedPnl = 0 } };
            tA = tA.AddSeconds(600);
            tB = tB.AddSeconds(600);
            engA.PollPositions(snap, tA, out _n);
            engB.PollPositions(snap, tB, out _n);

            Snapshot(engA, "I315a", "ref engine after 10-min hold");
            Snapshot(engB, "I315b", "ref engine after 10-min hold (identical inputs)");
            AssertLess("I315 identical inputs produce identical D5",
                Math.Abs(engA.EvidenceD5 - engB.EvidenceD5), 0.01,
                "determinism baseline");

            // Now prove the engine does NOT read a private wall-clock: advance
            // engA's engineTime by 8 days of pure idle (no new snapshot), and
            // engB's by 0 seconds.  engA's E5 should DECAY (Axiom 2) but MUST
            // NOT spontaneously jump up — the trader never took another action.
            double e5Before = engA.EvidenceD5;
            engA.PollPositions(new List<PositionSnapshot>(), tA.AddDays(8), out _n);
            Snapshot(engA, "I315c", "8-day idle after flat");
            AssertLess("I315 8-day idle does not INCREASE D5",
                engA.EvidenceD5, e5Before + 0.01,
                "wall-clock mismatch cannot spontaneously deposit Class A — " +
                "Landmine 10 regression would violate this by ~37 PSI pts");
        }

        // ─────────────────────────────────────────────────────────────────
        // TIER 8c — Invariant coverage for the D2/D6/D7 saturating-marginal
        //           redesign (2026-04-23).  These fill the same invariant-
        //           contract roles (I1, I3, I4, I6) that I301–I309 cover for
        //           D3, now anchored on dimensions whose scales are derived
        //           from user-declared `StrategyProfile` parameters rather
        //           than any magic multiplier.
        // ─────────────────────────────────────────────────────────────────

        // I316 [I4] — D6 MaxDailyLoss at EXTREME overshoot (r = 5) ⇒ C6 ≤ 70.
        //   Proves saturating Class A — overshooting the declared daily-loss
        //   by 5× does NOT produce 5× the evidence; the function asymptotes
        //   at CommitA_D6 = 60, so C6 → 100·(1 − e⁻¹) ≈ 63.
        private static void I316_I4_D6_ExtremeOvershootSaturates()
        {
            Title("I316 [I4] — D6 extreme overshoot (r=5) ⇒ C6 ≤ 70");
            var cfg = PsiEngineV2Config.Default;
            cfg.MaxDailyLossUsd = 100.0;
            var (eng, bl, _) = NewEngine(cfg: cfg);
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            // Realize $600 loss → overshoot = $500, r = 5.0 → I4 extreme.
            EntryFill(eng, t, 1, +1);
            t = t.AddSeconds(30);
            Close(eng, bl, -600, 1, t, false, 30, ExitKind.ProtectiveStop);
            t = t.AddSeconds(5);
            eng.MarkMaxDailyLossBreach(t);
            Snapshot(eng, "I316", "extreme overshoot r=5");
            AssertLess("I316 C6 ≤ 70 (saturating, not total collapse)",
                eng.DebtD6, 70.0,
                "r=5 saturating: target ΔE = 60·(1−e⁻⁵) ≈ 59.6 → C6 ≈ 63");
            // Sanity: a 10× overshoot shouldn't move C6 materially further.
            var (eng2, bl2, _) = NewEngine(cfg: cfg);
            var t2 = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(eng2, t2, 1, +1);
            t2 = t2.AddSeconds(30);
            Close(eng2, bl2, -1100, 1, t2, false, 30, ExitKind.ProtectiveStop);
            t2 = t2.AddSeconds(5);
            eng2.MarkMaxDailyLossBreach(t2);
            AssertLess("I316 C6(r=10) − C6(r=5) ≤ 5 (asymptotic)",
                eng2.DebtD6 - eng.DebtD6, 5.0,
                "further severity beyond r=5 produces vanishing additional evidence");
        }

        // I317 [I6] — D6 personalization: two traders with different
        //   declared MaxDailyLossUsd but the SAME relative overshoot (r)
        //   must produce the SAME C6.  Scale = MaxDailyLossUsd makes
        //   severity user-relative (Axiom 8).
        private static void I317_I6_D6_PersonalizationRelativeSeverity()
        {
            Title("I317 [I6] — D6 personalization: equal r ⇒ equal C6");
            // Trader A: small declared limit.
            var cfgA = PsiEngineV2Config.Default;
            cfgA.MaxDailyLossUsd = 100.0;
            var (engA, blA, _) = NewEngine(cfg: cfgA);
            var tA = new DateTime(2026, 4, 23, 10, 0, 0);
            // Overshoot = $100 (r = 1.0).
            EntryFill(engA, tA, 1, +1);
            tA = tA.AddSeconds(30);
            Close(engA, blA, -200, 1, tA, false, 30, ExitKind.ProtectiveStop);
            tA = tA.AddSeconds(5);
            engA.MarkMaxDailyLossBreach(tA);

            // Trader B: 10× declared limit, 10× overshoot ⇒ same r.
            var cfgB = PsiEngineV2Config.Default;
            cfgB.MaxDailyLossUsd = 1000.0;
            var (engB, blB, _) = NewEngine(cfg: cfgB);
            var tB = new DateTime(2026, 4, 23, 10, 0, 0);
            EntryFill(engB, tB, 1, +1);
            tB = tB.AddSeconds(30);
            Close(engB, blB, -2000, 1, tB, false, 30, ExitKind.ProtectiveStop);
            tB = tB.AddSeconds(5);
            engB.MarkMaxDailyLossBreach(tB);

            Snapshot(engA, "I317A", "MaxDailyLoss=$100, overshoot=$100 (r=1)");
            Snapshot(engB, "I317B", "MaxDailyLoss=$1000, overshoot=$1000 (r=1)");
            AssertTrue("I317 C6(A) ≈ C6(B) for equal r",
                Math.Abs(engA.DebtD6 - engB.DebtD6) < 1.0,
                "severity is profile-relative, not absolute-dollar");
        }

        // I318 [I1] — D2 naked exposure at MILD pastGrace (r = 1/3) ⇒ C2 ≤ 30.
        //   scale_D2 = NoStopGraceSeconds (default 20 s).  pastGrace ≈ 6.7 s.
        //   Mild break = "slightly forgot to attach SL" in trader terms.
        private static void I318_I1_D2_MildPastGraceBounded()
        {
            Title("I318 [I1] — D2 mild naked pastGrace (r=1/3) ⇒ C2 ≤ 30");
            var (eng, _, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            int grace = Math.Max(1, prof.NoStopGraceSeconds);
            EntryFill(eng, t, 1, +1);
            bool _n;
            // Poll naked positions until pastGrace = scale/3 elapsed.
            int targetSec = grace + grace / 3;    // pastGrace = grace/3
            for (int i = 0; i <= targetSec; i++)
            {
                t = t.AddSeconds(1);
                eng.PollPositions(Snaps(1, hasStop: false), t, out _n);
            }
            Snapshot(eng, "I318", "naked r=1/3 past grace");
            AssertLess("I318 C2 ≤ 30 (I1 mild-event bound)",
                eng.DebtD2, 30.0,
                "r=1/3 saturating: target ΔE = 60·(1−e⁻¹ᐟ³) ≈ 17 → C2 ≈ 24");
        }

        // I319 [I3] — D2 naked at MODERATE pastGrace (r = 1) ⇒ C2 ∈ [40, 55].
        //   pastGrace = scale = NoStopGraceSeconds: "still naked one full
        //   grace-window past the declared tolerance."
        private static void I319_I3_D2_ModeratePastGraceCritical()
        {
            Title("I319 [I3] — D2 moderate naked pastGrace (r=1) ⇒ C2 ∈ [40, 55]");
            var (eng, _, prof) = NewEngine();
            var t = new DateTime(2026, 4, 23, 10, 0, 0);
            int grace = Math.Max(1, prof.NoStopGraceSeconds);
            EntryFill(eng, t, 1, +1);
            bool _n;
            // pastGrace = grace (r=1): total naked duration = 2·grace.
            int targetSec = 2 * grace;
            for (int i = 0; i <= targetSec; i++)
            {
                t = t.AddSeconds(1);
                eng.PollPositions(Snaps(1, hasStop: false), t, out _n);
            }
            Snapshot(eng, "I319", "naked r=1 past grace");
            AssertBetween("I319 C2 ∈ [35, 55] (I3 moderate-critical band)",
                eng.DebtD2, 35.0, 55.0,
                "r=1 Class A saturating + small Class B persistence " +
                "contribution during the past-grace interval");
        }

        // I320 [I6] — D7 personalization: two traders with different
        //   declared TradesPerSessionMax but the SAME relative excess (r)
        //   must produce the SAME C7.  Scale = TradesPerSessionMax makes
        //   severity profile-relative (Axiom 8).
        private static void I320_I6_D7_PersonalizationRelativeSeverity()
        {
            Title("I320 [I6] — D7 personalization: equal r ⇒ equal C7");
            // Trader A: tight budget (3 trades), takes 6 → excess=3, r=1.
            var profA = new StrategyProfile {
                SizeMin = 1, SizeMax = 2, SlTicksMax = 20,
                MaxReentrySeconds = 180, MaxHoldMinutes = 30,
                NoStopGraceSeconds = 20,
                TradesPerSessionMin = 1, TradesPerSessionMax = 3,
                SessionStartHour = 9, SessionStartMinute = 30,
                SessionEndHour = 16, SessionEndMinute = 0,
                Sensitivity = PsiSensitivity.Balanced,
            };
            var blA = new TradeBaseline();
            var engA = new PsiEngineV2(profA, blA);
            engA.StartNewSession(100.0);
            var tA = new DateTime(2026, 4, 23, 10, 0, 0);
            for (int i = 0; i < 6; i++)
            {
                EntryFill(engA, tA, 1, +1);
                tA = tA.AddSeconds(30);
                Close(engA, blA, -20, 1, tA, false, 30, ExitKind.Manual);
                tA = tA.AddSeconds(60);
            }
            double c7A = engA.DebtD7;

            // Trader B: loose budget (10 trades), takes 20 → excess=10, r=1.
            var profB = new StrategyProfile {
                SizeMin = 1, SizeMax = 2, SlTicksMax = 20,
                MaxReentrySeconds = 180, MaxHoldMinutes = 30,
                NoStopGraceSeconds = 20,
                TradesPerSessionMin = 1, TradesPerSessionMax = 10,
                SessionStartHour = 9, SessionStartMinute = 30,
                SessionEndHour = 16, SessionEndMinute = 0,
                Sensitivity = PsiSensitivity.Balanced,
            };
            var blB = new TradeBaseline();
            var engB = new PsiEngineV2(profB, blB);
            engB.StartNewSession(100.0);
            var tB = new DateTime(2026, 4, 23, 10, 0, 0);
            for (int i = 0; i < 20; i++)
            {
                EntryFill(engB, tB, 1, +1);
                tB = tB.AddSeconds(30);
                Close(engB, blB, -20, 1, tB, false, 30, ExitKind.Manual);
                tB = tB.AddSeconds(60);
            }
            double c7B = engB.DebtD7;

            Snapshot(engA, "I320A", "Trader A: 6 trades / Max 3 (r=1)");
            Snapshot(engB, "I320B", "Trader B: 20 trades / Max 10 (r=1)");
            // Tolerance is wider than D6 because Class B trade-pace signal
            // also contributes via the re-entry gap, and that depends on
            // absolute time between fills (same in both here by construction).
            AssertTrue("I320 C7(A) ≈ C7(B) for equal r (within 2 pts)",
                Math.Abs(c7A - c7B) < 3.0,
                "user-declared TradesPerSessionMax scales D7 severity — " +
                "tripping your own stated budget is the same psychological " +
                "event regardless of the budget's absolute number");
        }

        private static void Idle(PsiEngineV2 eng, ref DateTime t,
                                  double totalSeconds, double stepSeconds = 30.0)
        {
            bool _naked;
            int steps = (int)Math.Ceiling(totalSeconds / stepSeconds);
            for (int i = 0; i < steps; i++)
            {
                t = t.AddSeconds(stepSeconds);
                eng.PollPositions(new List<PositionSnapshot>(), t, out _naked);
            }
        }

        private static (PsiEngineV2 eng, TradeBaseline bl, StrategyProfile prof)
            NewEngine(double sizeMax = 2.0,
                      int sessionEndHour = 12,
                      PsiEngineV2Config cfg = null,
                      int maxHoldMinutes = 30)
        {
            var prof = new StrategyProfile
            {
                SizeMin               = 1.0,
                SizeMax               = sizeMax,
                SlTicksMax            = 20,
                MaxReentrySeconds     = 180,
                MaxHoldMinutes        = maxHoldMinutes,
                NoStopLossTrader      = false,
                NoStopGraceSeconds    = 20,
                TradesPerSessionMin   = 3,
                TradesPerSessionMax   = 15,
                SessionStartHour      = 9,
                SessionStartMinute    = 30,
                SessionEndHour        = sessionEndHour,
                SessionEndMinute      = 0,
                Sensitivity           = PsiSensitivity.Balanced,
            };
            var bl  = new TradeBaseline();
            var eng = new PsiEngineV2(prof, bl, cfg);
            eng.StartNewSession(100.0);
            return (eng, bl, prof);
        }

        private static List<PositionSnapshot> Snaps(double netPosition,
                                                    bool hasStop = true,
                                                    double holdSeconds = 0)
        {
            var list = new List<PositionSnapshot>();
            if (netPosition > 0)
                list.Add(new PositionSnapshot
                {
                    Key          = "TEST::INSTR",
                    Quantity     = netPosition,
                    HasStopOrder = hasStop,
                    HoldSeconds  = holdSeconds,
                });
            return list;
        }

        private static double EntryFill(PsiEngineV2 eng, DateTime t,
                                        double size, int fillDir)
        {
            // Mirror production flow: lifecycle ADD fires D1/D6/D7 once,
            // then the fill updates continuous-state (D2/D3/D5).
            eng.OnLifecycleAdd(t);
            return eng.ProcessExecution(
                pnl: 0, size: size, fillTime: t,
                isWin: false, holdSeconds: 0,
                postFillPositions: Snaps(size),
                fillDirection: fillDir,
                exitKind: ExitKind.Unknown,
                isRoundTripFinal: false,
                roundTripPnl: 0);
        }

        private static double Close(PsiEngineV2 eng, TradeBaseline bl,
                                    double pnl, double size, DateTime t,
                                    bool isWin, double holdSec,
                                    ExitKind exitKind)
        {
            bl.UpdateOnExecution(pnl, size, holdSec, isWin);
            return eng.ProcessExecution(
                pnl: pnl, size: size, fillTime: t,
                isWin: isWin, holdSeconds: holdSec,
                postFillPositions: new List<PositionSnapshot>(),
                fillDirection: -1,
                exitKind: exitKind,
                isRoundTripFinal: true,
                roundTripPnl: pnl);
        }

        private static void Snapshot(PsiEngineV2 eng, string scenario, string note)
        {
            _csv.AppendLine(string.Format(
                "{0},{1},{2:F2},{3:F3},{4:F2},{5:F2},{6:F2},{7:F2},{8:F2},{9:F2},{10:F2}," +
                "{11:F3},{12:F3},{13:F3},{14:F3},{15:F3},{16:F3},{17:F3},{18:F2},{19:F2},{20}",
                scenario, "snapshot", eng.CurrentPsi, eng.Pressure,
                eng.DebtD1, eng.DebtD2, eng.DebtD3, eng.DebtD4,
                eng.DebtD5, eng.DebtD6, eng.DebtD7,
                eng.EvidenceD1, eng.EvidenceD2, eng.EvidenceD3,
                eng.EvidenceD4, eng.EvidenceD5, eng.EvidenceD6, eng.EvidenceD7,
                eng.ConsecutiveLosses, eng.SessionNetPnl, note));
            Log(string.Format(
                "  state: PSI={0:F2} P={1:F3} C=[{2:F1},{3:F1},{4:F1},{5:F1},{6:F1},{7:F1},{8:F1}] " +
                "streak={9:F1}",
                eng.CurrentPsi, eng.Pressure,
                eng.DebtD1, eng.DebtD2, eng.DebtD3, eng.DebtD4,
                eng.DebtD5, eng.DebtD6, eng.DebtD7,
                eng.ConsecutiveLosses));
        }

        private static void AssertLess(string tag, double actual, double max,
                                       string extra = "")
        {
            bool pass = actual < max;
            Log(string.Format("  {0} {1}: value={2:F3}  expected < {3}{4}",
                pass ? "[PASS]" : "[FAIL]", tag, actual, max,
                string.IsNullOrEmpty(extra) ? "" : "   # " + extra));
            if (pass) _passed++; else _failed++;
        }

        private static void AssertGreater(string tag, double actual, double min,
                                          string extra = "")
        {
            bool pass = actual > min;
            Log(string.Format("  {0} {1}: value={2:F3}  expected > {3}{4}",
                pass ? "[PASS]" : "[FAIL]", tag, actual, min,
                string.IsNullOrEmpty(extra) ? "" : "   # " + extra));
            if (pass) _passed++; else _failed++;
        }

        private static void AssertBetween(string tag, double actual,
                                          double min, double max,
                                          string extra = "")
        {
            bool pass = actual >= min && actual <= max;
            Log(string.Format("  {0} {1}: value={2:F3}  expected ∈ [{3}, {4}]{5}",
                pass ? "[PASS]" : "[FAIL]", tag, actual, min, max,
                string.IsNullOrEmpty(extra) ? "" : "   # " + extra));
            if (pass) _passed++; else _failed++;
        }

        private static void AssertTrue(string tag, bool condition, string detail = "")
        {
            Log(string.Format("  {0} {1}{2}",
                condition ? "[PASS]" : "[FAIL]", tag,
                string.IsNullOrEmpty(detail) ? "" : "   # " + detail));
            if (condition) _passed++; else _failed++;
        }

        private static void Log(string msg) { _log.AppendLine(msg); }

        private static void Banner(string title)
        {
            Log("");
            Log("=======================================================================");
            Log("  " + title);
            Log("=======================================================================");
        }

        private static void Section(string title)
        {
            Log("");
            Log("── " + title + " " + new string('─', Math.Max(0, 62 - title.Length)));
        }

        private static void Title(string title)
        {
            Log("");
            Log(title);
        }
    }
}
