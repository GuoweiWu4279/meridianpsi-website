﻿// SessionDetailStore.cs
//
// Tier-2 per-session detail storage: PSI timeline + fill log + composure peaks.
//
// Complements the lightweight SessionHistoryEntry (history.xml) with the full
// data needed to reconstruct a SessionReportWindow for any historical session:
//   • PsiHistory  — downsampled to ≤150 points (adequate for chart rendering)
//   • TradeRecord — per-fill D-scores, P&L, hold time (Tilt Cascade, Composure)
//   • Peak EWMA debts for D2/D3/D5 (Composure component bars)
//   • PrevFinalPsi / PrevAlerts (vs Previous Session section)
//
// Storage:
//   TradeMonitorData/sessions/YYYY-MM-DD.xml  (one file per trading day)
//   ~12 KB average per session · ~15 MB for 5 years of daily sessions
//
// Design notes:
//   • XML attributes instead of elements: ~60% smaller than element-style XML
//   • float (32-bit) instead of double for chart/score values: half the size
//   • DateTime stored as long Ticks: avoids ISO-8601 string overhead
//   • Files are written atomically (temp → rename) to survive crashes
//   • Load() never throws — returns null on any failure
//   • Backward-compatible: sessions before this feature was deployed simply
//     have no file; Exists() returns false and the UI degrades gracefully

using System;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================================
    // Data transfer objects (XML-serialisable)
    // =========================================================================

    /// <summary>One downsampled PSI snapshot.</summary>
    public sealed class SdPsiPoint
    {
        /// <summary>DateTime.Ticks of the snapshot timestamp.</summary>
        [XmlAttribute("t")] public long  Ticks { get; set; }
        /// <summary>PSI value at this tick (float precision is sufficient for charts).</summary>
        [XmlAttribute("v")] public float V     { get; set; }
    }

    /// <summary>One execution fill record (mirrors TradeRecord for XML serialisation).</summary>
    public sealed class SdFill
    {
        [XmlAttribute("t")]  public long  Ticks       { get; set; } // DateTime.Ticks
        [XmlAttribute("c")]  public bool  IsClosing   { get; set; }
        [XmlAttribute("w")]  public bool  IsWin       { get; set; }
        [XmlAttribute("p")]  public float Pnl         { get; set; }
        [XmlAttribute("h")]  public float HoldSeconds { get; set; }
        [XmlAttribute("x")]  public float Psi         { get; set; }
        [XmlAttribute("d1")] public float D1          { get; set; }
        [XmlAttribute("d2")] public float D2          { get; set; }
        [XmlAttribute("d3")] public float D3          { get; set; }
        [XmlAttribute("d4")] public float D4          { get; set; }
        [XmlAttribute("d5")] public float D5          { get; set; }
        [XmlAttribute("d6")] public float D6          { get; set; }
        [XmlAttribute("d7")] public float D7          { get; set; }
    }

    /// <summary>
    /// Complete per-session detail record.
    /// Root element kept short ("SD") to minimise XML verbosity.
    /// </summary>
    [XmlRoot("SD")]
    public sealed class SessionDetail
    {
        // ── Comparison values for "vs Previous Session" section ───────────────
        [XmlAttribute("psi")] public double PrevFinalPsi { get; set; }
        [XmlAttribute("alt")] public int    PrevAlerts   { get; set; }

        // ── Peak EWMA debts — required by GetComposureComponents() ───────────
        [XmlAttribute("d2")] public double PeakDebtD2 { get; set; }
        [XmlAttribute("d3")] public double PeakDebtD3 { get; set; }
        [XmlAttribute("d5")] public double PeakDebtD5 { get; set; }
        [XmlAttribute("d6")] public double PeakDebtD6 { get; set; }

        // ── PSI timeline (downsampled) ────────────────────────────────────────
        [XmlArray("H")]
        [XmlArrayItem("P")]
        public List<SdPsiPoint> PsiHistory { get; set; } = new List<SdPsiPoint>();

        // ── Per-fill trade records ────────────────────────────────────────────
        [XmlArray("F")]
        [XmlArrayItem("R")]
        public List<SdFill> Fills { get; set; } = new List<SdFill>();
    }

    // =========================================================================
    // SessionDetailStore — static I/O helper
    // =========================================================================

    internal static class SessionDetailStore
    {
        private const int MaxPsiPoints = 150; // per session, after downsampling

        // Serialises all file I/O (both Save and SaveDetail paths) so that the
        // per-trade background writer and the State.Terminated synchronous writer
        // never open the same .tmp file at the same time.
        // RULE: onError callbacks are NEVER invoked while this lock is held.
        // Calling delegates under a lock is a deadlock invitation if they marshal
        // back to the UI thread (NT8 log helpers often do exactly that).
        private static readonly object _fileIOLock = new object();

        // ── Directory location (co-located with history.xml) ─────────────────
        private static string Dir => Path.Combine(SessionHistoryStore.DataDir, "sessions");

        public static string PathFor(DateTime date) =>
            Path.Combine(Dir, date.ToString("yyyy-MM-dd") + ".xml");

        // ── Public API ───────────────────────────────────────────────────────

        /// <summary>True if a detail file exists for the given calendar date.</summary>
        public static bool Exists(DateTime date)
        {
            try   { return File.Exists(PathFor(date)); }
            catch { return false; }
        }

        /// <summary>
        /// Persists full session detail to disk.
        /// May be called from a thread-pool thread; <see cref="SessionData"/> is read
        /// only through lock-safe snapshot helpers.
        /// Never throws — errors reported via <paramref name="onError"/>.
        /// </summary>
        public static void Save(SessionData data, Action<string> onError = null)
        {
            if (data == null || data.TotalTrades == 0) return;

            string err = null;
            try
            {
                Directory.CreateDirectory(Dir);

                var    detail   = BuildDetail(data);
                string path     = PathFor(data.Date);
                string tempPath = path + ".tmp";
                var    xs       = new XmlSerializer(typeof(SessionDetail));

                // Lock only around the actual file I/O — not around BuildDetail
                // (lock-safe via SessionData accessors) and not around onError
                // (may marshal to the UI thread; calling a delegate under a lock
                // risks deadlock if the UI thread is itself waiting on this lock).
                lock (_fileIOLock)
                {
                    using (var fs = new FileStream(tempPath, FileMode.Create,
                                                   FileAccess.Write, FileShare.None))
                        xs.Serialize(fs, detail);

                    if (File.Exists(path)) File.Delete(path);
                    File.Move(tempPath, path);
                }
            }
            catch (Exception ex)
            {
                err = $"[MeridianPSI] Session detail save failed ({data.Date:yyyy-MM-dd}). " +
                      $"Reason: {ex.Message}";
            }
            // Invoke outside the lock — safe for any threading context.
            if (err != null) onError?.Invoke(err);
        }

        /// <summary>
        /// Loads a session detail file.
        /// Returns null on any failure (missing file, corrupt XML, etc.).
        /// </summary>
        public static SessionDetail Load(DateTime date)
        {
            string path = PathFor(date);
            if (!File.Exists(path)) return null;

            try
            {
                var xs = new XmlSerializer(typeof(SessionDetail));
                using (var fs = new FileStream(path, FileMode.Open,
                                               FileAccess.Read, FileShare.Read))
                    return (SessionDetail)xs.Deserialize(fs);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Writes a pre-built, immutable <see cref="SessionDetail"/> snapshot.
        /// The snapshot must have been constructed by <see cref="BuildSnapshot"/>
        /// on the calling (recording) thread; no live <see cref="SessionData"/>
        /// reference is accessed here.
        /// Safe to call from a thread-pool worker because no shared state is read.
        /// </summary>
        internal static void SaveDetail(DateTime date, SessionDetail detail,
                                        Action<string> onError = null)
        {
            if (detail == null) return;
            if (detail.Fills.Count == 0 && detail.PsiHistory.Count == 0) return;

            string err = null;
            try
            {
                Directory.CreateDirectory(Dir);
                string path     = PathFor(date);
                string tempPath = path + ".tmp";
                var    xs       = new XmlSerializer(typeof(SessionDetail));

                lock (_fileIOLock)
                {
                    using (var fs = new FileStream(tempPath, FileMode.Create,
                                                   FileAccess.Write, FileShare.None))
                        xs.Serialize(fs, detail);

                    if (File.Exists(path)) File.Delete(path);
                    File.Move(tempPath, path);
                }
            }
            catch (Exception ex)
            {
                err = $"[MeridianPSI] Session detail save failed ({date:yyyy-MM-dd}). " +
                      $"Reason: {ex.Message}";
            }
            if (err != null) onError?.Invoke(err);
        }

        /// <summary>
        /// Builds an immutable <see cref="SessionDetail"/> snapshot from a live
        /// <see cref="SessionData"/> by calling only lock-safe accessors.
        /// Must be called on the recording thread so the snapshot captures the
        /// exact state at the moment a trade was committed to memory.
        /// Returns null when there is nothing worth persisting yet.
        /// </summary>
        internal static SessionDetail BuildSnapshot(SessionData data)
        {
            if (data == null) return null;
            return BuildDetail(data);
        }

        // ── Build SessionDetail from live SessionData ─────────────────────────

        private static SessionDetail BuildDetail(SessionData data)
        {
            var detail = new SessionDetail();

            // Composure peaks and comparison values are obtained inside the lock
            // via dedicated accessors that SessionData already exposes.
            data.GetPeakDebts(out double d2, out double d3, out double d5, out double d6);
            detail.PeakDebtD2   = d2;
            detail.PeakDebtD3   = d3;
            detail.PeakDebtD5   = d5;
            detail.PeakDebtD6   = d6;
            detail.PrevFinalPsi = data.PrevFinalPsi;
            detail.PrevAlerts   = data.PrevAlerts;

            // PSI history — take a snapshot of the list, then downsample
            var history = data.GetPsiHistorySnapshot();
            detail.PsiHistory = Downsample(history, MaxPsiPoints);

            // Fills — take a snapshot of the trade list
            var trades = data.GetTradesSnapshot();
            foreach (var t in trades)
            {
                detail.Fills.Add(new SdFill
                {
                    Ticks       = t.Time.Ticks,
                    IsClosing   = t.IsClosing,
                    IsWin       = t.IsWin,
                    Pnl         = (float)t.Pnl,
                    HoldSeconds = (float)t.HoldSeconds,
                    Psi         = (float)t.Psi,
                    D1          = (float)t.D1,
                    D2          = (float)t.D2,
                    D3          = (float)t.D3,
                    D4          = (float)t.D4,
                    D5          = (float)t.D5,
                    D6          = (float)t.D6,
                    D7          = (float)t.D7,
                });
            }

            return detail;
        }

        // ── PSI downsampling ─────────────────────────────────────────────────

        /// <summary>
        /// Reduces a PSI snapshot list to at most <paramref name="maxPoints"/> points
        /// using uniform stride decimation, always preserving the first and last points
        /// so the chart endpoints match the session Start and Final PSI values.
        /// </summary>
        private static List<SdPsiPoint> Downsample(
            List<PsiSnapshot> source, int maxPoints)
        {
            var result = new List<SdPsiPoint>(Math.Min(source.Count, maxPoints));
            if (source.Count == 0) return result;

            if (source.Count <= maxPoints)
            {
                foreach (var p in source)
                    result.Add(new SdPsiPoint { Ticks = p.Time.Ticks, V = (float)p.Psi });
                return result;
            }

            // Stride decimation: include first, every Nth, and always the last
            double stride = (double)(source.Count - 1) / (maxPoints - 1);
            int    last   = -1;
            for (int i = 0; i < maxPoints; i++)
            {
                int idx = (i == maxPoints - 1)
                    ? source.Count - 1
                    : (int)Math.Round(i * stride);

                if (idx == last) continue; // avoid duplicates at high stride
                last = idx;

                result.Add(new SdPsiPoint
                {
                    Ticks = source[idx].Time.Ticks,
                    V     = (float)source[idx].Psi,
                });
            }
            return result;
        }
    }
}
