﻿// TradingClock.cs
//
// Single time-source abstraction for the PSI MeridianPSI engine.
//
// PROBLEM THIS SOLVES
// ────────────────────
// NT8 exposes at least four distinct time sources, each with different semantics:
//
//   • DateTime.Now              — wall clock on the IDE machine
//   • DateTime.UtcNow           — monotonic wall clock (UTC)
//   • NinjaTrader.Core.Globals.Now — wall clock in Live mode; replay clock
//                                    (frozen on pause) in Playback/Sim when
//                                    read on the NT8 dispatcher (main) thread;
//                                    wall-clock fallback on any other thread
//                                    (NT8 LANDMINE 7).
//   • execution.Time / order.Time — replay time during replay, wall in Live.
//
// Before this abstraction, callers hand-picked the right source for each
// path.  That produced:
//
//   1. Cross-domain EWMA math (fill in Playback at 06:21, timer poll in wall
//      at 14:32) producing negative deltaSec that silently dropped hard
//      deductions.
//   2. A "hybrid playback clock" patch that stitched playback fill time to
//      wall-clock elapsed — valid only while a position was open.
//      THIS IS THE CLASS OF BUG AXIOM A5 ELIMINATES:  the wall-clock
//      synthesis caused PSI to continue decaying while Market Replay was
//      paused, because UtcNow kept advancing regardless of replay state.
//   3. Replay-pause detection via snapshot-hash heuristics rather than a
//      first-class clock signal.
//
// DESIGN (post Axiom A5, 2026-04-23)
// ──────────────────────────────────
// TradingClock is the ONLY code allowed to read NT8's native time sources.
// Everyone else (PsiEngine, TradeBaseline, SessionData, UI) receives
// pre-resolved DateTime values from the clock.
//
// The clock's primary accessor is <see cref="EngineTime"/>.  It returns:
//
//   • Live            → DateTime.Now                    (wall clock)
//   • Playback / Sim  → NinjaTrader.Core.Globals.Now    (replay clock)
//   • Unknown         → NinjaTrader.Core.Globals.Now    (best effort)
//
// and ALWAYS delegates to the platform — there is NO synthesis, NO
// fill-anchored time extrapolation, NO wall-clock bridging.  When Market
// Replay is paused, Globals.Now is frozen on the main thread, so
// EngineTime is frozen, so the engine's dt goes to zero, so PSI does not
// decay.  This is the contract the user experiences as "pause freezes
// everything."
//
// Thread affinity (Axiom A5):
//
//   Globals.Now is reliable ONLY on the NT8 main (dispatcher) thread.
//   On any other thread in Playback, it returns wall-clock time instead
//   of replay time (LANDMINE 7).  Therefore:
//
//     • <see cref="EngineTime"/> detects off-main-thread reads in
//       Playback / Simulation, logs a warning (rate-limited), and
//       returns the last safely-observed main-thread EngineTime value
//       (cached) so a misbehaving caller cannot corrupt the engine
//       with a wall-clock reading.
//     • New callers MUST be scheduled on the main thread before they
//       read EngineTime.  The caller side enforces this (see MeridianPSI
//       post-M6 poll-timer marshalling).
//
// The clock is deliberately TINY.  It does not own EWMA state, does not
// decide which dimensions should freeze, does not know about positions.
// It only knows "what time is it right now for the engine?"

using System;
using System.Threading;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Trading environment the engine is currently observing.  Transitions
    /// between values (detected by <see cref="TradingClock.UpdateMode"/>) invalidate
    /// EWMA time anchors and force a fresh session so PSI does not integrate
    /// time across domains.
    /// </summary>
    public enum TradingMode
    {
        /// <summary>No account observed yet (engine just started).</summary>
        Unknown    = 0,
        /// <summary>Production account, real capital at risk.</summary>
        Live       = 1,
        /// <summary>Market Replay (historical playback) account.</summary>
        Playback   = 2,
        /// <summary>Simulation account (Sim101 / Connection.Mode.Simulation).</summary>
        Simulation = 3
    }

    /// <summary>
    /// The single authoritative clock for all PSI engine time reads.
    /// Thread-safe.  Owns the current <see cref="TradingMode"/> and raises
    /// <see cref="ModeChanged"/> on any transition so downstream state
    /// (EWMA anchors, session totals) can be reset cleanly.
    /// </summary>
    public sealed class TradingClock
    {
        private readonly object _sync = new object();

        private TradingMode _mode = TradingMode.Unknown;

        // Previous-fill platform-time baseline used by IsPlaybackRewind ONLY.
        // This field survived the 2026-04-23 A5 rewrite because rewind
        // detection ("is this incoming fill older than the last fill we
        // saw?") is a fill-to-fill comparison that remains in the platform
        // time domain — it does NOT need wall-clock synthesis.  The paired
        // _lastFillWallTimeUtc field was DELETED along with its synthesis
        // caller (the old PollTime body).
        private DateTime _lastFillPlatformTime = DateTime.MinValue;

        // Main-thread affinity tracking (Axiom A5).  Captured once via
        // CaptureMainThread() from a known main-thread caller (typically
        // MeridianPSI.State.Configure).  EngineTime uses this to detect
        // off-main-thread reads in Playback/Sim and return a cached safe
        // value instead of a wall-clock contaminated Globals.Now reading.
        private int      _mainThreadId = -1;
        private DateTime _lastMainThreadEngineTime = DateTime.MinValue;

        // Off-thread warning rate limit — at most one log line per N seconds
        // to avoid flooding the log if the ThreadPool hits EngineTime in a
        // tight loop before migration is complete.
        private DateTime _lastOffThreadWarnUtc = DateTime.MinValue;
        private const double OffThreadWarnIntervalSec = 5.0;

        /// <summary>Current trading mode (thread-safe read).</summary>
        public TradingMode Mode
        {
            get { lock (_sync) return _mode; }
        }

        /// <summary>
        /// Raised when <see cref="Mode"/> transitions to a different value.
        /// Arguments: (previousMode, newMode).  Invoked outside the internal lock.
        /// Subscribers must not block; exceptions are swallowed so one bad
        /// subscriber cannot corrupt the clock.
        /// </summary>
        public event Action<TradingMode, TradingMode> ModeChanged;

        /// <summary>
        /// Called once from a known main-thread context (typically
        /// <c>MeridianPSI.State.Configure</c>) so the clock can detect
        /// off-main-thread <see cref="EngineTime"/> reads in Playback/Sim.
        /// Safe to call multiple times; only the first call sets the ID.
        /// </summary>
        public void CaptureMainThread()
        {
            lock (_sync)
            {
                if (_mainThreadId == -1)
                    _mainThreadId = Thread.CurrentThread.ManagedThreadId;
            }
        }

        /// <summary>
        /// True iff the calling thread matches the captured main-thread
        /// identity.  Returns <c>true</c> when <see cref="CaptureMainThread"/>
        /// has not yet been invoked (pre-wiring grace), so callers do not
        /// crash before configuration runs.
        /// </summary>
        public bool IsOnMainThread
        {
            get
            {
                int captured;
                lock (_sync) captured = _mainThreadId;
                return captured == -1 ||
                       Thread.CurrentThread.ManagedThreadId == captured;
            }
        }

        /// <summary>
        /// Updates the observed mode.  If different from the current value,
        /// raises <see cref="ModeChanged"/> outside the lock.  Callers should
        /// invoke this from <see cref="MeridianPSI"/> whenever a subscribed
        /// account is discovered, reconnected, or the primary account changes.
        ///
        /// <para>
        /// <b>Live is sticky.</b>  Once a live fill has been observed, the mode
        /// will not be downgraded to Simulation or Playback by a subsequent
        /// fill event.  This prevents spurious Live → Simulation transitions
        /// caused by trade-copier plugins (e.g. Replikanto) that mirror live
        /// fills onto a local Sim account: the Sim-account fills arrive
        /// milliseconds after each live fill and previously caused the engine
        /// to clear all position-tracking state, fire IntegrityCheck repairs,
        /// and emit phantom D7 PSI commits on every single trade.
        /// </para>
        ///
        /// <para>
        /// To legitimately leave Live mode (e.g. the live account disconnects
        /// and the user switches to Simulation-only), call
        /// <see cref="ResetMode"/> first, which returns the clock to Unknown so
        /// the next fill re-establishes the mode cleanly.
        /// </para>
        /// </summary>
        public void UpdateMode(TradingMode observed)
        {
            TradingMode prev;
            bool changed;
            lock (_sync)
            {
                // Live is sticky: reject any Simulation / Playback observation
                // while in Live mode.  Replikanto (and similar copiers) mirror
                // every live fill to a local Sim account a few milliseconds
                // later, which previously caused Live ↔ Simulation oscillation
                // that cleared position-tracking state on every trade.
                if (_mode == TradingMode.Live &&
                    (observed == TradingMode.Simulation ||
                     observed == TradingMode.Playback))
                    return;

                changed = observed != _mode;
                prev = _mode;
                if (changed) _mode = observed;
            }
            if (!changed) return;

            var handler = ModeChanged;
            if (handler == null) return;
            try { handler(prev, observed); }
            catch { /* defensive: do not let a subscriber crash the clock */ }
        }

        /// <summary>
        /// Resets the mode to <see cref="TradingMode.Unknown"/> so that the
        /// next call to <see cref="UpdateMode"/> can re-establish it.  Call
        /// from the MeridianPSI epoch-reset path when the live account has
        /// genuinely disconnected and the user may be switching to a different
        /// mode (e.g. starting a Simulation session after going flat on a live
        /// account).  Do NOT call on every fill — only on account epoch
        /// transitions.
        /// </summary>
        public void ResetMode()
        {
            lock (_sync) _mode = TradingMode.Unknown;
        }

        /// <summary>
        /// The PRIMARY engine time accessor (Axiom A5).
        ///
        /// <para>
        /// Returns the current time in the mode-appropriate domain with NO
        /// wall-clock synthesis and NO fill-time extrapolation:
        /// </para>
        ///
        /// <list type="bullet">
        /// <item><description><b>Live</b> → <c>DateTime.Now</c></description></item>
        /// <item><description><b>Playback / Simulation</b> on main thread →
        /// <c>NinjaTrader.Core.Globals.Now</c> (replay clock; FROZEN when
        /// replay is paused — this is the desired behaviour per user
        /// request 2026-04-23)</description></item>
        /// <item><description><b>Playback / Simulation</b> off main thread →
        /// <em>last observed main-thread <see cref="EngineTime"/></em>
        /// (cached).  A warning is logged once per 5 s; the cached value
        /// is safe because it was sampled the last time a main-thread
        /// caller read EngineTime.  Off-thread callers should be migrated
        /// to dispatch onto the UI thread before reading (see
        /// MeridianPSI.OnPsiPollTimerElapsed's UI-dispatcher marshalling).</description></item>
        /// <item><description><b>Unknown mode</b> (engine just started) →
        /// <c>Globals.Now</c> as a best-effort fallback.</description></item>
        /// </list>
        /// </summary>
        public DateTime EngineTime
        {
            get
            {
                TradingMode m;
                bool onMain;
                int captured;
                lock (_sync)
                {
                    m        = _mode;
                    captured = _mainThreadId;
                }
                onMain = captured == -1 ||
                         Thread.CurrentThread.ManagedThreadId == captured;

                // Live — DateTime.Now is thread-safe and always correct.
                if (m == TradingMode.Live)
                {
                    DateTime now = DateTime.Now;
                    if (onMain)
                        lock (_sync) _lastMainThreadEngineTime = now;
                    return now;
                }

                // Playback / Simulation / Unknown — Globals.Now is correct
                // ONLY on the main thread.  Off the main thread it returns
                // wall-clock time (LANDMINE 7) which would contaminate the
                // engine with a totally different time domain.
                if (onMain)
                {
                    DateTime now = NinjaTrader.Core.Globals.Now;
                    lock (_sync) _lastMainThreadEngineTime = now;
                    return now;
                }

                // Off-main-thread in a non-Live mode — return the cached
                // main-thread reading.  Rate-limit the warning so we do
                // not flood logs if a pre-migration caller is in a tight
                // loop.
                DateTime cached;
                DateTime now_utc = DateTime.UtcNow;
                bool shouldWarn;
                lock (_sync)
                {
                    cached      = _lastMainThreadEngineTime;
                    shouldWarn  = (now_utc - _lastOffThreadWarnUtc).TotalSeconds
                                  >= OffThreadWarnIntervalSec;
                    if (shouldWarn) _lastOffThreadWarnUtc = now_utc;
                }
                if (shouldWarn)
                {
                    try
                    {
                        NinjaTrader.Code.Output.Process(
                            "[TradingClock] WARNING: EngineTime read from off-main-thread " +
                            "in " + m + " mode — returning cached main-thread value " +
                            (cached == DateTime.MinValue ? "(none yet)" :
                             cached.ToString("HH:mm:ss.fff")) +
                            " instead of Globals.Now to avoid LANDMINE 7 contamination. " +
                            "Fix the caller to dispatch onto the UI thread.",
                            PrintTo.OutputTab1);
                    }
                    catch { /* never let logging crash the clock */ }
                }

                // If no main-thread sample yet, fall back to Globals.Now as
                // a pragmatic best effort; better than returning MinValue
                // which would corrupt dt.
                return cached == DateTime.MinValue
                    ? NinjaTrader.Core.Globals.Now
                    : cached;
            }
        }

        /// <summary>
        /// Legacy accessor maintained for backward compatibility while M6's
        /// caller migration is in flight.  Delegates unconditionally to
        /// <see cref="EngineTime"/>; the <paramref name="hasOpenPosition"/>
        /// parameter is ignored (the old wall-clock synthesis path was
        /// DELETED — it was the root cause of the "PSI recovers during
        /// paused replay" bug identified 2026-04-23, Axiom A5).
        /// </summary>
        /// <remarks>
        /// New callers must use <see cref="EngineTime"/> directly.  This
        /// shim exists only until all call sites are migrated; once that is
        /// complete it will be removed.
        /// </remarks>
        [Obsolete("Use EngineTime; hasOpenPosition no longer affects the returned value.")]
        public DateTime PollTime(bool hasOpenPosition)
        {
            return EngineTime;
        }

        /// <summary>
        /// The platform timestamp of the most recently recorded fill, stored
        /// by the last call to <see cref="RecordFillAnchor"/>.  Returns
        /// <see cref="DateTime.MinValue"/> when no fill has been anchored
        /// yet.  Used ONLY by <see cref="IsPlaybackRewind"/> to detect a
        /// replay rewind; no longer feeds the engine clock.
        /// </summary>
        public DateTime LastFillPlatformTime
        {
            get { lock (_sync) return _lastFillPlatformTime; }
        }

        /// <summary>
        /// Engine time to use inside <c>OnOrderUpdate</c> (NT8 background thread).
        ///
        /// <para>
        /// <c>OnOrderUpdate</c> fires on a background thread and may arrive
        /// BEFORE the first <c>PsiPollTick_OnUiThread</c> has had a chance to
        /// warm <c>_lastMainThreadEngineTime</c>.  During that cold window
        /// <c>EngineTime</c> falls back to <c>Globals.Now</c> on the background
        /// thread which returns wall-clock time — a completely different domain
        /// from <c>_positionEntryTimes[key]</c> (which are filled from
        /// <c>execution.Time</c>, the historical replay timestamp).  Subtracting
        /// wall-clock from historical gives ~8-day <c>HoldSeconds</c>, instantly
        /// saturating D5 to 100 and crashing PSI to 0 (confirmed 2026-04-24,
        /// ARCHITECTURE.md §11 Landmine 13).
        /// </para>
        ///
        /// <para>
        /// <c>FillAlignedTime</c> solves this by returning
        /// <see cref="LastFillPlatformTime"/> — the most recently anchored
        /// <c>fill.Time</c> — which is always in the same domain as
        /// <c>_positionEntryTimes[key]</c>, making <c>HoldSeconds</c>
        /// subtraction safe.  Falls back to <c>EngineTime</c> only if no
        /// fill has been anchored yet (cold start with no position), in which
        /// case there is no open position and <c>HoldSeconds</c> = 0 anyway.
        /// </para>
        ///
        /// <para>
        /// In Live mode <c>LastFillPlatformTime</c> is also wall-clock (set from
        /// <c>fill.Time</c> which is live time), so the property is correct in
        /// every mode without any mode branch.
        /// </para>
        /// </summary>
        public DateTime FillAlignedTime
        {
            get
            {
                DateTime fill;
                lock (_sync) fill = _lastFillPlatformTime;
                return fill != DateTime.MinValue ? fill : EngineTime;
            }
        }

        /// <summary>
        /// Records the platform time of the latest confirmed fill so that
        /// <see cref="IsPlaybackRewind"/> can detect a subsequent rewound
        /// replay.  Post-A5 this NO LONGER records wall-clock time (the
        /// wall-clock field was deleted along with the synthesis path).
        /// </summary>
        public void RecordFillAnchor(DateTime fillPlatformTime)
        {
            lock (_sync) _lastFillPlatformTime = fillPlatformTime;
        }

        /// <summary>
        /// Returns <c>true</c> when <paramref name="incomingFillTime"/> is
        /// more than <paramref name="toleranceMinutes"/> minutes BEFORE the
        /// most recently anchored fill platform time.  A true result
        /// indicates that a Playback rewind or account reset has occurred
        /// and all session state should be cleared before processing the
        /// new fill.  Returns <c>false</c> when no prior fill has been
        /// anchored (first fill of a session) or the incoming fill is in
        /// the normal forward direction.
        /// </summary>
        public bool IsPlaybackRewind(DateTime incomingFillTime, double toleranceMinutes)
        {
            DateTime last;
            lock (_sync) last = _lastFillPlatformTime;
            if (last == DateTime.MinValue) return false;
            return incomingFillTime < last.AddMinutes(-toleranceMinutes);
        }

        /// <summary>
        /// Clears the fill anchor.  Called by MeridianPSI when the trader
        /// goes flat or a session boundary fires, so a subsequent rewind
        /// comparison does not treat a stale old fill as the baseline.
        /// </summary>
        public void ClearFillAnchor()
        {
            lock (_sync) _lastFillPlatformTime = DateTime.MinValue;
        }

        /// <summary>
        /// Maps an NT8 Account to a <see cref="TradingMode"/>.  Uses the
        /// connection mode as the primary signal and name-prefix as a
        /// fallback (name prefixes are NT8 convention, not guarantee).
        /// Centralised here so the entire engine shares exactly one
        /// detection rule.
        /// </summary>
        public static TradingMode InferMode(NinjaTrader.Cbi.Account account)
        {
            if (account == null) return TradingMode.Unknown;
            try
            {
                string name = account.Name ?? "";
                if (name.StartsWith("Playback", StringComparison.OrdinalIgnoreCase))
                    return TradingMode.Playback;
                if (account.Connection?.Options?.Mode == NinjaTrader.Cbi.Mode.Simulation)
                    return TradingMode.Simulation;
                if (name.StartsWith("Sim", StringComparison.OrdinalIgnoreCase))
                    return TradingMode.Simulation;
                return TradingMode.Live;
            }
            catch
            {
                return TradingMode.Unknown;
            }
        }
    }

    /// <summary>
    /// A wall-clock–based one-shot gate.  <see cref="Set"/> arms the gate;
    /// <see cref="IsActive"/> returns <c>true</c> while the configured window
    /// has not yet elapsed; <see cref="Clear"/> disarms it immediately.
    ///
    /// <para>
    /// Time source is <c>DateTime.UtcNow</c> — intentional.  These gates
    /// measure <em>real elapsed time</em> (e.g. "the ATM just re-submitted
    /// its stop 3 s ago"), which is always wall-clock time regardless of
    /// whether the engine is in Live, Playback, or Simulation mode.  Using
    /// the trading-domain clock here would mean a paused Market Replay
    /// never lets the grace window expire.
    /// </para>
    ///
    /// <para>
    /// Usage pattern: replace <c>_lastXxxWallTime != DateTime.MinValue &amp;&amp;
    /// (DateTime.UtcNow - _lastXxxWallTime).TotalSeconds &lt; XxxGraceSec</c>
    /// with a single <c>_xxxGate.IsActive()</c> call.
    /// </para>
    /// </summary>
    internal struct WallClockGate
    {
        private DateTime _setAt;
        private readonly double _windowSec;

        /// <param name="windowSec">
        /// Duration (seconds) after which <see cref="IsActive"/> returns
        /// <c>false</c>.
        /// </param>
        public WallClockGate(double windowSec)
        {
            _windowSec = windowSec;
            _setAt     = DateTime.MinValue;
        }

        /// <summary>Arms the gate at the current wall-clock instant.</summary>
        public void Set()   => _setAt = DateTime.UtcNow;

        /// <summary>
        /// Disarms the gate immediately regardless of the window.  Call on
        /// events that logically reset the grace period (e.g. a real execution
        /// arriving during a DESYNC grace).
        /// </summary>
        public void Clear() => _setAt = DateTime.MinValue;

        /// <summary>
        /// Returns <c>true</c> while the gate was set and the window has not yet
        /// expired; <c>false</c> if never set or window elapsed.
        /// </summary>
        public bool IsActive()
            => _setAt != DateTime.MinValue &&
               (DateTime.UtcNow - _setAt).TotalSeconds < _windowSec;
    }
}
