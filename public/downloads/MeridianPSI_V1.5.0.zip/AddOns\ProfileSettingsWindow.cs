// ProfileSettingsWindow.cs  —  Strategy Profile configuration panel.
//
// Changes vs previous version:
//   - Account list shows only CONNECTED accounts (failed/expired prop-firm
//     accounts are excluded because their Connection.Status is Disconnected).
//   - Preset button Grid uses interleaved star/gap columns (fixes overflow).
//   - Window is resizable: drag right edge, bottom edge, or corner.
//   - Higher contrast colours throughout.

using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal sealed class ProfileSettingsWindow : Window
    {
        // ── Win32 resize ──────────────────────────────────────────────────────
        [DllImport("user32.dll")]
        private static extern IntPtr SendMessage(IntPtr hWnd, uint msg, IntPtr wp, IntPtr lp);

        // Direction codes for WM_SYSCOMMAND + SC_SIZE (0xF000):
        // 2=right, 6=bottom, 8=bottom-right, 1=left, 3=top, 4=top-left, 5=top-right, 7=bottom-left
        private void BeginResize(int direction)
        {
            try
            {
                ReleaseMouseCapture();
                SendMessage(new WindowInteropHelper(this).Handle,
                            0x0112 /*WM_SYSCOMMAND*/,
                            new IntPtr(0xF000 + direction), IntPtr.Zero);
            }
            catch { /* best-effort */ }
        }

        // =====================================================================
        // Injected state
        // =====================================================================

        private readonly StrategyProfile    _profile;
        private readonly Action<string>    _onError;
        private readonly Func<List<string>> _accountsProvider;

        // =====================================================================
        // Form fields
        // =====================================================================

        private readonly TextBox _txStartH, _txStartM, _txEndH, _txEndM;
        private readonly TextBox _txSizeMin, _txSizeMax;
        private readonly TextBox _txSlMax;
        private readonly TextBox _txFreqMin, _txFreqMax;
        private readonly TextBox _txMaxHold;
        private readonly TextBox _txReentryMin, _txRentrySec;
        private readonly TextBox  _txReversalFactor;
        private readonly TextBox  _txGraceSeconds;
        private readonly CheckBox _cbNoStopTrader;
        private readonly TextBox  _txMaxDailyLoss;
        private readonly CheckBox _cbMaxDailyLossEnabled;
        private readonly TextBox  _txPauseAfterNLosses;
        private readonly CheckBox _cbPauseAfterNLossesEnabled;

        // =====================================================================
        // Accounts
        // =====================================================================

        private readonly List<CheckBox> _accountChecks = new List<CheckBox>();
        private StackPanel              _accPanel;

        // =====================================================================
        // Session window toggle
        // =====================================================================

        private readonly CheckBox _cbSessionEnabled;

        // =====================================================================
        // Dimension weights — DEPRECATED as of v1.1 (2026-04-21)
        // =====================================================================
        //
        // PSI aggregation switched from weighted sum Σ w_i·C_i to unweighted
        // Euclidean norm √(Σ C_i²).  Under a norm, per-dimension weights would
        // only limit how much a single severe violation can move PSI — exactly
        // the "ceiling effect" the v1.1 refactor eliminated (a single oversize
        // event used to drop PSI by at most ~16 points; now a severe single
        // dimension can crash PSI to 0 on its own, as real psychology would).
        //
        // StrategyProfile.Weight* XML fields are preserved for backward
        // compatibility (old profiles load without errors) but ignored at
        // runtime.  This window no longer exposes them as UI sliders.
        //
        // See ARCHITECTURE.md §3 for the Euclidean-norm derivation and §14.5
        // for the governing invariant that forbids reintroducing P&L-keyed
        // weights disguised as dimension weights.

        // =====================================================================
        // Test Mode (duration only — toggle lives in Profile tab)
        // =====================================================================

        private readonly TextBox _txTestModeMin;

        // =====================================================================
        // Advanced (PSI sensitivity + penalty overrides)
        // =====================================================================

        private Border _senConservative, _senBalanced, _senAggressive;
        private Border _activeSenPreset;
        private readonly TextBox _txRecoverySpeed;
        private readonly TextBox _txFalsePositiveRate;

        // =====================================================================
        // Error banner
        // =====================================================================

        private readonly TextBlock _errBanner;

        // =====================================================================
        // Constructor
        // =====================================================================

        public ProfileSettingsWindow(StrategyProfile     profile,
                                     List<string>        availableAccounts,
                                     Action<string>      onError           = null,
                                     Func<List<string>>  accountsProvider  = null)
        {
            _profile          = profile ?? throw new ArgumentNullException("profile");
            _onError          = onError;
            _accountsProvider = accountsProvider;

            WindowStyle        = WindowStyle.None;
            AllowsTransparency = true;
            Background         = Brushes.Transparent;
            ResizeMode         = ResizeMode.CanResize;   // enables system resize logic
            ShowInTaskbar      = true;
            Title              = "PSI Monitor – Settings";
            MinWidth           = 640;
            MinHeight          = 420;
            Width              = 880;
            Height             = 640;
            Left               = SystemParameters.WorkArea.Left + 80;
            Top                = SystemParameters.WorkArea.Top  + 60;

            // ── Outer grid: card + invisible resize border zones ──────────────
            var outer = new Grid();
            outer.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            outer.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(6) }); // right resize
            outer.RowDefinitions.Add(
                new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            outer.RowDefinitions.Add(
                new RowDefinition { Height = new GridLength(6) }); // bottom resize

            // Resize hit zones (transparent but hit-testable)
            var rRight  = ResizeZone(Cursors.SizeWE,   () => BeginResize(2));
            var rBottom = ResizeZone(Cursors.SizeNS,   () => BeginResize(6));
            var rCorner = ResizeZone(Cursors.SizeNWSE,  () => BeginResize(8));
            Grid.SetColumn(rRight,  1); Grid.SetRow(rRight,  0); outer.Children.Add(rRight);
            Grid.SetColumn(rBottom, 0); Grid.SetRow(rBottom, 1); outer.Children.Add(rBottom);
            Grid.SetColumn(rCorner, 1); Grid.SetRow(rCorner, 1); outer.Children.Add(rCorner);

            // ── Card ──────────────────────────────────────────────────────────
            var card = new Border
            {
                CornerRadius    = new CornerRadius(Theme.R3),
                Background      = Theme.BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(45, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };
            Grid.SetColumn(card, 0); Grid.SetRow(card, 0);
            outer.Children.Add(card);

            // ── Card layout: DockPanel (title top, buttons bottom, scroll fills) ──
            var dock = new DockPanel { LastChildFill = true };

            // Title bar
            var titleBar = BuildTitleBar();
            DockPanel.SetDock(titleBar, Dock.Top);
            dock.Children.Add(titleBar);

            // Button row + error at bottom
            _errBanner = new TextBlock
            {
                TextWrapping = TextWrapping.Wrap,
                Foreground   = ErrBrush,
                FontSize     = 10,
                Visibility   = Visibility.Collapsed,
                Margin       = new Thickness(18, 6, 18, 0),
            };

            var btnRow = new Grid { Margin = new Thickness(20, 10, 20, 18) };
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(8) });
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(8) });
            btnRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });

            var resetBtn  = MakeActionBtn("Reset",        BgSurface);
            var applyBtn  = MakeActionBtn("Apply & save", BgAccent);
            var cancelBtn = MakeActionBtn("Cancel",       BgSurface);

            resetBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                var def = new StrategyProfile();
                LoadDefaultsIntoForm(def);
                ShowWarn("Defaults loaded — click APPLY & SAVE to confirm, or CANCEL to discard.");
            };
            applyBtn.MouseLeftButtonDown  += (_, e) => { e.Handled = true; OnApply(); };
            cancelBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                Close();
            };

            Grid.SetColumn(resetBtn,  0); btnRow.Children.Add(resetBtn);
            Grid.SetColumn(applyBtn,  2); btnRow.Children.Add(applyBtn);
            Grid.SetColumn(cancelBtn, 4); btnRow.Children.Add(cancelBtn);

            var bottomStack = new StackPanel();
            bottomStack.Children.Add(_errBanner);
            bottomStack.Children.Add(btnRow);
            DockPanel.SetDock(bottomStack, Dock.Bottom);
            dock.Children.Add(bottomStack);

            // ── Scrollable form (card-based modern layout) ──────────────────
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };

            var form = new StackPanel { Margin = new Thickness(14, 10, 14, 16) };

            // ─── CARD: MONITORED ACCOUNTS ─────────────────────────────────────
            {
                var body = new StackPanel();
                body.Children.Add(CardHeader("\u24BE", "Monitored accounts",
                    "Select the account(s) you are actively trading.",
                    "Only CONNECTED accounts are listed.\nFailed or expired prop-firm accounts are automatically excluded.\n\nChecking all accounts (or leaving the list empty) monitors everything."));

                var accFilter = MakeTx("", 11);
                accFilter.Tag    = "Search accounts\u2026";
                accFilter.Margin = new Thickness(14, 8, 14, 6);
                SetPlaceholder(accFilter);
                accFilter.TextChanged += (_, __) =>
                    FilterAccounts(accFilter.Text == (string)accFilter.Tag ? "" : accFilter.Text);
                body.Children.Add(accFilter);

                _accPanel = new StackPanel();
                PopulateAccounts(availableAccounts ?? new List<string>());

                var accScroll = new ScrollViewer
                {
                    MaxHeight                     = 130,
                    VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                    HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                    Content                       = _accPanel,
                    Margin                        = new Thickness(0, 0, 0, 4),
                };
                body.Children.Add(accScroll);

                // Refresh button — only shown when a provider is wired up
                if (_accountsProvider != null)
                {
                    var refreshBtn = new TextBlock
                    {
                        Text               = "\u21BB  Refresh accounts",
                        FontSize           = 10,
                        Foreground         = FgAccent,
                        Cursor             = Cursors.Hand,
                        Margin             = new Thickness(16, 0, 14, 10),
                        TextDecorations    = TextDecorations.Underline,
                    };
                    refreshBtn.MouseLeftButtonDown += (_, e) =>
                    {
                        e.Handled = true;
                        PopulateAccounts(_accountsProvider());
                    };
                    body.Children.Add(refreshBtn);
                }

                form.Children.Add(WrapInCard(body));
            }

            // ─── CARD: TRADING SESSION ────────────────────────────────────────
            {
                var body = new StackPanel();
                body.Children.Add(CardHeader("\u231A", "Trading session",
                    "Trades outside your declared hours are flagged as rule violations.",
                    "Enter the start and end of your normal trading window.\n\nUse your computer\u2019s local clock time \u2014 the same time shown on your taskbar.\n\nTurn off if you have no fixed session hours (e.g. swing trading across multiple sessions)."));

                // ── Enable/disable toggle ─────────────────────────────────────
                _cbSessionEnabled = new CheckBox
                {
                    IsChecked  = profile.SessionWindowEnabled,
                    Visibility = Visibility.Collapsed,
                };
                Border sesToggleTrack, sesToggleThumb;
                var sesToggleSwitch = BuildToggleSwitch(profile.SessionWindowEnabled,
                                                        out sesToggleTrack, out sesToggleThumb);
                sesToggleTrack.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    _cbSessionEnabled.IsChecked = !(_cbSessionEnabled.IsChecked == true);
                };
                _cbSessionEnabled.Checked   += (_, __) =>
                {
                    sesToggleTrack.Background           = ToggleOnBrush;
                    sesToggleThumb.HorizontalAlignment  = HorizontalAlignment.Right;
                };
                _cbSessionEnabled.Unchecked += (_, __) =>
                {
                    sesToggleTrack.Background           = ToggleOffBrush;
                    sesToggleThumb.HorizontalAlignment  = HorizontalAlignment.Left;
                };
                body.Children.Add(_cbSessionEnabled); // hidden, in tree so save works
                body.Children.Add(SettingsRow("Track trading hours",
                    "Turn off if you trade with no fixed session hours",
                    sesToggleSwitch));

                body.Children.Add(RowDivider());

                // Time pickers — hidden when session window is disabled
                var timePickerArea = new StackPanel();
                _cbSessionEnabled.Checked   += (_, __) => timePickerArea.Visibility = Visibility.Visible;
                _cbSessionEnabled.Unchecked += (_, __) => timePickerArea.Visibility = Visibility.Collapsed;
                timePickerArea.Visibility = profile.SessionWindowEnabled
                    ? Visibility.Visible : Visibility.Collapsed;

                // Clock hint
                timePickerArea.Children.Add(new TextBlock
                {
                    Text       = "Your clock: " + DateTime.Now.ToString("HH:mm") +
                                 "  \u00B7  " + TimeZoneInfo.Local.DisplayName,
                    FontSize   = 9,
                    FontFamily = Theme.Font,
                    Foreground = FgHint,
                    Margin     = new Thickness(16, 0, 16, 8),
                });

                // Side-by-side start / end pickers
                var timeGrid = new Grid();
                timeGrid.ColumnDefinitions.Add(new ColumnDefinition());
                timeGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1) });
                timeGrid.ColumnDefinitions.Add(new ColumnDefinition());

                var startSP = new StackPanel { Margin = new Thickness(14, 6, 14, 12) };
                startSP.Children.Add(FieldLbl("Start time"));
                startSP.Children.Add(HhMm(profile.SessionStartHour.ToString("D2"),
                                          profile.SessionStartMinute.ToString("D2"),
                                          out _txStartH, out _txStartM));
                Grid.SetColumn(startSP, 0);
                timeGrid.Children.Add(startSP);

                var vDivider = new Border
                {
                    Width      = 1,
                    Background = new SolidColorBrush(Color.FromArgb(20, 255, 255, 255)),
                    VerticalAlignment = VerticalAlignment.Stretch,
                };
                Grid.SetColumn(vDivider, 1);
                timeGrid.Children.Add(vDivider);

                var endSP = new StackPanel { Margin = new Thickness(14, 6, 14, 12) };
                endSP.Children.Add(FieldLbl("End time"));
                endSP.Children.Add(HhMm(profile.SessionEndHour.ToString("D2"),
                                        profile.SessionEndMinute.ToString("D2"),
                                        out _txEndH, out _txEndM));
                Grid.SetColumn(endSP, 2);
                timeGrid.Children.Add(endSP);

                timePickerArea.Children.Add(timeGrid);
                body.Children.Add(timePickerArea);
                form.Children.Add(WrapInCard(body));
            }

            // ─── CARD: TRADING STYLE ──────────────────────────────────────────
            {
                var body = new StackPanel();
                body.Children.Add(CardHeader("\u25F0", "Trading style",
                    "Describe your normal trading parameters — PSI flags when you deviate from them.",
                    "Set these to your typical position size, stop-loss, trade frequency, and hold time.\n\nUse your real averages \u2014 not aspirational targets.\n\nMax hold time is used to detect when you hold a position longer than usual."));

                body.Children.Add(SettingsRow("Position size",
                    "Your normal size range per trade (contracts)",
                    InlineRangeControl("Min", profile.SizeMin.ToString(),
                                       "Max", profile.SizeMax.ToString(),
                                       "contracts", out _txSizeMin, out _txSizeMax)));

                body.Children.Add(RowDivider());

                body.Children.Add(SettingsRow("Max stop-loss",
                    "Flags when your stop-loss widens past this during a losing trade",
                    InlineUnitField(profile.SlTicksMax.ToString(), "ticks", out _txSlMax)));

                body.Children.Add(RowDivider());

                body.Children.Add(SettingsRow("Trade frequency",
                    "Flags when you take trades faster than your declared maximum",
                    InlineRangeControl("Min", profile.TradesPerSessionMin.ToString(),
                                       "Max", profile.TradesPerSessionMax.ToString(),
                                       "/ session", out _txFreqMin, out _txFreqMax)));

                body.Children.Add(RowDivider());

                body.Children.Add(SettingsRow("Max hold time",
                    "Flags when you hold a position past this time",
                    InlineUnitField(profile.MaxHoldMinutes.ToString(), "minutes", out _txMaxHold)));

                form.Children.Add(WrapInCard(body));
            }

            // ─── CARD: RISK LIMITS ────────────────────────────────────────────
            {
                var body = new StackPanel();
                body.Children.Add(CardHeader("\u26E8", "Risk limits",
                    "Declare your hard limits — PSI flags when you breach them.",
                    "Max Daily Loss \u2014 PSI tracks how far past this limit you trade; severity grows with the overshoot.\nToggle off to disable.\n\nPause After N Losses \u2014 PSI flags each consecutive loss past your declared number.\nToggle off to disable."));

                // ── Max daily loss toggle ─────────────────────────────────────
                bool mdlOn = profile.MaxDailyLossUsd > 0;
                _cbMaxDailyLossEnabled = new CheckBox { IsChecked = mdlOn, Visibility = Visibility.Collapsed };
                Border mdlTrack, mdlThumb;
                var mdlToggle = BuildToggleSwitch(mdlOn, out mdlTrack, out mdlThumb);
                mdlTrack.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    _cbMaxDailyLossEnabled.IsChecked = !(_cbMaxDailyLossEnabled.IsChecked == true);
                };
                _cbMaxDailyLossEnabled.Checked   += (_, __) => { mdlTrack.Background = ToggleOnBrush;  mdlThumb.HorizontalAlignment = HorizontalAlignment.Right; };
                _cbMaxDailyLossEnabled.Unchecked += (_, __) => { mdlTrack.Background = ToggleOffBrush; mdlThumb.HorizontalAlignment = HorizontalAlignment.Left;  };
                body.Children.Add(_cbMaxDailyLossEnabled);
                body.Children.Add(SettingsRow("Max daily loss",
                    "PSI flags when session losses exceed this amount",
                    mdlToggle));

                var mdlAmountRow = SettingsRow("",
                    "",
                    InlineUnitField(profile.MaxDailyLossUsd > 0 ? profile.MaxDailyLossUsd.ToString("0") : "",
                                    "USD", out _txMaxDailyLoss));
                mdlAmountRow.Visibility = mdlOn ? Visibility.Visible : Visibility.Collapsed;
                _cbMaxDailyLossEnabled.Checked   += (_, __) => mdlAmountRow.Visibility = Visibility.Visible;
                _cbMaxDailyLossEnabled.Unchecked += (_, __) => mdlAmountRow.Visibility = Visibility.Collapsed;
                body.Children.Add(mdlAmountRow);

                body.Children.Add(RowDivider());

                // ── Pause after N losses toggle ───────────────────────────────
                bool panOn = profile.PauseAfterNLosses > 0;
                _cbPauseAfterNLossesEnabled = new CheckBox { IsChecked = panOn, Visibility = Visibility.Collapsed };
                Border panTrack, panThumb;
                var panToggle = BuildToggleSwitch(panOn, out panTrack, out panThumb);
                panTrack.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    _cbPauseAfterNLossesEnabled.IsChecked = !(_cbPauseAfterNLossesEnabled.IsChecked == true);
                };
                _cbPauseAfterNLossesEnabled.Checked   += (_, __) => { panTrack.Background = ToggleOnBrush;  panThumb.HorizontalAlignment = HorizontalAlignment.Right; };
                _cbPauseAfterNLossesEnabled.Unchecked += (_, __) => { panTrack.Background = ToggleOffBrush; panThumb.HorizontalAlignment = HorizontalAlignment.Left;  };
                body.Children.Add(_cbPauseAfterNLossesEnabled);
                body.Children.Add(SettingsRow("Pause after N losses",
                    "PSI flags each consecutive loss past this number",
                    panToggle));

                var panAmountRow = SettingsRow("",
                    "",
                    InlineUnitField(profile.PauseAfterNLosses > 0 ? profile.PauseAfterNLosses.ToString() : "",
                                    "losses", out _txPauseAfterNLosses));
                panAmountRow.Visibility = panOn ? Visibility.Visible : Visibility.Collapsed;
                _cbPauseAfterNLossesEnabled.Checked   += (_, __) => panAmountRow.Visibility = Visibility.Visible;
                _cbPauseAfterNLossesEnabled.Unchecked += (_, __) => panAmountRow.Visibility = Visibility.Collapsed;
                body.Children.Add(panAmountRow);

                form.Children.Add(WrapInCard(body));
            }

            // ─── CARD: STOPS & RHYTHM ─────────────────────────────────────────
            {
                var body = new StackPanel();
                body.Children.Add(CardHeader("\u29C9", "Stops & rhythm",
                    "Calibrates revenge-trading detection to your personal rhythm.",
                    "Time between trades \u2014 How long you normally wait between trades in a calm session.\nScalpers: 15\u201330 s.  Intraday futures: 2 min.  Swing: 10\u201315 min.\n\nNo stop-loss trader \u2014 Enable if you never place stop-loss orders (mental stops or bracket exits only).\n\nStop grace period \u2014 Seconds after entry before the no-stop alert fires."));

                body.Children.Add(SettingsRow("Time between trades",
                    "Your typical wait between trades (used before enough data is collected)",
                    MmSs((profile.ColdStartInterTradeGapPriorSec / 60).ToString(),
                         (profile.ColdStartInterTradeGapPriorSec % 60).ToString("D2"),
                         out _txReentryMin, out _txRentrySec)));

                body.Children.Add(RowDivider());

                // ── Toggle switch for NoStopTrader ────────────────────────────
                _cbNoStopTrader = new CheckBox
                {
                    IsChecked  = profile.NoStopLossTrader,
                    Visibility = Visibility.Collapsed,
                };
                Border toggleTrack;
                Border toggleThumb;
                var toggleSwitch = BuildToggleSwitch(profile.NoStopLossTrader, out toggleTrack, out toggleThumb);
                toggleTrack.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    _cbNoStopTrader.IsChecked = !(_cbNoStopTrader.IsChecked == true);
                };
                _cbNoStopTrader.Checked   += (_, __) =>
                {
                    toggleTrack.Background = ToggleOnBrush;
                    toggleThumb.HorizontalAlignment = HorizontalAlignment.Right;
                };
                _cbNoStopTrader.Unchecked += (_, __) =>
                {
                    toggleTrack.Background = ToggleOffBrush;
                    toggleThumb.HorizontalAlignment = HorizontalAlignment.Left;
                };

                body.Children.Add(_cbNoStopTrader); // hidden, in tree so validation works
                body.Children.Add(SettingsRow("No stop-loss trader",
                    "I use mental stops or bracket exits \u2014 disables the no-stop alert",
                    toggleSwitch));

                body.Children.Add(RowDivider());

                var graceInitVal = profile.NoStopLossTrader ? "20" : profile.NoStopGraceSeconds.ToString();
                var graceRow = SettingsRow("Stop grace period",
                    "Seconds after entry before the no-stop alert fires (5\u2013120)",
                    InlineUnitField(graceInitVal, "sec", out _txGraceSeconds));
                graceRow.Visibility = profile.NoStopLossTrader ? Visibility.Collapsed : Visibility.Visible;
                _cbNoStopTrader.Checked   += (_, __) => graceRow.Visibility = Visibility.Collapsed;
                _cbNoStopTrader.Unchecked += (_, __) => graceRow.Visibility = Visibility.Visible;
                body.Children.Add(graceRow);

                form.Children.Add(WrapInCard(body));
            }

            // ─── CARD: ADVANCED ───────────────────────────────────────────────
            {
                var body = new StackPanel();
                body.Children.Add(CardHeader("\u2699", "Advanced",
                    "Leave at defaults unless PSI feels too reactive or not reactive enough.",
                    "RESPONSE LEVEL controls how quickly repeated behavior patterns are flagged. Hard rule breaks (size limit, loss limit, etc.) always respond the same regardless of this setting.\n\nFine-tuning overrides let you adjust individual values. Leave blank to use the preset default.\n\nTest mode duration \u2014 while test mode is active (toggle in the Profile tab), baseline recording is paused."));

                // Response level label
                body.Children.Add(new TextBlock
                {
                    Text       = "Response level",
                    FontSize   = 9,
                    FontFamily = Theme.Font,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = FgSub,
                    Margin     = new Thickness(14, 10, 14, 6),
                });

                // Segmented sensitivity control
                var senRow = new Grid { Margin = new Thickness(14, 0, 14, 10) };
                for (int i = 0; i < 3; i++)
                {
                    senRow.ColumnDefinitions.Add(new ColumnDefinition());
                    if (i < 2)
                        senRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(4) });
                }
                _senConservative = MakeSenPresetBtn("Sensitive",  "Flags patterns earlier");
                _senBalanced     = MakeSenPresetBtn("Balanced",   "For most traders");
                _senAggressive   = MakeSenPresetBtn("Relaxed",    "Slower to flag patterns");
                Grid.SetColumn(_senConservative, 0); senRow.Children.Add(_senConservative);
                Grid.SetColumn(_senBalanced,     2); senRow.Children.Add(_senBalanced);
                Grid.SetColumn(_senAggressive,   4); senRow.Children.Add(_senAggressive);
                _senConservative.MouseLeftButtonDown += (_, e) => { e.Handled = true; SetActiveSenPreset(_senConservative); };
                _senBalanced.MouseLeftButtonDown     += (_, e) => { e.Handled = true; SetActiveSenPreset(_senBalanced); };
                _senAggressive.MouseLeftButtonDown   += (_, e) => { e.Handled = true; SetActiveSenPreset(_senAggressive); };
                switch (profile.Sensitivity)
                {
                    case PsiSensitivity.Conservative: SetActiveSenPreset(_senConservative); break;
                    case PsiSensitivity.Aggressive:   SetActiveSenPreset(_senAggressive);   break;
                    default:                          SetActiveSenPreset(_senBalanced);      break;
                }
                body.Children.Add(senRow);
                body.Children.Add(RowDivider());

                // Expert Overrides collapsible row
                var overridesPanel = new StackPanel { Visibility = Visibility.Collapsed };
                var overridesChevron = new TextBlock
                {
                    Text              = "\u25B8",
                    FontSize          = 9,
                    Foreground        = FgSub,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin            = new Thickness(0, 0, 5, 0),
                };
                var overridesToggleRow = new StackPanel
                {
                    Orientation = Orientation.Horizontal,
                    Margin      = new Thickness(14, 8, 14, 4),
                    Cursor      = Cursors.Hand,
                };
                overridesToggleRow.Children.Add(overridesChevron);
                overridesToggleRow.Children.Add(new TextBlock
                {
                    Text              = "Fine-tuning",
                    FontSize          = 9,
                    FontFamily        = Theme.Font,
                    FontWeight        = FontWeights.SemiBold,
                    Foreground        = FgSub,
                    VerticalAlignment = VerticalAlignment.Center,
                });
                overridesToggleRow.Children.Add(new TextBlock
                {
                    Text              = "  \u2014 optional, leave blank to use the preset default",
                    FontSize          = 9,
                    Foreground        = new SolidColorBrush(Color.FromArgb(180, 154, 154, 158)),
                    VerticalAlignment = VerticalAlignment.Center,
                });
                bool overridesOpen = false;
                overridesToggleRow.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled     = true;
                    overridesOpen = !overridesOpen;
                    overridesPanel.Visibility   = overridesOpen ? Visibility.Visible : Visibility.Collapsed;
                    overridesChevron.Text       = overridesOpen ? "\u25BE" : "\u25B8";
                    overridesChevron.Foreground = overridesOpen ? FgSecondary : FgSub;
                };
                body.Children.Add(overridesToggleRow);

                // Override fields
                string recovVal  = profile.RecoverySpeedMultiplier > 0 ? profile.RecoverySpeedMultiplier.ToString("0.00") : "";
                string fprVal    = profile.FalsePositiveRate > 0       ? (profile.FalsePositiveRate * 100.0).ToString("0.#") : "";

                _txRecoverySpeed     = MakeTx(recovVal, 10);
                _txFalsePositiveRate = MakeTx(fprVal,   10);
                _txRecoverySpeed.Width     = 52;
                _txFalsePositiveRate.Width = 52;
                _txReversalFactor = MakeTx(Math.Round(profile.ReversalPenaltyFactor * 100).ToString(), 10);
                _txReversalFactor.Width = 52;

                var overrideContent = new StackPanel { Margin = new Thickness(14, 0, 14, 8) };
                overrideContent.Children.Add(OverrideRow("Alert sensitivity",
                    "1 = strict, fewer alerts · 10 = sensitive, more alerts · blank = preset default",
                    _txFalsePositiveRate));
                overrideContent.Children.Add(OverrideRow("Recovery speed",
                    "How quickly composure recovers · < 1.0 = slower · 1.0 = default · > 1.0 = faster",
                    _txRecoverySpeed));
                overrideContent.Children.Add(OverrideRow("Direction flip penalty",
                    "Extra penalty for reversing position after a loss · 0 = off · 25 = default",
                    _txReversalFactor));
                overridesPanel.Children.Add(overrideContent);
                body.Children.Add(overridesPanel);

                bool anyOverrideSet = profile.FalsePositiveRate > 0 ||
                                      profile.RecoverySpeedMultiplier > 0 ||
                                      profile.ReversalPenaltyFactor > 0;
                if (anyOverrideSet)
                {
                    overridesOpen               = true;
                    overridesPanel.Visibility   = Visibility.Visible;
                    overridesChevron.Text       = "\u25BE";
                    overridesChevron.Foreground = FgSecondary;
                }
                body.Children.Add(RowDivider());
                _txTestModeMin = MakeTx(profile.TestModeMinutes.ToString(), 10);
                _txTestModeMin.Width         = 42;
                _txTestModeMin.TextAlignment = System.Windows.TextAlignment.Center;
                var tmBody = new StackPanel { Margin = new Thickness(14, 6, 14, 10) };
                tmBody.Children.Add(OverrideRow("Test mode duration",
                    "Minutes before test mode turns off automatically (1–480)", _txTestModeMin));
                if (profile.IsTestModeActive)
                {
                    tmBody.Children.Add(new TextBlock
                    {
                        Text       = $"Test Mode is currently active — {profile.TestModeRemainingMinutes} min remaining.",
                        FontSize   = 9,
                        Foreground = new SolidColorBrush(Color.FromRgb(230, 165, 90)),
                        Margin     = new Thickness(0, 2, 0, 0),
                    });
                }
                body.Children.Add(tmBody);
                form.Children.Add(WrapInCard(body));
            }

            // ── Redistribute the built cards into a responsive 2-column grid ──
            // The card-building blocks above each appended one WrapInCard(...) to
            // `form`.  We do NOT touch their internals; we only move the finished
            // card Borders out of the single vertical stack and lay them across
            // two columns (left/right gutter), masonry-style by index.  This keeps
            // every binding, handler and field wiring exactly as constructed.
            var builtCards = new List<UIElement>();
            foreach (UIElement child in form.Children)
                builtCards.Add(child);
            form.Children.Clear(); // detach so cards can be re-parented below

            var colLeft  = new StackPanel();
            var colRight = new StackPanel();
            for (int i = 0; i < builtCards.Count; i++)
                (i % 2 == 0 ? colLeft : colRight).Children.Add(builtCards[i]);

            var twoCol = new Grid { Margin = new Thickness(14, 10, 14, 16) };
            twoCol.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            twoCol.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(14) }); // gutter
            twoCol.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            Grid.SetColumn(colLeft,  0); twoCol.Children.Add(colLeft);
            Grid.SetColumn(colRight, 2); twoCol.Children.Add(colRight);

            scroll.Content = twoCol;
            dock.Children.Add(scroll); // LastChildFill = fills remaining height

            card.Child = dock;
            Content    = outer;
        }

        // =====================================================================
        // Apply
        // =====================================================================

        private void OnApply()
        {
            HideErr();
            bool sessionEnabled = _cbSessionEnabled?.IsChecked == true;
            int sh = 0, sm = 0, eh = 23, em = 59; // safe defaults when window disabled
            if (sessionEnabled)
            {
                if (!PI(_txStartH, 0, 23, out sh)) return;
                if (!PI(_txStartM, 0, 59, out sm)) return;
                if (!PI(_txEndH,   0, 23, out eh)) return;
                if (!PI(_txEndM,   0, 59, out em)) return;
                if (new TimeSpan(sh, sm, 0) >= new TimeSpan(eh, em, 0))
                { ShowErr("Session start must be earlier than session end."); return; }
            }

            if (!PD(_txSizeMin,  0.01, 9999, out double sMin)) return;
            if (!PD(_txSizeMax,  0.01, 9999, out double sMax)) return;
            if (sMin > sMax) { ShowErr("Size Min cannot exceed Size Max."); return; }

            if (!PI(_txSlMax,    1,  9999, out int slMax))   return;
            if (!PI(_txFreqMin,  1,  9999, out int fMin))    return;
            if (!PI(_txFreqMax,  1,  9999, out int fMax))    return;
            if (fMin > fMax) { ShowErr("Frequency Min cannot exceed Max."); return; }

            if (!PI(_txMaxHold,      1, 1440, out int maxH))  return;
            // [Axiom A4] Repurposed: this row now controls the cold-start
            // inter-trade-gap prior (ColdStartInterTradeGapPriorSec), not
            // the obsolete MaxReentrySeconds.  The MM:SS widget is kept
            // because the range (5 s – 3600 s) matches the old one.
            if (!PI(_txReentryMin,   0,   60, out int rMin))  return;
            if (!PI(_txRentrySec,    0,   59, out int rSec))  return;
            int coldStartGapSec = rMin * 60 + rSec;
            if (coldStartGapSec < 5)   coldStartGapSec = 5;
            if (coldStartGapSec > 3600) coldStartGapSec = 3600;

            if (!PD(_txReversalFactor, 0, 100, out double reversalPct)) return;
            bool noStopTrader = _cbNoStopTrader.IsChecked == true;

            int graceSec = _profile.NoStopGraceSeconds;
            if (!noStopTrader && !PI(_txGraceSeconds, 5, 120, out graceSec)) return;

            // Soft cross-field warning (non-blocking)
            int sessionMins = (eh * 60 + em) - (sh * 60 + sm);
            if (maxH * fMax > sessionMins)
                ShowWarn($"Note: Max hold ({maxH} min) × Max trades ({fMax}) = {maxH * fMax} min, which exceeds your session length ({sessionMins} min). Early PSI estimates may be less accurate until real data is collected.");

            _profile.SessionWindowEnabled = sessionEnabled;
            _profile.SessionStartHour    = sh;   _profile.SessionStartMinute  = sm;
            _profile.SessionEndHour      = eh;   _profile.SessionEndMinute    = em;
            _profile.SizeMin             = sMin; _profile.SizeMax             = sMax;
            _profile.SlTicksMax          = slMax;
            _profile.TradesPerSessionMin = fMin; _profile.TradesPerSessionMax = fMax;
            _profile.MaxHoldMinutes      = maxH;
            _profile.ColdStartInterTradeGapPriorSec = coldStartGapSec;
            _profile.ReversalPenaltyFactor = reversalPct / 100.0;
            _profile.NoStopLossTrader      = noStopTrader;
            if (!noStopTrader) _profile.NoStopGraceSeconds = graceSec;

            // Risk limits — toggle off → 0 (disabled); toggle on → parse field
            double maxDailyLoss = 0.0;
            if (_cbMaxDailyLossEnabled?.IsChecked == true && !string.IsNullOrWhiteSpace(_txMaxDailyLoss.Text))
                if (!PD(_txMaxDailyLoss, 0, 1_000_000, out maxDailyLoss)) return;
            _profile.MaxDailyLossUsd = maxDailyLoss;

            int pauseN = 0;
            if (_cbPauseAfterNLossesEnabled?.IsChecked == true && !string.IsNullOrWhiteSpace(_txPauseAfterNLosses.Text))
                if (!PI(_txPauseAfterNLosses, 0, 100, out pauseN)) return;
            _profile.PauseAfterNLosses = pauseN;

            // Bug 3: if Test Mode is currently active and duration changed, restart timer
            if (PI(_txTestModeMin, 1, 480, out int tmMin))
            {
                bool wasActive = _profile.IsTestModeActive;
                _profile.TestModeMinutes = tmMin;
                if (wasActive) _profile.ActivateTestMode();
            }

            // ── Advanced: Sensitivity preset ──
            if (_activeSenPreset == _senConservative)
                _profile.Sensitivity = PsiSensitivity.Conservative;
            else if (_activeSenPreset == _senAggressive)
                _profile.Sensitivity = PsiSensitivity.Aggressive;
            else
                _profile.Sensitivity = PsiSensitivity.Balanced;

            // ── Advanced: Override fields (blank = -1 = use preset default) ──
            if (string.IsNullOrWhiteSpace(_txFalsePositiveRate.Text))
                _profile.FalsePositiveRate = -1;
            else
            {
                double pct = PD_Val(_txFalsePositiveRate, 1, 10, -1);
                _profile.FalsePositiveRate = pct > 0 ? pct / 100.0 : -1;
            }

            // NakedPositionPenalty and SessionWindowPenalty are deprecated (removed
            // from UI 2026-04-21); keep the profile-field values unchanged so
            // existing saved profiles remain loadable without data loss.

            _profile.RecoverySpeedMultiplier = string.IsNullOrWhiteSpace(_txRecoverySpeed.Text)
                ? -1 : PD_Val(_txRecoverySpeed, 0.25, 4.0, -1);

            _profile.MonitoredAccountNames.Clear();
            bool allChecked = true;
            foreach (var cb in _accountChecks)
            {
                if (cb.IsChecked == true)
                    _profile.MonitoredAccountNames.Add(cb.Content as string ?? "");
                else
                    allChecked = false;
            }
            if (allChecked) _profile.MonitoredAccountNames.Clear();

            // NOTE: StrategyProfile.Weight* fields are legacy (deprecated in
            // v1.1, ignored by the engine's Euclidean-norm aggregator).  We do
            // NOT overwrite them here — this preserves whatever values were
            // in the user's saved profile XML for backward compatibility and
            // avoids silent data loss on save.

            _profile.SaveToFile(_onError);

            ShowSuccess("Settings saved.");

            // Give the user 1.2 s to see the confirmation before closing.
            var closeTimer = new System.Windows.Threading.DispatcherTimer
            {
                Interval = TimeSpan.FromMilliseconds(1200)
            };
            closeTimer.Tick += (_, __) => { closeTimer.Stop(); Close(); };
            closeTimer.Start();
        }

        // =====================================================================
        // Presets
        // =====================================================================

        // (Dimension-weight preset methods removed in v1.1 — see header note.
        //  Engine-sensitivity preset handling lives in SetActiveSenPreset below.)

        private void SetActiveSenPreset(Border btn)
        {
            if (_activeSenPreset != null) _activeSenPreset.Background = BgSurface;
            _activeSenPreset = btn;
            if (_activeSenPreset != null) _activeSenPreset.Background = BgAccent;
        }

        private static FrameworkElement OverrideRow(string label, string hint, TextBox field)
        {
            var g = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var labelSP = new StackPanel();
            labelSP.Children.Add(new TextBlock
            {
                Text       = label,
                FontSize   = 11,
                Foreground = new SolidColorBrush(Color.FromRgb(229, 229, 234)),
                FontFamily = Theme.Font,
            });
            labelSP.Children.Add(new TextBlock
            {
                Text       = hint,
                FontSize   = 9,
                Foreground = new SolidColorBrush(Color.FromRgb(142, 142, 147)),
                FontFamily = Theme.Font,
            });
            Grid.SetColumn(labelSP, 0); g.Children.Add(labelSP);
            Grid.SetColumn(field,   1); g.Children.Add(field);
            return g;
        }

        // (Weight-preset helpers removed in v1.1.  MatchPreset / WMatch /
        //  UpdateWeightLabels / UpdateBudgetLabel / FmtPct no longer needed —
        //  the engine does not use per-dimension weights.)

        // =====================================================================
        // Account filter
        // =====================================================================

        private void PopulateAccounts(List<string> accounts)
        {
            _accountChecks.Clear();
            _accPanel.Children.Clear();

            var accList = accounts ?? new List<string>();
            if (accList.Count == 0)
            {
                _accPanel.Children.Add(new TextBlock
                {
                    Text       = "No active accounts found. Connect a trading account, then click Refresh.",
                    FontSize   = 10,
                    Foreground = FgHint,
                    Margin     = new Thickness(16, 4, 14, 10),
                    TextWrapping = TextWrapping.Wrap,
                });
                return;
            }

            foreach (string name in accList)
            {
                bool mon = _profile.MonitoredAccountNames == null ||
                           _profile.MonitoredAccountNames.Count == 0 ||
                           _profile.MonitoredAccountNames.Contains(name);
                var cb = new CheckBox
                {
                    Content    = name,
                    IsChecked  = mon,
                    Foreground = FgPrimary,
                    FontSize   = 12,
                    Margin     = new Thickness(16, 6, 14, 6),
                };
                _accountChecks.Add(cb);
                _accPanel.Children.Add(cb);
            }
        }

        private void FilterAccounts(string q)
        {
            foreach (var cb in _accountChecks)
            {
                string n = (cb.Content as string) ?? "";
                cb.Visibility = (q.Length == 0 ||
                                 n.IndexOf(q, StringComparison.OrdinalIgnoreCase) >= 0)
                    ? Visibility.Visible : Visibility.Collapsed;
            }
        }

        private static void SetPlaceholder(TextBox tb)
        {
            var tag = (string)tb.Tag;
            tb.Text       = tag;
            tb.Foreground = FgHint;
            tb.GotFocus   += (_, __) =>
            {
                if (tb.Text == (string)tb.Tag) { tb.Text = ""; tb.Foreground = FgPrimary; }
            };
            tb.LostFocus += (_, __) =>
            {
                if (string.IsNullOrEmpty(tb.Text)) { tb.Text = tag; tb.Foreground = FgHint; }
            };
        }

        // =====================================================================
        // Validation
        // =====================================================================

        private bool PI(TextBox tb, int lo, int hi, out int v)
        {
            tb.BorderBrush = BorderNormal;
            if (int.TryParse(tb.Text.Trim(), out v) && v >= lo && v <= hi) return true;
            tb.BorderBrush = ErrBrush;
            ShowErr($"'{tb.Text}' — expected a whole number {lo}–{hi}.");
            return false;
        }

        private bool PD(TextBox tb, double lo, double hi, out double v)
        {
            tb.BorderBrush = BorderNormal;
            if (double.TryParse(tb.Text.Trim(), out v) && v >= lo && v <= hi) return true;
            tb.BorderBrush = ErrBrush;
            ShowErr($"'{tb.Text}' — expected a number {lo}–{hi}.");
            return false;
        }

        private double PD_Val(TextBox tb, double lo, double hi, double fallback)
        {
            if (double.TryParse(tb.Text.Trim(), out double v) && v >= lo && v <= hi)
                return v;
            return fallback;
        }

        private void ShowErr(string m)
        {
            _errBanner.Foreground = ErrBrush;
            _errBanner.Text       = "⚠  " + m;
            _errBanner.Visibility = Visibility.Visible;
        }

        private void ShowWarn(string m)
        {
            _errBanner.Foreground = new SolidColorBrush(Color.FromRgb(255, 214, 0));
            _errBanner.Text       = "ℹ  " + m;
            _errBanner.Visibility = Visibility.Visible;
        }

        private void ShowSuccess(string m)
        {
            _errBanner.Foreground = new SolidColorBrush(Color.FromRgb(91, 201, 140)); // Apple green
            _errBanner.Text       = "✓  " + m;
            _errBanner.Visibility = Visibility.Visible;
        }

        private void HideErr() => _errBanner.Visibility = Visibility.Collapsed;

        // =====================================================================
        // =====================================================================
        // Palette  —  Apple dark system  (#1C1C1E family)
        // =====================================================================

        private static readonly Brush FgPrimary   = Theme.FgPrimary;
        private static readonly Brush FgSecondary = Theme.FgSecondary;
        private static readonly Brush FgHint      = Theme.FgHint;
        private static readonly Brush FgAccent    = Theme.Accent;
        private static readonly Brush BgField     = Theme.BgElevated;
        private static readonly Brush BgSurface   = Theme.BgCard;
        private static readonly Brush BgAccent    = Theme.Accent;
        private static readonly Brush BorderNormal = Theme.Border;
        private static readonly Brush ErrBrush    = new SolidColorBrush(Color.FromRgb(255,  69,  58)); // #FF453A

        // =====================================================================
        // Title bar
        // =====================================================================

        private Border BuildTitleBar()
        {
            var bg = new Border
            {
                Background = Theme.BgCard, // #2C2C2E
                Height     = 34,
            };
            var cols = new Grid();
            cols.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            cols.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var lbl = new Label
            {
                Content           = "PSI Monitor  ·  Strategy profile",
                FontSize          = 9,
                FontFamily        = Theme.Font,
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Padding           = new Thickness(12, 0, 0, 0),
            };

            var x = new Label
            {
                Content                    = "✕",
                FontSize                   = 11,
                Width                      = 30,
                Foreground                 = FgSecondary,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                VerticalContentAlignment   = VerticalAlignment.Center,
                Padding                    = new Thickness(0),
                Cursor                     = Cursors.Hand,
            };
            x.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                Close();
            };
            x.MouseEnter          += (_, __) => x.Foreground = FgPrimary;
            x.MouseLeave          += (_, __) => x.Foreground = FgSecondary;

            Grid.SetColumn(lbl, 0); cols.Children.Add(lbl);
            Grid.SetColumn(x,   1); cols.Children.Add(x);
            bg.Child = cols;

            cols.MouseLeftButtonDown += (_, e) =>
            {
                if (!e.Handled && e.ButtonState == MouseButtonState.Pressed) DragMove();
            };
            return bg;
        }

        // =====================================================================
        // Widget factories
        // =====================================================================

        // ── Section row with help icon ────────────────────────────────────────
        private static UIElement SectionRow(string title, string tip)
        {
            var sp = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 20, 0, 8),
            };
            sp.Children.Add(new TextBlock
            {
                Text              = title,
                FontSize          = 10,
                FontFamily        = Theme.Font,
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgSecondary,  // muted Apple-style section header
                VerticalAlignment = VerticalAlignment.Center,
            });
            sp.Children.Add(HelpBadge(tip));
            return sp;
        }

        // ── Help badge ────────────────────────────────────────────────────────
        // Uses a Popup (not ToolTip) for reliable display in custom-chrome windows.
        private static Border HelpBadge(string tipText)
        {
            var inner = new TextBlock
            {
                Text                = "?",
                FontSize            = 9,
                FontWeight          = FontWeights.Bold,
                Foreground          = FgAccent,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
            };

            var badge = new Border
            {
                Width             = 16,
                Height            = 16,
                CornerRadius      = new CornerRadius(Theme.R2),
                Background        = new SolidColorBrush(Color.FromArgb(40, 16, 185, 129)),
                BorderBrush       = new SolidColorBrush(Color.FromArgb(80, 16, 185, 129)),
                BorderThickness   = new Thickness(1),
                Margin            = new Thickness(7, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center,
                Cursor            = Cursors.Help,
                Child             = inner,
            };

            // Popup tooltip — guaranteed to render on top in borderless windows
            var tipContent = new Border
            {
                Background      = Theme.BgElevated,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(55, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(Theme.R2),
                Padding         = new Thickness(13, 10, 13, 11),
                MaxWidth        = 320,
                Child = new TextBlock
                {
                    Text         = tipText,
                    TextWrapping = TextWrapping.Wrap,
                    FontSize     = 11,
                    FontFamily   = Theme.Font,
                    Foreground   = new SolidColorBrush(Color.FromRgb(245, 245, 247)),
                    LineHeight   = 18,
                },
            };

            var popup = new Popup
            {
                Child              = tipContent,
                Placement          = PlacementMode.Mouse,
                HorizontalOffset   = 10,
                VerticalOffset     = 16,
                AllowsTransparency = true,
                StaysOpen          = true,
                IsHitTestVisible   = false,
            };

            badge.MouseEnter += (_, __) =>
            {
                badge.Background = new SolidColorBrush(Color.FromArgb(75, 16, 185, 129));
                inner.Foreground = FgPrimary;
                popup.IsOpen     = true;
            };
            badge.MouseLeave += (_, __) =>
            {
                badge.Background = new SolidColorBrush(Color.FromArgb(40, 16, 185, 129));
                inner.Foreground = FgAccent;
                popup.IsOpen     = false;
            };
            return badge;
        }

        // ── Field label ───────────────────────────────────────────────────────
        private static TextBlock FieldLbl(string t) => new TextBlock
        {
            Text       = t,
            FontSize   = 10,
            FontFamily = Theme.Font,
            Foreground = FgSecondary,
            Margin     = new Thickness(0, 0, 0, 5),
        };

        // ── HH:MM ─────────────────────────────────────────────────────────────
        private static UIElement HhMm(string hh, string mm,
                                      out TextBox txH, out TextBox txM)
        {
            var g = Col3(20);
            txH = MakeTx(hh); txM = MakeTx(mm);
            var c = Colon();
            Grid.SetColumn(txH, 0); g.Children.Add(txH);
            Grid.SetColumn(c,   1); g.Children.Add(c);
            Grid.SetColumn(txM, 2); g.Children.Add(txM);
            return Margin4(g);
        }

        // ── MM:SS ─────────────────────────────────────────────────────────────
        private static UIElement MmSs(string mm, string ss,
                                      out TextBox txM, out TextBox txS)
        {
            var outer = new Grid { Margin = new Thickness(0, 3, 0, 4) };
            outer.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            outer.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(20) });
            outer.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            outer.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(65) });

            txM = MakeTx(mm); txS = MakeTx(ss);
            var c = Colon();
            var lbl = new Label
            {
                Content           = "min : sec",
                FontSize          = 9,
                Foreground        = FgHint,
                VerticalAlignment = VerticalAlignment.Center,
                Padding           = new Thickness(6, 0, 0, 0),
            };

            Grid.SetColumn(txM, 0); outer.Children.Add(txM);
            Grid.SetColumn(c,   1); outer.Children.Add(c);
            Grid.SetColumn(txS, 2); outer.Children.Add(txS);
            Grid.SetColumn(lbl, 3); outer.Children.Add(lbl);
            return outer;
        }

        // ── Min / Max range row ───────────────────────────────────────────────
        private static UIElement RangeRow(string la, string va, string lb, string vb,
                                          string unit, out TextBox txA, out TextBox txB)
        {
            var g = new Grid { Margin = new Thickness(0, 0, 0, 4) };
            g.ColumnDefinitions.Add(new ColumnDefinition());
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(14) });
            g.ColumnDefinitions.Add(new ColumnDefinition());

            var left = new StackPanel();
            left.Children.Add(FieldLbl(la + "  (" + unit + ")"));
            txA = MakeTx(va);
            left.Children.Add(txA);

            var right = new StackPanel();
            right.Children.Add(FieldLbl(lb + "  (" + unit + ")"));
            txB = MakeTx(vb);
            right.Children.Add(txB);

            Grid.SetColumn(left,  0); g.Children.Add(left);
            Grid.SetColumn(right, 2); g.Children.Add(right);
            return g;
        }

        // ── Single field with unit label ──────────────────────────────────────
        private static UIElement UnitField(string label, string value,
                                           string unit, out TextBox tx)
        {
            var sp = new StackPanel { Margin = new Thickness(0, 0, 0, 4) };
            sp.Children.Add(FieldLbl(label));

            var g = new Grid();
            g.ColumnDefinitions.Add(
                new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            tx = MakeTx(value);
            var ul = new Label
            {
                Content           = unit,
                FontSize          = 9,
                Foreground        = FgHint,
                VerticalAlignment = VerticalAlignment.Center,
                Padding           = new Thickness(8, 0, 0, 0),
            };

            Grid.SetColumn(tx, 0); g.Children.Add(tx);
            Grid.SetColumn(ul, 1); g.Children.Add(ul);
            sp.Children.Add(g);
            return sp;
        }

        // (SliderRow and MakePresetBtn helpers removed in v1.1 — weight sliders
        //  and dimension-style preset buttons are no longer part of the UI.
        //  MakeSenPresetBtn below continues to serve the sensitivity preset row.)

        // ── Preset button (engine-sensitivity group) ──────────────────────────
        // Uses _activeSenPreset for its active check so hover doesn't override highlight.
        private Border MakeSenPresetBtn(string text, string subtitle = null)
        {
            var inner = new StackPanel { Margin = new Thickness(8, 6, 8, 6) };
            inner.Children.Add(new TextBlock
            {
                Text                = text,
                FontSize            = 8,
                FontFamily          = Theme.Font,
                FontWeight          = FontWeights.SemiBold,
                Foreground          = FgPrimary,
                TextAlignment       = System.Windows.TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
            });
            if (!string.IsNullOrEmpty(subtitle))
                inner.Children.Add(new TextBlock
                {
                    Text                = subtitle,
                    FontSize            = 8,
                    FontFamily          = Theme.Font,
                    Foreground          = new SolidColorBrush(Color.FromArgb(160, 200, 200, 205)),
                    TextAlignment       = System.Windows.TextAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    Margin              = new Thickness(0, 1, 0, 0),
                    TextWrapping        = TextWrapping.Wrap,
                });

            var btn = new Border
            {
                Background      = BgSurface,
                CornerRadius    = new CornerRadius(Theme.R1),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Child           = inner,
                Cursor          = Cursors.Hand,
            };

            btn.MouseEnter += (_, __) =>
            {
                if (btn != _activeSenPreset)
                    btn.Background = new SolidColorBrush(Color.FromRgb(58, 58, 60));
            };
            btn.MouseLeave += (_, __) =>
            {
                if (btn != _activeSenPreset) btn.Background = BgSurface;
            };
            return btn;
        }

        // ── Action button ─────────────────────────────────────────────────────
        private static Border MakeActionBtn(string text, Brush bg)
        {
            // Dark ink on a light/emerald fill (never white-on-green); light text on dark fills.
            Color bc = Theme.ColorOf(bg);
            Brush fg = (0.299 * bc.R + 0.587 * bc.G + 0.114 * bc.B) > 110 ? Theme.AccentInk : FgPrimary;
            var lbl = new Label
            {
                Content                    = text,
                FontSize                   = 11,
                FontFamily                 = Theme.Font,
                FontWeight                 = FontWeights.SemiBold,
                Foreground                 = fg,
                HorizontalContentAlignment = HorizontalAlignment.Center,
                Padding                    = new Thickness(0, 9, 0, 9),
            };
            var btn = new Border
            {
                Background      = bg,
                CornerRadius    = new CornerRadius(Theme.R2),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Child           = lbl,
                Cursor          = Cursors.Hand,
            };
            btn.MouseEnter += (_, __) => btn.Opacity = 0.80;
            btn.MouseLeave += (_, __) => btn.Opacity = 1.0;
            Ui.WireLift(btn, 1.5);
            return btn;
        }

        // ── Resize zone (transparent hit target) ─────────────────────────────
        private static Border ResizeZone(Cursor cursor, Action onDown)
        {
            var b = new Border
            {
                // Use a 1-alpha brush so the element still participates in hit testing
                Background = new SolidColorBrush(Color.FromArgb(1, 0, 0, 0)),
                Cursor     = cursor,
            };
            b.MouseLeftButtonDown += (_, e) => { e.Handled = true; onDown(); };
            return b;
        }

        // ── TextBox ───────────────────────────────────────────────────────────
        private static TextBox MakeTx(string value, double fs = 13) => new TextBox
        {
            Text            = value,
            FontSize        = fs,
            FontFamily      = Theme.Font,
            Foreground      = FgPrimary,
            Background      = BgField,
            BorderBrush     = BorderNormal, // same color as BgField → invisible; turns red on error
            BorderThickness = new Thickness(1),
            Padding         = new Thickness(9, 7, 9, 7),
            VerticalContentAlignment = VerticalAlignment.Center,
            CaretBrush      = FgPrimary,
        };

        // (MakeSlider helper removed in v1.1 — no sliders in the settings UI.)

        // ── Tiny helpers ──────────────────────────────────────────────────────
        private static Grid Col3(double midWidth)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition());
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(midWidth) });
            g.ColumnDefinitions.Add(new ColumnDefinition());
            return g;
        }

        private static Border Margin4(UIElement child)
        {
            var b = new Border { Margin = new Thickness(0, 0, 0, 4), Child = (FrameworkElement)child };
            return b;
        }

        private static TextBlock Colon() => new TextBlock
        {
            Text              = ":",
            FontSize          = 15,
            FontWeight        = FontWeights.SemiBold,
            Foreground        = FgHint,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center,
            TextAlignment     = TextAlignment.Center,
            Margin            = new Thickness(0, -1, 0, 0),
        };

        // ── Reset-to-defaults helper ──────────────────────────────────────────
        private void LoadDefaultsIntoForm(StrategyProfile def)
        {
            _txStartH.Text = def.SessionStartHour.ToString("D2");
            _txStartM.Text = def.SessionStartMinute.ToString("D2");
            _txEndH.Text   = def.SessionEndHour.ToString("D2");
            _txEndM.Text   = def.SessionEndMinute.ToString("D2");

            _txSizeMin.Text = def.SizeMin.ToString();
            _txSizeMax.Text = def.SizeMax.ToString();

            _txSlMax.Text   = def.SlTicksMax.ToString();
            _txFreqMin.Text = def.TradesPerSessionMin.ToString();
            _txFreqMax.Text = def.TradesPerSessionMax.ToString();

            _txMaxHold.Text       = def.MaxHoldMinutes.ToString();
            _txReentryMin.Text    = (def.ColdStartInterTradeGapPriorSec / 60).ToString();
            _txRentrySec.Text     = (def.ColdStartInterTradeGapPriorSec % 60).ToString("D2");
            _txReversalFactor.Text = Math.Round(def.ReversalPenaltyFactor * 100).ToString();
            _txGraceSeconds.Text  = def.NoStopGraceSeconds.ToString();

            _cbNoStopTrader.IsChecked = def.NoStopLossTrader;

            if (_cbMaxDailyLossEnabled != null)
                _cbMaxDailyLossEnabled.IsChecked = def.MaxDailyLossUsd > 0;
            _txMaxDailyLoss.Text = def.MaxDailyLossUsd > 0 ? def.MaxDailyLossUsd.ToString("0") : "";

            if (_cbPauseAfterNLossesEnabled != null)
                _cbPauseAfterNLossesEnabled.IsChecked = def.PauseAfterNLosses > 0;
            _txPauseAfterNLosses.Text = def.PauseAfterNLosses > 0 ? def.PauseAfterNLosses.ToString() : "";

            _txTestModeMin.Text = def.TestModeMinutes.ToString();

            _txFalsePositiveRate.Text     = "";
            _txRecoverySpeed.Text         = "";

            // Dimension weights removed from UI in v1.1 — nothing to reset here.
            SetActiveSenPreset(_senBalanced);
        }

        // =====================================================================
        // Modern card-layout helpers
        // =====================================================================

        private static readonly SolidColorBrush ToggleOnBrush =
            new SolidColorBrush(Color.FromRgb(91, 201, 140));
        private static readonly SolidColorBrush ToggleOffBrush =
            new SolidColorBrush(Color.FromRgb(72, 72, 74));

        // Wraps any content in a rounded dark card.
        private static Border WrapInCard(UIElement content)
        {
            return new Border
            {
                Background      = Theme.BgElevated,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(28, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(Theme.R2),
                Margin          = new Thickness(0, 0, 0, 10),
                ClipToBounds    = true,
                Child           = content,
            };
        }

        // Header row inside a card (icon badge + title + subtitle + optional help badge).
        private UIElement CardHeader(string icon, string title, string subtitle, string tip = null)
        {
            var row = new Grid
            {
                Background = new SolidColorBrush(Color.FromArgb(18, 255, 255, 255)),
                MinHeight  = 40,
            };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(44) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            if (tip != null)
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            // Icon badge
            var iconBadge = new Border
            {
                Width               = 28,
                Height              = 28,
                CornerRadius        = new CornerRadius(Theme.R1),
                Background          = new SolidColorBrush(Color.FromArgb(45, 16, 185, 129)),
                VerticalAlignment   = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Child               = new TextBlock
                {
                    Text                = icon,
                    FontSize            = 12,
                    FontFamily          = new FontFamily("Segoe UI Symbol"),
                    Foreground          = new SolidColorBrush(FgAccentColor),
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                },
            };
            Grid.SetColumn(iconBadge, 0);
            row.Children.Add(iconBadge);

            // Text stack
            var textStack = new StackPanel
            {
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(0, 8, 8, 8),
            };
            textStack.Children.Add(new TextBlock
            {
                Text       = title,
                FontSize   = 11,
                FontFamily = Theme.Font, FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(FgPrimaryColor),
            });
            if (!string.IsNullOrEmpty(subtitle))
            {
                textStack.Children.Add(new TextBlock
                {
                    Text         = subtitle,
                    FontSize     = 9,
                    FontFamily   = Theme.Font,
                    Foreground   = FgSub,
                    TextWrapping = TextWrapping.Wrap,
                    Margin       = new Thickness(0, 2, 0, 0),
                });
            }
            Grid.SetColumn(textStack, 1);
            row.Children.Add(textStack);

            if (tip != null)
            {
                var badge = HelpBadge(tip);
                badge.Margin            = new Thickness(0, 0, 10, 0);
                badge.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetColumn(badge, 2);
                row.Children.Add(badge);
            }

            var wrapper = new StackPanel();
            wrapper.Children.Add(row);
            wrapper.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(20, 255, 255, 255)),
            });
            return wrapper;
        }

        // A labeled settings row: bold label + muted hint on the left, control on the right.
        private static UIElement SettingsRow(string label, string hint, UIElement control)
        {
            var grid = new Grid { MinHeight = 50 };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var textStack = new StackPanel
            {
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(14, 10, 8, 10),
            };
            textStack.Children.Add(new TextBlock
            {
                Text       = label,
                FontSize   = 12,
                FontFamily = Theme.Font, FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(FgPrimaryColor),
            });
            if (!string.IsNullOrEmpty(hint))
            {
                textStack.Children.Add(new TextBlock
                {
                    Text         = hint,
                    FontSize     = 9,
                    FontFamily   = Theme.Font,
                    Foreground   = FgSub,
                    TextWrapping = TextWrapping.Wrap,
                    Margin       = new Thickness(0, 2, 0, 0),
                });
            }
            Grid.SetColumn(textStack, 0);
            grid.Children.Add(textStack);

            var controlWrapper = new Border
            {
                VerticalAlignment   = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin              = new Thickness(8, 8, 14, 8),
                Child               = control,
            };
            Grid.SetColumn(controlWrapper, 1);
            grid.Children.Add(controlWrapper);

            return grid;
        }

        // Thin hairline divider between rows inside a card.
        private static Border RowDivider()
        {
            return new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(15, 255, 255, 255)),
                Margin     = new Thickness(14, 0, 0, 0),
            };
        }

        // Compact "value unit" input (TextBox + unit label side by side).
        private static UIElement InlineUnitField(string value, string unit, out TextBox tx)
        {
            var panel = new StackPanel { Orientation = Orientation.Horizontal };
            tx = new TextBox
            {
                Text                     = value,
                Width                    = 64,
                Background               = new SolidColorBrush(Color.FromRgb(58, 58, 60)),
                Foreground               = new SolidColorBrush(FgPrimaryColor),
                CaretBrush               = new SolidColorBrush(FgPrimaryColor),
                BorderBrush              = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness          = new Thickness(1),
                Padding                  = new Thickness(6, 5, 6, 5),
                FontFamily               = Theme.Font,
                FontSize                 = 12,
                TextAlignment            = System.Windows.TextAlignment.Center,
                VerticalContentAlignment = VerticalAlignment.Center,
            };
            panel.Children.Add(tx);
            panel.Children.Add(new TextBlock
            {
                Text              = "\u00A0" + unit,
                FontSize          = 10,
                FontFamily        = Theme.Font,
                Foreground        = FgSub,
                VerticalAlignment = VerticalAlignment.Center,
            });
            return panel;
        }

        // Compact Min/Max range control (no external labels).
        private static UIElement InlineRangeControl(string la, string va, string lb, string vb,
                                                     string unit, out TextBox txA, out TextBox txB)
        {
            var panel = new StackPanel { Orientation = Orientation.Horizontal };

            panel.Children.Add(new TextBlock
            {
                Text              = la + "\u00A0",
                FontSize          = 10,
                FontFamily        = Theme.Font,
                Foreground        = FgSub,
                VerticalAlignment = VerticalAlignment.Center,
            });
            txA = new TextBox
            {
                Text                     = va,
                Width                    = 46,
                Background               = new SolidColorBrush(Color.FromRgb(58, 58, 60)),
                Foreground               = new SolidColorBrush(FgPrimaryColor),
                CaretBrush               = new SolidColorBrush(FgPrimaryColor),
                BorderBrush              = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness          = new Thickness(1),
                Padding                  = new Thickness(4, 5, 4, 5),
                FontFamily               = Theme.Font,
                FontSize                 = 12,
                TextAlignment            = System.Windows.TextAlignment.Center,
                VerticalContentAlignment = VerticalAlignment.Center,
            };
            panel.Children.Add(txA);

            panel.Children.Add(new TextBlock
            {
                Text              = "\u00A0\u00A0" + lb + "\u00A0",
                FontSize          = 10,
                FontFamily        = Theme.Font,
                Foreground        = FgSub,
                VerticalAlignment = VerticalAlignment.Center,
            });
            txB = new TextBox
            {
                Text                     = vb,
                Width                    = 46,
                Background               = new SolidColorBrush(Color.FromRgb(58, 58, 60)),
                Foreground               = new SolidColorBrush(FgPrimaryColor),
                CaretBrush               = new SolidColorBrush(FgPrimaryColor),
                BorderBrush              = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness          = new Thickness(1),
                Padding                  = new Thickness(4, 5, 4, 5),
                FontFamily               = Theme.Font,
                FontSize                 = 12,
                TextAlignment            = System.Windows.TextAlignment.Center,
                VerticalContentAlignment = VerticalAlignment.Center,
            };
            panel.Children.Add(txB);

            panel.Children.Add(new TextBlock
            {
                Text              = "\u00A0" + unit,
                FontSize          = 10,
                FontFamily        = Theme.Font,
                Foreground        = FgSub,
                VerticalAlignment = VerticalAlignment.Center,
            });
            return panel;
        }

        // iOS-style toggle switch: track + thumb.  Caller wires click and updates.
        private static UIElement BuildToggleSwitch(bool isOn, out Border track, out Border thumb)
        {
            thumb = new Border
            {
                Width               = 18,
                Height              = 18,
                CornerRadius        = new CornerRadius(9),
                Background          = Brushes.White,
                VerticalAlignment   = VerticalAlignment.Center,
                HorizontalAlignment = isOn ? HorizontalAlignment.Right : HorizontalAlignment.Left,
            };
            track = new Border
            {
                Width           = 40,
                Height          = 22,
                CornerRadius    = new CornerRadius(11),
                Background      = isOn ? ToggleOnBrush : ToggleOffBrush,
                Padding         = new Thickness(2),
                Cursor          = Cursors.Hand,
                Child           = thumb,
            };
            return track;
        }

        // Color values usable in static contexts (parallel to the SolidColorBrush statics).
        private static readonly Color FgPrimaryColor   = Theme.ColorOf(Theme.FgPrimary);
        private static readonly Color FgSecondaryColor = Theme.ColorOf(Theme.FgSecondary);
        private static readonly Color FgAccentColor    = Theme.ColorOf(Theme.Accent);

        // Mid-level gray for secondary text in card rows — #9A9A9E gives ≈4.2:1 on #2C2C2E.
        private static readonly SolidColorBrush FgSub =
            new SolidColorBrush(Color.FromRgb(154, 154, 158));
    }
}
