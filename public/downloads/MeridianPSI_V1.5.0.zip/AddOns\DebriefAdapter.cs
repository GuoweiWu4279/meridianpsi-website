using System;
using System.Globalization;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Adapter: live SessionData (+ profile) -> DebriefData. Pure C# (no NT8
    /// types, no WPF) — the thin layer between the engine's data and the pure-WPF
    /// DebriefView. Derives everything from per-trade P&amp;L + size + the trader's
    /// declared limits; needs NO entry/stop prices, so it touches none of the
    /// sensitive trade-recording plumbing. PSI is never computed here.
    /// </summary>
    internal static class DebriefAdapter
    {
        public static DebriefData FromSession(SessionData session, StrategyProfile profile)
        {
            var d = new DebriefData();
            if (session == null) return d;

            int sizeMax = (profile != null && profile.SizeMax > 0) ? (int)Math.Round(profile.SizeMax) : 0;
            double dailyLimit = profile != null ? profile.MaxDailyLossUsd : 0;
            d.SizeMax = sizeMax;

            foreach (var p in session.PsiHistory) d.PsiSeries.Add(p.Psi);

            double lastPsi = -1, worstPerContractLoss = 0;
            DateTime firstTime = DateTime.MinValue;
            char label = 'A';
            foreach (var t in session.Trades)
            {
                if (!t.IsClosing) continue;
                lastPsi = t.Psi;
                if (firstTime == DateTime.MinValue) firstTime = t.Time;

                bool disc = sizeMax <= 0 || t.Size <= 0 || t.Size <= sizeMax;
                var dt = new DebriefTrade
                {
                    Label = label.ToString(),
                    TimeText = t.Time.ToString("HH:mm", CultureInfo.InvariantCulture),
                    Dir = t.Dir ?? "",
                    Size = t.Size,
                    EntryPrice = 0, ExitPrice = 0,   // not plumbed; view shows "—"
                    Pnl = Math.Round(t.Pnl, 0),
                    IsWin = t.IsWin,
                    Disciplined = disc,
                    Cell = disc ? (t.IsWin ? DebriefCell.Earned : DebriefCell.Variance)
                                : (t.IsWin ? DebriefCell.Luck : DebriefCell.Spiral),
                };
                d.Trades.Add(dt);
                label++;

                if (!t.IsWin && t.Size > 0)
                {
                    double perC = Math.Abs(t.Pnl) / t.Size;
                    if (perC > worstPerContractLoss) worstPerContractLoss = perC;
                }
            }

            foreach (var t in d.Trades)
            {
                d.NetPnl += t.Pnl;
                if (t.IsWin) d.Wins++;
                switch (t.Cell)
                {
                    case DebriefCell.Earned:   d.EarnedPnl   += t.Pnl; d.EarnedN++;   break;
                    case DebriefCell.Luck:     d.LuckPnl     += t.Pnl; d.LuckN++;     break;
                    case DebriefCell.Variance: d.VariancePnl += t.Pnl; d.VarianceN++; break;
                    default:                   d.SpiralPnl   += t.Pnl; d.SpiralN++;   break;
                }
            }
            d.TotalTrades = d.Trades.Count;
            d.WinRatePct = d.TotalTrades > 0 ? 100.0 * d.Wins / d.TotalTrades : 0;
            d.DisciplinedNetPnl = d.EarnedPnl + d.VariancePnl;
            d.FinalPsi = lastPsi >= 0 ? lastPsi : (session.PsiHistory.Count > 0 ? session.PsiHistory[session.PsiHistory.Count - 1].Psi : -1);
            d.DimScores = session.DimCumScore != null && session.DimCumScore.Length == 7 ? (double[])session.DimCumScore.Clone() : null;
            d.DateText = firstTime != DateTime.MinValue ? firstTime.ToString("MMMM d, yyyy", CultureInfo.InvariantCulture) : "";

            // verdict
            if (d.SpiralPnl < -0.01 && d.SpiralPnl <= d.DisciplinedNetPnl)
            { d.Verdict = "Discipline slipped today."; d.VerdictCell = DebriefCell.Spiral; }
            else if (d.LuckPnl > d.DisciplinedNetPnl && d.LuckPnl > 0)
            { d.Verdict = "Today's profit was mostly luck."; d.VerdictCell = DebriefCell.Luck; }
            else
            { d.Verdict = "You stayed disciplined today."; d.VerdictCell = DebriefCell.Earned; }

            d.VerdictSub = d.VerdictCell == DebriefCell.Luck
                ? "Most of your profit came from a trade that broke your own size rule — not from your edge."
                : d.VerdictCell == DebriefCell.Spiral
                    ? "Rule-breaks cost you more than your disciplined trades made."
                    : "Your profit came from following your own rules. This is the part that repeats.";

            // danger (worst rule-break by size, risk = size x worst per-contract loss)
            DebriefTrade worst = null;
            foreach (var t in d.Trades)
                if (!t.Disciplined && (worst == null || t.Size > worst.Size)) worst = t;

            if (worst != null && worstPerContractLoss > 0 && dailyLimit > 0)
            {
                double risk = Math.Round(worst.Size * worstPerContractLoss, 0);
                double pct = 100.0 * risk / dailyLimit;
                d.HasDanger = true;
                d.DangerTradeLabel = "Trade " + worst.Label + " · " + worst.Size + " contracts";
                d.DangerRisk = risk;
                d.DangerLimit = dailyLimit;
                d.DangerReward = worst.Pnl;
                d.DangerStopPts = 0;
                d.DangerCaption =
                    "Your worst loss today ran $" + worstPerContractLoss.ToString("0") + " per contract. On this " +
                    worst.Size + "-contract position that's $" + risk.ToString("0") + " of downside — " +
                    pct.ToString("0") + "% of your $" + dailyLimit.ToString("0") +
                    " daily limit, in a single trade. You weren't stopped — that was luck, not sizing.";
                d.OneFix = "Hard-cap your size at " + sizeMax + " contracts. Your disciplined trades netted " +
                    Money(d.DisciplinedNetPnl) + " cleanly — the size spikes are the only thing risking a red month.";
            }
            else
            {
                d.OneFix = sizeMax > 0
                    ? "Keep your size within " + sizeMax + " contracts — today you did, and it shows."
                    : "Set a max position size in Settings so Meridian can flag oversizing.";
            }

            return d;
        }

        private static string Money(double v) => (v >= 0 ? "+$" : "-$") + Math.Abs(v).ToString("0");
    }
}
