using System.Collections.Generic;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal sealed class PreSessionProt { public string Label, Value; }
    internal sealed class PreSessionLeak { public string Name, Freq; public int Sev; } // Sev: 0=high, 1=med

    /// <summary>
    /// Pure data for the Pre-Session Brief — a PULL surface (the trader chose to open it,
    /// before trading, calm). Its ONE job is to PRIME: surface the single
    /// highest-probability leak for today, confirm the guardrails are armed, and offer
    /// Start. No risk-rainbow, no composure scoring, no scolding — see UX_DESIGN_ROOT.md
    /// §2.2. Priming requires ONE thing, not twelve.
    /// </summary>
    internal sealed class PreSessionData
    {
        public string DateText;
        public bool   HasData;        // enough history to personalize the focus?

        // TODAY'S READ — the trader's current condition, promoted from a buried gray
        // footnote to a glanceable, color-coded signal (the #1 pre-market question:
        // "am I coming in sharp or fragile today?").
        public bool   HasComposure;   // do we have a 30-day composure read?
        public int    Composure30;    // 30-day average composure, 0-100
        public string ComposureRead;  // one-line context (e.g. weekday trend)

        public string FocusTitle;     // the ONE thing to watch today
        public string FocusDetail;    // the evidence + the action
        public List<string> AlsoWatch = new List<string>();  // ≤2 small, subordinate reminders
        public string StandingLine;   // optional single muted context line (null = omit)
        public List<PreSessionProt> Protections = new List<PreSessionProt>();

        // ── Home: read-band KPIs ──────────────────────────────────────────
        public bool   HasKpis;         // any month data to show in the read band?
        public int    LastComp;        // last session composure %  (-1 = none)
        public string LastDate;        // e.g. "Wed, Jun 3"
        public double NetMonthPnl;     // net P&L this month
        public int    MonthSessions;   // sessions this month
        public int    StableDays;      // sessions ≥ stable threshold this month

        // ── Home: info rail ───────────────────────────────────────────────
        public List<int> TrajSeries = new List<int>(); // recent composure series (sparkline)
        public int    TrajNow = -1;    // latest composure (rail headline number)
        public string TrajGrade;       // A+ .. D
        public string TrajDelta;       // e.g. "↓ 39 pts · trending down"
        public string LessonText;      // last debrief takeaway (null = omit card)
        public string LessonDate;      // e.g. "Jun 3 debrief"
        public List<PreSessionLeak> Leaks  = new List<PreSessionLeak>(); // "what wrecks you most"
        public List<string>         Ritual = new List<string>();         // pre-session checklist
    }
}
