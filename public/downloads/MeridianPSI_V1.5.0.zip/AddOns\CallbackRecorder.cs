// CallbackRecorder.cs   (schema v2 — comprehensive, landmine-driven capture)
//
// Records the REAL NinjaTrader callback stream to a JSONL file so it can be
// replayed / inspected offline.  The capture set is designed directly from the
// hard-won NT8 landmine log in ARCHITECTURE.md §11 (LANDMINE 1–14), so a single
// good Sim/Playback recording contains everything needed to diagnose any of the
// known classes of NT8-behaviour surprise without re-running NT8.
//
// WHY (the core fix for "passes tests but fails in NT8"):
//   The unit tests feed the engine inputs an AI ASSUMED NinjaTrader produces.
//   When the assumption is wrong the tests stay green and the add-on breaks live.
//   This records what NT8 ACTUALLY sends — and, crucially, the CONTEXT that makes
//   NT8's worst traps visible:
//     • seq + ts          → the real EVENT ORDERING (LANDMINE 3, 7, 9)
//     • tid + onMain       → main-thread vs background-thread (LANDMINE 7,10,11,13,14
//                            — off-main Globals.Now silently returns wall-clock)
//     • ntTime vs gNow vs ts → the time-DOMAIN mismatch in Playback
//                            (LANDMINE 8,10,11,14 — replay-time vs wall-clock)
//     • orderAction + dir + trackedDir → the Sell/BuyToCover ambiguity & ghost
//                            state (LANDMINE 1, 4, 5)
//     • orderState + orderType        → Working-vs-Filled bracket detection (LANDMINE 2, 9)
//     • operation (Add/Update/Remove) → new-position vs scale-in vs close (LANDMINE 3, 12)
//     • trackedQty vs event qty       → scale-in N-vs-(N-1) race (LANDMINE 7)
//
// CONTROL (zero UI, zero risk):
//   OFF unless a sentinel file `RECORD_ENABLED` exists in the TradeMonitorData
//   folder.  Start() is a no-op without it.  Create it to record, delete to stop.
//
// PURITY:  no NinjaTrader / WPF references — every NT8 value is passed in by the
//   caller — so this also compiles in the standalone testbench.  Every method is
//   wrapped so a recording failure can NEVER crash a trading callback.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using System.Threading;

namespace NinjaTrader.NinjaScript.AddOns
{
    public static class CallbackRecorder
    {
        public const int SchemaVersion = 2;

        private const int FlushIntervalSec = 60; // near-real-time streaming cadence

        private static readonly object _sync = new object();
        private static StreamWriter   _writer;
        private static string         _path;
        private static string         _dataDir;     // remembered so Roll() can reopen + drain
        private static long           _seq;
        private static DateTime       _lastFlushUtc; // last time the live file was streamed
        private static string         _source = "user"; // "dev" (RECORD_ENABLED sentinel) vs "user" (consent)
        private static bool           _acctCtxDone;  // account context emitted for the current file?

        public static bool   Enabled    { get; private set; }
        public static string ActivePath { get { lock (_sync) return _path; } }

        /// <summary>
        /// Opens a recording IF the `RECORD_ENABLED` sentinel exists in dataDir OR the
        /// user consented to the research program. <paramref name="mainThreadId"/> is
        /// recorded in the meta line so the offline inspector can classify every event
        /// as on-main / off-main. Never throws.
        ///
        /// On open it ALSO drains any previously-finished recordings that were never
        /// uploaded (NT8 crash, machine offline, shutdown-time upload killed mid-flight),
        /// so no consented session is ever silently lost.
        /// </summary>
        public static void Start(string dataDir, int mainThreadId)
        {
            try
            {
                if (string.IsNullOrEmpty(dataDir)) return;
                ResearchData.Init(dataDir);
                bool opened = false;
                lock (_sync)
                {
                    if (Enabled) return;
                    // Record when the dev sentinel exists OR the research program is ACTIVE
                    // (a backend endpoint+key are configured and the install hasn't opted out;
                    // consent is via the website terms, not an in-app toggle). With no endpoint
                    // configured ResearchData.Enabled is false → default = no recording.
                    bool sentinel = File.Exists(Path.Combine(dataDir, "RECORD_ENABLED"));
                    if (!sentinel && !ResearchData.Enabled) return;
                    // A dev sentinel means this is the founder's own test machine — tag the
                    // stream "dev" so those sessions are trivially excluded from the cohort.
                    _source = sentinel ? "dev" : "user";
                    _dataDir = dataDir;
                    opened = OpenNewLocked(dataDir);
                }
                if (opened) EmitMeta(mainThreadId);

                // Recover orphans from prior runs (crash / offline / shutdown race).
                ResearchUploader.DrainPending(Path.Combine(dataDir, "recordings"));
            }
            catch { /* never break startup */ }
        }

        /// <summary>
        /// Close the current recording and immediately open a fresh one — called at the
        /// product's authoritative SESSION boundary (TradeMonitor day-rollover archive),
        /// so that exactly one recording file == one trading session. The finished file
        /// is handed to the (gated) uploader at the moment the session ends, NOT deferred
        /// to NT8 shutdown. Never throws into the trading callback.
        /// </summary>
        public static void Roll(int mainThreadId)
        {
            try
            {
                string finished = null; bool reopened = false; string dir = _dataDir;
                lock (_sync)
                {
                    if (!Enabled) return;                 // nothing in progress → no-op
                    if (_writer != null) { try { _writer.Flush(); _writer.Dispose(); } catch { } }
                    finished = _path;
                    _writer = null; _path = null; Enabled = false;
                    if (!string.IsNullOrEmpty(dir))
                        reopened = OpenNewLocked(dir);
                }
                if (reopened) EmitMeta(mainThreadId);
                if (!string.IsNullOrEmpty(finished))
                    ResearchUploader.QueueUpload(finished);
            }
            catch { }
        }

        public static void Stop()
        {
            try
            {
                string finished;
                lock (_sync)
                {
                    if (_writer != null) { try { _writer.Flush(); _writer.Dispose(); } catch { } }
                    finished = _path;
                    _writer = null; _path = null; Enabled = false;
                }
                // Best-effort anonymized upload — a no-op unless the user consented AND an
                // endpoint is configured (ResearchUploader gates on ResearchData.Enabled).
                // If this upload doesn't finish before the process dies, the file is left
                // un-marked and DrainPending re-uploads it on next launch.
                if (!string.IsNullOrEmpty(finished))
                    ResearchUploader.QueueUpload(finished);
            }
            catch { }
        }

        // Opens a fresh recording file. Caller MUST hold _sync. Never emits (would
        // re-enter the lock) — caller emits meta after releasing the lock.
        private static bool OpenNewLocked(string dataDir)
        {
            string dir = Path.Combine(dataDir, "recordings");
            Directory.CreateDirectory(dir);
            _path   = Path.Combine(dir, "session_" + DateTime.Now.ToString("yyyyMMdd_HHmmss") + ".jsonl");
            _writer = new StreamWriter(_path, append: false) { AutoFlush = true };
            _seq    = 0;
            _lastFlushUtc = DateTime.UtcNow; // give the new file an interval to accumulate
            _acctCtxDone  = false;           // re-emit account context for this new file
            Enabled = true;
            return true;
        }

        private static void EmitMeta(int mainThreadId)
        {
            Emit("meta", null, b =>
            {
                Str(b, "schema", "v" + SchemaVersion);
                Str(b, "product", "MeridianPSI");
                Num(b, "mainThreadId", mainThreadId);
                Str(b, "source", _source);
                Str(b, "startedLocal", DateTime.Now.ToString("o"));
            });
        }

        /// <summary>
        /// Emit the account-type context ONCE per recording file. Carries only DERIVED,
        /// non-PII category fields (class / vendor / self-declared type / mode / source) —
        /// never the raw account name or number — so it is safe to upload and survives
        /// anonymization (which strips the raw "acct" elsewhere). Idempotent per file;
        /// the caller may invoke it on every fill. Never throws.
        /// </summary>
        public static void AccountContext(string mode, string acctClass, string vendor, string accountType)
        {
            try
            {
                lock (_sync) { if (!Enabled || _acctCtxDone) return; _acctCtxDone = true; }
                Emit("account", b =>
                {
                    Str(b, "mode", mode);
                    Str(b, "acctClass", acctClass);
                    Str(b, "vendor", vendor);
                    Str(b, "accountType", accountType);
                    Str(b, "source", _source);
                });
            }
            catch { }
        }

        // =====================================================================
        // Per-event context, shared by every capture method.
        //   onMain  = _clock.IsOnMainThread  (authoritative)
        //   mode    = TradingClock.InferMode(...).ToString()
        //   gNow    = NinjaTrader.Core.Globals.Now  (the value that silently
        //             differs by thread/mode — the heart of LANDMINE 8/10/11/14)
        // =====================================================================

        private static void Ctx(StringBuilder b, bool onMain, string mode, DateTime gNow)
        {
            Bool(b, "onMain", onMain);
            Str (b, "mode", mode);
            Time(b, "gNow", gNow);   // Globals.Now as the caller saw it
        }

        /// <summary>Raw fill exactly as NT8 delivered it (ground truth + context).</summary>
        public static void RawExecution(bool onMain, string mode, DateTime gNow,
                                        DateTime fillTime, DateTime orderTime,
                                        string account, string instrument, string marketPosition,
                                        double qty, double price, string orderAction,
                                        string orderState, string orderType, string orderName,
                                        string fromEntrySignal, string trackedDir, double trackedQty)
        {
            Emit("exec_raw", b =>
            {
                Ctx (b, onMain, mode, gNow);
                Time(b, "fillTime", fillTime);     // execution.Time (historical in Playback)
                Time(b, "orderTime", orderTime);   // order.Time  (LANDMINE 8: wall-clock in Playback)
                Str (b, "acct", account);
                Str (b, "instr", instrument);
                Str (b, "dir", marketPosition);
                Num (b, "qty", qty);
                Num (b, "price", price);
                Str (b, "orderAction", orderAction);   // Buy/Sell/BuyToCover/SellShort (LANDMINE 1)
                Str (b, "orderState", orderState);
                Str (b, "orderType", orderType);
                Str (b, "orderName", orderName);
                Str (b, "fromEntrySignal", fromEntrySignal);
                Str (b, "trackedDir", trackedDir);     // our state BEFORE this fill (LANDMINE 4/5 ghost)
                Num (b, "trackedQty", trackedQty);
            });
        }

        /// <summary>
        /// Derived engine inputs + resulting PSI + the post-fill position snapshots
        /// that were passed to ProcessExecution.  With these (and the profile config
        /// captured once via <see cref="ProfileSnapshot"/>), an offline replay is
        /// point-for-point exact, including the snapshot-driven dims D2/D5.
        /// </summary>
        public static void EngineExecution(bool onMain, string mode, DateTime gNow,
                                           DateTime fillTime, double pnl, double size, bool isWin,
                                           double holdSeconds, int fillDir, string exitKind,
                                           bool isRoundTripFinal, double roundTripPnl, double newPsi,
                                           IEnumerable<PositionSnapshot> postFillSnaps)
        {
            Emit("exec_engine", b =>
            {
                Ctx (b, onMain, mode, gNow);
                Time(b, "fillTime", fillTime);
                Num (b, "pnl", pnl);
                Num (b, "size", size);
                Bool(b, "isWin", isWin);
                Num (b, "holdSec", holdSeconds);
                Num (b, "fillDir", fillDir);
                Str (b, "exitKind", exitKind);
                Bool(b, "rtFinal", isRoundTripFinal);
                Num (b, "roundTripPnl", roundTripPnl);
                Num (b, "psi", newPsi);
                // Inline the snapshot array so replay reproduces D2/D5 exactly.
                b.Append("\"snaps\":[");
                if (postFillSnaps != null)
                {
                    bool any = false;
                    foreach (var s in postFillSnaps)
                    {
                        if (s == null) continue;
                        any = true;
                        b.Append('{');
                        Str (b, "key", s.Key);
                        Num (b, "upnl", s.UnrealizedPnl);
                        Num (b, "minUpnl", s.MinUnrealizedPnl);
                        Time(b, "entryTime", s.EntryTime);
                        Num (b, "holdSec", s.HoldSeconds);
                        Bool(b, "hasStop", s.HasStopOrder);
                        Num (b, "qty", s.Quantity);
                        if (b[b.Length - 1] == ',') b.Length -= 1;
                        b.Append("},");
                    }
                    if (any && b[b.Length - 1] == ',') b.Length -= 1;
                }
                b.Append("],");
            });
        }

        /// <summary>
        /// Entry-decision edge (OnLifecycleAdd).  This is the AUTHORITATIVE entry
        /// trigger — fires once per position open (NOT per partial fill) and drives
        /// D1 (revenge) + D7 (overtrading) + the session entry count.  ProcessExecution
        /// runs per partial fill but does NOT count entries; replaying only fills
        /// therefore leaves D1/D7 at zero.  Capturing this makes them replayable.
        /// </summary>
        public static void EngineEntry(bool onMain, string mode, DateTime gNow,
                                       DateTime entryTime, string posKey, double newPsi)
        {
            Emit("engine_entry", b =>
            {
                Ctx (b, onMain, mode, gNow);
                Time(b, "entryTime", entryTime);
                Str (b, "posKey", posKey);
                Num (b, "psi", newPsi);
            });
        }

        /// <summary>
        /// Position-poll timer tick (PsiPollTick → PollPositions).  This is the
        /// out-of-band driver that advances the continuous dims (D5 overstay, decay)
        /// BETWEEN fills.  Capturing it makes offline replay exact: replaying only
        /// fills leaves PSI higher than live because the live engine also ran these
        /// polls.  snaps + pollTime + result let replay re-invoke PollPositions.
        /// </summary>
        public static void EnginePoll(bool onMain, string mode, DateTime gNow,
                                      DateTime pollTime, double newPsi, bool nakedDetected,
                                      IEnumerable<PositionSnapshot> snaps)
        {
            Emit("engine_poll", b =>
            {
                Ctx (b, onMain, mode, gNow);
                Time(b, "pollTime", pollTime);
                Num (b, "psi", newPsi);
                Bool(b, "naked", nakedDetected);
                b.Append("\"snaps\":[");
                if (snaps != null)
                {
                    bool any = false;
                    foreach (var s in snaps)
                    {
                        if (s == null) continue;
                        any = true;
                        b.Append('{');
                        Str (b, "key", s.Key);
                        Num (b, "upnl", s.UnrealizedPnl);
                        Num (b, "minUpnl", s.MinUnrealizedPnl);
                        Time(b, "entryTime", s.EntryTime);
                        Num (b, "holdSec", s.HoldSeconds);
                        Bool(b, "hasStop", s.HasStopOrder);
                        Num (b, "qty", s.Quantity);
                        if (b[b.Length - 1] == ',') b.Length -= 1;
                        b.Append("},");
                    }
                    if (any && b[b.Length - 1] == ',') b.Length -= 1;
                }
                b.Append("],");
            });
        }

        /// <summary>
        /// One-shot capture of the StrategyProfile fields the engine + its config use,
        /// so an offline replay can rebuild an identical PsiEngineV2Config.FromProfile.
        /// Emit once, right after the engine is constructed.
        /// </summary>
        public static void ProfileSnapshot(string sensitivity, double recoverySpeedMult,
                                           double maxDailyLossUsd, int pauseAfterNLosses,
                                           int tradesPerSessionMin, int tradesPerSessionMax,
                                           double sizeMin, double sizeMax, int maxHoldMinutes,
                                           int slTicksMax, int noStopGraceSeconds, bool noStopLossTrader,
                                           bool sessionWindowEnabled, int sStartH, int sStartM,
                                           int sEndH, int sEndM, int coldStartGapSec,
                                           double reversalPenaltyFactor, double falsePositiveRate)
        {
            Emit("profile", b =>
            {
                Str (b, "sensitivity", sensitivity);
                Num (b, "recoverySpeedMult", recoverySpeedMult);
                Num (b, "maxDailyLossUsd", maxDailyLossUsd);
                Num (b, "pauseAfterNLosses", pauseAfterNLosses);
                Num (b, "tradesPerSessionMin", tradesPerSessionMin);
                Num (b, "tradesPerSessionMax", tradesPerSessionMax);
                Num (b, "sizeMin", sizeMin);
                Num (b, "sizeMax", sizeMax);
                Num (b, "maxHoldMinutes", maxHoldMinutes);
                Num (b, "slTicksMax", slTicksMax);
                Num (b, "noStopGraceSeconds", noStopGraceSeconds);
                Bool(b, "noStopLossTrader", noStopLossTrader);
                Bool(b, "sessionWindowEnabled", sessionWindowEnabled);
                Num (b, "sStartH", sStartH);  Num(b, "sStartM", sStartM);
                Num (b, "sEndH", sEndH);      Num(b, "sEndM", sEndM);
                Num (b, "coldStartGapSec", coldStartGapSec);
                Num (b, "reversalPenaltyFactor", reversalPenaltyFactor);
                Num (b, "falsePositiveRate", falsePositiveRate);
            });
        }

        /// <summary>Raw order-state change exactly as NT8 fired it.</summary>
        public static void RawOrder(bool onMain, string mode, DateTime gNow,
                                    DateTime orderTime, string account, string instrument,
                                    string orderId, string state, string orderAction, string orderType,
                                    double qty, double filled, double stopPrice, double limitPrice,
                                    string orderName)
        {
            Emit("order_raw", b =>
            {
                Ctx (b, onMain, mode, gNow);
                Time(b, "orderTime", orderTime);   // LANDMINE 8: wall-clock in Playback
                Str (b, "acct", account);
                Str (b, "instr", instrument);
                Str (b, "orderId", orderId);
                Str (b, "state", state);            // Initialized/Working/Filled/PartFilled/Cancelled
                Str (b, "orderAction", orderAction);
                Str (b, "orderType", orderType);    // StopMarket/StopLimit/Limit/Market (bracket detection)
                Num (b, "qty", qty);
                Num (b, "filled", filled);
                Num (b, "stop", stopPrice);
                Num (b, "limit", limitPrice);
                Str (b, "orderName", orderName);
            });
        }

        /// <summary>Raw position update — EVENT-snapshot fields, not the mutated Position object.</summary>
        public static void RawPosition(bool onMain, string mode, DateTime gNow,
                                       string operation, string account, string instrument,
                                       string marketPosition, double quantity, double avgPrice,
                                       double trackedQty)
        {
            Emit("position_raw", b =>
            {
                Ctx (b, onMain, mode, gNow);
                Str (b, "operation", operation);    // Add/Update/Remove (LANDMINE 3/12)
                Str (b, "acct", account);
                Str (b, "instr", instrument);
                Str (b, "dir", marketPosition);
                Num (b, "qty", quantity);           // event-snapshot qty
                Num (b, "avgPrice", avgPrice);
                Num (b, "trackedQty", trackedQty);  // our tracked qty (LANDMINE 7: N vs N-1 race)
            });
        }

        /// <summary>Account subscription / connection / reset markers (LANDMINE 12 bootstrap replay, LANDMINE 4 reset).</summary>
        public static void Marker(string name, bool onMain, string mode, DateTime gNow, string detail = null)
        {
            Emit("marker", b =>
            {
                Ctx(b, onMain, mode, gNow);
                Str(b, "name", name);
                if (detail != null) Str(b, "detail", detail);
            });
        }

        /// <summary>
        /// Lightweight, anonymous UI-usage event (a tab opened, a feature used). Rides the
        /// SAME recording stream as the trading capture, so it inherits the ENTIRE pipeline
        /// for free: the install's random anon id, the dev/user source tag, the consent /
        /// opt-out gate, the ~60 s streaming upload, and crash-safe re-send. A no-op unless a
        /// recording is active — which itself requires the research program enabled OR the
        /// dev sentinel — so an opted-out install logs nothing here either. UI-thread safe: a
        /// quick buffered append on infrequent, user-driven actions ONLY (never per-frame /
        /// hover / scroll / keystroke). Never throws into the UI.
        ///   area   = surface  ("nav","guard","journal","intel","patterns","profile"...)
        ///   action = verb     ("open","save","toggle","arm","customize_open","view_switch"...)
        ///   detail = optional  (the tab name, "on"/"off", a label) — NEVER free user text.
        /// </summary>
        public static void UiEvent(string area, string action, string detail = null)
        {
            try
            {
                Emit("ui", b =>
                {
                    Str(b, "area", area);
                    Str(b, "action", action);
                    if (detail != null) Str(b, "detail", detail);
                    Str(b, "source", _source);
                });
            }
            catch { /* telemetry must never affect the UI */ }
        }

        // =====================================================================
        // JSON line writer — manual, no dependency, never throws.
        // Common envelope adds: seq, ts(wall-clock UTC), tid(thread id).
        // =====================================================================

        private static void Emit(string type, Action<StringBuilder> body)
        {
            if (!Enabled) return;
            try
            {
                long seq = Interlocked.Increment(ref _seq);
                var b = new StringBuilder(220);
                b.Append('{');
                Num (b, "seq", seq);
                Str (b, "ts", DateTime.UtcNow.ToString("o"));   // wall-clock arrival order
                Num (b, "tid", Thread.CurrentThread.ManagedThreadId);
                Str (b, "type", type);
                if (body != null) body(b);
                if (b[b.Length - 1] == ',') b.Length -= 1;
                b.Append('}');
                string livePath;
                lock (_sync)
                {
                    if (_writer == null) return;
                    _writer.WriteLine(b.ToString());
                    livePath = _path;
                }
                // Near-real-time streaming: at most once per FlushIntervalSec, ship the
                // growing file to the (gated) uploader. Off the trading path — FlushActive
                // dispatches the actual upload to a background task and no-ops if disabled,
                // unchanged, or already busy. Decoupled from any "session end" detection.
                if (livePath != null && (DateTime.UtcNow - _lastFlushUtc).TotalSeconds >= FlushIntervalSec)
                {
                    _lastFlushUtc = DateTime.UtcNow;
                    ResearchUploader.FlushActive(livePath);
                }
            }
            catch { /* recording must never throw into a trading callback */ }
        }

        // Overload used only by the meta line (lets it skip the body cast clutter).
        private static void Emit(string type, object _unused, Action<StringBuilder> body) => Emit(type, body);

        private static void Str(StringBuilder b, string k, string v)
        {
            b.Append('"').Append(k).Append("\":");
            if (v == null) b.Append("null"); else b.Append('"').Append(Escape(v)).Append('"');
            b.Append(',');
        }

        private static void Num(StringBuilder b, string k, double v)
        {
            b.Append('"').Append(k).Append("\":");
            if (double.IsNaN(v) || double.IsInfinity(v)) b.Append("null");
            else b.Append(v.ToString("R", CultureInfo.InvariantCulture));
            b.Append(',');
        }

        private static void Bool(StringBuilder b, string k, bool v)
            => b.Append('"').Append(k).Append("\":").Append(v ? "true" : "false").Append(',');

        private static void Time(StringBuilder b, string k, DateTime v)
            => Str(b, k, v.ToString("o", CultureInfo.InvariantCulture));

        private static string Escape(string s)
        {
            if (s.IndexOfAny(new[] { '"', '\\', '\n', '\r', '\t' }) < 0) return s;
            var sb = new StringBuilder(s.Length + 8);
            foreach (char c in s)
            {
                switch (c)
                {
                    case '"':  sb.Append("\\\""); break;
                    case '\\': sb.Append("\\\\"); break;
                    case '\n': sb.Append("\\n");  break;
                    case '\r': sb.Append("\\r");  break;
                    case '\t': sb.Append("\\t");  break;
                    default:   sb.Append(c);      break;
                }
            }
            return sb.ToString();
        }
    }
}
