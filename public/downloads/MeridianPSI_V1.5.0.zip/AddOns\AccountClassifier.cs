// AccountClassifier.cs
//
// Derives an account CLASS (replay / practice / prop / live / unknown) and a prop
// VENDOR from a NinjaTrader account's name + display name + connection name.
//
// WHY THIS EXISTS (the "prop firms are all sim" problem):
//   NinjaTrader exposes NO supported property for demo-vs-funded (NT Support confirmed;
//   feature request SFT-5732). Connection.Mode returns only Live/Simulated and is
//   unreliable — most futures PROP-FIRM accounts (Apex, Topstep, MFFU, Bulenox, …) route
//   through Rithmic/Tradovate/CQG as Connection.Mode == Simulation, i.e. they look
//   IDENTICAL to a plain Sim101 practice account by mode alone. The trader's real money
//   and emotional stakes are on a prop eval/funded account even though it is technically
//   "Simulation". So the ONLY automatic discriminator is the account NAME / DISPLAY /
//   CONNECTION string — and even that cannot tell EVALUATION from FUNDED (no firm encodes
//   that in the NT account name). Eval-vs-funded is therefore left to a self-declared
//   StrategyProfile.AccountType; this classifier nails everything that IS reliably
//   auto-detectable.
//
// PURITY: string-only, no NinjaTrader/WPF references, so it also compiles + unit-tests in
//   the standalone testbench. The caller extracts the NT strings and passes them in.
//
// MAINTENANCE: the futures-prop landscape shifts quarterly (e.g. the ProjectX → TopstepX
//   consolidation, cutoff 2026-02-28, moved Bulenox/Tradeify/TradeDay/Phidias/Alpha onto
//   Tradovate/Rithmic). Keep PropVendors current; matching is substring + case-insensitive
//   across name|display|connection because the connection label ("Rithmic 01 – Bulenox")
//   is frequently MORE diagnostic of the firm than the opaque account id.

using System;

namespace NinjaTrader.NinjaScript.AddOns
{
    public static class AccountClassifier
    {
        public const string ClassReplay   = "replay";    // Market Replay / Playback (not real trading)
        public const string ClassPractice = "practice";  // built-in Sim101/102… demo (no stakes)
        public const string ClassProp     = "prop";      // a prop-firm account (eval OR funded — see self-declared)
        public const string ClassLive     = "live";      // personal live brokerage (best-effort)
        public const string ClassUnknown  = "unknown";   // simulation connection, no firm token → undecidable by name

        // vendor key → substring tokens (lower-case). Checked across name|display|connection.
        private static readonly Tuple<string, string[]>[] PropVendors = new[]
        {
            Tuple.Create("apex",            new[]{ "apex" }),
            Tuple.Create("topstep",         new[]{ "topstep", "topstepx" }),
            Tuple.Create("earn2trade",      new[]{ "earn2trade", "trader career path", "leeloo" }),
            Tuple.Create("myfundedfutures", new[]{ "my funded", "myfunded", "mffu" }),
            Tuple.Create("bulenox",         new[]{ "bulenox" }),
            Tuple.Create("tradeify",        new[]{ "tradeify" }),
            Tuple.Create("takeprofit",      new[]{ "take profit", "takeprofit" }),
            Tuple.Create("elitetrader",     new[]{ "elite trader", "elitetraderfunding" }),
            Tuple.Create("uprofit",         new[]{ "uprofit" }),
            Tuple.Create("fundedfutures",   new[]{ "funded futures network", "funded futures" }),
            Tuple.Create("legends",         new[]{ "legends trading", "legendstrading" }),
            Tuple.Create("tradeday",        new[]{ "tradeday", "trade day" }),
            Tuple.Create("blusky",          new[]{ "blusky" }),
            Tuple.Create("aquafutures",     new[]{ "aqua futures", "aquafutures" }),
            Tuple.Create("phidias",         new[]{ "phidias" }),
            Tuple.Create("nexgen",          new[]{ "nexgen", "protrader funding" }),
            Tuple.Create("alphafutures",    new[]{ "alpha futures", "alphaticks" }),
            Tuple.Create("lucid",           new[]{ "lucid trading" }),
        };

        public struct Result
        {
            public string Class;
            public string Vendor;   // "" unless a prop firm was identified
        }

        /// <summary>
        /// Classify from the account name, display name, connection/provider name, and
        /// whether the connection reported Simulation mode. None of the inputs are stored
        /// downstream — only the derived (non-PII) Class + Vendor are.
        /// </summary>
        public static Result Classify(string name, string display, string connection, bool isSimMode)
        {
            string hay = ((name ?? "") + " | " + (display ?? "") + " | " + (connection ?? "")).ToLowerInvariant();

            // 1. Market Replay / Playback — authoritative built-in prefix.
            if (hay.IndexOf("playback", StringComparison.Ordinal) >= 0)
                return new Result { Class = ClassReplay, Vendor = "" };

            // 2. Prop-firm token anywhere in name|display|connection.
            foreach (var pv in PropVendors)
                foreach (var token in pv.Item2)
                    if (hay.IndexOf(token, StringComparison.Ordinal) >= 0)
                        return new Result { Class = ClassProp, Vendor = pv.Item1 };

            // 3. Built-in practice simulator (Sim101, Sim102, …). NT forces the "Sim" prefix.
            if (!string.IsNullOrEmpty(name) &&
                name.TrimStart().StartsWith("sim", StringComparison.OrdinalIgnoreCase))
                return new Result { Class = ClassPractice, Vendor = "" };

            // 4. Simulation connection, no firm token → genuinely undecidable by name
            //    (could be an opaque prop-on-Tradovate id OR a renamed practice account).
            //    Leave UNKNOWN; the self-declared AccountType resolves it.
            if (isSimMode)
                return new Result { Class = ClassUnknown, Vendor = "" };

            // 5. Live connection, no token → personal live brokerage (best-effort).
            return new Result { Class = ClassLive, Vendor = "" };
        }
    }
}
