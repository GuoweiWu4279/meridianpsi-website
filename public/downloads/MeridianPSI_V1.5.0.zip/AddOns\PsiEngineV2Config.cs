﻿// PsiEngineV2Config.cs
//
// v2.0 architectural redesign — separate config namespace so v1.x remains
// bit-identical during M1 Phase 0 / Phase 1 shadow-mode.
//
// Scope of v2.0 (see ARCHITECTURE.md §15 for the full design contract):
//   The PSI engine is reframed from a "trade-scoring pipeline" into an
//   inference engine over two observation classes:
//     Class A — declared-commitment breaks (hard evidence, single event ⇒
//               saturating PSI response, reserved for trader-stated limits)
//     Class B — behavioural signals consistent with instability (weak
//               evidence, single event ⇒ small PSI response; pattern
//               accumulation via E(t) drives the meaningful signal)
//
//   Each of the seven dimensions owns one Evidence Accumulator E_i(t) with
//   a single mathematical law:
//
//       on observation:   E_i ← E_i + commit_i(o, context)
//       continuously:     dE_i/dt = −E_i / τ_decay_i · (1 − P(t))
//       severity map:     C_i = (1 − exp(−E_i / τ_sev_i)) × 100
//       aggregation:      PSI = 100 − √(Σ C_i²) − carryDebt
//
//   Class B commits are modulated by the Pressure scalar P(t) ∈ [0, 1]:
//       commit_B_eff = commit_B × (1 + κ · P)
//   P is derived entirely from the current observable state (open loser
//   magnitude, loss streak, daily-loss proximity) — NOT accumulated, NOT
//   a persisted EWMA; it is a pure function of "how pressured is the
//   trader right now?"  The same P also gates decay, so recovery slows
//   while pressure is high (you cannot heal while still under stress).
//
// Hard removals vs v1.x (enforced by this config being self-contained):
//   • No hard deductions anywhere.  No Session-window penalty.  No naked
//     penalty constant.  No "per-event drop cap".
//   • No FatigueDebt / FinancialStressDebt / StreakFloorDebt hidden
//     accumulators.  Their psychological content migrated into P(t) as
//     context that modulates Class B evidence, not as direct debt.
//   • No D4PerTradeSingleSampleCap (removed by design: a single quick
//     exit IS weak evidence — commit_B is small by construction).
//   • No snap-up law, no drop-tau ≠ recovery-tau asymmetry.  Evidence
//     enters discretely on commits; decay is symmetric first-order.
//   • No "frozen recovery" or "post-exposure cooldown" state machines.
//
// Discipline-over-outcome (psi-discipline-over-outcome.mdc):
//   Realised P&L, loss count, and wall-clock time NEVER enter PSI as
//   direct deductions.  They may appear in:
//     (a) P(t) — as contextual pressure that modulates how strongly
//         weak behavioural evidence accumulates;
//     (b) Class A commit triggers — ONLY for trader-declared
//         commitments (e.g. MaxDailyLoss breach), which are genuine
//         discipline violations, not outcome penalties.
//
// Calibration:
//   Parameters below are first-order calibrated against the acceptance
//   targets in PsiTestRunnerV2.cs (S201…S220).  Any change to a τ or
//   commit value MUST be accompanied by a re-run of the V2 test suite.

using System;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// v2.0 engine configuration.  Independent of <see cref="PsiEngineConfig"/>
    /// so v1.x remains untouched during Phase 0 / Phase 1 shadow-mode.
    /// </summary>
    public sealed class PsiEngineV2Config
    {
        // =================================================================
        // Master switch (M1 Phase 1 wiring)
        // =================================================================

        /// <summary>
        /// When true and <see cref="ShadowMode"/> is false, MeridianPSI drives
        /// HUD/Dashboard from <see cref="PsiEngineV2"/>.  Default false in
        /// Phase 0 (engine not wired at all) and Phase 1 (shadow-mode only).
        /// Flipped to true at M2 entry.  See ARCHITECTURE.md §15.9.
        /// </summary>
        public bool Enabled { get; set; } = false;

        /// <summary>
        /// When true and <see cref="Enabled"/> is true, the V2 engine runs
        /// in parallel with V1 but does NOT drive the HUD or Dashboard —
        /// its outputs are logged for divergence analysis only.  This is
        /// the M1 Phase 1 safety mode.
        /// </summary>
        public bool ShadowMode { get; set; } = false;

        // =================================================================
        // Pressure P(t) derivation
        //
        // P is computed on every engine entry point as the MAXIMUM of the
        // four component factors (bounded in [0, 1]).  Max-aggregation
        // (not sum, not L2) is deliberately chosen so that any one
        // severe-pressure state drives P alone; this matches the
        // psychological reality that a single dominant stressor fully
        // captures attention.
        //
        //   openLoserFactor   = clamp(-minUnrealizedPnl(worst) / μLoss, 0, 1)
        //   streakFactor      = clamp(max(0, consecutiveLosses - 1) / StreakSaturationN, 0, 1)
        //                       × exp(-idleSec / StreakPressureDecayTauSec)
        //                       (a "streak" requires ≥ 2 consecutive losses;
        //                       a single loss is not a pattern and carries
        //                       NO pressure signal in isolation;
        //                       the exponential decay models the clinical fact
        //                       that acute loss-streak distress dissipates with
        //                       rest — after ~1 h of no trading the emotional
        //                       momentum from that streak is substantially gone)
        //   dailyProximity    = clamp(sessionLoss / MaxDailyLoss, 0, 1)
        //   sessionHourFactor = profile-gated tail-of-session ramp (0 by default)
        //
        // P = max(openLoser, streak, dailyProx, sessionHour)
        //
        // P feeds two places only:
        //   (1) Class B commit scaling:  commit_B × (1 + κ · P)
        //   (2) Decay-rate gating:       decay_rate = (1 / τ_decay) × (1 − P)
        //
        // P has no momentum, no EWMA — it IS the current pressure.  When
        // the stressor clears (loser stopped out, streak cleared, session
        // ends), P immediately returns to zero and recovery resumes.
        // =================================================================

        /// <summary>
        /// Streak excess at which streakFactor saturates to 1.0, where
        /// streakExcess = max(0, consecutiveLosses − 1).  Value 2 means:
        ///   streak=1 → 0          (single loss is not a streak)
        ///   streak=2 → 0.5        (streak begins)
        ///   streak=3 → 1.0        (three consecutive losses saturate pressure)
        ///   streak=4+ → 1.0       (bounded)
        /// This matches the clinical "three strikes" tilt-onset heuristic
        /// from trader-psychology literature without penalising a single
        /// probabilistic loss.
        /// </summary>
        public double StreakSaturationN { get; set; } = 2.0;

        /// <summary>
        /// Amplification coefficient κ for how much P boosts Class B commits.
        /// commit_B_effective = commit_B × (1 + κ × P).
        /// At κ=1.0 and P=1.0, weak evidence accumulates at 2× the
        /// unpressured rate — matching the clinical observation that
        /// behavioural dysregulation accelerates non-linearly under stress.
        /// </summary>
        public double PressureBoostKappa { get; set; } = 1.0;

        /// <summary>
        /// Time constant (seconds) for how quickly streak-based psychological
        /// pressure dissipates when the trader stops trading.
        ///
        /// Clinical basis: acute emotional momentum from a loss streak is driven
        /// by corticosteroid and sympathetic-nervous-system response.  After a
        /// genuine rest period with no new losses, this acute phase resolves.
        /// Lo &amp; Repin (2002) physiology data suggests the acute stress response
        /// of a recent loss reduces substantially within ~1 hour of rest.
        ///
        /// Mechanically: streakFactor is multiplied by exp(−idleSec / τ) where
        /// idleSec = time since the last realized fill (loss or win).  This means:
        ///   • After 30 min of no trading: streakFactor × 0.61 → P drops noticeably
        ///   • After 1 h:  streakFactor × 0.37 → acute pressure substantially reduced
        ///   • After 4 h:  streakFactor × 0.02 → effectively zero (full recovery)
        ///
        /// The openLoserFactor (open position) is NOT affected — if you are still
        /// holding a losing position, P stays high regardless of elapsed time.
        ///
        /// DERIVATION (Axiom 4 compliant): this is derived fresh from observable
        /// state (_lastRealizedFillTime, engineTime, _consecutiveLosses) — no new
        /// accumulated memory state is added to the engine.
        /// </summary>
        public double StreakPressureDecayTauSec { get; set; } = 3600.0;

        /// <summary>
        /// When non-zero, activates the session-hour fatigue factor as a
        /// SECONDARY contribution to P(t) computation.  0 (default) disables
        /// the factor entirely so fatigue does not directly penalise PSI —
        /// it only amplifies Class B evidence if the trader is simultaneously
        /// exhibiting dysregulated behaviour late in session.  Profile presets
        /// set this to non-zero only for traders who have explicitly opted in
        /// to fatigue-gated pressure scaling.
        /// </summary>
        public double SessionHourFactorWeight { get; set; } = 0.0;

        /// <summary>
        /// Optimal session hours — time from <c>_sessionFirstEntryTime</c>
        /// below which the session-hour factor is zero.
        /// </summary>
        public double SessionHourOptimalHours { get; set; } = 3.0;

        /// <summary>
        /// Saturation time constant (hours) for the session-hour factor.
        /// factor = 1 − exp(−(sessionHours − optimal) / this).
        /// </summary>
        public double SessionHourRampHours { get; set; } = 2.5;

        /// <summary>
        /// Safety clamp for the "open loser vs μLoss" ratio input to P.
        /// A pathological μLoss ≈ 0 would otherwise make openLoserFactor
        /// explode on any small loss; we floor the denominator at this
        /// currency amount (account currency per contract).
        /// </summary>
        public double PressureMuLossFloor { get; set; } = 50.0;

        /// <summary>
        /// Cold-start fallback for TradeBaseline.GetEffectiveMuLoss() when fewer
        /// than 5 losing trades have been recorded in the baseline.
        ///
        /// Derived in FromProfile() from MaxDailyLossUsd / TradesPerSessionMax × 0.5
        /// so the threshold is profile-relative rather than instrument-agnostic.
        /// Default 25.0 is used when the profile has no declared daily-loss limit.
        /// </summary>
        public double ColdStartMuLoss { get; set; } = 25.0;

        // =================================================================
        // Declared-commitment Class A thresholds
        //
        // These are the "hard limits the trader committed to on the way in".
        // Crossing any of them is a genuine discipline violation and earns
        // a Class A commit that meaningfully moves PSI.  Defaults are 0 /
        // "disabled" so an un-configured profile does NOT get false-positive
        // Class A commits — the trader must opt in by declaring the limit.
        // =================================================================

        /// <summary>
        /// Maximum session loss in account currency (positive value; the
        /// engine compares sessionNetPnl &lt; -MaxDailyLossUsd).  Once
        /// breached, any subsequent fill fires a Class A commit on D6
        /// (Rule Compliance).  0 = disabled (no Class A commit).
        ///
        /// This is the ONLY place sessionPnl enters the PSI formula, and
        /// even here the trigger is the trader's own declared limit — not
        /// the P&L outcome itself.
        /// </summary>
        public double MaxDailyLossUsd { get; set; } = 0.0;

        /// <summary>
        /// Consecutive-loss count at which the trader committed to pause.
        /// Any new entry fill once the streak reaches this count fires a
        /// Class A commit on D1 (Revenge Entry).  0 = disabled.
        ///
        /// Again: the trigger is the trader's declared commitment, not
        /// the streak outcome.  A trader who set PauseAfterN = 0 never
        /// earns a Class A D1 commit from streak length alone.
        /// </summary>
        public int PauseAfterNLosses { get; set; } = 0;

        // =================================================================
        // Per-dimension parameters
        //
        // For each dimension D_i:
        //   TauDecayD_i   — E(t) decay time constant (seconds); τ larger ⇒
        //                   evidence lingers longer.  Gated by (1 − P).
        //   TauSevD_i     — E→C severity-mapping time constant in the SAME
        //                   units as E.  Smaller ⇒ C saturates faster
        //                   (the dimension is "touchier").
        //   CommitA_D_i   — Evidence added by a single Class A observation.
        //                   Sized so that one event takes C_i to 60–75
        //                   (PSI drops ~30–40 from a max-100).
        //   CommitB_D_i   — Evidence added by a single Class B observation
        //                   (BEFORE pressure multiplier).  Sized so that
        //                   one isolated Class B event moves PSI by ≤ 3.
        //
        // See ARCHITECTURE.md §15.5 for the calibration derivation.
        // =================================================================

        // ─── D1 Revenge Entry ────────────────────────────────────────────
        // REGIME: acute commitment-break (Axiom 7).  Revenge-entry after
        // a declared `PauseAfterNLosses` break is the same regime as
        // breaching MaxDailyLoss — it is breaking a hard rule, not a
        // slow pattern.  v2.0 value 300 s (5 min) violated I5.
        /// <summary>
        /// Evidence decay τ for D1 (seconds).  DERIVATION: I5 acute
        /// commitment-break regime; choose 2000 s (shared default).
        /// </summary>
        public double TauDecayD1 { get; set; } = 2000.0;
        /// <summary>Severity-map τ for D1 (standard 60).</summary>
        public double TauSevD1   { get; set; } = 60.0;
        /// <summary>
        /// Class A commit when PauseAfterNLosses is configured AND the trader
        /// re-enters within 2 × MaxReentrySeconds after reaching the pause
        /// threshold.  DERIVATION: CommitA_D_i ∈ [48.5, 72.7] from I1∩I3∩I4;
        /// choose 60 (shared default, see ARCHITECTURE.md §15.12).
        /// </summary>
        public double CommitA_D1 { get; set; } = 60.0;
        /// <summary>
        /// Class B commit when trader re-enters within MaxReentrySeconds
        /// after a significant loss (roundtrip ≤ −0.8 × μLoss), in the
        /// same direction as the prior loser.  A single event ≈ 3 PSI pts
        /// at P=0; meaningful pattern emerges after ~5 repeats.
        /// </summary>
        public double CommitB_D1 { get; set; } = 2.0;

        /// <summary>
        /// Threshold (fraction of μLoss, positive) below which the prior
        /// loss is considered significant enough to seed revenge-urgency.
        /// Default 0.8: a loss ≤ −0.8 × μLoss counts.
        /// </summary>
        public double D1SignificantLossFraction { get; set; } = 0.8;

        // ─── D2 Stop manipulation / Naked exposure ───────────────────────
        // REGIME: acute commitment-break (Axiom 7).  Naked-past-grace is
        // a declared-rule break with immediate risk exposure.
        /// <summary>
        /// Evidence decay τ for D2 (seconds).  DERIVATION: I5 acute
        /// commitment-break regime; choose 2000 s (shared default).
        /// </summary>
        public double TauDecayD2 { get; set; } = 2000.0;
        /// <summary>
        /// Severity-map τ for D2 (standard 60).  Kept at the shared standard
        /// so the I1∩I3∩I4 derivation in ARCHITECTURE.md §15.12 applies
        /// uniformly to every saturating Class A dimension.  The old 90 s
        /// value (shipped 2026-04-22) was a hand-tuned softening — it
        /// broke the shared derivation and is removed together with the
        /// step-function Class A trigger it was paired with.
        /// </summary>
        public double TauSevD2   { get; set; } = 60.0;
        /// <summary>
        /// Class A SATURATING-MARGINAL commit cap (Axiom 6).  Each tick of
        /// sustained naked exposure PAST the trader's declared grace window
        /// deposits
        ///     ΔE = CommitA_D2 · [ (1 − e^(−sNow/scale_D2))
        ///                       − (1 − e^(−sPrev/scale_D2)) ]
        /// where s(t) = max(0, nakedElapsedSec − NoStopGraceSeconds) and
        /// scale_D2 = NoStopGraceSeconds (Axiom 8 — the trader's own
        /// declared tolerance IS the psychological scale; r=1 therefore
        /// means "naked twice as long as you said you needed to place the
        /// stop").  DERIVATION: §15.12 (I1∩I3∩I4 ⇒ CommitA ∈ [48.5, 72.7];
        /// midpoint 60).  No step threshold, no multiplier — every second
        /// past grace adds a small bounded amount, total per naked episode
        /// saturates at CommitA_D2.
        /// </summary>
        public double CommitA_D2 { get; set; } = 60.0;
        /// <summary>
        /// Class B commit PER SECOND of naked exposure past the grace
        /// window (before P amplification).  Integrates continuously and
        /// runs alongside the saturating Class A above; Class A captures
        /// "your commitment-break severity" while Class B captures "the
        /// pattern of living past grace."  DERIVATION (behavioural anchor,
        /// same shape as CommitB_D3, see §15.12): 30 s naked at P=0 ⇒
        /// ΔE ≈ 30 · 0.05 = 1.5 PSI pts — a weak contribution that only
        /// becomes meaningful via pattern accumulation.
        /// </summary>
        public double CommitB_D2 { get; set; } = 0.05;
        /// <summary>
        /// Class B commit for a single adverse stop-widening event (the
        /// trader pushed the SL further from entry, a tilt signature).
        /// </summary>
        public double CommitB_D2_AdverseMove { get; set; } = 3.0;
        // NOTE: D2NakedClassATriggerMultiplier was REMOVED 2026-04-23.
        // Rationale: with default 3.0 it silently TRIPLED the trader's
        // declared NoStopGraceSeconds before Class A fired (a 20 s
        // declared grace produced no Class A until 60 s of naked).
        // Identical bug-class as D5ClassATriggerMultiplier (retired
        // 2026-04-23) and the pre-v1.1.6 D7ClassATriggerMultiplier (=2.0).
        // See `psi-v2-evidence-accumulator.mdc` Anti-pattern 10a
        // (silent threshold inflation).  The new saturating-marginal
        // Class A starts smoothly from sNow = pastGraceSec > 0 with no
        // step; re-introducing this field is a PR reject.
        //
        // NOTE: the fallback scale for NoStopGraceSeconds = 0 is
        // max(1.0, NoStopGraceSeconds) seconds.  1.0 s is NOT an
        // arbitrary constant — it is the minimum engine observation
        // resolution (position-poll interval floor).  Below this there
        // is no meaningful "past grace" to integrate.

        // ─── D3 Size Outlier ─────────────────────────────────────────────
        // REGIME: acute commitment-break (Axiom 7).  I5 requires
        // τ_decay ∈ [1965, 2403] s → τ=2000 s (33 min ≈ Coates 2008
        // cortisol half-life) chosen as derived default.  Old v2.0 value
        // 120 s gave a 5-minute recovery that was mathematically legal
        // but psychologically absurd (see ARCHITECTURE.md §15.10–§15.13
        // for the 2026-04-22 live-session calibration audit).
        /// <summary>
        /// Evidence decay τ for D3 (seconds).  DERIVATION: I5 acute
        /// commitment-break regime; τ ∈ [1965, 2403] s; choose 2000 s.
        /// </summary>
        public double TauDecayD3 { get; set; } = 2000.0;
        /// <summary>
        /// Severity-map τ for D3 (standard 60).  Changing this breaks the
        /// shared I1–I4 derivation in ARCHITECTURE.md §15.12 and requires
        /// re-solving CommitA_D3 from the invariants.
        /// </summary>
        public double TauSevD3   { get; set; } = 60.0;
        /// <summary>
        /// Class A commit for an oversize commitment break.  Axiom 6
        /// (Graded Severity) mandates SATURATING application:
        /// ΔE = CommitA_D3 · (1 − exp(−excess / D3SaturationScale)).
        /// DERIVATION: I1 ∩ I3 ∩ I4 with τ_sev=60 yields
        /// CommitA_D_i ∈ [48.5, 72.7]; choose midpoint 60.
        /// Replaces the v2.0 linear `CommitA × excess` formula which
        /// produced the "6 contracts → PSI 22" incident (2026-04-22).
        /// </summary>
        public double CommitA_D3 { get; set; } = 60.0;
        /// <summary>
        /// Saturation scale for D3 Class A severity.  Personalised per
        /// Axiom 8: at engine init, the engine seeds this from
        /// `profile.SizeMax` so "exceeding by 100%" maps to the same
        /// relative severity across all traders.  This value is the
        /// global fallback when profile.SizeMax is unset or ≤ 0.
        /// </summary>
        public double D3SaturationScale { get; set; } = 3.0;
        /// <summary>
        /// Class B commit per unit of RELATIVE excess per second of continued
        /// over-limit exposure AFTER the recognition grace window (before P
        /// amplification).  The engine applies:
        ///   ΔE_B = CommitB_D3 × (excessContracts / SizeMax) × intervalPastGrace
        /// making the signal scale-relative (Axiom 8) and grace-gated (D2 parity):
        /// only time past NoStopGraceSeconds counts, so a disciplined trader who
        /// recognises and exits an accidental oversize within the grace window
        /// receives zero Class B — only the Class A entry penalty.
        ///
        /// DERIVATION (behavioural anchor, replaces I2 magic-number chain):
        ///   Target: a trader who holds exactly r=1 (doubled their declared
        ///   SizeMax) CONTINUOUSLY for one full τ_decay period (1800 s) should
        ///   reach the WARNING zone (C3 ≈ 65 %, PSI contribution ≈ 35 pts).
        ///
        ///   ODE steady-state for E3 during hold:
        ///     dE3/dt = CommitB·r − E3/τ_decay  →  E3_eq = CommitB·r·τ_decay
        ///
        ///   At t = τ_decay from episode start (with grace ≈ 0 for derivation):
        ///     E3(τ) = E3_eq·(1−e⁻¹) + E3_A·e⁻¹
        ///           = CommitB·1·1800·0.632 + 37.9·0.368
        ///   For C3(τ)=65 %: E3(τ)=62.8  →  CommitB·1138 = 62.8−13.9 = 48.9
        ///     CommitB = 48.9/1138 ≈ 0.043  →  choose 0.05 (nearest 0.005 step).
        ///
        ///   Verification:
        ///     r=1, grace exit in &lt;30 s: Class B ≈ 0 (only Class A, PSI≈53)
        ///     r=1, 5-minute hold:  PSI≈47  (WARNING boundary)
        ///     r=1, 30-minute hold: PSI≈31  (CRITICAL — intentional sustained breach)
        ///     r=2, 30-minute hold: PSI≈15  (extreme floor — 3× max for half an hour)
        /// </summary>
        public double CommitB_D3 { get; set; } = 0.05;

        // ─── D4 Hold Bias ────────────────────────────────────────────────
        // Clinical definition: the trader holds LOSING trades significantly
        // LONGER than their typical winning trade.  This is the canonical
        // loss-aversion pattern — treating open losers like open winners by
        // waiting for them to turn around instead of executing the plan.
        //
        // Correct trigger: holdSec (loss) > D4HoldBiasRatio × μWinHold
        //
        // DO NOT fire for quick loss exits — cutting losses fast is GOOD
        // behavior and must never generate negative PSI evidence.
        //
        /// <summary>Evidence decay τ for D4 (seconds).
        /// 900 s (15 min): hold-bias is a persistent behavioural tendency;
        /// one corrected session of quick exits should not erase it instantly.
        /// </summary>
        public double TauDecayD4 { get; set; } = 900.0;
        /// <summary>Severity-map τ for D4.</summary>
        public double TauSevD4   { get; set; } = 60.0;
        /// <summary>
        /// D4 has NO Class A commit.  Hold-time is never a hard rule-break —
        /// it is always a pattern signal.  Value present for interface
        /// symmetry; always 0.
        /// </summary>
        public double CommitA_D4 { get; set; } = 0.0;
        /// <summary>
        /// Class B commit when a losing manual exit's hold-time exceeds
        /// <see cref="D4HoldBiasRatio"/> × μWinHold.
        /// Single event ≈ 3 PSI pts (at P=0).
        /// Pattern of ~5 such exits → PSI drops ~15 pts.
        /// </summary>
        public double CommitB_D4 { get; set; } = 2.0;
        /// <summary>
        /// Ratio of (loss hold time) / (μWinHold) above which a losing
        /// manual exit is treated as hold-bias evidence.
        /// Default 2.0: the loss must be held at least TWICE as long as
        /// the trader's typical win before D4 fires.
        /// Quick loss exits (ratio &lt; 2.0) earn ZERO evidence — cutting
        /// losses fast is disciplined, not a hold-bias signal.
        /// </summary>
        public double D4HoldBiasRatio { get; set; } = 2.0;

        // ─── D5 Position Hold (扛单) ─────────────────────────────────────
        // REGIME: sustained behavioural pattern (Axiom 7).  Overstay is
        // a holding-discipline pattern, not an acute shock.  τ choice
        // within [900, 1800] s range.
        /// <summary>
        /// Evidence decay τ for D5 (seconds).  DERIVATION: I5 sustained-
        /// pattern regime; choose 1500 s.
        /// </summary>
        public double TauDecayD5 { get; set; } = 1500.0;
        /// <summary>Severity-map τ for D5 (standard 60).</summary>
        public double TauSevD5   { get; set; } = 60.0;
        /// <summary>
        /// Class A SATURATING-MARGINAL commit cap (Axiom 6).  Each observation
        /// of a new-maximum overstay deposits
        ///     ΔE = CommitA_D5 · [ (1 − e^(−sNow / scale_D5))
        ///                       − (1 − e^(−sPrev / scale_D5)) ]
        /// where s(t) = max(0, HoldSec − MaxHoldSec) and scale_D5 =
        /// profile.MaxHoldMinutes × 60 (Axiom 8 personalisation).
        /// DERIVATION: §15.12 (I1 ∩ I3 ∩ I4 ⇒ CommitA ∈ [48.5, 72.7];
        /// midpoint 60).  NOT a one-shot — the marginal formula caps
        /// total contribution from a single overstay episode at
        /// CommitA_D5, regardless of how extreme the overstay becomes.
        /// </summary>
        public double CommitA_D5 { get; set; } = 60.0;
        /// <summary>
        /// Class B persistence integration coefficient (Axiom 2).
        /// While the trader remains past MaxHoldSec, per-second evidence
        /// added is
        ///     CommitB_D5 × (overstaySec / scale_D5) × dt,
        /// amplified by (1 + κ·P).  P&amp;L is NOT a factor — D5 measures
        /// the DECISION to remain past the declared max, not the
        /// decision's profitability (psi-discipline-over-outcome.mdc).
        /// DERIVATION anchored to I2: five Class B commits over one
        /// τ_decay at P=0 should push C_5 ≥ 50 when relative-severity
        /// ≈ 1 (doubled declared max).  Yields CommitB_D5 ≈ 0.05.
        /// </summary>
        public double CommitB_D5 { get; set; } = 0.05;
        // NOTE: D5ClassATriggerMultiplier was REMOVED 2026-04-23.
        // Rationale: the old step-function Class A fired at
        // MaxHoldMinutes × multiplier (default 2.0), silently
        // doubling the trader's declared threshold (Axiom 2 violation,
        // same bug class as the D7 multiplier retired 2026-04-22).
        // The new saturating-marginal Class A starts smoothly from
        // overstaySec > 0 with no threshold step, so no multiplier is
        // meaningful.  See `psi-v2-evidence-accumulator.mdc`
        // Anti-patterns 10a (threshold inflation) and 10b (step-function
        // Class A) — re-introducing this field is a PR reject.

        // ─── D6 Rule compliance (session window + daily loss) ───────────
        // REGIME: acute commitment-break (Axiom 7).  MaxDailyLoss breach
        // is the single most severe declared-limit crossing.
        /// <summary>
        /// Evidence decay τ for D6 (seconds).  DERIVATION: I5 acute
        /// commitment-break regime; choose 3000 s (MaxDailyLoss is the
        /// most severe break — choose upper end of the regime).
        /// </summary>
        public double TauDecayD6 { get; set; } = 3000.0;
        /// <summary>Severity-map τ for D6 (standard 60).</summary>
        public double TauSevD6   { get; set; } = 60.0;
        /// <summary>
        /// Class A SATURATING commit cap for D6 (Axiom 6).  Shared default
        /// 60 (§15.12 — I1∩I3∩I4 ⇒ CommitA ∈ [48.5, 72.7]).
        ///
        /// Two independent observation channels deposit into D6 through this
        /// single cap — both saturating, neither step-function:
        ///
        ///   1. MaxDailyLoss overshoot (saturating-marginal in USD):
        ///        ΔE = CommitA_D6 · [(1−e^(−oNow/scale_d6loss))
        ///                         − (1−e^(−oPrev/scale_d6loss))]
        ///      where o(t) = max(0, −sessionNetPnl − MaxDailyLossUsd) and
        ///      scale_d6loss = MaxDailyLossUsd (Axiom 8 — r=1 means "lost
        ///      twice your declared max").  Grows marginally as the hole
        ///      deepens past the declared stop; total per session bounded
        ///      at CommitA_D6.
        ///
        ///   2. Session-window out-of-hours (saturating per fill):
        ///        ΔE = CommitA_D6 · (1 − e^(−minutesOver/scale_d6win))
        ///      where scale_d6win = declared session length in minutes
        ///      (Axiom 8 — r=1 means "out-of-window time equals your
        ///      declared in-window session length").  Each out-of-window
        ///      fill is its own Axiom-3 event, bounded per event; multiple
        ///      such fills accumulate as pattern (Axiom 3 corollary).
        ///
        /// The pre-2026-04-23 step-function trigger
        /// `if minutesOver ≥ D6WindowClassAMinutes fire CommitA else fire
        /// linear CommitB × minutesOver` was removed (Anti-pattern 10b):
        /// `D6WindowClassAMinutes = 30` and `CommitB_D6 = 2` were
        /// hand-picked magic numbers with no derivation from the
        /// Invariant Contract.  The single saturating curve above replaces
        /// both paths with one profile-relative formula.
        ///
        /// FALLBACK scales when profile fields are absent or 0:
        ///   scale_d6loss → max(1.0, MaxDailyLossUsd).  $1 is not arbitrary
        ///                  — it is the platform's minimum-resolvable
        ///                  currency unit per tick.  (If the trader has
        ///                  not declared a daily-loss limit, the rule is
        ///                  DISABLED entirely; fallback only engages when
        ///                  the limit is declared but tiny.)
        ///   scale_d6win  → max(1.0, declaredSessionLengthMinutes).  1 min
        ///                  is the platform's time-of-day resolution
        ///                  (SessionStartMinute / SessionEndMinute are int
        ///                  minutes).  Below this there is no meaningful
        ///                  "outside window" time to integrate.
        /// </summary>
        public double CommitA_D6 { get; set; } = 60.0;

        // ─── D7 Overtrading ──────────────────────────────────────────────
        // REGIME: sustained behavioural pattern (Axiom 7).  Overtrading
        // is a pace/frequency pattern signal, not an acute shock, so
        // retains the shorter sustained-pattern regime τ.
        /// <summary>
        /// Evidence decay τ for D7 (seconds).  DERIVATION: I5 sustained-
        /// pattern regime; choose 900 s (unchanged from v2.0).
        /// </summary>
        public double TauDecayD7 { get; set; } = 900.0;
        /// <summary>Severity-map τ for D7 (standard 60).</summary>
        public double TauSevD7   { get; set; } = 60.0;
        /// <summary>
        /// Class A SATURATING-MARGINAL commit cap for D7 (Axiom 6).  On each
        /// NEW entry DECISION (deduped on OrderId, Anti-pattern 10) whose
        /// session-trade-count has risen past the declared budget,
        ///     ΔE = CommitA_D7 · [(1−e^(−eNow/scale_d7))
        ///                       − (1−e^(−ePrev/scale_d7))]
        /// where e(t) = max(0, _sessionEntryCount − TradesPerSessionMax) and
        /// scale_d7 = TradesPerSessionMax (Axiom 8 — r=1 means "you've taken
        /// twice the trades you said you would").  The first over-budget
        /// trade deposits a small marginal; subsequent over-budget trades
        /// keep depositing; total per session saturates at CommitA_D7.
        ///
        /// DERIVATION: §15.12 (I1∩I3∩I4 ⇒ CommitA ∈ [48.5, 72.7]; midpoint
        /// 60).  Replaces the pre-2026-04-23 one-shot step-function
        /// `if count > max·multiplier then fire CommitA` (Anti-pattern 10b):
        /// that shape had no way to distinguish "one extra trade" from
        /// "ten extra trades" — both fired one CommitA.  The saturating
        /// curve makes marginal severity correspond to marginal psychology.
        ///
        /// FALLBACK: when TradesPerSessionMax = 0 the rule is DISABLED
        /// entirely — a trader who did not declare a trade budget cannot
        /// have "exceeded" one.  When declared but tiny (TradesPerSessionMax
        /// = 1), scale = max(1.0, TradesPerSessionMax) so the curve is
        /// numerically stable; 1.0 trade is the integer-resolution of the
        /// underlying count, not a tuning constant.
        /// </summary>
        public double CommitA_D7 { get; set; } = 60.0;
        /// <summary>
        /// Class B commit on each entry whose inter-entry gap is below
        /// <see cref="D7AccelFasterThan"/> × the trader's sessionAvgGap —
        /// acceleration signature.
        /// </summary>
        public double CommitB_D7 { get; set; } = 2.0;
        /// <summary>
        /// Class B commit for each entry whose utilization of the declared
        /// trade budget exceeds 50%.  Scaled by budget_pressure ∈ [0,1]:
        ///
        ///   budget_pressure = clamp((entryCount / TradesPerSessionMax − 0.5) / 0.5, 0, 1)
        ///
        /// Fires only while still within the limit (not on over-budget entries
        /// where Class A already fires).  Produces a gradual PSI slope as the
        /// trader approaches their declared limit instead of a pure cliff at
        /// the moment the limit is crossed.
        ///
        /// Derivation: target C7 ≈ 25 pts after 5 entries at full budget
        /// pressure (100 % utilization), which is half of the I2 B-accumulation
        /// target.  CommitB_D7Budget = CommitB_D7 × 0.5 ≈ 1.0 default.
        /// Invariant I2 still holds for the pace-signal path; this path is
        /// intentionally softer — approaching a limit is not yet a rule break.
        /// </summary>
        public double CommitB_D7Budget { get; set; } = 1.0;
        // NOTE: D7ClassATriggerMultiplier was REMOVED 2026-04-23.
        // Rationale: the v1.1.6 "user-configurable grace buffer" framing
        // (§15.12 note) is Anti-pattern 6 (config knob to tune around a
        // behavioural law).  A trader who wants more trades must raise
        // TradesPerSessionMax in their profile — that is the single
        // source of truth for "what I committed to."  The engine's job
        // is to observe the crossing, not to hide it behind an engine-
        // level softening.  See `psi-v2-evidence-accumulator.mdc`
        // Anti-pattern 10a (threshold inflation).
        /// <summary>
        /// Ratio threshold (recentGap / sessionAvgGap) below which entry
        /// pace is flagged as acceleration.  0.5 = "entering ≥2× faster
        /// than session average".
        /// </summary>
        public double D7AccelFasterThan { get; set; } = 0.5;
        /// <summary>
        /// Minimum entries accumulated in session before D7 acceleration
        /// signal is evaluated.  Below this, session average is unreliable.
        /// </summary>
        public int D7MinSessionEntriesForAccel { get; set; } = 4;

        // =================================================================
        // Overnight carry-forward  (unchanged semantics vs v1.x for
        // continuity — the trader's "opening PSI" calculation is a UX
        // choice, not an engine-core concern)
        // =================================================================

        /// <summary>Time constant (hours) for overnight carry-debt recovery.</summary>
        public double OvernightRecoveryTauHours { get; set; } = 48.0;

        /// <summary>Assumed overnight gap in hours when no fill anchor exists.</summary>
        public double OvernightEstimatedHours { get; set; } = 16.0;

        // =================================================================
        // Consecutive-loss tracking (retained for P computation only)
        // =================================================================

        /// <summary>Geometric decay factor applied to the loss-streak counter on each win.</summary>
        public double WinStreakDecayFactor { get; set; } = 0.6;

        /// <summary>Streak is zeroed when it decays below this threshold.</summary>
        public double StreakClearThreshold { get; set; } = 0.05;

        // =================================================================
        // Numerical guards
        // =================================================================

        /// <summary>Lower floor (seconds) for any dt used in decay/integration steps.</summary>
        public double MinDeltaSec { get; set; } = 0.0;

        /// <summary>
        /// Upper clamp (seconds) on a single decay/integration step.  Any
        /// platform-time gap larger than this collapses to this value —
        /// prevents a one-off time-domain anomaly or long idle gap from
        /// wiping all evidence in one step.
        /// </summary>
        public double MaxDeltaSec { get; set; } = 600.0;

        // =================================================================
        // Factory
        // =================================================================

        /// <summary>Exact default values (Balanced calibration).</summary>
        public static PsiEngineV2Config Default => new PsiEngineV2Config();

        /// <summary>
        /// Builds a v2.0 config seeded from the user's StrategyProfile.
        /// MaxDailyLossUsd and PauseAfterNLosses are read from the profile
        /// when added in M1 Phase 1; in Phase 0 they default to disabled.
        /// </summary>
        public static PsiEngineV2Config FromProfile(StrategyProfile p)
        {
            if (p == null) return Default;

            var cfg = PresetFor(p.Sensitivity);

            if (p.RecoverySpeedMultiplier > 0)
            {
                double m = Clamp(p.RecoverySpeedMultiplier, 0.25, 4.0);
                cfg.TauDecayD1 /= m;
                cfg.TauDecayD2 /= m;
                cfg.TauDecayD3 /= m;
                cfg.TauDecayD4 /= m;
                cfg.TauDecayD5 /= m;
                cfg.TauDecayD6 /= m;
                cfg.TauDecayD7 /= m;
            }

            // Profile → Class A limits.  MaxDailyLossUsd and PauseAfterNLosses
            // are declared by the trader in their StrategyProfile and map directly
            // to the engine's matching config properties — both default to 0
            // (disabled) when the profile omits them or the user leaves them blank.
            cfg.MaxDailyLossUsd   = p.MaxDailyLossUsd;
            cfg.PauseAfterNLosses = p.PauseAfterNLosses;

            // Cold-start μLoss default (Axiom 8 — profile-relative).
            //
            // TradeBaseline.GetEffectiveMuLoss() uses a hard-coded $100 default
            // while fewer than 5 losses have been recorded.  $100 is instrument-
            // agnostic and too high for small instruments (e.g. MNQ 1-3 lots with
            // tight ATM stops), silencing D1 for the entire cold-start period.
            //
            // Correct cold-start estimate:
            //   expected_loss_per_trade ≈ MaxDailyLossUsd / TradesPerSessionMax × 0.5
            //   (50 % of the daily budget divided evenly across declared trades)
            //
            // Rationale: if MaxDailyLossUsd = $200 and TradesPerSessionMax = 3,
            // the trader has budgeted roughly $33 per losing trade.  A $25 loss
            // on MNQ is therefore significant — it consumes 75 % of the budget —
            // and D1SignificantLossFraction (0.8) × $33 = $26 threshold passes.
            //
            // Fallbacks:
            //   • MaxDailyLossUsd or TradesPerSessionMax not set → $25 default
            //     (instrument-agnostic but reflects small-instrument reality
            //      better than $100).
            //   • Clamped [5, 200] so extreme profiles don't produce absurd results.
            if (p.MaxDailyLossUsd > 0 && p.TradesPerSessionMax > 0)
                cfg.ColdStartMuLoss = Clamp(
                    p.MaxDailyLossUsd / p.TradesPerSessionMax * 0.5, 5.0, 200.0);
            else
                cfg.ColdStartMuLoss = 25.0;

            return cfg;
        }

        private static PsiEngineV2Config PresetFor(PsiSensitivity level)
        {
            // Preset discipline (v2.1):
            //   Invariants I1–I6 bind the BALANCED preset.  Conservative /
            //   Aggressive may re-parametrise the CURVE (Class B weights,
            //   decay-speed multiplier, Pressure κ) but MUST NOT violate
            //   I1 ∩ I3 ∩ I4 for Class A commits.  Specifically:
            //     CommitA_D_i ∈ [48.5, 72.7]  (I1, I3, I4 intersection)
            //     Any τ_decay for commitment-break dims remains ≥ 1965 s
            //     so I5 (cortisol-grounded recovery) holds.
            //
            //   Conservative: Class B dose stronger (catches patterns earlier),
            //                 decay slightly slower, κ higher.
            //   Aggressive:   Class B softer (tolerates more before flagging),
            //                 decay slightly faster but still ≥ I5 floor,
            //                 κ lower.
            //   Class A magnitudes (commitment-break events) stay at the
            //   derived default 60 across all presets — a rule-break is a
            //   rule-break, independent of trader sensitivity.
            switch (level)
            {
                case PsiSensitivity.Conservative:
                    return new PsiEngineV2Config
                    {
                        CommitB_D1 = 2.5,
                        CommitB_D3 = 0.07,   // 1.4× balanced (0.05), ~40% more aggressive Class B
                        CommitB_D4 = 2.5,   CommitB_D5 = 0.07,
                        CommitB_D7 = 2.5,   CommitB_D7Budget = 1.25,
                        PressureBoostKappa = 1.3,
                        OvernightRecoveryTauHours = 72.0,
                    };

                case PsiSensitivity.Aggressive:
                    return new PsiEngineV2Config
                    {
                        CommitB_D1 = 1.5,
                        CommitB_D3 = 0.035,  // 0.7× balanced (0.05), more forgiving of brief oversize
                        CommitB_D4 = 1.5,   CommitB_D5 = 0.035,
                        CommitB_D7 = 1.5,   CommitB_D7Budget = 0.75,
                        PressureBoostKappa = 0.7,
                        OvernightRecoveryTauHours = 36.0,
                    };

                default: // Balanced
                    return new PsiEngineV2Config();
            }
        }

        private static double Clamp(double v, double min, double max)
            => v < min ? min : v > max ? max : v;
    }
}
