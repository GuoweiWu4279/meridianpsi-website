﻿// PsiEngine.cs
//
// Core PSI calculation engine.  Implements all seven behavioural signal dimensions,
// the weighted composite, and the asymmetric time-weighted EWMA.
//
// Design constraints:
//   - Zero NinjaTrader API dependencies — fully unit-testable in isolation.
//   - All public methods are thread-safe (single internal lock).
//   - No blocking I/O, no allocations on the hot path.
//   - All dimension outputs are strictly in [0, 1].
//   - PSI is strictly in [0, 100].

using System;
using System.Collections.Generic;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================================
    // ExitKind — first-class classification of how a closing fill arose.
    //
    // Introduced v1.1.1 to resolve the discipline-over-outcome invariant
    // violation where a protective stop-loss fill was mis-interpreted by D4
    // as a "panic exit" due to short hold time.  The only objective fact the
    // engine can determine from NT8 order data is whether the exit order was
    // an *active, pre-placed protective bracket* at the moment the fill
    // occurred.  That fact — NOT order creation time or naming conventions —
    // is what should drive dimension behaviour.
    //
    // Semantics:
    //   Unknown        — caller could not determine; engine applies the
    //                    conservative (pre-v1.1.1) behaviour.  Default.
    //   ProtectiveStop — exit order was an active Stop/StopLimit bracket
    //                    already in place when the position opened.
    //                    Psychologically: pre-planned, disciplined.
    //   Target         — exit order was an active Limit (take-profit)
    //                    bracket already in place when the position opened.
    //                    Psychologically: pre-planned, disciplined.
    //   Manual         — user-initiated market/limit flatten without an
    //                    active matching bracket.  Psychologically: may be
    //                    re-evaluation or panic (ambiguous; engine uses
    //                    weak-evidence accumulation, not single-event snap).
    //   Reversal       — closing fill is part of a position reversal
    //                    (excess quantity opens the opposite position).
    //   SystemClose    — end-of-day auto-flat, broker liquidation, margin
    //                    call, or other non-trader-initiated close.
    //
    // See ARCHITECTURE.md §14 for the philosophical framing (discipline-
    // over-outcome invariant) and §15 for the path-coverage matrix (ATM /
    // Chart Trader / SuperDOM / Close-All) which all produce ExitKind in a
    // uniform way via the "active bracket at fill time" heuristic.
    // =========================================================================

    public enum ExitKind
    {
        Unknown        = 0,
        ProtectiveStop = 1,
        Target         = 2,
        Manual         = 3,
        Reversal       = 4,
        SystemClose    = 5,
    }

    public sealed class PsiEngine
    {
        // =====================================================================
        // Dependencies (injected, immutable)
        // =====================================================================

        private readonly StrategyProfile  _profile;
        private readonly TradeBaseline    _baseline;
        private readonly PsiEngineConfig  _cfg;
        private readonly object           _sync = new object();

        // Optional diagnostic logger — injected by MeridianPSI so the engine
        // can emit per-event PSI-drop attribution (B1) and end-of-session
        // summary lines (B2) without a hard dependency on NinjaScript.  Null
        // when running in the unit-test harness.
        private Action<string> _debug;

        /// <summary>
        /// Install an optional diagnostic callback that receives attribution
        /// strings on significant PSI drops and other post-v1.1 observability
        /// output.  Safe to call once at startup; passing null disables logs.
        /// </summary>
        public void SetDebugLogger(Action<string> logger)
        {
            lock (_sync) _debug = logger;
        }

        // =====================================================================
        // Session observability counters (B2)
        //
        // Cleared by StartNewSession / ClearSessionBehavioralStateInternal.
        // Peaks are maintained on every ApplyDecomposedEwma pass; durations
        // are accumulated by PollPositions based on state at call time.
        // =====================================================================
        private double   _peakC1, _peakC2, _peakC3, _peakC4, _peakC5, _peakC6, _peakC7;
        private double   _peakDimNorm;
        private double   _minPsiThisSession = 100.0;
        private double   _overExposureTotalSec;
        private double   _nakedTotalSec;
        private int      _d6ViolationCount;
        private int      _slAdverseMovesTotal;
        private DateTime _lastPosSampleAt = DateTime.MinValue;

        // =====================================================================
        // PSI state
        // =====================================================================

        private double   _psi            = 100.0;
        private DateTime _lastEwmaUpdate = DateTime.MinValue;

        // =====================================================================
        // Consecutive-loss counter  (float for geometric decay)
        // =====================================================================

        private double _consecutiveLosses = 0.0;

        // =====================================================================
        // D1 — Revenge Entry state
        // =====================================================================

        private double   _lastRealizedPnl       = 0.0;
        private DateTime _lastRealizedFillTime  = DateTime.MinValue;

        // Direction of the last CLOSED position:
        //   +1 = was Long,  -1 = was Short,  0 = unknown
        private int _lastRealizedDirection = 0;

        // =====================================================================
        // D2 — Stop-Loss Manipulation state
        // Key = orderId.  Cleared when any position closes.
        // =====================================================================

        private readonly Dictionary<string, double> _prevSlTicks  = new Dictionary<string, double>();
        private readonly Dictionary<string, int>    _adverseMoves = new Dictionary<string, int>();

        // =====================================================================
        // D2 naked-position continuous-exposure timer
        //
        // Timestamp at which the currently-open position first entered the
        // "naked" state (no protective stop).  DateTime.MinValue when no naked
        // position is present.  Used to build a continuous D2 raw signal that
        // grows with exposure duration (1 − exp(−nakedSec / D2NakedTimeConstantSec)),
        // replacing the old one-shot hard-deduction that bypassed the EWMA pipeline.
        //
        // Reset on: any poll that finds no naked position, and by
        //           OnPositionTrackingCorrection / StartNewSession / ApplyOvernightDecay.
        // =====================================================================

        private DateTime _nakedStateBeganAt = DateTime.MinValue;

        // =====================================================================
        // D7 — Overtrading (过度交易)
        //
        // Measures intra-session entry pace acceleration and deviation from
        // the trader's declared profile frequency.  Fires regardless of P&L:
        // a winning streak at 10× normal pace is still a psychological alarm.
        //
        // Two signals combined as max():
        //   A. Acceleration: recentAvgGap << sessionAvgGap
        //   B. Profile:      sessionAvgGap << expectedGap (from LambdaVelocity)
        //
        // Partial-fill deduplication: entries within OversizeImpulseCooldownSec
        // of the previous entry are ignored (one order = one entry decision).
        // =====================================================================

        // Ring buffer of the most recent D7AccelWindowEntries entry timestamps.
        private readonly Queue<DateTime> _recentEntryTimes  = new Queue<DateTime>();
        private DateTime _sessionFirstEntryTime             = DateTime.MinValue;
        private int      _sessionEntryCount                 = 0;
        // Last entry fill time used for partial-fill deduplication.
        private DateTime _lastEntryFillTime                 = DateTime.MinValue;

        // =====================================================================
        // D3 unified over-limit evidence accumulator E(t)
        //
        // Single state variable (unit: contract·seconds) that captures three
        // physically-homogeneous contributions driven entirely by the
        // observable process |q(t)| − SizeMax:
        //
        //   (1) Commit jump on fills that deepen the over-limit state:
        //         ΔE = D3CommitEquivalentSec × Δ(excess)⁺
        //       Registers the DECISION itself, independent of how long the
        //       trader stays over limit — closes the "scalper loophole".
        //   (2) Persistence integration while |q| > SizeMax:
        //         dE/dt = excess(t)    (sample-and-hold between events)
        //       Registers the CHOICE TO REMAIN in an over-limit state.
        //   (3) Natural first-order decay once back within profile:
        //         dE/dt = −E / D3ExcessDecayTauSec
        //       Replaces the legacy frozen-τ / post-overexposure-τ /
        //       overexposure-cooldown-minutes compensation stack.
        //
        // D3 raw = 1 − exp(−E / D3ExcessIntegralTau), fed through the
        // unchanged snap-up / recovery pipeline in ApplyDecomposedEwma.
        // D3 does NOT read _consecutiveLosses, pnl, or any outcome — strictly
        // process-only per psi-discipline-over-outcome.mdc.
        // =====================================================================

        private double   _sizeExcessIntegral      = 0.0;  // E(t)
        private double   _prevSizeOverLimit       = 0.0;  // max(0,|q_prev|-SizeMax)
        private DateTime _sizeExcessSampleAt      = DateTime.MinValue;

        // Last platformTime seen by PollPositions — session heartbeat only.
        // Pausing Market Replay produces non-advancing eventTime, which is
        // handled implicitly by ApplyDecomposedEwma (Δt ≤ 0 → no-op).
        private DateTime _lastPollPlatformTime    = DateTime.MinValue;

        // =====================================================================
        // Instantaneous dimension signals  (0–1, refreshed on each event)
        // These are the raw behavioural inputs that feed the EWMA debt below.
        // Also exposed publicly (ScoreD1-D6) for session-record and log use.
        // =====================================================================

        private double _d1, _d2, _d3, _d4, _d5, _d6, _d7;

        // =====================================================================
        // Decomposed PSI debt per dimension  (unit: PSI points, 0–100)
        //
        // Each C_i tracks how many PSI points dimension i currently "owes".
        // Aggregation is via Euclidean norm (p-norm, p=2) so that a single
        // severe dimension dominates the PSI loss:
        //
        //     PSI  =  100  −  √(Σ C_i²)  −  _carryDebt  −  hidden debts
        //
        // A lone C_3 = 80 gives PSI ≈ 20 (matching the psychological reality
        // that "I just massively oversized" is itself a major instability
        // signal).  Two maxed dimensions naturally saturate toward PSI = 0.
        // HUD bars display individual C_i values; the shown PSI equals
        // 100 − p-norm(C) − hiddenDebts exactly on every tick.
        // =====================================================================

        private double _c1, _c2, _c3, _c4, _c5, _c6, _c7;

        // Carry-forward debt from the previous session.
        // Initialised to (100 − sessionOpenPsi) in StartNewSession.
        // Decays at the recovery tau so it dissolves as the trader trades
        // calmly today.  Not attributed to any dimension bar — it is
        // historical context, not a current behavioural signal.
        private double _carryDebt = 0.0;

        // =====================================================================
        // D6 — Rule Compliance: cumulative out-of-window violation counter
        // =====================================================================

        private int _sessionWindowViolationCount = 0;

        // =====================================================================
        // Session P&L accumulator — feeds the financial stress hidden component.
        // Reset each session; NOT persisted (baseline.xml tracks long-run stats).
        // =====================================================================

        private double _sessionNetPnl = 0.0;

        // =====================================================================
        // Hidden PSI debt components (not tied to any single HUD bar)
        //
        // These are ADDITIVE to the p-norm dimensional loss (they aggregate
        // independently of C_i because they represent session-level signals
        // that are not easily attributable to a single behavioural dimension):
        //
        //   PSI = 100 − √(ΣC_i²) − carryDebt
        //                        − financialStressDebt
        //                        − fatigueDebt
        //                        − streakFloorDebt
        //
        // Financial stress:  session-level cumulative P&L deficit.
        // Fatigue:           session-duration cognitive load.
        // StreakFloorDebt:   absorbs the "PSI would improve on a new loss"
        //                    gap during a consecutive-loss streak so the PSI
        //                    identity holds exactly.  Decays at the normal
        //                    recovery rate once the streak ends.
        // All three use slow EWMA (not snap-up — they are genuinely slow-
        // varying cognitive/financial signals).  All three decay overnight
        // via ApplyOvernightDecay.
        // =====================================================================

        private double _financialStressRaw  = 0.0;
        private double _financialStressDebt = 0.0;

        private double _fatigueRaw  = 0.0;
        private double _fatigueDebt = 0.0;

        // Streak-floor hidden debt.  Non-zero only while _consecutiveLosses ≥
        // LossStreakPsiFloorMinStreak and new losses keep arriving.
        private double _streakFloorDebt = 0.0;

        // =====================================================================
        // E6 — Process-violation ledger (observability for v1.3 discipline debt)
        //
        // Recorded at manual-exit fills (ExitKind != ProtectiveStop && != Target)
        // when the round-trip ended in loss.  These events are candidate
        // "discipline violations" but we do NOT feed them into PSI in v1.1.1 —
        // we first accumulate them for a period to calibrate thresholds before
        // wiring them into the hidden debt pipeline (ARCHITECTURE.md §14.4).
        //
        // Ring-buffer capacity 128: ~2 sessions' worth of quick-exit evidence
        // for diagnostics; cleared on StartNewSession.
        // =====================================================================

        public struct ProcessEvent
        {
            public DateTime Time;
            public double   HoldSeconds;
            public double   RoundTripPnl;
            public ExitKind Exit;
            public string   Kind;     // human-readable category
            public double   Weight;   // 0..1 evidence strength (reserved for v1.3)
        }

        private readonly Queue<ProcessEvent> _processEvents = new Queue<ProcessEvent>();
        private const int ProcessEventCapacity = 128;

        private void RecordProcessEventOnManualExit(DateTime t, double holdSec,
                                                    double rtPnl, ExitKind ek)
        {
            // Categorise the event against a rough hold-time reference.  A hold
            // shorter than a small fraction of the trader's LossHold mean is
            // treated as a "quick manual exit" — the behavioural signature we
            // most want to distinguish from bracket-triggered discipline.
            double muLossHold = Math.Max(_cfg.D4MinHoldGuardSec,
                                         _baseline.GetEffectiveMuLossHold(_profile));
            string kind;
            double weight;
            if (holdSec > 0 && holdSec < 0.35 * muLossHold)
            {
                kind   = "QuickManualExit";
                weight = 0.75;
            }
            else
            {
                kind   = "ManualExit";
                weight = 0.15;
            }

            var ev = new ProcessEvent
            {
                Time         = t,
                HoldSeconds  = holdSec,
                RoundTripPnl = rtPnl,
                Exit         = ek,
                Kind         = kind,
                Weight       = weight,
            };

            _processEvents.Enqueue(ev);
            while (_processEvents.Count > ProcessEventCapacity)
                _processEvents.Dequeue();
        }

        /// <summary>
        /// Snapshot of recent process-evidence events (E6 observability).
        /// Each entry is a candidate discipline-violation signal recorded on
        /// a non-bracket losing exit; weights are indicative only and not
        /// wired into PSI in v1.1.1.  Used by Dashboard diagnostics and by
        /// PsiTestRunner to verify E6 classification correctness.
        /// </summary>
        public IReadOnlyList<ProcessEvent> RecentProcessEvents
        {
            get { lock (_sync) return _processEvents.ToArray(); }
        }

        // =====================================================================
        // Constructor
        // =====================================================================

        /// <param name="profile">Strategy profile (user-supplied priors).</param>
        /// <param name="baseline">Historical baseline statistics.</param>
        /// <param name="config">
        /// Engine tuning parameters.  Pass null to use <see cref="PsiEngineConfig.Default"/>
        /// (exact original hard-coded values).
        /// </param>
        public PsiEngine(StrategyProfile profile, TradeBaseline baseline,
                         PsiEngineConfig config = null)
        {
            _profile  = profile  ?? throw new ArgumentNullException("profile");
            _baseline = baseline ?? throw new ArgumentNullException("baseline");
            _cfg      = config   ?? PsiEngineConfig.Default;
        }

        // =====================================================================
        // Public API
        // =====================================================================

        /// <summary>Current PSI score (0 = fully tilted, 100 = perfectly stable).</summary>
        public double CurrentPsi { get { lock (_sync) return _psi; } }

        /// <summary>Active configuration (read-only reference).</summary>
        public PsiEngineConfig Config => _cfg;

        // ── Instantaneous raw dimension signals (0–1) ────────────────────────
        // Used by MeridianPSI to record per-trade behavioural state in
        // SessionData (Tilt Cascade, Behavioral Quality Score).
        // NOT used for the live HUD bars — use DebtD1-D6 instead.
        public double ScoreD1 { get { lock (_sync) return _d1; } }
        public double ScoreD2 { get { lock (_sync) return _d2; } }
        public double ScoreD3 { get { lock (_sync) return _d3; } }
        public double ScoreD4 { get { lock (_sync) return _d4; } }
        public double ScoreD5 { get { lock (_sync) return _d5; } }
        public double ScoreD6 { get { lock (_sync) return _d6; } }
        public double ScoreD7 { get { lock (_sync) return _d7; } }

        /// <summary>Current consecutive-loss streak count (for Guard rule evaluation).</summary>
        public double ConsecutiveLosses { get { lock (_sync) return _consecutiveLosses; } }

        // ── EWMA debt per dimension (unit: PSI points, 0–100) ────────────────
        // These power the HUD bar display.  Their sum + _carryDebt = 100 − PSI,
        // so the bars are a mathematically exact decomposition of the PSI value.
        // When PSI = 95, all bars are near-zero.  When PSI = 50, the bars sum
        // to ~50 pts and the longest bar identifies the primary cause.
        public double DebtD1 { get { lock (_sync) return _c1; } }
        public double DebtD2 { get { lock (_sync) return _c2; } }
        public double DebtD3 { get { lock (_sync) return _c3; } }
        public double DebtD4 { get { lock (_sync) return _c4; } }
        public double DebtD5 { get { lock (_sync) return _c5; } }
        public double DebtD6 { get { lock (_sync) return _c6; } }
        public double DebtD7 { get { lock (_sync) return _c7; } }

        /// <summary>
        /// True when the most-recent EWMA-running call saw a net position
        /// above profile.SizeMax.  Derived from the authoritative
        /// <c>_prevSizeOverLimit</c> tracked inside the unified D3 evidence
        /// accumulator — not a cached flag maintained across code paths.
        /// HUD consumers should prefer deriving directly from
        /// <c>_positionQuantities</c> against <c>profile.SizeMax</c> when
        /// possible; this accessor is retained for test / convenience callers.
        /// </summary>
        public bool IsOverExposed { get { lock (_sync) return _prevSizeOverLimit > 0.0; } }

        /// <summary>
        /// Current value of the D3 over-limit evidence accumulator E(t),
        /// in units of contract·seconds.  Exposed for diagnostics and tests;
        /// not consumed by HUD.
        /// </summary>
        public double SizeExcessIntegral { get { lock (_sync) return _sizeExcessIntegral; } }

        /// <summary>
        /// Carry-forward PSI debt from the previous session (PSI points, 0–100).
        /// Decays toward zero as the trader demonstrates calm behaviour today.
        /// When non-zero, it contributes to the PSI deficit alongside C1–C7 but is
        /// not attributable to any single current behaviour — it is historical context.
        /// The HUD displays this so the trader can distinguish "recovering from
        /// yesterday" from "recovering from today's own violations".
        /// </summary>
        public double CarryDebt { get { lock (_sync) return _carryDebt; } }

        /// <summary>
        /// Hidden PSI debt from cumulative session P&L deficit (PSI points, 0–100).
        /// Fires when the session's net loss materially exceeds the trader's typical
        /// single-trade loss, reflecting the psychological reality of being deep in
        /// the hole today — independent of any individual trade behaviour.
        /// Resets at session start; carries forward overnight via the same decay as C_i.
        /// </summary>
        public double FinancialStressDebt { get { lock (_sync) return _financialStressDebt; } }

        /// <summary>
        /// Human-readable explanation of the most recent D6 session-window violation.
        /// Set each time CalcD6 detects an out-of-window entry (entry or order event).
        /// Empty string when no violation has fired this session.
        /// Thread-safe (lock-protected).  Consumed by the alert layer to surface
        /// a specific reason alongside the PSI drop notification.
        /// Example: "Session ended 12:00, entry at 12:32 (+32 min)"
        /// </summary>
        public string LastD6ViolationDetail { get { lock (_sync) return _lastD6ViolationDetail; } }
        private string _lastD6ViolationDetail = "";

        /// <summary>
        /// Hidden PSI debt from session duration / cognitive fatigue (PSI points, 0–100).
        /// Rises linearly after the optimal-performance window (default 2 h) and
        /// saturates at FatigueWeight × 100 after FatigueRampMinutes.
        /// Fully reset overnight (sleep restores cognitive resources).
        /// </summary>
        public double FatigueDebt { get { lock (_sync) return _fatigueDebt; } }

        /// <summary>
        /// Hidden PSI debt used to maintain the loss-streak PSI floor while
        /// upholding the PSI identity (PSI = 100 − √(ΣC_i²) − all debts).
        /// Absorbs the gap between "PSI would improve" and prevPsi on each
        /// loss fill during an active streak; decays at the normal recovery
        /// rate once the streak ends.  Non-zero only during active streaks.
        /// Not shown on a dedicated HUD bar but included in the identity sum.
        /// </summary>
        public double StreakFloorDebt { get { lock (_sync) return _streakFloorDebt; } }

        /// <summary>
        /// Net realised P&amp;L for the current session (account currency).
        /// Updated on every closing fill; reset at session start.
        /// Exposed for Guard rule evaluation so rules can fire on daily loss limits
        /// without requiring the Guard to duplicate accounting logic.
        /// </summary>
        public double SessionNetPnl { get { lock (_sync) return _sessionNetPnl; } }

        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Call on every confirmed fill (NT8 ExecutionUpdate).
        /// Updates the discrete-event dimensions (D1/D4/D6/D7) and then
        /// recomputes the continuous-state dimensions (D2/D3/D5) from the
        /// caller-supplied post-fill position snapshots so that PSI reflects
        /// the authoritative exposure state at this moment — not a cached
        /// flag — before the EWMA step runs.
        ///
        /// IMPORTANT: call <see cref="TradeBaseline.UpdateOnExecution"/> BEFORE
        /// this so that session averages are already updated when D4 reads them.
        /// </summary>
        /// <param name="pnl">Gross PnL of this fill (negative = loss).</param>
        /// <param name="size">Filled quantity (contracts / shares).</param>
        /// <param name="fillTime">Event time of the fill (platform time domain).</param>
        /// <param name="isWin">True when pnl &gt; 0.</param>
        /// <param name="holdSeconds">
        /// Seconds from position entry to this close-fill.  Zero for entry fills.
        /// </param>
        /// <param name="postFillPositions">
        /// Snapshot of all open positions AFTER this fill has been applied.
        /// Used to recompute D2 naked-exposure, D3 live size, and D5 hold-time
        /// state (continuous-state signals must reflect current exposure on
        /// every event, not just every 30-second timer tick — the core
        /// real-time requirement).  Pass an empty list on a full close.
        /// </param>
        /// <param name="fillDirection">
        /// Direction of THIS fill:
        ///   +1 = opening / holding a Long position,
        ///   -1 = opening / holding a Short position,
        ///    0 = unknown.
        /// For CLOSING fills, pass the direction of the position that was CLOSED.
        /// </param>
        /// <returns>Updated PSI.</returns>
        public double ProcessExecution(double pnl, double size, DateTime fillTime,
                                       bool isWin, double holdSeconds,
                                       IEnumerable<PositionSnapshot> postFillPositions,
                                       int fillDirection = 0)
        {
            // Backward-compatible thin wrapper.  Callers that haven't yet been
            // upgraded pass ExitKind.Unknown (conservative — engine falls back
            // to pre-v1.1.1 behaviour) and isRoundTripFinal=true (each fill is
            // treated as a complete round-trip, matching the original logic
            // where _consecutiveLosses incremented per fill).
            return ProcessExecution(pnl, size, fillTime, isWin, holdSeconds,
                postFillPositions, fillDirection,
                ExitKind.Unknown, isRoundTripFinal: true, roundTripPnl: pnl);
        }

        /// <summary>
        /// Full-signature fill ingestion with v1.1.1 enhancements:
        /// <para>
        /// • <paramref name="exitKind"/> — classifies the exit intent so D4 can
        ///   distinguish disciplined bracket-triggered closes from manual
        ///   (potentially panic) closes, and so D1's revenge-urgency timer
        ///   is only updated on trader-initiated exits.  See <see cref="ExitKind"/>.
        /// </para><para>
        /// • <paramref name="isRoundTripFinal"/> — true iff this fill brings the
        ///   position FULLY flat (end of a round-trip).  Partial exits set
        ///   this false.  Used to gate <c>_consecutiveLosses</c> updates so a
        ///   3-lot stop-out firing as 3 partial fills counts as ONE consecutive
        ///   loss, not three.
        /// </para><para>
        /// • <paramref name="roundTripPnl"/> — accumulated PnL across all fills
        ///   of the current round-trip.  On partial fills equals fill pnl; on
        ///   final equals the sum.  Used for win/loss classification in
        ///   <c>_consecutiveLosses</c>; fill pnl still drives <c>_sessionNetPnl</c>.
        /// </para>
        /// </summary>
        public double ProcessExecution(double pnl, double size, DateTime fillTime,
                                       bool isWin, double holdSeconds,
                                       IEnumerable<PositionSnapshot> postFillPositions,
                                       int fillDirection,
                                       ExitKind exitKind,
                                       bool isRoundTripFinal,
                                       double roundTripPnl)
        {
            lock (_sync)
            {
                bool hasRealizedOutcome = holdSeconds > 0 || pnl != 0.0;

                // Round-trip win classification uses accumulated PnL (not the
                // fill's pnl), so a 3-lot stop-out whose first fill happens to
                // be +$5 does not misclassify the round-trip as a win.
                bool roundTripWin = roundTripPnl > 0;

                // ── E2: Round-trip based consecutive-loss counting ─────────────
                // Only update on the FINAL fill of a round-trip (position flat).
                // Partial fills still contribute to _sessionNetPnl (accounting
                // is always per-fill) but the streak counter is per round-trip.
                // This eliminates the v1.1.0 bug where a 3-contract SL fill
                // incremented _consecutiveLosses three times.
                if (hasRealizedOutcome)
                {
                    _sessionNetPnl += pnl;

                    if (isRoundTripFinal)
                    {
                        if (roundTripWin)
                        {
                            _consecutiveLosses *= _cfg.WinStreakDecayFactor;
                            if (_consecutiveLosses < _cfg.StreakClearThreshold)
                                _consecutiveLosses = 0.0;
                        }
                        else
                        {
                            _consecutiveLosses += 1.0;
                        }
                    }
                }

                double muLoss = _baseline.GetEffectiveMuLoss();
                double muSize = _baseline.GetEffectiveMuSize(_profile);

                // ── Discrete-event dimensions (D1/D4/D6/D7) ──────────────────
                _d1 = CalcD1(size, fillTime, muLoss, muSize, hasRealizedOutcome, fillDirection);

                // E3/E4: D4 now receives ExitKind and the round-trip flag.
                //   ProtectiveStop / Target → per-trade signal = 0 (bracket
                //     execution is NOT evidence of composure deterioration).
                //   Manual / Unknown / Reversal / SystemClose → per-trade
                //     signal runs but is capped at D4PerTradeSingleSampleCap
                //     (single fill can never saturate D4).
                //   Non-final partial close → skip per-trade (wait for the
                //     round-trip to complete so hold time is well-defined).
                bool d4UsePerTrade = hasRealizedOutcome
                                   && isRoundTripFinal
                                   && exitKind != ExitKind.ProtectiveStop
                                   && exitKind != ExitKind.Target;

                _d4 = CalcD4(holdSeconds, roundTripWin, computePerTrade: d4UsePerTrade);

                // D6 (session window) is an entry-time violation — suppress on closes.
                _d6 = hasRealizedOutcome ? _d6 : CalcD6(fillTime);

                // D7 (pace) — only updates on entry fills.
                _d7 = CalcD7(fillTime, isEntry: !hasRealizedOutcome);

                // ── D2 adverse-move state hygiene on full close ──────────────
                // Partial closes retain the stop-manipulation history for the
                // residual exposure; only purge when the position is fully flat.
                bool anyOpenPositionAfterFill = false;
                if (postFillPositions != null)
                {
                    foreach (var p in postFillPositions)
                        if (p != null && p.Quantity > 0) { anyOpenPositionAfterFill = true; break; }
                }
                if (hasRealizedOutcome && !anyOpenPositionAfterFill)
                {
                    foreach (var kv in _adverseMoves)
                        _slAdverseMovesTotal += kv.Value;
                    _adverseMoves.Clear();
                    _prevSlTicks.Clear();
                }

                // ── E5: D1 revenge-clock gating by ExitKind ──────────────────
                // _lastRealizedFillTime seeds the "re-entry urgency" window in
                // CalcD1.  Bracket-triggered exits (ProtectiveStop/Target) are
                // pre-planned outcomes the trader committed to on entry — they
                // don't generate the same salience as a trader-initiated close.
                // So we update the objective ledger (_lastRealizedPnl, streak,
                // direction) regardless, but only MANUAL/UNKNOWN/Reversal/SystemClose
                // exits reset the urgency timer.  A rapid re-entry after a
                // bracket SL still sees streak pressure (D1 floor rises with
                // _consecutiveLosses) but not the urgency spike.
                if (hasRealizedOutcome)
                {
                    _lastRealizedPnl = isRoundTripFinal ? roundTripPnl : pnl;
                    if (fillDirection != 0)
                        _lastRealizedDirection = fillDirection;

                    bool bracketExit = (exitKind == ExitKind.ProtectiveStop ||
                                        exitKind == ExitKind.Target);
                    if (!bracketExit)
                        _lastRealizedFillTime = fillTime;

                    // ── E6: Process-violation ledger (observability only) ────
                    // Record manual quick-exits with small MAE as candidate
                    // discipline violations.  This does NOT affect PSI in
                    // v1.1.1; it populates a ring buffer surfaced via
                    // RecentProcessEvents for future Dashboard integration
                    // (§14 discipline-based recovery) and for diagnostic
                    // output when debugging discipline-vs-panic discrimination.
                    if (isRoundTripFinal && !roundTripWin && !bracketExit)
                        RecordProcessEventOnManualExit(
                            fillTime, holdSeconds, roundTripPnl, exitKind);
                }

                // ── Continuous-state dimensions (D2 naked / D3 size / D5 hold) ─
                bool nakedDetected;
                bool overExposed;
                RecomputeContinuousStateFromPositions(
                    postFillPositions, fillTime,
                    out nakedDetected, out overExposed);

                _financialStressRaw = CalcFinancialStress();
                _fatigueRaw         = CalcFatigue(fillTime);

                return ApplyDecomposedEwma(fillTime,
                    overExposed: overExposed,
                    isLossEvent: hasRealizedOutcome && isRoundTripFinal && !roundTripWin);
            }
        }

        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Call on every NT8 OrderUpdate that modifies a stop-loss price.
        /// Updates D2 (stop manipulation) and refreshes continuous-state
        /// dimensions (D2 naked / D3 size / D5 hold) from the authoritative
        /// open-position set so that PSI reflects current exposure at this
        /// moment, not whatever the last timer poll cached.
        /// </summary>
        /// <param name="orderId">Unique NT8 order ID string.</param>
        /// <param name="newSlTicks">
        /// New stop-loss width in ticks (absolute distance from entry; always positive).
        /// </param>
        /// <param name="orderTime">Time of this order change (platform time domain).</param>
        /// <param name="positions">
        /// Current open-position snapshots.  Used to refresh D2 naked / D3 / D5
        /// in lockstep with D2's stop-manipulation update.  Pass an empty list
        /// if no positions are open.
        /// </param>
        public void ProcessOrderChange(string orderId, double newSlTicks,
                                       DateTime orderTime,
                                       IEnumerable<PositionSnapshot> positions)
        {
            if (string.IsNullOrEmpty(orderId) || newSlTicks <= 0) return;

            lock (_sync)
            {
                if (_prevSlTicks.TryGetValue(orderId, out double prevTicks))
                {
                    if (newSlTicks > prevTicks + _cfg.D2SlTickRoundingBuffer)
                    {
                        int prev = _adverseMoves.TryGetValue(orderId, out int cv) ? cv : 0;
                        _adverseMoves[orderId] = prev + 1;
                    }
                }
                _prevSlTicks[orderId] = newSlTicks;

                // D2 adverse-move component reflects the stop-width.
                double d2AdverseComponent = CalcD2(newSlTicks);

                // Recompute continuous-state from positions (updates _d3, _d5 and
                // naked-exposure component of _d2).  The adverse-move signal we
                // just computed is merged in as max() so both sub-signals ride.
                bool nakedDetected;
                bool overExposed;
                RecomputeContinuousStateFromPositions(
                    positions, orderTime,
                    out nakedDetected, out overExposed);
                if (d2AdverseComponent > _d2) _d2 = d2AdverseComponent;

                _financialStressRaw = CalcFinancialStress();
                _fatigueRaw         = CalcFatigue(orderTime);

                ApplyDecomposedEwma(orderTime, overExposed: overExposed);
            }
        }

        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Session heartbeat.  Called periodically (default every 30 seconds)
        /// from the background timer.  With continuous-state signals now
        /// refreshed on every fill/order event (see ProcessExecution and
        /// ProcessOrderChange), the timer's role has narrowed to:
        ///   • session-duration signals (fatigue)
        ///   • naked-exposure time accumulation between fills
        ///   • ghost-position cleanup propagation to the EWMA clock
        ///   • EWMA recovery during inactivity
        /// </summary>
        public double PollPositions(IEnumerable<PositionSnapshot> positions,
                                    DateTime platformTime,
                                    out bool nakedPositionDetected)
        {
            lock (_sync)
            {
                _lastPollPlatformTime = platformTime;

                bool overExposed;
                RecomputeContinuousStateFromPositions(
                    positions, platformTime,
                    out nakedPositionDetected, out overExposed);

                // Session-duration accounting (B2): integrate overexposure
                // and naked-exposure seconds between consecutive polls.  Cap
                // the per-sample delta at 5 minutes so a long idle gap or
                // overnight jump cannot corrupt the totals.
                if (_lastPosSampleAt != DateTime.MinValue)
                {
                    double dSec = (platformTime - _lastPosSampleAt).TotalSeconds;
                    if (dSec > 0.0 && dSec <= 300.0)
                    {
                        if (overExposed)             _overExposureTotalSec += dSec;
                        if (nakedPositionDetected)   _nakedTotalSec        += dSec;
                    }
                }
                _lastPosSampleAt = platformTime;

                _financialStressRaw = CalcFinancialStress();
                _fatigueRaw         = CalcFatigue(platformTime);

                return ApplyDecomposedEwma(platformTime, overExposed: overExposed);
            }
        }

        // ─────────────────────────────────────────────────────────────────────
        // RecomputeContinuousStateFromPositions
        //
        // Single shared code path that updates the continuous-state dimensions
        // (D2 naked, D3 size, D5 hold) from the authoritative open-position
        // snapshot set.  Called from every engine entry point that runs the
        // EWMA step (ProcessExecution, ProcessOrderChange, PollPositions) so
        // these signals are always in sync with the current exposure state —
        // the core "derived state, never cached" principle from
        // first-principles-engineering.mdc.
        //
        // Outputs:
        //   nakedDetected — true when at least one position is naked past grace.
        //   overExposed   — true when at least one position's Quantity exceeds
        //                   profile.SizeMax.  Passed through to ApplyDecomposedEwma
        //                   to drive recovery-tau selection and HUD display,
        //                   replacing the old _liveOverExposed cached flag.
        // ─────────────────────────────────────────────────────────────────────
        private void RecomputeContinuousStateFromPositions(
            IEnumerable<PositionSnapshot> positions,
            DateTime eventTime,
            out bool nakedDetected,
            out bool overExposed)
        {
            nakedDetected = false;
            overExposed   = false;

            // D5 (and naked-detection signal) from the authoritative position set.
            _d5 = CalcD5(positions, out nakedDetected);

            // Live maximum net position across all open snapshots.
            double liveMaxSize = 0.0;
            if (positions != null)
            {
                foreach (var snap in positions)
                {
                    if (snap == null) continue;
                    if (snap.Quantity > liveMaxSize) liveMaxSize = snap.Quantity;
                }
            }

            double sizeMax = _profile != null ? _profile.SizeMax : double.PositiveInfinity;
            double excessNow = Math.Max(0.0, liveMaxSize - sizeMax);
            overExposed = excessNow > 0.0;

            // ── D3: update the unified over-limit evidence accumulator E(t) ──
            // One state variable, three physically-homogeneous contributions,
            // no "exceptional path" branches.  See the state-field comment for
            // the design derivation.
            UpdateSizeExcessIntegral(excessNow, eventTime);

            _d3 = CalcD3(_sizeExcessIntegral);

            // D2 naked-exposure continuous signal: time-integrated alarm
            // (1 − exp(−nakedSec / τ)), merged with any existing D2 adverse-
            // move component via max() so both sub-signals ride.
            if (nakedDetected)
            {
                if (_nakedStateBeganAt == DateTime.MinValue)
                    _nakedStateBeganAt = eventTime;
                double nakedSec = Math.Max(0.0,
                    (eventTime - _nakedStateBeganAt).TotalSeconds);
                double nakedRaw = 1.0 - Math.Exp(
                    -nakedSec / Math.Max(0.1, _cfg.D2NakedTimeConstantSec));
                if (nakedRaw > _d2) _d2 = nakedRaw;
            }
            else
            {
                _nakedStateBeganAt = DateTime.MinValue;
            }
        }

        // ─────────────────────────────────────────────────────────────────────
        // UpdateSizeExcessIntegral — advance E(t) by one sample.
        //
        // Every call represents a sample of the continuous state |q(t)| at
        // eventTime.  Between samples we approximate the excess trajectory by
        // sample-and-hold (excess held at the previous sample value until the
        // next event arrives) — the same mechanism D5 uses for naked-hold
        // accumulation.
        //
        // Order of operations is intentional:
        //   1. Integrate persistence over the just-closed interval using the
        //      PREVIOUS excess.  While oversize, this grows E.  While back
        //      within profile (ex_prev = 0), this term is zero.
        //   2. Decay only if ex_prev = 0 (no persistence contribution this
        //      interval) and E > 0.  First-order relaxation; no cooldown flag.
        //   3. Commit jump: credit the DECISION to deepen the over-limit
        //      state (ex_now > ex_prev).  This is what keeps a zero-duration
        //      oversize still registering, closing the scalper loophole.
        //
        // Δt is clamped at 300 s to bound a pathological idle/clock gap;
        // same defensive cap used by the other continuous-state counters.
        // ─────────────────────────────────────────────────────────────────────
        private void UpdateSizeExcessIntegral(double excessNow, DateTime eventTime)
        {
            double exPrev = _prevSizeOverLimit;

            double dt = 0.0;
            if (_sizeExcessSampleAt != DateTime.MinValue)
            {
                dt = (eventTime - _sizeExcessSampleAt).TotalSeconds;
                if (dt < 0.0)   dt = 0.0;
                if (dt > 300.0) dt = 300.0;
            }
            _sizeExcessSampleAt = eventTime;

            // (1) Persistence integration over [t_prev, t_now], using ex_prev
            //     as the held excess value.  Adds contract·seconds proportional
            //     to how much over limit we were since the last sample.
            if (dt > 0.0 && exPrev > 0.0)
                _sizeExcessIntegral += exPrev * dt;

            // (2) Natural decay when the preceding interval was fully within
            //     profile (ex_prev == 0).  E relaxes toward 0 on τ_decay.
            //     No separate cooldown flag / state-machine — the SAME
            //     mechanism handles "just back within profile" and "long since
            //     back within profile".
            if (dt > 0.0 && exPrev == 0.0 && _sizeExcessIntegral > 0.0)
            {
                double tau = Math.Max(0.1, _cfg.D3ExcessDecayTauSec);
                _sizeExcessIntegral *= Math.Exp(-dt / tau);
            }

            // (3) Commit jump on step-up into / deeper into over-limit state.
            //     Δ(excess)⁺ × k_commit has unit contract·seconds — dimensionally
            //     equivalent to persistence.  A scalper who sizes 6 when plan
            //     says 3 jumps E by 3 × k_commit even if they close in 0 s.
            double deltaExcess = excessNow - exPrev;
            if (deltaExcess > 0.0)
                _sizeExcessIntegral += deltaExcess * Math.Max(0.0, _cfg.D3CommitEquivalentSec);

            _prevSizeOverLimit = excessNow;

            // Defensive clamp: E is intrinsically non-negative.  FP drift or a
            // pathological config (τ_decay ≈ 0) cannot produce a sign flip
            // that would make D3_raw negative downstream.
            if (_sizeExcessIntegral < 0.0) _sizeExcessIntegral = 0.0;
        }

        // ─────────────────────────────────────────────────────────────────────

        /// <summary>
        /// Called at startup or Playback restart when only the previous session's
        /// final PSI is available (individual C_i values are not persisted to disk).
        ///
        /// Opening PSI is computed via overnight EWMA decay of the aggregate deficit:
        ///   openPSI = 100 − (100 − prevFinalPsi) × exp(−estimatedHours / τ_overnight)
        ///
        /// This replaces the old three-bucket (threshold → fixed value) system, which
        /// created cliff edges (PSI 69 → 80, PSI 70 → 95) and a flat floor (PSI 0–39
        /// all gave 65).  The continuous formula gives proportional, fair opening values.
        ///
        /// All C_i debts are reset to zero because they are not recoverable at startup;
        /// the entire history is summarised as _carryDebt = 100 − openPSI.
        /// </summary>
        /// <param name="previousSessionFinalPsi">
        /// PSI at the moment the previous session ended.  Pass 100 on first run.
        /// </param>
        public void StartNewSession(double previousSessionFinalPsi)
        {
            lock (_sync)
            {
                // Continuous overnight decay: deficit shrinks proportionally.
                double decayFactor = Math.Exp(
                    -_cfg.OvernightEstimatedHours / _cfg.OvernightRecoveryTauHours);
                _psi = 100.0 - (100.0 - previousSessionFinalPsi) * decayFactor;
                _psi = Math.Max(0.0, Math.Min(100.0, _psi));

                // C_i history is not available at startup — encode the entire deficit
                // as carryDebt so the decomposition identity holds (PSI = 100 − √(ΣC_i²) − carryDebt).
                _c1 = _c2 = _c3 = _c4 = _c5 = _c6 = _c7 = 0.0;
                _carryDebt = Math.Max(0.0, 100.0 - _psi);

                // D7 pace state must be reset on a full session restart (startup /
                // Playback rewind).  Kept separate from ClearSessionBehavioralStateInternal
                // because OnPositionTrackingCorrection must NOT clear pace history.
                ResetD7PaceState();

                // Reset hidden debt components — new session starts clean.
                _financialStressDebt = 0.0;
                _fatigueDebt         = 0.0;
                _streakFloorDebt     = 0.0;

                ClearSessionBehavioralStateInternal();

                // Force deltaSec = 0 on the first event of the new session so the
                // EWMA does not attack C_i before any real time has elapsed.
                _lastEwmaUpdate = DateTime.MinValue;
            }
        }

        /// <summary>
        /// Called at a real cross-day session boundary when live C_i debt values are
        /// still in memory.  Applies the actual overnight elapsed time to each dimension's
        /// debt independently, then resets intra-session behavioural state.
        ///
        ///   C_i_open = C_i_close × exp(−elapsedHours / τ_overnight)
        ///
        /// Benefits over StartNewSession:
        ///   • No information loss — all seven debt components are individually preserved.
        ///   • Actual elapsed time is used (handles weekends, holidays automatically).
        ///   • A 60-hour weekend gap recovers more than a 16-hour overnight gap, which
        ///     is psychologically correct.
        /// </summary>
        public void ApplyOvernightDecay(double elapsedHours)
        {
            lock (_sync)
            {
                double decay = Math.Exp(
                    -Math.Max(0.0, elapsedHours) / _cfg.OvernightRecoveryTauHours);

                _c1 *= decay;  _c2 *= decay;  _c3 *= decay;
                _c4 *= decay;  _c5 *= decay;  _c6 *= decay;  _c7 *= decay;
                _carryDebt *= decay;

                // D3 unified evidence accumulator decays on the same overnight
                // envelope as C_i — the "memory of yesterday's oversize" should
                // dissolve at the same rate as yesterday's PSI debt itself.
                _sizeExcessIntegral *= decay;

                // Financial stress carries forward overnight (partial decay) —
                // a trader who ended badly still feels it the next morning.
                _financialStressDebt *= decay;

                // Fatigue fully resets overnight — sleep restores cognitive resources.
                _fatigueDebt = 0.0;

                // Streak floor fully resets overnight — new day, fresh start.
                _streakFloorDebt = 0.0;

                // Recompute PSI via the p-norm identity used everywhere else.
                double sumSq = _c1*_c1 + _c2*_c2 + _c3*_c3 + _c4*_c4
                             + _c5*_c5 + _c6*_c6 + _c7*_c7;
                double dimNorm = Math.Sqrt(sumSq);
                _psi = 100.0 - dimNorm - _carryDebt - _financialStressDebt
                             - _fatigueDebt - _streakFloorDebt;
                _psi = Math.Max(0.0, Math.Min(100.0, _psi));

                ResetD7PaceState();
                ClearSessionBehavioralStateInternal();

                // Same rationale as StartNewSession: the first fill of the new day
                // must not see a giant deltaSec that would double-decay the C_i
                // already handled by the overnight formula above.
                _lastEwmaUpdate = DateTime.MinValue;
            }
        }

        // =====================================================================
        // Reset paths — three orthogonal levels (see ARCHITECTURE.md §6)
        // =====================================================================
        //
        //   OnPositionTrackingCorrection  — Fix A / OnPositionUpdate / Rule 3
        //     Scope: position-related state only (flags that could cause false
        //            penalties on the NEXT fill if left stale).
        //     Preserves: C_i debts, PSI, carryDebt, session P&L, D7 pace,
        //                _consecutiveLosses, _lastRealized*, clock anchors,
        //                hidden debts (financialStress, fatigue).
        //
        //   ResetClockAnchor              — TradingClock.ModeChanged
        //     Scope: _lastEwmaUpdate, _lastPollPlatformTime.
        //     Forces the next PSI event to start a fresh EWMA integration in
        //     the new time domain instead of integrating across the switch.
        //
        //   ClearSessionBehavioralStateInternal — StartNewSession / ApplyOvernightDecay
        //     Scope: full reset (position + session-level behavioural state).
        //     Hidden debts are handled by the caller (preserved across overnight
        //     decay, zeroed on full StartNewSession).
        // =====================================================================

        /// <summary>
        /// Called by position-tracking correction paths (Fix A stale-direction
        /// guard, OnPositionUpdate external-flat sync, Rule 3 DESYNC rebuild).
        /// Clears ONLY state that was tied to the (now corrected) position dict;
        /// does NOT touch C_i, PSI, carryDebt, P&L history, D7 pace, or clock
        /// anchors.  The trader's psychological record is preserved: only
        /// position-derived flags are cleared.
        /// </summary>
        public void OnPositionTrackingCorrection()
        {
            lock (_sync)
            {
                ResetPositionTrackingStateInternal();
            }
        }

        /// <summary>
        /// Called on <see cref="TradingMode"/> transitions (Live↔Playback/Sim)
        /// to force the next PSI event into a fresh EWMA integration in the new
        /// time domain.  All C_i debts and PSI value are preserved; only the
        /// clock anchors (<see cref="_lastEwmaUpdate"/>, <see cref="_lastPollPlatformTime"/>)
        /// are reset.
        /// </summary>
        public void ResetClockAnchor()
        {
            lock (_sync)
            {
                _lastEwmaUpdate       = DateTime.MinValue;
                _lastPollPlatformTime = DateTime.MinValue;
            }
        }

        // Internal helper (must be called from within _sync lock).
        private void ResetD7PaceState()
        {
            _recentEntryTimes.Clear();
            _sessionFirstEntryTime = DateTime.MinValue;
            _sessionEntryCount     = 0;
            _lastEntryFillTime     = DateTime.MinValue;
        }

        // Position-tracking-only reset.  Safe to call when position dicts were
        // found to be stale/ghost; none of the trader's psychological history
        // is touched.
        private void ResetPositionTrackingStateInternal()
        {
            // D3 unified evidence accumulator: a position-tracking desync means
            // |q| and therefore excess(t) was wrong while the ghost was live;
            // the evidence it accumulated is unreliable.  Discard entirely so
            // the next authoritative sample starts a clean integration.
            _sizeExcessIntegral       = 0.0;
            _prevSizeOverLimit        = 0.0;
            _sizeExcessSampleAt       = DateTime.MinValue;

            _nakedStateBeganAt        = DateTime.MinValue;

            _adverseMoves.Clear();
            _prevSlTicks.Clear();

            // Transient D2/D5 raws are tied to the now-removed position; clear
            // so the next recompute runs from the authoritative position set.
            _d2 = 0.0;
            _d3 = 0.0;
            _d5 = 0.0;
        }

        // Full session behavioural reset.  Called by StartNewSession (from
        // scratch) and ApplyOvernightDecay (cross-day boundary).  Clears
        // everything cleared by ResetPositionTrackingStateInternal PLUS the
        // session-scoped accumulators (P&L streaks, _sessionNetPnl, session
        // violation counts, all raw D-scores).  Does NOT clear hidden debts
        // (_financialStressDebt, _fatigueDebt) — the caller handles those
        // according to its policy (preserve-with-decay vs zero).  Does NOT
        // clear D7 pace buffers — ResetD7PaceState is a separate call.
        private void ClearSessionBehavioralStateInternal()
        {
            ResetPositionTrackingStateInternal();

            _consecutiveLosses       = 0.0;
            _lastRealizedPnl         = 0.0;
            _lastRealizedFillTime    = DateTime.MinValue;
            _lastRealizedDirection   = 0;

            _lastPollPlatformTime    = DateTime.MinValue;

            _sessionNetPnl               = 0.0;
            _financialStressRaw          = 0.0;
            _fatigueRaw                  = 0.0;
            _streakFloorDebt             = 0.0;
            _sessionWindowViolationCount = 0;
            _lastD6ViolationDetail       = "";

            // E6: clear process-violation ledger at session boundary — the
            // discipline signal is inherently session-scoped.
            _processEvents.Clear();

            _d1 = _d4 = _d6 = _d7 = 0.0;
            // (_d2, _d3, _d5 already cleared by ResetPositionTrackingStateInternal)

            // B2: reset session observability counters.  Peaks/durations are
            // session-scoped by definition; preserving them across sessions
            // would poison the EOD summary log.
            _peakC1 = _peakC2 = _peakC3 = _peakC4 = 0.0;
            _peakC5 = _peakC6 = _peakC7 = 0.0;
            _peakDimNorm            = 0.0;
            _minPsiThisSession      = _psi;
            _overExposureTotalSec   = 0.0;
            _nakedTotalSec          = 0.0;
            _slAdverseMovesTotal    = 0;
            _lastPosSampleAt        = DateTime.MinValue;
        }

        // =====================================================================
        // Session summary (B2)
        //
        // Builds a single-line, structured summary of the session's
        // psychological footprint for emission at session close (e.g. when
        // MeridianPSI observes the flat-to-flat or a new trading day).
        // Read under lock and returns a caller-owned string — no allocations
        // on the hot path.
        //
        // Format is intentionally flat key=value so it grep's cleanly from
        // the NT8 log file without JSON pretty-printing noise.
        // =====================================================================
        public string BuildSessionSummary()
        {
            lock (_sync)
            {
                int slMovesTotal = 0;
                foreach (var kv in _adverseMoves)
                    slMovesTotal += kv.Value;
                // Include persisted _slAdverseMovesTotal (events that cleared
                // _adverseMoves mid-session, e.g. on flatten).
                slMovesTotal += _slAdverseMovesTotal;

                return string.Format(
                    "[PsiEngine] SESSION SUMMARY " +
                    "psi_now={0:F1} psi_min={1:F1} peak_dimNorm={2:F1} " +
                    "peak_C=[D1={3:F1} D2={4:F1} D3={5:F1} D4={6:F1} " +
                    "D5={7:F1} D6={8:F1} D7={9:F1}] " +
                    "overExp_sec={10:F0} naked_sec={11:F0} " +
                    "d6_violations={12} sl_adverseMoves={13} " +
                    "losses_streak={14:F1} session_pnl={15:F2} " +
                    "debts(fs={16:F1} fa={17:F1} carry={18:F1} sf={19:F1})",
                    _psi, _minPsiThisSession, _peakDimNorm,
                    _peakC1, _peakC2, _peakC3, _peakC4,
                    _peakC5, _peakC6, _peakC7,
                    _overExposureTotalSec, _nakedTotalSec,
                    _sessionWindowViolationCount, slMovesTotal,
                    _consecutiveLosses, _sessionNetPnl,
                    _financialStressDebt, _fatigueDebt, _carryDebt, _streakFloorDebt);
            }
        }

        // =====================================================================
        // Dimension calculations  (called from within the lock)
        // =====================================================================

        // ── D1: Revenge Entry ─────────────────────────────────────────────────
        // Three-way AND: significant loss on last fill × quick re-entry × larger size.
        // Returns 0 unless ALL three conditions are met.
        //
        // Direction-reversal discount (ReversalPenaltyFactor):
        //   When the new entry is in the OPPOSITE direction to the closed position,
        //   the score is multiplied by ReversalPenaltyFactor (default 0.25).
        //   Rationale: closing Short and immediately going Long is often a tactical
        //   "flip" driven by a new signal, not emotional revenge (especially for
        //   scalpers).  Same-direction re-entry (double-down) always uses the full
        //   penalty since it is the canonical revenge pattern.
        //
        //   The discount is intentionally NOT zero so that an outsized flip
        //   (e.g. 4× position after a big loss) still registers weakly.

        private double CalcD1(double size, DateTime fillTime, double muLoss,
                               double muSize, bool hasRealizedOutcome, int entryDirection = 0)
        {
            // ── Continuous streak-pressure floor (background) ────────────────
            // Uses D1StreakBackgroundBase — intentionally SMALLER than D1ConsecutiveLossBase.
            // Design separation:
            //   Background  (D1StreakBackgroundBase = 0.25): quiet, persistent floor applied on
            //     close fills and as the entry-urgency minimum.  Kept small enough that a
            //     disciplined 45%-win-rate trader whose streak oscillates 1–3 without ever
            //     fully clearing does not accumulate excessive C1 debt over a full session.
            //   Entry urgency (D1ConsecutiveLossBase = 0.50): the stronger streak component
            //     used inside lossX, so fast re-entries after losses still fire meaningfully.
            double streakBackground = _cfg.D1StreakBackgroundBase
                                    * (1.0 - Math.Exp(-_cfg.D1ConsecutiveLossGain * _consecutiveLosses));

            if (hasRealizedOutcome)
                // Close fill: record the loss in _consecutiveLosses (done above in
                // ProcessExecution) but do NOT create D1 debt yet.  D1 is "Revenge
                // Entry" — the signal must fire when the trader OBSERVABLY re-enters
                // after a loss, not when a loss occurs.  streakBackground will still
                // apply at the NEXT entry fill as a floor (see fallback returns below),
                // so the streak is fully accounted for; it just manifests at entry
                // time rather than close time.  This aligns with the discipline-over-
                // outcome invariant: a disciplined stop-loss hit must never cause PSI
                // to drop on its own.
                return 0.0;

            // ── Entry-fill gate checks ────────────────────────────────────────
            if (_lastRealizedFillTime == DateTime.MinValue) return streakBackground;
            if (_lastRealizedPnl >= 0) return streakBackground;  // after a win: no entry urgency

            double T = _profile.MaxReentrySeconds;
            if (T <= 0) return streakBackground;
            double deltaSec = Math.Max(_cfg.D1MinDeltaSeconds,
                (fillTime - _lastRealizedFillTime).TotalSeconds);
            if (deltaSec >= T) return streakBackground;  // entry too far after loss: floor only

            double urgency = (T - deltaSec) / T;

            // ── lossX: statistical severity vs full streak pressure ──────────
            // Entry urgency uses D1ConsecutiveLossBase (the stronger value) for lossX,
            // so the urgency spike on fast re-entries is not weakened by the background change.
            double sigmaLoss  = _baseline.GetEffectiveSigmaLoss();
            double lossZ      = muLoss > 0
                              ? (Math.Abs(_lastRealizedPnl) - muLoss) / sigmaLoss
                              : 0.0;
            double lossXStat  = NormalCdf(lossZ - _cfg.ZThreshold);

            double streakPressure = _cfg.D1ConsecutiveLossBase
                                  * (1.0 - Math.Exp(-_cfg.D1ConsecutiveLossGain * _consecutiveLosses));
            double lossX = Math.Max(lossXStat, streakPressure);
            if (lossX <= 0) return streakBackground;

            double sigmaSize = _baseline.GetEffectiveSigmaSize(_profile);
            double sizeZ     = muSize > _cfg.D1MuSizeZeroGuard
                             ? (size - muSize) / sigmaSize : 0.0;
            double sizeX     = NormalCdf(Math.Max(sizeZ, 0.0) - _cfg.ZThreshold * 0.5);

            double baseScore = Clamp01(urgency * Math.Max(sizeX, _cfg.D1MinSizeFactor) * lossX);

            bool isReversal = _lastRealizedDirection != 0
                           && entryDirection        != 0
                           && entryDirection        != _lastRealizedDirection;

            double dirFactor = isReversal
                ? Clamp01(_profile.ReversalPenaltyFactor)
                : 1.0;

            // Entry urgency is floored at streakBackground: the spike from a fast
            // re-entry cannot push D1 BELOW the ambient streak pressure.
            return Clamp01(Math.Max(baseScore * dirFactor, streakBackground));
        }

        // ── D2: Stop-Loss Manipulation ────────────────────────────────────────
        // Exponential penalty on the number of adverse stop moves, boosted if
        // the current SL already exceeds the profile maximum.

        private double CalcD2(double currentSlTicks)
        {
            // Count the maximum adverse moves across all tracked orders.
            int maxAdverse = 0;
            foreach (var kv in _adverseMoves)
                if (kv.Value > maxAdverse) maxAdverse = kv.Value;

            double baseScore = 1.0 - Math.Exp(-_cfg.D2AdverseSaturationRate * maxAdverse);

            double maxTicks = _profile.SlTicksMax;
            if (maxTicks > 0 && currentSlTicks > maxTicks * _cfg.D2SlBreachMultiplier)
                return Clamp01(baseScore * (currentSlTicks / maxTicks));

            return Clamp01(baseScore);
        }

        // ── D3: Position Size Outlier ─────────────────────────────────────────
        // Z-score scaled by the consecutive-loss multiplier (context-sensitive).
        // Multiplier is applied INSIDE NormalCdf so the output stays in (0, 1).
        //
        // Mapping from the unified over-limit evidence accumulator E(t) to
        // the D3 raw signal.  E is maintained by UpdateSizeExcessIntegral;
        // this function is a pure smooth bijection:
        //
        //     D3_raw  =  1 - exp( -E / D3ExcessIntegralTau )
        //
        // Properties that fall out of this formulation:
        //   • D3_raw = 0 exactly when E = 0 (position never over limit in
        //     recent memory).  No floor, no special-case branch.
        //   • A zero-duration oversize still registers, because the commit
        //     jump in UpdateSizeExcessIntegral pushes E above 0 on the
        //     decision moment itself — closing the "scalper loophole".
        //   • Persistent oversize escalates via the integration term; long
        //     oversize saturates D3_raw toward 1.
        //   • Once back within profile, E decays on τ_decay, so D3_raw
        //     relaxes smoothly to 0 without any cooldown state machine.
        //   • D3 does NOT read consecutive losses, pnl, or outcome of any
        //     kind — process only, as required by psi-discipline-over-outcome.

        private double CalcD3(double sizeExcessIntegral)
        {
            if (sizeExcessIntegral <= 0.0) return 0.0;
            double tau = Math.Max(0.1, _cfg.D3ExcessIntegralTau);
            return Clamp01(1.0 - Math.Exp(-sizeExcessIntegral / tau));
        }

        // ── D4: Hold-Time Collapse ────────────────────────────────────────────
        // Two complementary signals combined via max():
        //
        //   Signal 1 — Session average (existing slow signal):
        //     Compares the session's average win/loss hold-time ratio to the
        //     long-term historical baseline.  Confidence scales with session trade
        //     count.  Reliable but lags real-time anomalies.
        //
        //   Signal 2 — Per-trade (new fast signal):
        //     Compares each individual trade's hold time against the historical
        //     baseline distribution via a log-ratio z-score.
        //     Confidence scales with HISTORICAL sample count (not session count),
        //     so the signal is active from the first trade of the day once
        //     sufficient history exists.  Only the "too-short" direction is
        //     detected here (panic exit); "too-long" is owned by D5.

        private double CalcD4(double holdSeconds = 0.0, bool isWin = false,
                               bool computePerTrade = false)
        {
            // ── Signal 1: session average vs historical baseline ──────────────
            double muWinHold  = Math.Max(_cfg.D4MinHoldGuardSec, _baseline.GetEffectiveMuWinHold(_profile));
            double muLossHold = Math.Max(_cfg.D4MinHoldGuardSec, _baseline.GetEffectiveMuLossHold(_profile));

            double sessWin  = Math.Max(0.0, _baseline.SessionAvgWinHold);
            double sessLoss = Math.Max(0.0, _baseline.SessionAvgLossHold);

            double ratioWin  = sessWin  / muWinHold;
            double ratioLoss = sessLoss / muLossHold;

            double logOdds = Math.Log((ratioLoss + _cfg.D4LogOddsEpsilon)
                                    / (ratioWin  + _cfg.D4LogOddsEpsilon));
            double d4Session = Clamp01(NormalCdf(logOdds - _cfg.ZThreshold));

            // Session confidence: scales the session signal up as data accumulates.
            // Uses a configurable divisor so early-session readings carry less weight,
            // reducing the 5–50× jump artefact seen when a single anomalous trade shifts
            // the session average.  Default divisor=2.0: conf reaches 0.50 at n=8
            // (vs n=4 with the original sqrt(n) formula).
            int    sessionN    = _baseline.SessionTradeCount;
            double effectiveN  = sessionN / Math.Max(1.0, _cfg.D4SessionConfidenceDivisor);
            double seRatio     = effectiveN > 0 ? 1.0 / Math.Sqrt(effectiveN) : 1.0;
            double sessionConf = Clamp01(1.0 - seRatio);
            d4Session *= sessionConf;

            if (!computePerTrade || holdSeconds <= 0)
                return d4Session;

            // ── Signal 2: per-trade vs ACTUAL observed baseline ──────────────
            // Design principle: compare each individual close to the trader's OWN
            // historical holding-time distribution, not to the StrategyProfile prior.
            //
            // Using the prior (e.g. MaxHoldMinutes=30 → muLossHold=900 s) as the
            // comparison target misfires badly for scalpers whose actual holds are
            // 60–300 s: every close looks like a "panic exit" relative to 900 s,
            // leading to d4PerTrade ≈ 0.9+ on every fill.  That then triggers
            // the Boost and SustainedViolation escalation, collapsing PSI to 0
            // even for perfectly disciplined traders.
            //
            // Requirements:
            //   histN >= 10  — need enough actual observations before the signal
            //                  can meaningfully distinguish "panic" from "style".
            //   muHold = actual WelfordStat mean (no prior blending) — once we
            //                  have 10 samples we trust the data over the prior.
            int histN = isWin ? _baseline.WinHold.N : _baseline.LossHold.N;
            if (histN < 10)
                return d4Session;  // not enough personal history; skip per-trade signal

            double observedMu = isWin ? _baseline.WinHold.Mean : _baseline.LossHold.Mean;
            double mu          = Math.Max(_cfg.D4MinHoldGuardSec, observedMu);
            double hold        = Math.Max(_cfg.D4MinHoldGuardSec, holdSeconds);
            double logRatio    = Math.Log(hold / mu);

            // histConf: scales the signal up as history grows (reaches ~0.68 at N=10,
            // ~0.84 at N=40).  Prevents a single outlier sample from firing at full strength.
            double histConf   = Clamp01(1.0 - 1.0 / Math.Sqrt(histN));

            // panicZ > 0 when hold << mu (closed much faster than personal historical mean).
            double panicZ     = -logRatio / _cfg.D4PerTradeLogSigma;
            double d4PerTrade = Clamp01(NormalCdf(panicZ - _cfg.ZThreshold) * histConf);

            // ── E4: Single-sample cap ────────────────────────────────────────
            // A single quick manual exit is ambiguous evidence — it may be
            // panic, or it may be legitimate re-evaluation ("I read the tape
            // wrong, flatten").  Statistically one sample cannot distinguish
            // these; treating it as strong evidence (d4PerTrade → 0.9+) is
            // what produced the v1.1.0 50-point PSI drop on a disciplined SL
            // hit.  The cap limits a single fill's per-trade contribution
            // (psychologically: a weak signal) while preserving accumulation:
            //   • Session signal (d4Session) rises as more quick exits shift
            //     the session average, so repeated quick manual exits still
            //     produce a meaningful red signal.
            //   • EWMA debt C4 is maintained across fills, so a pattern of
            //     quick manual exits holds elevated C4 even with small per-fill
            //     raw values.
            // The cap applies ONLY to the per-trade signal; session signal
            // remains uncapped because it is already confidence-scaled by n.
            if (d4PerTrade > _cfg.D4PerTradeSingleSampleCap)
                d4PerTrade = _cfg.D4PerTradeSingleSampleCap;

            return Math.Max(d4Session, d4PerTrade);
        }

        // ── D5: Position Hold (扛单) Monitor ─────────────────────────────────
        // Timer-driven; detects holding a losing position beyond the trader's
        // personal historical 90th percentile.
        //
        // Aggregation across multiple simultaneous positions:
        //   Old approach: worst = max(d5_i) — ignored all but the worst position,
        //   so ES + NQ both overstaying was no worse than one.
        //   New approach: probability union = 1 - ∏(1 - d5_i) across DISTINCT
        //   instruments.  Within each instrument group, max is taken (handles
        //   Replikanto cross-account copies of the same trade without inflating).
        //
        // MAE (Maximum Adverse Excursion) memory:
        //   Old: if (UnrealizedPnl >= 0) skip — instantly forgave a position that
        //   recovered to breakeven after 3 hours underwater.
        //   New: effectiveLoss = min(currentPnl, MinUnrealizedPnl) — if the
        //   position was ever at -$500, D5 reflects that even if it's now +$1,
        //   until the position is actually closed.

        private double CalcD5(IEnumerable<PositionSnapshot> positions,
                              out bool nakedPositionDetected)
        {
            nakedPositionDetected = false;
            if (positions == null) return 0.0;

            // Naked-position check is disabled when:
            //   (a) user declared themselves a no-stop-loss trader, OR
            //   (b) NoStopGraceSeconds was explicitly set to 0.
            bool checkNaked = !_profile.NoStopLossTrader && _profile.NoStopGraceSeconds > 0;

            double muLoss = _baseline.GetEffectiveMuLoss();
            double p90    = _baseline.GetP90LossHold(_profile);

            // instrD5: best (highest) D5 per unique instrument.
            // Keyed by the instrument portion of the position key (after "::") so
            // that Replikanto cross-account copies of the same trade collapse into
            // one entry and are not double-counted in the union formula.
            var instrD5 = new Dictionary<string, double>();

            foreach (var pos in positions)
            {
                if (pos == null) continue;

                // ── Naked-position check ──────────────────────────────────────
                if (checkNaked &&
                    !pos.HasStopOrder &&
                    pos.HoldSeconds >= _profile.NoStopGraceSeconds)
                {
                    nakedPositionDetected = true;
                    return 1.0; // maximum D5; no need to evaluate other positions
                }

                // ── Extract instrument key for Replikanto dedup ───────────────
                string instrKey = pos.Key != null && pos.Key.Contains("::")
                    ? pos.Key.Substring(pos.Key.IndexOf("::") + 2)
                    : (pos.Key ?? string.Empty);

                // ── MAE: use worst-case PnL seen, not just current ────────────
                // MinUnrealizedPnl is always ≤ 0 (set in PositionSnapshot.Create).
                // If position was at -$500 but recovered to +$10, effectiveLoss = -500.
                // If position was always profitable, effectiveLoss = 0 → skip below.
                double effectiveLoss = Math.Min(pos.UnrealizedPnl, pos.MinUnrealizedPnl);

                if (effectiveLoss >= 0) continue; // never was in meaningful loss territory

                // Loss severity via z-score against the trader's loss baseline.
                double sigmaLoss    = _baseline.GetEffectiveSigmaLoss();
                double lossZ        = sigmaLoss > 0
                    ? (Math.Abs(effectiveLoss) - muLoss) / sigmaLoss : 0.0;
                double lossSeverity = Clamp01(NormalCdf(lossZ));
                double hold         = pos.HoldSeconds;

                double d5;
                if (hold < p90)
                {
                    d5 = lossSeverity * _cfg.D5BackgroundSignalFactor;
                }
                else
                {
                    double denom    = Math.Max(p90, _cfg.D5P90DenomFloorSec);
                    double overtime = (hold - p90) / denom;
                    d5 = Clamp01(Math.Min(_cfg.D5MaxCap,
                        NormalCdf(overtime - _cfg.ZThreshold) * lossSeverity));
                }

                // Keep highest d5 per instrument (collapses Replikanto copies).
                double current;
                if (!instrD5.TryGetValue(instrKey, out current) || d5 > current)
                    instrD5[instrKey] = d5;
            }

            if (instrD5.Count == 0) return 0.0;

            // Probability union across distinct instruments:
            //   P(at least one position is critically held) = 1 - ∏(1 - d5_i)
            // Rationale: holding ES + NQ simultaneously in loss is worse than
            // holding either alone.  A single position with d5=0.7 gives 0.7.
            // Two positions both at d5=0.7 give 1 - 0.3² = 0.91.
            double combined = 0.0;
            foreach (var kv in instrD5)
                combined = 1.0 - (1.0 - combined) * (1.0 - kv.Value);

            return Clamp01(combined);
        }

        // ── D6: Rule Compliance ───────────────────────────────────────────────
        // Structural change: SL-width and size checks REMOVED.
        //   D2 already owns stop-manipulation; D3 already owns size outliers.
        //   Including them here caused double-counting and blurred each dimension's
        //   meaning on the HUD bar display.
        //
        // D6 now focuses exclusively on session-window compliance — the only
        // violation that D2/D3 cannot detect.  Trading outside your declared hours
        // is a uniquely clear psychological signal: inability to stop = loss of
        // control.  A disciplined trader who occasionally finishes 5 minutes late
        // differs from one who trades 3 hours past close; the cumulative escalation
        // mechanism now reflects that distinction.
        //
        // Mechanism:
        //   Each entry outside the declared session window increments the cumulative
        //   counter _sessionWindowViolationCount.  The raw D6 score saturates
        //   exponentially with violation count (1 − exp(−rate × count)).
        //   The hard deduction (surprise-impact component) scales logarithmically
        //   with how far outside the window the entry falls:
        //     overageFactor = 1 + ln(1 + minutesOver / 10)
        //   This gives ×1.07 at +2 min, ×1.47 at +15 min, ×1.69 at +30 min, ×1.85 at +60 min.
        //   The logarithm prevents extreme values while clearly differentiating a
        //   brief overshoot from prolonged out-of-window trading.
        //   Counter resets each session; does NOT reset when re-entering the window
        //   mid-session (violations this session are a cumulative record).

        // ── D6: Rule Compliance (session-window violation, continuous) ───────
        //
        // Design (first-principles):
        //   The raw signal is a product of two smooth factors, both in [0, 1]:
        //
        //     magnitude = 1 − exp(−minutesOver / D6WindowMagnitudeTau)
        //                 (0 min → 0, τ min → 0.63, 2τ → 0.86, 3τ → 0.95)
        //
        //     recency   = 1 − exp(−violationCount / D6RecencyTau)
        //                 (1st → 0.39, 2nd → 0.63, 3rd → 0.78 at τ=2)
        //
        //     raw = magnitude × recency              ∈ [0, 1]
        //
        //   This replaces the prior step-function hard deduction that bypassed
        //   the EWMA pipeline.  The new formulation:
        //     • feeds cleanly through the normal weighted-target / alpha EWMA,
        //     • respects the per-event drop cap and time-domain guards,
        //     • gives a grace-period feel for small overshoots (5 min ≈ 0.47
        //       magnitude), while still escalating to near-1.0 for gross
        //       violations (30+ min, repeated).
        //
        //   Computed on ENTRY fills only.  Order modifications (moving a stop)
        //   are not session-window signals — ProcessOrderChange must not call
        //   this method.

        private double CalcD6(DateTime eventTime)
        {
            TimeSpan tod     = eventTime.TimeOfDay;
            bool     outside = tod < _profile.SessionStart || tod > _profile.SessionEnd;

            if (!outside)
                return 0.0;

            double minutesOver = tod > _profile.SessionEnd
                ? (tod - _profile.SessionEnd).TotalMinutes
                : (_profile.SessionStart - tod).TotalMinutes;

            string boundary = tod > _profile.SessionEnd
                ? string.Format("Session ended {0:hh\\:mm}, entry at {1:hh\\:mm} (+{2:F0} min)",
                      _profile.SessionEnd, tod, minutesOver)
                : string.Format("Session starts {0:hh\\:mm}, entry at {1:hh\\:mm} (-{2:F0} min)",
                      _profile.SessionStart, tod, minutesOver);
            _lastD6ViolationDetail = boundary;

            _sessionWindowViolationCount++;

            double magnitude = 1.0 - Math.Exp(
                -minutesOver / Math.Max(0.1, _cfg.D6WindowMagnitudeTau));
            double recency   = 1.0 - Math.Exp(
                -_sessionWindowViolationCount / Math.Max(0.1, _cfg.D6RecencyTau));

            return Clamp01(magnitude * recency);
        }

        // ── Financial stress (hidden PSI debt component) ──────────────────────
        // Measures cumulative session-level P&L deficit against the trader's
        // historical single-trade loss distribution.  Fires when the session's
        // net loss materially exceeds a typical single-trade loss, reflecting the
        // psychologically well-documented effect of deep-hole pressure on trading
        // decisions (loss aversion amplification, gambler's fallacy, tilt spiral).
        //
        // NOT an event signal — updates on every close fill and poll tick.
        // NOT attributed to any HUD dimension bar — visible via FinancialStressDebt.
        // Carries forward overnight (partial decay); resets on full session start.

        private double CalcFinancialStress()
        {
            if (_sessionNetPnl >= 0) return 0.0;

            double muLoss    = _baseline.GetEffectiveMuLoss();
            double sigmaLoss = _baseline.GetEffectiveSigmaLoss();
            if (muLoss <= 0 || sigmaLoss <= 0) return 0.0;

            // z-score: how many standard deviations does the session deficit exceed
            // a typical single losing trade?  Fires meaningfully only when the hole
            // is deep relative to the trader's own normal loss magnitude.
            double z = (-_sessionNetPnl - muLoss) / sigmaLoss;

            // Confidence scales with session trade count to suppress noise when the
            // session has fewer than a handful of trades.
            int    n          = _baseline.SessionTradeCount;
            double confidence = Clamp01(1.0 - 1.0 / Math.Sqrt(Math.Max(1, n)));

            return Clamp01(NormalCdf(z - _cfg.ZThreshold) * confidence);
        }

        // ── Session fatigue (hidden PSI debt component) ───────────────────────
        // Applies a mild, continuously rising PSI pressure once the active trading
        // session exceeds the trader's "optimal performance window."  Based on the
        // empirically documented decline in decision-making quality, impulse control,
        // and risk calibration in extended cognitive task performance.
        //
        // Signal: linear ramp from 0 at OptimalWindowMinutes to 1.0 after
        // FatigueRampMinutes.  No sudden spike — a gradual, honest temperature reading.
        // Fully resets overnight (sleep restores cognitive resources).
        // Partially recovers during intra-session rest (via EWMA recovery tau).

        private double CalcFatigue(DateTime currentTime)
        {
            if (_sessionFirstEntryTime == DateTime.MinValue) return 0.0;

            double sessionMin = (currentTime - _sessionFirstEntryTime).TotalMinutes;
            double overtime   = Math.Max(0.0, sessionMin - _cfg.FatigueOptimalWindowMinutes);

            // Phase 1: linear ramp 0 → 1.0 over FatigueRampMinutes.
            // Behaviour identical to the original Clamp01 formula up to the end of phase 1.
            double phase1 = Math.Min(1.0, overtime / Math.Max(1.0, _cfg.FatigueRampMinutes));

            // Phase 2: secondary ramp 1.0 → FatigueExtendedCap over FatigueExtendedRampMinutes.
            // Allows the engine to differentiate a 4-hour session from a 7-hour session.
            // Disabled (no extra contribution) when FatigueExtendedRampMinutes = 0.
            double phase2 = 0.0;
            if (_cfg.FatigueExtendedRampMinutes > 0.0)
            {
                double overtime2   = Math.Max(0.0, overtime - _cfg.FatigueRampMinutes);
                double extendRange = _cfg.FatigueExtendedCap - 1.0;
                phase2 = Math.Min(extendRange,
                    overtime2 / _cfg.FatigueExtendedRampMinutes * extendRange);
            }

            return Math.Min(_cfg.FatigueExtendedCap, phase1 + phase2);
        }

        // ── D7: Overtrading (过度交易) ────────────────────────────────────────
        // Measures intra-session entry-pace acceleration (Signal A) and deviation
        // from the trader's profile frequency baseline (Signal B).
        //
        // isEntry == true  → update the pace statistics and compute the score.
        // isEntry == false → return 0.0.
        //
        // IMPORTANT — Signal semantics:
        //   D7 is a POINT-IN-TIME EVENT signal, not a continuous state.  It is only
        //   meaningful at the moment of a new entry: "Is the trader entering too fast
        //   right now?"  Between entries there is no new pace information — the correct
        //   D7 raw value is 0, so the EWMA recovery branch fires and C7 decays.
        //   Returning the stale _d7 from the last entry would falsely continue to
        //   charge D7 debt during position holds and on exit fills (the Q4 / Q3b bug).
        //
        // Partial-fill deduplication: if a second fill arrives within
        // OversizeImpulseCooldownSec of the last recorded entry, it is silently
        // ignored (treated as part of the same order).
        private double CalcD7(DateTime fillTime, bool isEntry)
        {
            if (!isEntry)
                return 0.0;  // No new entry → no pace signal; EWMA recovery branch fires

            // ── Partial-fill deduplication ────────────────────────────────────
            double secSinceLast = _lastEntryFillTime == DateTime.MinValue
                ? double.MaxValue
                : (fillTime - _lastEntryFillTime).TotalSeconds;

            if (secSinceLast < _cfg.OversizeImpulseCooldownSec)
                return 0.0;  // Same order partial fill → first fill already charged EWMA; recovery branch here

            _lastEntryFillTime = fillTime;

            // ── Update session statistics ─────────────────────────────────────
            if (_sessionFirstEntryTime == DateTime.MinValue)
                _sessionFirstEntryTime = fillTime;

            _sessionEntryCount++;

            // Maintain the rolling window of most-recent N timestamps.
            _recentEntryTimes.Enqueue(fillTime);
            while (_recentEntryTimes.Count > _cfg.D7AccelWindowEntries + 1)
                _recentEntryTimes.Dequeue();

            double floor = _cfg.D7MinGapFloorSec;

            // ── Session average inter-entry gap ───────────────────────────────
            double sessionSpanSec = Math.Max(floor,
                (fillTime - _sessionFirstEntryTime).TotalSeconds);
            double sessionAvgGap  = Math.Max(floor,
                sessionSpanSec / Math.Max(1, _sessionEntryCount - 1));

            // ── Signal B: deviation from profile frequency baseline ───────────
            // LambdaVelocity is trades-per-hour declared in StrategyProfile.
            // Convert to seconds-per-trade as the "expected" inter-entry gap.
            //
            // Fires from entry 2 onward (need at least 1 gap for sessionAvgGap
            // to reflect actual pace; at n=1 the gap is the floor, not real data).
            // Confidence ramps from 0 at n=2 to 1.0 at n=D7AccelWindowEntries+1,
            // matching the natural data requirement of Signal A.
            double signalB = 0.0;
            if (_profile.LambdaVelocity > 0.0 && _sessionEntryCount >= 2)
            {
                double expectedGap = 3600.0 / _profile.LambdaVelocity;
                double profileZ    = -Math.Log(sessionAvgGap / Math.Max(floor, expectedGap))
                                     / _cfg.D7ProfileSigma;
                double rawB        = NormalCdf(profileZ - _cfg.ZThreshold);

                // Natural warm-up: full confidence at D7AccelWindowEntries+1 entries
                // (the same number Signal A requires to fill its ring buffer).
                int    minForFull = _cfg.D7AccelWindowEntries + 1;
                double conf       = Math.Min(1.0,
                    (double)(_sessionEntryCount - 2) / Math.Max(1, minForFull - 2));
                signalB = rawB * conf;
            }

            // ── Signal A: session-internal acceleration ───────────────────────
            // Requires at least D7AccelWindowEntries+1 timestamps in the ring buffer.
            double signalA = 0.0;
            if (_recentEntryTimes.Count >= _cfg.D7AccelWindowEntries + 1)
            {
                DateTime[] ts    = _recentEntryTimes.ToArray();
                int         n    = ts.Length;
                double      sumRecent = 0.0;
                int         countR    = 0;

                for (int i = n - _cfg.D7AccelWindowEntries; i < n; i++)
                {
                    sumRecent += Math.Max(floor, (ts[i] - ts[i-1]).TotalSeconds);
                    countR++;
                }

                double recentAvgGap = countR > 0 ? sumRecent / countR : sessionAvgGap;

                // Log-ratio: negative when recent pace is faster than session average.
                double accelZ  = -Math.Log(recentAvgGap / sessionAvgGap)
                                  / _cfg.D7AccelSigma;
                signalA = NormalCdf(accelZ - _cfg.ZThreshold);
            }

            return Math.Max(signalA, signalB);
        }

        // =====================================================================
        // Decomposed EWMA  (first-principles redesign, 2026-04-21)
        //
        // Each of the seven behavioural dimensions maintains a PSI-debt
        // component C_i (unit: PSI points in 0–100, semantically comparable).
        //
        // PSI identity (non-additive aggregation):
        //
        //     dimNorm      = √( Σ C_i² )           (Euclidean / p-norm p=2)
        //     hiddenDebt   = carryDebt + financialStressDebt + fatigueDebt
        //                                          + streakFloorDebt
        //     PSI          = clamp( 100 − dimNorm − hiddenDebt, 0, 100 )
        //
        // WHY p-norm instead of Σ C_i:
        //   A single severe violation (e.g. C3 = 80, all others ≈ 0) must be
        //   able to drive PSI to ~20, matching the psychological reality that
        //   "I just massively oversized" is ALREADY a major instability event
        //   regardless of whether the other 6 dimensions happen to be calm.
        //   With simple summation and weight-scaled targets (old model), the
        //   maximum single-dimension contribution was capped at (weight × 100),
        //   e.g. 16 points for D3 — so PSI could only reach ~84 on a lone
        //   oversize violation.  p-norm with raw×100 targets puts the full
        //   severity back on the dominant dimension while still bounding the
        //   total loss when multiple dimensions worsen simultaneously
        //   (two maxed dimensions → √(100²+100²) ≈ 141, clipped to 100).
        //
        // Update law (per dimension, on each call):
        //
        //     target = raw_i × 100
        //     if target > C_i:
        //         C_i = target        ← SNAP UP (no EWMA attack-tau delay;
        //                               the psychological damage happens AT
        //                               the moment of the act, not 2 min later)
        //     else:
        //         α  = 1 − exp(−Δt / τ_recovery)
        //         C_i = (1−α)·C_i + α·target    ← gradual recovery only
        //
        // Per-event aggregate drop cap:
        //   To prevent a catastrophic single-step drop from a lone outlier
        //   fill, the NEW dimNorm is limited such that PSI cannot fall more
        //   than EwmaPerEventDropCap × (prevPsi/100) in one call.  When
        //   triggered, every C_i is scaled by the same factor so the
        //   dimensional composition is preserved and HUD bars remain a valid
        //   Euclidean decomposition of the new dimNorm.
        //
        // SINGLE PIPELINE INVARIANT: every PSI movement flows through this
        // method (or ApplyOvernightDecay / StartNewSession).  No hard
        // deductions.  No Boost/Escalation/Impulse bypasses — those were
        // patches that existed only to break through the weighted-sum ceiling
        // that no longer exists.
        // =====================================================================

        private double ApplyDecomposedEwma(DateTime eventTime,
                                           bool overExposed = false,
                                           bool isLossEvent = false)
        {
            // NOTE: the `overExposed` parameter is retained for API
            // compatibility and diagnostic reporting only.  The recovery-τ
            // selection is no longer branched on overexposure state — D3's
            // unified evidence accumulator E(t) encodes both the worsening
            // pressure (while |q|>SizeMax, E grows → raw grows → snap-up
            // pins C3 up) and the relaxation (once back within profile, E
            // decays on D3ExcessDecayTauSec → raw decays → C3 recovers on
            // EwmaNormalRecoveryTau).  This single mechanism replaces the
            // legacy three-state recovery-τ machine.

            // ── Time-base resolution ────────────────────────────────────────
            //   TradingClock guarantees eventTime is in a consistent domain
            //   (ARCHITECTURE.md §12).  Non-positive delta means paused replay
            //   or duplicate-timestamp fills → no recovery, but SNAP-UP still
            //   runs so real-time violations are visible even when Δt ≈ 0.
            double deltaSec;
            bool   timeAdvanced;
            if (_lastEwmaUpdate == DateTime.MinValue)
            {
                deltaSec     = 0.0;
                timeAdvanced = false;
            }
            else
            {
                double rawDelta = (eventTime - _lastEwmaUpdate).TotalSeconds;
                if (rawDelta <= 0.0)
                {
                    deltaSec     = 0.0;
                    timeAdvanced = false;
                }
                else
                {
                    deltaSec     = Math.Min(rawDelta, _cfg.EwmaMaxDeltaSec);
                    deltaSec     = Math.Max(deltaSec, _cfg.EwmaMinDeltaSec);
                    timeAdvanced = true;
                }
            }
            if (timeAdvanced)
                _lastEwmaUpdate = eventTime;
            else if (_lastEwmaUpdate == DateTime.MinValue)
                _lastEwmaUpdate = eventTime;

            // ── Recovery tau ────────────────────────────────────────────────
            // Single canonical recovery τ for all C_i.  D3's oversize-memory
            // is expressed through E(t) rather than a τ branch; other debts
            // have no reason to accelerate / decelerate on overexposure.
            double recoveryTau = _cfg.EwmaNormalRecoveryTau;

            double prevPsi = _psi;

            // ── Per-dimension snap-up / recovery update ─────────────────────
            double[] raws = { _d1, _d2, _d3, _d4, _d5, _d6, _d7 };
            double[] cs   = { _c1, _c2, _c3, _c4, _c5, _c6, _c7 };

            for (int i = 0; i < 7; i++)
            {
                double target = Math.Max(0.0, Math.Min(100.0, raws[i] * 100.0));

                if (target > cs[i])
                {
                    // Discrete worsening — snap up to full severity.  The
                    // per-event drop cap below enforces proportional limits
                    // at the aggregate level so a single outlier cannot crash
                    // PSI more than EwmaPerEventDropCap × (prevPsi/100).
                    cs[i] = target;
                }
                else if (timeAdvanced)
                {
                    // Gradual recovery toward a lower target.
                    double alpha = 1.0 - Math.Exp(-deltaSec / recoveryTau);
                    cs[i] = (1.0 - alpha) * cs[i] + alpha * target;
                }
                // If target ≤ cs[i] and no time advanced, hold current.

                cs[i] = Math.Max(0.0, cs[i]);
            }

            // ── Carry-forward decay ─────────────────────────────────────────
            if (timeAdvanced && _carryDebt > 0.0)
            {
                double carryAlpha = 1.0 - Math.Exp(-deltaSec / recoveryTau);
                _carryDebt = Math.Max(0.0, (1.0 - carryAlpha) * _carryDebt);
            }

            // ── Aggregate dimension loss via p-norm (p = 2) ─────────────────
            double sumSq = 0.0;
            for (int i = 0; i < 7; i++) sumSq += cs[i] * cs[i];
            double dimNorm = Math.Sqrt(sumSq);

            // ── Slow hidden debts (EWMA, not snap-up) ───────────────────────
            //   Financial stress and fatigue are genuinely slow-varying session-
            //   level signals — snap-up would be psychologically wrong here
            //   (cognitive fatigue doesn't arrive in an instant).  They remain
            //   on a smooth asymmetric EWMA, using EwmaDropTau for worsening
            //   and recoveryTau for improving, both in a DERIVED manner.
            if (timeAdvanced)
            {
                double fsTarget      = _cfg.FinancialStressWeight * _financialStressRaw * 100.0;
                double fsTau         = fsTarget > _financialStressDebt
                                       ? _cfg.EwmaDropTau : recoveryTau;
                double fsAlpha       = 1.0 - Math.Exp(-deltaSec / fsTau);
                _financialStressDebt = Math.Max(0.0,
                    fsAlpha * fsTarget + (1.0 - fsAlpha) * _financialStressDebt);

                double fatigueTarget = _cfg.FatigueWeight * _fatigueRaw * 100.0;
                double fatigueTau    = fatigueTarget > _fatigueDebt
                                       ? _cfg.EwmaDropTau : recoveryTau;
                double fatigueAlpha  = 1.0 - Math.Exp(-deltaSec / fatigueTau);
                _fatigueDebt = Math.Max(0.0,
                    fatigueAlpha * fatigueTarget + (1.0 - fatigueAlpha) * _fatigueDebt);
            }

            // ── Per-event aggregate drop cap ────────────────────────────────
            //   Limit: PSI cannot fall more than EwmaPerEventDropCap ×
            //   (prevPsi/100) in a single call.  Scales each C_i by the same
            //   factor so the Euclidean composition is preserved.
            double tentativePsi = 100.0 - dimNorm - _carryDebt
                                  - _financialStressDebt - _fatigueDebt
                                  - _streakFloorDebt;
            double maxDrop = _cfg.EwmaPerEventDropCap * (prevPsi / 100.0);

            if (tentativePsi < prevPsi - maxDrop && dimNorm > 0.0)
            {
                // Required dimNorm to bring PSI exactly to the capped floor.
                double cappedDimNorm = Math.Max(0.0,
                    100.0 - (prevPsi - maxDrop)
                          - _carryDebt - _financialStressDebt - _fatigueDebt
                          - _streakFloorDebt);
                double scale = cappedDimNorm / dimNorm;
                for (int i = 0; i < 7; i++) cs[i] *= scale;
                dimNorm = cappedDimNorm;
            }

            _c1=cs[0]; _c2=cs[1]; _c3=cs[2]; _c4=cs[3]; _c5=cs[4]; _c6=cs[5]; _c7=cs[6];

            // ── Loss-streak floor debt (hidden) ────────────────────────────
            //   Preserves the "new loss during a streak cannot improve PSI"
            //   invariant without violating the PSI identity — absorbs the
            //   would-improve gap into a hidden debt that decays post-streak.
            if (isLossEvent
                && _cfg.LossStreakPsiFloorMinStreak > 0.0
                && _consecutiveLosses >= _cfg.LossStreakPsiFloorMinStreak)
            {
                double tentative = Math.Max(0.0, Math.Min(100.0,
                    100.0 - dimNorm - _carryDebt
                          - _financialStressDebt - _fatigueDebt));
                double gap = tentative - prevPsi;   // > 0 means PSI would improve
                if (gap > 0.0)
                    _streakFloorDebt = Math.Min(100.0, _streakFloorDebt + gap);
            }
            else if (timeAdvanced && _streakFloorDebt > 0.0)
            {
                double floorAlpha = 1.0 - Math.Exp(-deltaSec / _cfg.EwmaNormalRecoveryTau);
                _streakFloorDebt  = Math.Max(0.0, _streakFloorDebt * (1.0 - floorAlpha));
            }

            // ── Final PSI from identity ─────────────────────────────────────
            double finalLoss = dimNorm + _carryDebt + _financialStressDebt
                             + _fatigueDebt + _streakFloorDebt;
            _psi = 100.0 - finalLoss;

            // ── B3: Defensive sanity clamps ─────────────────────────────────
            //   PSI identity should produce a finite value in [0,100] under
            //   normal operation; if upstream math ever produces NaN/Inf
            //   (e.g. a baseline divided by zero, a stale anchor with
            //   un-initialised state), fall back to the pre-event value
            //   rather than propagate a poisoned score to the HUD.
            if (double.IsNaN(_psi) || double.IsInfinity(_psi))
            {
                if (_debug != null)
                    _debug(string.Format(
                        "[PsiEngine] SANITY: non-finite PSI intercepted " +
                        "(dimNorm={0} carry={1} fs={2} fa={3} sf={4}) — reverting to prev={5:F1}",
                        dimNorm, _carryDebt, _financialStressDebt,
                        _fatigueDebt, _streakFloorDebt, prevPsi));
                _psi = prevPsi;
            }
            if (_psi < 0.0)   _psi = 0.0;
            if (_psi > 100.0) _psi = 100.0;

            // Defensive C_i clamps — norm math can overshoot due to FP drift.
            if (_c1 < 0) _c1 = 0; else if (_c1 > 100) _c1 = 100;
            if (_c2 < 0) _c2 = 0; else if (_c2 > 100) _c2 = 100;
            if (_c3 < 0) _c3 = 0; else if (_c3 > 100) _c3 = 100;
            if (_c4 < 0) _c4 = 0; else if (_c4 > 100) _c4 = 100;
            if (_c5 < 0) _c5 = 0; else if (_c5 > 100) _c5 = 100;
            if (_c6 < 0) _c6 = 0; else if (_c6 > 100) _c6 = 100;
            if (_c7 < 0) _c7 = 0; else if (_c7 > 100) _c7 = 100;

            // ── Session observability: peaks and min ───────────────────────
            if (_c1 > _peakC1) _peakC1 = _c1;
            if (_c2 > _peakC2) _peakC2 = _c2;
            if (_c3 > _peakC3) _peakC3 = _c3;
            if (_c4 > _peakC4) _peakC4 = _c4;
            if (_c5 > _peakC5) _peakC5 = _c5;
            if (_c6 > _peakC6) _peakC6 = _c6;
            if (_c7 > _peakC7) _peakC7 = _c7;
            if (dimNorm > _peakDimNorm) _peakDimNorm = dimNorm;
            if (_psi < _minPsiThisSession) _minPsiThisSession = _psi;

            // ── B1: PSI drop attribution log ───────────────────────────────
            //   Emit a structured attribution line when PSI moves materially
            //   in either direction so operators can diagnose "why did PSI
            //   drop here?" from the log alone without re-running the event.
            //   Threshold: |Δ| ≥ 1.5 pts keeps the log quiet during calm
            //   periods while capturing every material psychological event.
            if (_debug != null)
            {
                double delta = prevPsi - _psi;
                if (Math.Abs(delta) >= 1.5)
                {
                    int domIdx = 0; double domC = cs[0];
                    for (int i = 1; i < 7; i++)
                    {
                        if (cs[i] > domC) { domC = cs[i]; domIdx = i; }
                    }
                    double domRaw = raws[domIdx];
                    _debug(string.Format(
                        "[PsiEngine] ATTR prev={0:F1} now={1:F1} Δ={2:+0.0;-0.0} " +
                        "dom=D{3}(raw={4:F2} C={5:F1}) norm={6:F1} " +
                        "debts(carry={7:F1} fs={8:F1} fa={9:F1} sf={10:F1}) " +
                        "cap={11:F1} tau={12:F0}s over={13} E3={14:F0}cs",
                        prevPsi, _psi, -delta,
                        domIdx + 1, domRaw, domC, dimNorm,
                        _carryDebt, _financialStressDebt, _fatigueDebt, _streakFloorDebt,
                        maxDrop, recoveryTau,
                        _prevSizeOverLimit > 0.0 ? "Y" : "N",
                        _sizeExcessIntegral));
                }
            }

            return _psi;
        }

        // =====================================================================
        // Math helpers
        // =====================================================================

        private static double Clamp01(double v)
        {
            if (double.IsNaN(v) || double.IsNegativeInfinity(v)) return 0.0;
            if (double.IsPositiveInfinity(v)) return 1.0;
            return v < 0.0 ? 0.0 : v > 1.0 ? 1.0 : v;
        }

        /// <summary>
        /// Standard normal CDF — Abramowitz &amp; Stegun approximation 26.2.17.
        /// Max absolute error 7.5e-8.  Same implementation used in Black-Scholes
        /// pricing engines across the financial industry.
        /// </summary>
        private static double NormalCdf(double x)
        {
            const double a1 =  0.254829592,  a2 = -0.284496736,
                         a3 =  1.421413741,  a4 = -1.453152027,
                         a5 =  1.061405429,  p  =  0.3275911;
            int sign = x < 0 ? -1 : 1;
            x = Math.Abs(x) / Math.Sqrt(2.0);
            double t = 1.0 / (1.0 + p * x);
            double y = 1.0 - (((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t
                       * Math.Exp(-x * x));
            return 0.5 * (1.0 + sign * y);
        }

        /// <summary>
        /// Inverse standard normal CDF — Peter Acklam's rational approximation.
        /// Max relative error &lt; 1.15e-9.
        /// Ref: Glasserman (2003), Monte Carlo Methods in Financial Engineering.
        /// </summary>
        internal static double NormalCdfInverse(double prob)
        {
            const double a1 = -3.969683028665376e+01, a2 =  2.209460984245205e+02,
                         a3 = -2.759285104469687e+02, a4 =  1.383577518672690e+02,
                         a5 = -3.066479806614716e+01, a6 =  2.506628277459239e+00;
            const double b1 = -5.447609879822406e+01, b2 =  1.615858368580409e+02,
                         b3 = -1.556989798598866e+02, b4 =  6.680131188771972e+01,
                         b5 = -1.328068155288572e+01;
            const double c1 = -7.784894002430293e-03, c2 = -3.223964580411365e-01,
                         c3 = -2.400758277161838e+00, c4 = -2.549732539343734e+00,
                         c5 =  4.374664141464968e+00, c6 =  2.938163982698783e+00;
            const double d1 =  7.784695709041462e-03, d2 =  3.224671290700398e-01,
                         d3 =  2.445134137142996e+00, d4 =  3.754408661907416e+00;

            const double pLow = 0.02425, pHigh = 1.0 - pLow;

            if (prob <= 0) return double.NegativeInfinity;
            if (prob >= 1) return double.PositiveInfinity;

            double q, r;
            if (prob < pLow)
            {
                q = Math.Sqrt(-2.0 * Math.Log(prob));
                return (((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6)
                     / ((((d1 * q + d2) * q + d3) * q + d4) * q + 1.0);
            }
            if (prob <= pHigh)
            {
                q = prob - 0.5;
                r = q * q;
                return (((((a1 * r + a2) * r + a3) * r + a4) * r + a5) * r + a6) * q
                     / (((((b1 * r + b2) * r + b3) * r + b4) * r + b5) * r + 1.0);
            }
            q = Math.Sqrt(-2.0 * Math.Log(1.0 - prob));
            return -(((((c1 * q + c2) * q + c3) * q + c4) * q + c5) * q + c6)
                  / ((((d1 * q + d2) * q + d3) * q + d4) * q + 1.0);
        }
    }
}
