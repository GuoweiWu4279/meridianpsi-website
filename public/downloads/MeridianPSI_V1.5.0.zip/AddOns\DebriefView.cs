using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// The Debrief — post-session "truth ledger" hero surface. PURE WPF (no
    /// NinjaTrader types) so it renders offline in the UI harness AND inside
    /// NinjaTrader. Presentation only; numbers come from <see cref="DebriefData"/>.
    ///
    /// Rhetoric (this surface has ONE job): make "I made money, but it was luck,
    /// and that was dangerous" obvious at a glance. So the danger (risk vs your
    /// own daily limit) is the focal hero, not a neutral chart of all trades.
    /// Color encodes discipline QUALITY, never raw P&L.
    /// </summary>
    internal static class DebriefView
    {
        public static FrameworkElement Build(DebriefData d)
        {
            var root = new StackPanel();

            // ── Header ─────────────────────────────────────────────────────
            root.Children.Add(Ui.Txt((d.DateText ?? "") + "  ·  Session debrief", Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));

            var headRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, Theme.S2, 0, 0) };
            var head = Ui.Txt(d.Verdict, Theme.THeadline, Theme.FgPrimary, FontWeights.Bold);
            head.VerticalAlignment = VerticalAlignment.Center;
            headRow.Children.Add(head);
            var tag = Tag(CellName(d.VerdictCell), CellBrush(d.VerdictCell));
            tag.Margin = new Thickness(Theme.S3, 4, 0, 0);
            tag.VerticalAlignment = VerticalAlignment.Center;
            headRow.Children.Add(tag);
            root.Children.Add(headRow);

            if (!string.IsNullOrEmpty(d.VerdictSub))
            {
                var vs = Ui.Txt(d.VerdictSub, Theme.TSubhead, Theme.FgSecondary);
                vs.Margin = new Thickness(0, Theme.S2, 0, Theme.S5);
                root.Children.Add(vs);
            }

            // ── KPI strip ──────────────────────────────────────────────────
            root.Children.Add(KpiStrip(
                ("Net P&L", Money(d.NetPnl), d.TotalTrades + " trades", d.NetPnl >= 0 ? Theme.Good : Theme.Bad),
                ("Disciplined net", Money(d.DisciplinedNetPnl), "your real edge", d.DisciplinedNetPnl >= 0 ? Theme.Good : Theme.Bad),
                ("Win rate", d.WinRatePct.ToString("0") + "%", d.Wins + " / " + d.TotalTrades, Theme.FgPrimary),
                ("Final PSI", d.FinalPsi >= 0 ? d.FinalPsi.ToString("0") : "—", ZoneName(d.FinalPsi), d.FinalPsi >= 0 ? Theme.Zone(d.FinalPsi) : Theme.FgHint)));

            // ── DANGER HERO: the risk you didn't feel ──────────────────────
            if (d.HasDanger)
            {
                var dh = Ui.SectionHeader("The risk you didn't feel");
                dh.Margin = new Thickness(0, Theme.S5, 0, Theme.S2);
                root.Children.Add(dh);
                root.Children.Add(DangerCard(d));
            }

            // ── Profit attribution ─────────────────────────────────────────
            var ah = Ui.SectionHeader("Profit attribution");
            ah.Margin = new Thickness(0, Theme.S5, 0, Theme.S2);
            root.Children.Add(ah);
            root.Children.Add(AttributionBar(d.DisciplinedNetPnl, d.LuckPnl + d.SpiralPnl));

            // ── What pulled your score down — behavioral dimension breakdown (D1..D7) ──
            var dimCard = DimBreakdownCard(d);
            if (dimCard != null)
            {
                var dh = Ui.SectionHeader("What pulled your score down");
                dh.Margin = new Thickness(0, Theme.S5, 0, Theme.S2);
                root.Children.Add(dh);
                root.Children.Add(dimCard);
            }

            // ── Supporting charts: PSI curve + equity curve ────────────────
            var psiCard = ChartCard("PSI through the session",
                d.FinalPsi >= 0 ? "ended " + d.FinalPsi.ToString("0") + " · " + ZoneName(d.FinalPsi) : "",
                d.FinalPsi >= 0 ? Theme.Zone(d.FinalPsi) : Theme.FgHint,
                new SparkAreaChart { Values = d.PsiSeries, MinY = 40, MaxY = 100, Thresholds = new[] { 55.0, 72.0, 88.0 }, Stroke = Theme.Accent, ChartHeight = 128 });

            var eqCard = ChartCard("Equity (realized P&L)", "net " + Money(d.NetPnl), d.NetPnl >= 0 ? Theme.Good : Theme.Bad,
                new SparkAreaChart { Values = BuildEquity(d), ShowMarkers = true, ShowZeroLine = true, Stroke = d.NetPnl >= 0 ? Theme.Good : Theme.Bad, ChartHeight = 128 });

            var charts = Ui.Grid2(psiCard, eqCard, Theme.S3);
            charts.Margin = new Thickness(0, Theme.S5, 0, 0);
            root.Children.Add(charts);

            // ── Tomorrow's one fix ─────────────────────────────────────────
            if (!string.IsNullOrEmpty(d.OneFix))
            {
                var fix = new StackPanel();
                fix.Children.Add(Ui.Txt("Tomorrow's one fix", Theme.TCaption, Theme.Accent, FontWeights.Bold));
                var fb = Ui.Txt(d.OneFix, Theme.TSubhead, Theme.FgPrimary, FontWeights.SemiBold);
                fb.Margin = new Thickness(0, Theme.S2, 0, 0);
                fix.Children.Add(fb);
                var fc = Ui.AccentCard(fix, Theme.Accent);
                fc.Margin = new Thickness(0, Theme.S5, 0, 0);
                root.Children.Add(fc);
            }

            // ── Trade log ──────────────────────────────────────────────────
            var tl = Ui.SectionHeader("Trade log");
            tl.Margin = new Thickness(0, Theme.S5, 0, Theme.S2);
            root.Children.Add(tl);

            var table = new StackPanel();
            table.Children.Add(TradeHeaderRow());
            for (int i = 0; i < d.Trades.Count; i++)
                table.Children.Add(TradeRow(d.Trades[i], i < d.Trades.Count - 1));
            root.Children.Add(Ui.Card(table, Theme.S3));

            return Ui.Page(root, 880);   // content-rich reflective surface → wider column
        }

        // ── Danger hero card ────────────────────────────────────────────────
        private static Border DangerCard(DebriefData d)
        {
            var sp = new StackPanel();

            var top = new Grid();
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            top.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var who = Ui.Txt(d.DangerTradeLabel ?? "", Theme.TBody, Theme.FgPrimary, FontWeights.Bold);
            var made = Ui.Txt("you made +$" + Math.Abs(d.DangerReward).ToString("0"), Theme.TBody, Theme.Good, FontWeights.SemiBold);
            made.HorizontalAlignment = HorizontalAlignment.Right;
            Grid.SetColumn(who, 0); Grid.SetColumn(made, 1);
            top.Children.Add(who); top.Children.Add(made);
            top.Margin = new Thickness(0, 0, 0, Theme.S4);
            sp.Children.Add(top);

            sp.Children.Add(new RiskVsLimitChart { Risk = d.DangerRisk, Limit = d.DangerLimit, ChartHeight = 74 });

            var cap = Ui.Txt(d.DangerCaption, Theme.TBody, Theme.FgSecondary);
            cap.Margin = new Thickness(0, Theme.S4, 0, 0);
            sp.Children.Add(cap);

            return Ui.AccentCard(sp, Theme.Critical);
        }

        // ── KPI cards — 4 DISTINCT floating cards (each its own focal point) ─
        // One-card-per-metric (not a single hairline-split strip) is what gives the
        // eye four clear anchors instead of a flat grey band. Big tabular number is
        // the hero; the value carries the only color (green/red P&L, zone-hued PSI).
        private static FrameworkElement KpiStrip(params (string label, string value, string sub, Brush color)[] items)
        {
            var g = new Grid();
            for (int i = 0; i < items.Length; i++)
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            for (int i = 0; i < items.Length; i++)
            {
                var sp = new StackPanel();
                sp.Children.Add(Ui.Txt(items[i].label, Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
                var val = Ui.Num(items[i].value, Theme.THeadline, items[i].color, FontWeights.Bold);
                val.Margin = new Thickness(0, Theme.S2, 0, 0);
                sp.Children.Add(val);
                var sub = Ui.Txt(items[i].sub, Theme.TCaption, Theme.FgSecondary);
                sub.Margin = new Thickness(0, 3, 0, 0);
                sp.Children.Add(sub);

                var card = Ui.Card(sp, Theme.S4);
                card.Margin = new Thickness(i == 0 ? 0 : Theme.S3, 0, 0, 0);   // gap between cards
                Grid.SetColumn(card, i);
                g.Children.Add(card);
            }
            return g;
        }

        // ── Chart card (title + annotation + chart) ─────────────────────────
        private static Border ChartCard(string title, string note, Brush noteColor, UIElement chart)
        {
            var sp = new StackPanel();
            var header = new StackPanel { Orientation = Orientation.Horizontal };
            header.Children.Add(Ui.Txt(title, Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            if (!string.IsNullOrEmpty(note))
            {
                var n = Ui.Txt(note, Theme.TCaption, noteColor, FontWeights.SemiBold);
                n.Margin = new Thickness(Theme.S2, 0, 0, 0);
                header.Children.Add(n);
            }
            sp.Children.Add(header);
            ((FrameworkElement)chart).Margin = new Thickness(0, Theme.S2, 0, 0);
            sp.Children.Add(chart);
            return Ui.Card(sp);
        }

        // ── Attribution bar (edge vs rule-break) ────────────────────────────
        private static FrameworkElement AttributionBar(double edge, double ruleBreak)
        {
            double e = Math.Max(0, edge), r = Math.Max(0, ruleBreak);
            double total = e + r; if (total < 1) total = 1;
            double ef = e / total, rf = r / total;

            var wrap = new StackPanel();

            var labels = new Grid();
            labels.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            labels.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var left = Ui.Txt("Edge  " + Money(edge) + "  ·  " + (ef * 100).ToString("0") + "%", Theme.TBody, Theme.Good, FontWeights.SemiBold);
            var right = Ui.Txt("Luck  " + Money(ruleBreak) + "  ·  " + (rf * 100).ToString("0") + "%", Theme.TBody, Theme.Warning, FontWeights.SemiBold);
            right.HorizontalAlignment = HorizontalAlignment.Right;
            Grid.SetColumn(left, 0); Grid.SetColumn(right, 1);
            labels.Children.Add(left); labels.Children.Add(right);
            labels.Margin = new Thickness(0, 0, 0, Theme.S2);
            wrap.Children.Add(labels);

            var bar = new Grid { Height = 16 };
            bar.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(ef, GridUnitType.Star) });
            bar.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(rf, GridUnitType.Star) });
            var eSeg = new Border { Background = Theme.Good, CornerRadius = new CornerRadius(Theme.R1, 0, 0, Theme.R1) };
            var rSeg = new Border { Background = Theme.Warning, CornerRadius = new CornerRadius(0, Theme.R1, Theme.R1, 0) };
            Grid.SetColumn(eSeg, 0); Grid.SetColumn(rSeg, 1);
            bar.Children.Add(eSeg); bar.Children.Add(rSeg);
            wrap.Children.Add(bar);

            int luckPct = (int)Math.Round(rf * 100);
            var cap = Ui.Txt(
                luckPct >= 50
                    ? luckPct + "% of today's result came from trades that broke your own rules — not from your edge."
                    : "Most of today's result came from disciplined trades — the part that repeats.",
                Theme.TBody, Theme.FgSecondary);
            cap.Margin = new Thickness(0, Theme.S3, 0, 0);
            wrap.Children.Add(cap);

            return Ui.Card(wrap);
        }

        // ── Behavioral dimension breakdown — which behaviors pulled the score down ──
        private static FrameworkElement DimBreakdownCard(DebriefData d)
        {
            if (d.DimScores == null || d.DimScores.Length < 7) return null;
            double total = 0;
            for (int i = 0; i < 7; i++) if (d.DimScores[i] > 0) total += d.DimScores[i];
            if (total <= 0.0001) return null;

            var idx = new List<int>();
            for (int i = 0; i < 7; i++) if (d.DimScores[i] > 0.0001) idx.Add(i);
            if (idx.Count == 0) return null;
            idx.Sort((a, b) => d.DimScores[b].CompareTo(d.DimScores[a]));

            var sp = new StackPanel();
            for (int k = 0; k < idx.Count; k++)
            {
                int i = idx[k];
                var row = DimBar(IntelligenceEngine.HumanizeDimIndex(i), d.DimScores[i] / total, k == 0);
                if (k > 0) row.Margin = new Thickness(0, Theme.S3 + 1, 0, 0);
                sp.Children.Add(row);
            }
            return Ui.Card(sp, Theme.S4 + 2);
        }

        private static FrameworkElement DimBar(string name, double frac, bool dominant)
        {
            var wrap = new StackPanel();

            var labelRow = new Grid();
            labelRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            labelRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var nm = Ui.Txt(name, Theme.TBody, dominant ? Theme.FgPrimary : Theme.FgSecondary, dominant ? FontWeights.SemiBold : FontWeights.Normal);
            var pct = Ui.Txt(Math.Round(frac * 100) + "%", Theme.TCaption, Theme.FgHint, FontWeights.SemiBold);
            pct.HorizontalAlignment = HorizontalAlignment.Right; pct.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(nm, 0); Grid.SetColumn(pct, 1); labelRow.Children.Add(nm); labelRow.Children.Add(pct);
            labelRow.Margin = new Thickness(0, 0, 0, 5);
            wrap.Children.Add(labelRow);

            double f = Math.Max(0.02, Math.Min(1, frac));
            var bar = new Grid { Height = 8 };
            bar.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(f, GridUnitType.Star) });
            bar.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1 - f, GridUnitType.Star) });
            var track = new Border { Background = Theme.BgElevated, CornerRadius = new CornerRadius(Theme.R1) };
            Grid.SetColumnSpan(track, 2); bar.Children.Add(track);
            var fill = new Border { Background = dominant ? Theme.Critical : Theme.Warning, CornerRadius = new CornerRadius(Theme.R1) };
            Grid.SetColumn(fill, 0); bar.Children.Add(fill);
            wrap.Children.Add(bar);
            return wrap;
        }

        private static List<double> BuildEquity(DebriefData d)
        {
            var eq = new List<double> { 0 };
            double cum = 0;
            foreach (var t in d.Trades) { cum += t.Pnl; eq.Add(cum); }
            return eq;
        }

        // ── Trade log ───────────────────────────────────────────────────────
        private static UIElement TradeHeaderRow()
        {
            var g = TradeGrid();
            string[] hs = { "", "Time", "Position", "Entry → exit", "P&L", "" };
            for (int i = 0; i < hs.Length; i++)
            {
                var tb = Ui.Txt(hs[i], Theme.TCaption, Theme.FgHint, FontWeights.SemiBold);
                if (i == 4) tb.HorizontalAlignment = HorizontalAlignment.Right;
                Grid.SetColumn(tb, i); g.Children.Add(tb);
            }
            g.Margin = new Thickness(0, 0, 0, Theme.S2);
            return g;
        }

        private static UIElement TradeRow(DebriefTrade t, bool divider)
        {
            var g = TradeGrid();
            var lbl = Ui.Txt(t.Label, Theme.TBody, Theme.FgHint, FontWeights.Bold);
            var time = Ui.Num(t.TimeText, Theme.TBody, Theme.FgSecondary);
            var pos = Ui.Txt(t.Dir + " " + t.Size + (!t.Disciplined ? " ⚠" : ""), Theme.TBody, t.Disciplined ? Theme.FgPrimary : Theme.Warning, t.Disciplined ? FontWeights.Normal : FontWeights.SemiBold);
            string pxText = (t.EntryPrice <= 0 && t.ExitPrice <= 0)
                ? "—"
                : t.EntryPrice.ToString("0.00") + "  →  " + t.ExitPrice.ToString("0.00");
            var px = Ui.Num(pxText, Theme.TBody, Theme.FgSecondary);
            var pnl = Ui.Num(Money(t.Pnl), Theme.TBody, t.Pnl >= 0 ? Theme.Good : Theme.Bad, FontWeights.SemiBold);
            pnl.HorizontalAlignment = HorizontalAlignment.Right;

            Grid.SetColumn(lbl, 0); Grid.SetColumn(time, 1); Grid.SetColumn(pos, 2); Grid.SetColumn(px, 3); Grid.SetColumn(pnl, 4);
            g.Children.Add(lbl); g.Children.Add(time); g.Children.Add(pos); g.Children.Add(px); g.Children.Add(pnl);

            var cellTag = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(Theme.S4, 0, 0, 0), VerticalAlignment = VerticalAlignment.Center };
            cellTag.Children.Add(new Border { Width = 7, Height = 7, CornerRadius = new CornerRadius(99), Background = CellBrush(t.Cell), VerticalAlignment = VerticalAlignment.Center });
            var cn = Ui.Txt(CellName(t.Cell), Theme.TCaption, Theme.FgSecondary, FontWeights.SemiBold);
            cn.Margin = new Thickness(Theme.S1 + 2, 0, 0, 0);
            cellTag.Children.Add(cn);
            Grid.SetColumn(cellTag, 5); g.Children.Add(cellTag);

            var row = new Border { Child = g, Padding = new Thickness(0, Theme.S2, 0, Theme.S2) };
            if (divider) { row.BorderBrush = Theme.Border; row.BorderThickness = new Thickness(0, 0, 0, 1); }
            return row;
        }

        private static Grid TradeGrid()
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(22) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(52) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(92) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(108) });
            return g;
        }

        // ── Helpers ─────────────────────────────────────────────────────────
        private static Border Tag(string text, Brush color)
        {
            var bg = new SolidColorBrush(Theme.ColorOf(color)) { Opacity = 0.16 }; bg.Freeze();
            var tb = Ui.Txt(text, Theme.TCaption, color, FontWeights.Bold);
            tb.TextWrapping = TextWrapping.NoWrap;
            return new Border { Background = bg, CornerRadius = new CornerRadius(Theme.R1), Padding = new Thickness(Theme.S2, 2, Theme.S2, 2), Child = tb };
        }

        private static Brush CellBrush(DebriefCell c)
        {
            switch (c)
            {
                case DebriefCell.Earned:   return Theme.Good;        // disciplined win — genuinely good
                case DebriefCell.Luck:     return Theme.Warning;     // rule-break win — the dangerous one
                case DebriefCell.Variance: return Theme.FgSecondary; // disciplined loss — neutral, no alarm
                default:                   return Theme.Critical;    // rule-break loss — bad
            }
        }

        private static string CellName(DebriefCell c)
        {
            switch (c)
            {
                case DebriefCell.Earned:   return "Earned";
                case DebriefCell.Luck:     return "Luck";
                case DebriefCell.Variance: return "Variance";
                default:                   return "Spiral";
            }
        }

        private static string ZoneName(double psi)
        {
            if (psi < 0) return "no data";
            return psi >= 88 ? "Stable" : psi >= 72 ? "Caution" : psi >= 55 ? "Warning" : "Critical";
        }

        private static string Money(double v) => (v >= 0 ? "+$" : "-$") + Math.Abs(v).ToString("0");
    }
}
