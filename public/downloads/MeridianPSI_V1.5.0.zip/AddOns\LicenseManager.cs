﻿// LicenseManager.cs
//
// Manages Whop license key activation and the Guard-tier sampling window for
// MeridianPSI PSI.
//
// Trial model:
//   The 7-day free trial is handled entirely by Whop (subscription with trial
//   period — credit card required at checkout).  There is NO local pre-checkout
//   trial: TrialDays is 0, and Trial_Active is effectively unreachable.
//   trial.dat is kept as a placeholder for backward compatibility.
//
// Guard-tier sampling for Core subscribers:
//   For the first 7 days after a license is first activated on a machine
//   (FirstActivatedAt timestamp in license.dat), Core subscribers receive
//   full Guard tier access.  This lets new Core users try Guard features
//   during the same 7-day window in which they're already free to cancel.
//   After day 7, tier reverts to whatever Whop says the plan is.
//
// License validation:
//   Whop license key validated against their hosted API.  Result is cached
//   in encrypted license.dat for a 7-day offline grace period so prop-firm
//   firewalls don't lock users out during transient connectivity issues.
//
// No NinjaTrader API dependencies — independently unit-testable.

using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================================
    // LicenseStatus
    // =========================================================================

    // =========================================================================
    // LicenseTier
    // =========================================================================

    /// <summary>
    /// Determines which feature set the user has access to.
    /// <list type="bullet">
    ///   <item><b>Core</b> — everything EXCEPT the Guard rules: PSI monitoring, Session
    ///       Report, History, PSI Intelligence, Journal, Profile &amp; Settings.</item>
    ///   <item><b>Guard</b> — all Core features plus the Guard rules engine
    ///       (auto-flatten / trading pause / strict lock). This is the only paid feature.</item>
    /// </list>
    /// </summary>
    public enum LicenseTier
    {
        Core  = 0,
        Guard = 1,
    }

    // LicenseStatus enum moved to LicenseStatus.cs (pure type, no NinjaTrader
    // coupling) so the License page can render offline in the UI harness.

    // =========================================================================
    // LicenseManager
    // =========================================================================

    public sealed class LicenseManager
    {
        // =====================================================================
        // Public constants (visible to UI layer)
        // =====================================================================

        public const int TrialDays = 0;   // No local free trial — trial is handled by Whop's 7-day free subscription period
        public const int GraceDays = 7;  // Offline grace after a valid license is cached

        /// <summary>
        /// Number of days after first activation during which Core subscribers
        /// receive full Guard tier access (Plan C: Core trial → Guard preview).
        /// Aligned with Whop's 7-day free trial window so users get to try
        /// the upgrade tier before their card is charged.
        /// </summary>
        public const int CoreGuardSamplingDays = 7;

        // ── Shown to users whose trial has expired or license is invalid. ─────
        // Points to the product website rather than the payment processor directly,
        // so the landing page (pricing, social proof, FAQ) can be updated without
        // changing plugin code.
        public const string StoreUrl     = "https://www.meridianpsi.com/pricing";

        /// <summary>Landing page for the Guard tier upgrade (the Guard rules engine).</summary>
        public const string GuardStoreUrl = "https://www.meridianpsi.com/guard";

        /// <summary>Product documentation and user guide.</summary>
        public const string DocsUrl       = "https://www.meridianpsi.com/docs";

        // ── Whop Plan IDs — fill in after creating products in Whop dashboard ──
        // List every plan ID that should resolve to the Guard tier.
        // Typically 2 entries: Guard Monthly and Guard Annual.
        //
        // When the array contains only empty/placeholder strings (not yet configured),
        // every validated license is treated as Guard so existing subscribers are
        // never silently downgraded during rollout.
        //
        // How to find a Plan ID:
        //   Whop Dashboard → Products → click your product → Plans section
        //   Each plan row shows an ID in the format  plan_XXXXXXXXXX
        //
        // CorePlanIds is informational only — anything not in GuardPlanIds is treated as Core.
        public static readonly string[] GuardPlanIds = { "plan_ZHX4ySB65fahf", "plan_frPOgHtDTvBkR" };  // Guard Monthly, Guard Annual
        public static readonly string[] CorePlanIds  = { "plan_4Z0XZqQl7TaDH", "plan_JhWetoQ39OCNz" };  // Core Monthly, Core Annual (informational)

        // ── Host a small JSON file at this URL to enable in-app update checks ─
        // Format: { "version": "1.0.1", "notes": "Bug fix description", "download": "https://..." }
        // Update the file on your server whenever you release a new version.
        public const string VersionCheckUrl = "https://www.meridianpsi.com/version.json";

        // =====================================================================
        // Internal constants
        // =====================================================================

        private const int    ApiTimeoutSec  = 10;

        // Whop API v2 — license validation endpoint.
        // POST https://api.whop.com/api/v2/memberships/{license_key}/validate_license
        // The {id} path param accepts either a membership ID (mem_xxx) or the license key itself.
        private const string WhopApiBase    = "https://api.whop.com/api/v2/memberships";

        // Read-only Whop API key (validate_license permission only).
        // Obtain from: Whop Dashboard → Developer → Company API Keys
        // Required permission: "Validate license keys"
        // IMPORTANT: Replace this placeholder with your actual key before shipping.
        private const string WhopApiKey     = "apik_NUVwlzvC5byCG_C4931691_C_f9e35d52326d963975529020edbe716ae71fafd27dac263fa383b9fc1db3f8";

        private const string TrialFile      = "trial.dat";
        private const string LicenseFile    = "license.dat";

        // Salt strings for AES key derivation.
        // Security comes from binding the key to the MachineId, not from these strings.
        private const string TrialSalt      = "tm-trial-v1";
        private const string LicenseSalt    = "tm-license-v1";

        // =====================================================================
        // Data directory — injected by MeridianPSI (same as other data files)
        // =====================================================================

        private static string _dataDir;

        internal static void SetDataDir(string path)
        {
            if (!string.IsNullOrEmpty(path)) _dataDir = path;
        }

        // =====================================================================
        // Machine ID — injected from MeridianPSI using NT8's own fingerprint API
        // (NinjaTrader.Core.Globals.GenerateLicenseCode).  Falls back to Windows
        // MachineGuid if the NT8 API is unavailable (unit tests, edge cases).
        //
        // Using NT8's fingerprint instead of raw Windows MachineGuid means:
        //   • Reinstalling Windows does NOT invalidate the user's activation.
        //   • The license is bound to the NT8 installation, which is the correct
        //     semantic unit for an NT8 AddOn product.
        //   • Consistent with how other commercial NT8 vendors (e.g. Replikanto)
        //     identify machines.
        // =====================================================================

        private static string _injectedMachineId;

        /// <summary>
        /// Call once from MeridianPSI.OnStateChange(Configure) with the result of
        /// NinjaTrader.Core.Globals.GenerateLicenseCode() so the license is bound
        /// to the NT8 installation rather than the underlying Windows OS.
        /// </summary>
        internal static void SetMachineId(string ntLicenseCode)
        {
            if (!string.IsNullOrEmpty(ntLicenseCode))
                _injectedMachineId = ntLicenseCode;
        }

        private static string TrialPath   => Path.Combine(_dataDir ?? "", TrialFile);
        private static string LicensePath => Path.Combine(_dataDir ?? "", LicenseFile);

        // =====================================================================
        // Runtime state
        // =====================================================================

        private LicenseStatus _status             = LicenseStatus.Trial_Expired; // Locked until InitialiseAsync completes
        private string        _key                = null;
        private string        _instanceId         = null;
        private int           _trialDaysRemaining = TrialDays;
        private LicenseTier   _tier               = LicenseTier.Guard; // default Guard for Trial/Unknown
        private DateTime      _firstActivatedAt   = DateTime.MinValue;  // when this key was first activated on this machine; never overwritten once set

        private readonly object _sync = new object();

        // One HttpClient per AppDomain is the correct pattern.
        private static readonly HttpClient _http = new HttpClient
        {
            Timeout = TimeSpan.FromSeconds(ApiTimeoutSec)
        };

        // =====================================================================
        // Public properties
        // =====================================================================

        public LicenseStatus Status
        {
            get { lock (_sync) { return _status; } }
        }

        /// <summary>Days remaining in the trial; 0 when trial has expired or license is active.</summary>
        public int TrialDaysRemaining
        {
            get { lock (_sync) { return _trialDaysRemaining; } }
        }

        /// <summary>The license tier (Core or Guard) derived from the Whop plan ID.</summary>
        public LicenseTier Tier
        {
            get { lock (_sync) { return _tier; } }
        }

        /// <summary>
        /// True when the Guard-tier feature is accessible: the Guard rules engine
        /// (auto-flatten / trading pause / strict lock). This is the only paid
        /// feature — History and PSI Intelligence are Core.
        ///
        /// Returns true when:
        ///   • Status is Trial_Active (legacy code path, currently unreachable
        ///     because TrialDays = 0 — kept for forward compatibility).
        ///   • Status is Licensed/Offline_Grace AND Tier is Guard.
        ///   • Status is Licensed/Offline_Grace AND it is within the first
        ///     CoreGuardSamplingDays (7) days since first activation — Core
        ///     subscribers get a Guard preview during their Whop free-trial
        ///     window so they can decide whether to upgrade before being charged.
        /// </summary>
        public bool HasGuard
        {
            get
            {
                lock (_sync)
                {
                    if (_status == LicenseStatus.Trial_Active)
                        return true;

                    bool isLive = _status == LicenseStatus.Licensed
                               || _status == LicenseStatus.Offline_Grace;
                    if (!isLive) return false;

                    if (_tier == LicenseTier.Guard) return true;

                    // Plan C: Core users receive Guard tier for the first
                    // CoreGuardSamplingDays from FirstActivatedAt.  The timestamp
                    // is persisted in license.dat and never overwritten, so
                    // uninstall/reinstall does not reset the window.
                    if (_firstActivatedAt != DateTime.MinValue)
                    {
                        double days = (DateTime.UtcNow - _firstActivatedAt).TotalDays;
                        if (days >= 0 && days <= CoreGuardSamplingDays) return true;
                    }

                    return false;
                }
            }
        }

        /// <summary>
        /// UTC timestamp the active license key was first activated on this
        /// machine.  DateTime.MinValue when no key has ever been activated.
        /// Persisted in license.dat — survives reinstalls so the Plan C
        /// 7-day Guard sampling window cannot be reset by deleting/reinstalling.
        /// </summary>
        public DateTime FirstActivatedAt
        {
            get { lock (_sync) { return _firstActivatedAt; } }
        }

        /// <summary>
        /// Days remaining in the Plan C Guard-sampling window for Core users.
        /// Returns 0 when the user is already on Guard (no sampling needed),
        /// when the window has expired, or when no license is active.
        /// </summary>
        public int CoreGuardSamplingDaysRemaining
        {
            get
            {
                lock (_sync)
                {
                    bool isLive = _status == LicenseStatus.Licensed
                               || _status == LicenseStatus.Offline_Grace;
                    if (!isLive || _tier == LicenseTier.Guard) return 0;
                    if (_firstActivatedAt == DateTime.MinValue) return 0;
                    int used = (int)(DateTime.UtcNow - _firstActivatedAt).TotalDays;
                    return Math.Max(0, CoreGuardSamplingDays - used);
                }
            }
        }

        /// <summary>The currently stored license key, or null if none has been entered.</summary>
        public string LicenseKey
        {
            get { lock (_sync) { return _key; } }
        }

        /// <summary>True when the plugin should function normally.</summary>
        public bool IsFunctional =>
            Status == LicenseStatus.Trial_Active  ||
            Status == LicenseStatus.Licensed      ||
            Status == LicenseStatus.Offline_Grace;

        // =====================================================================
        // Initialise — call once from MeridianPSI.OnStateChange(Configure)
        // Runs async so NT8 startup is never blocked.
        // =====================================================================

        public async Task InitialiseAsync()
        {
            try
            {
                // ── Step 1: Is there a saved license key? ─────────────────────
                var cached = LoadLicenseCache();
                if (cached != null)
                {
                    // FirstActivatedAt: preserve from cache, or backfill to ValidatedAt
                    // for caches written before the field existed (so existing users
                    // don't get a fresh Guard-sampling window on the first run after
                    // upgrading).
                    DateTime firstActivated = cached.FirstActivatedAt != DateTime.MinValue
                        ? cached.FirstActivatedAt
                        : cached.ValidatedAt;

                    lock (_sync)
                    {
                        _key = cached.Key;
                        _instanceId = cached.InstanceId;
                        _tier = cached.CachedTier;
                        _firstActivatedAt = firstActivated;
                    }

                    var (onlineStatus, onlinePlanId) = await ValidateOnlineAsync(cached.Key);
                    if (onlineStatus.HasValue)
                    {
                        LicenseTier onlineTier = ResolveTier(onlinePlanId);

                        // Defensive guard against schema drift / partial response bodies:
                        // if Whop returned valid=true but the plan field was empty/unparseable,
                        // ResolveTier would silently downgrade Guard subscribers to Core.
                        // Keep the cached tier in that case — same root cause as the
                        // GuardPlanIds bug fix; we don't trust an empty planId to be authoritative.
                        if (onlineStatus.Value == LicenseStatus.Licensed
                            && string.IsNullOrEmpty(onlinePlanId))
                        {
                            onlineTier = cached.CachedTier;
                            NinjaTrader.Code.Output.Process(
                                "[Meridian] Whop response had valid=true but no plan field — preserving cached tier to avoid silent downgrade.",
                                PrintTo.OutputTab1);
                        }

                        SaveLicenseCache(cached.Key, cached.InstanceId, onlineStatus.Value, onlineTier, firstActivated);
                        lock (_sync) { _status = onlineStatus.Value; _tier = onlineTier; }
                    }
                    else
                    {
                        // Server unreachable — honour cached result within grace period.
                        var age = DateTime.UtcNow - cached.ValidatedAt;
                        lock (_sync)
                        {
                            _status = age.TotalDays <= GraceDays && cached.WasLicensed
                                ? LicenseStatus.Offline_Grace
                                : (age.TotalDays <= GraceDays ? cached.CachedStatus : LicenseStatus.Expired);
                            _tier = cached.CachedTier;
                        }
                    }
                    return;
                }

                // ── Step 2: No license key — fall back to trial countdown ─────
                var trial   = LoadOrCreateTrial();
                var elapsed = DateTime.UtcNow - trial.StartUtc;
                int remaining = Math.Max(0, TrialDays - (int)elapsed.TotalDays);

                lock (_sync)
                {
                    _trialDaysRemaining = remaining;
                    _status = remaining > 0
                        ? LicenseStatus.Trial_Active
                        : LicenseStatus.Trial_Expired;
                    _tier = LicenseTier.Guard; // trial always shows everything
                    _firstActivatedAt = DateTime.MinValue;
                }
            }
            catch (Exception ex)
            {
                // Fail closed — on any unexpected error show Trial_Expired so the user
                // enters their key rather than getting free access.  The error is logged
                // so support can diagnose it; Activate still works normally from the UI.
                NinjaTrader.Code.Output.Process(
                    $"[MeridianPSI] LicenseManager.InitialiseAsync exception: {ex.Message}",
                    PrintTo.OutputTab1);
                lock (_sync)
                {
                    _status = LicenseStatus.Trial_Expired;
                    _tier = LicenseTier.Core;
                    _firstActivatedAt = DateTime.MinValue;
                }
            }
        }

        // =====================================================================
        // Activate — called when user clicks Activate in the License tab.
        // Whop uses a single validate_license endpoint for both initial
        // activation and subsequent re-validations, so there is no separate
        // "activate" call.  Submitting the key the first time records the
        // machine metadata with Whop; subsequent calls reconfirm the status.
        // Returns (true, null) on success; (false, errorMessage) on failure.
        // =====================================================================

        public async Task<(bool Success, string ErrorMessage)> ActivateAsync(string rawKey)
        {
            string key = rawKey?.Trim() ?? "";
            if (string.IsNullOrEmpty(key))
                return (false, "Please enter a License Key.");

            try
            {
                string machineId = GetMachineId();
                var (status, planId, membershipId) = await CallWhopValidateAsync(key, machineId);

                if (status == LicenseStatus.Licensed)
                {
                    LicenseTier tier = ResolveTier(planId);

                    // Same defensive guard as InitialiseAsync: never assume Core
                    // when Whop says valid=true but the plan field is empty.
                    if (string.IsNullOrEmpty(planId))
                    {
                        // First activation with no plan — fall back to Guard so the
                        // user is never silently downgraded.  This is safer than
                        // Core because tier is re-checked on every restart.
                        tier = LicenseTier.Guard;
                        NinjaTrader.Code.Output.Process(
                            "[Meridian] Activate succeeded but Whop returned no plan field — provisionally setting Guard until next validation.",
                            PrintTo.OutputTab1);
                    }

                    // Plan C: preserve any existing FirstActivatedAt (so re-entering
                    // a previously-used key doesn't reset the 7-day Guard sampling
                    // window).  Set to now if this is the first activation ever.
                    var existingCache = LoadLicenseCache();
                    DateTime firstActivated = (existingCache != null
                                               && existingCache.Key == key
                                               && existingCache.FirstActivatedAt != DateTime.MinValue)
                        ? existingCache.FirstActivatedAt
                        : DateTime.UtcNow;

                    SaveLicenseCache(key, membershipId, LicenseStatus.Licensed, tier, firstActivated);
                    lock (_sync)
                    {
                        _key              = key;
                        _instanceId       = membershipId;
                        _status            = LicenseStatus.Licensed;
                        _tier              = tier;
                        _firstActivatedAt  = firstActivated;
                    }
                    return (true, null);
                }

                if (status == LicenseStatus.Expired)
                    return (false, "This subscription has expired. Please renew at " + StoreUrl);

                if (status == LicenseStatus.Invalid && membershipId == "MACHINE_MISMATCH")
                    return (false, "This key is already activated on a different machine. Deactivate it there first, or contact support.");

                if (status == null)
                    return (false, "Could not reach Whop server. Check your internet connection and try again.");

                return (false, "License key not found or is invalid. Please check and try again.");
            }
            catch (TaskCanceledException)
            {
                return (false, "Connection timed out. Please check your network and try again.");
            }
            catch (Exception ex)
            {
                return (false, $"Activation error: {ex.Message}");
            }
        }

        // =====================================================================
        // Deactivate — removes this machine's cached license so the key can be
        // re-entered on a different computer.  Whop tracks machine metadata
        // server-side via validate_license calls but does not require an
        // explicit deactivation API call — deleting the local cache is
        // sufficient for the end-user move-to-another-PC use case.
        // =====================================================================

        public Task<(bool Success, string ErrorMessage)> DeactivateAsync()
        {
            Exception deleteException = null;
            try
            {
                if (File.Exists(LicensePath)) File.Delete(LicensePath);
            }
            catch (Exception ex)
            {
                deleteException = ex;
            }

            // If license.dat still exists, the deactivation has NOT actually
            // succeeded — the user thinks the key is freed but on the next
            // start LoadLicenseCache will pick it up again.  Surface the
            // failure so they can resolve it (AV lock, file in use, etc.)
            // before assuming the key is portable to another machine.
            if (File.Exists(LicensePath))
            {
                NinjaTrader.Code.Output.Process(
                    $"[Meridian] DeactivateAsync — could not remove license.dat: {deleteException?.Message ?? "file still exists"}",
                    PrintTo.OutputTab1);
                return Task.FromResult<(bool, string)>((false,
                    "Could not remove the local license file. Close NT8, manually delete license.dat from your Meridian data folder, then try again."));
            }

            lock (_sync)
            {
                _key              = null;
                _instanceId       = null;
                _status           = LicenseStatus.Trial_Expired;
                _tier             = LicenseTier.Core;
                _firstActivatedAt = DateTime.MinValue;
            }
            return Task.FromResult<(bool, string)>((true, null));
        }

        // =====================================================================
        // Machine ID — stable per NT8 installation (preferred) or Windows OS
        // (fallback).  Sent as metadata in Whop validate_license calls so
        // Whop can track per-device usage server-side.
        //
        // Using NT8's fingerprint instead of raw Windows MachineGuid means:
        //   • Reinstalling Windows does NOT change the machine's identity.
        //   • The license is bound to the NT8 installation, which is the correct
        //     semantic unit for an NT8 AddOn product.
        //   • Consistent with how other commercial NT8 vendors (e.g. Replikanto)
        //     identify machines.
        // =====================================================================

        public static string GetMachineId()
        {
            // Use the NT8-injected fingerprint when available (set at startup
            // from NinjaTrader.Core.Globals.GenerateLicenseCode).
            if (!string.IsNullOrEmpty(_injectedMachineId))
            {
                using (var sha = SHA256.Create())
                {
                    byte[] hash = sha.ComputeHash(
                        Encoding.UTF8.GetBytes(_injectedMachineId + "tm-mid-v1"));
                    return Convert.ToBase64String(hash)
                        .Substring(0, 20)
                        .Replace('+', 'A')
                        .Replace('/', 'B')
                        .Replace('=', 'C');
                }
            }

            // Fallback: Windows MachineGuid (used in unit tests and if NT8 API
            // is unavailable for any reason).
            try
            {
                string guid = Registry.GetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography",
                    "MachineGuid", null) as string
                    ?? Environment.MachineName;

                using (var sha = SHA256.Create())
                {
                    byte[] hash = sha.ComputeHash(Encoding.UTF8.GetBytes(guid + "tm-mid-v1"));
                    return Convert.ToBase64String(hash)
                        .Substring(0, 20)
                        .Replace('+', 'A')
                        .Replace('/', 'B')
                        .Replace('=', 'C');
                }
            }
            catch
            {
                return "UNKNOWN-MACHINE";
            }
        }

        // =====================================================================
        // Whop API call — POST /v2/memberships/{key}/validate_license
        // Returns (status, planId, membershipId).
        // Returns (null, "", "") if the server is unreachable (treat as offline).
        // =====================================================================

        private async Task<(LicenseStatus? Status, string PlanId, string MembershipId)> CallWhopValidateAsync(
            string licenseKey, string machineId = null)
        {
            string url = $"{WhopApiBase}/{Uri.EscapeDataString(licenseKey)}/validate_license";
            try
            {
                // Note: NinjaTrader.Code.Output.Process is a no-op on background threads.
                // All logging for activation results is done on the UI thread in the caller.
                //
                // Machine-binding metadata is intentionally omitted: the NT8-generated
                // machine fingerprint changes on every AddOn recompile, so sending it would
                // cause HTTP 400 "metadata mismatch" on every reload.  Subscription-status
                // validation (active / expired) is sufficient for the current product model.
                string bodyJson = "{\"metadata\":{}}";

                using (var request = new HttpRequestMessage(HttpMethod.Post, url))
                using (var cts = new System.Threading.CancellationTokenSource(
                    TimeSpan.FromSeconds(ApiTimeoutSec)))
                {
                    request.Headers.Authorization =
                        new AuthenticationHeaderValue("Bearer", WhopApiKey);
                    request.Content = new StringContent(bodyJson, Encoding.UTF8, "application/json");

                    // Pass an explicit CancellationToken so the timeout fires reliably
                    // even if the underlying OS TCP stack stalls.
                    HttpResponseMessage resp;
                    try
                    {
                        resp = await _http.SendAsync(request, cts.Token);
                    }
                    catch (OperationCanceledException)
                    {
                        NinjaTrader.Code.Output.Process(
                            "[Meridian] License check timed out — no response from Whop after 10 s.",
                            PrintTo.OutputTab1);
                        return (null, "", "");
                    }

                    string body = await resp.Content.ReadAsStringAsync();

                    NinjaTrader.Code.Output.Process(
                        $"[Meridian] Whop API responded: HTTP {(int)resp.StatusCode}  valid={ExtractJsonString(body, "valid")}  status={ExtractJsonString(body, "status")}  plan_id={ExtractJsonString(body, "id", "plan")}",
                        PrintTo.OutputTab1);

                    // 404 = key not found
                    if (resp.StatusCode == System.Net.HttpStatusCode.NotFound)
                        return (LicenseStatus.Invalid, "", "");

                    // 400 = malformed request OR (legacy) machine metadata mismatch.
                    // Since we deliberately omit machine metadata from the payload
                    // (NT8's GenerateLicenseCode rotates on every recompile, which
                    // would cause spurious mismatches), a 400 in normal operation
                    // is almost certainly a transient API/server issue rather than
                    // a real binding problem — treat as transient and let the
                    // caller retry.  Only flag MACHINE_MISMATCH if the response
                    // body explicitly mentions machine/metadata so we don't
                    // mislead users with the "already activated elsewhere" message.
                    if (resp.StatusCode == System.Net.HttpStatusCode.BadRequest)
                    {
                        NinjaTrader.Code.Output.Process(
                            $"[Meridian] Whop API HTTP 400 — body: {body.Substring(0, Math.Min(300, body.Length))}",
                            PrintTo.OutputTab1);

                        bool looksLikeMismatch =
                            body.IndexOf("metadata", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            body.IndexOf("machine",  StringComparison.OrdinalIgnoreCase) >= 0;

                        return looksLikeMismatch
                            ? (LicenseStatus.Invalid, "", "MACHINE_MISMATCH")
                            : ((LicenseStatus?)null, "", "");
                    }

                    // Any other non-success (401, 403, 422, 500 …) → treat as server error
                    if (!resp.IsSuccessStatusCode)
                    {
                        NinjaTrader.Code.Output.Process(
                            $"[Meridian] Whop API non-success response — body: {body.Substring(0, Math.Min(300, body.Length))}",
                            PrintTo.OutputTab1);
                        return (null, "", "");
                    }

                    // Dump body on success so we can diagnose tier resolution issues.
                    NinjaTrader.Code.Output.Process(
                        $"[Meridian] Whop response body (first 600): {body.Substring(0, Math.Min(600, body.Length))}",
                        PrintTo.OutputTab1);

                    // Whop validate_license returns "plan":"plan_xxx" as a flat string field
                    // (confirmed from live response body).  Fall back to nested {"id":"..."} and
                    // "plan_id" for forward-compatibility if the schema ever changes.
                    string planId = ExtractJsonString(body, "plan");
                    if (string.IsNullOrEmpty(planId) || planId.StartsWith("{"))
                        planId = ExtractJsonString(body, "id", "plan");
                    if (string.IsNullOrEmpty(planId))
                        planId = ExtractJsonString(body, "plan_id");

                    NinjaTrader.Code.Output.Process(
                        $"[Meridian] Tier resolution — extracted planId='{planId}'  GuardPlanIds=[{string.Join(",", GuardPlanIds)}]",
                        PrintTo.OutputTab1);

                    string membershipId = ExtractJsonString(body, "id");
                    string validStr     = ExtractJsonString(body, "valid");
                    string statusStr    = ExtractJsonString(body, "status");

                    bool valid = string.Equals(validStr, "true", StringComparison.OrdinalIgnoreCase);

                    if (!valid)
                    {
                        switch (statusStr)
                        {
                            case "expired":
                            case "completed":
                            case "canceled":
                            case "past_due":
                                return (LicenseStatus.Expired, planId, membershipId);
                            default:
                                return (LicenseStatus.Invalid, planId, membershipId);
                        }
                    }

                    return (LicenseStatus.Licensed, planId, membershipId);
                }
            }
            catch (Exception ex)
            {
                NinjaTrader.Code.Output.Process(
                    $"[Meridian] License check exception — {ex.GetType().Name}: {ex.Message}",
                    PrintTo.OutputTab1);
                return (null, "", "");
            }
        }

        // =====================================================================
        // Online validation (wrapper used by InitialiseAsync for cached keys).
        // Returns null Status if server is unreachable.
        // =====================================================================

        private async Task<(LicenseStatus? Status, string PlanId)> ValidateOnlineAsync(string key)
        {
            var (status, planId, _) = await CallWhopValidateAsync(key, GetMachineId());
            return (status, planId);
        }

        // =====================================================================
        // Tier resolution helpers
        // =====================================================================

        /// <summary>
        /// Maps a Whop plan ID string to a <see cref="LicenseTier"/>.
        /// When <see cref="GuardPlanIds"/> contains only placeholder values (not yet
        /// configured), every validated license is treated as Guard so existing
        /// subscribers are never silently downgraded during rollout.
        /// </summary>
        private static LicenseTier ResolveTier(string planId)
        {
            // Not yet configured (all placeholders) → treat everyone as Guard.
            bool configured = GuardPlanIds.Length > 0 &&
                              !(GuardPlanIds.Length == 1 && GuardPlanIds[0] == "") &&
                              !GuardPlanIds[0].StartsWith("plan_FILL_ME");
            if (!configured) return LicenseTier.Guard;

            if (!string.IsNullOrEmpty(planId))
            {
                foreach (string id in GuardPlanIds)
                    if (!string.IsNullOrEmpty(id) && id == planId) return LicenseTier.Guard;
            }

            return LicenseTier.Core;
        }

        // =====================================================================
        // Trial persistence
        // =====================================================================

        private sealed class TrialData { public DateTime StartUtc; }

        private TrialData LoadOrCreateTrial()
        {
            if (string.IsNullOrEmpty(_dataDir))
                return new TrialData { StartUtc = DateTime.UtcNow };

            Directory.CreateDirectory(_dataDir);

            if (File.Exists(TrialPath))
            {
                try
                {
                    string json = AesDecrypt(File.ReadAllBytes(TrialPath),
                                             DeriveBytesFromMachine(TrialSalt));
                    long   ticks = long.Parse(ExtractJsonString(json, "t"));
                    string mid   = ExtractJsonString(json, "m");

                    // Reject copied trial.dat from another machine.
                    if (mid == GetStableMachineId())
                        return new TrialData { StartUtc = new DateTime(ticks, DateTimeKind.Utc) };
                }
                catch (Exception ex)
                {
                    NinjaTrader.Code.Output.Process(
                        $"[Meridian] LoadOrCreateTrial — trial.dat unreadable, recreating: {ex.GetType().Name}: {ex.Message}",
                        PrintTo.OutputTab1);
                }
            }

            return CreateFreshTrial();
        }

        private TrialData CreateFreshTrial()
        {
            var data = new TrialData { StartUtc = DateTime.UtcNow };
            try
            {
                string json  = $"{{\"t\":{data.StartUtc.Ticks},\"m\":\"{GetStableMachineId()}\"}}";
                File.WriteAllBytes(TrialPath, AesEncrypt(json, DeriveBytesFromMachine(TrialSalt)));
            }
            catch (Exception ex)
            {
                NinjaTrader.Code.Output.Process(
                    $"[Meridian] CreateFreshTrial — could not write trial.dat: {ex.GetType().Name}: {ex.Message}",
                    PrintTo.OutputTab1);
            }
            return data;
        }

        // =====================================================================
        // License cache persistence
        // =====================================================================

        private sealed class LicenseCache
        {
            public string        Key;
            public string        InstanceId;
            public DateTime      ValidatedAt;
            public DateTime      FirstActivatedAt;   // Plan C anchor — never overwritten once set
            public LicenseStatus CachedStatus;
            public LicenseTier   CachedTier;
            public bool          WasLicensed =>
                CachedStatus == LicenseStatus.Licensed ||
                CachedStatus == LicenseStatus.Offline_Grace;
        }

        private LicenseCache LoadLicenseCache()
        {
            if (string.IsNullOrEmpty(_dataDir) || !File.Exists(LicensePath))
                return null;
            try
            {
                string json   = AesDecrypt(File.ReadAllBytes(LicensePath),
                                           DeriveBytesFromMachine(LicenseSalt));
                string k      = ExtractJsonString(json, "k");
                string iid    = ExtractJsonString(json, "i");
                long   ticks  = long.Parse(ExtractJsonString(json, "t"));
                int    status = int.Parse(ExtractJsonString(json, "s"));

                // "r" = rank/tier field added in v1.1.0.
                // Existing caches without this field default to Guard so current
                // subscribers are never silently downgraded during rollout.
                string tierStr = ExtractJsonString(json, "r");
                LicenseTier tier = tierStr == "0" ? LicenseTier.Core : LicenseTier.Guard;

                // "f" = first-activated timestamp (UTC ticks) added in v1.3.0
                // for the Plan C Core→Guard sampling window.  Existing caches
                // without this field return DateTime.MinValue and the caller
                // backfills it to ValidatedAt so existing subscribers don't
                // get a fresh 7-day window on the first run after upgrading.
                string firstStr = ExtractJsonString(json, "f");
                DateTime firstActivated = DateTime.MinValue;
                if (!string.IsNullOrEmpty(firstStr) && long.TryParse(firstStr, out long firstTicks)
                    && firstTicks > 0)
                {
                    firstActivated = new DateTime(firstTicks, DateTimeKind.Utc);
                }

                if (string.IsNullOrEmpty(k)) return null;

                return new LicenseCache
                {
                    Key              = k,
                    InstanceId       = iid,
                    ValidatedAt      = new DateTime(ticks, DateTimeKind.Utc),
                    FirstActivatedAt = firstActivated,
                    CachedStatus     = (LicenseStatus)status,
                    CachedTier       = tier,
                };
            }
            catch (Exception ex)
            {
                NinjaTrader.Code.Output.Process(
                    $"[Meridian] LoadLicenseCache failed — license.dat may be corrupt: {ex.GetType().Name}: {ex.Message}",
                    PrintTo.OutputTab1);
                return null;
            }
        }

        private void SaveLicenseCache(string key, string instanceId,
                                      LicenseStatus status,
                                      LicenseTier tier = LicenseTier.Guard,
                                      DateTime firstActivatedAt = default(DateTime))
        {
            if (string.IsNullOrEmpty(_dataDir)) return;
            try
            {
                Directory.CreateDirectory(_dataDir);
                long firstTicks = firstActivatedAt == default(DateTime)
                    ? 0L
                    : firstActivatedAt.Ticks;
                string json = $"{{\"k\":\"{key}\",\"i\":\"{instanceId ?? ""}\",\"t\":{DateTime.UtcNow.Ticks},\"s\":{(int)status},\"r\":{(int)tier},\"f\":{firstTicks}}}";
                File.WriteAllBytes(LicensePath, AesEncrypt(json, DeriveBytesFromMachine(LicenseSalt)));
            }
            catch (Exception ex)
            {
                NinjaTrader.Code.Output.Process(
                    $"[Meridian] SaveLicenseCache failed — tier/license state may not survive restart: {ex.GetType().Name}: {ex.Message}",
                    PrintTo.OutputTab1);
            }
        }

        // =====================================================================
        // AES-256-CBC helpers
        // =====================================================================

        /// <summary>
        /// Returns a machine-stable identifier for AES key derivation.
        /// Deliberately uses Windows MachineGuid (NOT _injectedMachineId / NT8's
        /// GenerateLicenseCode) because NT8 changes GenerateLicenseCode on every
        /// AddOn recompile, which would rotate the AES key and invalidate the
        /// persisted license.dat on every reload.  MachineGuid is set once at
        /// Windows installation and never changes during normal use.
        /// </summary>
        private static string GetStableMachineId()
        {
            try
            {
                string guid = Registry.GetValue(
                    @"HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Cryptography",
                    "MachineGuid", null) as string;
                if (!string.IsNullOrEmpty(guid)) return guid;
            }
            catch { }
            return Environment.MachineName;
        }

        private static byte[] DeriveBytesFromMachine(string salt)
        {
            using (var sha = SHA256.Create())
                return sha.ComputeHash(Encoding.UTF8.GetBytes(GetStableMachineId() + salt));
        }

        private static byte[] AesEncrypt(string plaintext, byte[] key)
        {
            using (var aes = Aes.Create())
            {
                aes.Key  = key;
                aes.Mode = CipherMode.CBC;
                aes.GenerateIV();
                using (var enc = aes.CreateEncryptor())
                {
                    byte[] data   = Encoding.UTF8.GetBytes(plaintext);
                    byte[] cipher = enc.TransformFinalBlock(data, 0, data.Length);
                    byte[] result = new byte[16 + cipher.Length];
                    Buffer.BlockCopy(aes.IV, 0, result, 0,  16);
                    Buffer.BlockCopy(cipher, 0, result, 16, cipher.Length);
                    return result;
                }
            }
        }

        private static string AesDecrypt(byte[] combined, byte[] key)
        {
            byte[] iv     = new byte[16];
            byte[] cipher = new byte[combined.Length - 16];
            Buffer.BlockCopy(combined, 0,  iv,     0, 16);
            Buffer.BlockCopy(combined, 16, cipher, 0, cipher.Length);
            using (var aes = Aes.Create())
            {
                aes.Key  = key;
                aes.IV   = iv;
                aes.Mode = CipherMode.CBC;
                using (var dec = aes.CreateDecryptor())
                {
                    byte[] plain = dec.TransformFinalBlock(cipher, 0, cipher.Length);
                    return Encoding.UTF8.GetString(plain);
                }
            }
        }

        // =====================================================================
        // Minimal JSON field extractor
        // Avoids Newtonsoft.Json dependency for portability.
        // =====================================================================

        private static string ExtractJsonString(string json, string field,
                                                string withinObject = null)
        {
            try
            {
                string search = json;

                if (!string.IsNullOrEmpty(withinObject))
                {
                    int objStart = json.IndexOf($"\"{withinObject}\"", StringComparison.Ordinal);
                    if (objStart < 0) return "";
                    int braceOpen = json.IndexOf('{', objStart);
                    if (braceOpen < 0) return "";
                    int depth = 0, braceClose = braceOpen;
                    for (int i = braceOpen; i < json.Length; i++)
                    {
                        if      (json[i] == '{') depth++;
                        else if (json[i] == '}') { depth--; if (depth == 0) { braceClose = i; break; } }
                    }
                    search = json.Substring(braceOpen, braceClose - braceOpen + 1);
                }

                string pattern = $"\"{field}\":";
                int pos = search.IndexOf(pattern, StringComparison.Ordinal);
                if (pos < 0) return "";

                int valStart = pos + pattern.Length;
                while (valStart < search.Length && search[valStart] == ' ') valStart++;
                if (valStart >= search.Length) return "";

                if (search[valStart] == '"')
                {
                    int end = search.IndexOf('"', valStart + 1);
                    return end < 0 ? "" : search.Substring(valStart + 1, end - valStart - 1);
                }
                else
                {
                    int end = valStart;
                    while (end < search.Length && search[end] != ',' && search[end] != '}') end++;
                    return search.Substring(valStart, end - valStart).Trim();
                }
            }
            catch { return ""; }
        }
    }
}
