﻿// GuardRule.cs
//
// Data model for the Guard protection rule engine.
//
// Each GuardRule is a user-authored commitment device:
//   "When [these conditions] are ALL/ANY met, do [this action]."
//
// The user sets every rule when they are calm.  The system enforces their
// own rules against their impulsive self — it never makes decisions for them.
//
// Serialised to XML (guard.xml) alongside the other data files.

using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================================
    // Condition types
    // =========================================================================

    public enum GuardConditionType
    {
        /// <summary>PSI is currently below the threshold value.</summary>
        PsiBelow,

        /// <summary>Consecutive losing trades >= threshold (uses PsiEngine streak counter).</summary>
        ConsecutiveLossesAtLeast,

        /// <summary>Session realised P&L is below −threshold (user enters positive $).</summary>
        SessionPnlBelow,

        /// <summary>Minutes since the first fill this session exceeds threshold.</summary>
        SessionMinutesOver,

        /// <summary>
        /// Current unrealised (floating) P&L of all open positions is below −threshold.
        /// User enters a positive $ amount.  Fires even before the position is closed,
        /// covering the blind spot where SessionPnlBelow cannot see deep-hole risk.
        /// </summary>
        UnrealizedPnlBelow,

        /// <summary>
        /// The most recent completed round-trip trade produced a loss exceeding threshold.
        /// User enters a positive $ amount.  Fires on the fill that closes the trade.
        /// Useful for per-trade max-loss rules ("never lose more than $X on a single trade").
        /// </summary>
        SingleTradeLossExceeds,
    }

    // =========================================================================
    // Action types — ordered from lightest to most disruptive
    // =========================================================================

    public enum GuardActionType
    {
        /// <summary>Non-blocking toast notification (dismissible immediately).</summary>
        Toast,

        /// <summary>
        /// Modal dialog requiring the user to type their OverridePhrase before dismissing.
        /// If OverridePhrase is empty, falls back to a single Acknowledged button.
        /// Forces cognitive engagement — typing the phrase the user wrote when calm
        /// creates deliberate friction and self-reflection.
        /// CountdownSeconds > 0 means the button is locked until the timer expires
        /// (absorbs the old Countdown action).
        /// </summary>
        Acknowledge,

        /// <summary>
        /// LEGACY — absorbed into Acknowledge.  Rules saved with this action are
        /// automatically mapped to Acknowledge on deserialization; CountdownSeconds
        /// carries over unchanged so the "wait N seconds" behaviour is preserved.
        /// </summary>
        Countdown,

        /// <summary>
        /// Persistent warning state: HUD banner remains visible and new entry fills trigger
        /// a simple one-click acknowledgment dialog.  Does NOT block orders (NT8 architecture
        /// does not allow reliable pre-submission interception).  Exits when the condition
        /// clears naturally (e.g. PSI recovers).
        /// </summary>
        RiskAlert,

        /// <summary>
        /// LEGACY — use TradingPause instead.  Kept for backward compat so existing
        /// guard.xml files continue to work.  Mapped internally to TradingPause with
        /// PauseMode=Disconnect and PauseDurationMinutes=LockMinutes.
        /// </summary>
        Disconnect,

        /// <summary>
        /// Real enforcement: blocks new entry orders for the configured duration.
        /// Mechanism is configurable: CancelOrders (stay connected, cancel any new
        /// entry order immediately after submission) or Disconnect (sever broker
        /// connection and re-disconnect if the user reconnects during the window).
        /// Replaces the old Disconnect action with richer configuration.
        /// </summary>
        TradingPause,
    }

    // =========================================================================
    // PauseModeType — mechanism used by TradingPause action
    // =========================================================================

    public enum PauseModeType
    {
        /// <summary>
        /// Stay connected to the broker.  Any new entry order that reaches
        /// OrderState.Initialized during the pause window is immediately cancelled.
        /// Existing positions are unaffected.  The HUD shows an amber countdown banner.
        /// </summary>
        CancelOrders,

        /// <summary>
        /// Sever the broker connection.  If BlockReconnectDuringPause is true,
        /// the AddOn re-disconnects whenever the user manually reconnects during
        /// the pause window.  Stronger enforcement at the cost of requiring a
        /// manual reconnect after the window expires.
        /// </summary>
        Disconnect,
    }

    // =========================================================================
    // Condition logic (how multiple conditions in one rule combine)
    // =========================================================================

    public enum GuardConditionLogic
    {
        /// <summary>ALL conditions must be true (AND semantics).</summary>
        All,

        /// <summary>ANY condition must be true (OR semantics).</summary>
        Any,
    }

    // =========================================================================
    // GuardCondition — one predicate inside a rule
    // =========================================================================

    [XmlType("Condition")]
    public class GuardCondition
    {
        [XmlAttribute] public GuardConditionType Type      { get; set; }
        [XmlAttribute] public double             Threshold { get; set; }
    }

    // =========================================================================
    // GuardRule — one complete rule authored by the user
    // =========================================================================

    [XmlType("Rule")]
    public class GuardRule
    {
        [XmlAttribute] public string              Id               { get; set; } = Guid.NewGuid().ToString("N");
        [XmlAttribute] public string              Name             { get; set; } = "New Rule";
        [XmlAttribute] public bool                Enabled          { get; set; } = true;
        [XmlAttribute] public GuardConditionLogic Logic            { get; set; } = GuardConditionLogic.All;
        [XmlAttribute] public GuardActionType     Action           { get; set; } = GuardActionType.Toast;
        [XmlAttribute] public int                 CountdownSeconds { get; set; } = 60;
        [XmlAttribute] public int                 LockMinutes      { get; set; } = 15;
        [XmlAttribute] public string              CustomMessage    { get; set; } = "";
        [XmlAttribute] public int                 CooldownMinutes  { get; set; } = 10;
        /// <summary>How long a Toast/Notify banner stays visible (seconds). Default 8.</summary>
        [XmlAttribute] public int                 ToastDurationSeconds { get; set; } = 8;

        /// <summary>
        /// Phrase the user writes when calm.  Required for the Acknowledge action:
        /// the user must type this exact text to dismiss the modal.  Creates deliberate
        /// cognitive friction — typing "I am revenge trading and I need to stop" forces
        /// the prefrontal cortex to re-engage.  Optional (empty = simple Acknowledged btn).
        /// Also used as the EarlyExit phrase for TradingPause when EarlyExitRequiresPhrase=true.
        /// </summary>
        [XmlAttribute] public string OverridePhrase { get; set; } = "";

        // ── TradingPause-specific fields ──────────────────────────────────────

        /// <summary>
        /// Duration of the pause in minutes.  0 = rest-of-day (until the rollover
        /// cutoff, typically 17:00 ET).  Only used when Action == TradingPause.
        /// Default 15 matches the old LockMinutes default for Disconnect.
        /// </summary>
        [XmlAttribute] public int PauseDurationMinutes { get; set; } = 15;

        /// <summary>
        /// How the pause is enforced: stay connected and cancel new entry orders
        /// (CancelOrders) or disconnect from the broker (Disconnect).
        /// </summary>
        [XmlAttribute] public PauseModeType PauseMode { get; set; } = PauseModeType.CancelOrders;

        /// <summary>
        /// When true, all open positions are automatically flattened the moment the
        /// pause activates.  Default false — safety first, the user chooses.
        /// </summary>
        [XmlAttribute] public bool AutoFlattenOnPause { get; set; } = false;

        /// <summary>
        /// Disconnect mode only.  When true, the AddOn re-disconnects if the user
        /// manually reconnects during the active pause window.  Default true.
        /// </summary>
        [XmlAttribute] public bool BlockReconnectDuringPause { get; set; } = true;

        /// <summary>
        /// When true, the user can dismiss the active pause early via an "End Early"
        /// button in the Guard status zone.  Default false (full duration enforced).
        /// </summary>
        [XmlAttribute] public bool AllowEarlyExit { get; set; } = false;

        /// <summary>
        /// When AllowEarlyExit is true and this is true, the user must type their
        /// OverridePhrase to confirm early exit.  Reuses the existing phrase field.
        /// Default true.
        /// </summary>
        [XmlAttribute] public bool EarlyExitRequiresPhrase { get; set; } = true;

        /// <summary>
        /// Acknowledge action only.  When true, new entry orders are cancelled
        /// (CancelOrders mode) for as long as the Acknowledge dialog is open.
        /// Trading resumes the instant the user completes the acknowledgment.
        /// Default false — the original "friction only" behaviour is preserved
        /// for existing rules that load from guard.xml without this attribute.
        /// </summary>
        [XmlAttribute] public bool BlockTradesWhileAcknowledging { get; set; } = false;

        // ── Qualified-loss streak filter ──────────────────────────────────────

        /// <summary>
        /// Minimum dollar loss for a trade to count toward the ConsecutiveLossesAtLeast
        /// streak.  0 = any loss (current / default behaviour).  Set to e.g. 20.0 to
        /// exclude CTC-fee-sized losses from the streak counter, so only genuine
        /// risk-taking losses trigger the rule.
        /// </summary>
        [XmlAttribute] public double MinLossUsdForStreak { get; set; } = 0.0;

        /// <summary>
        /// LEGACY (pre-1.3.0): number of consecutive evaluation cycles a Disconnect
        /// rule's condition had to remain true before firing.  This was incorrectly
        /// counting events (fills + 5 s timer ticks) instead of wall-clock time, so
        /// rapid fills could fire a Disconnect in well under a second.
        ///
        /// SUPERSEDED by <see cref="ConfirmationSeconds"/>.  Field is preserved so
        /// rules saved by older versions deserialize cleanly.  When ConfirmationSeconds
        /// is 0 (legacy rules), the engine interprets ConfirmationTicks * 30 as the
        /// confirmation window in seconds — matching the original "each ~30 s" intent.
        /// New rules should set ConfirmationSeconds directly.
        /// </summary>
        [XmlAttribute] public int ConfirmationTicks { get; set; } = 1;

        /// <summary>
        /// Wall-clock seconds the condition must remain continuously true before
        /// the rule fires.  0 = fire immediately on the first evaluation where
        /// the condition is met.  Used by Disconnect/TradingPause to prevent misfires
        /// on transient PSI dips; other actions ignore this and fire immediately.
        ///
        /// New default for TradingPause rules is 90 (set in MeridianDashboard when
        /// the user creates a TradingPause rule via the editor).  When 0 and
        /// ConfirmationTicks > 1, the engine falls back to ConfirmationTicks * 30
        /// seconds for backward compatibility with legacy rule files.
        /// </summary>
        [XmlAttribute] public int ConfirmationSeconds { get; set; } = 0;

        [XmlArray("Conditions")]
        [XmlArrayItem("Condition")]
        public List<GuardCondition> Conditions { get; set; } = new List<GuardCondition>();

        // ── Runtime state (not persisted) ─────────────────────────────────────

        [XmlIgnore] public DateTime LastTriggeredUtc { get; set; } = DateTime.MinValue;

        // Edge-trigger latch: fires once on condition entry, silent while it persists,
        // resets when the condition fully clears.  CooldownMinutes is a secondary
        // rate-limiter for rapid oscillation around the threshold, not the primary
        // re-trigger mechanism.
        [XmlIgnore] public bool WasConditionMet { get; set; } = false;

        /// <summary>
        /// UTC timestamp the condition first became true in the current run
        /// (DateTime.MinValue = condition is currently false / not yet started).
        /// Wall-clock anchor for ConfirmationSeconds — the rule fires when
        /// (UtcNow - FirstMetUtc).TotalSeconds &gt;= EffectiveConfirmationSeconds.
        /// Reset whenever the condition clears.
        /// </summary>
        [XmlIgnore] public DateTime FirstMetUtc { get; set; } = DateTime.MinValue;

        // Legacy counter — preserved for backward source compatibility but no
        // longer used by Evaluate().  Wall-clock semantics in FirstMetUtc replace it.
        [XmlIgnore] public int ConditionMetCount { get; set; } = 0;

        /// <summary>
        /// Wall-clock seconds the condition must remain continuously true before
        /// firing.  Honours <see cref="ConfirmationSeconds"/> when set, otherwise
        /// falls back to <see cref="ConfirmationTicks"/> × 30 to preserve the
        /// originally documented behaviour for legacy rules.
        /// </summary>
        [XmlIgnore]
        public int EffectiveConfirmationSeconds =>
            ConfirmationSeconds > 0 ? ConfirmationSeconds
            : (ConfirmationTicks > 1 ? ConfirmationTicks * 30 : 0);

        // RiskAlert mode: true while a RiskAlert rule's condition is currently met.
        // Cleared when the condition clears.  Consumed by MeridianPSI to decide
        // whether to show the persistent HUD banner and per-fill acknowledgment dialogs.
        [XmlIgnore] public bool RiskAlertActive { get; set; } = false;

        // ── Effective pause duration ──────────────────────────────────────────

        /// <summary>
        /// Effective pause duration in minutes.  For TradingPause action, returns
        /// PauseDurationMinutes.  For legacy Disconnect, returns LockMinutes.
        /// </summary>
        [XmlIgnore]
        public int EffectivePauseDurationMinutes =>
            Action == GuardActionType.TradingPause ? PauseDurationMinutes : LockMinutes;

        // ── Evaluation ────────────────────────────────────────────────────────

        public bool IsInCooldown() =>
            LastTriggeredUtc != DateTime.MinValue &&
            (DateTime.UtcNow - LastTriggeredUtc).TotalMinutes < CooldownMinutes;

        /// <summary>
        /// Returns true exactly once when the rule should fire: the first evaluation
        /// after the condition has been continuously true long enough to satisfy
        /// the wall-clock confirmation window (TradingPause/Disconnect only).  Other
        /// actions fire on the first evaluation where the condition becomes met.
        /// Updates RiskAlertActive for RiskAlert rules on every call regardless of firing.
        ///
        /// State-machine order:
        ///   1. Evaluate condition first, regardless of cooldown — so the latch reset
        ///      (WasConditionMet=false, FirstMetUtc=MinValue) always executes when the
        ///      condition clears, even if a cooldown is active.  Without this, a
        ///      condition that clears during a cooldown window would leave WasConditionMet
        ///      true permanently, silencing the rule forever after the cooldown expires.
        ///   2. FirstMetUtc is only set / preserved when NOT in cooldown, preventing
        ///      ConfirmationSeconds from being silently satisfied while the rule is locked.
        ///   3. When <see cref="CooldownMinutes"/> &gt; 0 and cooldown has just expired, if
        ///      <see cref="WasConditionMet"/> is still true while the predicate remains true
        ///      (e.g. consecutive-loss streak never dropped because no intervening win), the
        ///      latch and confirmation anchor reset once so the rule can re-arm — otherwise
        ///      Step 2 never runs and the rule fires at most once per session.  Skipped when
        ///      CooldownMinutes is 0 so Toast/Countdown rules still edge-trigger once per
        ///      continuous violation episode without spamming every poll tick.
        ///   4. RiskAlert's persistent flag is updated whenever the condition is met,
        ///      so the HUD banner always reflects live state even during cooldown.
        /// </summary>
        public bool Evaluate(GuardContext ctx)
        {
            if (!Enabled || Conditions.Count == 0) return false;

            // Legacy Countdown action: treat identically to Acknowledge (backward compat).
            // TradingPause and Disconnect share the same confirmation-window logic below.

            // ── Step 1: evaluate condition (always, regardless of cooldown) ──────
            bool conditionNowMet;
            if (Logic == GuardConditionLogic.All)
            {
                conditionNowMet = true;
                foreach (var c in Conditions)
                    if (!EvaluateOne(c, ctx, MinLossUsdForStreak)) { conditionNowMet = false; break; }
            }
            else // Any
            {
                conditionNowMet = false;
                foreach (var c in Conditions)
                    if (EvaluateOne(c, ctx, MinLossUsdForStreak)) { conditionNowMet = true; break; }
            }

            // ── Step 2: condition not met — reset latches unconditionally ────────
            if (!conditionNowMet)
            {
                WasConditionMet   = false;
                FirstMetUtc       = DateTime.MinValue;
                ConditionMetCount = 0;
                RiskAlertActive   = false;
                return false;
            }

            // ── Step 3: condition IS met ─────────────────────────────────────────

            // RiskAlert: keep the persistent flag live even during cooldown so the
            // HUD banner accurately reflects the current condition state.
            if (Action == GuardActionType.RiskAlert)
            {
                bool wasActive = RiskAlertActive;
                RiskAlertActive = true;

                // Fire the initial trigger event once per condition entry, but only
                // when not in cooldown.  MeridianPSI polls RiskAlertActive directly
                // for per-fill dialogs; the event is just the "banner on" notification.
                if (IsInCooldown()) return false;
                if (wasActive) return false;          // already active this entry
                if (WasConditionMet) return false;    // already fired this entry
                WasConditionMet = true;
                return true;
            }

            // For all other actions: cooldown gates both the timestamp anchor and the trigger.
            if (IsInCooldown()) return false;

            // Re-arm after a real cooldown only (CooldownMinutes &gt; 0).  When cooldown is 0,
            // IsInCooldown() is always false — without the CooldownMinutes guard, clearing
            // WasConditionMet here every other tick would let Toast/Countdown fire repeatedly
            // while the condition stayed true.  When cooldown is positive, violation persisting
            // through the whole lock window never clears Step 2, so this one-shot reset after
            // expiry is the only way CooldownMinutes can mean "rate-limit between fires."
            if (CooldownMinutes > 0 && WasConditionMet)
            {
                WasConditionMet = false;
                FirstMetUtc     = DateTime.MinValue;
                return false;
            }

            // Anchor the wall-clock confirmation window the first time the condition
            // is observed met outside of cooldown.  Subsequent calls just check
            // elapsed time — the cadence at which Evaluate is invoked no longer
            // affects the confirmation window length.
            if (FirstMetUtc == DateTime.MinValue) FirstMetUtc = DateTime.UtcNow;

            if (WasConditionMet) return false;

            // For Disconnect / TradingPause: require the condition to remain continuously
            // true for EffectiveConfirmationSeconds wall-clock seconds before firing.
            // Other actions fire immediately on the first eligible evaluation.
            bool requiresConfirmation = Action == GuardActionType.Disconnect
                                     || Action == GuardActionType.TradingPause;
            if (requiresConfirmation)
            {
                int requiredSec = EffectiveConfirmationSeconds;
                if (requiredSec > 0)
                {
                    double elapsed = (DateTime.UtcNow - FirstMetUtc).TotalSeconds;
                    if (elapsed < requiredSec) return false;
                }
            }

            WasConditionMet = true;
            return true;
        }

        private static bool EvaluateOne(GuardCondition c, GuardContext ctx, double minLossUsdForStreak)
        {
            switch (c.Type)
            {
                case GuardConditionType.PsiBelow:
                    return ctx.Psi < c.Threshold;
                case GuardConditionType.ConsecutiveLossesAtLeast:
                    // Use the filtered counter when a min-loss threshold is configured.
                    double streak = minLossUsdForStreak > 0.0
                        ? ctx.ConsecutiveLossesAboveMin
                        : ctx.ConsecutiveLosses;
                    return streak >= c.Threshold;
                case GuardConditionType.SessionPnlBelow:
                    return ctx.SessionPnl < -Math.Abs(c.Threshold);
                case GuardConditionType.SessionMinutesOver:
                    return ctx.SessionMinutes > c.Threshold;
                case GuardConditionType.UnrealizedPnlBelow:
                    return ctx.UnrealizedPnl < -Math.Abs(c.Threshold);
                case GuardConditionType.SingleTradeLossExceeds:
                    // Fires when the last trade was a loss exceeding the threshold.
                    // ctx.LastTradePnl is negative for a loss; user enters positive $.
                    return ctx.LastTradePnl < 0 && Math.Abs(ctx.LastTradePnl) > Math.Abs(c.Threshold);
                default:
                    return false;
            }
        }
    }

    // =========================================================================
    // GuardContext — snapshot of current state passed to rule evaluation
    // =========================================================================

    public class GuardContext
    {
        public double Psi               { get; set; }
        public double ConsecutiveLosses { get; set; }
        public double SessionPnl        { get; set; }   // realised P&L this session ($)
        public double SessionMinutes    { get; set; }   // minutes since first fill

        /// <summary>
        /// Current unrealised (floating) P&L of all open positions, summed across all
        /// subscribed accounts.  Read directly from account.Positions (NT8 ground truth),
        /// not from internal tracking, to avoid desync errors.  Zero when flat.
        /// </summary>
        public double UnrealizedPnl { get; set; }

        /// <summary>
        /// Realised P&L of the most recently completed round-trip trade (negative = loss).
        /// Updated on each closing fill.  Zero until the first trade closes this session.
        /// Used by SingleTradeLossExceeds condition.
        /// </summary>
        public double LastTradePnl { get; set; }

        /// <summary>
        /// Consecutive losses counter filtered to only include losses whose absolute
        /// P&L exceeds the rule's MinLossUsdForStreak threshold.  Used by
        /// ConsecutiveLossesAtLeast when MinLossUsdForStreak > 0.  When the threshold
        /// is 0, ConsecutiveLosses is used instead (default / backward-compat behaviour).
        /// </summary>
        public double ConsecutiveLossesAboveMin { get; set; }
    }

    // =========================================================================
    // GuardConfig — root XML container (list of rules + master switch)
    // =========================================================================

    [XmlRoot("GuardConfig")]
    public class GuardConfig
    {
        [XmlAttribute] public bool MasterEnabled { get; set; } = true;

        // Strict Lock as a STANDING setting (commitment device). When on, any pause/disconnect
        // that fires engages an un-bypassable lockout for StrictModeLockMinutes: entries stay
        // frozen the whole time, and force-reset / end-early / turning Guard or this setting off
        // are all refused until the clock releases it. Inert (no behavior change) while false.
        [XmlAttribute] public bool StrictModeEnabled     { get; set; } = false;
        // Lockout length once engaged, in minutes. 0 = rest of day (until 17:00).
        [XmlAttribute] public int  StrictModeLockMinutes { get; set; } = 60;

        [XmlArray("Rules")]
        [XmlArrayItem("Rule")]
        public List<GuardRule> Rules { get; set; } = new List<GuardRule>();
    }
}
