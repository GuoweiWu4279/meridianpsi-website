using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// A one-screen gallery rendering every <see cref="Ui"/> component once, so
    /// the new visual language can be reviewed (offline, via the UI harness)
    /// before it is applied to real product screens. Not shipped/wired into the
    /// product UI — review scaffold only.
    /// </summary>
    internal static class UiGallery
    {
        public static FrameworkElement Build()
        {
            var root = new StackPanel { Margin = new Thickness(Theme.S5) };

            root.Children.Add(Ui.Txt("Meridian — UI Component Gallery", Theme.TDisplay, Theme.FgPrimary, FontWeights.Bold));
            var sub = Ui.Txt("New design language: color tokens, type scale, spacing, reusable components.", Theme.TBody, Theme.FgSecondary);
            sub.Margin = new Thickness(0, Theme.S1, 0, Theme.S5);
            root.Children.Add(sub);

            // Stat tiles (multi-column — not stacked)
            root.Children.Add(Ui.SectionHeader("Stat tiles"));
            root.Children.Add(Ui.TileGrid(4, Theme.S3,
                Ui.StatTile("Final PSI", "62", "Warning zone", Theme.Warning),
                Ui.StatTile("Net P&L", "+$390", "5 trades", Theme.Good),
                Ui.StatTile("Win rate", "80%", "4 / 5"),
                Ui.StatTile("Composure", "71%", "Slipping", Theme.Caution)));

            root.Children.Add(Ui.Divider());

            // Buttons
            root.Children.Add(Ui.SectionHeader("Buttons"));
            root.Children.Add(Ui.Row(Theme.S2,
                Ui.Button("Primary", BtnVariant.Primary),
                Ui.Button("Secondary", BtnVariant.Secondary),
                Ui.Button("Ghost", BtnVariant.Ghost),
                Ui.Button("Danger", BtnVariant.Danger)));

            root.Children.Add(Ui.Divider());

            // Zone pills
            root.Children.Add(Ui.SectionHeader("Zone pills"));
            root.Children.Add(Ui.Row(Theme.S2,
                Ui.Pill("STABLE", Theme.Stable),
                Ui.Pill("CAUTION", Theme.Caution),
                Ui.Pill("WARNING", Theme.Warning),
                Ui.Pill("CRITICAL", Theme.Critical)));

            root.Children.Add(Ui.Divider());

            // Signal bars inside a card
            root.Children.Add(Ui.SectionHeader("Signal bars"));
            var bars = new StackPanel();
            bars.Children.Add(Ui.MetricBar("D3 Size Spike", 0.78, Theme.Critical, "78"));
            bars.Children.Add(Ui.MetricBar("D1 Revenge", 0.22, Theme.Caution, "22"));
            bars.Children.Add(Ui.MetricBar("D4 Hold Bias", 0.05, Theme.Stable, "5"));
            root.Children.Add(Ui.Card(bars));

            root.Children.Add(Ui.Divider());

            // Composed card — a teaser of the Debrief verdict
            root.Children.Add(Ui.SectionHeader("Composed card (Debrief teaser)"));
            var inner = new StackPanel();
            inner.Children.Add(Ui.Txt("You got lucky today.", Theme.TTitle, Theme.FgPrimary, FontWeights.Bold));
            var line = Ui.Txt("$258 of your +$390 (66%) came from one oversized trade — borrowed from variance.", Theme.TBody, Theme.FgSecondary);
            line.Margin = new Thickness(0, Theme.S2, 0, Theme.S3);
            inner.Children.Add(line);
            inner.Children.Add(Ui.Row(Theme.S2, Ui.Pill("LUCK  $258", Theme.Warning), Ui.Pill("EARNED  $132", Theme.Stable)));
            root.Children.Add(Ui.Card(inner));

            return new Border { Background = Theme.BgWindow, Child = root };
        }
    }
}
