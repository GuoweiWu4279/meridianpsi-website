﻿#region Using declarations
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NinjaTrader.Cbi;
#endregion

// =====================================================================
// IntegrityCheck — runtime invariant assertion + auto-repair subsystem.
//
// Purpose: turn MeridianPSI from a "glass machine" (one wrong NT8 event
// cascades into total state collapse) into a "self-healing machine" (state
// drift is detected within 1 s, logged loudly, and corrected from NT8
// ground truth automatically).
//
// Architecture:
//   1. MeridianPSI builds an immutable IntegritySnapshot every 1 s on
//      a dedicated background timer.  The snapshot copies all internal
//      dictionaries and counters atomically (per-key snapshot semantics).
//   2. IntegrityCheck.Run(snapshot) returns a List<IntegrityViolation>
//      with no side effects — pure analysis.  Reusable by the live
//      runtime, the LogReplayHarness, and the PropertyFuzzer.
//   3. MeridianPSI.RepairViolations(violations) applies repairs in a
//      deterministic order (NT8 truth always wins), logs both the
//      [INTEGRITY VIOLATION] and the [INTEGRITY REPAIRED] line.
//
// Design constraints:
//   • Every violation carries a stable Code (enum) so users / logs /
//     replay reports can grep without parsing prose.
//   • Severity = Info  → cosmetic / transient (mid-event windows).  Logged
//                        but never repaired.
//   • Severity = Warning → recoverable inconsistency.  Logged + repaired
//                          if it persists more than the grace window.
//   • Severity = Critical → will produce wrong PSI / wrong trade count
//                           if not fixed.  Logged + repaired immediately.
//   • Persistence filter: the live runtime filters Warning-level
//     violations by "must persist for >= 1 s".  IntegrityCheck itself is
//     stateless; the persistence tracking lives in MeridianPSI.
// =====================================================================

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>Severity of an integrity violation.</summary>
    public enum IntegritySeverity
    {
        /// <summary>Cosmetic / transient — likely a mid-event observation; never repaired.</summary>
        Info     = 0,
        /// <summary>Inconsistent but recoverable; repaired if it persists past the grace window.</summary>
        Warning  = 1,
        /// <summary>Will produce wrong PSI / wrong trade count if uncorrected; repaired immediately.</summary>
        Critical = 2,
    }

    /// <summary>
    /// Stable code for each invariant violation.  Names follow GROUP_LETTER+NUM pattern
    /// matching the Architecture §15 invariant table.  Logs grep-friendly.
    /// </summary>
    public enum IntegrityCode
    {
        // Group A: Shadow state ↔ NT8 ground truth
        A1_ShadowQtyDisagreesWithNt8        = 100,
        A2_Nt8OpenButShadowMissing          = 101,
        A3_ShadowDirDisagreesWithNt8        = 102,
        A4_ShadowOpenButNt8Flat             = 103,
        A5_ShadowDirsAndQtysOutOfSync       = 104,

        // Group B: Lifecycle metadata ↔ NT8 ground truth
        B1_LifecycleNotInNt8                = 200,
        B2_Nt8OpenButLifecycleMissing       = 201,
        B3_LifecycleDirectionMismatch       = 202,
        B4_LifecycleCarriesFlat             = 203,

        // Group C: Bridge dictionary consistency
        C1_OriginObservedOrphan             = 300,
        C2_OriginObservedMissingForLife     = 301,
        C3_ReversalBridgeStuck              = 302,
        C4_FlatPendingOverlapsLifecycle     = 303,

        // Group D: Counter / session sanity
        D1_NegativeTotalTrades              = 400,
        D2_NegativeSessionEntryCount        = 401,
        D3_EntryCountBelowTotalTrades       = 402,
        D4_EntryCountExceedsRecordedPlusOpen = 403,

        // Group E: Pending partial-close state
        E1_PendingPnlOrphan                 = 500,
        E2_PendingPnlAndQtyOutOfSync        = 501,

        // Group F: Per-position auxiliary state
        F1_EntryTimeOrphan                  = 600,
        F2_EntryPriceOrphan                 = 601,
        F3_PositionMinPnlOrphan             = 602,
    }

    /// <summary>
    /// Symbolic repair action to apply to MeridianPSI when a violation persists.
    /// Resolves to a concrete dictionary mutation in MeridianPSI.RepairViolation.
    /// </summary>
    public enum IntegrityRepairKind
    {
        None                       = 0,
        ClearShadowKey             = 1,  // remove from _positionQuantities + _positionDirections
        SetShadowFromNt8           = 2,  // overwrite shadow state with NT8 truth
        ClearLifecycleAndBridges   = 3,  // remove from _lifecycles + _posOriginObserved + _flatPending
        ClearReversalBridge        = 4,  // remove from _reversalCloseOriginObserved
        ClearFlatPending           = 5,  // remove from _flatPending
        ClearPendingPnlAndQty      = 6,  // remove from _pendingPartialPnl + _pendingPartialQty (no-op; dicts removed)
        ClearAuxStateForPosKey     = 7,  // clear _positionEntryTimes/_positionEntryPrices/_positionMinPnl
        ReconcileLifecycleFromNt8  = 8,  // re-fire ProcessLifecycleEdge logic with NT8 truth as the synthetic event
        ForceCompleteRetiringLifecycle = 9, // B3: force-record a stuck retiring lifecycle (fills never arrived)
        TryRecordRetiringLifecycle     = 10, // B1-enhanced: call TryRecordTrade for a retiring lifecycle
        /// <summary>
        /// C2a repair: a lifecycle has OriginObserved=false but was minted after the bootstrap
        /// window closed (wrongly tagged ghost, likely from the bootstrap-reset bug fixed 2026-04-25).
        /// Repair: set OriginObserved=true on the live lifecycle and — if it is already in the
        /// retiring table — call TryRecordTrade so the trade is recorded and cleaned up.
        /// </summary>
        SetOriginObservedAndRetry      = 11,
    }

    /// <summary>
    /// One detected violation.  Pure data; no behavior.
    /// </summary>
    public sealed class IntegrityViolation
    {
        public IntegrityCode       Code;
        public IntegritySeverity   Severity;
        public string              PosKey;          // empty string if non-position-specific
        public string              Description;
        public IntegrityRepairKind RepairKind;

        public override string ToString()
        {
            return string.Format("[{0}/{1}] {2}{3}: {4}",
                Severity, Code,
                string.IsNullOrEmpty(PosKey) ? "" : "posKey=",
                string.IsNullOrEmpty(PosKey) ? "" : PosKey,
                Description);
        }
    }

    /// <summary>
    /// Atomic snapshot of one NT8 position's state at the moment the snapshot
    /// was built.  Captured with snapshot semantics (each field read once into
    /// a local) to minimise tearing risk.
    /// </summary>
    public struct Nt8PositionSnap
    {
        public string         AccountName;
        public string         InstrumentName;
        public MarketPosition Direction;
        public double         Quantity;
        public double         AveragePrice;
    }

    /// <summary>
    /// Public snapshot of one MeridianPSI.PositionLifecycle entry.  Decoupled
    /// from the internal class so IntegrityCheck doesn't depend on MeridianPSI
    /// internals; the LogReplayHarness can construct these directly.
    /// </summary>
    public sealed class LifecycleSnap
    {
        public Guid           LifecycleId;
        public DateTime       EntryTime;
        public double         MaxQtySeen;
        public bool           OriginObserved;
        public MarketPosition Direction;
        /// <summary>Wall-clock UTC time at which this lifecycle was minted (see PositionLifecycle.MintedAt).</summary>
        public DateTime       MintedAt;
    }

    /// <summary>
    /// Public snapshot of a lifecycle that is in the retiring state
    /// (REMOVE fired, waiting for close fills to complete TryRecordTrade).
    /// </summary>
    public sealed class RetiringLifecycleSnap
    {
        public Guid           LifecycleId;
        public DateTime       EntryTime;
        public MarketPosition Direction;
        public bool           OriginObserved;
        public bool           IsRemoved;
        public bool           Recorded;
        public double         AccumulatedPnl;
        public int            QtyAtLastScaleIn;
        public int            PostLastScaleInCloseQty;
        public DateTime       LastCloseFillTime;
        /// <summary>Wall-clock UTC time at which this lifecycle was minted (see PositionLifecycle.MintedAt).</summary>
        public DateTime       MintedAt;
    }

    /// <summary>
    /// Immutable, atomically-collected view of all MeridianPSI state relevant
    /// to integrity invariants.  Constructed by MeridianPSI.BuildIntegritySnapshot;
    /// consumed by IntegrityCheck.Run.  Read-only — IntegrityCheck cannot mutate
    /// state, removing entire classes of "the analyzer broke the system" bugs.
    /// </summary>
    public sealed class IntegritySnapshot
    {
        public DateTime    SnapshotTime;

        // Shadow state (PSI cache — now used for D3/D5 continuous signals only)
        public IReadOnlyDictionary<string, double>          PositionQuantities;
        public IReadOnlyDictionary<string, MarketPosition>  PositionDirections;

        // Active lifecycle metadata (Axiom A1)
        public IReadOnlyDictionary<string, LifecycleSnap>           Lifecycles;
        /// <summary>Retiring lifecycles (between Remove and TryRecordTrade completing).</summary>
        public IReadOnlyDictionary<string, RetiringLifecycleSnap>   RetiringLifecycles;

        // Bridge dictionaries (kept for snapshot ABI compat but now always empty)
        public IReadOnlyDictionary<string, bool>            PosOriginObserved;
        public IReadOnlyDictionary<string, bool>            ReversalCloseOriginObserved;
        public IReadOnlyDictionary<string, bool>            FlatPending;

        // Pending round-trip accumulation (now on lifecycle objects; these dicts are always empty)
        public IReadOnlyDictionary<string, double>          PendingPartialPnl;
        public IReadOnlyDictionary<string, double>          PendingPartialQty;

        // Per-position auxiliary tracking
        public IReadOnlyDictionary<string, DateTime>        PositionEntryTimes;
        public IReadOnlyDictionary<string, double>          PositionEntryPrices;
        public IReadOnlyDictionary<string, double>          PositionMinPnl;

        // NT8 ground truth (per posKey)
        public IReadOnlyDictionary<string, Nt8PositionSnap> Nt8Positions;

        /// <summary>
        /// Copy of _accountSubscribedAt at snapshot time.
        /// Keyed by account name.  Used by C2 to distinguish true bootstrap ghosts
        /// (lifecycle.MintedAt ≈ subscribedAt) from wrongly-tagged live trades
        /// (lifecycle.MintedAt significantly after subscribedAt + BootstrapReplayWindow).
        /// </summary>
        public IReadOnlyDictionary<string, DateTime>        AccountSubscribedAt;

        // Engine + session counters
        public int      TotalTrades;        // _currentSession.TotalTrades
        public int      SessionEntryCount;  // _engine.SessionEntryCount

        // Bootstrap window status
        public bool     InBootstrapWindow;
    }

    /// <summary>
    /// Stateless invariant checker.  Pure function: snapshot in → violations out.
    /// </summary>
    public static class IntegrityCheck
    {
        /// <summary>
        /// Run all invariants over <paramref name="s"/>.  Returns a list (possibly
        /// empty); each element describes exactly one violation.  Order is by
        /// group (A → F) for stable diff in replay reports.
        /// </summary>
        public static List<IntegrityViolation> Run(IntegritySnapshot s)
        {
            var v = new List<IntegrityViolation>(8);
            if (s == null) return v;

            CheckGroupA_ShadowVsNt8(s, v);
            CheckGroupB_LifecycleVsNt8(s, v);
            CheckGroupB3_RetiringLifecycles(s, v);
            CheckGroupC_BridgeDicts(s, v);
            CheckGroupD_Counters(s, v);
            CheckGroupE_PendingState(s, v);
            CheckGroupF_AuxState(s, v);

            return v;
        }

        /// <summary>
        /// Format a violation list into a multi-line report suitable for log
        /// output, replay-result files, or the License → Developer Tools panel.
        /// </summary>
        public static string FormatReport(IList<IntegrityViolation> violations,
                                          DateTime stamp)
        {
            var sb = new StringBuilder();
            sb.Append("=== INTEGRITY REPORT @ ").Append(stamp.ToString("o")).Append(" ===\n");
            if (violations == null || violations.Count == 0)
            {
                sb.Append("OK — no violations detected.\n");
                return sb.ToString();
            }
            sb.Append(violations.Count).Append(" violation(s):\n");
            foreach (var x in violations) sb.Append("  ").Append(x).Append('\n');
            return sb.ToString();
        }

        // ──────────────────────────────────────────────────────────────────
        // Group A — Shadow state ↔ NT8 ground truth.
        //
        // These check that _positionQuantities / _positionDirections agree
        // with what NT8 is currently reporting.  All A-violations are
        // Critical because they directly drive HUD trade counts and engine
        // ProcessExecution closure logic.
        //
        // Repair: SetShadowFromNt8 (NT8 wins) for A1/A3, ClearShadowKey for
        // A4 (shadow says open but NT8 flat → stale ghost), and Reconcile-
        // LifecycleFromNt8 for A2 (NT8 has a position we missed entirely).
        // ──────────────────────────────────────────────────────────────────
        private static void CheckGroupA_ShadowVsNt8(IntegritySnapshot s, List<IntegrityViolation> v)
        {
            // A1: shadow has a non-flat qty that differs from NT8's qty
            // A3: shadow has a direction that differs from NT8's direction
            // A4: shadow has a non-flat key that NT8 reports flat for
            foreach (var kv in s.PositionDirections)
            {
                var posKey = kv.Key;
                var shadowDir = kv.Value;
                if (shadowDir == MarketPosition.Flat) continue;

                Nt8PositionSnap nt8;
                bool hasNt8 = s.Nt8Positions.TryGetValue(posKey, out nt8);

                if (!hasNt8 || nt8.Direction == MarketPosition.Flat)
                {
                    // Skip A4 when _flatPending is set for this key: shadow hasn't been
                    // cleared yet because the execution close fill hasn't arrived yet.
                    // This is the same legitimate-transient exemption C1 already uses
                    // (line ~478).  The transient resolves within one event step.
                    if (s.FlatPending.ContainsKey(posKey)) continue;

                    v.Add(new IntegrityViolation
                    {
                        Code        = IntegrityCode.A4_ShadowOpenButNt8Flat,
                        Severity    = IntegritySeverity.Critical,
                        PosKey      = posKey,
                        Description = string.Format(
                            "Shadow tracks {0} qty={1} but NT8 reports flat (or missing).  Stale shadow ghost — clear.",
                            shadowDir,
                            s.PositionQuantities.TryGetValue(posKey, out var qShadow) ? qShadow : double.NaN),
                        RepairKind  = IntegrityRepairKind.ClearShadowKey,
                    });
                    continue;
                }

                if (nt8.Direction != shadowDir)
                {
                    v.Add(new IntegrityViolation
                    {
                        Code        = IntegrityCode.A3_ShadowDirDisagreesWithNt8,
                        Severity    = IntegritySeverity.Critical,
                        PosKey      = posKey,
                        Description = string.Format(
                            "Shadow direction {0} but NT8 reports {1}.  Possible undetected reversal.",
                            shadowDir, nt8.Direction),
                        RepairKind  = IntegrityRepairKind.SetShadowFromNt8,
                    });
                }

                double shadowQty;
                if (s.PositionQuantities.TryGetValue(posKey, out shadowQty))
                {
                    if (Math.Abs(shadowQty - nt8.Quantity) > 1e-9)
                    {
                        v.Add(new IntegrityViolation
                        {
                            Code        = IntegrityCode.A1_ShadowQtyDisagreesWithNt8,
                            Severity    = IntegritySeverity.Critical,
                            PosKey      = posKey,
                            Description = string.Format(
                                "Shadow qty={0} but NT8 qty={1}.  Drift {2:+0.##;-0.##}.",
                                shadowQty, nt8.Quantity, nt8.Quantity - shadowQty),
                            RepairKind  = IntegrityRepairKind.SetShadowFromNt8,
                        });
                    }
                }
                else
                {
                    v.Add(new IntegrityViolation
                    {
                        Code        = IntegrityCode.A5_ShadowDirsAndQtysOutOfSync,
                        Severity    = IntegritySeverity.Warning,
                        PosKey      = posKey,
                        Description = "PositionDirections has key but PositionQuantities does not.",
                        RepairKind  = IntegrityRepairKind.SetShadowFromNt8,
                    });
                }
            }

            // A2: NT8 reports a non-flat position our shadow missed entirely
            //     (post-bootstrap; during the bootstrap window NT8 is still
            //      replaying the existing snapshot, so don't false-positive).
            //
            // RepairKind = SetShadowFromNt8 (NOT ReconcileLifecycleFromNt8).
            //
            // Root cause of the repair loop fixed here (2026-05-01):
            // ReconcileLifecycleFromNt8 calls ReconcileLifecycleEdgeAtomic,
            // which creates/updates the lifecycle object but NEVER writes
            // _positionDirections or _positionQuantities.  On the next
            // IntegrityCheck tick, A2 checks PositionDirections, finds it
            // still flat, and fires again — forever.  With 100+ cycles/session
            // this generated 100+ phantom D7 PSI commits from the ADD path.
            //
            // SetShadowFromNt8 directly writes _positionDirections[posKey]
            // and _positionQuantities[posKey] from NT8 truth, so A2 passes
            // on the very next tick.  The lifecycle itself is created by the
            // companion B2 violation (B2_Nt8OpenButLifecycleMissing) which
            // fires on the same tick and still uses ReconcileLifecycleFromNt8.
            if (!s.InBootstrapWindow)
            {
                foreach (var kv in s.Nt8Positions)
                {
                    if (kv.Value.Direction == MarketPosition.Flat) continue;
                    if (s.PositionDirections.TryGetValue(kv.Key, out var d) && d != MarketPosition.Flat) continue;

                    v.Add(new IntegrityViolation
                    {
                        Code        = IntegrityCode.A2_Nt8OpenButShadowMissing,
                        Severity    = IntegritySeverity.Critical,
                        PosKey      = kv.Key,
                        Description = string.Format(
                            "NT8 reports {0} qty={1} but our shadow is flat/missing.  Missed entry.",
                            kv.Value.Direction, kv.Value.Quantity),
                        RepairKind  = IntegrityRepairKind.SetShadowFromNt8,
                    });
                }
            }

            // A5: PositionQuantities has a key with no matching PositionDirections
            foreach (var kv in s.PositionQuantities)
            {
                if (!s.PositionDirections.ContainsKey(kv.Key))
                {
                    v.Add(new IntegrityViolation
                    {
                        Code        = IntegrityCode.A5_ShadowDirsAndQtysOutOfSync,
                        Severity    = IntegritySeverity.Warning,
                        PosKey      = kv.Key,
                        Description = "PositionQuantities has key but PositionDirections does not.",
                        RepairKind  = IntegrityRepairKind.ClearShadowKey,
                    });
                }
            }
        }

        // ──────────────────────────────────────────────────────────────────
        // Group B — Lifecycle metadata ↔ NT8 ground truth.
        //
        // Lifecycles are the post-shadow source of truth (Axiom A1).  These
        // checks exist to detect the exact bug class that produced the
        // 02-17 PM CSV failure: a stuck lifecycle whose NT8 position has
        // already gone flat.
        // ──────────────────────────────────────────────────────────────────
        private static void CheckGroupB_LifecycleVsNt8(IntegritySnapshot s, List<IntegrityViolation> v)
        {
            foreach (var kv in s.Lifecycles)
            {
                var posKey = kv.Key;
                var life = kv.Value;

                // B4: lifecycle should never carry Flat as a direction
                if (life.Direction == MarketPosition.Flat)
                {
                    v.Add(new IntegrityViolation
                    {
                        Code        = IntegrityCode.B4_LifecycleCarriesFlat,
                        Severity    = IntegritySeverity.Critical,
                        PosKey      = posKey,
                        Description = "Lifecycle.Direction == Flat — invariant violated; lifecycle is meaningless without a direction.",
                        RepairKind  = IntegrityRepairKind.ClearLifecycleAndBridges,
                    });
                    continue;
                }

                Nt8PositionSnap nt8;
                bool hasNt8 = s.Nt8Positions.TryGetValue(posKey, out nt8);

                if (!hasNt8 || nt8.Direction == MarketPosition.Flat)
                {
                    v.Add(new IntegrityViolation
                    {
                        Code        = IntegrityCode.B1_LifecycleNotInNt8,
                        Severity    = IntegritySeverity.Critical,
                        PosKey      = posKey,
                        Description = string.Format(
                            "Lifecycle has {0} (id={1}) but NT8 reports flat.  Lifecycle never retired — Operation_Remove was missed.  This is the 02-17 PM root-cause class.",
                            life.Direction, life.LifecycleId),
                        RepairKind  = IntegrityRepairKind.TryRecordRetiringLifecycle,
                    });
                    continue;
                }
                // B3: directions disagree (an undetected reversal)
                if (nt8.Direction != life.Direction)
                {
                    v.Add(new IntegrityViolation
                    {
                        Code        = IntegrityCode.B3_LifecycleDirectionMismatch,
                        Severity    = IntegritySeverity.Critical,
                        PosKey      = posKey,
                        Description = string.Format(
                            "Lifecycle direction {0} but NT8 has {1}.  Reversal edge missed.",
                            life.Direction, nt8.Direction),
                        RepairKind  = IntegrityRepairKind.ReconcileLifecycleFromNt8,
                    });
                }
            }

            // B2: NT8 has a non-flat position with no lifecycle (post-bootstrap)
            if (!s.InBootstrapWindow)
            {
                foreach (var kv in s.Nt8Positions)
                {
                    if (kv.Value.Direction == MarketPosition.Flat) continue;
                    if (s.Lifecycles.ContainsKey(kv.Key)) continue;

                    v.Add(new IntegrityViolation
                    {
                        Code        = IntegrityCode.B2_Nt8OpenButLifecycleMissing,
                        Severity    = IntegritySeverity.Critical,
                        PosKey      = kv.Key,
                        Description = string.Format(
                            "NT8 has {0} qty={1} but no lifecycle entry.  Position_Add was missed.",
                            kv.Value.Direction, kv.Value.Quantity),
                        RepairKind  = IntegrityRepairKind.ReconcileLifecycleFromNt8,
                    });
                }
            }
        }

        // ──────────────────────────────────────────────────────────────────
        // Group B3 — Retiring lifecycle consistency (new, post-refactor).
        //
        // A retiring lifecycle is a PositionLifecycle that has had
        // IsRemoved = true set by the REMOVE edge handler, and is waiting
        // for close fills to accumulate before TryRecordTrade can fire.
        // This check enforces two invariants:
        //   B3a: a retiring lifecycle that is NOT yet recorded, AND NT8
        //        confirms the position is flat, AND > 5 s have elapsed since
        //        removal → force-complete it (accept whatever PnL arrived).
        //   B3b: a retiring lifecycle that has all its fills (PostClose >=
        //        QtyAtLastScaleIn) but !Recorded → the gate failed to fire;
        //        call TryRecordTrade normally.
        // ──────────────────────────────────────────────────────────────────
        private static void CheckGroupB3_RetiringLifecycles(IntegritySnapshot s, List<IntegrityViolation> v)
        {
            if (s.RetiringLifecycles == null) return;

            foreach (var kv in s.RetiringLifecycles)
            {
                var posKey = kv.Key;
                var life   = kv.Value;
                if (life.Recorded) continue;   // already done — should not be in snapshot but be safe

                bool nt8IsFlat = !s.Nt8Positions.ContainsKey(posKey) ||
                                 s.Nt8Positions[posKey].Direction == MarketPosition.Flat;

                // B3b: all fills arrived but Recorded is still false (gate failure)
                if (life.PostLastScaleInCloseQty >= life.QtyAtLastScaleIn && life.IsRemoved)
                {
                    v.Add(new IntegrityViolation
                    {
                        Code        = IntegrityCode.B1_LifecycleNotInNt8,
                        Severity    = IntegritySeverity.Warning,
                        PosKey      = posKey,
                        Description = string.Format(
                            "Retiring lifecycle id={0} has all fills (closeQty={1} >= expected={2}) but Recorded=false.  TryRecordTrade gate stalled.",
                            life.LifecycleId, life.PostLastScaleInCloseQty, life.QtyAtLastScaleIn),
                        RepairKind  = IntegrityRepairKind.TryRecordRetiringLifecycle,
                    });
                    continue;
                }

                // B3a: NT8 is flat + elapsed > 5s → force-complete with partial PnL
                if (nt8IsFlat)
                {
                    double elapsedSec = (s.SnapshotTime - life.EntryTime).TotalSeconds;
                    if (elapsedSec > 5.0)
                    {
                        v.Add(new IntegrityViolation
                        {
                            Code        = IntegrityCode.B1_LifecycleNotInNt8,
                            Severity    = IntegritySeverity.Critical,
                            PosKey      = posKey,
                            Description = string.Format(
                                "Retiring lifecycle id={0} stuck for {1:F0}s (closeQty={2} < expected={3}, NT8=flat).  Force-completing with partial PnL={4:F2}.",
                                life.LifecycleId, elapsedSec, life.PostLastScaleInCloseQty, life.QtyAtLastScaleIn, life.AccumulatedPnl),
                            RepairKind  = IntegrityRepairKind.ForceCompleteRetiringLifecycle,
                        });
                    }
                }
            }
        }

        // ──────────────────────────────────────────────────────────────────
        // Group C — OriginObserved lifecycle integrity.
        //
        // The old bridge dictionaries (_posOriginObserved, _reversalCloseOriginObserved,
        // _flatPending, _pendingPartialPnl, _pendingPartialQty) have been removed from
        // MeridianPSI — OriginObserved now lives directly on PositionLifecycle.
        // C1/C3/C4 are retained in ABI-compat form (always-empty dicts → no violations).
        // C2 is fully rewritten to validate lifecycle.OriginObserved against the real
        // source of truth: MintedAt vs AccountSubscribedAt + bootstrap window.
        // ──────────────────────────────────────────────────────────────────
        private static void CheckGroupC_BridgeDicts(IntegritySnapshot s, List<IntegrityViolation> v)
        {
            // Bootstrap window — mirrors MeridianPSI.BootstrapReplayWindow (2 seconds).
            // Defined here so IntegrityCheck does not need a reference back to MeridianPSI.
            var bootstrapWindow = TimeSpan.FromSeconds(2.0);

            // C1/C2: _posOriginObserved — now always empty; no violations expected
            foreach (var kv in s.PosOriginObserved)
            {
                if (s.Lifecycles.ContainsKey(kv.Key)) continue;
                if (s.FlatPending.ContainsKey(kv.Key)) continue;

                v.Add(new IntegrityViolation
                {
                    Code        = IntegrityCode.C1_OriginObservedOrphan,
                    Severity    = IntegritySeverity.Warning,
                    PosKey      = kv.Key,
                    Description = "PosOriginObserved has key with no matching lifecycle nor FlatPending.  Orphan bridge entry.",
                    RepairKind  = IntegrityRepairKind.ClearLifecycleAndBridges,
                });
            }

            // C2a — wrongly-tagged active lifecycle: OriginObserved=false but minted AFTER
            // the bootstrap window closed.  This is only possible if the bootstrap window was
            // reset by a spurious AccountStatusUpdate AFTER process startup (the
            // bootstrap-reset bug fixed 2026-04-25 by switching _accountSubscribedAt to
            // TryAdd semantics).  The check uses MintedAt vs AccountSubscribedAt to distinguish
            // a true bootstrap ghost (minted WITHIN the 2-second window) from a wrongly-tagged
            // live trade (minted after the window had already closed).
            foreach (var kv in s.Lifecycles)
            {
                var lc = kv.Value;
                if (lc.OriginObserved) continue;  // correctly observed — no issue

                // Extract account name from posKey ("AcctName::Instrument")
                string acctName = kv.Key.Contains("::") ? kv.Key.Substring(0, kv.Key.IndexOf("::")) : string.Empty;
                DateTime subscribedAt;
                if (!s.AccountSubscribedAt.TryGetValue(acctName, out subscribedAt)) continue;

                // True bootstrap ghost: lifecycle was minted WITHIN the bootstrap window.
                var mintOffset = lc.MintedAt - subscribedAt;
                if (mintOffset <= bootstrapWindow) continue;

                // Lifecycle minted AFTER bootstrap window closed but has OriginObserved=false.
                v.Add(new IntegrityViolation
                {
                    Code        = IntegrityCode.C2_OriginObservedMissingForLife,
                    Severity    = IntegritySeverity.Warning,
                    PosKey      = kv.Key,
                    Description = string.Format(
                        "Active lifecycle minted {0:F1}s after subscription (bootstrap window={1:F0}s) but OriginObserved=false. " +
                        "Trade will be silently dropped when it closes. Repairing by setting OriginObserved=true.",
                        mintOffset.TotalSeconds, bootstrapWindow.TotalSeconds),
                    RepairKind  = IntegrityRepairKind.SetOriginObservedAndRetry,
                });
            }

            // C2b — wrongly-tagged retiring lifecycle: same diagnosis as C2a, but the position
            // has already closed (IsRemoved=true).  TryRecordTrade will skip it silently.
            // Also catches retiring ghosts stuck in the table with all fills received but
            // TryRecordTrade never called — these need cleanup regardless of why they're there.
            foreach (var kv in s.RetiringLifecycles)
            {
                var lc = kv.Value;
                if (lc.Recorded) continue;  // already cleaned up — no issue

                // Sub-case C2b-i: wrongly-tagged (minted after bootstrap window).
                string acctName = kv.Key.Contains("::") ? kv.Key.Substring(0, kv.Key.IndexOf("::")) : string.Empty;
                DateTime subscribedAt;
                bool hasSubscription = s.AccountSubscribedAt.TryGetValue(acctName, out subscribedAt);
                bool wronglyTagged = hasSubscription && !lc.OriginObserved &&
                                     (lc.MintedAt - subscribedAt) > bootstrapWindow;

                // Sub-case C2b-ii: any unrecorded retiring lifecycle (observed or not) with
                // all fills received that is stuck (TryRecordTrade cleanup never fired).
                bool allFillsArrived = lc.QtyAtLastScaleIn > 0 &&
                                       lc.PostLastScaleInCloseQty >= lc.QtyAtLastScaleIn;
                bool stuck = allFillsArrived && !lc.Recorded;

                if (!wronglyTagged && !stuck) continue;

                var repairKind = wronglyTagged
                    ? IntegrityRepairKind.SetOriginObservedAndRetry
                    : IntegrityRepairKind.TryRecordRetiringLifecycle;

                string reason = wronglyTagged
                    ? string.Format(
                        "Retiring lifecycle minted {0:F1}s after subscription (bootstrap window={1:F0}s) but OriginObserved=false; trade will be silently dropped.",
                        (lc.MintedAt - subscribedAt).TotalSeconds, bootstrapWindow.TotalSeconds)
                    : string.Format(
                        "Retiring lifecycle with all fills received (closeQty={0}/{1}) and Recorded=false; TryRecordTrade cleanup never fired.",
                        lc.PostLastScaleInCloseQty, lc.QtyAtLastScaleIn);

                v.Add(new IntegrityViolation
                {
                    Code        = IntegrityCode.C2_OriginObservedMissingForLife,
                    Severity    = IntegritySeverity.Warning,
                    PosKey      = kv.Key,
                    Description = reason,
                    RepairKind  = repairKind,
                });
            }

            // C3: stuck reversal bridge (transient — should be cleared by close fill)
            //     If it persists across a snapshot, something failed to consume it.
            foreach (var kv in s.ReversalCloseOriginObserved)
            {
                v.Add(new IntegrityViolation
                {
                    Code        = IntegrityCode.C3_ReversalBridgeStuck,
                    Severity    = IntegritySeverity.Warning,
                    PosKey      = kv.Key,
                    Description = "ReversalCloseOriginObserved has a persistent entry; close fill failed to consume it.",
                    RepairKind  = IntegrityRepairKind.ClearReversalBridge,
                });
            }

            // C4: FlatPending overlaps a live lifecycle
            foreach (var kv in s.FlatPending)
            {
                if (!s.Lifecycles.ContainsKey(kv.Key)) continue;
                v.Add(new IntegrityViolation
                {
                    Code        = IntegrityCode.C4_FlatPendingOverlapsLifecycle,
                    Severity    = IntegritySeverity.Warning,
                    PosKey      = kv.Key,
                    Description = "FlatPending key overlaps an open lifecycle — close path mid-flight ambiguity.",
                    RepairKind  = IntegrityRepairKind.ClearFlatPending,
                });
            }
        }

        // ──────────────────────────────────────────────────────────────────
        // Group D — Counter / session sanity.
        //
        // Trade counter invariants:
        //   D1: TotalTrades >= 0
        //   D2: SessionEntryCount >= 0
        //   D3: SessionEntryCount >= TotalTrades  (every closed round-trip
        //       must have been counted as an entry first)
        //   D4: SessionEntryCount <= TotalTrades + open lifecycles  (entries
        //       are bounded by recorded round-trips plus currently-open ones)
        // ──────────────────────────────────────────────────────────────────
        private static void CheckGroupD_Counters(IntegritySnapshot s, List<IntegrityViolation> v)
        {
            if (s.TotalTrades < 0)
            {
                v.Add(new IntegrityViolation
                {
                    Code        = IntegrityCode.D1_NegativeTotalTrades,
                    Severity    = IntegritySeverity.Critical,
                    PosKey      = "",
                    Description = "TotalTrades = " + s.TotalTrades + " (must be >= 0).",
                    RepairKind  = IntegrityRepairKind.None,
                });
            }
            if (s.SessionEntryCount < 0)
            {
                v.Add(new IntegrityViolation
                {
                    Code        = IntegrityCode.D2_NegativeSessionEntryCount,
                    Severity    = IntegritySeverity.Critical,
                    PosKey      = "",
                    Description = "SessionEntryCount = " + s.SessionEntryCount + " (must be >= 0).",
                    RepairKind  = IntegrityRepairKind.None,
                });
            }
            if (s.SessionEntryCount < s.TotalTrades)
            {
                v.Add(new IntegrityViolation
                {
                    Code        = IntegrityCode.D3_EntryCountBelowTotalTrades,
                    Severity    = IntegritySeverity.Critical,
                    PosKey      = "",
                    Description = string.Format(
                        "SessionEntryCount={0} < TotalTrades={1}: a round-trip was recorded without being counted as an entry — this is the HUD '1/3' bug class.",
                        s.SessionEntryCount, s.TotalTrades),
                    RepairKind  = IntegrityRepairKind.None,
                });
            }
            int upperBound = s.TotalTrades + s.Lifecycles.Count;
            if (s.SessionEntryCount > upperBound + 1)  // +1 grace for in-flight transitions
            {
                v.Add(new IntegrityViolation
                {
                    Code        = IntegrityCode.D4_EntryCountExceedsRecordedPlusOpen,
                    Severity    = IntegritySeverity.Warning,
                    PosKey      = "",
                    Description = string.Format(
                        "SessionEntryCount={0} > TotalTrades({1}) + open({2}) + 1 grace.  Phantom entry counted.",
                        s.SessionEntryCount, s.TotalTrades, s.Lifecycles.Count),
                    RepairKind  = IntegrityRepairKind.None,
                });
            }
        }

        // ──────────────────────────────────────────────────────────────────
        // Group E — Pending partial-close state.
        //
        // _pendingPartialPnl / _pendingPartialQty accumulate during partial
        // close fills until the round-trip finalises.  Their domain is
        // "positions currently being closed" — keys must belong to a known
        // lifecycle (or be in flight as FlatPending).  An orphan key means
        // a round-trip never finalised and the accumulator leaked.
        // ──────────────────────────────────────────────────────────────────
        private static void CheckGroupE_PendingState(IntegritySnapshot s, List<IntegrityViolation> v)
        {
            foreach (var kv in s.PendingPartialPnl)
            {
                bool hasContext =
                    s.Lifecycles.ContainsKey(kv.Key)   ||
                    s.FlatPending.ContainsKey(kv.Key)  ||
                    s.PositionDirections.TryGetValue(kv.Key, out var d) && d != MarketPosition.Flat;

                if (!hasContext)
                {
                    v.Add(new IntegrityViolation
                    {
                        Code        = IntegrityCode.E1_PendingPnlOrphan,
                        Severity    = IntegritySeverity.Warning,
                        PosKey      = kv.Key,
                        Description = string.Format(
                            "PendingPartialPnl={0:F2} for {1} has no lifecycle / FlatPending / shadow context.  Stale partial-fill accumulator.",
                            kv.Value, kv.Key),
                        RepairKind  = IntegrityRepairKind.ClearPendingPnlAndQty,
                    });
                }
            }

            // Symmetry: every key in PendingPartialPnl must be in PendingPartialQty
            foreach (var kv in s.PendingPartialPnl)
            {
                if (!s.PendingPartialQty.ContainsKey(kv.Key))
                {
                    v.Add(new IntegrityViolation
                    {
                        Code        = IntegrityCode.E2_PendingPnlAndQtyOutOfSync,
                        Severity    = IntegritySeverity.Warning,
                        PosKey      = kv.Key,
                        Description = "PendingPartialPnl has key, PendingPartialQty does not.",
                        RepairKind  = IntegrityRepairKind.ClearPendingPnlAndQty,
                    });
                }
            }
            foreach (var kv in s.PendingPartialQty)
            {
                if (!s.PendingPartialPnl.ContainsKey(kv.Key))
                {
                    v.Add(new IntegrityViolation
                    {
                        Code        = IntegrityCode.E2_PendingPnlAndQtyOutOfSync,
                        Severity    = IntegritySeverity.Warning,
                        PosKey      = kv.Key,
                        Description = "PendingPartialQty has key, PendingPartialPnl does not.",
                        RepairKind  = IntegrityRepairKind.ClearPendingPnlAndQty,
                    });
                }
            }
        }

        // ──────────────────────────────────────────────────────────────────
        // Group F — Per-position auxiliary state (entry time, entry price,
        // min unrealised PnL).  Should always have a corresponding lifecycle
        // or shadow direction; orphans are leaks.
        // ──────────────────────────────────────────────────────────────────
        private static void CheckGroupF_AuxState(IntegritySnapshot s, List<IntegrityViolation> v)
        {
            CheckAuxOrphans(s, s.PositionEntryTimes.Keys,
                IntegrityCode.F1_EntryTimeOrphan, "PositionEntryTimes", v);
            CheckAuxOrphans(s, s.PositionEntryPrices.Keys,
                IntegrityCode.F2_EntryPriceOrphan, "PositionEntryPrices", v);
            CheckAuxOrphans(s, s.PositionMinPnl.Keys,
                IntegrityCode.F3_PositionMinPnlOrphan, "PositionMinPnl", v);
        }

        private static void CheckAuxOrphans(IntegritySnapshot s,
                                            IEnumerable<string> keys,
                                            IntegrityCode code,
                                            string dictName,
                                            List<IntegrityViolation> v)
        {
            foreach (var k in keys)
            {
                if (s.Lifecycles.ContainsKey(k)) continue;
                if (s.PositionDirections.TryGetValue(k, out var d) && d != MarketPosition.Flat) continue;

                v.Add(new IntegrityViolation
                {
                    Code        = code,
                    Severity    = IntegritySeverity.Info,
                    PosKey      = k,
                    Description = dictName + " has key with no live lifecycle / shadow position.  Orphan aux state.",
                    RepairKind  = IntegrityRepairKind.ClearAuxStateForPosKey,
                });
            }
        }
    }
}
