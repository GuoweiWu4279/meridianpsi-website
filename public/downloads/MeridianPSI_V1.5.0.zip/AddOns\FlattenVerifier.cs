// FlattenVerifier.cs
//
// The brain of the hardened auto-flatten path (#31). PURE state machine — zero
// NinjaTrader dependencies — so the dangerous decision logic (when to retry, when
// to give up, and the absolute rule that "confirmed flat" requires actually
// OBSERVING zero open contracts) is exhaustively unit-testable offline with
// scripted broker responses. No broker, no live trigger needed to prove it correct.
//
// Why this exists:
//   The old path called acct.Flatten() once and ASSUMED success — then disconnected
//   the broker. If the flatten failed / partially filled / was rejected, the user
//   was left disconnected WITH an open position while the app believed it was flat.
//   This verifier replaces that with: flatten -> verify -> retry -> only report
//   ConfirmedFlat once zero contracts are actually observed; otherwise GaveUp (so
//   the caller can ALERT and stay connected instead of disconnecting blind).
//
// Cadence & the double-close guard:
//   acct.Flatten() submits async market orders. Re-issuing it before the prior
//   flatten's fills land could submit closing orders for a quantity that is already
//   being closed -> over-close -> a REVERSED position. So a retry only happens after
//   `settlePolls` poll intervals have elapsed since the last flatten (giving fills
//   time to land), and never while close orders are still working (closeOrdersPending).
//
// Driving it:
//   Live  -> a DispatcherTimer calls Tick() once per poll interval; the caller
//            inspects Status and acts (ConfirmedFlat -> proceed/disconnect; GaveUp
//            -> loud alert + STAY connected).
//   Tests -> Start()/Tick() are called manually with a scripted openContracts source.

using System;

namespace NinjaTrader.NinjaScript.AddOns
{
    public enum FlattenStatus { Running, ConfirmedFlat, GaveUp }

    public sealed class FlattenVerifier
    {
        private readonly Func<int>  _openContracts;       // current open contract count (>0 = still open)
        private readonly Action     _flatten;             // issue one flatten
        private readonly Func<bool> _closeOrdersPending;  // optional: true while our flatten orders are still working

        private readonly int _maxFlattenAttempts;         // how many times we'll (re-)issue a flatten
        private readonly int _settlePolls;                // poll intervals to wait after a flatten before re-issuing
        private readonly int _maxTotalPolls;              // hard cap (breaks a closeOrdersPending stall) -> GaveUp

        private int _attempts;
        private int _pollsSinceFlatten;
        private int _totalPolls;
        private FlattenStatus _status = FlattenStatus.Running;

        public FlattenStatus Status   => _status;
        public int           Attempts => _attempts;
        public bool          IsDone   => _status != FlattenStatus.Running;

        /// <param name="openContracts">Reads the live open-contract count. MUST reflect real fills.</param>
        /// <param name="flatten">Issues one flatten (idempotent on the broker side).</param>
        /// <param name="maxFlattenAttempts">Max flatten issues before giving up (default 3).</param>
        /// <param name="settlePolls">Polls to wait after a flatten before a retry (default 3 — lets fills land).</param>
        /// <param name="maxTotalPolls">Hard poll cap so a stuck "orders pending" can't loop forever (default 16).</param>
        /// <param name="closeOrdersPending">Optional: true while our close orders are still working (skip retry).</param>
        public FlattenVerifier(
            Func<int> openContracts,
            Action flatten,
            int maxFlattenAttempts = 3,
            int settlePolls = 3,
            int maxTotalPolls = 16,
            Func<bool> closeOrdersPending = null)
        {
            _openContracts      = openContracts ?? throw new ArgumentNullException(nameof(openContracts));
            _flatten            = flatten       ?? throw new ArgumentNullException(nameof(flatten));
            _closeOrdersPending = closeOrdersPending;
            _maxFlattenAttempts = Math.Max(1, maxFlattenAttempts);
            _settlePolls        = Math.Max(1, settlePolls);
            _maxTotalPolls      = Math.Max(_settlePolls * _maxFlattenAttempts + 1, maxTotalPolls);
        }

        /// <summary>
        /// Begin. If already flat, confirms immediately (no flatten issued). Otherwise
        /// issues the first flatten. Returns the resulting Status.
        /// </summary>
        public FlattenStatus Start()
        {
            if (_status != FlattenStatus.Running) return _status;
            if (_openContracts() <= 0) { _status = FlattenStatus.ConfirmedFlat; return _status; }
            IssueFlatten();
            return _status;
        }

        /// <summary>
        /// Advance one poll interval. Confirms flat the moment zero contracts are observed;
        /// re-issues a flatten once a flatten has had time to settle and is still open; gives
        /// up (so the caller alerts + stays connected) after exhausting attempts / the hard cap.
        /// </summary>
        public FlattenStatus Tick()
        {
            if (_status != FlattenStatus.Running) return _status;

            // The ONLY way to ConfirmedFlat: actually observe zero open contracts.
            if (_openContracts() <= 0) { _status = FlattenStatus.ConfirmedFlat; return _status; }

            _totalPolls++;
            if (_totalPolls >= _maxTotalPolls) { _status = FlattenStatus.GaveUp; return _status; }

            // A prior flatten's orders are still working — let them fill; never double-submit.
            if (_closeOrdersPending != null && _closeOrdersPending()) return _status;

            _pollsSinceFlatten++;
            if (_pollsSinceFlatten >= _settlePolls)
            {
                if (_attempts < _maxFlattenAttempts) IssueFlatten();
                else                                 _status = FlattenStatus.GaveUp;
            }
            return _status;
        }

        private void IssueFlatten()
        {
            _attempts++;
            _pollsSinceFlatten = 0;
            try { _flatten(); } catch { /* the live caller logs; a throw must not stall the machine */ }
        }
    }
}
