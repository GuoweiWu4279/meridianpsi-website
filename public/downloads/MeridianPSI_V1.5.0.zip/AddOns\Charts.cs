using System;
using System.Collections.Generic;
using System.Globalization;
using System.Windows;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Lightweight WPF chart primitives drawn with DrawingContext. PURE WPF
    /// (no NinjaTrader types) so they render offline in the UI harness AND
    /// inside NinjaTrader. Each is a FrameworkElement that fills its width and
    /// draws in OnRender, so it is responsive (no hard-coded pixel width).
    /// </summary>

    /// <summary>Line + soft area chart with optional threshold gridlines and end markers.</summary>
    internal sealed class SparkAreaChart : FrameworkElement
    {
        public IList<double> Values;
        public double MinY = double.NaN, MaxY = double.NaN;   // auto when NaN
        public Brush Stroke;
        public double[] Thresholds;                            // horizontal guide lines
        public bool ShowMarkers;
        public bool ShowZeroLine;
        public double ChartHeight = 130;

        protected override Size MeasureOverride(Size available)
            => new Size(double.IsInfinity(available.Width) ? 320 : available.Width, ChartHeight);

        protected override void OnRender(DrawingContext dc)
        {
            double w = ActualWidth, h = ActualHeight;
            if (w <= 2 || h <= 2 || Values == null || Values.Count < 2) return;

            double min = double.IsNaN(MinY) ? MinOf(Values) : MinY;
            double max = double.IsNaN(MaxY) ? MaxOf(Values) : MaxY;
            if (max - min < 1e-6) max = min + 1;

            const double padT = 10, padB = 8;
            double XX(int i) => w * i / (double)(Values.Count - 1);
            double YY(double v) => padT + (h - padT - padB) * (1 - (v - min) / (max - min));

            var grid = new Pen(Theme.GridLine, 1); grid.Freeze();
            if (Thresholds != null)
                foreach (var th in Thresholds)
                    if (th >= min && th <= max)
                        dc.DrawLine(grid, new Point(0, YY(th)), new Point(w, YY(th)));

            if (ShowZeroLine && min < 0 && max > 0)
            {
                var zp = new Pen(Theme.BorderStrong, 1); zp.Freeze();
                dc.DrawLine(zp, new Point(0, YY(0)), new Point(w, YY(0)));
            }

            var stroke = Stroke ?? Theme.Accent;
            var c = Theme.ColorOf(stroke);

            // soft area fill (stroke color → transparent)
            var lg = new LinearGradientBrush { StartPoint = new Point(0, 0), EndPoint = new Point(0, 1) };
            lg.GradientStops.Add(new GradientStop(Color.FromArgb(56, c.R, c.G, c.B), 0));
            lg.GradientStops.Add(new GradientStop(Color.FromArgb(0, c.R, c.G, c.B), 1));
            lg.Freeze();

            var fig = new PathFigure { StartPoint = new Point(0, h - padB) };
            for (int i = 0; i < Values.Count; i++)
                fig.Segments.Add(new LineSegment(new Point(XX(i), YY(Values[i])), false));
            fig.Segments.Add(new LineSegment(new Point(w, h - padB), false));
            fig.IsClosed = true;
            var geo = new PathGeometry(); geo.Figures.Add(fig); geo.Freeze();
            dc.DrawGeometry(lg, null, geo);

            var pen = new Pen(stroke, 1.8) { LineJoin = PenLineJoin.Round, StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
            pen.Freeze();
            for (int i = 0; i < Values.Count - 1; i++)
                dc.DrawLine(pen, new Point(XX(i), YY(Values[i])), new Point(XX(i + 1), YY(Values[i + 1])));

            if (ShowMarkers)
                for (int i = 0; i < Values.Count; i++)
                    dc.DrawEllipse(Theme.BgWindow, pen, new Point(XX(i), YY(Values[i])), 2.6, 2.6);
        }

        private static double MinOf(IList<double> v) { double m = v[0]; foreach (var x in v) if (x < m) m = x; return m; }
        private static double MaxOf(IList<double> v) { double m = v[0]; foreach (var x in v) if (x > m) m = x; return m; }
    }

    internal sealed class ScatterDot { public string Label; public double Pnl; public double Disc; public int Size; public bool Win; public Brush Color; }

    /// <summary>
    /// Discipline × Outcome quadrant scatter. X = P&L (loss←0→profit),
    /// Y = discipline (rule-break bottom, disciplined top), bubble size = contracts.
    /// Each trade is a dot — makes the matrix self-explanatory.
    /// </summary>
    internal sealed class QuadrantScatter : FrameworkElement
    {
        public IList<ScatterDot> Dots;
        public double ChartHeight = 230;

        protected override Size MeasureOverride(Size available)
            => new Size(double.IsInfinity(available.Width) ? 320 : available.Width, ChartHeight);

        protected override void OnRender(DrawingContext dc)
        {
            double w = ActualWidth, h = ActualHeight;
            if (w <= 2 || h <= 2 || Dots == null || Dots.Count == 0) return;

            double maxAbs = 1;
            foreach (var d in Dots) maxAbs = Math.Max(maxAbs, Math.Abs(d.Pnl));
            maxAbs *= 1.2;

            const double padL = 10, padR = 10, padT = 22, padB = 22;
            double X(double pnl) => padL + (w - padL - padR) * ((pnl + maxAbs) / (2 * maxAbs));
            double Y(double disc) => padT + (h - padT - padB) * (1 - disc);

            // quadrant cross
            var gl = new Pen(Theme.GridLine, 1); gl.Freeze();
            double xZero = X(0);
            dc.DrawLine(gl, new Point(xZero, padT - 6), new Point(xZero, h - padB + 6));
            double yMid = padT + (h - padT - padB) * 0.5;
            dc.DrawLine(gl, new Point(0, yMid), new Point(w, yMid));

            // corner labels (muted)
            Label(dc, "EARNED",   w - padR, padT - 4, true,  false);
            Label(dc, "VARIANCE", padL,     padT - 4, false, false);
            Label(dc, "LUCK",     w - padR, h - padB + 14, true,  true);
            Label(dc, "SPIRAL",   padL,     h - padB + 14, false, true);

            // axis hints
            AxisHint(dc, "LOSS", padL, yMid - 7, false);
            AxisHint(dc, "PROFIT", w - padR, yMid - 7, true);

            foreach (var d in Dots)
            {
                double r = 6 + Math.Min(20, d.Size * 1.4);
                // Color encodes DISCIPLINE QUALITY (not raw P&L), so a lucky
                // rule-break reads as a warning, not a reassuring green dot.
                var col = d.Color ?? (d.Win ? Theme.Good : Theme.Bad);
                var cc = Theme.ColorOf(col);
                var fill = new SolidColorBrush(Color.FromArgb(70, cc.R, cc.G, cc.B)); fill.Freeze();
                var pen = new Pen(col, 1.6); pen.Freeze();
                var p = new Point(X(d.Pnl), Y(d.Disc));
                dc.DrawEllipse(fill, pen, p, r, r);

                var ft = Text(d.Label, 12, Theme.FgPrimary, true);
                dc.DrawText(ft, new Point(p.X - ft.Width / 2, p.Y - ft.Height / 2));
            }
        }

        private void Label(DrawingContext dc, string s, double x, double y, bool right, bool bottom)
        {
            var ft = Text(s, 10, Theme.FgHint, true);
            double px = right ? x - ft.Width : x;
            double py = bottom ? y - ft.Height : y;
            dc.DrawText(ft, new Point(px, py));
        }

        private void AxisHint(DrawingContext dc, string s, double x, double y, bool right)
        {
            var ft = Text(s, 9, Theme.FgHint, false);
            dc.DrawText(ft, new Point(right ? x - ft.Width : x, y));
        }

        private static FormattedText Text(string s, double size, Brush b, bool bold)
        {
            return new FormattedText(s, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
                new Typeface(Theme.Font, FontStyles.Normal, bold ? FontWeights.Bold : FontWeights.Normal, FontStretches.Normal),
                size, b, 1.0);
        }
    }

    /// <summary>
    /// The danger visual: one risk bar measured against the trader's daily-loss
    /// limit. The portion past the limit line is bright red — "one trade carried
    /// more risk than your whole day's budget." Conveys "made money BUT dangerous"
    /// at a glance, with the limit breach as the focal point.
    /// </summary>
    internal sealed class RiskVsLimitChart : FrameworkElement
    {
        public double Risk;
        public double Limit;
        public double ChartHeight = 74;

        protected override Size MeasureOverride(Size available)
            => new Size(double.IsInfinity(available.Width) ? 320 : available.Width, ChartHeight);

        protected override void OnRender(DrawingContext dc)
        {
            double w = ActualWidth, h = ActualHeight;
            if (w <= 2 || h <= 2 || Risk <= 0 || Limit <= 0) return;

            double scale = Math.Max(Risk, Limit) * 1.24;
            const double rightPad = 104, top = 26, barH = 26;
            double axW = w - rightPad;
            double X(double v) => axW * (v / scale);

            double xLimit = X(Limit), xRisk = X(Risk);

            // track
            Round(dc, 0, top, axW, barH, Argb(14, 255, 255, 255));
            // within-limit (muted red)
            Round(dc, 0, top, Math.Min(xLimit, xRisk), barH, Argb(150, 240, 86, 78));
            // over-limit (bright red)
            if (Risk > Limit) Round(dc, xLimit, top, xRisk - xLimit, barH, Argb(255, 255, 84, 74));

            // daily-limit marker
            var pen = new Pen(Theme.FgPrimary, 1.5) { DashStyle = new DashStyle(new double[] { 3, 2 }, 0) };
            pen.Freeze();
            dc.DrawLine(pen, new Point(xLimit, top - 12), new Point(xLimit, top + barH + 8));

            Label(dc, "Daily limit $" + Limit.ToString("0"), xLimit + 5, top - 15, Theme.FgHint, 11, true);
            Label(dc, "$" + Risk.ToString("0") + " at risk", xRisk + 9, top + barH / 2 - 9, Theme.Bad, 14, true);
            Label(dc, (100.0 * Risk / Limit).ToString("0") + "% of your limit", xRisk + 9, top + barH / 2 + 7, Theme.FgSecondary, 11, false);
        }

        private static void Round(DrawingContext dc, double x, double y, double width, double height, Brush b)
        {
            if (width <= 0) return;
            dc.DrawRoundedRectangle(b, null, new Rect(x, y, width, height), 5, 5);
        }

        private static void Label(DrawingContext dc, string s, double x, double y, Brush b, double size, bool bold)
        {
            var ft = new FormattedText(s, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
                new Typeface(Theme.Font, FontStyles.Normal, bold ? FontWeights.Bold : FontWeights.Normal, FontStretches.Normal),
                size, b, 1.0);
            dc.DrawText(ft, new Point(x, y));
        }

        private static Brush Argb(byte a, byte r, byte g, byte b)
        {
            var br = new SolidColorBrush(Color.FromArgb(a, r, g, b)); br.Freeze(); return br;
        }
    }
}
