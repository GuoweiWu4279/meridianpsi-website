using System;
using System.Collections.Generic;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>One auto-surfaced finding from the insight engine.</summary>
    internal sealed class ProgressInsight
    {
        public string Title;
        public string Detail;
        public Brush  Accent;   // small severity dot color
    }

    /// <summary>One calendar day.</summary>
    internal sealed class ProgressDay
    {
        public int      Day;
        public bool     HasSession;
        public double   Composure;  // 0..100 (drives the day's dot color — discipline, not P&L)
        public bool     IsToday;
        public DateTime Date;       // full date — lets a click open that day's full report
        public double   Pnl;        // session P&L (hover tooltip)
        public int      Trades;     // session trade count (hover tooltip)
        public double   FinalPsi;   // session final PSI (hover tooltip); <0 = unknown
    }

    /// <summary>One row in the recent-sessions table.</summary>
    internal sealed class ProgressSession
    {
        public DateTime Date;
        public double   Composure;  // 0..100
        public double   Pnl;
    }

    /// <summary>
    /// Pure data model for Progress (the ANSWER-layer "am I getting better?" surface).
    /// Curated: hero edge-share trend + a few KPIs + auto-surfaced insights + calendar.
    /// The full breadth lives in EXPLORE, not here.
    /// </summary>
    internal sealed class ProgressData
    {
        public string MonthLabel;       // "June 2026"
        public string Headline;         // "Your edge is starting to show."
        public string HeadlineSub;

        public int    Sessions;
        public double AvgComposure;     // 0..100
        public double MonthPnl;
        public double EdgeShareNow;     // 0..100 (% of profit from disciplined trading)
        public double EdgeSharePrev;    // last month, for the trend note

        public List<double> EdgeShareSeries = new List<double>();   // weekly edge % (fills in as size-tracked sessions accrue)
        public List<double> ComposureSeries = new List<double>();   // recent session composure % (always available)
        public List<ProgressInsight> Insights = new List<ProgressInsight>();

        public int BrokeDown;           // sessions this month with composure < 55
        public List<ProgressSession> RecentSessions = new List<ProgressSession>();  // newest first

        public int FirstBlank;          // leading empty cells before day 1 (Mon-first)
        public List<ProgressDay> Days = new List<ProgressDay>();
    }
}
