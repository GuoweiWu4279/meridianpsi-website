using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Central design tokens — single source of truth for color, spacing, type,
    /// radius. PURE WPF (no NinjaTrader types) so any view built on it renders
    /// offline in the UI harness AND inside NinjaTrader.
    ///
    /// Anchored on the shadcn/ui DARK theme (official tokens, ui.shadcn.com/docs/theming):
    /// near-black canvas, FLAT card surfaces lifted by a hairline white-alpha border
    /// (no gradient, no heavy shadow), off-white text, ONE green accent, and semantic
    /// colours from shadcn's colourblind-aware chart palette. Radius 10. (Design approved
    /// 2026-06 after researching Refactoring UI + shadcn; replaces the old "crisp" attempt.)
    /// </summary>
    internal static class Theme
    {
        // ── Surfaces (shadcn dark) ────────────────────────────────────────
        // Canvas #0a0a0a, cards a clear step lighter, depth via a VISIBLE white-alpha
        // hairline border (NOT a gradient, NOT a shadow — shadcn is flat + bordered).
        public static readonly Brush BgWindow    = Rgb(9, 9, 11);      // zinc-950  #09090b (brand base)
        public static readonly Brush BgCard       = Rgb(22, 22, 25);    // card       #161619
        public static readonly Brush BgCardTop    = Rgb(27, 27, 31);    // card-2     #1b1b1f
        public static readonly Brush BgElevated   = Rgb(27, 27, 31);    // inner cell #1b1b1f
        public static readonly Brush BgHeader     = Rgb(15, 15, 18);    // nav/topbar #0f0f12
        public static readonly Brush BgSubtle     = Argb(10, 255, 255, 255);
        // Soft white-alpha hairline (NOT a hard gray line). Reads as a gentle top-light
        // edge on the card; depth now comes from elevation (fill + a faint shadow), not
        // from a drawn outline. This is the single biggest "de-sharpen" lever.
        public static readonly Brush Border       = Argb(18, 255, 255, 255);  // ~7% white, soft edge
        public static readonly Brush BorderStrong = Argb(34, 255, 255, 255);  // ~13% white, for chips
        public static readonly Brush HairlineTop  = Argb(10, 255, 255, 255);

        // Minimal shadow (shadcn cards are flat; depth is the border). Used only for popovers.
        public static readonly Color ShadowColor = Color.FromArgb(120, 0, 0, 0);

        // Card material — FLAT solid (was a gradient). Kept as a token so every existing
        // reference (incl. the hub's BgCard) renders the new flat shadcn card automatically.
        public static readonly Brush CardGradient = Rgb(22, 22, 25);          // card #161619 (flat)
        public static readonly Brush GridLine     = Argb(13, 255, 255, 255);

        // ── Text (shadcn) ─────────────────────────────────────────────────
        public static readonly Brush FgPrimary    = Rgb(250, 250, 250);  // --foreground        #fafafa
        public static readonly Brush FgSecondary  = Rgb(180, 180, 189);  // readable secondary #b4b4bd
        public static readonly Brush FgHint        = Rgb(118, 118, 127);  // labels #76767f

        // ── Accent + semantic (shadcn chart palette — colourblind-aware) ──
        public static readonly Brush Accent       = Rgb(16, 185, 129);   // emerald-500 #10b981 (brand accent, tuned deeper than the site's -400 so it reads "comfortable" not neon on the dense dark UI)
        public static readonly Brush AccentSolid  = Rgb(16, 185, 129);   // filled-button emerald
        public static readonly Brush Accent2      = Rgb(110, 231, 183);  // emerald-300 #6ee7b7
        public static readonly Brush AccentDeep   = Rgb(5, 150, 105);    // emerald-600 #059669
        public static readonly Brush AccentInk    = Rgb(4, 20, 13);      // text ON the emerald button
        public static readonly Brush Good          = Rgb(16, 185, 129);   // gain
        public static readonly Brush Bad           = Rgb(226, 86, 78);    // loss #e2564e (controlled red, not pink)
        public static readonly Brush Info          = Rgb(124, 131, 255);  // #7c83ff (chart-1, lightened)

        // zone ramp (PSI chart / day chips): Stable → Caution → Warning → Critical
        public static readonly Brush Stable        = Rgb(16, 185, 129);   // emerald
        public static readonly Brush Caution       = Rgb(215, 181, 73);   // #d7b549
        public static readonly Brush Warning       = Rgb(224, 162, 60);   // #e0a23c
        public static readonly Brush Critical      = Rgb(226, 86, 78);    // #e2564e

        // ── Spacing scale ─────────────────────────────────────────────────
        public const double S1 = 4, S2 = 8, S3 = 12, S4 = 16, S5 = 24, S6 = 32, S7 = 48;

        // ── Type scale ────────────────────────────────────────────────────
        public const double TCaption = 11, TBody = 13.5, TSubhead = 15, TTitle = 22, THeadline = 27, TDisplay = 36;
        // Inter (shadcn's typeface) when installed on the machine, else Segoe UI.
        public static readonly FontFamily Font = new FontFamily("Inter, Segoe UI");

        // ── Radius scale ──  small/inputs 10 · buttons/cells 13 · cards 18.
        // Bigger, VISIBLE radii (was 7/8/10, which read square on large cards). Pills are
        // fully rounded separately in Ui.Pill. Soft corners are core to the calm look.
        public const double R1 = 10, R2 = 13, R3 = 18;

        /// <summary>Zone brush for a PSI value.</summary>
        public static Brush Zone(double psi)
            => psi >= 88 ? Stable : psi >= 72 ? Caution : psi >= 55 ? Warning : Critical;

        public static Color ColorOf(Brush b) => (b as SolidColorBrush)?.Color ?? Colors.Gray;

        /// <summary>A subtle tinted fill of a status colour (shadcn badge style): the hue
        /// at low alpha on the dark surface — NOT a candy pastel.</summary>
        public static Brush Tint(Brush b, byte alpha = 30)
        {
            var c = ColorOf(b);
            var br = new SolidColorBrush(Color.FromArgb(alpha, c.R, c.G, c.B)); br.Freeze(); return br;
        }

        private static Brush Rgb(byte r, byte g, byte b)
        {
            var br = new SolidColorBrush(Color.FromRgb(r, g, b)); br.Freeze(); return br;
        }
        private static Brush Argb(byte a, byte r, byte g, byte b)
        {
            var br = new SolidColorBrush(Color.FromArgb(a, r, g, b)); br.Freeze(); return br;
        }
    }
}
