// TradeMonitorHub.cs
//
// Unified dashboard window that consolidates Session Report, History,
// Trading Profile, and Settings into a single tabbed interface with
// a sidebar navigation panel.
//
// Content for each page is produced by the existing standalone Window
// classes (SessionReportWindow, HistoryWindow, BaselineWindow) via a
// "content transplant" pattern: the window is instantiated but never
// shown, its body content is extracted and placed into the Hub's
// content area.  This eliminates code duplication while keeping
// all existing visual and behavioral code intact.

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal enum HubPage { Session, History, Profile, Settings, License, Guard, Intelligence, Journal }

    internal sealed class MeridianDashboard : Window
    {
        // ── Window layout persistence ──────────────────────────────────────────
        // Saves/restores Left, Top, Width, Height across NT8 restarts.
        // Stored as a tiny XML file in TradeMonitorData/ (same data directory
        // as other add-on files; injected via SetDataDir at startup).

        private static string _hubDataDir;
        internal static void SetDataDir(string path)
        {
            if (!string.IsNullOrEmpty(path)) _hubDataDir = path;
        }

        private static string LayoutFilePath =>
            System.IO.Path.Combine(_hubDataDir ?? "", "layout.xml");

        private static bool TryLoadLayout(out double left, out double top,
                                          out double width, out double height)
        {
            left = top = width = height = double.NaN;
            try
            {
                if (string.IsNullOrEmpty(_hubDataDir) || !File.Exists(LayoutFilePath))
                    return false;

                var text = File.ReadAllText(LayoutFilePath);
                // Parse minimal XML: <Layout Left="…" Top="…" Width="…" Height="…" />
                left   = ParseAttr(text, "Left");
                top    = ParseAttr(text, "Top");
                width  = ParseAttr(text, "Width");
                height = ParseAttr(text, "Height");

                // Sanity-check: must be on-screen and a reasonable size.
                var area = SystemParameters.VirtualScreenWidth;
                if (double.IsNaN(left) || double.IsNaN(top) ||
                    double.IsNaN(width) || double.IsNaN(height)) return false;
                if (width < 400 || height < 380) return false;
                if (left < -200 || top < -200) return false;
                if (left > SystemParameters.VirtualScreenWidth  - 100) return false;
                if (top  > SystemParameters.VirtualScreenHeight - 60)  return false;
                return true;
            }
            catch { return false; }
        }

        private static double ParseAttr(string xml, string attr)
        {
            string marker = attr + "=\"";
            int start = xml.IndexOf(marker, StringComparison.Ordinal);
            if (start < 0) return double.NaN;
            start += marker.Length;
            int end = xml.IndexOf('"', start);
            if (end < 0) return double.NaN;
            double v;
            return double.TryParse(xml.Substring(start, end - start),
                System.Globalization.NumberStyles.Float,
                System.Globalization.CultureInfo.InvariantCulture, out v) ? v : double.NaN;
        }

        private static void SaveLayout(double left, double top, double width, double height)
        {
            try
            {
                if (string.IsNullOrEmpty(_hubDataDir)) return;
                Directory.CreateDirectory(_hubDataDir);
                var ic = System.Globalization.CultureInfo.InvariantCulture;
                string xml = string.Format(ic,
                    "<Layout Left=\"{0:F1}\" Top=\"{1:F1}\" Width=\"{2:F1}\" Height=\"{3:F1}\" />",
                    left, top, width, height);
                File.WriteAllText(LayoutFilePath, xml);
            }
            catch { }
        }

        // ── Events ───────────────────────────────────────────────────────────
        public event Action        BaselineResetRequested;
        public event Action        HistoryClearRequested;
        public event Action        SettingsRequested;

        // ── Data references (shared with TradeMonitor) ───────────────────────
        private TradeBaseline       _baseline;
        private StrategyProfile     _profile;
        private SessionHistoryStore _historyStore;
        private SessionData         _sessionData;
        private List<string>        _availableAccounts;
        private Func<List<string>>  _accountsProvider;
        private Action<string>      _onError;
        private LicenseManager      _licenseManager;
        private string              _updateVersion;
        private string              _updateNotes;
        private GuardEngine         _guardEngine;
        private MeridianPSI         _monitor;   // for Emergency Override callback

        // ── Page state ───────────────────────────────────────────────────────
        private HubPage  _currentPage = HubPage.Session;
        private readonly Grid       _contentArea;
        private readonly Border[]    _navBorders = new Border[8];
        private readonly TextBlock[] _navLabels  = new TextBlock[8];
        private readonly System.Windows.Shapes.Path[] _navIcons = new System.Windows.Shapes.Path[8];

        /// <summary>
        /// True when the current license grants access to the Guard-tier feature
        /// (the Guard rules engine — the ONLY paid feature; everything else,
        /// including PSI Intelligence, is Core).
        ///
        /// FAIL-CLOSED: when _licenseManager is null (only possible in tests /
        /// dev harnesses), Guard-tier features are LOCKED.  Production never
        /// passes a null license manager.  See LicenseManager.HasGuard for the
        /// authoritative tier-resolution logic, including the Plan C 7-day
        /// Core→Guard sampling window for new subscribers.
        /// </summary>
        private bool HasGuardAccess => _licenseManager?.HasGuard ?? false;

        // Keep reference to BaselineWindow for ResetRequested event
        private BaselineWindow _embeddedBaselineWindow;

        // ── Palette ──────────────────────────────────────────────────────────
        private static readonly Brush BgWindow     = Theme.BgWindow;
        private static readonly Brush BgSidebar    = new SolidColorBrush(Color.FromRgb( 22,  22,  24));
        private static readonly Brush BgHeader     = new SolidColorBrush(Color.FromRgb( 44,  44,  46));
        private static readonly Brush BgNavActive  = new SolidColorBrush(Color.FromArgb( 30, 255, 255, 255));
        private static readonly Brush BgNavHover   = new SolidColorBrush(Color.FromArgb( 18, 255, 255, 255));
        // Aligned to the central Theme tokens so every v1 page color-matches the v2 design.
        private static readonly Brush FgPrimary    = Theme.FgPrimary;
        private static readonly Brush FgSecondary  = Theme.FgSecondary;
        private static readonly Brush FgHint       = Theme.FgHint;
        private static readonly Brush FgAccent     = Theme.Accent;
        private static readonly Brush BgCard       = Theme.CardGradient;  // top-lit material, not flat

        // Freeze all static brushes so they can be used from any thread.
        // NT8 may call State.Active (which accesses TradeMonitorHub.SetDataDir) on a
        // worker thread, triggering the static initializer there.  Unfrozen WPF
        // Freezables created on a worker thread cannot be used on the UI thread.
        static MeridianDashboard()
        {
            ((SolidColorBrush)BgWindow  ).Freeze();
            ((SolidColorBrush)BgSidebar ).Freeze();
            ((SolidColorBrush)BgHeader  ).Freeze();
            ((SolidColorBrush)BgNavActive).Freeze();
            ((SolidColorBrush)BgNavHover).Freeze();
            ((SolidColorBrush)FgPrimary ).Freeze();
            ((SolidColorBrush)FgSecondary).Freeze();
            ((SolidColorBrush)FgHint    ).Freeze();
            ((SolidColorBrush)FgAccent  ).Freeze();
            // BgCard is now a LinearGradientBrush (top-lit card material) — freeze it as a
            // generic Freezable, NOT via a SolidColorBrush cast (that cast threw an
            // InvalidCastException in the static ctor → the whole dashboard failed to open).
            if (BgCard.CanFreeze && !BgCard.IsFrozen) BgCard.Freeze();
        }

        // Nav icons \u2014 Lucide geometry (verified on the harness), indexed by HubPage:
        // Session, Patterns, Profile, Settings, License, Guard, Intel, Journal.
        private static readonly Geometry[] NavGeoms = { Icons.Dashboard, Icons.Chart, Icons.User, Icons.Settings, Icons.Key, Icons.Shield, Icons.Sparkles, Icons.Pen };
        private static readonly string[] NavLabels = { "Overview", "Patterns", "Profile", "Settings", "License", "Guard", "Intel", "Journal" };

        // =====================================================================
        // Constructor
        // =====================================================================

        public MeridianDashboard(TradeBaseline baseline,
                               StrategyProfile profile,
                               SessionHistoryStore historyStore,
                               SessionData sessionData,
                               List<string> availableAccounts,
                               Action<string> onError,
                               LicenseManager licenseManager = null,
                               string updateVersion = null,
                               string updateNotes   = null,
                               GuardEngine guardEngine = null,
                               MeridianPSI monitor = null,
                               Func<List<string>> accountsProvider = null)
        {
            _baseline          = baseline      ?? new TradeBaseline();
            _profile           = profile       ?? new StrategyProfile();
            _historyStore      = historyStore  ?? new SessionHistoryStore();
            _sessionData       = sessionData;
            _availableAccounts = availableAccounts ?? new List<string>();
            _accountsProvider  = accountsProvider;
            _onError           = onError;
            _licenseManager    = licenseManager;
            _updateVersion     = updateVersion;
            _updateNotes       = updateNotes;
            _guardEngine       = guardEngine;
            _monitor           = monitor;

            WindowStyle        = WindowStyle.None;
            AllowsTransparency = true;
            Background         = Brushes.Transparent;
            ResizeMode         = ResizeMode.CanResizeWithGrip;
            ShowInTaskbar      = true;
            Title              = "Meridian Dashboard";
            Width    = 1380;   // open big enough for the dense multi-column dashboard
            Height   = 880;
            MinWidth = 1180;   // floor — below this the 2/3-col layouts clip; WPF clamps any
            MinHeight= 720;    // smaller saved layout up to this, so it can never get cramped
                               // (720 also fits a 1366x768 laptop after the taskbar)


            // Restore last position/size if available; otherwise centre on screen.
            double savedL, savedT, savedW, savedH;
            if (TryLoadLayout(out savedL, out savedT, out savedW, out savedH))
            {
                Left   = savedL;
                Top    = savedT;
                Width  = savedW;
                Height = savedH;
            }
            else
            {
                Left = (SystemParameters.WorkArea.Width  - Width)  / 2;
                Top  = (SystemParameters.WorkArea.Height - Height) / 2;
            }

            // ── Outer card ─────────────────────────────────────────────────────
            var card = new Border
            {
                CornerRadius    = new CornerRadius(14),
                Background      = BgWindow,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };

            var rootGrid = new Grid();
            rootGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(44) });
            rootGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // ── Header ─────────────────────────────────────────────────────────
            var header = BuildHeader();
            Grid.SetRow(header, 0);
            rootGrid.Children.Add(header);

            // ── Body: sidebar + content ────────────────────────────────────────
            var bodyGrid = new Grid();
            bodyGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(140) });
            bodyGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1) });
            bodyGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Sidebar
            var sidebar = BuildSidebar();
            Grid.SetColumn(sidebar, 0);
            bodyGrid.Children.Add(sidebar);

            // Separator line
            var sep = new Border
            {
                Width      = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
            };
            Grid.SetColumn(sep, 1);
            bodyGrid.Children.Add(sep);

            // Content area
            _contentArea = new Grid { Background = Brushes.Transparent };
            Grid.SetColumn(_contentArea, 2);
            bodyGrid.Children.Add(_contentArea);

            Grid.SetRow(bodyGrid, 1);
            rootGrid.Children.Add(bodyGrid);

            card.Child = rootGrid;
            Content    = card;

            // ── Show initial page ──────────────────────────────────────────────
            Closed += OnHubWindowClosed;

            // Dev: if a RENDER_UI sentinel exists, snapshot every page to PNG once
            // the window has laid out (so Claude can review the full UI offline).
            Loaded += (s, e) => TryRenderAllPagesForPreview();

            // Open to Session page always; NavigateTo handles the license gate
            // (non-activated users see the Activate gate page on Session).
            NavigateTo(HubPage.Session);
        }

        // ── Offline-render preview hooks (used by the UI harness, never by NT8) ──
        /// <summary>Navigate to a page for offline rendering.</summary>
        internal void PreviewNavigate(HubPage page) => NavigateTo(page);
        /// <summary>The window's root visual (the outer card) for offline rendering.</summary>
        internal FrameworkElement PreviewRoot => Content as FrameworkElement;

        // ── In-NT8 page renderer ─────────────────────────────────────────────
        // Standalone rendering is impossible (NinjaTrader.Core/Gui are AgileDotNet-
        // obfuscated; their runtime only initialises inside NinjaTrader.exe).  So we
        // render INSIDE NT8 instead: on Dashboard load, if a `RENDER_UI` sentinel
        // file exists in the data dir, snapshot every page to ui-renders/*.png so the
        // whole UI can be reviewed offline from the PNGs.  No-op without the sentinel.
        private void TryRenderAllPagesForPreview()
        {
            try
            {
                string dir = _hubDataDir;
                if (string.IsNullOrEmpty(dir) ||
                    !System.IO.File.Exists(System.IO.Path.Combine(dir, "RENDER_UI")))
                    return;

                string outDir = System.IO.Path.Combine(dir, "ui-renders");
                System.IO.Directory.CreateDirectory(outDir);

                var root = Content as FrameworkElement;
                if (root == null) return;
                double w = ActualWidth  > 1 ? ActualWidth  : Width;
                double h = ActualHeight > 1 ? ActualHeight : Height;

                var pages = new[]
                {
                    HubPage.Session, HubPage.History, HubPage.Profile, HubPage.Settings,
                    HubPage.License, HubPage.Guard, HubPage.Intelligence, HubPage.Journal,
                };
                foreach (var pg in pages)
                {
                    try
                    {
                        NavigateTo(pg);
                        root.UpdateLayout();
                        var rtb = new System.Windows.Media.Imaging.RenderTargetBitmap(
                            (int)w, (int)h, 96, 96, System.Windows.Media.PixelFormats.Pbgra32);
                        rtb.Render(root);
                        var enc = new System.Windows.Media.Imaging.PngBitmapEncoder();
                        enc.Frames.Add(System.Windows.Media.Imaging.BitmapFrame.Create(rtb));
                        using (var fs = System.IO.File.Create(
                            System.IO.Path.Combine(outDir, "dash-" + pg + ".png")))
                            enc.Save(fs);
                    }
                    catch { /* skip the odd page that fails; render the rest */ }
                }
                NavigateTo(HubPage.Session);   // restore the user's view
            }
            catch { /* rendering must never disrupt the live Dashboard */ }
        }

        private void OnHubWindowClosed(object sender, EventArgs e)
        {
            // Persist window geometry for next session.
            SaveLayout(Left, Top, Width, Height);
            TeardownEmbeddedBaseline();
            _contentArea?.Children.Clear();
        }

        /// <summary>
        /// Unhook embedded page objects so they are not leaked after the visual tree
        /// is torn down.  BaselineWindow subscribes to <see cref="BaselineResetRequested"/>.
        /// </summary>
        private void TeardownEmbeddedBaseline()
        {
            if (_embeddedBaselineWindow == null) return;
            _embeddedBaselineWindow.ResetRequested -= OnEmbeddedBaselineReset;
            _embeddedBaselineWindow = null;
        }

        // =====================================================================
        // Header
        // =====================================================================

        private Border BuildHeader()
        {
            var bg = new Border { Background = BgHeader };
            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            // Brand wordmark now lives at the top of the sidebar; the header stays a clean
            // drag bar with just the close button.

            var closeBtn = MakeHeaderBtn("\u2715", "Close dashboard");
            closeBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; Close(); };
            Grid.SetColumn(closeBtn, 1);
            grid.Children.Add(closeBtn);

            bg.Child = grid;

            bg.MouseLeftButtonDown += (_, e) =>
            {
                if (!e.Handled && e.ButtonState == MouseButtonState.Pressed)
                    DragMove();
            };

            return bg;
        }

        private static Border MakeHeaderBtn(string glyph, string tooltip)
        {
            var lbl = new TextBlock
            {
                Text                = glyph,
                FontSize            = 14,
                Foreground          = FgSecondary,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Width     = 40,
                Height    = 40,
                Background = Brushes.Transparent,
                Cursor    = Cursors.Hand,
                Child     = lbl,
                ToolTip   = tooltip,
                VerticalAlignment = VerticalAlignment.Center,
            };
            btn.MouseEnter += (_, __) => btn.Background = BgNavHover;
            btn.MouseLeave += (_, __) => btn.Background = Brushes.Transparent;
            return btn;
        }

        // =====================================================================
        // Sidebar
        // =====================================================================

        private Border BuildSidebar()
        {
            var bg    = new Border { Background = BgSidebar };
            var stack = new StackPanel { Margin = new Thickness(0, 6, 0, 0) };

            // Brand wordmark at the top of the sidebar (fail-safe: if the embedded logo
            // can't decode, nothing is added and the nav still works).
            try
            {
                var logoSrc = MeridianLogo.Dark();
                if (logoSrc != null)
                {
                    var logo = new System.Windows.Controls.Image
                    {
                        Source              = logoSrc,
                        Width               = 100,
                        Stretch             = System.Windows.Media.Stretch.Uniform,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        Margin              = new Thickness(0, 8, 0, 18),
                        SnapsToDevicePixels = true,
                    };
                    System.Windows.Media.RenderOptions.SetBitmapScalingMode(logo, System.Windows.Media.BitmapScalingMode.HighQuality);
                    stack.Children.Add(logo);
                }
            }
            catch { }

            // Grouped by the discipline loop + frequency (UX_DESIGN_ROOT.md §2.10).
            // Intel (6) is a full analytics page — keep it as a first-class REVIEW nav
            // item (restored: consolidating it into a buried link read as "a feature
            // disappeared"). Arrays are null-guarded so any slot is safe to add/skip.
            AddNavGroup(stack, "Today",  new[] { 0, 5, 7 }, isFirst: true);   // Session, Guard, Journal
            AddNavGroup(stack, "Review", new[] { 1, 6 },    isFirst: false);  // Patterns, Intel
            AddNavGroup(stack, "Setup",  new[] { 2, 3, 4 }, isFirst: false);  // Profile, Settings, License

            bg.Child = stack;
            return bg;
        }

        // Builds a labelled group of nav items inside the sidebar.
        // pageIndices contains HubPage int values in desired display order.
        private void AddNavGroup(StackPanel stack, string groupLabel, int[] pageIndices, bool isFirst)
        {
            if (!isFirst)
            {
                stack.Children.Add(new Border
                {
                    Height     = 1,
                    Background = new SolidColorBrush(Color.FromArgb(25, 255, 255, 255)),
                    Margin     = new Thickness(12, 8, 12, 0),
                });
            }

            stack.Children.Add(new TextBlock
            {
                Text       = groupLabel,
                FontSize   = 8,
                FontFamily = Theme.Font,
                FontWeight = FontWeights.Bold,
                Foreground = FgHint,
                Margin     = new Thickness(16, isFirst ? 6 : 10, 0, 2),
            });

            foreach (int i in pageIndices)
            {
                int idx = i;
                var navItem = BuildNavItem(NavGeoms[i], NavLabels[i], (HubPage)i,
                                           out var border, out var icon, out var lbl);
                _navBorders[i] = border;
                _navIcons[i]   = icon;
                _navLabels[i]  = lbl;

                bool isGated = !(_licenseManager?.IsFunctional ?? true) && (HubPage)i != HubPage.License
                    || (i == 5 && !HasGuardAccess);
                if (isGated)
                {
                    var badge = new Border
                    {
                        Background    = i == 5 && !HasGuardAccess
                            ? new SolidColorBrush(Color.FromArgb(180, 230, 165, 90))   // amber GUARD badge
                            : new SolidColorBrush(Color.FromArgb(160, 120, 120, 120)), // grey LOCK badge
                        CornerRadius  = new CornerRadius(3),
                        Padding       = new Thickness(3, 1, 3, 1),
                        Margin        = new Thickness(4, 0, 0, 0),
                        VerticalAlignment = VerticalAlignment.Center,
                        Child         = new TextBlock
                        {
                            Text       = i == 5 && !HasGuardAccess ? "Guard" : "🔒",
                            FontSize   = 7,
                            FontFamily = Theme.Font,
                            FontWeight = FontWeights.Bold,
                            Foreground = new SolidColorBrush(Color.FromRgb(28, 28, 30)),
                        },
                    };
                    var row = (StackPanel)((Border)navItem).Child;
                    row.Children.Add(badge);
                }

                navItem.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    NavigateTo((HubPage)idx);
                };
                stack.Children.Add(navItem);
            }
        }

        private static Border BuildNavItem(Geometry icon, string label, HubPage page,
                                           out Border borderRef, out System.Windows.Shapes.Path iconRef, out TextBlock labelRef)
        {
            var iconPath = Icons.Make(icon, 17, FgHint, 1.8);
            iconPath.HorizontalAlignment = HorizontalAlignment.Center;
            iconPath.VerticalAlignment   = VerticalAlignment.Center;
            var iconBox = new Border { Width = 26, Child = iconPath };

            var labelTb = new TextBlock
            {
                Text              = label,
                FontSize          = 13,
                FontFamily        = Theme.Font,
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(9, 0, 0, 0),
            };

            var row = new StackPanel
            {
                Orientation       = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(10, 0, 8, 0),
            };
            row.Children.Add(iconBox);
            row.Children.Add(labelTb);

            var border = new Border
            {
                Height          = 38,
                Background      = Brushes.Transparent,
                Cursor          = Cursors.Hand,
                Child           = row,
                Margin          = new Thickness(6, 1, 6, 1),
                CornerRadius    = new CornerRadius(8),
            };
            border.MouseEnter += (_, __) =>
            {
                if (border.Tag as string != "active")
                    border.Background = BgNavHover;
            };
            border.MouseLeave += (_, __) =>
            {
                if (border.Tag as string != "active")
                    border.Background = Brushes.Transparent;
            };

            Ui.WireLift(border, 1.5);   // subtle hover-lift micro-interaction
            borderRef = border;
            iconRef   = iconPath;
            labelRef  = labelTb;
            return border;
        }

        private void UpdateNavHighlight(HubPage page)
        {
            int idx = (int)page;
            for (int i = 0; i < 8; i++)
            {
                // A nav item may not be built (e.g. Intel, merged into Patterns and dropped
                // from the sidebar). Skip un-built slots so highlighting never NREs — this is
                // why the whole dashboard failed to open after the nav was consolidated.
                if (_navBorders[i] == null || _navIcons[i] == null || _navLabels[i] == null)
                    continue;
                bool active = i == idx;
                _navBorders[i].Background = active ? BgNavActive : Brushes.Transparent;
                _navBorders[i].Tag        = active ? "active" : null;
                _navIcons[i].Stroke       = active ? FgAccent : FgHint;
                _navLabels[i].Foreground  = active ? FgPrimary : FgSecondary;

                _navLabels[i].FontWeight  = active ? FontWeights.SemiBold : FontWeights.Normal;
            }
        }

        // Removes stale 🔒 lock badges from nav items after activation.
        // Called whenever license status changes to Licensed.
        private void RefreshNavBadges()
        {
            bool licensed = _licenseManager?.IsFunctional ?? true;
            for (int i = 0; i < 8; i++)
            {
                if ((HubPage)i == HubPage.License) continue;
                bool isGuardGated = i == 5 && !HasGuardAccess;
                if (isGuardGated) continue; // GUARD badge stays

                var row = _navBorders[i]?.Child as StackPanel;
                if (row == null) continue;

                // Remove any grey 🔒 lock badge (Badge has a Border child with TextBlock "🔒").
                if (licensed)
                {
                    for (int j = row.Children.Count - 1; j >= 0; j--)
                    {
                        if (row.Children[j] is Border badge
                            && badge.Child is TextBlock tb
                            && tb.Text == "🔒")
                        {
                            row.Children.RemoveAt(j);
                        }
                    }
                }
            }
        }

        // =====================================================================
        // Navigation
        // =====================================================================

        /// <summary>
        /// Reloads the shared SessionHistoryStore from disk in-place.
        /// Updates Sessions on the existing object so the Hub and TradeMonitor
        /// (which share the same reference) both see the new data immediately.
        /// Must be called on the UI thread.
        /// </summary>
        private void ReloadHistoryStore()
        {
            var fresh = SessionHistoryStore.LoadFromFile(_onError);
            _historyStore.Sessions.Clear();
            _historyStore.Sessions.AddRange(fresh.Sessions);
        }

        public void NavigateTo(HubPage page)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.InvokeAsync(() => NavigateTo(page));
                return;
            }

            bool isFunctional = _licenseManager?.IsFunctional ?? true;

            TeardownEmbeddedBaseline();
            _currentPage = page;
            CallbackRecorder.UiEvent("nav", "open", page.ToString()); // anonymous: which tab, + dwell via timestamps
            UpdateNavHighlight(page);

            _contentArea.Children.Clear();

            FrameworkElement content;
            // Safety net: any page that throws during build falls back to a placeholder
            // instead of crashing navigation / the dashboard. Protects the restructured tabs.
            try
            {
            switch (page)
            {
                case HubPage.Session:
                    content = !isFunctional ? BuildActivateGatePage()
                            : UiV2On()       ? CreateDebriefPage()
                                             : CreateSessionPage();
                    break;
                case HubPage.History:
                    content = !isFunctional ? BuildActivateGatePage()
                            : UiV2On()       ? CreateProgressV2Page()
                                             : CreateHistoryPage();
                    break;
                case HubPage.Profile:
                    content = isFunctional ? CreateProfilePage() : BuildActivateGatePage();
                    break;
                case HubPage.Settings:
                    content = isFunctional ? CreateSettingsPage() : BuildActivateGatePage();
                    break;
                case HubPage.License:
                    content = CreateLicensePage();
                    break;
                case HubPage.Guard:
                    content = !isFunctional ? BuildActivateGatePage()
                            : HasGuardAccess  ? CreateGuardPage()
                                              : BuildGuardUpgradePage();
                    break;
                case HubPage.Intelligence:
                    content = isFunctional ? CreateIntelligencePage() : BuildActivateGatePage();
                    break;
                case HubPage.Journal:
                    content = isFunctional ? CreateJournalPage() : BuildActivateGatePage();
                    break;
                default:
                    content = new TextBlock { Text = "Unknown page", Foreground = FgPrimary };
                    break;
            }
            }
            catch (Exception pageEx)
            {
                System.Diagnostics.Debug.WriteLine("[Hub] page build failed (" + page + "): " + pageEx.Message);
                content = new TextBlock
                {
                    Text              = "This view hit an error and was skipped — the rest of the dashboard is fine.",
                    Foreground        = FgSecondary,
                    FontFamily        = Theme.Font,
                    FontSize          = 13,
                    Margin            = new Thickness(24),
                    TextWrapping      = TextWrapping.Wrap,
                };
            }

            // Entrance: fade + slide-up the incoming page (cosmetic; the animation holds at
            // fully-visible, so even if it no-ops the content is shown).
            content.Opacity = 0;
            var slideT = new TranslateTransform(0, 10);
            content.RenderTransform = slideT;
            _contentArea.Children.Add(content);
            content.BeginAnimation(UIElement.OpacityProperty,
                new System.Windows.Media.Animation.DoubleAnimation(0, 1, new Duration(TimeSpan.FromMilliseconds(260)))
                { EasingFunction = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut } });
            slideT.BeginAnimation(TranslateTransform.YProperty,
                new System.Windows.Media.Animation.DoubleAnimation(10, 0, new Duration(TimeSpan.FromMilliseconds(300)))
                { EasingFunction = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut } });
        }

        // =====================================================================
        // Public API — called from TradeMonitor
        // =====================================================================

        /// <summary>
        /// Refresh session data and rebuild the Session page if it's visible.
        /// </summary>
        public void UpdateSessionData(SessionData data)
        {
            _sessionData = data;
            if (_currentPage == HubPage.Session)
                NavigateTo(HubPage.Session);
        }

        /// <summary>
        /// Update data references after a baseline reset.
        /// </summary>
        public void UpdateDataRefs(TradeBaseline baseline, StrategyProfile profile)
        {
            _baseline = baseline;
            _profile  = profile;
            if (_currentPage == HubPage.Profile)
                NavigateTo(HubPage.Profile);
        }

        // =====================================================================
        // Page: Debrief (UI v2) — flag-gated, default OFF. Reuses the empty-state
        // and, on any error, falls back to the proven old Session page. Toggled by
        // a `UI_V2_DEBRIEF` sentinel in the data dir (never ships to customers).
        // =====================================================================

        // Master switch for the rebuilt UI. Default OFF (no sentinel → old pages).
        // Sentinel lives in the data dir and never ships to customers.
        private bool UiV2On()
            => !string.IsNullOrEmpty(_hubDataDir)
               && System.IO.File.Exists(System.IO.Path.Combine(_hubDataDir, "UI_V2"));

        private FrameworkElement CreateDebriefPage()
        {
            try
            {
                if (_sessionData == null || !_sessionData.HasRecordedTrades())
                    return CreatePreSessionPage();

                SessionData snap = _sessionData.CreateSnapshot();
                snap.Flush(DateTime.Now);
                DebriefData data = DebriefAdapter.FromSession(snap, _profile);
                FrameworkElement view = DebriefView.Build(data);

                // Body = the debrief + a small, COLLAPSED "PSI insight" the curious can
                // click open (restored: it was on the old Session page; kept tucked here
                // so it never competes with the clean truth-ledger above it).
                var scrollContent = new StackPanel();
                scrollContent.Children.Add(view);
                if (_monitor != null)
                    scrollContent.Children.Add(BuildPsiInsightCollapsible());

                var scroll = new ScrollViewer
                {
                    Content = scrollContent,
                    VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                    HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                };

                // Restored: "Copy Session Report" action (was dropped in the v2 swap).
                var dock = new DockPanel { LastChildFill = true };
                var bar  = BuildPageActionBar("⎘  Copy Session Report",
                    () => { try { new SessionReportWindow(snap).CopySummaryToClipboard(); } catch { } });
                DockPanel.SetDock(bar, Dock.Top);
                dock.Children.Add(bar);
                dock.Children.Add(scroll);
                return dock;
            }
            catch
            {
                // Safety net: never break the dashboard — fall back to the old page.
                try { return CreateSessionPage(); } catch { return BuildSessionEmptyPage(); }
            }
        }

        // A small, collapsed-by-default "PSI insight" disclosure for the Debrief: the
        // engine-detail panel from the old Session page, tucked behind one click so the
        // curious can open it without it cluttering the clean report.
        private FrameworkElement BuildPsiInsightCollapsible()
        {
            var outer = new StackPanel { Margin = new Thickness(14, 6, 14, 12) };

            var panel = BuildPsiInsightSection(_monitor.GetPsiInsightSnapshot());
            panel.Visibility = Visibility.Collapsed;

            var caret = new TextBlock { Text = "▸", FontSize = 11, Foreground = FgHint, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0) };
            var head  = new TextBlock { Text = "PSI insight — engine detail", FontSize = 11, FontFamily = Theme.Font, FontWeight = FontWeights.SemiBold, Foreground = FgHint, VerticalAlignment = VerticalAlignment.Center };
            var headRow = new StackPanel { Orientation = Orientation.Horizontal, Cursor = Cursors.Hand, Margin = new Thickness(0, 0, 0, 4) };
            headRow.Children.Add(caret); headRow.Children.Add(head);
            headRow.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                bool show = panel.Visibility != Visibility.Visible;
                panel.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
                caret.Text = show ? "▾" : "▸";
            };
            headRow.MouseEnter += (_, __) => { head.Foreground = FgSecondary; caret.Foreground = FgSecondary; };
            headRow.MouseLeave += (_, __) => { head.Foreground = FgHint;       caret.Foreground = FgHint; };

            outer.Children.Add(headRow);
            outer.Children.Add(panel);
            return outer;
        }

        // Pre-Session brief (UI v2 pre-trade state). Read-only; reuses the
        // existing risk-brief engine. Falls back to the old empty state on error.
        // Pre-session ritual checklist — ticks live in memory and reset when the day rolls over.
        private readonly System.Collections.Generic.HashSet<string> _ritualDone = new System.Collections.Generic.HashSet<string>();
        private DateTime _ritualDate = DateTime.MinValue;

        private FrameworkElement CreatePreSessionPage()
        {
            try
            {
                PreSessionData data = PreSessionAdapter.From(_historyStore, _profile, DateTime.Now);
                if (_ritualDate.Date != DateTime.Today) { _ritualDone.Clear(); _ritualDate = DateTime.Today; }
                return new ScrollViewer
                {
                    Content = PreSessionView.Build(data, () => Hide(), _ritualDone,
                        item =>
                        {
                            if (_ritualDone.Contains(item)) _ritualDone.Remove(item); else _ritualDone.Add(item);
                        },
                        () =>   // + Add step — the user defines their own ritual
                        {
                            string step = PromptForText("Add a pre-session step", "");
                            if (!string.IsNullOrWhiteSpace(step)) { RitualStore.Add(step); NavigateTo(HubPage.Session); }
                        },
                        item => // ✕ remove a step
                        {
                            RitualStore.Remove(item);
                            _ritualDone.Remove(item);
                            NavigateTo(HubPage.Session);
                        },
                        () => NavigateTo(HubPage.Intelligence),   // "Open Intel →" on the trend card
                        OpenLatestDebrief,                          // "Yesterday's lesson" date link
                        () => NavigateTo(HubPage.History)),         // "worst days" on the wrecks card
                    VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                    HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                };
            }
            catch { return BuildSessionEmptyPage(); }
        }

        // "Yesterday's lesson" → open the most recent session's debrief. If its detail
        // archive isn't on disk, fall back to History so the click is never a no-op.
        private void OpenLatestDebrief()
        {
            DateTime latest = DateTime.MinValue;
            var ss = _historyStore?.Sessions;
            if (ss != null)
                foreach (var s in ss) if (s != null && s.Date > latest) latest = s.Date;
            if (latest > DateTime.MinValue && SessionDetailStore.Exists(latest))
                OpenSessionReportFor(latest);
            else
                NavigateTo(HubPage.History);
        }

        // Minimal modal text prompt (WPF ships none). Returns the entered text, or null if cancelled.
        private string PromptForText(string title, string initial)
        {
            string result = null;
            var win = new Window
            {
                Title                 = title,
                Width                 = 420,
                SizeToContent         = SizeToContent.Height,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                ResizeMode            = ResizeMode.NoResize,
                WindowStyle           = WindowStyle.SingleBorderWindow,
                Background            = new SolidColorBrush(Color.FromRgb(20, 20, 22)),
                ShowInTaskbar         = false,
            };
            try { win.Owner = this; } catch { }

            var sp = new StackPanel { Margin = new Thickness(18) };
            sp.Children.Add(new TextBlock { Text = title, Foreground = FgPrimary, FontFamily = Theme.Font, FontSize = 14, FontWeight = FontWeights.SemiBold, Margin = new Thickness(0, 0, 0, 10) });
            var tb = new TextBox
            {
                Text            = initial ?? "",
                FontFamily      = Theme.Font,
                FontSize        = 13,
                Padding         = new Thickness(10, 7, 10, 7),
                Background      = BgCard,
                Foreground      = FgPrimary,
                CaretBrush      = FgPrimary,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255)),
                BorderThickness = new Thickness(1),
            };
            sp.Children.Add(tb);
            var btnRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 14, 0, 0) };
            var cancel = BuildSimpleButton("Cancel", accent: false);
            var ok     = BuildSimpleButton("Add",    accent: true);
            cancel.Margin = new Thickness(0, 0, 8, 0);
            cancel.Click += (_, __) => win.Close();
            ok.Click     += (_, __) => { result = tb.Text; win.Close(); };
            tb.KeyDown   += (_, e) => { if (e.Key == Key.Enter) { result = tb.Text; win.Close(); } else if (e.Key == Key.Escape) win.Close(); };
            btnRow.Children.Add(cancel); btnRow.Children.Add(ok);
            sp.Children.Add(btnRow);
            win.Content = sp;
            tb.Loaded += (_, __) => { tb.Focus(); tb.SelectAll(); };
            win.ShowDialog();
            return result;
        }

        // Progress (UI v2 of the History page — History + Intelligence merged).
        // Read-only; real composure trend + calendar + KPIs. Falls back to the
        // old History page on error.
        private DateTime _progressMonth = DateTime.MinValue;   // which month History is showing

        private FrameworkElement CreateProgressV2Page()
        {
            try
            {
                var today    = DateTime.Today;
                var curMonth = new DateTime(today.Year, today.Month, 1);
                if (_progressMonth < new DateTime(2000, 1, 1)) _progressMonth = curMonth;
                if (_progressMonth > curMonth) _progressMonth = curMonth;

                // Floor prev-nav at the earliest recorded session's month (or 5 years back).
                var floor = curMonth.AddYears(-5);
                var sessions = _historyStore?.Sessions;
                if (sessions != null && sessions.Count > 0)
                {
                    DateTime earliest = curMonth;
                    foreach (var s in sessions) if (s != null && s.Date < earliest) earliest = s.Date;
                    floor = new DateTime(earliest.Year, earliest.Month, 1);
                }
                bool canGoPrev = _progressMonth > floor;
                bool canGoNext = _progressMonth < curMonth;

                ProgressData data = ProgressAdapter.FromHistory(_historyStore, _profile, _progressMonth, today);
                return new ScrollViewer
                {
                    Content = ProgressView.Build(data,
                        () => NavigateTo(HubPage.Intelligence),
                        OpenSessionReportFor,
                        () => { if (_progressMonth > floor)    { _progressMonth = _progressMonth.AddMonths(-1); NavigateTo(HubPage.History); } },
                        () => { if (_progressMonth < curMonth) { _progressMonth = _progressMonth.AddMonths(1);  NavigateTo(HubPage.History); } },
                        canGoPrev, canGoNext, ExportHistoryCsv),
                    VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                    HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                };
            }
            catch { return CreateHistoryPage(); }
        }

        // Export ALL recorded sessions to CSV (restored data-portability feature).
        private void ExportHistoryCsv()
        {
            try
            {
                var sessions = _historyStore?.Sessions;
                if (sessions == null || sessions.Count == 0) return;
                var dlg = new Microsoft.Win32.SaveFileDialog
                {
                    FileName = "meridian-history-" + DateTime.Today.ToString("yyyy-MM-dd") + ".csv",
                    Filter   = "CSV files (*.csv)|*.csv",
                    Title    = "Export session history",
                };
                if (dlg.ShowDialog() != true) return;

                var inv = System.Globalization.CultureInfo.InvariantCulture;
                var sb  = new System.Text.StringBuilder();
                sb.AppendLine("Date,Composure%,FinalPSI,Trades,Wins,WinRate%,NetPnL,D1_Revenge,D2_StopMgmt,D3_Size,D4_Hold,D5_Overstay,D6_RuleBreak,D7_Overtrade");
                var ordered = new List<SessionHistoryEntry>(sessions);
                ordered.Sort((a, b) => a.Date.CompareTo(b.Date));
                foreach (var s in ordered)
                {
                    if (s == null) continue;
                    sb.AppendLine(string.Join(",",
                        s.Date.ToString("yyyy-MM-dd", inv),
                        s.ComposurePct.ToString(inv),
                        s.FinalPsi.ToString("0.0", inv),
                        s.TotalTrades.ToString(inv),
                        s.WinTrades.ToString(inv),
                        s.WinPct.ToString("0.0", inv),
                        s.TotalPnl.ToString("0.00", inv),
                        s.D1.ToString("0.000", inv), s.D2.ToString("0.000", inv), s.D3.ToString("0.000", inv),
                        s.D4.ToString("0.000", inv), s.D5.ToString("0.000", inv), s.D6.ToString("0.000", inv), s.D7.ToString("0.000", inv)));
                }
                System.IO.File.WriteAllText(dlg.FileName, sb.ToString());
            }
            catch { }
        }

        // Open the full SessionReportWindow for a past day (Progress calendar click).
        // Only days with a Tier-2 detail archive can be fully reconstructed; others no-op.
        private void OpenSessionReportFor(DateTime date)
        {
            try
            {
                if (_historyStore?.Sessions == null) return;
                SessionHistoryEntry entry = null;
                foreach (var s in _historyStore.Sessions)
                    if (s != null && s.Date.Date == date.Date) { entry = s; break; }
                if (entry == null) return;
                if (!SessionDetailStore.Exists(entry.Date)) return;
                var detail = SessionDetailStore.Load(entry.Date);
                if (detail == null) return;
                var sd = SessionData.FromArchive(entry, detail);
                sd.Flush(sd.Date);
                new SessionReportWindow(sd).Show();
            }
            catch { }
        }

        // =====================================================================
        // Page: Session Report
        // =====================================================================

        private FrameworkElement CreateSessionPage()
        {
            if (_sessionData == null || !_sessionData.HasRecordedTrades())
                return BuildSessionEmptyPage();

            try
            {
                // Point-in-time copy: timer + execution threads mutate live SessionData.
                SessionData snap = _sessionData.CreateSnapshot();
                // Commit the current zone's pending time slice into the snapshot so
                // Time-in-State is accurate when the report is opened mid-session.
                snap.Flush(DateTime.Now);
                var source = new SessionReportWindow(snap);
                var body   = TransplantWindowBody(source);

                var dock = new DockPanel { LastChildFill = true };
                var bar  = BuildPageActionBar("⎘  Copy Session Report",
                    () => source.CopySummaryToClipboard(),
                    "Intel →",
                    () => NavigateTo(HubPage.Intelligence));
                DockPanel.SetDock(bar, Dock.Top);
                dock.Children.Add(bar);

                // ── PSI Insight — scrolls WITH the session report body ────────
                // SessionReportWindow's body still contains an inner ScrollViewer.
                // Disabling its scrollbars is not enough: WPF's ScrollViewer still
                // handles PreviewMouseWheel and swallows the bubble, so the outer
                // Hub ScrollViewer only reacted when the cursor was on the scrollbar.
                // Hoist the inner Content (StackPanel) directly into the Grid so one
                // outer ScrollViewer owns all vertical mouse-wheel scrolling.
                if (body is Border bodyCard && bodyCard.Child is Grid bodyGrid)
                {
                    for (int i = 0; i < bodyGrid.Children.Count; i++)
                    {
                        if (bodyGrid.Children[i] is ScrollViewer sv &&
                            sv.Content is UIElement innerContent)
                        {
                            int row = Grid.GetRow(sv);
                            sv.Content = null;
                            bodyGrid.Children.RemoveAt(i);
                            bodyGrid.Children.Add(innerContent);
                            Grid.SetRow(innerContent, row);
                            break;
                        }
                    }
                }

                var outerScroll = new ScrollViewer
                {
                    VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                    HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                };
                var scrollContent = new StackPanel();
                if (_monitor != null)
                    scrollContent.Children.Add(BuildPsiInsightSection(_monitor.GetPsiInsightSnapshot()));
                scrollContent.Children.Add(body);
                outerScroll.Content = scrollContent;

                dock.Children.Add(outerScroll);
                return dock;
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load session report.");
            }
        }

        // =====================================================================
        // BuildPsiInsightSection — v2 engine observability, rendered compactly
        // at the top of the Session page.  All data is passed in; no engine
        // references held.  Layout:
        //
        //   ┌─ PSI INSIGHT ─────────────────────────────────────────────┐
        //   │  PSI 82.4    P 0.34 (peak 0.71)    Class A events: 2      │
        //   │                                                          │
        //   │  Peak severity per dim (cumulative PSI-points cost):     │
        //   │    Revenge 0.0   SL Move 12.3  Size 0.0   Hold 4.1 ...   │
        //   │                                                          │
        //   │  Rule events (newest at bottom):                         │
        //   │    09:31:22  D2·SL Move [A]  E+=3.00  P=0.42             │
        //   │    09:32:05  D6·Rules   [A]  E+=3.50  P=0.55             │
        //   └──────────────────────────────────────────────────────────┘
        // =====================================================================
        private FrameworkElement BuildPsiInsightSection(PsiInsightSnapshot s)
        {
            var card = new Border
            {
                Background    = BgCard,
                CornerRadius  = new CornerRadius(8),
                Margin        = new Thickness(14, 4, 14, 6),
                Padding       = new Thickness(14, 10, 14, 12),
            };
            var stack = new StackPanel();
            card.Child = stack;

            var header = new StackPanel { Orientation = Orientation.Horizontal };
            header.Children.Add(new TextBlock
            {
                Text       = "PSI insight",
                FontSize   = 10,
                FontFamily = Theme.Font,
                FontWeight = FontWeights.Bold,
                Foreground = FgSecondary,
                Margin     = new Thickness(0, 0, 6, 0),
            });
            stack.Children.Add(header);

            // KPI row — single horizontal panel, three groups.
            var kpiRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 8, 0, 2),
            };
            kpiRow.Children.Add(MakeKpi("PSI",
                string.Format("{0:F1}", s.CurrentPsi), FgPrimary,
                "Psychological Stability Index (0–100)."));
            kpiRow.Children.Add(MakeKpi("Pressure",
                string.Format("{0:F2}", s.CurrentPressure),
                PressureBrush(s.CurrentPressure),
                "Stress context (0–1). Amplifies behaviour evidence and slows PSI recovery while high."));
            kpiRow.Children.Add(MakeKpi("Peak P",
                string.Format("{0:F2}", s.PeakPressure),
                PressureBrush(s.PeakPressure),
                "Highest Pressure reached this session (0–1)."));
            kpiRow.Children.Add(MakeKpi("Class A",
                s.ClassACommitCount.ToString(),
                s.ClassACommitCount > 0
                    ? (Brush)new SolidColorBrush(Color.FromRgb(242, 129, 138))
                    : FgPrimary,
                "Count of hard rule breaks you declared (Class A commits) this session."));
            stack.Children.Add(kpiRow);

            // Peak severity per dim — a compact grid of dim name + peak C_i.
            stack.Children.Add(new TextBlock
            {
                Text       = "Highest stress per rule (this session, PSI points):",
                FontSize   = 10,
                FontFamily = Theme.Font,
                Foreground = FgSecondary,
                Margin     = new Thickness(0, 10, 0, 2),
            });
            stack.Children.Add(new TextBlock
            {
                Text       = "Higher = that rule cost you more composure this session.",
                FontSize   = 9,
                FontFamily = Theme.Font,
                Foreground = FgHint,
                Margin     = new Thickness(0, 0, 0, 4),
                TextWrapping = TextWrapping.Wrap,
            });
            var sevGrid = new Grid();
            for (int c = 0; c < 7; c++)
                sevGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            string[] dimNames = PsiOverlayWindow.DimNamesStatic;
            for (int di = 0; di < 7; di++)
            {
                double peak = (s.PeakSeverityPerDim != null && s.PeakSeverityPerDim.Length > di + 1)
                    ? s.PeakSeverityPerDim[di + 1] : 0.0;
                CommitClass cls = (s.DimLastClass != null && s.DimLastClass.Length > di + 1)
                    ? s.DimLastClass[di + 1] : CommitClass.None;
                var cell = new StackPanel { Margin = new Thickness(2, 0, 2, 0) };
                cell.Children.Add(new TextBlock
                {
                    Text                = dimNames[di],
                    FontSize            = 9,
                    FontFamily          = Theme.Font,
                    Foreground          = DimNameBrush(cls),
                    HorizontalAlignment = HorizontalAlignment.Center,
                });
                cell.Children.Add(new TextBlock
                {
                    Text                = string.Format("{0:F1}", peak),
                    FontSize            = 12,
                    FontFamily          = Theme.Font,
                    FontWeight          = FontWeights.SemiBold,
                    Foreground          = peak >= 20.0
                                            ? new SolidColorBrush(Color.FromRgb(230, 165, 90))
                                            : FgPrimary,
                    HorizontalAlignment = HorizontalAlignment.Center,
                });
                Grid.SetColumn(cell, di);
                sevGrid.Children.Add(cell);
            }
            stack.Children.Add(sevGrid);

            // Recent commit log — last N events.
            stack.Children.Add(new TextBlock
            {
                Text       = s.RecentCommits != null && s.RecentCommits.Length > 0
                                ? string.Format("Rule events ({0}) — newest at bottom:", s.RecentCommits.Length)
                                : "No rule events logged this session yet.",
                FontSize   = 10,
                FontFamily = Theme.Font,
                Foreground = FgSecondary,
                Margin     = new Thickness(0, 10, 0, 2),
            });
            stack.Children.Add(new TextBlock
            {
                Text       = "[A] = hard rule break · [B] = behaviour pattern · E+ = evidence added · P = Pressure (0–1)",
                FontSize   = 9,
                FontFamily = Theme.Font,
                Foreground = FgHint,
                Margin     = new Thickness(0, 0, 0, 4),
                TextWrapping = TextWrapping.Wrap,
            });

            if (s.RecentCommits != null && s.RecentCommits.Length > 0)
            {
                var logBox = new Border
                {
                    Background   = new SolidColorBrush(Color.FromRgb(28, 28, 30)),
                    CornerRadius = new CornerRadius(4),
                    Padding      = new Thickness(8, 6, 8, 6),
                    MaxHeight    = 140,
                };
                var scroll = new ScrollViewer
                {
                    VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
                };
                var logStack = new StackPanel();
                scroll.Content = logStack;
                logBox.Child   = scroll;

                int show = Math.Min(s.RecentCommits.Length, 20);
                int from = s.RecentCommits.Length - show;
                for (int i = from; i < s.RecentCommits.Length; i++)
                {
                    var ev = s.RecentCommits[i];
                    string dimName = (ev.Dim - 1 >= 0 && ev.Dim - 1 < dimNames.Length)
                        ? dimNames[ev.Dim - 1] : ("D" + ev.Dim);
                    string kindStr = ev.Kind == CommitClass.A ? "A" : "B";
                    Brush  kindBr  = ev.Kind == CommitClass.A
                                        ? (Brush)new SolidColorBrush(Color.FromRgb(255,  69,  58))
                                        : (Brush)new SolidColorBrush(Color.FromRgb(255, 149,   0));
                    var line = new TextBlock
                    {
                        FontSize   = 11,
                        FontFamily = new FontFamily("Consolas"),
                        Foreground = FgPrimary,
                    };
                    line.Inlines.Add(new System.Windows.Documents.Run(
                        string.Format("{0:HH:mm:ss}  ", ev.Time)) { Foreground = FgHint });
                    line.Inlines.Add(new System.Windows.Documents.Run(
                        string.Format("D{0}·{1,-9} ", ev.Dim, dimName)));
                    line.Inlines.Add(new System.Windows.Documents.Run("[" + kindStr + "]")
                        { Foreground = kindBr, FontWeight = FontWeights.Bold });
                    line.Inlines.Add(new System.Windows.Documents.Run(
                        string.Format("  E+={0:F2}  P={1:F2}", ev.Amount, ev.Pressure)));
                    logStack.Children.Add(line);
                }
                stack.Children.Add(logBox);
            }
            return card;
        }

        private static Brush PressureBrush(double p)
        {
            if (p <= 0.30) return new SolidColorBrush(Color.FromRgb( 48, 209,  88));
            if (p <= 0.70) return new SolidColorBrush(Color.FromRgb(255, 214,  10));
            return               new SolidColorBrush(Color.FromRgb(255,  69,  58));
        }

        private static Brush DimNameBrush(CommitClass cls)
        {
            switch (cls)
            {
                case CommitClass.A: return new SolidColorBrush(Color.FromRgb(255,  69,  58));
                case CommitClass.B: return new SolidColorBrush(Color.FromRgb(255, 149,   0));
                default:            return new SolidColorBrush(Color.FromRgb(136, 136, 136));
            }
        }

        private FrameworkElement MakeKpi(string label, string value, Brush valueBrush, string toolTip = null)
        {
            var panel = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Margin      = new Thickness(0, 0, 22, 0),
            };
            if (!string.IsNullOrEmpty(toolTip))
                panel.ToolTip = toolTip;
            panel.Children.Add(new TextBlock
            {
                Text       = label,
                FontSize   = 9,
                FontFamily = Theme.Font,
                Foreground = FgHint,
            });
            panel.Children.Add(new TextBlock
            {
                Text       = value,
                FontSize   = 18,
                FontFamily = Theme.Font,
                FontWeight = FontWeights.SemiBold,
                Foreground = valueBrush,
            });
            return panel;
        }

        // =====================================================================
        // Guard Upgrade page — shown when a Core-tier user clicks a Guard feature
        // =====================================================================

        private FrameworkElement BuildGuardUpgradePage()
        {
            var outer = new Border
            {
                Background = new SolidColorBrush(Color.FromRgb(28, 28, 30)),
            };

            var center = new StackPanel
            {
                Orientation         = Orientation.Vertical,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
                MaxWidth            = 340,
                Margin              = new Thickness(32),
            };

            // Lock icon
            center.Children.Add(new TextBlock
            {
                Text                = "🔒",
                FontSize            = 40,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 16),
            });

            // Headline
            center.Children.Add(new TextBlock
            {
                Text                = "Guard Tier Required",
                FontSize            = 18,
                FontFamily          = Theme.Font,
                FontWeight          = FontWeights.Bold,
                Foreground          = new SolidColorBrush(Color.FromRgb(245, 245, 247)),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 8),
            });

            // Sub-headline
            center.Children.Add(new TextBlock
            {
                Text         = "Upgrade to Guard to unlock these features:",
                FontSize     = 12,
                FontFamily   = Theme.Font,
                Foreground   = new SolidColorBrush(Color.FromRgb(174, 174, 178)),
                TextWrapping = TextWrapping.Wrap,
                TextAlignment = TextAlignment.Center,
                Margin       = new Thickness(0, 0, 0, 20),
            });

            // Feature list
            string[] features =
            {
                "🛡  Guard System — rules that enforce themselves\n      (6 triggers · 5 action levels)",
                "🔒  Auto-flatten · trading pause · strict lock —\n      protection that acts the moment you can't",
            };
            foreach (var f in features)
            {
                center.Children.Add(new TextBlock
                {
                    Text         = f,
                    FontSize     = 11,
                    FontFamily   = Theme.Font,
                    Foreground   = new SolidColorBrush(Color.FromRgb(220, 220, 224)),
                    TextWrapping = TextWrapping.Wrap,
                    Margin       = new Thickness(0, 0, 0, 10),
                });
            }

            // Divider
            center.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                Margin     = new Thickness(0, 12, 0, 16),
            });

            // Price line
            center.Children.Add(new TextBlock
            {
                Text                = "$69.99 / month",
                FontSize            = 22,
                FontFamily          = Theme.Font,
                FontWeight          = FontWeights.Bold,
                Foreground          = new SolidColorBrush(Color.FromRgb(91, 201, 140)),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 4),
            });
            center.Children.Add(new TextBlock
            {
                Text                = "Cancel any time · Instant activation",
                FontSize            = 10,
                FontFamily          = Theme.Font,
                Foreground          = new SolidColorBrush(Color.FromRgb(99, 99, 102)),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 20),
            });

            // Upgrade button
            var upgradeBtn = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(16, 185, 129)),
                CornerRadius    = new CornerRadius(8),
                Padding         = new Thickness(28, 12, 28, 12),
                Cursor          = Cursors.Hand,
                HorizontalAlignment = HorizontalAlignment.Center,
                Child = new TextBlock
                {
                    Text       = "Upgrade to Guard  →",
                    FontSize   = 13,
                    FontFamily = Theme.Font,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = Theme.AccentInk,
                },
            };
            upgradeBtn.MouseEnter += (_, __) =>
                upgradeBtn.Background = new SolidColorBrush(Color.FromRgb(13, 160, 112));
            upgradeBtn.MouseLeave += (_, __) =>
                upgradeBtn.Background = new SolidColorBrush(Color.FromRgb(16, 185, 129));
            upgradeBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                try { System.Diagnostics.Process.Start(LicenseManager.GuardStoreUrl); } catch { }
            };
            center.Children.Add(upgradeBtn);

            // Already have a Guard key? → go to License tab
            var alreadyHaveKey = new Border
            {
                Padding = new Thickness(0, 14, 0, 0),
                Cursor  = Cursors.Hand,
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            var alreadyTb = new TextBlock
            {
                Text      = "Already purchased? Activate your key →",
                FontSize  = 10,
                FontFamily = Theme.Font,
                Foreground = new SolidColorBrush(Color.FromRgb(16, 185, 129)),
            };
            alreadyHaveKey.Child = alreadyTb;
            alreadyHaveKey.MouseEnter += (_, __) => alreadyTb.TextDecorations = TextDecorations.Underline;
            alreadyHaveKey.MouseLeave += (_, __) => alreadyTb.TextDecorations = null;
            alreadyHaveKey.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                NavigateTo(HubPage.License);
            };
            center.Children.Add(alreadyHaveKey);

            outer.Child = center;
            return outer;
        }

        // =====================================================================
        // Activate Gate page — shown for ALL pages when no valid license exists
        // =====================================================================

        private FrameworkElement BuildActivateGatePage()
        {
            var outer = new Border
            {
                Background  = BgCard,
                CornerRadius = new CornerRadius(10),
                Margin      = new Thickness(16),
            };

            var center = new StackPanel
            {
                VerticalAlignment   = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin = new Thickness(32, 40, 32, 40),
            };

            // Lock icon
            center.Children.Add(new TextBlock
            {
                Text                = "🔒",
                FontSize            = 48,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 16),
            });

            // Heading
            center.Children.Add(new TextBlock
            {
                Text                = "Activate to Unlock",
                FontSize            = 18,
                FontFamily          = Theme.Font,
                FontWeight          = FontWeights.Bold,
                Foreground          = FgPrimary,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 8),
            });

            center.Children.Add(new TextBlock
            {
                Text         = "Subscribe to access all features:",
                FontSize     = 12,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin       = new Thickness(0, 0, 0, 20),
                TextWrapping = TextWrapping.Wrap,
            });

            // Feature list
            string[] features =
            {
                "📊  Session Report — real-time PSI composure score",
                "📅  History — calendar view of every session",
                "🧠  Intel — monthly digest, weekday patterns & crash-trigger analysis",
                "✏️  Journal — emotion tags + trade notes",
                "⚙️  Profile & Settings — strategy configuration",
                "🛡  Guard — automated protection rules  (Guard tier)",
            };
            foreach (var f in features)
            {
                center.Children.Add(new TextBlock
                {
                    Text         = f,
                    FontSize     = 12,
                    FontFamily   = Theme.Font,
                    Foreground   = FgSecondary,
                    Margin       = new Thickness(0, 0, 0, 6),
                    TextWrapping = TextWrapping.Wrap,
                });
            }

            // Divider
            center.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 20, 0, 20),
            });

            // Price
            center.Children.Add(new TextBlock
            {
                Text                = "From $49.99 / month",
                FontSize            = 22,
                FontFamily          = Theme.Font,
                FontWeight          = FontWeights.Bold,
                Foreground          = new SolidColorBrush(Color.FromRgb(80, 200, 120)),
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 4),
            });
            center.Children.Add(new TextBlock
            {
                Text                = "Cancel any time · 7-day free trial",
                FontSize            = 11,
                FontFamily          = Theme.Font,
                Foreground          = FgHint,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 20),
            });

            // CTA button
            var ctaBtn = new Border
            {
                Background    = new SolidColorBrush(Color.FromRgb(30, 120, 220)),
                CornerRadius  = new CornerRadius(8),
                Padding       = new Thickness(24, 12, 24, 12),
                Cursor        = System.Windows.Input.Cursors.Hand,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin        = new Thickness(0, 0, 0, 16),
                Child         = new TextBlock
                {
                    Text       = "Get Started  →",
                    FontSize   = 14,
                    FontFamily = Theme.Font,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = FgPrimary,
                },
            };
            ctaBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                try { System.Diagnostics.Process.Start(LicenseManager.StoreUrl); } catch { }
            };
            center.Children.Add(ctaBtn);

            // Already purchased link
            var alreadyHaveKey = new Border
            {
                Cursor              = System.Windows.Input.Cursors.Hand,
                HorizontalAlignment = HorizontalAlignment.Center,
                Child = new TextBlock
                {
                    Text            = "Already purchased? Activate your key  →",
                    FontSize        = 12,
                    FontFamily      = Theme.Font,
                    Foreground      = FgAccent,
                    TextDecorations = TextDecorations.Underline,
                },
            };
            alreadyHaveKey.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                NavigateTo(HubPage.License);
            };
            center.Children.Add(alreadyHaveKey);

            outer.Child = center;
            return outer;
        }

        // =====================================================================
        // Page: History
        // =====================================================================

        private FrameworkElement CreateHistoryPage()
        {
            try
            {
                var source = new HistoryWindow(_historyStore);
                source.ViewTodayRequested    += () => NavigateTo(HubPage.Session);
                source.ViewJournalRequested  += date =>
                {
                    _journalDateShown = date.Date;
                    NavigateTo(HubPage.Journal);
                };
                source.ClearHistoryRequested += () =>
                {
                    ShowCountdownConfirmDialog(
                        "Clear All Session History",
                        "This permanently deletes every session record.\n\n" +
                        "Your trading baseline is separate and will not be affected.\n" +
                        "This action cannot be undone.",
                        20,
                        () =>
                        {
                            HistoryClearRequested?.Invoke();
                            NavigateTo(HubPage.History);
                        });
                };

                var dock = new DockPanel { LastChildFill = true };

                var bar = BuildPageActionBar(
                    "⎘  Copy Month Summary",
                    () => source.CopySummary(),
                    "Intel →",
                    () => NavigateTo(HubPage.Intelligence));
                DockPanel.SetDock(bar, Dock.Top);
                dock.Children.Add(bar);

                dock.Children.Add(TransplantWindowBody(source));

                return dock;
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load history.");
            }
        }

        // ── Thin action bar docked to the top of Session/History pages ─────────
        // Provides Copy actions that were lost when TransplantWindowBody stripped
        // the original window header.  Optional rightLabel/rightAction adds a
        // cross-navigation link on the right side.
        private static Border BuildPageActionBar(string label, Action onClick,
                                                  string rightLabel = null, Action rightAction = null)
        {
            var bar = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(38, 38, 40)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                BorderThickness = new Thickness(0, 0, 0, 1),
                Padding         = new Thickness(14, 6, 14, 6),
            };

            var barGrid = new Grid();
            barGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            barGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            // Left: copy button (optional — if label is null, left side is empty)
            if (label != null && onClick != null)
            {
                var btn = new Border
                {
                    Background        = Brushes.Transparent,
                    Cursor            = Cursors.Hand,
                    VerticalAlignment = VerticalAlignment.Center,
                };
                var lbl = new TextBlock
                {
                    Text              = label,
                    FontSize          = 11,
                    FontFamily        = Theme.Font,
                    Foreground        = FgSecondary,
                    VerticalAlignment = VerticalAlignment.Center,
                };
                btn.Child = lbl;
                btn.MouseEnter += (_, __) => lbl.Foreground = FgPrimary;
                btn.MouseLeave += (_, __) => lbl.Foreground = FgSecondary;
                btn.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    onClick?.Invoke();
                    string orig = lbl.Text;
                    lbl.Text = "✓  Copied!";
                    lbl.Foreground = new SolidColorBrush(Color.FromRgb(91, 201, 140));
                    var t = new System.Windows.Threading.DispatcherTimer
                        { Interval = TimeSpan.FromSeconds(2) };
                    t.Tick += (__, ___) =>
                    {
                        lbl.Text = orig;
                        lbl.Foreground = FgSecondary;
                        t.Stop();
                    };
                    t.Start();
                };
                Grid.SetColumn(btn, 0);
                barGrid.Children.Add(btn);
            }

            // Right: cross-nav link (optional)
            if (rightLabel != null && rightAction != null)
            {
                var linkTb = new TextBlock
                {
                    Text              = rightLabel,
                    FontSize          = 11,
                    FontFamily        = Theme.Font,
                    Foreground        = FgAccent,
                    VerticalAlignment = VerticalAlignment.Center,
                    Cursor            = Cursors.Hand,
                };
                var linkBorder = new Border
                {
                    Background        = Brushes.Transparent,
                    Cursor            = Cursors.Hand,
                    VerticalAlignment = VerticalAlignment.Center,
                    Child             = linkTb,
                };
                linkBorder.MouseEnter += (_, __) => linkTb.TextDecorations = TextDecorations.Underline;
                linkBorder.MouseLeave += (_, __) => linkTb.TextDecorations = null;
                linkBorder.MouseLeftButtonDown += (_, e) => { e.Handled = true; rightAction?.Invoke(); };
                Grid.SetColumn(linkBorder, 1);
                barGrid.Children.Add(linkBorder);
            }

            bar.Child = barGrid;
            return bar;
        }

        // ── Session page empty state: shows last recorded session summary ──────
        private FrameworkElement BuildSessionEmptyPage()
        {
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };

            var stack = new StackPanel
            {
                Margin              = new Thickness(20, 20, 20, 28),
                HorizontalAlignment = HorizontalAlignment.Stretch,
            };

            // ── Monitor-active status line ────────────────────────────────────
            var statusRow = new StackPanel
            {
                Orientation         = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 20),
            };
            var pulseDot = new System.Windows.Shapes.Ellipse
            {
                Width  = 7, Height = 7,
                Fill   = new SolidColorBrush(Color.FromRgb(91, 201, 140)),
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 7, 0),
            };
            statusRow.Children.Add(pulseDot);
            statusRow.Children.Add(new TextBlock
            {
                Text              = "Monitor active — waiting for today's first trade",
                FontSize          = 11,
                FontFamily        = Theme.Font,
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            });
            stack.Children.Add(statusRow);

            // ── Today's Risk Brief (inline from Intel engine) ─────────────────
            try
            {
                var sessions = _historyStore?.Sessions
                    .Where(s => s.TotalTrades > 0).ToList()
                    ?? new System.Collections.Generic.List<SessionHistoryEntry>();
                var brief = IntelligenceEngine.ComputeRiskBrief(sessions);

                var briefCard = new Border
                {
                    Background      = BgCard,
                    CornerRadius    = new CornerRadius(10),
                    Padding         = new Thickness(16, 12, 16, 14),
                    Margin          = new Thickness(0, 0, 0, 16),
                    BorderBrush     = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                    BorderThickness = new Thickness(1),
                };
                var briefStack = new StackPanel();

                // Header row: "TODAY'S RISK BRIEF" + risk badge
                var briefHeader = new Grid { Margin = new Thickness(0, 0, 0, 8) };
                briefHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                briefHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                briefHeader.Children.Add(new TextBlock
                {
                    Text              = "Today's risk brief",
                    FontSize          = 9,
                    FontFamily        = Theme.Font,
                    FontWeight        = FontWeights.Bold,
                    Foreground        = FgSecondary,
                    VerticalAlignment = VerticalAlignment.Center,
                });

                if (brief.HasEnoughData)
                {
                    Color riskColor = brief.RiskScore >= 70 ? Color.FromRgb(242, 129, 138)
                                    : brief.RiskScore >= 50 ? Color.FromRgb(255, 214, 0)
                                    : brief.RiskScore >= 30 ? Color.FromRgb(90, 200, 250)
                                    : Color.FromRgb(91, 201, 140);
                    var riskBadge = new Border
                    {
                        Background    = new SolidColorBrush(Color.FromArgb(40, riskColor.R, riskColor.G, riskColor.B)),
                        CornerRadius  = new CornerRadius(6),
                        Padding       = new Thickness(8, 3, 8, 3),
                        VerticalAlignment = VerticalAlignment.Center,
                        Child = new TextBlock
                        {
                            Text       = $"{brief.RiskLabel} Risk",
                            FontSize   = 10,
                            FontFamily = Theme.Font,
                            FontWeight = FontWeights.SemiBold,
                            Foreground = new SolidColorBrush(riskColor),
                        },
                    };
                    Grid.SetColumn(riskBadge, 1);
                    briefHeader.Children.Add(riskBadge);

                    // Risk factors
                    foreach (var f in brief.Factors)
                    {
                        Color fc   = f.IsGood ? Color.FromRgb(91, 201, 140)
                                   : f.Delta >= 15 ? Color.FromRgb(242, 129, 138)
                                   : Color.FromRgb(255, 214, 0);
                        string ico = f.IsGood ? "✓" : f.Delta >= 15 ? "⚠" : "·";
                        briefStack.Children.Add(new TextBlock
                        {
                            Text         = $"{ico}  {f.Reason}",
                            FontSize     = 11,
                            FontFamily   = Theme.Font,
                            Foreground   = new SolidColorBrush(fc),
                            TextWrapping = TextWrapping.Wrap,
                            Margin       = new Thickness(0, 3, 0, 0),
                        });
                    }

                    briefStack.Children.Add(new Border
                    {
                        Height     = 1,
                        Background = new SolidColorBrush(Color.FromArgb(22, 255, 255, 255)),
                        Margin     = new Thickness(0, 8, 0, 8),
                    });
                    briefStack.Children.Add(new TextBlock
                    {
                        Text         = brief.RecommendationText,
                        FontSize     = 11,
                        FontFamily   = Theme.Font,
                        Foreground   = FgSecondary,
                        TextWrapping = TextWrapping.Wrap,
                        FontStyle    = FontStyles.Italic,
                    });
                }
                else
                {
                    briefStack.Children.Add(new TextBlock
                    {
                        Text         = brief.RecommendationText,
                        FontSize     = 11,
                        FontFamily   = Theme.Font,
                        Foreground   = FgHint,
                        TextWrapping = TextWrapping.Wrap,
                        FontStyle    = FontStyles.Italic,
                    });
                }

                // "View full Intel →" link
                var intelLink = new Border
                {
                    Background = Brushes.Transparent,
                    Cursor     = Cursors.Hand,
                    Margin     = new Thickness(0, 10, 0, 0),
                    HorizontalAlignment = HorizontalAlignment.Right,
                };
                var intelTb = new TextBlock
                {
                    Text       = "Full analysis in Intel →",
                    FontSize   = 10,
                    FontFamily = Theme.Font,
                    Foreground = FgAccent,
                };
                intelLink.Child = intelTb;
                intelLink.MouseEnter += (_, __) => intelTb.TextDecorations = TextDecorations.Underline;
                intelLink.MouseLeave += (_, __) => intelTb.TextDecorations = null;
                intelLink.MouseLeftButtonDown += (_, e) => { e.Handled = true; NavigateTo(HubPage.Intelligence); };
                briefStack.Children.Add(intelLink);

                var briefInner = new StackPanel();
                briefInner.Children.Add(briefHeader);
                foreach (UIElement child in briefStack.Children)
                    briefInner.Children.Add(child);
                briefCard.Child = briefInner;
                stack.Children.Add(briefCard);
            }
            catch { /* If Intel data unavailable, skip Risk Brief silently */ }

            // ── "Meridian is watching" — the trader's active limits, so the wait
            //    state shows useful context instead of empty space. ───────────────
            try
            {
                var limits = new System.Collections.Generic.List<string>();
                if (_profile.MaxDailyLossUsd   > 0) limits.Add($"Daily loss limit  ${_profile.MaxDailyLossUsd:0}");
                if (_profile.PauseAfterNLosses > 0) limits.Add($"Pause after {_profile.PauseAfterNLosses} losses in a row");
                if (_profile.SizeMax           > 0) limits.Add($"Max size  {_profile.SizeMax:0.##} contracts");
                if (_profile.TradesPerSessionMax > 0) limits.Add($"Max {_profile.TradesPerSessionMax} trades this session");
                if (_profile.SessionWindowEnabled)  limits.Add($"Session  {_profile.SessionStartHour:00}:{_profile.SessionStartMinute:00}–{_profile.SessionEndHour:00}:{_profile.SessionEndMinute:00}");

                var watchCard = new Border
                {
                    Background      = BgCard,
                    CornerRadius    = new CornerRadius(10),
                    Padding         = new Thickness(16, 12, 16, 14),
                    Margin          = new Thickness(0, 0, 0, 16),
                    BorderBrush     = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                    BorderThickness = new Thickness(1),
                };
                var watchStack = new StackPanel();
                watchStack.Children.Add(new TextBlock
                {
                    Text = limits.Count > 0 ? "Meridian is watching" : "Set your limits",
                    FontSize = 9, FontFamily = Theme.Font, FontWeight = FontWeights.Bold,
                    Foreground = FgSecondary, Margin = new Thickness(0, 0, 0, 8),
                });
                if (limits.Count > 0)
                {
                    foreach (var ln in limits)
                        watchStack.Children.Add(new TextBlock
                        {
                            Text = "•  " + ln, FontSize = 12, FontFamily = Theme.Font,
                            Foreground = FgPrimary, Margin = new Thickness(0, 2, 0, 2),
                        });
                }
                else
                {
                    watchStack.Children.Add(new TextBlock
                    {
                        Text = "You haven't declared your limits yet. Meridian's strongest signals turn on once it knows your daily stop, size and pace.",
                        FontSize = 12, FontFamily = Theme.Font, Foreground = FgSecondary,
                        TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 2),
                    });
                }
                var setLink = new TextBlock
                {
                    Text = limits.Count > 0 ? "Adjust in Settings →" : "Set them in Settings →",
                    FontSize = 10, FontFamily = Theme.Font, Foreground = FgAccent,
                    Margin = new Thickness(0, 10, 0, 0), HorizontalAlignment = HorizontalAlignment.Right,
                    Cursor = Cursors.Hand,
                };
                setLink.MouseEnter += (_, __) => setLink.TextDecorations = TextDecorations.Underline;
                setLink.MouseLeave += (_, __) => setLink.TextDecorations = null;
                setLink.MouseLeftButtonDown += (_, e) => { e.Handled = true; NavigateTo(HubPage.Settings); };
                watchStack.Children.Add(setLink);

                watchCard.Child = watchStack;
                stack.Children.Add(watchCard);
            }
            catch { /* never break the page over a context card */ }

            // ── Last session card ─────────────────────────────────────────────
            var lastEntry = _historyStore?.ByDateDescending.FirstOrDefault();
            if (lastEntry != null)
            {
                stack.Children.Add(new TextBlock
                {
                    Text       = "Last session",
                    FontSize   = 9,
                    FontFamily = Theme.Font,
                    FontWeight = FontWeights.Bold,
                    Foreground = FgHint,
                    Margin     = new Thickness(0, 0, 0, 8),
                });

                var card = new Border
                {
                    Background      = BgCard,
                    CornerRadius    = new CornerRadius(10),
                    Padding         = new Thickness(16, 14, 16, 14),
                };

                Color zoneColor = lastEntry.FinalZone == PsiZone.Stable   ? Color.FromRgb( 48, 209,  88)
                                : lastEntry.FinalZone == PsiZone.Caution  ? Color.FromRgb(255, 214,   0)
                                :                                            Color.FromRgb(255,  69,  58);

                var cardStack = new StackPanel();

                // Date + zone badge row
                var dateRow = new Grid { Margin = new Thickness(0, 0, 0, 12) };
                dateRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                dateRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                dateRow.Children.Add(new TextBlock
                {
                    Text              = lastEntry.Date.ToString("dddd, MMMM d, yyyy"),
                    FontSize          = 13,
                    FontFamily        = Theme.Font,
                    FontWeight        = FontWeights.SemiBold,
                    Foreground        = FgPrimary,
                    VerticalAlignment = VerticalAlignment.Center,
                });

                var zoneBadge = new Border
                {
                    Background    = new SolidColorBrush(
                        Color.FromArgb(40, zoneColor.R, zoneColor.G, zoneColor.B)),
                    BorderBrush   = new SolidColorBrush(zoneColor),
                    BorderThickness = new Thickness(1),
                    CornerRadius  = new CornerRadius(10),
                    Padding       = new Thickness(8, 3, 8, 3),
                };
                zoneBadge.Child = new TextBlock
                {
                    Text       = lastEntry.FinalZone.ToString(),
                    FontSize   = 9,
                    FontFamily = Theme.Font,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = new SolidColorBrush(zoneColor),
                };
                Grid.SetColumn(zoneBadge, 1);
                dateRow.Children.Add(zoneBadge);
                cardStack.Children.Add(dateRow);

                // Stat tiles: PSI, P&L, Trades, Composure
                var statsGrid = new Grid();
                for (int i = 0; i < 4; i++)
                    statsGrid.ColumnDefinitions.Add(
                        new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

                string pnlStr = (lastEntry.TotalPnl >= 0 ? "+" : "-") + "$" +
                                Math.Abs(lastEntry.TotalPnl).ToString("0");
                Color  pnlCol = lastEntry.TotalPnl >= 0
                    ? Color.FromRgb(91, 201, 140) : Color.FromRgb(242, 129, 138);

                AddLastSessionStat(statsGrid, 0, "Final PSI",
                    lastEntry.FinalPsi.ToString("0"), zoneColor);
                AddLastSessionStat(statsGrid, 1, "P&L",
                    pnlStr, pnlCol);
                AddLastSessionStat(statsGrid, 2, "Trades",
                    lastEntry.TotalTrades.ToString(),
                    Color.FromRgb(245, 245, 247));
                AddLastSessionStat(statsGrid, 3, "Composure",
                    lastEntry.ComposurePct + "%",
                    // Canonical PSI zone bands (SessionData.ZoneOf — 88/72/55).
                    lastEntry.ComposurePct >= 88 ? Color.FromRgb(91, 201, 140)
                    : lastEntry.ComposurePct >= 72 ? Color.FromRgb(163, 213, 72)
                    : lastEntry.ComposurePct >= 55 ? Color.FromRgb(255, 214, 0)
                    : Color.FromRgb(242, 129, 138));
                cardStack.Children.Add(statsGrid);

                card.Child = cardStack;
                stack.Children.Add(card);
            }

            scroll.Content = stack;
            return scroll;
        }

        private static void AddLastSessionStat(Grid grid, int col, string label, string value, Color valueColor)
        {
            var sp = new StackPanel
            {
                Margin = new Thickness(col == 0 ? 0 : 4, 0, 0, 0),
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            sp.Children.Add(new TextBlock
            {
                Text                = value,
                FontSize            = 18,
                FontFamily          = Theme.Font,
                FontWeight          = FontWeights.Bold,
                Foreground          = new SolidColorBrush(valueColor),
                HorizontalAlignment = HorizontalAlignment.Center,
            });
            sp.Children.Add(new TextBlock
            {
                Text                = label,
                FontSize            = 8.5,
                FontFamily          = Theme.Font,
                FontWeight          = FontWeights.SemiBold,
                Foreground          = FgHint,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 2, 0, 0),
            });
            Grid.SetColumn(sp, col);
            grid.Children.Add(sp);
        }

        private FrameworkElement BuildHistoryDangerZone()
        {
            var container = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(28, 28, 30)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                BorderThickness = new Thickness(0, 1, 0, 0),
                Padding         = new Thickness(20, 12, 20, 14),
            };

            var clearBtn = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(55, 30, 30)),
                CornerRadius    = new CornerRadius(6),
                Padding         = new Thickness(14, 8, 14, 8),
                Cursor          = Cursors.Hand,
                BorderBrush     = new SolidColorBrush(Color.FromRgb(242, 129, 138)),
                BorderThickness = new Thickness(1),
            };

            var btnStack = new StackPanel();
            btnStack.Children.Add(new TextBlock
            {
                Text       = "Clear Session History",
                FontSize   = 12,
                FontFamily = Theme.Font,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(242, 129, 138)),
            });
            btnStack.Children.Add(new TextBlock
            {
                Text         = "Deletes all session log entries. Does not affect your statistical baseline.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = new SolidColorBrush(Color.FromRgb(174, 174, 178)),
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 3, 0, 0),
            });
            clearBtn.Child = btnStack;

            clearBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                var result = MessageBox.Show(
                    this,
                    "This will permanently delete all session history entries.\n\n" +
                    "Your statistical baseline is NOT affected — only the session log will be cleared.\n\n" +
                    "Are you sure?",
                    "Clear Session History",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning,
                    MessageBoxResult.No);

                if (result == MessageBoxResult.Yes)
                {
                    HistoryClearRequested?.Invoke();
                    NavigateTo(HubPage.History);
                }
            };

            container.Child = clearBtn;
            return container;
        }

        // =====================================================================
        // Page: Profile (Baseline)
        // =====================================================================

        private FrameworkElement CreateProfilePage()
        {
            try
            {
                if (_embeddedBaselineWindow != null)
                    _embeddedBaselineWindow.ResetRequested -= OnEmbeddedBaselineReset;

                // Last RECORDED session's final PSI (incl. Playback) so the Profile's
                // "Last Session PSI" tile matches Session/History instead of the
                // baseline's live-only carry value (which defaults to 100).
                double? lastSessionPsi =
                    (_historyStore?.Sessions != null && _historyStore.Sessions.Count > 0)
                        ? _historyStore.Sessions[_historyStore.Sessions.Count - 1].FinalPsi
                        : (double?)null;
                _embeddedBaselineWindow = new BaselineWindow(_baseline, _profile, lastSessionPsi);
                _embeddedBaselineWindow.ResetRequested         += OnEmbeddedBaselineReset;
                _embeddedBaselineWindow.ClearHistoryRequested  += () =>
                {
                    HistoryClearRequested?.Invoke();
                };

                return TransplantWindowBody(_embeddedBaselineWindow);
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load profile.");
            }
        }

        private void OnEmbeddedBaselineReset()
        {
            ShowCountdownConfirmDialog(
                "Reset Trading Baseline",
                "This clears your personal statistical baseline (inter-trade gap\n" +
                "distribution, μLoss).\n\n" +
                "PSI cold-start defaults apply until enough trades rebuild it.\n" +
                "Your session history is unaffected.",
                15,
                () => BaselineResetRequested?.Invoke());
        }

        // =====================================================================
        // Page: License
        // =====================================================================

        private FrameworkElement CreateLicensePage()
        {
            var lm = _licenseManager;

            // ── Status badge colours ─────────────────────────────────────────
            LicenseStatus status = lm?.Status ?? LicenseStatus.Trial_Active;
            string statusText;
            Brush  statusBg;
            switch (status)
            {
                case LicenseStatus.Trial_Active:
                    int days = lm?.TrialDaysRemaining ?? LicenseManager.TrialDays;
                    statusText = $"Trial Active — {days} day{(days == 1 ? "" : "s")} remaining";
                    statusBg   = new SolidColorBrush(Color.FromRgb(5, 120, 84));
                    break;
                case LicenseStatus.Trial_Expired:
                    statusText = "Trial Expired — Please activate";
                    statusBg   = new SolidColorBrush(Color.FromRgb(160, 60, 40));
                    break;
                case LicenseStatus.Licensed:
                    statusText = "Licensed  ✓";
                    statusBg   = new SolidColorBrush(Color.FromRgb(5, 120, 84));
                    break;
                case LicenseStatus.Offline_Grace:
                    statusText = $"Offline Grace — up to {LicenseManager.GraceDays} days";
                    statusBg   = new SolidColorBrush(Color.FromRgb(140, 100, 20));
                    break;
                case LicenseStatus.Expired:
                    statusText = "Subscription Expired — Please renew";
                    statusBg   = new SolidColorBrush(Color.FromRgb(160, 60, 40));
                    break;
                default:
                    statusText = "License Invalid — Please re-activate";
                    statusBg   = new SolidColorBrush(Color.FromRgb(160, 60, 40));
                    break;
            }

            // ── Root scroll ─────────────────────────────────────────────────
            var scroll = new System.Windows.Controls.ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };

            // A license / activation surface reads as a focused, capped column (like a
            // checkout) — not a form stretched across the whole tab. Cap + centre it.
            var stack = new StackPanel
            {
                Margin              = new Thickness(28, 24, 28, 24),
                MaxWidth            = 620,
                HorizontalAlignment = HorizontalAlignment.Center,
            };

            // ── Update available banner (shown above everything else) ─────────
            if (_updateVersion != null)
            {
                var updateBorder = new Border
                {
                    Background   = new SolidColorBrush(Color.FromRgb(40, 80, 140)),
                    CornerRadius = new CornerRadius(6),
                    Padding      = new Thickness(16, 12, 16, 12),
                    Margin       = new Thickness(0, 0, 0, 20),
                };
                var updateInner = new StackPanel();
                updateInner.Children.Add(new TextBlock
                {
                    Text       = $"⬆  Update available — {_updateVersion}",
                    FontSize   = 14,
                    FontFamily = Theme.Font,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = FgPrimary,
                    Margin     = new Thickness(0, 0, 0, 4),
                });
                if (!string.IsNullOrEmpty(_updateNotes))
                {
                    updateInner.Children.Add(new TextBlock
                    {
                        Text       = _updateNotes,
                        FontSize   = 12,
                        FontFamily = Theme.Font,
                        Foreground = FgSecondary,
                        TextWrapping = TextWrapping.Wrap,
                        Margin     = new Thickness(0, 0, 0, 8),
                    });
                }
                var dlBtn = new Button
                {
                    Content             = "Go to Download",
                    Padding             = new Thickness(14, 6, 14, 6),
                    Background          = new SolidColorBrush(Color.FromRgb(30, 120, 220)),
                    Foreground          = FgPrimary,
                    BorderThickness     = new Thickness(0),
                    FontFamily          = Theme.Font,
                    FontSize            = 12,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Cursor              = System.Windows.Input.Cursors.Hand,
                };
                dlBtn.Click += (s, e) =>
                {
                    try { System.Diagnostics.Process.Start(LicenseManager.StoreUrl); } catch { }
                };
                updateInner.Children.Add(dlBtn);
                updateBorder.Child = updateInner;
                stack.Children.Add(updateBorder);
            }

            // ── Status badge ────────────────────────────────────────────────
            var badge = new Border
            {
                Background    = statusBg,
                CornerRadius  = new CornerRadius(6),
                Padding       = new Thickness(14, 8, 14, 8),
                Margin        = new Thickness(0, 0, 0, 24),
                HorizontalAlignment = HorizontalAlignment.Left,
            };
            badge.Child = new TextBlock
            {
                Text       = statusText,
                FontSize   = 13,
                FontFamily = Theme.Font,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgPrimary,
            };
            stack.Children.Add(badge);

            // ── Machine ID row ───────────────────────────────────────────────
            stack.Children.Add(MakeLicenseLabel("Machine ID"));
            string machineId = LicenseManager.GetMachineId();
            var midRow = new Grid { Margin = new Thickness(0, 4, 0, 20) };
            midRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            midRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var midBox = new TextBox
            {
                Text              = machineId,
                IsReadOnly        = true,
                FontFamily        = new FontFamily("Consolas"),
                FontSize          = 12,
                Foreground        = FgSecondary,
                Background        = BgCard,
                BorderBrush       = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness   = new Thickness(1),
                Padding           = new Thickness(10, 7, 10, 7),
            };
            Grid.SetColumn(midBox, 0);
            midRow.Children.Add(midBox);

            var copyBtn = MakeLicenseButton("Copy");
            copyBtn.Margin = new Thickness(8, 0, 0, 0);
            copyBtn.Click += (_, __) =>
            {
                try { System.Windows.Clipboard.SetText(machineId); } catch { }
            };
            Grid.SetColumn(copyBtn, 1);
            midRow.Children.Add(copyBtn);
            stack.Children.Add(midRow);

            // ── Key input (hidden when already licensed) ─────────────────────
            bool showActivate = status != LicenseStatus.Licensed &&
                                status != LicenseStatus.Offline_Grace;

            if (showActivate)
            {
                stack.Children.Add(MakeLicenseLabel("License Key"));
                var keyRow = new Grid { Margin = new Thickness(0, 4, 0, 8) };
                keyRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                keyRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                var keyBox = new TextBox
                {
                    FontFamily      = new FontFamily("Consolas"),
                    FontSize        = 12,
                    Foreground      = FgPrimary,
                    Background      = BgCard,
                    BorderBrush     = new SolidColorBrush(Color.FromArgb(80, 255, 255, 255)),
                    BorderThickness = new Thickness(1),
                    Padding         = new Thickness(10, 7, 10, 7),
                    ToolTip         = "Paste your Whop license key — find it at whop.com/hub after purchase",
                };
                // Pre-fill with existing key if we have one (invalid/expired case).
                if (!string.IsNullOrEmpty(lm?.LicenseKey)) keyBox.Text = lm.LicenseKey;
                Grid.SetColumn(keyBox, 0);
                keyRow.Children.Add(keyBox);

                var activateBtn = MakeLicenseButton("Activate", accent: true);
                activateBtn.Margin = new Thickness(8, 0, 0, 0);
                Grid.SetColumn(activateBtn, 1);
                keyRow.Children.Add(activateBtn);
                stack.Children.Add(keyRow);

                // Feedback label
                var feedbackLabel = new TextBlock
                {
                    FontSize   = 12,
                    FontFamily = Theme.Font,
                    Foreground = FgSecondary,
                    Margin     = new Thickness(0, 4, 0, 20),
                    TextWrapping = TextWrapping.Wrap,
                };
                stack.Children.Add(feedbackLabel);

                activateBtn.Click += async (_, __) =>
                {
                    if (lm == null) { feedbackLabel.Text = "License module not loaded."; return; }
                    activateBtn.IsEnabled = false;
                    feedbackLabel.Foreground = FgSecondary;
                    feedbackLabel.Text = "Connecting to server...";
                    NinjaTrader.Code.Output.Process("[Meridian] Activate clicked — key length=" + (keyBox.Text?.Trim().Length ?? 0), PrintTo.OutputTab1);

                    // async void handler: await captures the WPF SynchronizationContext so
                    // the continuation automatically returns to the UI thread — no Dispatcher
                    // wiring needed, Output.Process works, labels are safe to write directly.
                    (bool Success, string ErrorMessage) result;
                    try
                    {
                        // Belt-and-suspenders outer timeout in case HttpClient's own timeout
                        // fails (known .NET Framework bug with SSL/TLS hang on SendAsync).
                        var apiTask = lm.ActivateAsync(keyBox.Text);
                        var won = await Task.WhenAny(apiTask, Task.Delay(TimeSpan.FromSeconds(15)));
                        result = (won == apiTask)
                            ? await apiTask
                            : (false, "Activation timed out (15 s). Check your network connection.");
                    }
                    catch (Exception ex)
                    {
                        result = (false, $"Unexpected error: {ex.Message}");
                    }

                    NinjaTrader.Code.Output.Process(
                        $"[Meridian] Activate result: success={result.Success}  msg={result.ErrorMessage ?? "ok"}",
                        PrintTo.OutputTab1);

                    activateBtn.IsEnabled = true;
                    if (result.Success)
                    {
                        feedbackLabel.Foreground = new SolidColorBrush(Color.FromRgb(80, 200, 80));
                        feedbackLabel.Text = "Activated! MeridianPSI fully unlocked.";
                        RefreshNavBadges();
                        NavigateTo(HubPage.License);
                    }
                    else
                    {
                        feedbackLabel.Foreground = new SolidColorBrush(Color.FromRgb(220, 80, 60));
                        feedbackLabel.Text = result.ErrorMessage ?? "Activation failed.";
                    }
                };
            }
            else
            {
                // Already licensed — show masked key + deactivate option
                stack.Children.Add(MakeLicenseLabel("License Key"));
                string maskedKey = lm?.LicenseKey ?? "";
                if (maskedKey.Length > 8)
                    maskedKey = maskedKey.Substring(0, 4) + "-****-****-" + maskedKey.Substring(maskedKey.Length - 4);

                stack.Children.Add(new TextBlock
                {
                    Text         = maskedKey,
                    FontFamily   = new FontFamily("Consolas"),
                    FontSize     = 12,
                    Foreground   = FgSecondary,
                    Margin       = new Thickness(0, 4, 0, 20),
                });

                // Remove license button — clears local cache so key can be entered on another PC
                var deactBtn = MakeLicenseButton("Remove license from this machine (to move to another PC)");
                deactBtn.Margin = new Thickness(0, 0, 0, 8);

                var deactFeedback = new TextBlock
                {
                    FontSize   = 12,
                    FontFamily = Theme.Font,
                    Foreground = FgSecondary,
                    Margin     = new Thickness(0, 4, 0, 20),
                    TextWrapping = TextWrapping.Wrap,
                };
                stack.Children.Add(deactBtn);
                stack.Children.Add(deactFeedback);

                deactBtn.Click += (_, __) =>
                {
                    if (lm == null) return;
                    deactBtn.IsEnabled = false;
                    deactFeedback.Text = "Removing...";
                    Task.Run(async () =>
                    {
                        var result = await lm.DeactivateAsync();
                        Dispatcher.InvokeAsync(() =>
                        {
                            deactBtn.IsEnabled = true;
                            if (result.Success)
                                NavigateTo(HubPage.License);
                            else
                            {
                                deactFeedback.Foreground = new SolidColorBrush(Color.FromRgb(220, 80, 60));
                                deactFeedback.Text = result.ErrorMessage;
                            }
                        });
                    });
                };
            }

            // ── Divider ──────────────────────────────────────────────────────
            stack.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 8, 0, 20),
            });

            // ── Store link ───────────────────────────────────────────────────
            stack.Children.Add(new TextBlock
            {
                Text         = "Subscribe / Purchase",
                FontSize     = 11,
                FontFamily   = Theme.Font,
                FontWeight   = FontWeights.SemiBold,
                Foreground   = FgHint,
                Margin       = new Thickness(0, 0, 0, 4),
            });

            var storeLink = new TextBlock
            {
                Text            = LicenseManager.StoreUrl,
                FontSize        = 12,
                FontFamily      = Theme.Font,
                Foreground      = FgAccent,
                Cursor          = Cursors.Hand,
                TextDecorations = TextDecorations.Underline,
                Margin          = new Thickness(0, 0, 0, 0),
            };
            storeLink.MouseLeftButtonDown += (_, __) =>
            {
                try { System.Diagnostics.Process.Start(LicenseManager.StoreUrl); } catch { }
            };
            stack.Children.Add(storeLink);

            // ── Trial upgrade CTA (shown for trial / expired users) ──────────
            if (status == LicenseStatus.Trial_Active || status == LicenseStatus.Trial_Expired
                || status == LicenseStatus.Expired)
            {
                stack.Children.Add(new Border
                {
                    Height     = 1,
                    Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                    Margin     = new Thickness(0, 20, 0, 16),
                });
                stack.Children.Add(new TextBlock
                {
                    Text       = "Unlock with a full license",
                    FontSize   = 13,
                    FontFamily = Theme.Font,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = FgPrimary,
                    Margin     = new Thickness(0, 0, 0, 8),
                });
                string[] features =
                {
                    "Guard — rules that enforce themselves (6 triggers · 5 action levels)",
                    "Intel — monthly digest, weekday patterns & crash-trigger analysis",
                    "PSI × P&L correlation — Stable vs Critical session averages",
                    "Today's Risk Brief — personalized pre-session summary",
                };
                foreach (var f in features)
                    stack.Children.Add(new TextBlock
                    {
                        Text         = "✓  " + f,
                        FontSize     = 11,
                        FontFamily   = Theme.Font,
                        Foreground   = FgSecondary,
                        TextWrapping = TextWrapping.Wrap,
                        Margin       = new Thickness(0, 0, 0, 5),
                    });
                var ctaBtn = new Border
                {
                    Background      = new SolidColorBrush(Color.FromRgb(16, 185, 129)),
                    CornerRadius    = new CornerRadius(8),
                    Padding         = new Thickness(0, 12, 0, 12),
                    Margin          = new Thickness(0, 12, 0, 0),
                    Cursor          = Cursors.Hand,
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                    Child = new TextBlock
                    {
                        Text                = "Upgrade — full access  →",
                        FontSize            = 13,
                        FontFamily          = Theme.Font,
                        FontWeight          = FontWeights.SemiBold,
                        Foreground          = Theme.AccentInk,
                        HorizontalAlignment = HorizontalAlignment.Center,
                    },
                };
                ctaBtn.MouseEnter += (_, __) => ctaBtn.Background = new SolidColorBrush(Color.FromRgb(13, 160, 112));
                ctaBtn.MouseLeave += (_, __) => ctaBtn.Background = new SolidColorBrush(Color.FromRgb(16, 185, 129));
                ctaBtn.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    try { System.Diagnostics.Process.Start(LicenseManager.StoreUrl); } catch { }
                };
                stack.Children.Add(ctaBtn);
            }

            // ── Export Diagnostics ───────────────────────────────────────────
            stack.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(18, 255, 255, 255)),
                Margin     = new Thickness(0, 24, 0, 16),
            });
            stack.Children.Add(new TextBlock
            {
                Text         = "Having an issue? Export a diagnostics file and send it to support.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 8),
            });
            var diagStatusLbl = new TextBlock
            {
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 6, 0, 0),
            };
            var diagBtn = new Button
            {
                Content             = "Export Diagnostics File",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = BgCard,
                Foreground          = FgPrimary,
                BorderBrush         = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255)),
                BorderThickness     = new Thickness(1),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            diagBtn.Click += (s, e) =>
            {
                diagBtn.IsEnabled   = false;
                diagStatusLbl.Text  = "Collecting...";
                diagStatusLbl.Foreground = FgSecondary;
                try
                {
                    // Snapshot must be captured on the UI thread (same thread as
                    // _currentSession, _engine, _guardEngine).  The write runs
                    // on a Task thread so the UI doesn't block.
                    var snap = _monitor.GetDiagnosticsSnapshot();
                    System.Threading.Tasks.Task.Run(() =>
                    {
                        string outPath = null; string summary;
                        bool   ok      = false;
                        try
                        {
                            outPath = DiagnosticsExporter.WriteToDesktop(snap);
                            summary = "Saved to Desktop: " + System.IO.Path.GetFileName(outPath);
                            ok      = true;
                        }
                        catch (Exception ex)
                        {
                            summary = "Export failed: " + ex.Message;
                        }
                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            diagBtn.IsEnabled        = true;
                            diagStatusLbl.Text       = summary;
                            diagStatusLbl.Foreground = ok
                                ? new SolidColorBrush(Color.FromRgb(120, 200, 130))
                                : new SolidColorBrush(Color.FromRgb(220, 120, 110));
                            if (outPath != null)
                                try { System.Diagnostics.Process.Start(outPath); } catch { }
                        }));
                    });
                }
                catch (Exception ex)
                {
                    diagBtn.IsEnabled        = true;
                    diagStatusLbl.Text       = "Snapshot failed: " + ex.Message;
                    diagStatusLbl.Foreground = new SolidColorBrush(Color.FromRgb(220, 120, 110));
                }
            };
            stack.Children.Add(diagBtn);
            stack.Children.Add(diagStatusLbl);

            // ── Version footer (click 5× to reveal developer tools) ──────────
            stack.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(18, 255, 255, 255)),
                Margin     = new Thickness(0, 24, 0, 12),
            });

            // ── Help / documentation link ────────────────────────────────────
            var docsRow = new StackPanel
            {
                Orientation         = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 10),
            };
            var docsTb = new TextBlock
            {
                Text              = "Documentation & User Guide",
                FontSize          = 10,
                FontFamily        = Theme.Font,
                Foreground        = FgAccent,
                TextDecorations   = null,
                Cursor            = System.Windows.Input.Cursors.Hand,
                VerticalAlignment = VerticalAlignment.Center,
            };
            docsTb.MouseEnter        += (_, __) => docsTb.TextDecorations = TextDecorations.Underline;
            docsTb.MouseLeave        += (_, __) => docsTb.TextDecorations = null;
            docsTb.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                try { System.Diagnostics.Process.Start(LicenseManager.DocsUrl); } catch { }
            };
            docsRow.Children.Add(docsTb);
            stack.Children.Add(docsRow);

            int devClicks = 0;
            var devPanel  = new StackPanel { Visibility = Visibility.Collapsed };

            var versionTb = new TextBlock
            {
                Text      = $"MeridianPSI v{MeridianPSI.ProductVersion}",
                FontSize  = 10,
                FontFamily = Theme.Font,
                Foreground = FgHint,
                Cursor     = Cursors.Hand,
                Margin     = new Thickness(0, 0, 0, 16),
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            versionTb.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                devClicks++;
                if (devClicks >= 5)
                    devPanel.Visibility = Visibility.Visible;
            };
            stack.Children.Add(versionTb);

            // ── Developer Tools (hidden; reveal by clicking version 5 times) ──
            devPanel.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 0, 0, 12),
            });
            devPanel.Children.Add(new TextBlock
            {
                Text       = "Developer Tools",
                FontSize   = 11,
                FontFamily = Theme.Font,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgHint,
                Margin     = new Thickness(0, 0, 0, 6),
            });

            // ── Hard reset (clear Strict Lock + reset PSI) — DEV ONLY ──
            // Gated behind the RECORD_ENABLED sentinel (developer machines only), NOT just the
            // 5-tap reveal — otherwise an end user could discover the panel and clear their own
            // Strict Lock, defeating the commitment device. (Seed/test tools stay 5-tap; they
            // don't bypass a safety commitment.)
            bool devToolsUnlocked = !string.IsNullOrEmpty(_hubDataDir)
                && System.IO.File.Exists(System.IO.Path.Combine(_hubDataDir, "RECORD_ENABLED"));
            if (devToolsUnlocked)
            {
            devPanel.Children.Add(new TextBlock
            {
                Text         = "Clears the Strict Lock + all Guard runtime and resets PSI to 100. For testing and screenshots. Leaves rules, profile, baseline, and history untouched.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 8),
            });
            var hardResetStatus = new TextBlock
            {
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 6, 0, 0),
            };
            var hardResetBtn = new Button
            {
                Content             = "Hard reset (clear Strict Lock + PSI → 100)",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(80, 60, 120)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            hardResetBtn.Click += (s, e) =>
            {
                _monitor?.DevHardReset();
                CallbackRecorder.UiEvent("dev", "hard_reset");
                hardResetStatus.Text       = "Done — Strict Lock cleared, PSI reset to 100. (Rules / profile / history untouched.)";
                hardResetStatus.Foreground = new SolidColorBrush(Color.FromRgb(120, 200, 130));
            };
            devPanel.Children.Add(hardResetBtn);
            devPanel.Children.Add(hardResetStatus);
            }

            devPanel.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 12, 0, 12),
            });

            // ── Demo Data ──────────────────────────────────────────────────────
            devPanel.Children.Add(new TextBlock
            {
                Text         = "Seed 5 months of story-driven demo history (Dec 2025 – Apr 2026). ⚠ This overwrites your real history.xml. Back up TradeMonitorData\\history.xml first.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 8),
            });

            var demoStatusLbl = new TextBlock
            {
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 6, 0, 0),
            };

            var seedBtn = new Button
            {
                Content             = "Seed Demo Data (Dec 2025 – Apr 2026)",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(80, 60, 120)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            seedBtn.Click += (s, e) =>
            {
                seedBtn.IsEnabled  = false;
                demoStatusLbl.Text = "Seeding — writing history.xml + 3 session-detail files…";
                demoStatusLbl.Foreground = FgSecondary;

                System.Threading.Tasks.Task.Run(() =>
                {
                    string result;
                    bool   ok = false;
                    try
                    {
                        result = MeridianDevTools.SeedDemoData(msg =>
                            Dispatcher.BeginInvoke(new Action(() => demoStatusLbl.Text = msg)));
                        ok = result != null && !result.StartsWith("[Demo")
                            && result.IndexOf("not in this build", StringComparison.OrdinalIgnoreCase) < 0;
                    }
                    catch (Exception ex)
                    {
                        result = "Seed failed: " + ex.Message;
                    }

                    string captured = result;
                    bool   capturedOk = ok;
                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        seedBtn.IsEnabled        = true;
                        demoStatusLbl.Text       = captured ?? "(no output)";
                        demoStatusLbl.Foreground = capturedOk
                            ? new SolidColorBrush(Color.FromRgb(120, 200, 130))
                            : new SolidColorBrush(Color.FromRgb(220, 120, 110));
                        // Reload history in memory so History / Intelligence pages
                        // update immediately without an NT8 restart.
                        if (capturedOk) ReloadHistoryStore();
                    }));
                });
            };
            devPanel.Children.Add(seedBtn);
            devPanel.Children.Add(demoStatusLbl);

            devPanel.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 16, 0, 12),
            });

            // ── V2 Engine Test Suite ──────────────────────────────────────────
            devPanel.Children.Add(new TextBlock
            {
                Text         = "Runs PsiEngineV2 against all acceptance scenarios. Does NOT touch the live engine, HUD, or baseline. Results written to Desktop\\PsiV2TestResults.txt.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 10),
            });

            var v2StatusLbl = new TextBlock
            {
                FontSize   = 11,
                FontFamily = Theme.Font,
                Foreground = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin     = new Thickness(0, 8, 0, 0),
            };

            var v2RunBtn = new Button
            {
                Content             = "Run V2 Engine Test Suite (S201–S255)",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(60, 80, 120)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            v2RunBtn.Click += (s, e) =>
            {
                v2RunBtn.IsEnabled = false;
                v2StatusLbl.Text = "Running — this may take a few seconds…";
                v2StatusLbl.Foreground = FgSecondary;

                System.Threading.Tasks.Task.Run(() =>
                {
                    string summary;
                    bool ok = false;
                    try
                    {
                        summary = MeridianDevTools.RunPsiV2Tests();
                        ok = summary != null
                            && summary.IndexOf("FAIL", StringComparison.OrdinalIgnoreCase) < 0
                            && summary.IndexOf("not in this build", StringComparison.OrdinalIgnoreCase) < 0;
                    }
                    catch (Exception ex)
                    {
                        summary = "V2 test runner threw: " + ex.Message;
                    }

                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        v2RunBtn.IsEnabled = true;
                        v2StatusLbl.Text   = summary ?? "(no output)";
                        v2StatusLbl.Foreground = ok
                            ? new SolidColorBrush(Color.FromRgb(120, 200, 130))
                            : new SolidColorBrush(Color.FromRgb(220, 120, 110));
                    }));
                });
            };
            devPanel.Children.Add(v2RunBtn);

            var v2OpenBtn = new Button
            {
                Content             = "Open PsiV2TestResults.txt",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(70, 70, 80)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
                Margin              = new Thickness(0, 8, 0, 0),
            };
            v2OpenBtn.Click += (s, e) =>
            {
                try
                {
                    string path = System.IO.Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                        "PsiV2TestResults.txt");
                    if (System.IO.File.Exists(path))
                        System.Diagnostics.Process.Start(path);
                    else
                        v2StatusLbl.Text = "No results file yet — run the suite first.";
                }
                catch (Exception ex)
                {
                    v2StatusLbl.Text = "Open failed: " + ex.Message;
                }
            };
            devPanel.Children.Add(v2OpenBtn);
            devPanel.Children.Add(v2StatusLbl);

            // ── Guard Engine acceptance tests ──────────────────────────────────
            devPanel.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 16, 0, 12),
            });
            devPanel.Children.Add(new TextBlock
            {
                Text         = "Guard Rule Tests",
                FontSize     = 11,
                FontFamily   = Theme.Font,
                FontWeight   = FontWeights.SemiBold,
                Foreground   = FgPrimary,
                Margin       = new Thickness(0, 0, 0, 4),
            });
            devPanel.Children.Add(new TextBlock
            {
                Text         = "67 acceptance scenarios: conditions, cooldown, confirmation, pause " +
                               "state machine, persistence, MinLossUsd, ALL/ANY logic, RiskAlert, " +
                               "legacy Disconnect. Writes GuardTestResults.txt to Desktop.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 10),
            });

            var guardStatusLbl = new TextBlock
            {
                FontSize     = 11,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 8, 0, 0),
            };

            var guardRunBtn = new Button
            {
                Content             = "Run Guard Test Suite (G001–G067)",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(80, 60, 100)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            guardRunBtn.Click += (s, e) =>
            {
                guardRunBtn.IsEnabled = false;
                guardStatusLbl.Text      = "Running…";
                guardStatusLbl.Foreground = FgSecondary;

                System.Threading.Tasks.Task.Run(() =>
                {
                    string summary;
                    bool ok = false;
                    try
                    {
                        summary = MeridianDevTools.RunGuardTests();
                        // Extract the last "Completed" line for the inline summary
                        string inline = summary ?? "";
                        int idx = inline.LastIndexOf("passed=", StringComparison.Ordinal);
                        if (idx >= 0)
                        {
                            int end = inline.IndexOf('\n', idx);
                            inline = end >= 0 ? inline.Substring(idx, end - idx).Trim()
                                              : inline.Substring(idx).Trim();
                        }
                        ok = summary != null &&
                             summary.IndexOf("  FAIL  ", StringComparison.Ordinal) < 0 &&
                             summary.IndexOf("not in this build", StringComparison.OrdinalIgnoreCase) < 0;
                        summary = inline;
                    }
                    catch (Exception ex)
                    {
                        summary = "Guard test runner threw: " + ex.Message;
                    }

                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        guardRunBtn.IsEnabled  = true;
                        guardStatusLbl.Text    = summary ?? "(no output)";
                        guardStatusLbl.Foreground = ok
                            ? new SolidColorBrush(Color.FromRgb(120, 200, 130))
                            : new SolidColorBrush(Color.FromRgb(220, 120, 110));
                    }));
                });
            };

            var guardOpenBtn = new Button
            {
                Content             = "Open GuardTestResults.txt",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(70, 70, 80)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
                Margin              = new Thickness(0, 8, 0, 0),
            };
            guardOpenBtn.Click += (s, e) =>
            {
                try
                {
                    string path = System.IO.Path.Combine(
                        Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                        "GuardTestResults.txt");
                    if (System.IO.File.Exists(path))
                        System.Diagnostics.Process.Start(path);
                    else
                        guardStatusLbl.Text = "No results file yet — run the suite first.";
                }
                catch (Exception ex)
                {
                    guardStatusLbl.Text = "Open failed: " + ex.Message;
                }
            };
            devPanel.Children.Add(guardRunBtn);
            devPanel.Children.Add(guardOpenBtn);
            devPanel.Children.Add(guardStatusLbl);

            // ── Flatten safety — on-demand live test on a Sim account (#31) ──────
            devPanel.Children.Add(new Border { Height = 1, Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)), Margin = new Thickness(0, 16, 0, 12) });
            devPanel.Children.Add(new TextBlock { Text = "Flatten Safety — live test (Sim only)", FontSize = 11, FontFamily = Theme.Font, FontWeight = FontWeights.SemiBold, Foreground = FgHint, Margin = new Thickness(0, 0, 0, 6) });
            devPanel.Children.Add(new TextBlock { Text = "Open a position on a Sim account, then trigger the hardened flatten on demand — no need to hit a real Guard limit. “Test retry” skips the first flatten so you watch it re-issue; “Test alert” skips all so you see the could-not-confirm alert (then close the Sim position manually). Fault injection is blocked on a Live account.", FontSize = 10, FontFamily = Theme.Font, Foreground = FgSecondary, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 10) });

            var flattenStatusLbl = new TextBlock { FontSize = 11, FontFamily = Theme.Font, Foreground = FgSecondary, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 8, 0, 0) };
            Func<string, int, Button> mkFlattenBtn = (label, skip) =>
            {
                var b = new Button { Content = label, Padding = new Thickness(14, 6, 14, 6), Background = new SolidColorBrush(Color.FromRgb(80, 60, 100)), Foreground = FgPrimary, BorderThickness = new Thickness(0), FontFamily = Theme.Font, FontSize = 12, HorizontalAlignment = HorizontalAlignment.Left, Cursor = System.Windows.Input.Cursors.Hand, Margin = new Thickness(0, 6, 0, 0) };
                b.Click += (s, e) =>
                {
                    string msg;
                    try { msg = _monitor != null ? _monitor.DevTestFlatten(skip) : "Monitor not available (open the dashboard from a connected session)."; }
                    catch (Exception ex) { msg = "Test threw: " + ex.Message; }
                    flattenStatusLbl.Text = msg;
                };
                return b;
            };
            devPanel.Children.Add(mkFlattenBtn("Test flatten now", 0));
            devPanel.Children.Add(mkFlattenBtn("Test retry (skip 1 flatten)", 1));
            devPanel.Children.Add(mkFlattenBtn("Test alert (skip all → give up)", 9));
            devPanel.Children.Add(flattenStatusLbl);
            // Architecturally these belong to the same "Developer Tools"
            // section, but their job is to verify the state-machine fabric
            // (TradeMonitor lifecycle dictionaries + IntegrityCheck), not
            // the engine math.  See ARCHITECTURE.md §15 (Self-Healing State).
            devPanel.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 16, 0, 12),
            });
            devPanel.Children.Add(new TextBlock
            {
                Text       = "State Integrity Tools",
                FontSize   = 11,
                FontFamily = Theme.Font,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgHint,
                Margin     = new Thickness(0, 0, 0, 6),
            });
            devPanel.Children.Add(new TextBlock
            {
                Text         = "Replay diagnoses any past CSV log against the current build to surface state-tearing / lifecycle bugs that happened in that session. Fuzzer generates 1000 random NT8 event scenarios and asserts our state-machine invariants always hold. Both write detailed reports to your Desktop.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 10),
            });

            var integrityStatusLbl = new TextBlock
            {
                FontSize   = 11,
                FontFamily = Theme.Font,
                Foreground = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin     = new Thickness(0, 8, 0, 0),
            };

            var replayBtn = new Button
            {
                Content             = "Run Replay Harness on CSV log(s)…",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(60, 80, 120)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            replayBtn.Click += (s, e) =>
            {
                try
                {
                    var dlg = new Microsoft.Win32.OpenFileDialog
                    {
                        Title       = "Choose NinjaTrader Grid CSV log(s) — hold Ctrl / Shift to select multiple",
                        Filter      = "NinjaTrader Grid CSV (*.csv)|*.csv|All files (*.*)|*.*",
                        InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile)
                                           + System.IO.Path.DirectorySeparatorChar + "Downloads",
                        Multiselect = true,
                    };
                    if (dlg.ShowDialog() != true) return;

                    string[] csvPaths = dlg.FileNames;
                    replayBtn.IsEnabled = false;
                    integrityStatusLbl.Text = string.Format(
                        "Replaying {0} file(s)…", csvPaths.Length);
                    integrityStatusLbl.Foreground = FgSecondary;

                    System.Threading.Tasks.Task.Run(() =>
                    {
                        string outDir  = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                        int    totalV  = 0;
                        int    totalS  = 0;
                        bool   allOk   = true;
                        string lastOut = null;

                        // Batch: run each file, accumulate totals.
                        // Individual report files are written as usual.
                        // When more than one file is selected, also write a
                        // single-page batch-summary file.
                        var batchLines = new System.Collections.Generic.List<string>();
                        batchLines.Add("==================== BATCH REPLAY SUMMARY ====================");
                        batchLines.Add(string.Format("Run:   {0:u}", DateTime.UtcNow));
                        batchLines.Add(string.Format("Files: {0}", csvPaths.Length));
                        batchLines.Add("");

                        foreach (string csvPath in csvPaths)
                        {
                            string fname = System.IO.Path.GetFileName(csvPath);
                            try
                            {
                                var (rep, path) = LogReplayHarness.RunFile(csvPath, outDir);
                                lastOut = path;
                                totalV += rep.TotalViolations;
                                totalS += rep.TotalSteps;
                                if (rep.TotalViolations > 0) allOk = false;

                                string status = rep.TotalViolations == 0 ? "CLEAN" : "VIOLATIONS=" + rep.TotalViolations;
                                batchLines.Add(string.Format("  [{0}]  steps={1}  {2}  →  {3}",
                                    status, rep.TotalSteps, fname,
                                    System.IO.Path.GetFileName(path)));
                            }
                            catch (Exception ex)
                            {
                                allOk = false;
                                batchLines.Add(string.Format("  [ERROR]  {0}  →  {1}", fname, ex.Message));
                            }
                        }

                        batchLines.Add("");
                        batchLines.Add(string.Format("TOTAL  steps={0}  violations={1}  {2}",
                            totalS, totalV, allOk ? "ALL CLEAN" : "NEEDS REVIEW"));
                        batchLines.Add("=============================================================");

                        // Write batch summary only when multiple files were selected.
                        string batchPath = null;
                        if (csvPaths.Length > 1)
                        {
                            batchPath = System.IO.Path.Combine(outDir,
                                string.Format("ReplayBatchSummary_{0:yyyy-MM-dd_HH-mm-ss}.txt",
                                    DateTime.Now));
                            System.IO.File.WriteAllLines(batchPath, batchLines,
                                System.Text.Encoding.UTF8);
                        }

                        string openFile = batchPath ?? lastOut;
                        string summary  = csvPaths.Length == 1
                            ? string.Format("Replay complete · steps={0} · violations={1} · written to Desktop", totalS, totalV)
                            : string.Format("Batch done · {0} files · {1} total violations · summary on Desktop",
                                csvPaths.Length, totalV);

                        Dispatcher.BeginInvoke(new Action(() =>
                        {
                            replayBtn.IsEnabled = true;
                            integrityStatusLbl.Text       = summary;
                            integrityStatusLbl.Foreground = allOk
                                ? new SolidColorBrush(Color.FromRgb(120, 200, 130))
                                : new SolidColorBrush(Color.FromRgb(220, 180, 110));
                            if (openFile != null)
                            {
                                try { System.Diagnostics.Process.Start(openFile); } catch { }
                            }
                        }));
                    });
                }
                catch (Exception ex)
                {
                    integrityStatusLbl.Text       = "Replay launch failed: " + ex.Message;
                    integrityStatusLbl.Foreground = new SolidColorBrush(Color.FromRgb(220, 120, 110));
                }
            };
            devPanel.Children.Add(replayBtn);

            var fuzzBtn = new Button
            {
                Content             = "Run Property Fuzzer (1000 scenarios)",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(70, 70, 80)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
                Margin              = new Thickness(0, 8, 0, 0),
            };
            fuzzBtn.Click += (s, e) =>
            {
                fuzzBtn.IsEnabled = false;
                integrityStatusLbl.Text = "Fuzzing 1000 scenarios…";
                integrityStatusLbl.Foreground = FgSecondary;

                System.Threading.Tasks.Task.Run(() =>
                {
                    string summary; bool ok = false; string outPath = null;
                    try
                    {
                        string outDir = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                        var (pass, fail, seed, path) = MeridianDevTools.RunPropertyFuzzer(1000, outDir);
                        outPath = path;
                        if (path == null && pass == 0 && fail == 0)
                            summary = MeridianDevTools.NotInstalledMessage;
                        else
                            summary = string.Format(
                                "Fuzz complete · pass={0} · fail={1} · seed={2} · written to Desktop\\{3}",
                                pass, fail, seed,
                                path != null ? System.IO.Path.GetFileName(path) : "(none)");
                        ok = fail == 0 && path != null;
                    }
                    catch (Exception ex)
                    {
                        summary = "Fuzz failed: " + ex.Message;
                    }

                    Dispatcher.BeginInvoke(new Action(() =>
                    {
                        fuzzBtn.IsEnabled = true;
                        integrityStatusLbl.Text       = summary;
                        integrityStatusLbl.Foreground = ok
                            ? new SolidColorBrush(Color.FromRgb(120, 200, 130))
                            : new SolidColorBrush(Color.FromRgb(220, 120, 110));
                        if (outPath != null)
                        {
                            try { System.Diagnostics.Process.Start(outPath); } catch { }
                        }
                    }));
                });
            };
            devPanel.Children.Add(fuzzBtn);

            devPanel.Children.Add(integrityStatusLbl);
            stack.Children.Add(devPanel);

            scroll.Content = stack;
            return scroll;
        }

        // ── License page helpers ──────────────────────────────────────────────

        private static TextBlock MakeLicenseLabel(string text) => new TextBlock
        {
            Text       = text,
            FontSize   = 11,
            FontFamily = Theme.Font,
            FontWeight = FontWeights.SemiBold,
            Foreground = FgHint,
            Margin     = new Thickness(0, 0, 0, 2),
        };

        private static System.Windows.Controls.Button MakeLicenseButton(string label, bool accent = false)
        {
            Brush bg = accent ? Theme.AccentSolid : BgCard;
            Brush fg = accent ? Theme.AccentInk : FgPrimary;       // dark ink on the emerald — never white
            Brush bd = accent ? Theme.Tint(Theme.Accent, 64) : new SolidColorBrush(Color.FromArgb(60, 255, 255, 255));
            return new System.Windows.Controls.Button
            {
                Content          = label,
                FontSize         = 12,
                FontFamily       = Theme.Font,
                FontWeight       = FontWeights.SemiBold,
                Foreground       = fg,
                Cursor           = Cursors.Hand,
                FocusVisualStyle = null,
                Template         = Ui.FlatButtonTemplate(bg, bd, 6, 14, 7),
            };
        }

        // =====================================================================
        // Page: Intelligence
        // =====================================================================

        private FrameworkElement CreateIntelligencePage()
        {
            try
            {
                var sessions = _historyStore?.Sessions
                    ?? new System.Collections.Generic.List<SessionHistoryEntry>();
                var source = new IntelligenceWindow(sessions);
                var body   = TransplantWindowBody(source);

                var dock = new DockPanel { LastChildFill = true };
                var bar  = BuildPageActionBar(
                    null, null,
                    "History →",
                    () => NavigateTo(HubPage.History));
                DockPanel.SetDock(bar, Dock.Top);
                dock.Children.Add(bar);
                dock.Children.Add(body);
                return dock;
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load PSI Intelligence.");
            }
        }

        // =====================================================================
        // Page: Journal (v1.2)
        // =====================================================================
        //
        // Design: passive, non-intrusive, zero mandatory input.  Every entry
        // is stamped with the current PSI / dominant dim / session P&L so the
        // trader cannot fully retcon their state later (evidence-anchored
        // recall — ARCHITECTURE.md §14.3).

        private TextBox    _journalNoteBox;
        private TextBox    _journalDayNoteBox;
        private StackPanel _journalEntriesList;
        private TextBlock  _journalDateLabel;
        private DateTime   _journalDateShown = DateTime.Today;

        // Reflection panel fields
        private TextBox    _reflWentWellBox;
        private TextBox    _reflImproveBox;
        private TextBox    _reflFocusBox;
        private Border     _reflectionPanel;

        // Right-rail reference for the Journal workbench.
        private FrameworkElement BuildJournalRail()
        {
            var card = new Border
            {
                Background = Theme.BgCard, BorderBrush = Theme.Border, BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(Theme.R3), Padding = new Thickness(16),
            };
            var sp = new StackPanel();
            sp.Children.Add(new TextBlock { Text = "Why journal", FontFamily = Theme.Font, FontSize = 10, FontWeight = FontWeights.Bold, Foreground = FgHint, Margin = new Thickness(0, 0, 0, 10) });
            sp.Children.Add(new TextBlock { Text = "PSI measures what you did. The journal captures how it felt — the part the engine can't see. A line written in the moment is hard to retcon later.", FontFamily = Theme.Font, FontSize = 12, Foreground = FgSecondary, TextWrapping = TextWrapping.Wrap, LineHeight = 19 });
            card.Child = sp;
            var rail = new StackPanel();
            rail.Children.Add(card);
            return rail;
        }

        private FrameworkElement CreateJournalPage()
        {
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };

            var root = new StackPanel { Margin = new Thickness(24, 24, 18, 48) };
            var journalGrid = new Grid();
            journalGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.55, GridUnitType.Star) });
            journalGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            Grid.SetColumn(root, 0); journalGrid.Children.Add(root);
            var journalRail = (StackPanel)BuildJournalRail();
            journalRail.Margin = new Thickness(18, 24, 24, 48);
            Grid.SetColumn(journalRail, 1); journalGrid.Children.Add(journalRail);
            scroll.Content = journalGrid;

            // ── Title row ─────────────────────────────────────────────────────
            root.Children.Add(new TextBlock
            {
                Text       = "Journal",
                FontSize   = 18,
                FontWeight = FontWeights.Bold,
                FontFamily = Theme.Font,
                Foreground = FgPrimary,
            });
            root.Children.Add(new TextBlock
            {
                Text         = "Quick notes and emotion tags captured during the session are compiled here.  Nothing is mandatory.",
                FontSize     = 11,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 2, 0, 16),
            });

            // ── Date navigation row ───────────────────────────────────────────
            var dateNavRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 0, 0, 14),
            };

            var prevDayBtn = new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(5),
                Padding         = new Thickness(10, 5, 10, 5),
                Cursor          = Cursors.Hand,
                Child           = new TextBlock { Text = "◀", FontSize = 12, Foreground = FgSecondary,
                                                  FontFamily = Theme.Font },
            };

            _journalDateLabel = new TextBlock
            {
                FontSize            = 13,
                FontWeight          = FontWeights.SemiBold,
                FontFamily          = Theme.Font,
                Foreground          = FgPrimary,
                VerticalAlignment   = VerticalAlignment.Center,
                Margin              = new Thickness(10, 0, 10, 0),
                MinWidth            = 180,
                TextAlignment       = TextAlignment.Center,
            };

            var nextDayBtn = new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(5),
                Padding         = new Thickness(10, 5, 10, 5),
                Cursor          = Cursors.Hand,
                Child           = new TextBlock { Text = "▶", FontSize = 12, Foreground = FgSecondary,
                                                  FontFamily = Theme.Font },
            };

            var todayBtn = new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(5),
                Padding         = new Thickness(10, 5, 10, 5),
                Cursor          = Cursors.Hand,
                Margin          = new Thickness(8, 0, 0, 0),
                Child           = new TextBlock { Text = "Today", FontSize = 11, Foreground = FgSecondary,
                                                  FontFamily = Theme.Font },
            };

            dateNavRow.Children.Add(prevDayBtn);
            dateNavRow.Children.Add(_journalDateLabel);
            dateNavRow.Children.Add(nextDayBtn);
            dateNavRow.Children.Add(todayBtn);
            root.Children.Add(dateNavRow);

            // ── Day note area ─────────────────────────────────────────────────
            var dayNoteHeader = new Grid();
            dayNoteHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            dayNoteHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var dayNoteLabel = new TextBlock
            {
                Text              = "Day journal",
                FontSize          = 13,
                FontWeight        = FontWeights.SemiBold,
                FontFamily        = Theme.Font,
                Foreground        = FgPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(0, 0, 0, 0),
            };
            Grid.SetColumn(dayNoteLabel, 0);
            dayNoteHeader.Children.Add(dayNoteLabel);

            // "Complete Journal" (auto-compile) button
            var compileBtn = new Border
            {
                Background      = Theme.Tint(Theme.Accent, 18),
                BorderBrush     = Theme.Tint(Theme.Accent, 60),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(5),
                Padding         = new Thickness(10, 4, 10, 4),
                Cursor          = Cursors.Hand,
                ToolTip         = "Auto-compile all today's quick notes, emotion tags and session stats into a draft journal. Review, edit, then save.",
                Child           = new TextBlock
                {
                    Text       = "✦ Complete Journal",
                    FontSize   = 11,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = Theme.Accent,
                    FontFamily = Theme.Font,
                },
            };
            Grid.SetColumn(compileBtn, 1);
            dayNoteHeader.Children.Add(compileBtn);

            dayNoteHeader.Margin = new Thickness(0, 0, 0, 6);
            root.Children.Add(dayNoteHeader);

            root.Children.Add(new TextBlock
            {
                Text         = "Compiled automatically or write freely. Saved per trading day — visible in History.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgHint,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 8),
            });

            _journalDayNoteBox = new TextBox
            {
                Background      = BgCard,
                Foreground      = FgPrimary,
                CaretBrush      = FgPrimary,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(10, 8, 10, 8),
                FontFamily      = new FontFamily("Consolas"),
                FontSize        = 11,
                AcceptsReturn   = true,
                TextWrapping    = TextWrapping.Wrap,
                MinHeight       = 130,
                MaxHeight       = 380,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            };
            root.Children.Add(_journalDayNoteBox);

            var saveDayBtn = BuildSimpleButton("Save journal", accent: true);
            saveDayBtn.Margin = new Thickness(0, 8, 0, 20);
            saveDayBtn.Click += (s, e) =>
            {
                if (_journalDayNoteBox == null) return;
                string txt  = _journalDayNoteBox.Text ?? "";
                DateTime dt = _journalDateShown;
                try { JournalStore.SaveDayNote(dt, txt); }
                catch { }
                saveDayBtn.Content   = "Saved ✓";
                saveDayBtn.IsEnabled = false;
                var t = new System.Windows.Threading.DispatcherTimer
                    { Interval = TimeSpan.FromMilliseconds(1200) };
                t.Tick += (_, __) =>
                {
                    saveDayBtn.Content   = "Save journal";
                    saveDayBtn.IsEnabled = true;
                    t.Stop();
                };
                t.Start();
            };
            root.Children.Add(saveDayBtn);

            // ── Divider ───────────────────────────────────────────────────────
            root.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 0, 0, 18),
            });

            // ── Quick emotion tags (live — always for today) — in the capture rail ─
            journalRail.Children.Add(new TextBlock
            {
                Text       = "Tag your mood",
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                FontFamily = Theme.Font,
                Foreground = FgPrimary,
                Margin     = new Thickness(0, 18, 0, 8),
            });
            var emotionRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 0, 0, 14),
            };
            emotionRow.Children.Add(BuildEmotionButton("😊 Great",     JournalEmotion.Calm));
            emotionRow.Children.Add(BuildEmotionButton("😐 Neutral",   JournalEmotion.Neutral));
            emotionRow.Children.Add(BuildEmotionButton("😤 Frustrated", JournalEmotion.Stressed));
            journalRail.Children.Add(emotionRow);

            // ── Quick note input — in the capture rail ────────────────────────
            journalRail.Children.Add(new TextBlock
            {
                Text       = "Quick note",
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                FontFamily = Theme.Font,
                Foreground = FgPrimary,
                Margin     = new Thickness(0, 14, 0, 6),
            });

            _journalNoteBox = new TextBox
            {
                Background      = BgCard,
                Foreground      = FgPrimary,
                CaretBrush      = FgPrimary,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(10, 8, 10, 8),
                FontFamily      = Theme.Font,
                FontSize        = 12,
                AcceptsReturn   = false,
                MinHeight       = 34,
            };
            _journalNoteBox.KeyDown += (s, e) =>
            {
                if (e.Key == Key.Enter)
                {
                    e.Handled = true;
                    SubmitQuickNote();
                }
            };
            journalRail.Children.Add(_journalNoteBox);

            var actionRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 8, 0, 16),
            };
            var addBtn = BuildSimpleButton("Add note", accent: true);
            addBtn.Click += (s, e) => SubmitQuickNote();
            actionRow.Children.Add(addBtn);
            journalRail.Children.Add(actionRow);

            // ── Session Reflection (collapsible) ──────────────────────────────
            var reflToggleRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 0, 0, 8),
                Cursor      = Cursors.Hand,
            };
            var reflChevron = new TextBlock
            {
                Text       = "▼",
                FontSize   = 9,
                FontFamily = Theme.Font,
                Foreground = FgHint,
                VerticalAlignment = VerticalAlignment.Center,
                Margin     = new Thickness(0, 0, 6, 0),
            };
            reflToggleRow.Children.Add(reflChevron);
            reflToggleRow.Children.Add(new TextBlock
            {
                Text       = "Session reflection",
                FontSize   = 11,
                FontWeight = FontWeights.SemiBold,
                FontFamily = Theme.Font,
                Foreground = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            });
            root.Children.Add(reflToggleRow);

            // Build the expandable reflection panel — styling matches _journalNoteBox exactly
            TextBox MakeReflBox() => new TextBox
            {
                Background      = BgCard,
                Foreground      = FgPrimary,
                CaretBrush      = FgPrimary,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(10, 8, 10, 8),
                FontFamily      = Theme.Font,
                FontSize        = 12,
                AcceptsReturn   = true,
                TextWrapping    = TextWrapping.Wrap,
                MinHeight       = 46,
                MaxHeight       = 120,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            };
            _reflWentWellBox = MakeReflBox();
            _reflImproveBox  = MakeReflBox();
            _reflFocusBox    = MakeReflBox();

            TextBlock ReflLabel(string text, bool first = false) => new TextBlock
            {
                Text       = text,
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                FontFamily = Theme.Font,
                Foreground = FgPrimary,
                Margin     = new Thickness(0, first ? 0 : 12, 0, 6),
            };

            var reflInner = new StackPanel();

            // Customizable prompts (LIVE path): render only ENABLED prompts in saved order with
            // the user's labels; inline Customize editor renames / toggles / reorders them.
            // Answers persist in the 3 fixed slots (boxes above) so there is no data migration.
            var jprompts = JournalStore.LoadReflectionPrompts();
            TextBox[] jslot = { _reflWentWellBox, _reflImproveBox, _reflFocusBox };

            var jbody = new StackPanel();
            Action jrebuild = () =>
            {
                jbody.Children.Clear();
                bool any = false, first = true;
                foreach (var p in jprompts)
                {
                    if (p == null || !p.Enabled || p.Slot < 0 || p.Slot > 2) continue;
                    jbody.Children.Add(ReflLabel((p.Label ?? "") + ":", first));
                    jbody.Children.Add(jslot[p.Slot]);
                    any = true; first = false;
                }
                if (!any) jbody.Children.Add(new TextBlock { Text = "All prompts are turned off. Use Customize to switch some back on.", FontFamily = Theme.Font, FontSize = 11, Foreground = FgHint, TextWrapping = TextWrapping.Wrap });
            };
            jrebuild();

            Func<string, bool, Border> jReorderBtn = (g, en) =>
            {
                var gt = new TextBlock { Text = g, FontFamily = Theme.Font, FontSize = 8, Foreground = en ? FgSecondary : FgHint, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                return new Border { Width = 18, Height = 13, CornerRadius = new CornerRadius(3), Background = en ? BgCard : Brushes.Transparent, BorderBrush = en ? new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)) : Brushes.Transparent, BorderThickness = new Thickness(1), Margin = new Thickness(0, 1, 0, 1), Cursor = en ? Cursors.Hand : Cursors.Arrow, Child = gt };
            };

            var jed = new StackPanel { Visibility = Visibility.Collapsed, Margin = new Thickness(0, 8, 0, 0) };
            var jeb = new System.Collections.Generic.List<TextBox>();
            Action jcommit = () =>
            {
                for (int i = 0; i < jprompts.Count && i < jeb.Count; i++)
                {
                    var lb = jeb[i]; if (lb == null) continue;
                    if (!string.IsNullOrWhiteSpace(lb.Text)) jprompts[i].Label = lb.Text.Trim();
                    if (lb.Tag is System.Windows.Controls.CheckBox cb) jprompts[i].Enabled = cb.IsChecked == true;
                }
            };
            Action jrebEd = null;
            jrebEd = () =>
            {
                jed.Children.Clear(); jeb.Clear();
                jed.Children.Add(new TextBlock { Text = "Rename, reorder or turn off each prompt; your saved answers are kept.", FontFamily = Theme.Font, FontSize = 10, Foreground = FgHint, Margin = new Thickness(0, 0, 0, 8), TextWrapping = TextWrapping.Wrap });
                for (int pi = 0; pi < jprompts.Count; pi++)
                {
                    int idx = pi;
                    var rg = new Grid { Margin = new Thickness(0, 0, 0, 6) };
                    rg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                    rg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                    rg.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                    var ud = new StackPanel { Orientation = Orientation.Vertical, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 8, 0) };
                    var up = jReorderBtn("▲", idx > 0);
                    if (idx > 0) up.MouseLeftButtonDown += (_, e3) => { e3.Handled = true; jcommit(); var tmp = jprompts[idx - 1]; jprompts[idx - 1] = jprompts[idx]; jprompts[idx] = tmp; jrebEd(); };
                    var dn = jReorderBtn("▼", idx < jprompts.Count - 1);
                    if (idx < jprompts.Count - 1) dn.MouseLeftButtonDown += (_, e3) => { e3.Handled = true; jcommit(); var tmp = jprompts[idx + 1]; jprompts[idx + 1] = jprompts[idx]; jprompts[idx] = tmp; jrebEd(); };
                    ud.Children.Add(up); ud.Children.Add(dn);
                    Grid.SetColumn(ud, 0); rg.Children.Add(ud);
                    var chk = new System.Windows.Controls.CheckBox { IsChecked = jprompts[pi].Enabled, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 8, 0), Foreground = FgSecondary };
                    Grid.SetColumn(chk, 1); rg.Children.Add(chk);
                    var lb = MakeReflBox(); lb.Text = jprompts[pi].Label; lb.AcceptsReturn = false; lb.MinHeight = 30; lb.MaxHeight = 36; lb.Tag = chk;
                    Grid.SetColumn(lb, 2); rg.Children.Add(lb);
                    jeb.Add(lb);
                    jed.Children.Add(rg);
                }
                var sp2 = BuildSimpleButton("Save prompts", accent: true);
                sp2.Margin = new Thickness(0, 4, 0, 0);
                sp2.Click += (_, __) => { jcommit(); JournalStore.SaveReflectionPrompts(jprompts); jrebuild(); jed.Visibility = Visibility.Collapsed; };
                jed.Children.Add(sp2);
            };
            jrebEd();

            var jcr = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 0, 0, 2) };
            var jcl = new TextBlock { Text = "Customize", FontFamily = Theme.Font, FontSize = 11, FontWeight = FontWeights.SemiBold, Foreground = Theme.Accent, Cursor = Cursors.Hand };
            jcl.MouseLeftButtonDown += (_, e3) => { e3.Handled = true; bool willOpen = jed.Visibility != Visibility.Visible; jed.Visibility = willOpen ? Visibility.Visible : Visibility.Collapsed; if (willOpen) CallbackRecorder.UiEvent("journal", "customize_open"); };
            jcr.Children.Add(jcl);
            reflInner.Children.Add(jcr);
            reflInner.Children.Add(jbody);
            reflInner.Children.Add(jed);

            var saveReflBtn = BuildSimpleButton("Save reflection", accent: false);
            saveReflBtn.Margin = new Thickness(0, 10, 0, 0);
            saveReflBtn.Click += (s, e) =>
            {
                try
                {
                    JournalStore.SaveReflection(
                        _journalDateShown,
                        _reflWentWellBox?.Text ?? "",
                        _reflImproveBox?.Text  ?? "",
                        _reflFocusBox?.Text    ?? "");
                }
                catch { }
                CallbackRecorder.UiEvent("journal", "save");
                saveReflBtn.Content   = "Saved ✓";
                saveReflBtn.IsEnabled = false;
                var t2 = new System.Windows.Threading.DispatcherTimer
                    { Interval = TimeSpan.FromMilliseconds(1200) };
                t2.Tick += (__, ___) =>
                {
                    saveReflBtn.Content   = "Save reflection";
                    saveReflBtn.IsEnabled = true;
                    t2.Stop();
                };
                t2.Start();
            };
            reflInner.Children.Add(saveReflBtn);

            _reflectionPanel = new Border
            {
                Visibility      = Visibility.Visible,
                Background      = Brushes.Transparent,
                BorderThickness = new Thickness(0),
                Margin          = new Thickness(0, 0, 0, 16),
                Child           = reflInner,
            };
            root.Children.Add(_reflectionPanel);

            // Toggle expand/collapse
            reflToggleRow.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                bool show = _reflectionPanel.Visibility != Visibility.Visible;
                _reflectionPanel.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
                reflChevron.Text = show ? "▼" : "▶";
            };

            // ── Entries for selected date — the capture log, in the rail ──────
            journalRail.Children.Add(new TextBlock
            {
                Text       = "Session entries",
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                FontFamily = Theme.Font,
                Foreground = FgPrimary,
                Margin     = new Thickness(0, 18, 0, 8),
            });

            _journalEntriesList = new StackPanel();
            journalRail.Children.Add(_journalEntriesList);

            // ── Wire date navigation ──────────────────────────────────────────
            Action refreshJournalDate = () =>
            {
                // Update date label
                bool isToday = _journalDateShown.Date == DateTime.Today.Date;
                _journalDateLabel.Text = isToday
                    ? "Today  ·  " + _journalDateShown.ToString("MMM d")
                    : _journalDateShown.ToString("ddd, MMM d, yyyy");

                // Load day note for selected date
                string existing = "";
                try { existing = JournalStore.LoadDayNote(_journalDateShown); } catch { }
                if (_journalDayNoteBox != null)
                    _journalDayNoteBox.Text = existing ?? "";

                // Load reflection fields for selected date
                try
                {
                    var (well, improve, focus) = JournalStore.LoadReflection(_journalDateShown);
                    if (_reflWentWellBox != null) _reflWentWellBox.Text = well    ?? "";
                    if (_reflImproveBox  != null) _reflImproveBox.Text  = improve ?? "";
                    if (_reflFocusBox    != null) _reflFocusBox.Text    = focus   ?? "";
                }
                catch { }

                // Refresh entries list for selected date
                RefreshJournalEntries(_journalDateShown);

                // Disable "next" when already at today
                ((TextBlock)nextDayBtn.Child).Foreground =
                    _journalDateShown.Date >= DateTime.Today.Date ? FgHint : FgSecondary;
                nextDayBtn.Cursor =
                    _journalDateShown.Date >= DateTime.Today.Date
                    ? Cursors.Arrow : Cursors.Hand;
            };

            prevDayBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                _journalDateShown = _journalDateShown.AddDays(-1);
                refreshJournalDate();
            };
            nextDayBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                if (_journalDateShown.Date < DateTime.Today.Date)
                {
                    _journalDateShown = _journalDateShown.AddDays(1);
                    refreshJournalDate();
                }
            };
            todayBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                _journalDateShown = DateTime.Today;
                refreshJournalDate();
            };

            // ── Wire Complete Journal (auto-compile) ──────────────────────────
            compileBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                DateTime dt = _journalDateShown;

                double psi       = _sessionData != null ? _sessionData.FinalPsi    : 100.0;
                int    trades    = _sessionData != null ? _sessionData.TotalTrades  : 0;
                double pnl       = _sessionData != null ? _sessionData.TotalPnl     : 0.0;
                double winRate   = (_sessionData != null && _sessionData.TotalTrades > 0)
                                   ? (double)_sessionData.WinTrades / _sessionData.TotalTrades
                                   : -1.0;
                string dominantDim = _monitor != null ? (_monitor.GetDominantDimLabel() ?? "") : "";

                string compiled = JournalStore.CompileSessionJournal(
                    dt, psi, trades, pnl, winRate, dominantDim);

                if (_journalDayNoteBox != null)
                    _journalDayNoteBox.Text = compiled;

                // Visual feedback on the button
                var lbl = (TextBlock)compileBtn.Child;
                string origText = lbl.Text;
                lbl.Text = "✓ Draft ready — review & save";
                var t = new System.Windows.Threading.DispatcherTimer
                    { Interval = TimeSpan.FromSeconds(3) };
                t.Tick += (__, ___) => { lbl.Text = origText; t.Stop(); };
                t.Start();
            };

            // Initial population
            refreshJournalDate();

            return scroll;
        }

        private Border BuildEmotionButton(string label, JournalEmotion em)
        {
            var textBlock = new TextBlock
            {
                Text              = label,
                FontSize          = 12,
                FontFamily        = Theme.Font,
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            };

            var border = new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(16),
                Padding         = new Thickness(12, 6, 14, 6),
                Margin          = new Thickness(0, 0, 8, 0),
                Cursor          = Cursors.Hand,
                Child           = textBlock,
            };
            border.MouseEnter += (_, __) => border.Background = BgNavHover;
            border.MouseLeave += (_, __) => border.Background = BgCard;
            border.MouseLeftButtonUp += (_, __) =>
            {
                if (_monitor == null) return;
                _monitor.RecordJournalEntry(JournalKind.EmotionTag, em, null);
                RefreshJournalEntries();
            };
            return border;
        }

        private Border BuildSnapshotCard()
        {
            double psi = _sessionData != null ? _sessionData.FinalPsi : 100.0;
            double pnl = _sessionData != null ? _sessionData.TotalPnl : 0.0;
            string dom = _monitor != null ? (_monitor.GetDominantDimLabel() ?? "none") : "-";

            var panel = new StackPanel { Orientation = Orientation.Horizontal };
            panel.Children.Add(MakeKv("PSI",      psi.ToString("F1")));
            panel.Children.Add(MakeKv("Dominant", dom));
            panel.Children.Add(MakeKv("Session P&L", (pnl >= 0 ? "+" : "") + pnl.ToString("F2")));

            return new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(8),
                Padding         = new Thickness(12, 8, 12, 8),
                Child           = panel,
            };
        }

        private static UIElement MakeKv(string key, string value)
        {
            var stack = new StackPanel { Margin = new Thickness(0, 0, 18, 0) };
            stack.Children.Add(new TextBlock
            {
                Text       = key,
                FontSize   = 10,
                FontFamily = Theme.Font,
                Foreground = FgHint,
            });
            stack.Children.Add(new TextBlock
            {
                Text       = value,
                FontSize   = 13,
                FontWeight = FontWeights.SemiBold,
                FontFamily = Theme.Font,
                Foreground = FgPrimary,
            });
            return stack;
        }

        private void SubmitQuickNote()
        {
            if (_journalNoteBox == null || _monitor == null) return;
            string text = (_journalNoteBox.Text ?? "").Trim();
            if (string.IsNullOrEmpty(text)) return;

            _monitor.RecordJournalEntry(JournalKind.QuickNote, JournalEmotion.None, text);
            _journalNoteBox.Text = "";
            RefreshJournalEntries(_journalDateShown);
        }


        // date parameter: show entries for that specific date (null = recent 40 across all dates)
        private void RefreshJournalEntries(DateTime? date = null)
        {
            if (_journalEntriesList == null) return;
            _journalEntriesList.Children.Clear();

            List<JournalEntry> entries;
            try
            {
                entries = date.HasValue
                    ? JournalStore.Recent(limit: 200, sessionDate: date.Value)
                    : JournalStore.Recent(limit: 40);
            }
            catch { entries = new List<JournalEntry>(); }

            if (entries.Count == 0)
            {
                _journalEntriesList.Children.Add(new TextBlock
                {
                    Text       = date.HasValue
                                 ? "No quick notes or emotion tags recorded for this session."
                                 : "No entries yet.  Tag an emotion or write one line above.",
                    FontSize   = 11,
                    FontFamily = Theme.Font,
                    Foreground = FgHint,
                    FontStyle  = FontStyles.Italic,
                });
                return;
            }

            for (int i = entries.Count - 1; i >= 0; i--)
                _journalEntriesList.Children.Add(BuildJournalRow(entries[i]));
        }

        private Border BuildJournalRow(JournalEntry e)
        {
            bool isSystem = string.Equals(e.Kind, "SessionSummary", StringComparison.OrdinalIgnoreCase);

            // User-friendly kind label
            string kindLabel;
            if (isSystem)
                kindLabel = "End of session";
            else if (string.Equals(e.Kind, "QuickNote", StringComparison.OrdinalIgnoreCase))
                kindLabel = "Note";
            else if (string.Equals(e.Kind, "EmotionTag", StringComparison.OrdinalIgnoreCase))
            {
                string em = e.EmotionString ?? "";
                if (string.Equals(em, "Calm",     StringComparison.OrdinalIgnoreCase)) kindLabel = "Calm";
                else if (string.Equals(em, "Neutral",  StringComparison.OrdinalIgnoreCase)) kindLabel = "Neutral";
                else if (string.Equals(em, "Stressed", StringComparison.OrdinalIgnoreCase)) kindLabel = "Stressed";
                else kindLabel = em;
            }
            else
                kindLabel = e.Kind ?? "";

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(96) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Time + kind (left col)
            var leftStack = new StackPanel();
            leftStack.Children.Add(new TextBlock
            {
                Text       = e.Timestamp.ToString("HH:mm:ss"),
                FontSize   = 11,
                FontFamily = new FontFamily("Consolas"),
                Foreground = isSystem ? FgHint : FgSecondary,
            });
            leftStack.Children.Add(new TextBlock
            {
                Text       = kindLabel,
                FontSize   = 10,
                FontFamily = Theme.Font,
                Foreground = isSystem ? FgHint : FgSecondary,
            });
            Grid.SetColumn(leftStack, 0);
            grid.Children.Add(leftStack);

            // Note + context (right col)
            var midStack = new StackPanel();
            midStack.Children.Add(new TextBlock
            {
                Text         = isSystem && string.IsNullOrWhiteSpace(e.Note)
                                   ? "(auto)"
                                   : string.IsNullOrWhiteSpace(e.Note) ? "(no note)" : e.Note,
                FontSize     = isSystem ? 11 : 12,
                FontFamily   = Theme.Font,
                Foreground   = isSystem ? FgHint
                             : string.IsNullOrWhiteSpace(e.Note) ? FgHint : FgPrimary,
                TextWrapping = TextWrapping.Wrap,
                FontStyle    = isSystem ? FontStyles.Italic : FontStyles.Normal,
            });
            midStack.Children.Add(new TextBlock
            {
                Text = string.Format("PSI {0:F0}  ·  {1}  ·  {2}{3:F2}",
                                     e.Psi,
                                     string.IsNullOrEmpty(e.DominantDim) ? "—" : e.DominantDim,
                                     e.SessionPnl >= 0 ? "+" : "",
                                     e.SessionPnl),
                FontSize   = 9,
                FontFamily = Theme.Font,
                Foreground = FgHint,
                Margin     = new Thickness(0, 2, 0, 0),
            });
            Grid.SetColumn(midStack, 1);
            grid.Children.Add(midStack);

            return new Border
            {
                Background      = isSystem
                    ? new SolidColorBrush(Color.FromArgb(15, 255, 255, 255))
                    : BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb((byte)(isSystem ? 15 : 30), 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(6),
                Padding         = new Thickness(10, 7, 10, 7),
                Margin          = new Thickness(0, 0, 0, 5),
                Child           = grid,
            };
        }

        private Button BuildSimpleButton(string label, bool accent)
        {
            // accent → ghost-emerald (tinted outline + emerald text — no heavy fill, no white
            // text); neutral → card surface. Flat template kills the native blue focus ring.
            Brush bg = accent ? Theme.Tint(Theme.Accent, 20) : BgCard;
            Brush fg = accent ? Theme.Accent : FgPrimary;
            Brush bd = accent ? Theme.Tint(Theme.Accent, 64) : new SolidColorBrush(Color.FromArgb(60, 255, 255, 255));
            return new Button
            {
                Content          = label,
                FontSize         = 12,
                FontFamily       = Theme.Font,
                FontWeight       = FontWeights.SemiBold,
                Foreground       = fg,
                Cursor           = Cursors.Hand,
                FocusVisualStyle = null,
                Template         = Ui.FlatButtonTemplate(bg, bd, 7, 14, 7),
            };
        }

        // =====================================================================
        // Page: Guard
        // =====================================================================

        // Right-rail reference for the Guard workbench: the enforcement ladder + rationale.
        private FrameworkElement BuildGuardLadder()
        {
            var rail = new StackPanel();
            rail.Children.Add(GuardInfoCard("Enforcement ladder", new[]
            {
                new[] { "Notify",               "A quiet toast — a nudge that a line was crossed.", "h" },
                new[] { "Acknowledge",          "A blocking prompt — type to continue.",            "w" },
                new[] { "Pause",                "New entries frozen for a set window.",             "w" },
                new[] { "Disconnect + flatten", "Positions closed, broker severed — day over.",     "b" },
            }));
            var why = new Border
            {
                Background = Theme.BgCard, BorderBrush = Theme.Border, BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(Theme.R3), Padding = new Thickness(16), Margin = new Thickness(0, 14, 0, 0),
            };
            var whyStack = new StackPanel();
            whyStack.Children.Add(new TextBlock { Text = "Why this works", FontFamily = Theme.Font, FontSize = 10, FontWeight = FontWeights.Bold, Foreground = FgHint, Margin = new Thickness(0, 0, 0, 8) });
            whyStack.Children.Add(new TextBlock { Text = "Rules you set when calm, executed automatically when you're not — the mast you tie yourself to before the sirens sing.", FontFamily = Theme.Font, FontSize = 12, Foreground = FgSecondary, TextWrapping = TextWrapping.Wrap, LineHeight = 19 });
            why.Child = whyStack;
            rail.Children.Add(why);
            return rail;
        }

        private FrameworkElement GuardInfoCard(string title, string[][] tiers)
        {
            var card = new Border { Background = Theme.BgCard, BorderBrush = Theme.Border, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(Theme.R3), Padding = new Thickness(16) };
            var sp = new StackPanel();
            sp.Children.Add(new TextBlock { Text = title, FontFamily = Theme.Font, FontSize = 10, FontWeight = FontWeights.Bold, Foreground = FgHint, Margin = new Thickness(0, 0, 0, 12) });
            foreach (var t in tiers)
            {
                Brush dot = t[2] == "b" ? Theme.Bad : t[2] == "w" ? Theme.Warning : Theme.FgHint;
                var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 11) };
                row.Children.Add(new Border { Width = 7, Height = 7, CornerRadius = new CornerRadius(99), Background = dot, VerticalAlignment = VerticalAlignment.Top, Margin = new Thickness(0, 5, 10, 0) });
                var tc = new StackPanel();
                tc.Children.Add(new TextBlock { Text = t[0], FontFamily = Theme.Font, FontSize = 12.5, FontWeight = FontWeights.SemiBold, Foreground = FgPrimary });
                tc.Children.Add(new TextBlock { Text = t[1], FontFamily = Theme.Font, FontSize = 11, Foreground = FgSecondary, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0) });
                row.Children.Add(tc);
                sp.Children.Add(row);
            }
            card.Child = sp;
            return card;
        }

        private FrameworkElement CreateGuardPage()
        {
            var ge = _guardEngine;

            // Visual tree is built by the pure-WPF GuardPageView (shared with the
            // offline UI harness so the Guard tab can be iterated without NT8).
            // Build() renders read-only over `ge`; here we re-attach the LIVE
            // interactivity onto the anchors it exposes, so behavior is unchanged.
            var view = GuardPageView.BuildWithAnchors(ge);

            // ── Master toggle → ge.MasterEnabled ──────────────────────────────
            var masterToggle = view.MasterToggle;
            // refreshList is declared below — capture via a box so the lambda resolves at call time.
            Action refreshListRef = null;
            masterToggle.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                bool next = !(bool)(masterToggle.Tag ?? false);
                // Strict Lock: you committed to keeping Guard on until the clock releases it —
                // turning it off is the bypass you gave up. Refuse, explain, leave it on (the
                // engine setter also enforces this, but we check here to avoid a desynced toggle).
                if (!next && ge != null && ge.IsStrictLockActive)
                {
                    System.Windows.MessageBox.Show(
                        "Strict Lock is active until " + ge.StrictLockUntil.ToString("HH:mm") + ".\n\n" +
                        "You committed to keeping Guard on until then — it can't be turned off early, not even by you. " +
                        (ge.IsDisconnectActive
                            ? "Your broker is disconnected until it releases; manage any open position from your platform's native stops."
                            : "You can still close any open position at any time."),
                        "Strict Lock active", MessageBoxButton.OK, MessageBoxImage.Information);
                    CallbackRecorder.UiEvent("guard", "master_toggle_blocked", "strict_lock");
                    return;
                }
                masterToggle.Tag = (bool?)next;
                CallbackRecorder.UiEvent("guard", "master_toggle", next ? "on" : "off");
                UpdateToggleBtn(masterToggle, next, "Guard ON", "Guard OFF");
                if (ge != null) ge.MasterEnabled = next;
                view.RefreshProtection?.Invoke(); // keep the Protection card (Off/Idle/Armed) in sync — was the stuck-"Idle" bug
                refreshListRef?.Invoke();          // and the in-list active-rules status line
            };

            // ── Active Status Zone (live, ticking) ────────────────────────────
            // Swap the view's static snapshot for the live BuildGuardStatusZone,
            // which runs a DispatcherTimer + early-exit confirmation flow.
            var statusZone = BuildGuardStatusZone(ge, () =>
            {
                // On early exit confirmed: call ForceReset, refresh page.
                _monitor?.ForceResetGuard();
                refreshListRef?.Invoke();
            });
            view.StatusZoneHost.Child = statusZone;

            // ── Rules list (live cards with toggle / edit / delete) ───────────
            var rulesPanel = view.RulesPanel;
            Action refreshList = null;
            refreshList = () =>
            {
                // Keep the master "Guard ON/OFF" pill in sync with the engine. Rule toggles
                // can arm Guard automatically (enabling a rule turns Guard on), so the pill
                // must reflect ge.MasterEnabled — not only its own clicks — or it desyncs
                // (pill shows "OFF" while protection is actually armed).
                bool masterOnSync = ge?.MasterEnabled ?? true;
                masterToggle.Tag = (bool?)masterOnSync;
                UpdateToggleBtn(masterToggle, masterOnSync, "Guard ON", "Guard OFF");

                rulesPanel.Children.Clear();
                var rules = ge?.Rules ?? new List<GuardRule>().AsReadOnly();

                // Active-rules status — clarifies that the "Guard ON" master toggle
                // only protects you when at least one rule is actually ENABLED.
                if (rules.Count > 0)
                {
                    int enabledCount = 0;
                    foreach (var rr in rules) if (rr.Enabled) enabledCount++;
                    bool masterOnNow = ge?.MasterEnabled ?? true;

                    string statusTxt;
                    Brush  statusCol;
                    if (!masterOnNow)
                    {
                        statusTxt = "Guard is off — your rules are paused.";
                        statusCol = new SolidColorBrush(Color.FromRgb(230, 165, 90));
                    }
                    else if (enabledCount == 0)
                    {
                        statusTxt = "Guard is on, but no rules are active — enable one below to be protected.";
                        statusCol = new SolidColorBrush(Color.FromRgb(230, 165, 90));
                    }
                    else
                    {
                        statusTxt = enabledCount + (enabledCount == 1 ? " rule active" : " rules active");
                        statusCol = new SolidColorBrush(Color.FromRgb(91, 201, 140));
                    }
                    rulesPanel.Children.Add(new TextBlock
                    {
                        Text         = statusTxt,
                        FontFamily   = Theme.Font,
                        FontSize     = 11,
                        Foreground   = statusCol,
                        TextWrapping = TextWrapping.Wrap,
                        Margin       = new Thickness(0, 0, 0, 10),
                    });
                }

                if (rules.Count == 0)
                {
                    // First-run guidance card
                    var guideCard = new Border
                    {
                        Background      = new SolidColorBrush(Color.FromArgb(26, 16, 185, 129)),
                        CornerRadius    = new CornerRadius(8),
                        Padding         = new Thickness(14, 12, 14, 14),
                        BorderBrush     = new SolidColorBrush(Color.FromArgb(60, 16, 185, 129)),
                        BorderThickness = new Thickness(1),
                        Margin          = new Thickness(0, 0, 0, 16),
                    };
                    var guideStack = new StackPanel();
                    guideStack.Children.Add(new TextBlock
                    {
                        Text         = "No rules yet",
                        FontSize     = 12,
                        FontFamily   = Theme.Font,
                        FontWeight   = FontWeights.SemiBold,
                        Foreground   = FgPrimary,
                        Margin       = new Thickness(0, 0, 0, 6),
                    });
                    guideStack.Children.Add(new TextBlock
                    {
                        Text         = "Add a rule to protect yourself when emotion takes over. Example:",
                        FontSize     = 11,
                        FontFamily   = Theme.Font,
                        Foreground   = FgSecondary,
                        TextWrapping = TextWrapping.Wrap,
                        Margin       = new Thickness(0, 0, 0, 6),
                    });
                    guideStack.Children.Add(new TextBlock
                    {
                        Text         = "  When PSI < 70  →  Notify me in the HUD",
                        FontSize     = 11,
                        FontFamily   = new FontFamily("Consolas"),
                        Foreground   = FgAccent,
                        Margin       = new Thickness(0, 0, 0, 0),
                    });
                    guideCard.Child = guideStack;
                    rulesPanel.Children.Add(guideCard);
                }
                else
                {
                    foreach (var r in rules)
                    {
                        var ruleCopy = r;
                        rulesPanel.Children.Add(BuildRuleCard(ruleCopy, ge, refreshList));
                    }
                }
                view.RefreshProtection?.Invoke(); // rule enable/disable/add/delete → keep Off/Idle/Armed honest
            };
            refreshListRef = refreshList; // wire the status-zone early-exit lambda
            refreshList();

            // ── Add Rule button → GuardRuleEditorWindow ───────────────────────
            view.AddButton.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                var newRule = new GuardRule { ConfirmationSeconds = 90 };
                var editor = new GuardRuleEditorWindow(newRule, isNew: true, ge, refreshList);
                editor.Show();
            };

            // ── Emergency override → countdown-confirm dialog ─────────────────
            // OverrideButton is only built when no Strict Lock is active (GuardPageView
            // hides Force-reset during a lock). When locked it's null — guard the wiring,
            // or opening Guard while strict-locked throws and the whole page is skipped.
            if (view.OverrideButton != null)
            {
                view.OverrideButton.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    ShowEmergencyOverrideDialog();
                };
            }

            // Strict Lock is now a standing setting (toggle + duration) wired inside
            // GuardPageView's card directly to the engine — no per-button arming here.

            return view.Root;
        }

        private FrameworkElement BuildGuardStatusZone(GuardEngine ge, Action onEarlyExit)
        {
            // Container — hidden when no pause is active, visible with details when active.
            var zone = new Border
            {
                Background      = new SolidColorBrush(Color.FromArgb(40, 242, 129, 138)),
                CornerRadius    = new CornerRadius(8),
                BorderBrush     = new SolidColorBrush(Color.FromRgb(242, 129, 138)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(14, 12, 14, 12),
                Margin          = new Thickness(0, 0, 0, 16),
                Visibility      = Visibility.Collapsed,
            };
            var zoneStack = new StackPanel();
            zone.Child = zoneStack;

            // Title row: status label + progress bar + time remaining
            var titleRow = new Grid();
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var statusLabel = new TextBlock
            {
                FontFamily  = Theme.Font,
                FontSize    = 13,
                FontWeight  = FontWeights.SemiBold,
                Foreground  = new SolidColorBrush(Color.FromRgb(242, 129, 138)),
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(statusLabel, 0);

            var progressBar = new System.Windows.Controls.ProgressBar
            {
                Height     = 8,
                Margin     = new Thickness(12, 0, 12, 0),
                Background = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255)),
                Foreground = new SolidColorBrush(Color.FromRgb(242, 129, 138)),
                BorderThickness = new Thickness(0),
                Minimum    = 0,
                Maximum    = 100,
                Value      = 50,
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(progressBar, 1);

            var timeLabel = new TextBlock
            {
                FontFamily  = new FontFamily("Consolas"),
                FontSize    = 13,
                FontWeight  = FontWeights.Bold,
                Foreground  = new SolidColorBrush(Color.FromRgb(242, 129, 138)),
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(timeLabel, 2);

            titleRow.Children.Add(statusLabel);
            titleRow.Children.Add(progressBar);
            titleRow.Children.Add(timeLabel);
            zoneStack.Children.Add(titleRow);

            // Rule name sub-label
            var ruleNameLabel = new TextBlock
            {
                FontFamily  = Theme.Font,
                FontSize    = 11,
                Foreground  = new SolidColorBrush(Color.FromRgb(200, 140, 130)),
                Margin      = new Thickness(0, 4, 0, 0),
            };
            zoneStack.Children.Add(ruleNameLabel);

            // End Early button row (shown only when AllowEarlyExit is true)
            var earlyExitRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin      = new Thickness(0, 8, 0, 0),
                Visibility  = Visibility.Collapsed,
            };
            var earlyExitBtn = MakeActionBtn("End Early \u25b8",
                new SolidColorBrush(Color.FromRgb(242, 129, 138)));
            earlyExitBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                var rule = ge?.ActivePauseRule;
                if (rule != null && rule.AllowEarlyExit && rule.EarlyExitRequiresPhrase
                    && !string.IsNullOrWhiteSpace(rule.OverridePhrase))
                {
                    // Require phrase confirmation.
                    ShowEarlyExitConfirmDialog(rule.OverridePhrase, onEarlyExit);
                }
                else
                {
                    onEarlyExit?.Invoke();
                }
            };
            earlyExitRow.Children.Add(earlyExitBtn);
            zoneStack.Children.Add(earlyExitRow);

            // Attach a 1-second DispatcherTimer that updates the zone while the page is alive.
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            timer.Tick += (_, __) =>
            {
                if (ge == null || !ge.IsPauseActive)
                {
                    zone.Visibility = Visibility.Collapsed;
                    return;
                }

                zone.Visibility = Visibility.Visible;
                var rule = ge.ActivePauseRule;
                TimeSpan rem = ge.PauseRemaining;
                bool isDayLock = ge.IsDayLockActive;

                string timeStr = rem.TotalHours >= 1
                    ? string.Format("{0:h\\:mm\\:ss}", rem)
                    : string.Format("{0:mm\\:ss}", rem);

                bool isDisconnect = rule == null
                    || rule.Action == GuardActionType.Disconnect
                    || (rule.Action == GuardActionType.TradingPause && rule.PauseMode == PauseModeType.Disconnect);

                statusLabel.Text = isDayLock ? "Day lock"
                    : isDisconnect ? "Trading locked"
                    : "Trading paused";
                timeLabel.Text = timeStr;
                ruleNameLabel.Text = string.Format("Rule: \"{0}\"", rule?.Name ?? "");

                // Progress bar: fraction of pause time remaining (100% at start, 0% at end).
                int durMins = rule != null ? rule.EffectivePauseDurationMinutes : 15;
                double totalSec = durMins == 0 ? 3600 : durMins * 60.0;
                progressBar.Value = totalSec > 0 ? Math.Max(0, Math.Min(100, rem.TotalSeconds / totalSec * 100)) : 0;

                // Strict Lock disables End Early — the early-exit is part of what you locked away.
                earlyExitRow.Visibility = (rule != null && rule.AllowEarlyExit && !(_guardEngine?.IsStrictLockActive ?? false))
                    ? Visibility.Visible : Visibility.Collapsed;
            };

            // Start/stop the timer with the zone's load/unload lifecycle.
            zone.Loaded   += (_, __) => { timer.Start(); };
            zone.Unloaded += (_, __) => timer.Stop();

            // Initial state.
            if (ge != null && ge.IsPauseActive)
                zone.Visibility = Visibility.Visible;

            return zone;
        }

        private void ShowEarlyExitConfirmDialog(string requiredPhrase, Action onConfirmed)
        {
            var win = new Window
            {
                WindowStyle           = WindowStyle.None,
                AllowsTransparency    = false,
                Background            = new SolidColorBrush(Color.FromRgb(28, 28, 30)),
                Width                 = 420,
                SizeToContent         = SizeToContent.Height,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                Topmost               = true,
                ResizeMode            = ResizeMode.NoResize,
            };
            System.Windows.Shell.WindowChrome.SetWindowChrome(win,
                new System.Windows.Shell.WindowChrome { CaptionHeight = 0, ResizeBorderThickness = new Thickness(0) });

            var stack = new StackPanel { Margin = new Thickness(24, 20, 24, 20) };
            stack.Children.Add(new TextBlock
            {
                Text       = "End Trading Pause Early",
                FontFamily = Theme.Font,
                FontSize   = 14,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(245, 245, 247)),
                Margin     = new Thickness(0, 0, 0, 10),
            });
            stack.Children.Add(new TextBlock
            {
                Text         = string.Format("Type your commitment phrase to confirm:\n\"{0}\"", requiredPhrase),
                FontFamily   = Theme.Font,
                FontSize     = 12,
                Foreground   = new SolidColorBrush(Color.FromRgb(174, 174, 178)),
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 12),
            });
            var phraseBox = new System.Windows.Controls.TextBox
            {
                Background      = new SolidColorBrush(Color.FromRgb(48, 48, 50)),
                Foreground      = new SolidColorBrush(Color.FromRgb(245, 245, 247)),
                CaretBrush      = new SolidColorBrush(Color.FromRgb(245, 245, 247)),
                BorderThickness = new Thickness(1),
                BorderBrush     = new SolidColorBrush(Color.FromRgb(70, 70, 73)),
                Padding         = new Thickness(8, 6, 8, 6),
                FontFamily      = Theme.Font,
                FontSize        = 12,
                Margin          = new Thickness(0, 0, 0, 12),
            };
            stack.Children.Add(phraseBox);
            var btnRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            var cancelBtn = new Button
            {
                Content = "Cancel",
                Padding = new Thickness(14, 7, 14, 7),
                Background = new SolidColorBrush(Color.FromRgb(55, 55, 58)),
                Foreground = new SolidColorBrush(Color.FromRgb(245, 245, 247)),
                BorderThickness = new Thickness(0),
                Margin = new Thickness(0, 0, 8, 0),
            };
            var confirmBtn = new Button
            {
                Content = "End Pause",
                Padding = new Thickness(14, 7, 14, 7),
                Background = new SolidColorBrush(Color.FromRgb(242, 129, 138)),
                Foreground = new SolidColorBrush(Colors.White),
                BorderThickness = new Thickness(0),
            };
            cancelBtn.Click += (_, __) => win.Close();
            confirmBtn.Click += (_, __) =>
            {
                if (phraseBox.Text.Trim().Equals(requiredPhrase.Trim(), StringComparison.OrdinalIgnoreCase))
                {
                    win.Close();
                    onConfirmed?.Invoke();
                }
                else
                {
                    phraseBox.BorderBrush = new SolidColorBrush(Color.FromRgb(242, 129, 138));
                }
            };
            btnRow.Children.Add(cancelBtn);
            btnRow.Children.Add(confirmBtn);
            stack.Children.Add(btnRow);
            win.Content = stack;
            win.Show();
        }

        private void ShowEmergencyOverrideDialog()        {
            // Strict Lock makes the emergency override the very thing you gave up. Refuse it
            // (the engine's ForceReset also refuses, defense in depth) and explain.
            if (_guardEngine != null && _guardEngine.IsStrictLockActive)
            {
                // Strict Lock makes the emergency override the very thing you gave up. Refuse it
                // (the engine's ForceReset also refuses, defense in depth) and explain. Developers
                // reset test state via License → Developer Tools → Hard reset, not from here.
                System.Windows.MessageBox.Show(
                    "Strict Lock is active until " + _guardEngine.StrictLockUntil.ToString("HH:mm") + ".\n\n" +
                    "The emergency override is disabled — this is the commitment you set. " +
                    (_guardEngine.IsDisconnectActive
                        ? "Your broker is disconnected until it releases; manage any open position from your platform's native stops."
                        : "You can still close any open position manually at any time; you just can't resume trading early."),
                    "Strict Lock", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            ShowCountdownConfirmDialog(
                "⚠  Emergency Override",
                "This will clear all active Guard states.\n\n" +
                "You set these rules to protect yourself.\n" +
                "Take a moment — the reset will apply automatically.",
                20,
                () =>
                {
                    _monitor?.ForceResetGuard();
                    NinjaTrader.NinjaScript.NinjaScript.Log(
                        "[Guard] Emergency Override applied by user.", NinjaTrader.Cbi.LogLevel.Warning);
                });
        }

        // ── Reusable countdown-confirm dialog ─────────────────────────────────
        // Shows a modal-ish (Topmost) chromeless dark window with a large countdown
        // number and a Cancel button.  If the user does nothing, `onConfirm` fires
        // after `countdownSec` seconds.  Cancelling closes the window silently.
        //
        // Used for all high-risk destructive actions (Emergency Override, Clear
        // History, Reset Baseline) to introduce a mandatory cooling-off pause that
        // cannot be bypassed by mindlessly clicking through a confirmation dialog.
        private void ShowCountdownConfirmDialog(string title, string description,
                                                int countdownSec, Action onConfirm)
        {
            var win = new Window
            {
                WindowStyle           = WindowStyle.None,
                AllowsTransparency    = true,
                Background            = Brushes.Transparent,
                SizeToContent         = SizeToContent.Height,
                Width                 = 440,
                ResizeMode            = ResizeMode.NoResize,
                Topmost               = true,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
            };

            var card = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(22, 14, 14)),
                CornerRadius    = new CornerRadius(12),
                BorderBrush     = new SolidColorBrush(Color.FromRgb(120, 38, 38)),
                BorderThickness = new Thickness(1),
                Margin          = new Thickness(8),
            };

            var stack = new StackPanel { Margin = new Thickness(28, 24, 28, 24) };

            stack.Children.Add(new TextBlock
            {
                Text       = title,
                Foreground = new SolidColorBrush(Color.FromRgb(255, 100, 60)),
                FontFamily = Theme.Font,
                FontSize   = 15,
                FontWeight = FontWeights.SemiBold,
                Margin     = new Thickness(0, 0, 0, 12),
            });

            stack.Children.Add(new TextBlock
            {
                Text         = description,
                Foreground   = new SolidColorBrush(Color.FromRgb(200, 150, 140)),
                FontFamily   = Theme.Font,
                FontSize     = 12,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 22),
            });

            var countdownBlock = new TextBlock
            {
                Text                = countdownSec.ToString(),
                Foreground          = new SolidColorBrush(Color.FromRgb(255, 140, 60)),
                FontFamily          = new FontFamily("Consolas"),
                FontSize            = 56,
                FontWeight          = FontWeights.Bold,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 6),
            };
            stack.Children.Add(countdownBlock);

            stack.Children.Add(new TextBlock
            {
                Text                = "Taking effect automatically…",
                Foreground          = new SolidColorBrush(Color.FromRgb(130, 100, 90)),
                FontFamily          = Theme.Font,
                FontSize            = 11,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 22),
            });

            var cancelBorder = new Border
            {
                Background          = new SolidColorBrush(Color.FromRgb(38, 34, 34)),
                CornerRadius        = new CornerRadius(6),
                Padding             = new Thickness(20, 8, 20, 8),
                Cursor              = Cursors.Hand,
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            cancelBorder.Child = new TextBlock
            {
                Text       = "Cancel",
                Foreground = new SolidColorBrush(Color.FromRgb(180, 155, 150)),
                FontFamily = Theme.Font,
                FontSize   = 12,
            };
            stack.Children.Add(cancelBorder);

            card.Child  = stack;
            win.Content = card;

            bool cancelled = false;
            cancelBorder.MouseLeftButtonDown += (_, __) => { cancelled = true; win.Close(); };

            int remaining = countdownSec;
            var timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            timer.Tick += (_, __) =>
            {
                remaining--;
                if (remaining <= 0)
                {
                    timer.Stop();
                    if (!cancelled)
                    {
                        win.Close();
                        onConfirm?.Invoke();
                    }
                    return;
                }
                countdownBlock.Text = remaining.ToString();
            };

            win.Closed += (_, __) => timer.Stop();
            win.Show();
            timer.Start();
        }

        private Border BuildRuleCard(GuardRule rule, GuardEngine ge, Action refresh)
        {
            // Action-type color + icon (Segoe MDL2 Assets glyphs — monochrome, respect Foreground)
            Color accentColor;
            string iconGlyph;
            switch (rule.Action)
            {
                case GuardActionType.TradingPause:
                case GuardActionType.Disconnect:
                    accentColor = Theme.ColorOf(Theme.Bad);     // soft pastel red, not harsh
                    iconGlyph   = "\uE769"; // Pause glyph
                    break;
                case GuardActionType.Acknowledge:
                case GuardActionType.Countdown:
                    accentColor = Theme.ColorOf(Theme.Warning);
                    iconGlyph   = "\uE8BD"; // Comment/Chat glyph
                    break;
                case GuardActionType.RiskAlert:
                    accentColor = Theme.ColorOf(Theme.Warning);
                    iconGlyph   = "\uE7BA"; // Warning glyph
                    break;
                default: // Toast / Notify
                    accentColor = Theme.ColorOf(Theme.Stable);  // soft green
                    iconGlyph   = "\uEA8F"; // Bell glyph
                    break;
            }

            // ── Card ─────────────────────────────────────────────────────────────
            var outerCard = new Border
            {
                Background      = BgCard,
                CornerRadius    = new CornerRadius(Theme.R3),
                Margin          = new Thickness(0, 0, 0, 8),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(rule.Enabled ? (byte)70 : (byte)25, accentColor.R, accentColor.G, accentColor.B)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(12, 12, 14, 12),
                Effect          = Ui.CardShadow,   // float like the v2 cards
            };
            var accentStrip = new Border
            {
                Width        = 3,
                Background   = new SolidColorBrush(Color.FromArgb(rule.Enabled ? (byte)220 : (byte)55, accentColor.R, accentColor.G, accentColor.B)),
                CornerRadius = new CornerRadius(2, 0, 0, 2),
                Margin       = new Thickness(-12, -12, 0, -12),
            };

            var mainGrid = new Grid();
            mainGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            mainGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            mainGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            mainGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            outerCard.Child = mainGrid;

            Grid.SetColumn(accentStrip, 0);
            mainGrid.Children.Add(accentStrip);

            // ── Icon badge (circle with Segoe MDL2 icon in accent color) ─────────
            byte bgAlpha   = rule.Enabled ? (byte)55  : (byte)20;
            byte bdAlpha   = rule.Enabled ? (byte)100 : (byte)30;
            byte iconAlpha = rule.Enabled ? (byte)230 : (byte)80;
            var iconBg = new Border
            {
                Width           = 38,
                Height          = 38,
                CornerRadius    = new CornerRadius(19),
                Background      = new SolidColorBrush(Color.FromArgb(bgAlpha, accentColor.R, accentColor.G, accentColor.B)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(bdAlpha, accentColor.R, accentColor.G, accentColor.B)),
                BorderThickness = new Thickness(1),
                Margin          = new Thickness(8, 0, 12, 0),
                VerticalAlignment = VerticalAlignment.Center,
                Child = new TextBlock
                {
                    Text       = iconGlyph,
                    FontFamily = new FontFamily("Segoe MDL2 Assets"),
                    FontSize   = 16,
                    Foreground = new SolidColorBrush(Color.FromArgb(iconAlpha, accentColor.R, accentColor.G, accentColor.B)),
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                },
            };
            Grid.SetColumn(iconBg, 1);
            mainGrid.Children.Add(iconBg);

            // ── Text ─────────────────────────────────────────────────────────────
            var textStack = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            Grid.SetColumn(textStack, 2);

            var nameTb = new TextBlock
            {
                Text       = rule.Name,
                FontFamily = Theme.Font,
                FontSize   = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = rule.Enabled ? FgPrimary : FgHint,
            };
            textStack.Children.Add(nameTb);

            var condSummary  = BuildConditionSummary(rule);
            string actionSummary = FormatAction(rule);
            textStack.Children.Add(new TextBlock
            {
                Text         = condSummary + "  →  " + actionSummary,
                FontFamily   = Theme.Font,
                FontSize     = 11,
                Foreground   = rule.Enabled ? FgSecondary : FgHint,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 3, 8, 0),
            });
            mainGrid.Children.Add(textStack);

            // ── Right controls: pill toggle + edit + delete ───────────────────────
            var ctrlStack = new StackPanel
            {
                Orientation       = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(8, 0, 0, 0),
            };
            Grid.SetColumn(ctrlStack, 3);

            // iOS-style pill toggle
            var pillToggle = MakePillToggle(rule.Enabled);
            pillToggle.Margin = new Thickness(0, 0, 10, 0);
            pillToggle.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                rule.Enabled = !rule.Enabled;
                // The rule toggle is the PRIMARY control: enabling any rule arms Guard
                // automatically, so you never also have to flip the master "Guard ON"
                // (that confusing redundant second step). Master stays available as a
                // deliberate global pause. Strict-lock can't be bypassed by this either —
                // MasterEnabled's setter refuses to go false while strict-locked.
                if (rule.Enabled && ge != null && !ge.MasterEnabled)
                    ge.MasterEnabled = true;
                UpdatePillToggle(pillToggle, rule.Enabled);
                byte newStripAlpha = rule.Enabled ? (byte)220 : (byte)55;
                byte newBgAlpha    = rule.Enabled ? (byte)55  : (byte)20;
                byte newBdAlpha    = rule.Enabled ? (byte)100 : (byte)30;
                byte newIconAlpha  = rule.Enabled ? (byte)230 : (byte)80;
                accentStrip.Background  = new SolidColorBrush(Color.FromArgb(newStripAlpha, accentColor.R, accentColor.G, accentColor.B));
                iconBg.Background       = new SolidColorBrush(Color.FromArgb(newBgAlpha,   accentColor.R, accentColor.G, accentColor.B));
                iconBg.BorderBrush      = new SolidColorBrush(Color.FromArgb(newBdAlpha,   accentColor.R, accentColor.G, accentColor.B));
                if (iconBg.Child is TextBlock iconTb)
                    iconTb.Foreground   = new SolidColorBrush(Color.FromArgb(newIconAlpha, accentColor.R, accentColor.G, accentColor.B));
                nameTb.Foreground = rule.Enabled ? FgPrimary : FgHint;
                if (textStack.Children.Count > 1 && textStack.Children[1] is TextBlock sumTb)
                    sumTb.Foreground = rule.Enabled ? FgSecondary : FgHint;
                ge?.UpdateRule(rule);
                refresh?.Invoke(); // resync master pill + Protection card + active-rules status line
            };
            ctrlStack.Children.Add(pillToggle);

            // Edit icon button (pencil)
            var editBtn = MakeIconBtn2("✎", "Edit rule");
            editBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                var editor = new GuardRuleEditorWindow(rule, isNew: false, ge, refresh);
                editor.Show();
            };
            ctrlStack.Children.Add(editBtn);

            // Delete icon button (trash)
            var delBtn = MakeIconBtn2("🗑", "Delete rule");
            delBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                ge?.DeleteRule(rule.Id);
                refresh?.Invoke();
            };
            ctrlStack.Children.Add(delBtn);

            mainGrid.Children.Add(ctrlStack);
            return outerCard;
        }

        private static string BuildConditionSummary(GuardRule rule)
        {
            if (rule.Conditions.Count == 0) return "(no conditions)";
            string logic = rule.Logic == GuardConditionLogic.All ? " AND " : " OR ";
            var parts = new List<string>();
            foreach (var c in rule.Conditions)
            {
                switch (c.Type)
                {
                    case GuardConditionType.PsiBelow:
                        parts.Add(string.Format("PSI < {0}", c.Threshold)); break;
                    case GuardConditionType.ConsecutiveLossesAtLeast:
                        string lossNote = rule.MinLossUsdForStreak > 0
                            ? string.Format(" (>${0:F0})", rule.MinLossUsdForStreak) : "";
                        parts.Add(string.Format("{0} losses\u2265{1}{2}",
                            lossNote.Length > 0 ? "" : "Consecutive ", c.Threshold, lossNote));
                        break;
                    case GuardConditionType.SessionPnlBelow:
                        parts.Add(string.Format("Session P&L below \u2212${0}", c.Threshold)); break;
                    case GuardConditionType.SessionMinutesOver:
                        parts.Add(string.Format("Session time > {0} min", c.Threshold)); break;
                    case GuardConditionType.UnrealizedPnlBelow:
                        parts.Add(string.Format("Floating loss > ${0}", c.Threshold)); break;
                    case GuardConditionType.SingleTradeLossExceeds:
                        parts.Add(string.Format("Single trade loss > ${0}", c.Threshold)); break;
                    default:
                        parts.Add("?"); break;
                }
            }
            return string.Join(logic, parts);
        }

        private static string FormatAction(GuardRule rule)
        {
            switch (rule.Action)
            {
                case GuardActionType.Toast:
                    return "Notify";
                case GuardActionType.Acknowledge:
                case GuardActionType.Countdown:  // legacy, same behaviour
                {
                    var parts = new List<string>();
                    if (!string.IsNullOrWhiteSpace(rule.OverridePhrase))
                        parts.Add("phrase required");
                    if (rule.CountdownSeconds > 0)
                        parts.Add(string.Format("wait {0}s", rule.CountdownSeconds));
                    return parts.Count > 0
                        ? string.Format("Acknowledge ({0})", string.Join(", ", parts))
                        : "Acknowledge";
                }
                case GuardActionType.RiskAlert:
                    return "Alert (persistent)";
                case GuardActionType.TradingPause:
                {
                    int durMins = rule.PauseDurationMinutes;
                    string dur = durMins == 0 ? "rest of day" : string.Format("{0} min", durMins);
                    string mode = rule.PauseMode == PauseModeType.CancelOrders
                        ? "cancel entries" : "disconnect";
                    int sec = rule.EffectiveConfirmationSeconds;
                    string conf = sec > 0 ? string.Format(" after {0}s", sec) : "";
                    return string.Format("Pause {0}{1}, {2}", dur, conf, mode);
                }
                case GuardActionType.Disconnect:
                {
                    int sec = rule.EffectiveConfirmationSeconds;
                    return sec > 0
                        ? string.Format("Disconnect {0} min (after {1}s)", rule.LockMinutes, sec)
                        : string.Format("Disconnect {0} min", rule.LockMinutes);
                }
                default:
                    return "?";
            }
        }

        private static Border MakeToggleBtn(bool isOn, string onText, string offText)
        {
            var tb = new TextBlock
            {
                Text              = isOn ? onText : offText,
                FontFamily        = Theme.Font,
                FontSize          = 11,
                FontWeight        = FontWeights.SemiBold,
                Foreground        = isOn
                                        ? new SolidColorBrush(Color.FromRgb(50, 220, 80))
                                        : new SolidColorBrush(Color.FromRgb(150, 150, 155)),
                VerticalAlignment = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Background    = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                CornerRadius  = new CornerRadius(4),
                Padding       = new Thickness(8, 3, 8, 3),
                Cursor        = Cursors.Hand,
                Child         = tb,
            };
            btn.MouseEnter += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255));
            btn.MouseLeave += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255));
            return btn;
        }

        private static void UpdateToggleBtn(Border btn, bool isOn, string onText, string offText)
        {
            if (btn.Child is TextBlock tb)
            {
                tb.Text       = isOn ? onText : offText;
                tb.Foreground = isOn
                                    ? new SolidColorBrush(Color.FromRgb(50, 220, 80))
                                    : new SolidColorBrush(Color.FromRgb(150, 150, 155));
            }
        }

        // ── iOS-style pill toggle ─────────────────────────────────────────────
        private static Border MakePillToggle(bool isOn)
        {
            var thumb = new Border
            {
                Width             = 18,
                Height            = 18,
                CornerRadius      = new CornerRadius(9),
                Background        = new SolidColorBrush(Colors.White),
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = isOn ? new Thickness(20, 0, 2, 0) : new Thickness(2, 0, 20, 0),
            };
            var track = new Border
            {
                Width             = 42,
                Height            = 24,
                CornerRadius      = new CornerRadius(12),
                Background        = isOn
                                        ? new SolidColorBrush(Color.FromRgb(91, 201, 140))
                                        : new SolidColorBrush(Color.FromRgb(60, 60, 65)),
                Cursor            = Cursors.Hand,
                Child             = thumb,
                // Tag: thumb ref for UpdatePillToggle
                Tag = thumb,
            };
            return track;
        }

        private static void UpdatePillToggle(Border track, bool isOn)
        {
            track.Background = isOn
                ? new SolidColorBrush(Color.FromRgb(91, 201, 140))
                : new SolidColorBrush(Color.FromRgb(60, 60, 65));
            if (track.Child is Border thumb)
                thumb.Margin = isOn ? new Thickness(20, 0, 2, 0) : new Thickness(2, 0, 20, 0);
        }

        // ── Slim icon button for rule card (pencil / trash) ───────────────────
        private static Border MakeIconBtn2(string glyph, string tip)
        {
            var tb = new TextBlock
            {
                Text              = glyph,
                FontSize          = 14,
                Foreground        = FgSecondary,  // brighter base — was FgHint
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            var btn = new Border
            {
                Width         = 30,
                Height        = 30,
                Background    = Brushes.Transparent,
                CornerRadius  = new CornerRadius(6),
                Cursor        = Cursors.Hand,
                Child         = tb,
                ToolTip       = tip,
                Margin        = new Thickness(3, 0, 0, 0),
            };
            btn.MouseEnter += (_, __) =>
            {
                btn.Background = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255));
                tb.Foreground  = FgPrimary;
            };
            btn.MouseLeave += (_, __) =>
            {
                btn.Background = Brushes.Transparent;
                tb.Foreground  = FgSecondary;
            };
            return btn;
        }

        private static Border MakeIconBtn(string glyph, string tip)
        {
            var tb = new TextBlock
            {
                Text              = glyph,
                FontSize          = 14,
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Width         = 32,
                Height        = 28,
                Background    = Brushes.Transparent,
                CornerRadius  = new CornerRadius(4),
                Cursor        = Cursors.Hand,
                Child         = tb,
                ToolTip       = tip,
                Margin        = new Thickness(4, 0, 0, 0),
            };
            btn.MouseEnter += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255));
            btn.MouseLeave += (_, __) =>
                btn.Background = Brushes.Transparent;
            return btn;
        }

        private static Border MakeActionBtn(string text, Brush fg)
        {
            var tb = new TextBlock
            {
                Text              = text,
                FontFamily        = Theme.Font,
                FontSize          = 13,
                Foreground        = fg,
                VerticalAlignment = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Background   = new SolidColorBrush(Color.FromArgb(25, 16, 185, 129)),
                CornerRadius = new CornerRadius(6),
                Padding      = new Thickness(16, 8, 16, 8),
                Cursor       = Cursors.Hand,
                Child        = tb,
            };
            btn.MouseEnter += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(50, 16, 185, 129));
            btn.MouseLeave += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(25, 16, 185, 129));
            Ui.WireLift(btn, 1.5);
            return btn;
        }

        // =====================================================================
        // Page: Settings
        // =====================================================================

        private FrameworkElement CreateSettingsPage()
        {
            // Refresh every time the page renders — accounts may have connected
            // or changed after the Hub was first opened.
            if (_accountsProvider != null)
                _availableAccounts = _accountsProvider() ?? _availableAccounts;

            try
            {
                var source = new ProfileSettingsWindow(_profile, _availableAccounts, _onError,
                                                       accountsProvider: _accountsProvider);
                var card   = TransplantSettingsBody(source);

                // Inject the Display section at the BOTTOM of the profile form StackPanel
                // (after ADVANCED) — display preferences are lowest-priority; users open
                // Settings to configure their trading parameters first.
                // Structure after transplant: Border → DockPanel → [bottomStack (Dock.Bottom),
                //                            ScrollViewer (Fill)] → form (StackPanel).
                var dock   = (card as Border)?.Child as DockPanel;
                var scroll = dock?.Children.OfType<ScrollViewer>().FirstOrDefault();
                var form   = scroll?.Content as StackPanel;
                if (form != null)
                {
                    form.Children.Add(BuildDisplaySettingsSection());
                    form.Children.Add(BuildResearchSettingsSection());
                }

                return card;
            }
            catch
            {
                return BuildEmptyPage("\u26A0", "Error", "Could not load settings.");
            }
        }

        // ── Privacy / research-data opt-out (matches the live Privacy Policy §6,
        // which promises an in-software off switch for anonymized research data) ──
        private FrameworkElement BuildResearchSettingsSection()
        {
            var fgSecondary = new SolidColorBrush(Color.FromRgb(174, 174, 178));
            var fgPrimary   = new SolidColorBrush(Color.FromRgb(245, 245, 247));
            var fgHint      = new SolidColorBrush(Color.FromRgb( 99,  99, 102));

            var section = new StackPanel();
            section.Children.Add(new StackPanel
            {
                Orientation = Orientation.Horizontal, Margin = new Thickness(0, 20, 0, 8),
                Children =
                {
                    new TextBlock { Text = "Privacy", FontSize = 10, FontFamily = Theme.Font, FontWeight = FontWeights.SemiBold, Foreground = fgSecondary, VerticalAlignment = VerticalAlignment.Center },
                },
            });

            bool isOn = !ResearchData.OptedOut;   // on = contributing
            var pill  = MakePillToggle(isOn);

            var row = new Grid { Margin = new Thickness(0, 4, 0, 0) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var text = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            text.Children.Add(new TextBlock { Text = "Contribute anonymized research data", FontSize = 13, FontFamily = Theme.Font, Foreground = fgPrimary });
            text.Children.Add(new TextBlock
            {
                Text = "Anonymized trade activity + discipline signals, used to improve Meridian and research trading psychology. No name, account numbers, credentials, or balances. Turn off to be excluded.",
                FontSize = 11, FontFamily = Theme.Font, Foreground = fgHint, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 12, 0),
            });
            Grid.SetColumn(text, 0); row.Children.Add(text);
            pill.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(pill, 1); row.Children.Add(pill);
            pill.MouseLeftButtonDown += (_, __) =>
            {
                isOn = !isOn;
                ResearchData.SetOptOut(!isOn);   // off → opted out
                UpdatePillToggle(pill, isOn);
            };
            section.Children.Add(row);
            return section;
        }

        // ── Display Settings inline section ──────────────────────────────────
        // Visual style matches the ProfileSettingsWindow sections exactly:
        // same fonts, same muted secondary header, same field sizes.

        private FrameworkElement BuildDisplaySettingsSection()
        {
            var current = _monitor?.CurrentDisplaySettings ?? new DisplaySettings();

            // ── Reuse same palette as ProfileSettingsWindow ──────────────────
            var fgSecondary = new SolidColorBrush(Color.FromRgb(174, 174, 178));
            var fgPrimary   = new SolidColorBrush(Color.FromRgb(245, 245, 247));
            var fgHint      = new SolidColorBrush(Color.FromRgb( 99,  99, 102));
            var bgAccent    = Color.FromRgb(16, 185, 129);

            // Section header (same style as SectionRow in ProfileSettingsWindow)
            var header = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 20, 0, 8),
            };
            header.Children.Add(new TextBlock
            {
                Text              = "Display",
                FontSize          = 10,
                FontFamily        = Theme.Font,
                FontWeight        = FontWeights.SemiBold,
                Foreground        = fgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            });

            var section = new StackPanel();
            section.Children.Add(header);

            // ── Mode row ─────────────────────────────────────────────────────
            section.Children.Add(MakeDisplayLabel("Display Mode", fgSecondary));

            var modeOptions = new[]
            {
                (HudDisplayMode.Minimal,  "Minimal",  "Composure gauge only — no signal bars"),
                (HudDisplayMode.Standard, "Standard", "Gauge + dimmed signal bars (default)"),
                (HudDisplayMode.Full,     "Full",     "Gauge + all signal bars at full brightness"),
            };
            var selMode     = current.Mode;
            var modePills   = new Border[3];
            var modeRow     = MakeOptionRow();
            for (int i = 0; i < 3; i++)
            {
                int   idx = i;
                var   opt = modeOptions[i];
                var   pill = MakeOptionPill(opt.Item2, opt.Item3, opt.Item1 == selMode, bgAccent, fgPrimary, fgHint);
                modePills[i] = pill;
                pill.MouseLeftButtonDown += (_, __) =>
                {
                    selMode = opt.Item1;
                    for (int k = 0; k < 3; k++) SetPillSelected(modePills[k], k == idx, bgAccent);
                };
                modeRow.Children.Add(pill);
            }
            section.Children.Add(modeRow);

            // ── Pressure row ─────────────────────────────────────────────────
            section.Children.Add(MakeDisplayLabel("Stress indicator", fgSecondary));

            // The corner stress badge auto-shows when emotional pressure is high.
            // This selector controls whether a numeric readout also appears in the
            // SESSION stats row for traders who want a precise value.
            var pressureOptions = new[]
            {
                (HudPressureDisplay.GaugeRing, "Badge only",     "Small colored badge in the corner (default)"),
                (HudPressureDisplay.Both,      "Badge + number", "Badge + exact stress value in the stats row"),
                (HudPressureDisplay.Number,    "Number only",    "Stats row number only, no corner badge"),
            };
            var selPressure   = current.PressureDisplay;
            var pressurePills = new Border[3];
            var pressureRow   = MakeOptionRow();
            for (int i = 0; i < 3; i++)
            {
                int  idx = i;
                var  opt = pressureOptions[i];
                var  pill = MakeOptionPill(opt.Item2, opt.Item3, opt.Item1 == selPressure, bgAccent, fgPrimary, fgHint);
                pressurePills[i] = pill;
                pill.MouseLeftButtonDown += (_, __) =>
                {
                    selPressure = opt.Item1;
                    for (int k = 0; k < 3; k++) SetPillSelected(pressurePills[k], k == idx, bgAccent);
                };
                pressureRow.Children.Add(pill);
            }
            section.Children.Add(pressureRow);

            // ── Save button ───────────────────────────────────────────────────
            var saveLbl = new TextBlock
            {
                Text       = "Save",
                FontSize   = 10,
                FontFamily = Theme.Font,
                FontWeight = FontWeights.SemiBold,
                Foreground = Theme.AccentInk,
                Padding    = new Thickness(0),
            };
            var saveBtn = new Border
            {
                Background        = new SolidColorBrush(bgAccent),
                CornerRadius      = new CornerRadius(5),
                Padding           = new Thickness(14, 5, 14, 5),
                Cursor            = Cursors.Hand,
                Margin            = new Thickness(0, 10, 0, 0),
                HorizontalAlignment = HorizontalAlignment.Left,
                Child             = saveLbl,
            };
            saveBtn.MouseLeftButtonDown += (_, __) =>
            {
                _monitor?.UpdateDisplaySettings(new DisplaySettings
                {
                    Mode            = selMode,
                    PressureDisplay = selPressure,
                });
                saveLbl.Text = "Saved \u2713";
                var t = new System.Windows.Threading.DispatcherTimer
                    { Interval = TimeSpan.FromSeconds(1.5) };
                t.Tick += (tt, ___) => { saveLbl.Text = "Save"; (tt as System.Windows.Threading.DispatcherTimer)?.Stop(); };
                t.Start();
            };
            section.Children.Add(saveBtn);

            // Bottom separator — same as between other sections
            section.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 16, 0, 0),
            });

            return section;
        }

        private static TextBlock MakeDisplayLabel(string text, Brush fg) => new TextBlock
        {
            Text       = text,
            FontSize   = 10,
            FontFamily = Theme.Font,
            Foreground = fg,
            Margin     = new Thickness(0, 6, 0, 5),
        };

        private static WrapPanel MakeOptionRow() => new WrapPanel
        {
            Orientation = Orientation.Horizontal,
            Margin      = new Thickness(0, 0, 0, 2),
        };

        private static Border MakeOptionPill(string title, string tip, bool selected,
                                             Color accent, Brush fgPrimary, Brush fgHint)
        {
            var inner = new StackPanel { Margin = new Thickness(10, 6, 10, 6) };
            inner.Children.Add(new TextBlock
            {
                Text       = title,
                FontSize   = 10,
                FontFamily = Theme.Font,
                FontWeight = FontWeights.SemiBold,
                Foreground = fgPrimary,
            });
            inner.Children.Add(new TextBlock
            {
                Text         = tip,
                FontSize     = 9,
                FontFamily   = Theme.Font,
                Foreground   = fgHint,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 1, 0, 0),
            });
            var pill = new Border
            {
                Child           = inner,
                Width           = 158,
                Margin          = new Thickness(0, 0, 8, 0),
                CornerRadius    = new CornerRadius(6),
                BorderThickness = new Thickness(1.5),
                Cursor          = Cursors.Hand,
                ToolTip         = tip,
            };
            SetPillSelected(pill, selected, accent);
            return pill;
        }

        private static void SetPillSelected(Border pill, bool selected, Color accent)
        {
            pill.Background  = selected
                ? new SolidColorBrush(Color.FromArgb(45, accent.R, accent.G, accent.B))
                : new SolidColorBrush(Color.FromArgb(18, 255, 255, 255));
            pill.BorderBrush = selected
                ? new SolidColorBrush(accent)
                : new SolidColorBrush(Color.FromArgb(35, 255, 255, 255));
        }

        /// <summary>
        /// ProfileSettingsWindow has a different structure:
        /// Content = Grid(outer) → [Border(card, col0 row0), resize zones]
        /// card → DockPanel → [titleBar(top), bottomStack(bottom), scroll(fill)]
        /// We extract the card, strip the title bar, and return it.
        /// </summary>
        private static FrameworkElement TransplantSettingsBody(ProfileSettingsWindow source)
        {
            var outer = source.Content as Grid;
            source.Content = null;
            if (outer == null) return MakeErrorBlock();

            // The card Border is the first child (column 0, row 0)
            Border card = null;
            foreach (UIElement child in outer.Children)
            {
                if (child is Border b && b.Child is DockPanel)
                {
                    card = b;
                    break;
                }
            }
            if (card == null) return MakeErrorBlock();

            outer.Children.Remove(card);

            var dock = card.Child as DockPanel;
            if (dock != null && dock.Children.Count > 0)
            {
                // Remove the title bar (first DockPanel.Top child)
                dock.Children.RemoveAt(0);
            }

            card.CornerRadius    = new CornerRadius(0);
            card.BorderThickness = new Thickness(0);
            card.Background      = Brushes.Transparent;

            return card;
        }

        // =====================================================================
        // Content transplant helper
        // =====================================================================

        /// <summary>
        /// Extracts the scrollable body from a standard-pattern window:
        ///   Content = Border(card) → Grid(root) → [header(row 0), scroll(row 1)]
        /// Strips the header and card styling, returning the body content.
        /// </summary>
        private static FrameworkElement TransplantWindowBody(Window source)
        {
            var card = source.Content as Border;
            source.Content = null;
            if (card == null) return MakeErrorBlock();

            var root = card.Child as Grid;
            if (root == null) return card;

            // Remove the header (first child, row 0)
            if (root.Children.Count >= 2 && root.RowDefinitions.Count >= 2)
            {
                root.Children.RemoveAt(0);
                root.RowDefinitions.RemoveAt(0);

                // Fix remaining children's row indices
                for (int i = 0; i < root.Children.Count; i++)
                    Grid.SetRow(root.Children[i], i);
            }

            card.CornerRadius    = new CornerRadius(0);
            card.BorderThickness = new Thickness(0);
            card.Background      = Brushes.Transparent;

            return card;
        }

        // =====================================================================
        // Placeholder / error helpers
        // =====================================================================

        private static FrameworkElement BuildEmptyPage(string icon, string title, string message)
        {
            var stack = new StackPanel
            {
                VerticalAlignment   = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(40),
            };

            stack.Children.Add(new TextBlock
            {
                Text                = icon,
                FontSize            = 40,
                Foreground          = FgHint,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 12),
            });

            stack.Children.Add(new TextBlock
            {
                Text                = title,
                FontSize            = 16,
                FontWeight          = FontWeights.SemiBold,
                Foreground          = FgPrimary,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 8),
            });

            stack.Children.Add(new TextBlock
            {
                Text                = message,
                FontSize            = 12,
                Foreground          = FgSecondary,
                TextWrapping        = TextWrapping.Wrap,
                TextAlignment       = TextAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
                MaxWidth            = 300,
            });

            return stack;
        }

        private static TextBlock MakeErrorBlock()
        {
            return new TextBlock
            {
                Text       = "Error loading page content.",
                Foreground = FgSecondary,
                FontSize   = 12,
                Margin     = new Thickness(20),
            };
        }
    }

    // =========================================================================
    // Guard Rule Editor Window
    // =========================================================================

    internal sealed class GuardRuleEditorWindow : Window
    {
        private readonly GuardRule   _rule;
        private readonly bool        _isNew;
        private readonly GuardEngine _engine;
        private readonly Action      _onSaved;

        // ── Palette (aligned to the central Theme tokens) ─────────────────────
        private static readonly SolidColorBrush BgWin    = new SolidColorBrush(Color.FromRgb( 15,  16,  19));
        private static readonly SolidColorBrush BgCard   = new SolidColorBrush(Color.FromRgb( 24,  26,  31));
        private static readonly SolidColorBrush BgInput  = new SolidColorBrush(Color.FromRgb( 36,  39,  46));
        private static readonly SolidColorBrush BgHdr    = new SolidColorBrush(Color.FromRgb( 30,  33,  39));
        private static readonly SolidColorBrush BgSelOn  = new SolidColorBrush(Color.FromArgb( 40,  16, 185, 129));
        private static readonly SolidColorBrush BgSelOff = new SolidColorBrush(Color.FromArgb( 25, 255, 255, 255));
        private static readonly SolidColorBrush BdInput  = new SolidColorBrush(Color.FromRgb( 72,  76,  86));
        private static readonly SolidColorBrush FgPri    = new SolidColorBrush(Color.FromRgb(237, 237, 240));
        private static readonly SolidColorBrush FgSec    = new SolidColorBrush(Color.FromRgb(146, 146, 153));
        private static readonly SolidColorBrush FgHint   = new SolidColorBrush(Color.FromRgb( 94,  94, 101));
        private static readonly SolidColorBrush FgAcc    = new SolidColorBrush(Color.FromRgb( 16, 185, 129));
        private static readonly SolidColorBrush FgSelOn  = new SolidColorBrush(Color.FromRgb( 16, 185, 129));

        static GuardRuleEditorWindow()
        {
            BgWin.Freeze(); BgCard.Freeze(); BgInput.Freeze(); BgHdr.Freeze();
            BgSelOn.Freeze(); BgSelOff.Freeze(); BdInput.Freeze();
            FgPri.Freeze(); FgSec.Freeze(); FgHint.Freeze(); FgAcc.Freeze(); FgSelOn.Freeze();
        }

        private StackPanel _conditionsPanel;
        private string     _windowTitle;

        public GuardRuleEditorWindow(GuardRule rule, bool isNew, GuardEngine engine, Action onSaved)
        {
            _rule    = new GuardRule
            {
                Id               = rule.Id,
                Name             = rule.Name,
                Enabled          = rule.Enabled,
                Logic            = rule.Logic,
                Action           = rule.Action == GuardActionType.Countdown
                                   ? GuardActionType.Acknowledge : rule.Action, // migrate Countdown
                CountdownSeconds = rule.CountdownSeconds,
                LockMinutes      = rule.LockMinutes,
                CustomMessage    = rule.CustomMessage,
                CooldownMinutes  = rule.CooldownMinutes,
                OverridePhrase   = rule.OverridePhrase,
                ConfirmationTicks   = rule.ConfirmationTicks,
                ConfirmationSeconds = rule.ConfirmationSeconds,
                // TradingPause fields
                PauseDurationMinutes     = rule.PauseDurationMinutes,
                PauseMode                = rule.PauseMode,
                AutoFlattenOnPause       = rule.AutoFlattenOnPause,
                BlockReconnectDuringPause = rule.BlockReconnectDuringPause,
                AllowEarlyExit           = rule.AllowEarlyExit,
                EarlyExitRequiresPhrase  = rule.EarlyExitRequiresPhrase,
                MinLossUsdForStreak      = rule.MinLossUsdForStreak,
                BlockTradesWhileAcknowledging = rule.BlockTradesWhileAcknowledging,
                Conditions       = new List<GuardCondition>(),
            };
            foreach (var c in rule.Conditions)
                _rule.Conditions.Add(new GuardCondition { Type = c.Type, Threshold = c.Threshold });

            _isNew       = isNew;
            _engine      = engine;
            _onSaved     = onSaved;
            _windowTitle = isNew ? "Guard — New Rule" : "Guard — Edit Rule";

            WindowStyle           = WindowStyle.None;
            AllowsTransparency    = false;
            Background            = new SolidColorBrush(Color.FromRgb(28, 28, 30));
            Width  = 720;
            // Size to content so the bottom of the config ("When pause activates" and
            // the options under it) is never clipped below the fold; cap to the screen
            // and let the inner ScrollViewer handle anything taller than that.
            SizeToContent         = SizeToContent.Height;
            MaxHeight             = Math.Max(560, SystemParameters.WorkArea.Height - 60);
            MinWidth              = 440;
            MinHeight             = 500;
            ResizeMode            = ResizeMode.CanResize;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            Topmost               = true;

            // WindowChrome removes the 1-px DWM border that Windows adds to all
            // non-transparent frameless windows, while still giving us OS-level
            // resize hit-testing on all four edges.
            System.Windows.Shell.WindowChrome.SetWindowChrome(this,
                new System.Windows.Shell.WindowChrome
                {
                    CaptionHeight         = 0,
                    ResizeBorderThickness = new Thickness(5),
                    GlassFrameThickness   = new Thickness(0),
                });

            Content = BuildShell();
        }

        // ── Outer shell: custom title bar + scrollable content ───────────────
        private FrameworkElement BuildShell()
        {
            var dock = new DockPanel { Background = BgWin };

            // Title bar
            var header = new Border
            {
                Background   = BgHdr,
                BorderBrush  = new SolidColorBrush(Color.FromRgb(55, 55, 58)),
                BorderThickness = new Thickness(0, 0, 0, 1),
                Padding      = new Thickness(16, 10, 10, 10),
            };
            DockPanel.SetDock(header, Dock.Top);

            var headerRow = new Grid();
            headerRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            headerRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var titleTb = new TextBlock
            {
                Text       = _windowTitle,
                FontFamily = Theme.Font,
                FontSize   = 14,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgPri,
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(titleTb, 0);

            // Drag support
            header.MouseLeftButtonDown += (_, e) =>
            {
                if (e.ButtonState == System.Windows.Input.MouseButtonState.Pressed)
                    DragMove();
            };

            var closeBtn = new Border
            {
                Width        = 28,
                Height       = 28,
                CornerRadius = new CornerRadius(4),
                Background   = Brushes.Transparent,
                Cursor       = Cursors.Hand,
                Child        = new TextBlock
                {
                    Text              = "✕",
                    FontSize          = 12,
                    Foreground        = FgSec,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                },
            };
            closeBtn.MouseEnter += (_, __) =>
                closeBtn.Background = new SolidColorBrush(Color.FromRgb(180, 50, 50));
            closeBtn.MouseLeave += (_, __) =>
                closeBtn.Background = Brushes.Transparent;
            closeBtn.MouseLeftButtonDown += (_, __) => Close();
            Grid.SetColumn(closeBtn, 1);

            headerRow.Children.Add(titleTb);
            headerRow.Children.Add(closeBtn);
            header.Child = headerRow;
            dock.Children.Add(header);

            // Scrollable content
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Background = BgWin,
            };
            dock.Children.Add(scroll);

            var root = new StackPanel
            {
                Margin              = new Thickness(24, 24, 24, 48),
                MaxWidth            = 680,
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            scroll.Content = root;
            BuildContent(root);
            return dock;
        }

        private void BuildContent(StackPanel root)
        {
            // ═══════════════════════════════════════════════════════════════════
            // TWO-COLUMN LAYOUT
            //  Left (280px): action selector  |  Right (*): dynamic config panel
            // ═══════════════════════════════════════════════════════════════════

            // Step-number label for the top section
            root.Children.Add(SectionLabel("1 — What should happen when this rule fires?"));

            var topGrid = new Grid { Margin = new Thickness(0, 10, 0, 0) };
            topGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(268) });
            topGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(12) }); // gutter
            topGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            root.Children.Add(topGrid);

            // ── LEFT: action selector ─────────────────────────────────────────
            var leftCol = new StackPanel();
            Grid.SetColumn(leftCol, 0);
            topGrid.Children.Add(leftCol);

            var actionDefs = new (GuardActionType act, string glyph, string label, string desc, Color color, PauseModeType? mode)[]
            {
                (GuardActionType.Toast,        "", "Notify",
                 "Brief banner in the HUD corner. Informational only; does not stop trading.",
                 Color.FromRgb(91, 201, 140), null),
                (GuardActionType.RiskAlert,    "", "Alert",
                 "Persistent HUD warning banner until the condition clears. Non-blocking.",
                 Color.FromRgb(210, 160, 50), null),
                (GuardActionType.Acknowledge,  "", "Acknowledge",
                 "Blocking dialog requiring dismissal. Optional countdown + commitment phrase.",
                 Color.FromRgb(210, 160, 50), null),
                (GuardActionType.TradingPause, "", "Pause",
                 "Freezes NEW entries for a set window; you stay connected. Open positions are left alone unless you also flatten.",
                 Color.FromRgb(210, 160, 50), PauseModeType.CancelOrders),
                (GuardActionType.TradingPause, "", "Disconnect",
                 "Cuts the broker connection for the window; the hardest stop. Can flatten first.",
                 Color.FromRgb(210, 65, 55), PauseModeType.Disconnect),
            };

            // Right-column panels — one per action that has inline config.
            // All start hidden; selectAction shows the correct one.
            var notifyConfigPanel = BuildNotifyConfigPanel();
            var alertConfigPanel  = BuildAlertConfigPanel();
            var ackConfigPanel    = BuildAckConfigPanel();

            var rightCol = new Border { CornerRadius = new CornerRadius(8) };
            Grid.SetColumn(rightCol, 2);
            topGrid.Children.Add(rightCol);

            FrameworkElement PanelForChoice(int idx)
            {
                var d = actionDefs[idx];
                if (d.act == GuardActionType.Toast)       return notifyConfigPanel;
                if (d.act == GuardActionType.RiskAlert)   return alertConfigPanel;
                if (d.act == GuardActionType.Acknowledge) return ackConfigPanel;
                return BuildPauseConfigPanel(d.mode == PauseModeType.Disconnect);
            }

            bool IsChoiceSelected(int idx)
            {
                var d = actionDefs[idx];
                if (d.mode.HasValue)
                {
                    if (_rule.Action == GuardActionType.Disconnect) return d.mode.Value == PauseModeType.Disconnect;
                    return _rule.Action == GuardActionType.TradingPause && _rule.PauseMode == d.mode.Value;
                }
                if (d.act == GuardActionType.Acknowledge)
                    return _rule.Action == GuardActionType.Acknowledge || _rule.Action == GuardActionType.Countdown;
                return _rule.Action == d.act;
            }

            var actionRows = new Border[actionDefs.Length];
            Action<int> selectChoice = sel =>
            {
                var d = actionDefs[sel];
                _rule.Action = d.act;
                if (d.mode.HasValue) _rule.PauseMode = d.mode.Value;
                for (int i = 0; i < actionDefs.Length; i++)
                    UpdateActionRow(actionRows[i], i == sel);
                rightCol.Child = PanelForChoice(sel);
            };

            for (int i = 0; i < actionDefs.Length; i++)
            {
                int ii = i;
                var d = actionDefs[i];
                var row = ActionRadioRow2(d.glyph, d.label, d.desc, d.color, IsChoiceSelected(i));
                row.MouseLeftButtonDown += (_, e) => { e.Handled = true; selectChoice(ii); };
                actionRows[i] = row;
                leftCol.Children.Add(row);
            }

            int seedIdx = 0;
            for (int i = 0; i < actionDefs.Length; i++) if (IsChoiceSelected(i)) { seedIdx = i; break; }
            rightCol.Child = PanelForChoice(seedIdx);

            // ═══════════════════════════════════════════════════════════════════
            // STEP 2: When?  (Conditions — full width below)
            // ═══════════════════════════════════════════════════════════════════
            root.Children.Add(new Border
            {
                Height = 1, Background = new SolidColorBrush(Color.FromRgb(55, 55, 58)),
                Margin = new Thickness(0, 20, 0, 0),
            });
            root.Children.Add(SectionLabel("2 — When should this rule fire?", top: 14));

            var logicRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 6, 0, 8) };
            Border allBtn = null, anyBtn = null;
            Action<GuardConditionLogic> selectLogic = chosen =>
            {
                _rule.Logic = chosen;
                UpdateSelBtn(allBtn, chosen == GuardConditionLogic.All);
                UpdateSelBtn(anyBtn, chosen == GuardConditionLogic.Any);
            };
            allBtn = SelBtn("All  (every condition must match)", _rule.Logic == GuardConditionLogic.All);
            anyBtn = SelBtn("Any  (at least one must match)",    _rule.Logic == GuardConditionLogic.Any);
            allBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; selectLogic(GuardConditionLogic.All); };
            anyBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; selectLogic(GuardConditionLogic.Any); };
            logicRow.Children.Add(allBtn);
            logicRow.Children.Add(anyBtn);
            root.Children.Add(logicRow);

            _conditionsPanel = new StackPanel();
            root.Children.Add(_conditionsPanel);
            RefreshConditionsPanel();

            var addCondBtn = MiniBtn("＋  Add Condition");
            addCondBtn.Margin = new Thickness(0, 6, 0, 0);
            addCondBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                _rule.Conditions.Add(new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 60 });
                RefreshConditionsPanel();
            };
            root.Children.Add(addCondBtn);

            // ═══════════════════════════════════════════════════════════════════
            // SETTINGS ROW: name + cooldown (inline, side by side)
            // ═══════════════════════════════════════════════════════════════════
            root.Children.Add(new Border
            {
                Height = 1, Background = new SolidColorBrush(Color.FromRgb(55, 55, 58)),
                Margin = new Thickness(0, 20, 0, 0),
            });
            root.Children.Add(SectionLabel("3 — Settings", top: 14));

            var settingsGrid = new Grid { Margin = new Thickness(0, 8, 0, 0) };
            settingsGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(3, GridUnitType.Star) });
            settingsGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(12) });
            settingsGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            root.Children.Add(settingsGrid);

            var nameCol = new StackPanel();
            Grid.SetColumn(nameCol, 0);
            nameCol.Children.Add(SectionLabel("Rule name", top: 0));
            var nameBox = InputBox(_rule.Name);
            nameBox.TextChanged += (_, __) => _rule.Name = nameBox.Text;
            nameCol.Children.Add(nameBox);
            settingsGrid.Children.Add(nameCol);

            var coolCol = new StackPanel();
            Grid.SetColumn(coolCol, 2);
            coolCol.Children.Add(SectionLabel("Cooldown (min)", top: 0));
            var coolBox = InputBox(_rule.CooldownMinutes.ToString());
            coolBox.TextChanged += (_, __) => { if (int.TryParse(coolBox.Text, out int v)) _rule.CooldownMinutes = Math.Max(0, v); };
            coolCol.Children.Add(coolBox);
            settingsGrid.Children.Add(coolCol);

            // ── Save / Cancel ─────────────────────────────────────────────────
            root.Children.Add(new Border
            {
                Height = 1, Background = new SolidColorBrush(Color.FromRgb(55, 55, 58)),
                Margin = new Thickness(0, 18, 0, 0),
            });

            var btns = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 14, 0, 0),
            };

            var cancelBtn = ActionBtn("Cancel", Color.FromRgb(55, 55, 58));
            cancelBtn.Click += (_, __) => Close();

            var saveBtn = ActionBtn("Save Rule", Color.FromRgb(16, 185, 129));
            saveBtn.Click += (_, __) =>
            {
                if (_rule.Conditions.Count == 0)
                {
                    System.Windows.MessageBox.Show(
                        "Please add at least one condition.", "Guard",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                if (string.IsNullOrWhiteSpace(_rule.Name))
                    _rule.Name = "Unnamed Rule";

                if (_isNew) _engine?.AddRule(_rule);
                else        _engine?.UpdateRule(_rule);

                _onSaved?.Invoke();
                Close();
            };

            btns.Children.Add(cancelBtn);
            btns.Children.Add(saveBtn);
            root.Children.Add(btns);
        }

        // ── Acknowledge config panel (right column) ───────────────────────────
        // ── Notify config panel (right column) ───────────────────────────────
        private FrameworkElement BuildNotifyConfigPanel()
        {
            var panel = new Border
            {
                Background   = new SolidColorBrush(Color.FromArgb(20, 255, 255, 255)),
                CornerRadius = new CornerRadius(8),
                Padding      = new Thickness(14, 12, 14, 12),
            };
            var stack = new StackPanel();
            panel.Child = stack;

            stack.Children.Add(SectionLabel("Custom message  (optional)", top: 0));
            stack.Children.Add(new TextBlock
            {
                Text = "Override the default alert text shown in the HUD banner. Leave blank to use the automatic message.",
                FontFamily = Theme.Font, FontSize = 11, Foreground = FgSec,
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 6),
            });
            var msgBox = new System.Windows.Controls.TextBox
            {
                Text = _rule.CustomMessage, AcceptsReturn = false, TextWrapping = TextWrapping.Wrap,
                Background = BgInput, Foreground = FgPri, CaretBrush = FgPri,
                BorderThickness = new Thickness(1), BorderBrush = BdInput,
                Padding = new Thickness(8, 6, 8, 6), FontFamily = Theme.Font,
                FontSize = 12, Margin = new Thickness(0, 0, 0, 12),
            };
            msgBox.TextChanged += (_, __) => _rule.CustomMessage = msgBox.Text;
            stack.Children.Add(msgBox);

            stack.Children.Add(SectionLabel("Banner stays visible for (seconds)", top: 0));
            stack.Children.Add(new TextBlock
            {
                Text = "How long the HUD banner lingers before fading. 0 = use the default (8 s).",
                FontFamily = Theme.Font, FontSize = 11, Foreground = FgSec,
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 6),
            });
            var durBox = InputBox(_rule.ToastDurationSeconds.ToString());
            durBox.TextChanged += (_, __) =>
            {
                if (int.TryParse(durBox.Text, out int v))
                    _rule.ToastDurationSeconds = Math.Max(0, v);
            };
            stack.Children.Add(durBox);

            return panel;
        }

        // ── Alert config panel (right column) ────────────────────────────────
        private FrameworkElement BuildAlertConfigPanel()
        {
            var panel = new Border
            {
                Background   = new SolidColorBrush(Color.FromArgb(20, 255, 255, 255)),
                CornerRadius = new CornerRadius(8),
                Padding      = new Thickness(14, 12, 14, 12),
            };
            var stack = new StackPanel();
            panel.Child = stack;

            stack.Children.Add(SectionLabel("Custom message  (optional)", top: 0));
            stack.Children.Add(new TextBlock
            {
                Text = "Override the default warning text shown persistently in the HUD. Leave blank to use the automatic message.",
                FontFamily = Theme.Font, FontSize = 11, Foreground = FgSec,
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 6),
            });
            var msgBox = new System.Windows.Controls.TextBox
            {
                Text = _rule.CustomMessage, AcceptsReturn = false, TextWrapping = TextWrapping.Wrap,
                Background = BgInput, Foreground = FgPri, CaretBrush = FgPri,
                BorderThickness = new Thickness(1), BorderBrush = BdInput,
                Padding = new Thickness(8, 6, 8, 6), FontFamily = Theme.Font,
                FontSize = 12,
            };
            msgBox.TextChanged += (_, __) => _rule.CustomMessage = msgBox.Text;
            stack.Children.Add(msgBox);

            return panel;
        }

        private FrameworkElement BuildAckConfigPanel()
        {
            var panel = new Border
            {
                Background      = new SolidColorBrush(Color.FromArgb(20, 255, 255, 255)),
                CornerRadius    = new CornerRadius(8),
                Padding         = new Thickness(14, 12, 14, 12),
            };
            var stack = new StackPanel();
            panel.Child = stack;

            stack.Children.Add(SectionLabel("Commitment Phrase", top: 0));
            stack.Children.Add(new TextBlock
            {
                Text = "What would calm-you say to tilt-you? Leave blank for a simple OK button.",
                FontFamily = Theme.Font, FontSize = 11, Foreground = FgSec,
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 6),
            });
            var phraseBox = new System.Windows.Controls.TextBox
            {
                Text = _rule.OverridePhrase,
                AcceptsReturn = false, TextWrapping = TextWrapping.Wrap,
                Background = BgInput, Foreground = FgPri, CaretBrush = FgPri,
                BorderThickness = new Thickness(1), BorderBrush = BdInput,
                Padding = new Thickness(8, 6, 8, 6), FontFamily = Theme.Font,
                FontSize = 12, Margin = new Thickness(0, 0, 0, 10),
            };
            phraseBox.TextChanged += (_, __) => _rule.OverridePhrase = phraseBox.Text;
            stack.Children.Add(phraseBox);

            stack.Children.Add(SectionLabel("Lock OK button for (seconds)", top: 10));
            stack.Children.Add(new TextBlock
            {
                Text = "Prevents immediate dismissal. Set to 0 to allow instant OK.",
                FontFamily = Theme.Font, FontSize = 11, Foreground = FgSec,
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 6),
            });
            var cdBox = InputBox(_rule.CountdownSeconds.ToString());
            cdBox.TextChanged += (_, __) => { if (int.TryParse(cdBox.Text, out int v)) _rule.CountdownSeconds = Math.Max(0, v); };
            stack.Children.Add(cdBox);

            // Block-trades toggle
            stack.Children.Add(SectionLabel("Block new trades while open", top: 12));
            stack.Children.Add(new TextBlock
            {
                Text = "Cancel any new entry order until you acknowledge. Works like a temporary trading pause.",
                FontFamily = Theme.Font, FontSize = 11, Foreground = FgSec,
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 6),
            });
            var blockTradesRow = CheckRow("Block new entry orders until acknowledged", _rule.BlockTradesWhileAcknowledging);
            blockTradesRow.Tag = (bool?)_rule.BlockTradesWhileAcknowledging;
            blockTradesRow.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                _rule.BlockTradesWhileAcknowledging = !(bool)(blockTradesRow.Tag ?? false);
                blockTradesRow.Tag = (bool?)_rule.BlockTradesWhileAcknowledging;
                UpdateCheckRow(blockTradesRow, _rule.BlockTradesWhileAcknowledging);
            };
            stack.Children.Add(blockTradesRow);

            return panel;
        }

        // ── TradingPause config panel (right column) ──────────────────────────
        private FrameworkElement BuildPauseConfigPanel(bool isDisconnect)
        {
            var panel = new Border
            {
                Background   = new SolidColorBrush(Color.FromArgb(20, 255, 255, 255)),
                CornerRadius = new CornerRadius(8),
                Padding      = new Thickness(14, 12, 14, 12),
            };
            var stack = new StackPanel();
            panel.Child = stack;

            // Duration row
            var durGrid = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            durGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            durGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(8) });
            durGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            stack.Children.Add(SectionLabel("Duration", top: 0));
            var durBox = InputBox(_rule.PauseDurationMinutes.ToString());
            durBox.TextChanged += (_, __) => { if (int.TryParse(durBox.Text, out int v)) _rule.PauseDurationMinutes = Math.Max(0, v); };
            Grid.SetColumn(durBox, 0);
            var durHint = new TextBlock
            {
                Text = "min  (0 = rest of day)",
                FontFamily = Theme.Font, FontSize = 11,
                Foreground = FgSec, VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(8, 0, 0, 0),
            };
            Grid.SetColumn(durHint, 2);
            durGrid.Children.Add(durBox);
            durGrid.Children.Add(durHint);
            stack.Children.Add(durGrid);

            // Mode is set by the chosen action card (Pause vs Disconnect) - no in-panel toggle.
            stack.Children.Add(new TextBlock
            {
                Text = isDisconnect
                    ? "Cuts the broker connection for the full duration. The hardest stop."
                    : "New entry orders are auto-cancelled the instant they are placed. You stay connected.",
                FontFamily = Theme.Font, FontSize = 11, Foreground = FgSec,
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 10),
            });

            // Grace period
            stack.Children.Add(SectionLabel("Grace period before activating (seconds)", top: 2));
            stack.Children.Add(new TextBlock
            {
                Text = "How long the condition must persist before Guard acts. Prevents a brief spike from triggering a full pause. 0 = fire immediately.",
                FontFamily = Theme.Font, FontSize = 11, Foreground = FgSec,
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 4),
            });
            int initialConfSec = _rule.ConfirmationSeconds > 0
                ? _rule.ConfirmationSeconds
                : (_rule.ConfirmationTicks > 1 ? _rule.ConfirmationTicks * 30 : 0);
            var confBox = InputBox(initialConfSec.ToString());
            confBox.Margin = new Thickness(0, 0, 0, 10);
            confBox.TextChanged += (_, __) =>
            {
                if (int.TryParse(confBox.Text, out int v))
                {
                    _rule.ConfirmationSeconds = Math.Max(0, v);
                    _rule.ConfirmationTicks = v <= 0 ? 1 : Math.Max(1, (v + 29) / 30);
                }
            };
            stack.Children.Add(confBox);

            // When pause activates
            stack.Children.Add(SectionLabel("When pause activates", top: 2));

            var autoFlattenCheck = CheckRow("Close all open positions immediately", _rule.AutoFlattenOnPause);
            autoFlattenCheck.Tag = (bool?)_rule.AutoFlattenOnPause;
            autoFlattenCheck.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                _rule.AutoFlattenOnPause = !(bool)(autoFlattenCheck.Tag ?? false);
                autoFlattenCheck.Tag = (bool?)_rule.AutoFlattenOnPause;
                UpdateCheckRow(autoFlattenCheck, _rule.AutoFlattenOnPause);
            };
            stack.Children.Add(autoFlattenCheck);

            if (isDisconnect)
            {
                var blockReconnRow = CheckRow("Re-disconnect if I reconnect during the window", _rule.BlockReconnectDuringPause);
                blockReconnRow.Tag = (bool?)_rule.BlockReconnectDuringPause;
                blockReconnRow.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    _rule.BlockReconnectDuringPause = !(bool)(blockReconnRow.Tag ?? false);
                    blockReconnRow.Tag = (bool?)_rule.BlockReconnectDuringPause;
                    UpdateCheckRow(blockReconnRow, _rule.BlockReconnectDuringPause);
                };
                stack.Children.Add(blockReconnRow);
            }

            var earlyExitRow = CheckRow("Allow ending the pause early", _rule.AllowEarlyExit);
            earlyExitRow.Tag = (bool?)_rule.AllowEarlyExit;

            var reqPhraseRow = CheckRow("  └ Must type a phrase to end early", _rule.EarlyExitRequiresPhrase);
            reqPhraseRow.Tag = (bool?)_rule.EarlyExitRequiresPhrase;

            // Helper: grey-out the sub-row when parent is off
            Action refreshReqPhraseEnabled = () =>
            {
                bool parentOn = (bool)(earlyExitRow.Tag ?? false);
                reqPhraseRow.IsHitTestVisible = parentOn;
                reqPhraseRow.Opacity          = parentOn ? 1.0 : 0.35;
            };
            refreshReqPhraseEnabled();

            earlyExitRow.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                _rule.AllowEarlyExit = !(bool)(earlyExitRow.Tag ?? false);
                earlyExitRow.Tag = (bool?)_rule.AllowEarlyExit;
                UpdateCheckRow(earlyExitRow, _rule.AllowEarlyExit);
                refreshReqPhraseEnabled();
            };
            stack.Children.Add(earlyExitRow);

            reqPhraseRow.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                _rule.EarlyExitRequiresPhrase = !(bool)(reqPhraseRow.Tag ?? false);
                reqPhraseRow.Tag = (bool?)_rule.EarlyExitRequiresPhrase;
                UpdateCheckRow(reqPhraseRow, _rule.EarlyExitRequiresPhrase);
            };
            stack.Children.Add(reqPhraseRow);

            return panel;
        }

        // Segmented-toggle pill button for binary choices (e.g. mode selection)
        private static Border ModeToggle(string label, bool selected, bool leftCap)
        {
            var tb = new TextBlock
            {
                Text = label,
                FontFamily = Theme.Font,
                FontSize = 11,
                FontWeight = selected ? FontWeights.SemiBold : FontWeights.Normal,
                Foreground = selected ? FgPri : FgSec,
                VerticalAlignment = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Background = selected
                    ? new SolidColorBrush(Color.FromArgb(200, 10, 80, 200))
                    : new SolidColorBrush(Color.FromRgb(42, 42, 46)),
                BorderBrush = selected
                    ? new SolidColorBrush(Color.FromArgb(160, 16, 185, 129))
                    : new SolidColorBrush(Color.FromRgb(60, 60, 65)),
                BorderThickness = leftCap ? new Thickness(1) : new Thickness(0, 1, 1, 1),
                CornerRadius = leftCap ? new CornerRadius(6, 0, 0, 6) : new CornerRadius(0, 6, 6, 0),
                Padding = new Thickness(14, 7, 14, 7),
                Cursor = Cursors.Hand,
                Child = tb,
                Tag = tb,
            };
            btn.MouseEnter += (_, __) =>
            {
                if (btn.Tag is TextBlock t2 && t2.Foreground == FgSec)
                    btn.Background = new SolidColorBrush(Color.FromRgb(52, 52, 58));
            };
            btn.MouseLeave += (_, __) =>
            {
                if (btn.Tag is TextBlock t2 && t2.Foreground == FgSec)
                    btn.Background = new SolidColorBrush(Color.FromRgb(42, 42, 46));
            };
            return btn;
        }

        private static void UpdateModeToggle(Border btn, bool selected)
        {
            if (btn == null) return;
            btn.Background = selected
                ? new SolidColorBrush(Color.FromArgb(200, 10, 80, 200))
                : new SolidColorBrush(Color.FromRgb(42, 42, 46));
            btn.BorderBrush = selected
                ? new SolidColorBrush(Color.FromArgb(160, 16, 185, 129))
                : new SolidColorBrush(Color.FromRgb(60, 60, 65));
            if (btn.Child is TextBlock tb)
            {
                tb.Foreground  = selected ? FgPri : FgSec;
                tb.FontWeight  = selected ? FontWeights.SemiBold : FontWeights.Normal;
            }
        }

        // ── Action radio row with Segoe MDL2 icon + accent color ─────────────
        private static Border ActionRadioRow2(string glyph, string title, string description, Color accentColor, bool selected)
        {
            var innerDot = new Border
            {
                Width = 8, Height = 8, CornerRadius = new CornerRadius(4),
                Background = FgAcc,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
                Visibility = selected ? Visibility.Visible : Visibility.Collapsed,
            };
            var circle = new Border
            {
                Width = 16, Height = 16, CornerRadius = new CornerRadius(8),
                BorderThickness = new Thickness(2),
                BorderBrush = selected ? FgAcc : FgHint,
                Background  = Brushes.Transparent,
                Margin      = new Thickness(0, 0, 10, 0),
                VerticalAlignment = VerticalAlignment.Center,
                Child = innerDot,
            };

            // Icon circle badge with Segoe MDL2 Assets glyph
            var iconBadge = new Border
            {
                Width        = 30,
                Height       = 30,
                CornerRadius = new CornerRadius(15),
                Background   = new SolidColorBrush(Color.FromArgb(selected ? (byte)50 : (byte)25, accentColor.R, accentColor.G, accentColor.B)),
                BorderBrush  = new SolidColorBrush(Color.FromArgb(selected ? (byte)90 : (byte)40, accentColor.R, accentColor.G, accentColor.B)),
                BorderThickness = new Thickness(1),
                Margin       = new Thickness(0, 0, 10, 0),
                VerticalAlignment = VerticalAlignment.Center,
                Child = new TextBlock
                {
                    Text       = glyph,
                    FontFamily = new FontFamily("Segoe MDL2 Assets"),
                    FontSize   = 14,
                    Foreground = new SolidColorBrush(Color.FromArgb(selected ? (byte)230 : (byte)140, accentColor.R, accentColor.G, accentColor.B)),
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                },
            };

            var titleTb = new TextBlock
            {
                Text = title, FontFamily = Theme.Font,
                FontSize = 12, FontWeight = FontWeights.SemiBold,
                Foreground = selected ? FgPri : FgSec,
            };
            var descTb = new TextBlock
            {
                Text = description, FontFamily = Theme.Font,
                FontSize = 10,
                Foreground = selected ? FgSec : FgHint,  // visible when selected, dim when not
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 2, 0, 0),
            };
            var textStack = new StackPanel();
            textStack.Children.Add(titleTb);
            textStack.Children.Add(descTb);

            var inner = new Grid();
            inner.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // radio circle
            inner.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto }); // icon badge
            inner.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) }); // text
            Grid.SetColumn(circle,    0);
            Grid.SetColumn(iconBadge, 1);
            Grid.SetColumn(textStack, 2);
            inner.Children.Add(circle);
            inner.Children.Add(iconBadge);
            inner.Children.Add(textStack);

            var row = new Border
            {
                Background      = selected ? BgSelOn : Brushes.Transparent,
                BorderThickness = new Thickness(1),
                BorderBrush     = selected
                    ? new SolidColorBrush(Color.FromArgb(80, accentColor.R, accentColor.G, accentColor.B))
                    : new SolidColorBrush(Color.FromRgb(55, 55, 58)),
                CornerRadius = new CornerRadius(7),
                Padding      = new Thickness(10, 9, 10, 9),
                Margin       = new Thickness(0, 0, 0, 5),
                Cursor       = Cursors.Hand,
                Child        = inner,
                // Tag: [circle, innerDot, titleTb, iconBadge, accentColor, descTb]
                Tag          = new object[] { circle, innerDot, titleTb, iconBadge, accentColor, descTb },
            };
            row.MouseEnter += (_, __) =>
            {
                if (row.Tag is object[] t && t[1] is Border d && d.Visibility != Visibility.Visible)
                    row.Background = new SolidColorBrush(Color.FromArgb(15, 255, 255, 255));
            };
            row.MouseLeave += (_, __) =>
            {
                if (row.Tag is object[] t && t[1] is Border d && d.Visibility != Visibility.Visible)
                    row.Background = Brushes.Transparent;
            };
            return row;
        }

        private void RefreshConditionsPanel()
        {
            _conditionsPanel.Children.Clear();
            if (_rule.Conditions.Count == 0)
            {
                _conditionsPanel.Children.Add(new TextBlock
                {
                    Text       = "No conditions yet.",
                    FontFamily = Theme.Font,
                    FontSize   = 11,
                    Foreground = FgHint,
                    Margin     = new Thickness(0, 2, 0, 4),
                });
                return;
            }

            for (int i = 0; i < _rule.Conditions.Count; i++)
            {
                int idx  = i;
                var cond = _rule.Conditions[i];

                var row = new Border
                {
                    Background    = BgCard,
                    CornerRadius  = new CornerRadius(6),
                    Padding       = new Thickness(10, 8, 8, 8),
                    Margin        = new Thickness(0, 0, 0, 6),
                };
                var rowGrid = new Grid();
                rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(110) });
                rowGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(28) });
                row.Child = rowGrid;

                // Condition type picker (styled ComboBox)
                var typePicker = new ComboBox
                {
                    Background      = BgInput,
                    Foreground      = FgPri,
                    BorderThickness = new Thickness(1),
                    BorderBrush     = BdInput,
                    FontFamily      = Theme.Font,
                    FontSize        = 12,
                    Padding         = new Thickness(6, 4, 6, 4),
                    Margin          = new Thickness(0, 0, 8, 0),
                    VerticalContentAlignment = VerticalAlignment.Center,
                };
                typePicker.Items.Add("PSI below");
                typePicker.Items.Add("Consecutive losses \u2265");
                typePicker.Items.Add("Session P&L below \u2212$");
                typePicker.Items.Add("Session time >");
                typePicker.Items.Add("Floating loss exceeds $");
                typePicker.Items.Add("Single trade loss exceeds $");
                typePicker.SelectedIndex = (int)cond.Type;
                typePicker.SelectionChanged += (_, __) =>
                    _rule.Conditions[idx].Type = (GuardConditionType)typePicker.SelectedIndex;
                Grid.SetColumn(typePicker, 0);
                rowGrid.Children.Add(typePicker);

                // Threshold box
                var threshBox = new System.Windows.Controls.TextBox
                {
                    Text            = cond.Threshold.ToString("G"),
                    Background      = BgInput,
                    Foreground      = FgPri,
                    CaretBrush      = FgPri,
                    BorderThickness = new Thickness(1),
                    BorderBrush     = BdInput,
                    Padding         = new Thickness(6, 4, 6, 4),
                    FontFamily      = Theme.Font,
                    FontSize        = 12,
                    VerticalContentAlignment = VerticalAlignment.Center,
                };
                threshBox.TextChanged += (_, __) =>
                {
                    if (double.TryParse(threshBox.Text, out double v))
                        _rule.Conditions[idx].Threshold = v;
                };
                Grid.SetColumn(threshBox, 1);
                rowGrid.Children.Add(threshBox);

                // Remove button
                var remBtn = new Border
                {
                    Width         = 24,
                    Height        = 24,
                    Background    = Brushes.Transparent,
                    CornerRadius  = new CornerRadius(4),
                    Cursor        = Cursors.Hand,
                    Child         = new TextBlock
                    {
                        Text              = "✕",
                        FontSize          = 11,
                        Foreground        = FgHint,
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment   = VerticalAlignment.Center,
                    },
                    VerticalAlignment   = VerticalAlignment.Center,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    Margin = new Thickness(4, 0, 0, 0),
                };
                remBtn.MouseEnter += (_, __) =>
                {
                    remBtn.Background = new SolidColorBrush(Color.FromRgb(120, 40, 40));
                    if (remBtn.Child is TextBlock t) t.Foreground = FgPri;
                };
                remBtn.MouseLeave += (_, __) =>
                {
                    remBtn.Background = Brushes.Transparent;
                    if (remBtn.Child is TextBlock t) t.Foreground = FgHint;
                };
                remBtn.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    _rule.Conditions.RemoveAt(idx);
                    RefreshConditionsPanel();
                };
                Grid.SetColumn(remBtn, 2);
                rowGrid.Children.Add(remBtn);

                _conditionsPanel.Children.Add(row);

                // For "Consecutive losses ≥" — show the min-loss filter inline below
                if (cond.Type == GuardConditionType.ConsecutiveLossesAtLeast)
                {
                    var minLossRow = new StackPanel
                    {
                        Orientation = Orientation.Horizontal,
                        Margin = new Thickness(10, 0, 0, 6),
                    };
                    var minLossLabel = new TextBlock
                    {
                        Text = "Only count losses above $",
                        FontFamily = Theme.Font, FontSize = 11,
                        Foreground = FgSec, VerticalAlignment = VerticalAlignment.Center,
                        Margin = new Thickness(0, 0, 6, 0),
                    };
                    var minLossBox = new System.Windows.Controls.TextBox
                    {
                        Text = _rule.MinLossUsdForStreak.ToString("G"),
                        Width = 70, Background = BgInput, Foreground = FgPri, CaretBrush = FgPri,
                        BorderThickness = new Thickness(1), BorderBrush = BdInput,
                        Padding = new Thickness(6, 3, 6, 3), FontFamily = Theme.Font,
                        FontSize = 11, VerticalContentAlignment = VerticalAlignment.Center,
                    };
                    minLossBox.TextChanged += (_, __) =>
                    {
                        if (double.TryParse(minLossBox.Text, out double v))
                            _rule.MinLossUsdForStreak = Math.Max(0.0, v);
                    };
                    var minLossHint = new TextBlock
                    {
                        Text = "  (0 = count all losses)",
                        FontFamily = Theme.Font, FontSize = 10,
                        Foreground = FgHint, VerticalAlignment = VerticalAlignment.Center,
                    };
                    minLossRow.Children.Add(minLossLabel);
                    minLossRow.Children.Add(minLossBox);
                    minLossRow.Children.Add(minLossHint);
                    _conditionsPanel.Children.Add(minLossRow);
                }
            }
        }

        // ── Widget helpers ────────────────────────────────────────────────────

        private static TextBlock SectionLabel(string text, double top = 0) =>
            new TextBlock
            {
                Text       = text,
                FontFamily = Theme.Font,
                FontSize   = 11,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgSec,
                Margin     = new Thickness(0, top, 0, 0),
            };

        private static System.Windows.Controls.TextBox InputBox(string value) =>
            new System.Windows.Controls.TextBox
            {
                Text            = value,
                Background      = BgInput,
                Foreground      = FgPri,
                CaretBrush      = FgPri,
                BorderThickness = new Thickness(1),
                BorderBrush     = BdInput,
                Padding         = new Thickness(8, 6, 8, 6),
                FontFamily      = Theme.Font,
                FontSize        = 12,
                Margin          = new Thickness(0, 6, 0, 0),
            };

        // "Radio-style" selector button — rounded chip, no OS chrome
        private static Border SelBtn(string text, bool selected)
        {
            var tb = new TextBlock
            {
                Text       = text,
                FontFamily = Theme.Font,
                FontSize   = 12,
                Foreground = selected ? FgSelOn : FgSec,
            };
            var btn = new Border
            {
                Background    = selected ? BgSelOn : BgSelOff,
                CornerRadius  = new CornerRadius(6),
                Padding       = new Thickness(12, 6, 12, 6),
                Margin        = new Thickness(0, 0, 8, 0),
                Cursor        = Cursors.Hand,
                Child         = tb,
                BorderThickness = new Thickness(1),
                BorderBrush     = selected
                                      ? new SolidColorBrush(Color.FromArgb(80, 16, 185, 129))
                                      : new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
            };
            return btn;
        }

        private static void UpdateSelBtn(Border btn, bool selected)
        {
            if (btn == null) return;
            btn.Background   = selected ? BgSelOn : BgSelOff;
            btn.BorderBrush  = selected
                                   ? new SolidColorBrush(Color.FromArgb(80, 16, 185, 129))
                                   : new SolidColorBrush(Color.FromArgb(30, 255, 255, 255));
            if (btn.Child is TextBlock tb)
                tb.Foreground = selected ? FgSelOn : FgSec;
        }

        // ── Radio-row for action selection ────────────────────────────────────
        // Layout: [circle indicator] [title / description]
        private static Border ActionRadioRow(string title, string description, bool selected)
        {
            var innerDot = new Border
            {
                Width               = 8,
                Height              = 8,
                CornerRadius        = new CornerRadius(4),
                Background          = FgAcc,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
                Visibility          = selected ? Visibility.Visible : Visibility.Collapsed,
            };
            var circle = new Border
            {
                Width           = 16,
                Height          = 16,
                CornerRadius    = new CornerRadius(8),
                BorderThickness = new Thickness(2),
                BorderBrush     = selected ? FgAcc : FgHint,
                Background      = Brushes.Transparent,
                Margin          = new Thickness(0, 2, 12, 0),
                VerticalAlignment = VerticalAlignment.Top,
                Child           = innerDot,
            };

            var titleTb = new TextBlock
            {
                Text       = title,
                FontFamily = Theme.Font,
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = selected ? FgPri : FgSec,
            };
            var descTb = new TextBlock
            {
                Text         = description,
                FontFamily   = Theme.Font,
                FontSize     = 11,
                Foreground   = FgHint,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 3, 0, 0),
            };
            var textStack = new StackPanel();
            textStack.Children.Add(titleTb);
            textStack.Children.Add(descTb);

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            Grid.SetColumn(circle,    0);
            Grid.SetColumn(textStack, 1);
            grid.Children.Add(circle);
            grid.Children.Add(textStack);

            var row = new Border
            {
                Background      = selected ? BgSelOn : Brushes.Transparent,
                BorderThickness = new Thickness(1),
                BorderBrush     = selected
                                      ? new SolidColorBrush(Color.FromArgb(80, 16, 185, 129))
                                      : new SolidColorBrush(Color.FromRgb(55, 55, 58)),
                CornerRadius    = new CornerRadius(6),
                Padding         = new Thickness(12, 10, 12, 10),
                Margin          = new Thickness(0, 0, 0, 4),
                Cursor          = Cursors.Hand,
                Child           = grid,
                // Tag stores refs for UpdateActionRow: [circle, innerDot, titleTb, row itself]
                Tag             = new object[] { circle, innerDot, titleTb },
            };
            row.MouseEnter += (_, __) =>
            {
                if (row.Tag is object[] t2 && t2[1] is Border d && d.Visibility != Visibility.Visible)
                    row.Background = new SolidColorBrush(Color.FromArgb(15, 255, 255, 255));
            };
            row.MouseLeave += (_, __) =>
            {
                if (row.Tag is object[] t2 && t2[1] is Border d && d.Visibility != Visibility.Visible)
                    row.Background = Brushes.Transparent;
            };
            return row;
        }

        private static void UpdateActionRow(Border row, bool selected)
        {
            if (!(row?.Tag is object[] refs)) return;
            var circle    = refs[0] as Border;
            var dot       = refs[1] as Border;
            var titleTb   = refs[2] as TextBlock;
            // refs[3] = iconBadge (Border), refs[4] = accentColor (Color), refs[5] = descTb (TextBlock)
            var iconBadge = refs.Length > 3 ? refs[3] as Border : null;
            Color accentColor = refs.Length > 4 && refs[4] is Color c ? c : Color.FromRgb(16, 185, 129);
            var descTb    = refs.Length > 5 ? refs[5] as TextBlock : null;

            row.Background  = selected ? BgSelOn : Brushes.Transparent;
            row.BorderBrush = selected
                ? new SolidColorBrush(Color.FromArgb(80, accentColor.R, accentColor.G, accentColor.B))
                : new SolidColorBrush(Color.FromRgb(55, 55, 58));
            if (circle  != null) circle.BorderBrush = selected ? FgAcc : FgHint;
            if (dot     != null) dot.Visibility     = selected ? Visibility.Visible : Visibility.Collapsed;
            if (titleTb != null) titleTb.Foreground = selected ? FgPri : FgSec;
            if (descTb  != null) descTb.Foreground  = selected ? FgSec : FgHint;
            if (iconBadge != null)
            {
                iconBadge.Background = new SolidColorBrush(Color.FromArgb(selected ? (byte)50 : (byte)25, accentColor.R, accentColor.G, accentColor.B));
                iconBadge.BorderBrush = new SolidColorBrush(Color.FromArgb(selected ? (byte)90 : (byte)40, accentColor.R, accentColor.G, accentColor.B));
                if (iconBadge.Child is TextBlock iconTb)
                    iconTb.Foreground = new SolidColorBrush(Color.FromArgb(selected ? (byte)230 : (byte)140, accentColor.R, accentColor.G, accentColor.B));
            }
        }

        private static Border MiniBtn(string text)
        {
            var btn = new Border
            {
                Background    = new SolidColorBrush(Color.FromArgb(25, 16, 185, 129)),
                CornerRadius  = new CornerRadius(5),
                Padding       = new Thickness(12, 5, 12, 5),
                Cursor        = Cursors.Hand,
                Child         = new TextBlock
                {
                    Text       = text,
                    FontFamily = Theme.Font,
                    FontSize   = 11,
                    Foreground = FgAcc,
                },
            };
            btn.MouseEnter += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(50, 16, 185, 129));
            btn.MouseLeave += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(25, 16, 185, 129));
            Ui.WireLift(btn, 1.5);
            return btn;
        }

        private static Button ActionBtn(string text, Color bg)
        {
            // Luminance-aware ink so the emerald CTA gets DARK text (not white), + a flat
            // rounded template so the native Button shows no grey hover box or blue
            // default-button focus ring (the old "ugly green with white text + blue ring").
            double lum = 0.299 * bg.R + 0.587 * bg.G + 0.114 * bg.B;
            return new Button
            {
                Content          = text,
                Foreground       = lum > 110 ? Theme.AccentInk : FgPri,
                FontFamily       = Theme.Font,
                FontSize         = 13,
                FontWeight       = FontWeights.SemiBold,
                Margin           = new Thickness(8, 0, 0, 0),
                Cursor           = Cursors.Hand,
                FocusVisualStyle = null,
                Template         = Ui.FlatButtonTemplate(new SolidColorBrush(bg), null, 7, 22, 8),
            };
        }

        private static Border CheckRow(string text, bool isChecked)
        {
            var checkBox = new Border
            {
                Width           = 16,
                Height          = 16,
                CornerRadius    = new CornerRadius(3),
                BorderThickness = new Thickness(2),
                BorderBrush     = isChecked ? FgAcc : FgHint,
                Background      = isChecked ? BgSelOn : Brushes.Transparent,
                Margin          = new Thickness(0, 1, 8, 0),
                VerticalAlignment = VerticalAlignment.Center,
                Child = isChecked ? new TextBlock
                {
                    Text = "✓", FontSize = 10, Foreground = FgAcc,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                } : null,
            };
            var label = new TextBlock
            {
                Text       = text,
                FontFamily = Theme.Font,
                FontSize   = 11,
                Foreground = isChecked ? FgPri : FgSec,
                VerticalAlignment = VerticalAlignment.Center,
            };
            var row = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 4, 0, 0),
                Cursor      = Cursors.Hand,
                // Tag stores refs for UpdateCheckRow
                Tag = new object[] { checkBox, label },
            };
            row.Children.Add(checkBox);
            row.Children.Add(label);
            var wrapper = new Border { Child = row, Cursor = Cursors.Hand };
            return wrapper;
        }

        private static void UpdateCheckRow(Border wrapper, bool isChecked)
        {
            if (!(wrapper?.Child is StackPanel row)) return;
            if (!(row.Tag is object[] refs)) return;
            var checkBox = refs[0] as Border;
            var label    = refs[1] as TextBlock;
            if (checkBox != null)
            {
                checkBox.BorderBrush = isChecked ? FgAcc : FgHint;
                checkBox.Background  = isChecked ? BgSelOn : Brushes.Transparent;
                checkBox.Child = isChecked ? new TextBlock
                {
                    Text = "✓", FontSize = 10, Foreground = FgAcc,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                } : null;
            }
            if (label != null)
                label.Foreground = isChecked ? FgPri : FgSec;
        }
    }
}


