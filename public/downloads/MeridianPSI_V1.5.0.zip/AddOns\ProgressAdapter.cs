using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Adapter: SessionHistoryStore (+ profile) -> ProgressData. Pure C# (no NT8,
    /// no WPF). Everything here is derivable from the persisted history:
    /// composure trend, monthly KPIs, calendar, and a couple of honest insights.
    /// The edge-vs-luck split is left empty until size-tracked sessions accrue
    /// (it needs per-trade size, captured from this build forward).
    /// </summary>
    internal static class ProgressAdapter
    {
        // viewMonth = any day in the month being shown (enables prior-month browsing).
        // today    = the real current date, used only to mark "today" + gate forward nav.
        public static ProgressData FromHistory(SessionHistoryStore store, StrategyProfile profile, DateTime viewMonth, DateTime today)
        {
            var d = new ProgressData { MonthLabel = viewMonth.ToString("MMMM yyyy", CultureInfo.InvariantCulture) };

            var all = (store?.Sessions ?? new List<SessionHistoryEntry>())
                      .Where(s => s != null).OrderBy(s => s.Date).ToList();

            // Everything on this page is scoped to the VIEWED month, so navigating months
            // shows a coherent, self-contained picture (matches the old History behaviour).
            var month = all.Where(s => s.Date.Year == viewMonth.Year && s.Date.Month == viewMonth.Month)
                           .OrderBy(s => s.Date).ToList();
            d.Sessions = month.Count;
            d.AvgComposure = month.Count > 0 ? Math.Round(month.Average(s => (double)s.ComposurePct), 0) : 0;
            d.MonthPnl = month.Sum(s => s.TotalPnl);
            d.EdgeShareNow = -1;   // accrues from size-tracked sessions
            d.EdgeSharePrev = -1;
            d.BrokeDown = month.Count(s => s.ComposurePct < 55);

            // this month's sessions, newest first, for the table
            foreach (var s in Enumerable.Reverse(month).Take(8))
                d.RecentSessions.Add(new ProgressSession { Date = s.Date, Composure = s.ComposurePct, Pnl = s.TotalPnl });

            // composure series — this month's sessions, chronological
            foreach (var s in month) d.ComposureSeries.Add(s.ComposurePct);

            // headline from this month's composure trend (first half vs second half)
            string monthName = viewMonth.ToString("MMMM", CultureInfo.InvariantCulture);
            if (month.Count == 0)
            {
                d.Headline = "No sessions in " + monthName + ".";
                d.HeadlineSub = "Nothing was recorded this month.";
            }
            else if (month.Count < 5)
            {
                // Honest low-data state — never render a confident trend verdict on a few sessions.
                d.Headline = "Building your baseline.";
                d.HeadlineSub = "Your discipline trend fills in as you log more sessions — " + month.Count + " this month.";
            }
            else
            {
                int half = Math.Max(1, month.Count / 2);
                double early = month.Take(half).Average(s => (double)s.ComposurePct);
                double late = month.Skip(month.Count - half).Average(s => (double)s.ComposurePct);
                double trend = late - early;
                if (trend >= 4) { d.Headline = "Your composure trended up."; d.HeadlineSub = "Discipline improved across the month — keep doing what's working."; }
                else if (trend <= -4) { d.Headline = "Your composure dipped."; d.HeadlineSub = "Sessions ran below your baseline — worth a look at what changed."; }
                else { d.Headline = "You held steady."; d.HeadlineSub = "Composure was stable across the month."; }
            }

            // honest insights from the month's data
            if (month.Count > 0)
            {
                var best = month.OrderByDescending(s => s.ComposurePct).First();
                var worst = month.OrderBy(s => s.ComposurePct).First();
                // "Stable day" uses the canonical single-source threshold
                // (SessionData.ComposureStableThreshold = 70) so this count matches
                // History / Intelligence; red day = ended in the Critical zone (<55).
                int stableDays = month.Count(s => s.ComposurePct >= SessionData.ComposureStableThreshold);
                int redDays = month.Count(s => s.ComposurePct < 55);

                // Green only when it's genuinely good news; a "0 of N" line must not be green.
                d.Insights.Add(new ProgressInsight { Title = stableDays + " of " + month.Count + " sessions stayed composed", Detail = "composure 70%+ — these are your repeatable days", Accent = stableDays > 0 ? Theme.Stable : Theme.FgSecondary });
                if (redDays > 0)
                    d.Insights.Add(new ProgressInsight { Title = redDays + " session" + (redDays == 1 ? "" : "s") + " broke down (composure < 55%)", Detail = "worst was " + worst.Date.ToString("ddd MMM d", CultureInfo.InvariantCulture) + " at " + worst.ComposurePct + "%", Accent = Theme.Critical });
                d.Insights.Add(new ProgressInsight { Title = "Best session: " + best.Date.ToString("ddd MMM d", CultureInfo.InvariantCulture) + " at " + best.ComposurePct + "%", Detail = "study what you did right that day", Accent = Theme.Accent });
            }

            // calendar (Monday-first) — "today" only marks the current month
            bool isCurMonth = viewMonth.Year == today.Year && viewMonth.Month == today.Month;
            int firstDow = (int)new DateTime(viewMonth.Year, viewMonth.Month, 1).DayOfWeek; // Sunday = 0
            d.FirstBlank = (firstDow + 6) % 7;
            int days = DateTime.DaysInMonth(viewMonth.Year, viewMonth.Month);
            var byDay = new Dictionary<int, SessionHistoryEntry>();
            foreach (var s in month) byDay[s.Date.Day] = s;
            for (int day = 1; day <= days; day++)
            {
                bool has = byDay.TryGetValue(day, out var s2);
                d.Days.Add(new ProgressDay
                {
                    Day = day, HasSession = has, Composure = has ? s2.ComposurePct : 0,
                    IsToday = isCurMonth && day == today.Day, Date = new DateTime(viewMonth.Year, viewMonth.Month, day),
                    Pnl = has ? s2.TotalPnl : 0, Trades = has ? s2.TotalTrades : 0, FinalPsi = has ? s2.FinalPsi : -1,
                });
            }

            return d;
        }
    }
}
