﻿// PsiEngineV2.cs
//
// v2.0 architectural redesign of the PSI inference engine.
//
// ┌───────────────────────────────────────────────────────────────────────┐
// │  Design contract (see ARCHITECTURE.md §15 and                         │
// │   .cursor/rules/psi-v2-evidence-accumulator.mdc for the full rules):  │
// │                                                                       │
// │  Axiom 1 — PSI is an inference over OBSERVED BEHAVIOUR against the   │
// │    trader's DECLARED COMMITMENTS.  P&L, clock time, and streak count  │
// │    are NEVER direct PSI deductions.                                   │
// │                                                                       │
// │  Axiom 2 — Every dimension owns ONE Evidence Accumulator E_i(t).      │
// │    State is a scalar; dynamics are a single first-order ODE plus      │
// │    discrete commit events.  No per-dimension special cases.           │
// │                                                                       │
// │  Axiom 3 — Observations fall into exactly two classes:                │
// │    Class A (Commitment Break) — the trader crossed a self-declared    │
// │       hard limit.  Single event ⇒ saturating evidence ⇒ PSI moves    │
// │       meaningfully (~30–40 pts from that dimension alone).            │
// │    Class B (Behavioural Signal) — behaviour CONSISTENT WITH           │
// │       instability but not conclusive.  Single event ⇒ small evidence  │
// │       (~3 pts); pattern emerges from E(t) accumulation.               │
// │                                                                       │
// │  Axiom 4 — A single Pressure scalar P(t) ∈ [0, 1] is DERIVED from    │
// │    the current observable state (open loser magnitude, loss streak,   │
// │    daily-loss proximity).  P has no memory of its own; it is a pure   │
// │    function of "how pressured is the trader right now".  P amplifies  │
// │    Class B commits (by 1+κP) and gates decay (by 1−P).                │
// │                                                                       │
// │  Axiom 5 — Time flows through ONE clock domain.  The caller supplies  │
// │    an engineTime on every entry point; the engine does not call into  │
// │    TradingClock itself.  A caller that cannot supply a consistent     │
// │    DateTime (e.g. playback is idle with no fills yet) must NOT call   │
// │    the engine.                                                        │
// └───────────────────────────────────────────────────────────────────────┘
//
// Mathematical core (applied on every engine entry point):
//
//   For each dimension i = 1..7:
//     dt = clamp(engineTime - _lastTick, 0, MaxDeltaSec)
//     if dt > 0:  E_i ← E_i × exp(−dt · (1 − P) / τ_decay_i)     (decay)
//     E_i ← E_i + commit_A_i + commit_B_i × (1 + κ · P)         (commit)
//     C_i = (1 − exp(−E_i / τ_sev_i)) × 100                     (severity map)
//
//   PSI = clamp(100 − √(Σ C_i²) − carryDebt, 0, 100)            (aggregation)
//
// Removed vs v1.x (enforced by this file being self-contained — no v1
// state fields, no v1 config reads, no hard-deduction paths):
//   • FatigueDebt, FinancialStressDebt, StreakFloorDebt (hidden EWMAs)
//   • Snap-up / drop-tau / recovery-tau asymmetry
//   • D4PerTradeSingleSampleCap
//   • Per-event drop cap
//   • Frozen-recovery / post-exposure / overexposure-cooldown state
//   • All "hard deduction" paths (session window penalty, naked penalty)
//
// No `using NinjaTrader.Cbi` — all NT8 types consumed via MeridianPSI.

using System;
using System.Collections.Generic;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =====================================================================
    // Commit telemetry shape (public so MeridianPSI + Dashboard can read).
    // CommitClass mirrors the Axiom 3 distinction:
    //   • A (Commitment Break)  — the trader crossed a self-declared hard
    //                             limit.  Single event ⇒ saturating evidence.
    //   • B (Behavioural Signal) — behaviour CONSISTENT WITH instability
    //                             but not conclusive.  Pattern emerges from
    //                             repeated commits.
    // =====================================================================
    public enum CommitClass { None, A, B }

    public struct CommitEvent
    {
        public DateTime    Time;     // EngineTime domain
        public int         Dim;      // 1..7
        public CommitClass Kind;     // A or B (None events are never recorded)
        public double      Amount;   // evidence deposited (post-pressure amplification)
        public double      Pressure; // P(t) at commit time, 0..1
    }

    public sealed class PsiEngineV2
    {
        // =====================================================================
        // Dependencies (injected, immutable)
        // =====================================================================

        private readonly StrategyProfile   _profile;
        private readonly TradeBaseline     _baseline;
        private readonly PsiEngineV2Config _cfg;
        private readonly object            _sync = new object();

        // ── Epoch identity reference ─────────────────────────────────────────
        // Set by StartNewSession (inside lock(_sync)) to the caller-supplied
        // Axiom 8 personalised scale factors (ARCHITECTURE.md §15.10, §15.12,
        // §15.14, §15.15).  Seeded ONCE at construction from profile so the
        // signal all saturating Class A formulas consume is the user-invariant
        // RELATIVE severity (excess / SizeMax, overstay / MaxHoldSec,
        // pastGrace / NoStopGraceSeconds, overshoot / MaxDailyLossUsd,
        // excessTrades / TradesPerSessionMax), NOT absolute contract counts /
        // absolute seconds / absolute dollars.
        //
        // Fallbacks when the profile field is 0 or negative are NOT magic
        // numbers — each is the minimum observation/measurement resolution of
        // the underlying quantity:
        //   _d2Scale       : min 1.0 s  — engine position-poll resolution
        //   _d3Scale       : min 0.01 contracts — integer-count resolution
        //                    floor (covered by D3SaturationScale; retained)
        //   _d5Scale       : min 1800 s (30 min fallback — cold session when
        //                    MaxHoldMinutes is unset) — see §15.14
        //   _d6LossScale   : min $1     — platform account-currency resolution
        //   _d7Scale       : min 1.0    — integer trade-count resolution
        //
        // D6 session-window scale is computed PER CALL (depends on declared
        // window which is two int fields, and correctly handles wrap-midnight
        // sessions) so it isn't cached here.
        private readonly double _d3Scale;
        private readonly double _d5Scale;
        private readonly double _d2Scale;
        private readonly double _d6LossScale;
        private readonly double _d7Scale;

        private Action<string> _debug;

        public void SetDebugLogger(Action<string> logger)
        {
            lock (_sync) _debug = logger;
        }

        // =====================================================================
        // Core state — minimal by design
        //   _E[i]           : per-dimension evidence accumulator.  Dimensionless
        //                     after calibration; τ_sev is expressed in the same
        //                     units so E/τ_sev is unitless.  Always ≥ 0.
        //   _lastTick       : engineTime of the most recent tick that already
        //                     applied decay.  Monotonic; guarded by Max clamp.
        //   _carryDebt      : overnight carry (PSI points); same role as v1.
        // =====================================================================

        private readonly double[] _E = new double[8]; // index 1..7; slot 0 unused
        private DateTime _lastTick = DateTime.MinValue;
        private double   _carryDebt;

        // =====================================================================
        // Derived / observable tracking state (minimal, for P and commits only).
        // None of these directly drive PSI — they are inputs to commit functions
        // and to the pressure computation.
        // =====================================================================

        private double   _consecutiveLosses;
        private DateTime _lastRealizedFillTime = DateTime.MinValue;
        private double   _lastRealizedPnl;
        private int      _lastRealizedDirection;
        private double   _sessionNetPnl;
        private DateTime _sessionFirstEntryTime = DateTime.MinValue;
        private int      _sessionEntryCount;
        private readonly Queue<DateTime> _recentEntryTimes = new Queue<DateTime>();


        // D2 — adverse-move and naked-state tracking.
        //
        // Saturating-marginal Class A anchors the "previous past-grace
        // severity" for the CURRENT naked epoch.  `_prevNakedPastGraceSec`
        // monotonically grows while naked exposure continues past grace,
        // and is reset to 0 when the epoch ends (SL is placed OR position
        // closes).  The marginal formula
        //     ΔE = CommitA_D2 · [(1−e^(−sNow/scale)) − (1−e^(−sPrev/scale))]
        // guarantees total deposit over one naked epoch saturates at
        // CommitA_D2, regardless of how extreme the episode becomes.  No
        // one-shot latch is needed because the marginal goes to zero as
        // sNow → ∞ (saturation).  See ARCHITECTURE.md §15.15.
        private readonly Dictionary<string, double> _prevSlTicks  = new Dictionary<string, double>();
        private DateTime _nakedStateBeganAt    = DateTime.MinValue;
        private double   _prevNakedPastGraceSec;

        // D3 — size tracking (commit jump uses step change in excess)
        private double   _prevSizeOverLimit;
        // When the current oversize episode began.  Class B only fires after
        // NoStopGraceSeconds — the window in which a disciplined trader would
        // recognise and exit an accidental oversize entry.  DateTime.MinValue
        // means no active oversize episode.
        private DateTime _d3OversizeBeganAt = DateTime.MinValue;

        // D5 — worst overstay severity tracked from previous sample (for
        // saturating-marginal Class A, Axiom 6).  Analogous to _prevSizeOverLimit
        // for D3.  Resets to 0 in StartNewSession / ApplyOvernightDecay /
        // OnPositionTrackingCorrection and on flat (no open positions).
        //
        // The historical per-position one-shot latch (`_d5ClassAFiredKeys`)
        // was deleted 2026-04-23 together with the step-function Class A
        // trigger it supported — see `psi-v2-evidence-accumulator.mdc`
        // Anti-pattern 10b.
        private double _prevWorstOverstaySec;

        // D6 — MaxDailyLoss overshoot: saturating-marginal (Axiom 6,
        // ARCHITECTURE.md §15.15).  Anchors the previous overshoot in USD
        // so each deepening of the hole past declared max deposits
        // marginal evidence, and a partial recovery does not ADD evidence
        // (decay removes it over time).  Monotone-max with reset on
        // session boundary so an intra-session partial-recovery-then-
        // re-breach correctly re-accumulates.
        private double _prevD6MaxLossOvershootUsd;

        // D7 — over-budget trade count: saturating-marginal (Axiom 6).
        // Anchors the previous excess-trade count; each new over-budget
        // entry deposits marginal, saturating at CommitA_D7.
        private double _prevD7ExcessTrades;

        // =====================================================================
        // D1 PauseAfterNLosses anchor (Axiom A6 — saturating-marginal)
        // =====================================================================
        // Anchors the previous streak-excess past the declared
        // PauseAfterNLosses threshold.  Mirrors the _prevD6MaxLossOvershootUsd
        // contract exactly: marginal evidence fires only when the trader
        // enters at a NEW deeper excess than we've already paid evidence for.
        // Re-crossing into compliance (streakExcess ≤ 0) snaps anchor to 0
        // so a later re-breach generates a FRESH 0→1 marginal — semantically
        // a new commitment break, not the old one continuing.
        //
        // Replaces the prior step-function: "if excess > 0 then deposit
        // full CommitA_D1."  That formulation made each entry past the
        // threshold indistinguishable in evidence value from the first
        // crossing, and repeated entries past the threshold silently
        // compounded evidence N-fold, violating Axiom 6 (no linear
        // amplification).  See REMEDIATION_PLAN_v1.2.md Part 11.
        //
        // Reset: StartNewSession / ApplyOvernightDecay to 0 (streak itself
        // resets). Preserved across OnPositionTrackingCorrection — this is
        // session behavioural history, not position-tracking state.
        // =====================================================================
        private double _prevD1StreakExcess;

        // Instantaneous C_i values, cached for public accessors.
        private readonly double[] _C = new double[8];
        private double _psi = 100.0;
        private double _pressureForHud;
        // Pressure used exclusively for decay gating (1−P gate in AdvanceTime).
        // Equals P_raw — the max of openLoserFactor, streakFactor, dailyProxFactor,
        // sessionHourFactor — WITHOUT the behavioralStrainFactor.  Rationale:
        // behavioralStrainFactor captures past-evidence tilt; it should amplify the
        // NEXT impulsive Class B commit (via _pressureForHud) but must NOT slow
        // recovery once the position is flat.  Using the full P in the decay gate
        // creates a self-reinforcing lock: PSI drop → P rises → decay stalls → PSI
        // stays low → P stays high → permanent lock.  Real stressors (open loser,
        // streak, daily-loss approach) legitimately slow recovery; behavioral history
        // does not — the trader needs a real chance to recover between sessions.
        private double _pressureForDecay;
        // EWMA-smoothed pressure for display only (τ ≈ 8 updates ≈ 16 s at 2 s poll).
        // P_raw drives all math (Class B amplification, decay gating); this field
        // is read exclusively by the HUD chip and the timeline shadow.
        // α = 0.18 → half-life ≈ 3.5 updates ≈ 7 s; smooth enough to eliminate the
        // 0→50 jump from a single loss, fast enough to reflect a genuine streak.
        private const  double PDisplayAlpha    = 0.18;
        private double _pDisplaySmoothed;

        // Session observability counters
        private double _minPsiThisSession = 100.0;
        private double _peakPressure;
        private readonly double[] _peakC = new double[8];
        private double _nakedTotalSec;
        private double _overExposureTotalSec;
        private DateTime _lastPosSampleAt = DateTime.MinValue;

        // ─── Commit telemetry (for HUD / Dashboard / attribution log) ──────
        //
        // Every firing Commit() call records:
        //   • per-dimension "last commit class" (A / B / None) so the HUD
        //     dominant-dimension label can render "[A]" (commitment break,
        //     red) vs "[B]" (behavioral pattern, amber);
        //   • a ring-buffered list of the last RecentCommitsCap events so
        //     MeridianPSI can attribute a PSI drop to the specific
        //     commit(s) that caused it and surface the last-N log in the
        //     Dashboard Session Insight panel.
        //
        // _currentProcessingTime is set at the top of every public entry
        // point (ProcessExecution / PollPositions / ProcessOrderChange /
        // MarkMaxDailyLossBreach) so Commit() can timestamp events without
        // needing an additional parameter threaded through every caller.
        private readonly CommitClass[]      _lastCommitKind = new CommitClass[8];
        private readonly DateTime[]         _lastCommitTime = new DateTime[8];
        private readonly Queue<CommitEvent> _recentCommits  = new Queue<CommitEvent>();
        private const int                   RecentCommitsCap = 64;
        private DateTime                    _currentProcessingTime = DateTime.MinValue;
        private int                         _classACommitCountThisSession;

        // =====================================================================
        // Constructor
        // =====================================================================

        public PsiEngineV2(StrategyProfile profile, TradeBaseline baseline,
                           PsiEngineV2Config config = null)
        {
            _profile  = profile  ?? throw new ArgumentNullException("profile");
            _baseline = baseline ?? throw new ArgumentNullException("baseline");
            _cfg      = config   ?? PsiEngineV2Config.Default;

            // Seed personalised scales (Axiom 8).  A trader with SizeMax=10
            // needs `excess = 10` to reach the same relative severity as a
            // trader with SizeMax=3 reaching `excess = 3`.  Similarly for D5:
            // scale_D5 = MaxHoldSec so `overstaySec/scale_D5 = 1.0` means
            // "held exactly twice as long as declared max" regardless of
            // whether declared max is 5 min or 50 min.
            double profileSizeMax = (_profile.SizeMax > 0) ? _profile.SizeMax : 0.0;
            _d3Scale = profileSizeMax > 0.0 ? profileSizeMax
                                            : Math.Max(0.01, _cfg.D3SaturationScale);

            int profileMaxHoldMin = (_profile.MaxHoldMinutes > 0) ? _profile.MaxHoldMinutes : 0;
            _d5Scale = profileMaxHoldMin > 0
                ? profileMaxHoldMin * 60.0
                : 1800.0;  // 30 min cold fallback when user hasn't declared MaxHoldMinutes

            // D2 scale = NoStopGraceSeconds (trader-declared SL-placement
            // tolerance).  r=1 psychologically means "naked twice as long as
            // I said I needed to place the stop."  Fallback 1.0 s = engine
            // position-poll resolution; below this no "past grace" signal
            // is observable.
            int profileGraceSec = (_profile.NoStopGraceSeconds > 0)
                ? _profile.NoStopGraceSeconds : 0;
            _d2Scale = profileGraceSec > 0 ? profileGraceSec : 1.0;

            // D6 MaxDailyLoss scale = MaxDailyLossUsd (trader-declared stop).
            // r=1 psychologically means "lost twice the declared max."
            // When MaxDailyLossUsd ≤ 0 the rule is disabled (see
            // CommitD6MaxDailyLossMarginal early-return), so the fallback
            // below only matters for numerical stability inside the curve
            // when the declared limit is tiny (e.g. $5).  Fallback $1 =
            // account-currency tick resolution.
            _d6LossScale = (_cfg.MaxDailyLossUsd > 0) ? _cfg.MaxDailyLossUsd : 1.0;

            // D7 scale = TradesPerSessionMax (trader-declared trade budget).
            // r=1 psychologically means "doubled your declared trade count."
            // When TradesPerSessionMax ≤ 0 the rule is disabled (see
            // CommitD7OnEntry early-return), so the fallback below only
            // matters for numerical stability when the declared max is 1.
            // Fallback 1.0 = integer-count resolution.
            _d7Scale = (_profile.TradesPerSessionMax > 0)
                ? _profile.TradesPerSessionMax : 1.0;
        }

        // =====================================================================
        // Public API — signature parity with PsiEngine (v1) so MeridianPSI
        // can select between them at construction time in M1 Phase 1.
        // =====================================================================

        public PsiEngineV2Config Config => _cfg;

        public double CurrentPsi         { get { lock (_sync) return _psi; } }
        public double Pressure           { get { lock (_sync) return _pressureForHud; } }
        // Smoothed pressure for display (HUD chip + timeline shadow). Never use for math.
        public double PressureDisplay    { get { lock (_sync) return _pDisplaySmoothed; } }
        public double ConsecutiveLosses  { get { lock (_sync) return _consecutiveLosses; } }
        public int    SessionEntryCount  { get { lock (_sync) return _sessionEntryCount; } }
        public double CarryDebt          { get { lock (_sync) return _carryDebt; } }
        public double SessionNetPnl      { get { lock (_sync) return _sessionNetPnl; } }
        public double MinPsiThisSession  { get { lock (_sync) return _minPsiThisSession; } }
        public double PeakPressure       { get { lock (_sync) return _peakPressure; } }

        public double EvidenceD1 { get { lock (_sync) return _E[1]; } }
        public double EvidenceD2 { get { lock (_sync) return _E[2]; } }
        public double EvidenceD3 { get { lock (_sync) return _E[3]; } }
        public double EvidenceD4 { get { lock (_sync) return _E[4]; } }
        public double EvidenceD5 { get { lock (_sync) return _E[5]; } }
        public double EvidenceD6 { get { lock (_sync) return _E[6]; } }
        public double EvidenceD7 { get { lock (_sync) return _E[7]; } }

        // DebtD* names preserved for HUD compatibility (C_i values 0..100).
        public double DebtD1 { get { lock (_sync) return _C[1]; } }
        public double DebtD2 { get { lock (_sync) return _C[2]; } }
        public double DebtD3 { get { lock (_sync) return _C[3]; } }
        public double DebtD4 { get { lock (_sync) return _C[4]; } }
        public double DebtD5 { get { lock (_sync) return _C[5]; } }
        public double DebtD6 { get { lock (_sync) return _C[6]; } }
        public double DebtD7 { get { lock (_sync) return _C[7]; } }

        // v1 Score* accessors map to the instantaneous severity C_i / 100 so
        // callers that log "the current D_i raw signal" get a 0..1 value.
        public double ScoreD1 { get { lock (_sync) return _C[1] / 100.0; } }
        public double ScoreD2 { get { lock (_sync) return _C[2] / 100.0; } }
        public double ScoreD3 { get { lock (_sync) return _C[3] / 100.0; } }
        public double ScoreD4 { get { lock (_sync) return _C[4] / 100.0; } }
        public double ScoreD5 { get { lock (_sync) return _C[5] / 100.0; } }
        public double ScoreD6 { get { lock (_sync) return _C[6] / 100.0; } }
        public double ScoreD7 { get { lock (_sync) return _C[7] / 100.0; } }

        public bool   IsOverExposed { get { lock (_sync) return _prevSizeOverLimit > 0.0; } }

        // Hidden-debt compatibility accessors — always 0 in v2.  Retained so
        // MeridianPSI's diagnostic log builder can remain unchanged during
        // shadow-mode.  M2 (when V1 is retired) can delete these.
        public double FinancialStressDebt => 0.0;
        public double FatigueDebt         => 0.0;
        public double StreakFloorDebt     => 0.0;

        // ─── Commit telemetry accessors (HUD / Dashboard / attribution) ───
        //
        // GetDimLastClass(dim) — the last commit class (A / B / None) fired
        // on this dimension since session start.  HUD uses it to tag the
        // dominant-dim label so the trader can see "is this a commitment
        // break or a pattern signal".
        //
        // GetDimLastCommitTime(dim) — when the most recent commit on this
        // dimension fired.  Useful for age-fading the tag colour.
        //
        // RecentCommits — up to RecentCommitsCap most recent commit events,
        // oldest first.  Dashboard reads this for the Session Insight log.
        //
        // ClassACommitCountThisSession — total Class A events this session,
        // surfaced as a single discipline KPI.
        public CommitClass GetDimLastClass(int dim)
        {
            if (dim < 1 || dim > 7) return CommitClass.None;
            lock (_sync) return _lastCommitKind[dim];
        }
        public DateTime GetDimLastCommitTime(int dim)
        {
            if (dim < 1 || dim > 7) return DateTime.MinValue;
            lock (_sync) return _lastCommitTime[dim];
        }
        public CommitEvent[] RecentCommits
        {
            get { lock (_sync) return _recentCommits.ToArray(); }
        }
        public int ClassACommitCountThisSession
        {
            get { lock (_sync) return _classACommitCountThisSession; }
        }
        public double[] PeakSeverityPerDim
        {
            get
            {
                lock (_sync)
                {
                    var copy = new double[8];
                    for (int i = 0; i < 8; i++) copy[i] = _peakC[i];
                    return copy;
                }
            }
        }

        // Human-readable D6 violation detail, captured at the most recent
        // session-window Class A / Class B commit.  Used by the HUD culprit
        // label to render "Rule Violation: Session ended 12:00, entry at
        // 12:32 (+32 min)" instead of a bare "[Rule Violation]".  Empty
        // string when no D6 commit has occurred this session.
        private string _lastD6ViolationDetail = "";
        public string LastD6ViolationDetail
        {
            get { lock (_sync) return _lastD6ViolationDetail; }
        }

        // =====================================================================
        // Fill ingestion
        // =====================================================================

        /// <summary>
        /// Full-signature fill ingestion.  Mirrors the v1 engine's signature
        /// so MeridianPSI can call either engine uniformly in shadow-mode.
        ///
        /// All time arguments MUST be in a single, monotonic domain supplied
        /// by the caller (TradingClock.EngineTime).  The engine does not
        /// normalise or remap times.
        /// </summary>
        public double ProcessExecution(double pnl, double size, DateTime fillTime,
                                       bool isWin, double holdSeconds,
                                       IEnumerable<PositionSnapshot> postFillPositions,
                                       int fillDirection,
                                       ExitKind exitKind,
                                       bool isRoundTripFinal,
                                       double roundTripPnl)
        {
            lock (_sync)
            {
                // Stamp the processing clock so every Commit() fired inside
                // this call timestamps its CommitEvent consistently.
                _currentProcessingTime = fillTime;

                // 1. Apply time-advance decay up to fillTime BEFORE any commit.
                AdvanceTime(fillTime, caller: "ProcessExecution");

                bool hasRealizedOutcome = holdSeconds > 0 || pnl != 0.0;
                bool roundTripWin       = roundTripPnl > 0;

                if (hasRealizedOutcome)
                {
                    _sessionNetPnl += pnl;

                    // Round-trip-based streak (v1.1.1 E2 logic retained —
                    // tracking-layer correctness is orthogonal to v2's
                    // evidence-accumulator model).
                    if (isRoundTripFinal)
                    {
                        if (roundTripWin)
                        {
                            _consecutiveLosses *= _cfg.WinStreakDecayFactor;
                            if (_consecutiveLosses < _cfg.StreakClearThreshold)
                                _consecutiveLosses = 0.0;
                        }
                        else
                        {
                            _consecutiveLosses += 1.0;
                        }
                    }

                    _lastRealizedPnl = isRoundTripFinal ? roundTripPnl : pnl;

                    // _lastRealizedDirection tracks the TRADE direction (the
                    // sign of the position that just closed), NOT the fill
                    // side of the closing order.  On a round-trip-final
                    // close the closing fill is OPPOSITE to the trade:
                    //   Long trade:  entry fill = +1, exit fill = -1, trade_dir = +1
                    //   Short trade: entry fill = -1, exit fill = +1, trade_dir = -1
                    // Hence trade_dir = -fillDirection at the round-trip
                    // boundary.  Assigning raw fillDirection stored the EXIT
                    // side as the "last direction," which caused CommitD1 to
                    // wrongly reject every same-direction revenge re-entry
                    // (tests S221, S233).
                    //
                    // Updated only at round-trip-final so partial/scale fills
                    // never corrupt the direction of the still-open trade
                    // and the upcoming revenge comparison sees the direction
                    // of the most recently CLOSED round-trip only.
                    if (isRoundTripFinal && fillDirection != 0)
                        _lastRealizedDirection = -fillDirection;

                    // [Axiom A4] Unconditional fill-time stamp on every
                    // realised fill that closes a round-trip.  The previous
                    // guard `if (!bracketExit) _lastRealizedFillTime = fillTime;`
                    // treated bracket (ProtectiveStop / Target) exits as
                    // "disciplined" and silently suppressed the stamp — which
                    // was Anti-pattern 3 (replacing the unobservable internal
                    // state "discipline" with the observable but flawed proxy
                    // "exit came from a bracket").  It left D1 revenge silent
                    // for the entire population of ATM-strategy users, whose
                    // every exit is a bracket exit.
                    //
                    // Correct semantics: `_lastRealizedFillTime` records WHEN
                    // the trader's most recent round-trip closed.  Whether
                    // that close was disciplined or not is determined
                    // DOWNSTREAM by D1 Class B via the user's own inter-trade
                    // gap distribution (`TradeBaseline.GapPercentile`); at
                    // the stamp site we record the fact, not interpret it.
                    //
                    // Bug class closed: #4 in REMEDIATION_PLAN_v1.2.md.
                    _lastRealizedFillTime = fillTime;
                }


                // 2. Compute pressure from current observable state.  Must be
                //    AFTER sessionNetPnl / consecutiveLosses updates so the
                //    commit this fill earns sees the current stress level.
                double P = ComputePressure(fillTime, postFillPositions);

                // 3. Fire commits for this fill.
                //    Entry-decision signals (D1 revenge, D6 session-window, D7
                //    overtrading) are fired from OnLifecycleAdd, not here.
                //    ProcessExecution's entry path only refreshes continuous-
                //    state (D2/D3/D5) via RecomputeContinuousDimensions below.
                if (isRoundTripFinal)
                {
                    // D4: hold-bias / manual-exit shape signal (Class B only).
                    CommitD4OnClose(holdSeconds, roundTripWin, exitKind, P);
                }

                // 4. Refresh continuous-state dimensions from the post-fill
                //    position set (D2 naked, D3 size, D5 overstay).  These
                //    commit zero if no position, so the flat-state PSI is
                //    purely decay-driven.
                bool overExposed, nakedDetected;
                RecomputeContinuousDimensions(postFillPositions, fillTime, P,
                                               out overExposed, out nakedDetected);

                // 5. Map E → C → PSI.
                return RecomputePsi(fillTime, P);
            }
        }

        /// <summary>
        /// Back-compat overload matching v1's minimal-argument ProcessExecution.
        /// Used only by code paths not yet upgraded (treats every fill as a
        /// complete round-trip with Unknown exit kind).
        /// </summary>
        public double ProcessExecution(double pnl, double size, DateTime fillTime,
                                       bool isWin, double holdSeconds,
                                       IEnumerable<PositionSnapshot> postFillPositions,
                                       int fillDirection = 0)
        {
            return ProcessExecution(pnl, size, fillTime, isWin, holdSeconds,
                postFillPositions, fillDirection,
                ExitKind.Unknown, isRoundTripFinal: true, roundTripPnl: pnl);
        }

        /// <summary>
        /// Called by MeridianPSI.ProcessLifecycleEdge when NT8 signals a new
        /// position opened (Operation_Add, or the opening leg of a reversal).
        /// This is the authoritative "entry decision" trigger for:
        ///   D1 — revenge urgency (gap from last close vs own gap distribution)
        ///   D6 — session-window commitment check
        ///   D7 — overtrading (entry count vs TradesPerSessionMax)
        ///
        /// Lifecycle-level counting eliminates orderId dedup entirely:
        /// one position ADD = one trader decision, regardless of how many
        /// NT8 orders or partial fills comprise that entry.
        ///
        /// Only called when OriginObserved=true (position opened in this
        /// process lifetime, not a bootstrap replay ghost).
        /// </summary>
        public double OnLifecycleAdd(DateTime entryTime)
        {
            lock (_sync)
            {
                _currentProcessingTime = entryTime;
                AdvanceTime(entryTime, caller: "OnLifecycleAdd");

                // P at the moment of entry: streak and daily-proximity factors
                // are current.  openLoserFactor = 0 (the new position has just
                // opened, unrealized PnL = 0 by definition).
                double P = ComputePressure(entryTime,
                                           new List<PositionSnapshot>());

                // Advance session entry state (was in ProcessExecution's
                // isFirstOfEntryDecision block, which used orderId dedup to
                // handle partial fills of one order.  Lifecycle-level counting
                // makes dedup unnecessary: one ADD = one decision).
                if (_sessionFirstEntryTime == DateTime.MinValue)
                    _sessionFirstEntryTime = entryTime;
                _sessionEntryCount++;
                EnqueueRecentEntry(entryTime);

                CommitD1OnEntry(entryTime, P);
                CommitD6OnEntry(entryTime, P);
                CommitD7OnEntry(P);

                return RecomputePsi(entryTime, P);
            }
        }


        // Order-change ingestion (stop-width adjustments)
        //
        // v2 treats every adverse stop-widening as a single Class B commit on
        // D2.  The continuous "naked-time" integration is handled inside
        // RecomputeContinuousDimensions on the next poll/fill.
        //
        // DESIGN NOTE (2026-04-24, Landmine 13 root fix):
        //   This method intentionally has NO AdvanceTime and NO
        //   RecomputeContinuousDimensions.  It is called from
        //   MeridianPSI.OnOrderUpdate which fires on an NT8 background thread
        //   with no reliable time anchor (see ARCHITECTURE.md §11 Landmine 13).
        //   Any AdvanceTime(orderTime) here would corrupt the EWMA decay with a
        //   wrong Δt (up to 8 days during the cold-cache bootstrap window).
        //
        //   Invariant: AdvanceTime and RecomputeContinuousDimensions execute
        //   ONLY from callers that carry authoritative timestamps:
        //     • ProcessExecution  — uses fill.Time (always historical/live-correct)
        //     • PollPositions     — uses _clock.EngineTime on UI dispatcher main thread
        //   No other caller may add AdvanceTime or RecomputeContinuousDimensions
        //   without providing evidence that its time source is in the same domain
        //   as _positionEntryTimes (see psi-v2-evidence-accumulator.mdc rule 11).
        // =====================================================================

        public void ProcessOrderChange(string orderId, double newSlTicks)
        {
            if (string.IsNullOrEmpty(orderId) || newSlTicks <= 0) return;

            lock (_sync)
            {
                // Use _currentProcessingTime (last fill/poll authoritative time)
                // for pressure computation and PSI attribution logging.
                // openLoserFactor omitted (no positions available on background
                // thread); streak + dailyProx factors are position-independent.
                double P = ComputePressure(_currentProcessingTime, null);

                if (_prevSlTicks.TryGetValue(orderId, out double prevTicks))
                {
                    if (newSlTicks > prevTicks + 0.5)   // adverse widening
                    {
                        Commit(2, classA: 0.0, classB: _cfg.CommitB_D2_AdverseMove, P: P);
                    }
                }
                _prevSlTicks[orderId] = newSlTicks;

                // Recompute PSI so CurrentPsi reflects the new D2 commit
                // immediately for HUD display — no AdvanceTime needed since
                // RecomputePsi only reads _E[i] (already updated by Commit).
                RecomputePsi(_currentProcessingTime, P);
            }
        }

        // =====================================================================
        // Timer heartbeat
        // =====================================================================

        public double PollPositions(IEnumerable<PositionSnapshot> positions,
                                    DateTime engineTime,
                                    out bool nakedPositionDetected)
        {
            lock (_sync)
            {
                _currentProcessingTime = engineTime;
                AdvanceTime(engineTime, caller: "PollPositions");
                double P = ComputePressure(engineTime, positions);

                bool overExposed;
                RecomputeContinuousDimensions(positions, engineTime, P,
                                              out overExposed, out nakedPositionDetected);

                // Observability accounting
                if (_lastPosSampleAt != DateTime.MinValue)
                {
                    double dSec = (engineTime - _lastPosSampleAt).TotalSeconds;
                    if (dSec > 0.0 && dSec <= 300.0)
                    {
                        if (overExposed)            _overExposureTotalSec += dSec;
                        if (nakedPositionDetected)  _nakedTotalSec       += dSec;
                    }
                }
                _lastPosSampleAt = engineTime;

                return RecomputePsi(engineTime, P);
            }
        }

        // =====================================================================
        // Session / lifecycle
        // =====================================================================

        public void StartNewSession(double previousSessionFinalPsi, object epochAccount = null)
        {
            lock (_sync)
            {
                double tauHours = Math.Max(1.0, _cfg.OvernightRecoveryTauHours);
                double decay    = Math.Exp(-_cfg.OvernightEstimatedHours / tauHours);
                _psi = 100.0 - (100.0 - previousSessionFinalPsi) * decay;
                _psi = Math.Max(0.0, Math.Min(100.0, _psi));

                for (int i = 1; i <= 7; i++) { _E[i] = 0.0; _C[i] = 0.0; _peakC[i] = 0.0; }
                _carryDebt = Math.Max(0.0, 100.0 - _psi);

                _consecutiveLosses     = 0.0;
                _lastRealizedPnl       = 0.0;
                _lastRealizedFillTime  = DateTime.MinValue;
                _lastRealizedDirection = 0;
                _sessionNetPnl         = 0.0;
                _sessionFirstEntryTime = DateTime.MinValue;
                _sessionEntryCount     = 0;
                _recentEntryTimes.Clear();
                _prevSlTicks.Clear();
                _nakedStateBeganAt          = DateTime.MinValue;
                _prevNakedPastGraceSec      = 0.0;
                _prevSizeOverLimit          = 0.0;
                _d3OversizeBeganAt          = DateTime.MinValue;
                _prevWorstOverstaySec       = 0.0;
                _prevD6MaxLossOvershootUsd  = 0.0;
                _prevD7ExcessTrades         = 0.0;
                _prevD1StreakExcess         = 0.0;
                _peakPressure               = 0.0;
                _pressureForHud             = 0.0;
                _pressureForDecay           = 0.0;
                _pDisplaySmoothed           = 0.0;
                _nakedTotalSec         = 0.0;
                _overExposureTotalSec  = 0.0;

                for (int i = 0; i < 8; i++)
                {
                    _lastCommitKind[i] = CommitClass.None;
                    _lastCommitTime[i] = DateTime.MinValue;
                }
                _recentCommits.Clear();
                _classACommitCountThisSession = 0;
                _currentProcessingTime = DateTime.MinValue;
            }
        }

        public void ApplyOvernightDecay(double elapsedHours)
        {
            if (elapsedHours <= 0) return;
            lock (_sync)
            {
                double tauHours = Math.Max(1.0, _cfg.OvernightRecoveryTauHours);
                double decay    = Math.Exp(-elapsedHours / tauHours);

                for (int i = 1; i <= 7; i++) _E[i] *= decay;
                _carryDebt *= decay;

                // Session-volatile state clears at cross-day boundary.
                _consecutiveLosses     = 0.0;
                _lastRealizedFillTime  = DateTime.MinValue;
                _lastRealizedPnl       = 0.0;
                _sessionNetPnl         = 0.0;
                _sessionFirstEntryTime = DateTime.MinValue;
                _sessionEntryCount     = 0;
                _recentEntryTimes.Clear();
                _nakedStateBeganAt          = DateTime.MinValue;
                _prevNakedPastGraceSec      = 0.0;
                _prevSizeOverLimit          = 0.0;
                _d3OversizeBeganAt          = DateTime.MinValue;
                _prevWorstOverstaySec       = 0.0;
                _prevD6MaxLossOvershootUsd  = 0.0;
                _prevD7ExcessTrades         = 0.0;
                _prevD1StreakExcess         = 0.0;
                _lastD6ViolationDetail      = "";

                _lastTick              = DateTime.MinValue;
                _lastPosSampleAt       = DateTime.MinValue;

                for (int i = 0; i < 8; i++)
                {
                    _lastCommitKind[i] = CommitClass.None;
                    _lastCommitTime[i] = DateTime.MinValue;
                    _peakC[i]          = 0.0;
                }
                _recentCommits.Clear();
                _classACommitCountThisSession = 0;
                _currentProcessingTime = DateTime.MinValue;

                // Re-aggregate so _psi and _C are consistent with new E's.
                RecomputePsi(DateTime.MinValue, 0.0);
            }
        }

        /// <summary>
        /// Called when the tracking layer (MeridianPSI) discovers that its
        /// internal position set has drifted from the platform's authoritative
        /// state and has just force-cleared it.  The engine mirrors the
        /// decision by clearing the subset of state that is DIRECTLY tied to
        /// the believed position set (naked-state clock, D5 overstay flags,
        /// size-excess tracking).  E_i accumulators are NOT cleared — a real
        /// behavioural history is not nullified by a bookkeeping correction.
        /// </summary>
        public void OnPositionTrackingCorrection()
        {
            lock (_sync)
            {
                _nakedStateBeganAt     = DateTime.MinValue;
                _prevNakedPastGraceSec = 0.0;
                _prevSizeOverLimit     = 0.0;
                _d3OversizeBeganAt     = DateTime.MinValue;
                _prevWorstOverstaySec  = 0.0;
                // _prevD6MaxLossOvershootUsd, _prevD7ExcessTrades and
                // _prevD1StreakExcess are NOT cleared here: a bookkeeping
                // correction of the position set does not undo the trader's
                // realized P&L history, trade count, or loss streak for the
                // session — those anchors reflect session behavioural facts,
                // not position-set state.  See ARCHITECTURE.md §6
                // (Reset-path semantic contracts).
                _prevSlTicks.Clear();
            }
        }

        /// <summary>
        /// Resets session entry-counting state when ALL position tracking is
        /// cleared due to a mode transition (e.g. Live → Simulation → Live
        /// oscillation caused by a trade-copier plugin such as Replikanto).
        ///
        /// Distinct from <see cref="OnPositionTrackingCorrection"/> which
        /// intentionally preserves these counters for single-position
        /// reconcile corrections.  When ALL lifecycles are retired without
        /// RecordTrade (cross-domain close), the entry count must restart at
        /// zero so D7's saturating-marginal curve is not pre-saturated by
        /// phantom lifecycle ADDs from the previous mode epoch.
        ///
        /// Does NOT reset PSI E_i, _consecutiveLosses, or _sessionNetPnl —
        /// those reflect cumulative psychological evidence and P&L that survive
        /// across mode transitions within the same calendar session.
        /// </summary>
        public void ResetSessionEntryCounters()
        {
            lock (_sync)
            {
                _sessionEntryCount     = 0;
                _sessionFirstEntryTime = DateTime.MinValue;
                _recentEntryTimes.Clear();
                _prevD7ExcessTrades    = 0.0;
            }
        }

        /// <summary>
        /// Called on Live↔Playback transitions where the time domain flips
        /// discontinuously.  _lastTick is voided so the next AdvanceTime call
        /// treats the current engineTime as a fresh anchor (dt=0, no decay).
        /// </summary>
        public void ResetClockAnchor()
        {
            lock (_sync)
            {
                DateTime priorTick = _lastTick;
                _lastTick        = DateTime.MinValue;
                _lastPosSampleAt = DateTime.MinValue;
                if (_debug != null)
                {
                    try
                    {
                        _debug(string.Format(
                            "[PSI v2 trace] ResetClockAnchor priorTick={0}",
                            priorTick == DateTime.MinValue
                                ? "MinValue (already)"
                                : priorTick.ToString("HH:mm:ss.fff")));
                    }
                    catch { }
                }
            }
        }

        /// <summary>
        /// One-shot notification that the trader's declared MaxDailyLoss has
        /// just been breached THIS fill.  Wired by MeridianPSI when it
        /// detects the threshold crossing.  Fires a Class A commit on D6
        /// — "I broke my own daily-loss rule by continuing to trade".
        /// Idempotent within a session (first call wins).
        /// </summary>
        public void MarkMaxDailyLossBreach(DateTime atTime)
        {
            lock (_sync)
            {
                _currentProcessingTime = atTime;
                AdvanceTime(atTime, caller: "MarkMaxDailyLossBreach");
                double P = ComputePressure(atTime, null);
                CommitD6MaxDailyLossMarginal(P);
                RecomputePsi(atTime, P);
            }
        }

        /// <summary>
        /// Saturating-marginal Class A commit for D6 MaxDailyLoss (Axiom 6).
        /// Single entry point shared by <see cref="MarkMaxDailyLossBreach"/>
        /// and the per-entry <c>CommitD6OnEntry</c> path; idempotent when
        /// sessionNetPnl has not moved deeper past the declared limit.
        ///
        /// Mechanics (ARCHITECTURE.md §15.15):
        ///   overshootUsd_now  = max(0, −_sessionNetPnl − MaxDailyLossUsd)
        ///   targetNow  = CommitA_D6 · (1 − e^(−overshootUsd_now  / scale))
        ///   targetPrev = CommitA_D6 · (1 − e^(−_prevD6MaxLossOvershootUsd / scale))
        ///   ΔE         = targetNow − targetPrev          (only non-negative)
        /// scale = _d6LossScale ≡ profile-declared MaxDailyLossUsd.  r=1
        /// means "lost twice the declared max" (I3 moderate-critical anchor).
        /// A partial P&amp;L recovery does NOT add evidence — decay handles
        /// shrinkage.  Total deposit per session is bounded by CommitA_D6.
        /// </summary>
        private void CommitD6MaxDailyLossMarginal(double P)
        {
            if (_cfg.MaxDailyLossUsd <= 0.0) return;   // rule disabled

            double overshootUsd = Math.Max(0.0,
                -_sessionNetPnl - _cfg.MaxDailyLossUsd);
            if (overshootUsd <= 0.0) return;            // not yet past limit

            double scale = Math.Max(1.0, _d6LossScale);
            double targetNow  = _cfg.CommitA_D6 *
                                (1.0 - Math.Exp(-overshootUsd / scale));
            double targetPrev = _cfg.CommitA_D6 *
                                (1.0 - Math.Exp(-_prevD6MaxLossOvershootUsd / scale));
            double marginal   = targetNow - targetPrev;
            if (marginal > 0.0)
            {
                Commit(6, classA: marginal, classB: 0.0, P: P);
                _prevD6MaxLossOvershootUsd = overshootUsd;
            }
        }

        public string BuildSessionSummary()
        {
            lock (_sync)
            {
                return string.Format(
                    "[PSI v2] Session summary — minPsi={0:F1}  peakP={1:F2}  " +
                    "peakC[1..7]=[{2:F1},{3:F1},{4:F1},{5:F1},{6:F1},{7:F1},{8:F1}]  " +
                    "nakedSec={9:F0}  overExpSec={10:F0}  entries={11}  streak={12:F2}",
                    _minPsiThisSession, _peakPressure,
                    _peakC[1], _peakC[2], _peakC[3], _peakC[4], _peakC[5], _peakC[6], _peakC[7],
                    _nakedTotalSec, _overExposureTotalSec,
                    _sessionEntryCount, _consecutiveLosses);
            }
        }

        // =====================================================================
        // Internal — decay, commit, aggregation
        // =====================================================================

        private void AdvanceTime(DateTime engineTime, string caller = "?")
        {
            // ── Diagnostic trace (Anti-pattern 8 corollary): instrumentation
            // for the "PSI rose after a rule-breaking trade" investigation
            // (2026-04-26).  A SINGLE AdvanceTime call with `dt × gate ≈ 343 s`
            // can silently outweigh a +6 commit and lift PSI when it should
            // fall.  This trace fires only on three suspicious events:
            //   (1) anchor was MinValue → fresh re-anchor (which path?)
            //   (2) raw dt > 30 s       → cross-domain or paused-resume gap
            //   (3) raw dt was clamped  → hidden multi-minute jump
            // Normal sub-second polls produce no log output.  When trace
            // fires we record CALLER + raw/clamped dt + gate + P_decay +
            // streak + lastRealizedFillTime so the source of the surprise
            // is unambiguous from the log alone.
            DateTime priorTick = _lastTick;
            if (_lastTick == DateTime.MinValue)
            {
                _lastTick = engineTime;
                if (_debug != null)
                {
                    try
                    {
                        _debug(string.Format(
                            "[PSI v2 trace] AdvanceTime[{0}] anchor=MinValue → set _lastTick={1:HH:mm:ss.fff} (no decay)",
                            caller, engineTime));
                    }
                    catch { }
                }
                return;
            }

            double dtRaw = (engineTime - _lastTick).TotalSeconds;
            double dt    = dtRaw;
            if (dt < _cfg.MinDeltaSec) dt = 0.0;
            bool clamped = dt > _cfg.MaxDeltaSec;
            if (clamped) dt = _cfg.MaxDeltaSec;

            // Decay uses the stressor-only pressure gate (not behavioral strain).
            // _pressureForDecay = P without behavioralStrainFactor — see field comment.
            // Using the full _pressureForHud here would create a self-reinforcing lock:
            // PSI drop → behavioral strain rises → decay stalls → PSI never recovers.
            double P    = _pressureForDecay;
            double gate = Math.Max(0.0, Math.Min(1.0, 1.0 - P));

            bool suspicious = dtRaw > 30.0 || clamped;
            if (suspicious && _debug != null)
            {
                try
                {
                    _debug(string.Format(
                        "[PSI v2 trace] AdvanceTime[{0}] _lastTick={1:HH:mm:ss.fff} engineTime={2:HH:mm:ss.fff} " +
                        "dtRaw={3:F1}s dt={4:F1}s clamped={5} gate={6:F2} P_decay={7:F2} " +
                        "streak={8:F2} lastRealizedFill={9} → effDecay={10:F1}s on each E_i",
                        caller, priorTick, engineTime, dtRaw, dt, clamped,
                        gate, _pressureForDecay, _consecutiveLosses,
                        _lastRealizedFillTime == DateTime.MinValue
                            ? "MinValue"
                            : _lastRealizedFillTime.ToString("HH:mm:ss.fff"),
                        dt * gate));
                }
                catch { }
            }

            if (dt <= 0.0)
            {
                _lastTick = engineTime;
                return;
            }

            double[] taus = { 0.0,
                _cfg.TauDecayD1, _cfg.TauDecayD2, _cfg.TauDecayD3, _cfg.TauDecayD4,
                _cfg.TauDecayD5, _cfg.TauDecayD6, _cfg.TauDecayD7 };

            for (int i = 1; i <= 7; i++)
            {
                double tau = Math.Max(0.1, taus[i]);
                _E[i] *= Math.Exp(-dt * gate / tau);
                if (_E[i] < 1e-9) _E[i] = 0.0;
            }

            // Carry-debt decays on the overnight time constant expressed per-
            // second.  One business day ≈ 23400 s; overnight 16 h ≈ 57600 s —
            // at τ=48 h this gives ~27% decay overnight, matching v1's
            // StartNewSession formula when lastTick gap equals OvernightEstimatedHours.
            double carryTauSec = Math.Max(60.0, _cfg.OvernightRecoveryTauHours * 3600.0);
            _carryDebt *= Math.Exp(-dt * gate / carryTauSec);

            _lastTick = engineTime;
        }

        /// <summary>
        /// Central commit entry point.  Pressure-amplifies only the Class B
        /// contribution; Class A is pure commitment-break evidence and is
        /// NOT scaled by pressure (a broken hard rule is equally serious
        /// regardless of mood).
        ///
        /// Also records a CommitEvent into the telemetry ring buffer and
        /// updates per-dim last-commit-class so the HUD / Dashboard can
        /// surface "[A]" vs "[B]" tags and render an attribution log.  The
        /// classA > 0 XOR classB > 0 contract is enforced by the callers
        /// (CommitD1..D7OnEntry / MarkMaxDailyLossBreach) so we read only
        /// the dominant contributor's class.
        /// </summary>
        private void Commit(int dim, double classA, double classB, double P)
        {
            if (dim < 1 || dim > 7) return;
            double amount = Math.Max(0.0, classA)
                          + Math.Max(0.0, classB) * (1.0 + _cfg.PressureBoostKappa * P);
            if (amount <= 0.0) return;
            _E[dim] += amount;

            CommitClass kind = classA > 0.0 ? CommitClass.A : CommitClass.B;
            _lastCommitKind[dim] = kind;
            _lastCommitTime[dim] = _currentProcessingTime;
            if (kind == CommitClass.A) _classACommitCountThisSession++;

            _recentCommits.Enqueue(new CommitEvent
            {
                Time     = _currentProcessingTime,
                Dim      = dim,
                Kind     = kind,
                Amount   = amount,
                Pressure = P,
            });
            while (_recentCommits.Count > RecentCommitsCap)
                _recentCommits.Dequeue();
        }

        private double RecomputePsi(DateTime engineTime, double P)
        {
            double sumSq = 0.0;
            double[] tauSev = { 0.0,
                _cfg.TauSevD1, _cfg.TauSevD2, _cfg.TauSevD3, _cfg.TauSevD4,
                _cfg.TauSevD5, _cfg.TauSevD6, _cfg.TauSevD7 };
            for (int i = 1; i <= 7; i++)
            {
                double tau = Math.Max(0.1, tauSev[i]);
                double c   = (1.0 - Math.Exp(-_E[i] / tau)) * 100.0;
                if (c < 0.0) c = 0.0;
                if (c > 100.0) c = 100.0;
                _C[i] = c;
                sumSq += c * c;
                if (c > _peakC[i]) _peakC[i] = c;
            }

            double psi = 100.0 - Math.Sqrt(sumSq) - _carryDebt;
            if (psi < 0.0) psi = 0.0;
            if (psi > 100.0) psi = 100.0;
            _psi = psi;
            _pressureForHud   = P;
            _pDisplaySmoothed = PDisplayAlpha * P + (1.0 - PDisplayAlpha) * _pDisplaySmoothed;
            if (P > _peakPressure) _peakPressure = P;
            if (psi < _minPsiThisSession) _minPsiThisSession = psi;
            return psi;
        }

        // =====================================================================
        // Pressure computation — the single public derivation of P(t)
        //
        // All four factors clamp to [0, 1]; P is the max, bounded in [0, 1].
        // =====================================================================

        private double ComputePressure(DateTime engineTime,
                                       IEnumerable<PositionSnapshot> positions)
        {
            // Factor 1 — worst open-loser magnitude vs the trader's μLoss.
            double muLoss = Math.Max(_cfg.PressureMuLossFloor,
                                     _baseline.GetEffectiveMuLoss(_cfg.ColdStartMuLoss));
            double openLoser = 0.0;
            if (positions != null)
            {
                foreach (var p in positions)
                {
                    if (p == null) continue;
                    if (p.Quantity <= 0) continue;
                    double mae = -p.MinUnrealizedPnl;        // ≥ 0 (MAE is ≤ 0)
                    if (mae > openLoser) openLoser = mae;
                }
            }
            double openLoserFactor = Clamp01(openLoser / muLoss);

            // Factor 2 — consecutive-loss streak, with temporal decay.
            //
            // Semantic definition: a "streak" requires at least 2 consecutive
            // losses.  One loss is a normal probabilistic outcome and carries
            // NO psychological pressure signal in isolation — treating it
            // otherwise would be a backdoor that lets raw P&L outcome amplify
            // subsequent Class B commits, violating axiom 1 of the v2.0
            // contract ("PSI must never reward or penalise P&L outcomes").
            //
            // Formula: excess = max(0, streak − 1); streakFactor = excess / N.
            //   streak=1 → 0   (single loss is not a streak)
            //   streak=2 → 1/N (streak begins; linear rise)
            //   streak=N+1 → 1.0 (saturated)
            //
            // Temporal decay: the ACUTE emotional momentum from a streak
            // dissipates while the trader is resting (no new fills).  We
            // multiply streakFactor by exp(−idleSec / τ) where idleSec =
            // time since the last realized fill.  This is Axiom-4-compliant
            // (derived from observable state, no new memory) and matches the
            // clinical observation that sympathetic-nervous-system stress
            // response from recent losses reduces substantially within ~1 h.
            double streakExcess = Math.Max(0.0, _consecutiveLosses - 1.0);
            double rawStreakFactor = Clamp01(
                streakExcess / Math.Max(1.0, _cfg.StreakSaturationN));

            double streakTimeFactor = 1.0;
            if (rawStreakFactor > 0.0 && _lastRealizedFillTime != DateTime.MinValue)
            {
                double idleSec = Math.Max(0.0,
                    (engineTime - _lastRealizedFillTime).TotalSeconds);
                double tau = Math.Max(1.0, _cfg.StreakPressureDecayTauSec);
                streakTimeFactor = Math.Exp(-idleSec / tau);
            }
            double streakFactor = rawStreakFactor * streakTimeFactor;

            // Factor 3 — proximity to declared daily loss.
            double dailyProxFactor = 0.0;
            if (_cfg.MaxDailyLossUsd > 0 && _sessionNetPnl < 0)
                dailyProxFactor = Clamp01(-_sessionNetPnl / _cfg.MaxDailyLossUsd);

            // Factor 4 — session-hour (profile-gated, default 0).
            double sessionHourFactor = 0.0;
            if (_cfg.SessionHourFactorWeight > 0 &&
                _sessionFirstEntryTime != DateTime.MinValue &&
                engineTime != DateTime.MinValue)
            {
                double hoursIn = Math.Max(0.0,
                    (engineTime - _sessionFirstEntryTime).TotalHours);
                if (hoursIn > _cfg.SessionHourOptimalHours)
                {
                    double ramp = Math.Max(0.1, _cfg.SessionHourRampHours);
                    sessionHourFactor = 1.0 - Math.Exp(
                        -(hoursIn - _cfg.SessionHourOptimalHours) / ramp);
                    sessionHourFactor *= Clamp01(_cfg.SessionHourFactorWeight);
                }
            }

            double P = Math.Max(openLoserFactor,
                       Math.Max(streakFactor,
                       Math.Max(dailyProxFactor, sessionHourFactor)));
            if (P < 0.0) P = 0.0;
            if (P > 1.0) P = 1.0;

            // Save stressor-only P for the decay gate (AdvanceTime).
            // Recovery rate is gated by REAL stressors (open loser, streak,
            // daily-loss approach) — NOT by behavioral history, which would
            // create a self-reinforcing lock preventing PSI from ever recovering.
            _pressureForDecay = P;

            // Option A — Behavioral strain (Axiom 4 extension).
            // Past rule violations indicate elevated tilt that amplifies the NEXT
            // impulsive Class B commit (via the 1+κP factor) and raises the HUD
            // Pressure display so the two gauges remain visually consistent.
            // Critically: this factor feeds only Class B amplification and the HUD —
            // NOT the decay gate — so a closed position with no open stressors still
            // recovers at its natural τ_decay rate.
            double behavioralStrainFactor = Math.Min(0.8, Math.Max(0.0, (100.0 - _psi) / 70.0));
            double Pfull = Math.Max(P, behavioralStrainFactor);
            if (Pfull > 1.0) Pfull = 1.0;
            return Pfull;
        }

        // =====================================================================
        // Per-dimension commit triggers
        // =====================================================================

        private void CommitD1OnEntry(DateTime fillTime, double P)
        {
            // ──────────────────────────────────────────────────────────────
            // Class A — PauseAfterNLosses commitment-break (Axiom A6).
            // ──────────────────────────────────────────────────────────────
            // Replaces the prior step-function trigger
            //     if (streak >= N) Commit(full CommitA_D1); return;
            // with a saturating-marginal on the streak excess, matching
            // D3 / D6 / D7:
            //
            //     excess     = max(0, consecutiveLosses − N + 1)
            //                  (0 while compliant; 1 on the trade that
            //                   crosses the declared pause; 2,3,… if the
            //                   trader takes further losses AND keeps
            //                   entering)
            //     scale_D1   = max(1, N)             (Axiom 8: user-relative)
            //     targetNow  = CommitA_D1 · (1 − e^(−excess / scale_D1))
            //     targetPrev = CommitA_D1 · (1 − e^(−_prevD1StreakExcess / scale_D1))
            //     ΔE (A)     = max(0, targetNow − targetPrev)
            //
            // Anchor behaviour (mirrors _prevD6MaxLossOvershootUsd):
            //   excess ≤ 0  → snap anchor to 0 (trader back in compliance;
            //                 future re-breach is a FRESH commitment break).
            //   excess < anchor → snap anchor down to excess (wins have
            //                 partially decayed the streak but we're still
            //                 past N; no new evidence).
            //   excess ≥ anchor → deposit marginal, advance anchor.
            //
            // Satisfies invariant contract I1–I4 with CommitA_D1 = 60,
            // τ_sev = 60, scale = N (see REMEDIATION_PLAN_v1.2.md Part 11
            // and ARCHITECTURE.md §15.12 for the derivation).  Class A no
            // longer early-returns — Class B (revenge urgency) can fire
            // on the same entry; the two signals are orthogonal and
            // stacking them is legitimate pattern evidence per Axiom 3.
            // ──────────────────────────────────────────────────────────────
            if (_cfg.PauseAfterNLosses > 0)
            {
                double scale   = Math.Max(1.0, (double)_cfg.PauseAfterNLosses);
                double excess  = Math.Max(0.0,
                                 _consecutiveLosses - _cfg.PauseAfterNLosses + 1.0);

                if (excess <= 0.0)
                {
                    _prevD1StreakExcess = 0.0;
                }
                else if (excess < _prevD1StreakExcess)
                {
                    _prevD1StreakExcess = excess;
                }
                else if (excess > _prevD1StreakExcess)
                {
                    double targetNow  = _cfg.CommitA_D1 *
                                        (1.0 - Math.Exp(-excess / scale));
                    double targetPrev = _cfg.CommitA_D1 *
                                        (1.0 - Math.Exp(-_prevD1StreakExcess / scale));
                    double delta      = Math.Max(0.0, targetNow - targetPrev);
                    if (delta > 0.0)
                        Commit(1, classA: delta, classB: 0.0, P: P);
                    _prevD1StreakExcess = excess;
                }
                // excess == _prevD1StreakExcess → no new evidence (Axiom 6:
                // ΔE only on step-up in severity).
            }

            // ──────────────────────────────────────────────────────────────
            // Class B — revenge urgency (Axiom A4).
            // ──────────────────────────────────────────────────────────────
            // Severity is derived from WHERE this re-entry gap sits in the
            // trader's OWN observed inter-trade-gap distribution, not from
            // a static profile threshold (`MaxReentrySeconds`, now obsolete).
            //
            //     gap        = fillTime − _lastRealizedFillTime
            //     F          = baseline.GapPercentile(gap)    // 0=fastest, 1=slowest
            //     urgency    = max(0, 0.5 − F) · 2            // 1 at p0, 0 at p50+
            //     ΔE (B)     = CommitB_D1 · urgency
            //
            // A scalper whose own median gap is 15 s sees a 10 s re-entry
            // as urgency ≈ 0.2 (mild); a swing trader whose median is
            // 30 min sees a 2 min re-entry as urgency ≈ 0.95 (strong).
            // The "who decides what is rapid" question is answered by
            // the trader's own behaviour, not a magic constant.
            //
            // Cold-start (N < 10 gaps): `GapPercentile` uses the profile
            // setting `ColdStartInterTradeGapPriorSec` as a pseudo-median
            // prior, so new users behave identically to the previous
            // profile-driven design until enough data accrues.
            //
            // Pre-filters retained:
            //   • prior round-trip was a LOSS (domain-supported — see
            //     `psi-discipline-over-outcome.mdc` loss-streak grey area).
            //   • loss was SIGNIFICANT vs μLoss (Axiom 3: a trivial scratch
            //     loss does not psychologically trigger revenge urgency).
            //
            // Direction filter REMOVED (RC-2):
            //   A "flip-flop" re-entry (Long stop-loss → immediate Short)
            //   is psychologically identical to a same-direction re-entry —
            //   the trader is impulsively chasing the market in a new direction.
            //   The direction filter was Anti-pattern 3: it used an unobservable
            //   internal state proxy ("same direction = bad, opposite = OK")
            //   instead of the OBSERVABLE signal (gap is too fast vs own history).
            //   The gap distribution captures impulsiveness regardless of direction.
            // ──────────────────────────────────────────────────────────────
            if (_lastRealizedFillTime == DateTime.MinValue) return;
            if (_lastRealizedPnl >= 0) return;

            double muLoss   = Math.Max(1.0, _baseline.GetEffectiveMuLoss(_cfg.ColdStartMuLoss));
            double lossSize = -_lastRealizedPnl;
            if (lossSize < _cfg.D1SignificantLossFraction * muLoss) return;

            double gap = (fillTime - _lastRealizedFillTime).TotalSeconds;
            if (gap < 0) return;

            double F        = Clamp01(_baseline.GapPercentile(gap, _profile));
            double urgency  = Math.Max(0.0, 0.5 - F) * 2.0;
            if (urgency <= 0.0) return;

            Commit(1, classA: 0.0, classB: _cfg.CommitB_D1 * urgency, P: P);
        }

        private void CommitD4OnClose(double holdSec, bool roundTripWin,
                                     ExitKind exitKind, double P)
        {
            if (holdSec <= 0) return;
            if (roundTripWin) return;

            // Bracket-triggered closes are disciplined by construction.
            if (exitKind == ExitKind.ProtectiveStop || exitKind == ExitKind.Target) return;

            // D4 fires ONLY when a losing trade is held SIGNIFICANTLY LONGER
            // than the trader's typical winning trade.  This is the canonical
            // hold-bias / loss-aversion pattern: treating an open loser with
            // the same patience reserved for winners, waiting for it to
            // "come back" rather than executing the pre-planned exit.
            //
            // Reference: μWinHold (not μLossHold).  Hold Bias means the trader
            // holds losses *like wins* — so the win hold time is the correct
            // behavioral baseline to compare against.
            //
            // Axiom 1: a short (< ratio threshold) loss exit is DISCIPLINED
            // behavior — cutting losses quickly.  It earns ZERO D4 evidence.
            // The old logic (firing when holdSec < fraction × μLossHold) was
            // semantically inverted: it punished disciplined stops.
            double muWinHold = Math.Max(1.0, _baseline.GetEffectiveMuWinHold(_profile));
            if (holdSec < muWinHold * _cfg.D4HoldBiasRatio) return;

            Commit(4, classA: 0.0, classB: _cfg.CommitB_D4, P: P);
        }

        private void CommitD6OnEntry(DateTime fillTime, double P)
        {
            // ── Channel 1: MaxDailyLoss overshoot (saturating-marginal) ──
            // Each deepening of the hole past the declared daily-loss stop
            // adds marginal evidence.  See CommitD6MaxDailyLossMarginal.
            CommitD6MaxDailyLossMarginal(P);

            // ── Channel 2: Session-window out-of-hours (saturating per fill) ─
            // Every fill whose time-of-day sits outside the declared
            // [SessionStart, SessionEnd) window deposits
            //     ΔE = CommitA_D6 · (1 − e^(−minutesOver / scale_d6win))
            // where scale_d6win = declared session length in minutes.
            // This is a per-fill Axiom-3 event (bounded at CommitA_D6 for
            // any single fill regardless of how far out of window), and
            // multiple out-of-window fills accumulate the usual way —
            // that's legitimate pattern accumulation.
            if (_profile == null) return;
            if (!_profile.SessionWindowEnabled) return;
            int startMinutes = _profile.SessionStartHour * 60 + _profile.SessionStartMinute;
            int endMinutes   = _profile.SessionEndHour   * 60 + _profile.SessionEndMinute;
            int fillMinutes  = fillTime.Hour * 60 + fillTime.Minute;

            int minutesOver = 0;
            if (fillMinutes < startMinutes)       minutesOver = startMinutes - fillMinutes;
            else if (fillMinutes >= endMinutes)   minutesOver = fillMinutes - endMinutes + 1;

            if (minutesOver <= 0) return;

            // Declared session length in minutes (forward duration, wraps
            // correctly for sessions that cross midnight — e.g. start=22:00,
            // end=02:00 ⇒ length = 240 min).  Fallback `max(1.0, ...)` is
            // integer-minute resolution, NOT a tuning constant.
            double sessionLenMin = ((endMinutes - startMinutes) + 1440) % 1440;
            if (sessionLenMin <= 0)
            {
                // Trader did not declare a distinct session window; the rule
                // cannot meaningfully fire.  (An un-declared window is NOT
                // "24-hour always-in-window" — profile validation rejects
                // start == end, so this branch is defensive.)
                return;
            }
            double scale = Math.Max(1.0, sessionLenMin);

            double dE = _cfg.CommitA_D6 *
                        (1.0 - Math.Exp(-minutesOver / scale));

            // Capture a human-readable detail string for the HUD culprit
            // label.  Uses profile-declared window bounds and the caller-
            // supplied fillTime (EngineTime domain — Landmine 10), so
            // phrasing matches whatever time domain the trader is
            // actually in (Live / Replay).  Overwritten on each firing
            // commit — only the most recent violation is shown.
            var winStart = new TimeSpan(
                _profile.SessionStartHour, _profile.SessionStartMinute, 0);
            var winEnd   = new TimeSpan(
                _profile.SessionEndHour,   _profile.SessionEndMinute,   0);
            var tod      = fillTime.TimeOfDay;
            _lastD6ViolationDetail = fillMinutes >= endMinutes
                ? string.Format("Session ended {0:hh\\:mm}, entry at {1:hh\\:mm} (+{2} min)",
                      winEnd, tod, minutesOver)
                : string.Format("Session starts {0:hh\\:mm}, entry at {1:hh\\:mm} (-{2} min)",
                      winStart, tod, minutesOver);

            Commit(6, classA: dE, classB: 0.0, P: P);
        }

        private void CommitD7OnEntry(double P)
        {
            // Class A — saturating-marginal on excess trades past the
            // trader's declared TradesPerSessionMax (Axiom 6).
            //
            // Axiom 2 alignment: the declared budget N is the boundary.
            // The (N+1)th trade is the first over-budget entry decision
            // (deduped on OrderId per Anti-pattern 10).  Per-trade
            // marginal severity:
            //   excessNow   = max(0, _sessionEntryCount − TradesPerSessionMax)
            //   targetNow   = CommitA_D7 · (1 − e^(−excessNow / scale_d7))
            //   targetPrev  = CommitA_D7 · (1 − e^(−_prevD7ExcessTrades / scale_d7))
            //   ΔE          = targetNow − targetPrev
            // scale_d7 = TradesPerSessionMax (Axiom 8 — r=1 psychologically
            // means "doubled the declared trade count").  First over-budget
            // trade gives a small non-zero marginal, subsequent over-budget
            // trades add diminishing but strictly positive deposits; total
            // per session bounded at CommitA_D7.
            if (_profile != null && _profile.TradesPerSessionMax > 0)
            {
                double excessNow = Math.Max(0.0,
                    _sessionEntryCount - _profile.TradesPerSessionMax);
                if (excessNow > _prevD7ExcessTrades)
                {
                    double scale = Math.Max(1.0, _d7Scale);
                    double targetNow  = _cfg.CommitA_D7 *
                                        (1.0 - Math.Exp(-excessNow          / scale));
                    double targetPrev = _cfg.CommitA_D7 *
                                        (1.0 - Math.Exp(-_prevD7ExcessTrades / scale));
                    double marginal = targetNow - targetPrev;
                    if (marginal > 0.0)
                    {
                        Commit(7, classA: marginal, classB: 0.0, P: P);
                        _prevD7ExcessTrades = excessNow;
                    }
                }

                // Class B — budget-pressure ramp.
                //
                // Psychological basis: a trader approaching their declared trade
                // budget experiences increasing cognitive constraint.  The signal
                // fires while STILL within the limit (excessNow == 0) so it
                // produces a gradual PSI slope rather than a pure cliff at the
                // moment Class A fires.
                //
                //   utilization      = sessionEntryCount / TradesPerSessionMax
                //   budget_pressure  = clamp((utilization − 0.5) / 0.5, 0, 1)
                //   ΔE_B             = CommitB_D7Budget × budget_pressure
                //
                // At <50 % utilization: budget_pressure = 0 (well within budget).
                // At 75 % utilization: budget_pressure = 0.5 (halfway to limit).
                // At 100 % utilization: budget_pressure = 1.0 (fully committed).
                //
                // CommitB_D7Budget ≈ 0.5 × CommitB_D7 (derivation in config).
                // Not amplified by P because approaching a declared limit is a
                // structural constraint, not an emotionally-driven impulse.
                if (excessNow == 0.0 && _profile.TradesPerSessionMax > 0)
                {
                    double utilization    = (double)_sessionEntryCount / _profile.TradesPerSessionMax;
                    double budgetPressure = Math.Max(0.0, (utilization - 0.5) / 0.5);
                    if (budgetPressure > 0.0)
                        Commit(7, classA: 0.0,
                               classB: _cfg.CommitB_D7Budget * budgetPressure, P: 0.0);
                }
            }

            // Class B — recent inter-entry gap < D7AccelFasterThan × session
            // average.  Requires enough history for a meaningful average.
            if (_sessionEntryCount < _cfg.D7MinSessionEntriesForAccel) return;
            if (_recentEntryTimes.Count < 3) return;

            var arr = _recentEntryTimes.ToArray();
            int n = arr.Length;
            double recentGap = Math.Max(1.0,
                (arr[n - 1] - arr[n - 2]).TotalSeconds);
            double sessionAvgGap = 0.0;
            if (_sessionFirstEntryTime != DateTime.MinValue && _sessionEntryCount > 1)
                sessionAvgGap = Math.Max(1.0,
                    (arr[n - 1] - _sessionFirstEntryTime).TotalSeconds /
                    Math.Max(1, _sessionEntryCount - 1));

            if (sessionAvgGap <= 0) return;
            if (recentGap < _cfg.D7AccelFasterThan * sessionAvgGap)
                Commit(7, classA: 0.0, classB: _cfg.CommitB_D7, P: P);
        }

        private void EnqueueRecentEntry(DateTime t)
        {
            const int Cap = 10;
            _recentEntryTimes.Enqueue(t);
            while (_recentEntryTimes.Count > Cap) _recentEntryTimes.Dequeue();
        }

        // =====================================================================
        // Continuous-state dimensions refresh (D2 naked, D3 size, D5 overstay)
        //
        // Called on every fill / order-change / poll so these dimensions
        // track the authoritative position set, not a cached snapshot.  The
        // integration uses sample-and-hold on the [lastPosSampleAt, eventTime]
        // interval — same physically-homogeneous treatment as v1.1.4 D3 but
        // unified across all three continuous dimensions.
        // =====================================================================

        private void RecomputeContinuousDimensions(
            IEnumerable<PositionSnapshot> positions,
            DateTime eventTime,
            double P,
            out bool overExposed,
            out bool nakedDetected)
        {
            nakedDetected = false;
            overExposed   = false;

            double liveMaxSize = 0.0;
            bool anyOpen = false;
            PositionSnapshot worstOverstay = null;
            double worstOverstaySec = 0.0;
            double aggNakedWeight = 0.0;       // sum of in-loser weights for naked exposure

            // D5 threshold: a position is "overstayed" only when its hold
            // time has exceeded the declared MaxHoldSec (Axiom 8 personalisation
            // — _d5Scale was seeded from profile.MaxHoldMinutes at construction).
            // Before the boundary, overstay = 0 and D5 contributes nothing —
            // the trader has not crossed the commitment they declared.
            double maxHoldSec = _d5Scale;   // scale_D5 ≡ profile.MaxHoldMinutes × 60

            if (positions != null)
            {
                foreach (var snap in positions)
                {
                    if (snap == null) continue;
                    if (snap.Quantity <= 0) continue;
                    anyOpen = true;
                    if (snap.Quantity > liveMaxSize) liveMaxSize = snap.Quantity;

                    if (!snap.HasStopOrder)
                        nakedDetected = true;

                    double overstayThis = Math.Max(0.0, snap.HoldSeconds - maxHoldSec);
                    if (overstayThis > worstOverstaySec)
                    {
                        worstOverstaySec = overstayThis;
                        worstOverstay = snap;
                    }
                }
            }

            double sizeMax  = _profile != null ? _profile.SizeMax : double.PositiveInfinity;
            double excessNow = Math.Max(0.0, liveMaxSize - sizeMax);
            overExposed = excessNow > 0.0;

            double dt = 0.0;
            if (_lastPosSampleAt != DateTime.MinValue)
            {
                dt = (eventTime - _lastPosSampleAt).TotalSeconds;
                if (dt < 0) dt = 0;
                if (dt > _cfg.MaxDeltaSec) dt = _cfg.MaxDeltaSec;
            }

            // ── D3 size: Axiom 6 saturating Class A + persistence × dt Class B ──
            //
            // Saturating Class A (ARCHITECTURE.md §15.10):
            //   targetE(s)   = CommitA_D3 · (1 − exp(−s / scale_D3))
            //   commit_delta = targetE(excessNow) − targetE(_prevSizeOverLimit)
            //
            // This keeps the sum of Class A evidence contributed during a
            // single over-size episode bounded at CommitA_D3, regardless
            // of how many partial fills (step-ups) the broker reports.
            //
            // Class B has a RECOGNITION GRACE WINDOW (NoStopGraceSeconds) before
            // it starts firing — the same window used by D2 (naked exposure).
            // Rationale: a disciplined trader who accidentally entered oversize
            // will self-correct within seconds; only sustained oversize (beyond
            // the recognition window) constitutes evidence of deliberate rule-
            // breaking.  Firing Class B from t=0 punishes accidental entries
            // identically to intentional ones, which violates the product goal
            // of measuring actual psychological state.
            //
            // scale_D3 is personalised (Axiom 8): at engine init the D3
            // scale is seeded from profile.SizeMax so r = excess/SizeMax
            // is the user-relative severity signal.  See _d3Scale below.
            if (excessNow > _prevSizeOverLimit)
            {
                // Record episode start when first crossing into oversize.
                if (_prevSizeOverLimit <= 0.0 && excessNow > 0.0)
                    _d3OversizeBeganAt = eventTime;

                double scale    = Math.Max(0.01, _d3Scale);
                double targetE  = _cfg.CommitA_D3 * (1.0 - Math.Exp(-excessNow   / scale));
                double prevE    = _cfg.CommitA_D3 * (1.0 - Math.Exp(-_prevSizeOverLimit / scale));
                double marginal = targetE - prevE;
                if (marginal > 0.0)
                    Commit(3, classA: marginal, classB: 0.0, P: P);
            }

            // Class B: only fires for the portion of dt that falls AFTER the
            // recognition grace window.  The formula mirrors D2's grace logic:
            //   oversizeElapsed = time since this episode began
            //   pastGrace       = max(0, oversizeElapsed - graceSec)
            //   intervalPastGrace = min(dt, pastGrace)  — portion of dt past grace
            // Using raw excess
            // (not normalized) would violate Axiom 8: a 4-contract breach on
            // SizeMax=100 (r=0.04) is far less severe per second than the same
            // 4-contract breach on SizeMax=2 (r=2.0).
            if (dt > 0 && _prevSizeOverLimit > 0.0 && _d3OversizeBeganAt != DateTime.MinValue)
            {
                int graceSec3 = _profile != null ? Math.Max(0, _profile.NoStopGraceSeconds) : 20;
                double oversizeElapsedSec = (eventTime - _d3OversizeBeganAt).TotalSeconds;
                double pastGraceSec       = Math.Max(0.0, oversizeElapsedSec - graceSec3);
                if (pastGraceSec > 0.0)
                {
                    double intervalPastGrace = Math.Min(dt, pastGraceSec);
                    double scale    = Math.Max(0.01, _d3Scale);
                    double relExcess = _prevSizeOverLimit / scale;  // r = excess / SizeMax
                    Commit(3, classA: 0.0,
                           classB: _cfg.CommitB_D3 * relExcess * intervalPastGrace, P: P);
                }
            }

            // Clear the episode timer when position drops back within SizeMax.
            if (excessNow <= 0.0 && _d3OversizeBeganAt != DateTime.MinValue)
                _d3OversizeBeganAt = DateTime.MinValue;

            _prevSizeOverLimit = excessNow;

            // ── D2 naked exposure (ARCHITECTURE.md §15.15 — saturating-
            //    marginal Class A + persistence-integration Class B,
            //    both outcome-free and continuous on pastGraceSec) ──────
            //
            // Declared commitment:  NoStopGraceSeconds  = "I'll place the
            //                       SL within this many seconds of entry."
            // Severity axis s(t) = max(0, nakedElapsedSec − NoStopGraceSeconds)
            //                      — seconds past the trader's own grace.
            // Scale (Axiom 8):     scale_D2 = NoStopGraceSeconds  ⇒ r=1
            //                      means "naked twice as long as you said
            //                      you needed to place the stop."
            //
            // Class A (saturating-marginal):
            //   targetNow  = CommitA_D2 · (1 − e^(−sNow  / scale_D2))
            //   targetPrev = CommitA_D2 · (1 − e^(−sPrev / scale_D2))
            //   ΔE         = targetNow − targetPrev    (only non-negative)
            // Every tick grows sNow slightly ⇒ slightly more marginal
            // evidence, saturating at CommitA_D2 for one naked epoch.  No
            // step, no threshold, no multiplier.
            //
            // Class B (persistence integration, unchanged shape):
            //   ΔE = CommitB_D2 × intervalPastGrace
            int graceSec = _profile != null ? Math.Max(0, _profile.NoStopGraceSeconds) : 20;
            if (nakedDetected)
            {
                if (_nakedStateBeganAt == DateTime.MinValue)
                {
                    _nakedStateBeganAt     = eventTime;
                    _prevNakedPastGraceSec = 0.0;
                }
                double nakedElapsed = Math.Max(0.0,
                    (eventTime - _nakedStateBeganAt).TotalSeconds);
                double pastGrace    = Math.Max(0.0, nakedElapsed - graceSec);

                if (pastGrace > 0.0)
                {
                    double scale = Math.Max(1.0, _d2Scale);
                    double targetNow  = _cfg.CommitA_D2 *
                                        (1.0 - Math.Exp(-pastGrace              / scale));
                    double targetPrev = _cfg.CommitA_D2 *
                                        (1.0 - Math.Exp(-_prevNakedPastGraceSec / scale));
                    double marginalA  = targetNow - targetPrev;

                    double classB = 0.0;
                    if (dt > 0)
                    {
                        double intervalPastGrace = Math.Min(dt, pastGrace);
                        classB = _cfg.CommitB_D2 * intervalPastGrace;
                    }

                    if (marginalA > 0.0 || classB > 0.0)
                        Commit(2, classA: marginalA, classB: classB, P: P);

                    _prevNakedPastGraceSec = pastGrace;
                }
            }
            else
            {
                _nakedStateBeganAt     = DateTime.MinValue;
                _prevNakedPastGraceSec = 0.0;
            }

            // ── D5 overstay (ARCHITECTURE.md §15.14 — saturating-marginal
            //    Class A + persistence-integration Class B, both outcome-free)
            //
            // Inputs (all process, no P&L):
            //   overstaySec(t)  = max(0, HoldSec(t) − MaxHoldSec).  Zero
            //                     while the position is within declared max;
            //                     grows continuously once crossed.
            //   scale_D5        = profile.MaxHoldMinutes × 60 (Axiom 8
            //                     personalisation, seeded at construction).
            //
            // Class A (saturating-marginal, Axiom 6):
            //   targetE(s) = CommitA_D5 · (1 − exp(−s / scale_D5))
            //   ΔE         = targetE(overstayNow) − targetE(_prevWorstOverstaySec)
            //
            //   Properties: bounded per episode at CommitA_D5; severity-
            //   proportional in the small; no step-function cliff; no
            //   per-position one-shot latch needed (the severity map is
            //   what bounds C_5 asymptotically, Axiom 2 invariant #3).
            //
            // Class B (persistence integration, outcome-free):
            //   ΔE per dt = CommitB_D5 × (overstayNow / scale_D5) × dt
            //
            //   Relative severity `r = overstayNow / scale_D5` is the
            //   user-invariant pressure signal — 1.0 means "doubled the
            //   declared max".  Identical relative pressure ⇒ identical
            //   signal regardless of whether declared max is 5 min or 60 min
            //   (Axiom 8 / Invariant I6).
            //
            //   P&L IS NOT READ.  The previous `weight = -MinUnrealizedPnl /
            //   μLoss` formulation was a direct discipline-over-outcome
            //   violation: holding a winner past declared max produced zero
            //   signal, holding a loser produced full signal — same process,
            //   opposite outputs.  Retired 2026-04-23.  See
            //   `psi-discipline-over-outcome.mdc` D5 section.
            if (worstOverstay != null && worstOverstaySec > 0.0)
            {
                double scale5 = Math.Max(1.0, _d5Scale);

                double targetNow  = _cfg.CommitA_D5 * (1.0 - Math.Exp(-worstOverstaySec    / scale5));
                double targetPrev = _cfg.CommitA_D5 * (1.0 - Math.Exp(-_prevWorstOverstaySec / scale5));
                double marginal   = targetNow - targetPrev;
                if (marginal > 0.0)
                    Commit(5, classA: marginal, classB: 0.0, P: P);

                if (dt > 0)
                {
                    double relOver = worstOverstaySec / scale5;
                    Commit(5, classA: 0.0,
                           classB: _cfg.CommitB_D5 * relOver * dt, P: P);
                }

                _prevWorstOverstaySec = worstOverstaySec;
            }
            else
            {
                // No active overstay: reset the marginal anchor so the next
                // overstay episode starts fresh from 0 (Axiom 2 — decay is
                // the cooldown; the severity map bounds C_5 on its own).
                _prevWorstOverstaySec = 0.0;
            }

            _lastPosSampleAt = eventTime;
        }

        private static double Clamp01(double v)
            => v < 0 ? 0 : (v > 1 ? 1 : v);
    }
}
