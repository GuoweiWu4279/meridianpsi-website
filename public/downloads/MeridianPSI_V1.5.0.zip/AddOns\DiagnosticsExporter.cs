// DiagnosticsExporter.cs
//
// Collects a point-in-time snapshot of every piece of state that is useful
// for diagnosing a support report, then writes a plain-text report file to
// the user's Desktop.
//
// Design goals:
//   • Zero dependencies on NT8 UI thread — all data is pre-copied by
//     TradeMonitor.GetDiagnosticsSnapshot() before this class is called.
//   • Pure text output — readable in any email client or pastebin.
//   • Self-contained — no external libraries.
//
// Usage:
//   var snap = _monitor.GetDiagnosticsSnapshot();
//   string path = DiagnosticsExporter.WriteToDesktop(snap);

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================================
    // DiagnosticsSnapshot — everything the exporter needs, pre-copied from
    // live objects on the UI thread so the writer can run on a Task thread.
    // =========================================================================
    internal sealed class DiagnosticsSnapshot
    {
        // ── Metadata ─────────────────────────────────────────────────────────
        public string   ProductVersion;
        public DateTime ExportTimeUtc;
        public string   MachineName;
        public string   OsVersion;
        public string   TradingMode;          // "Live" / "Simulation" / "Playback"
        public string[] ActiveAccounts;       // account names

        // ── Strategy Profile ─────────────────────────────────────────────────
        public int    SessionStartHour;
        public int    SessionStartMinute;
        public int    SessionEndHour;
        public int    SessionEndMinute;
        public bool   SessionWindowEnabled;
        public int    SlTicksMax;
        public double SizeMin;
        public double SizeMax;
        public int    TradesPerSessionMin;
        public int    TradesPerSessionMax;
        public int    MaxHoldMinutes;
        public bool   NoStopLossTrader;
        public int    NoStopGraceSeconds;
        public double MaxDailyLossUsd;
        public int    PauseAfterNLosses;
        public bool   ExcludeStrategyOrders;
        public string Sensitivity;
        public int    ColdStartInterTradeGapPriorSec;
        public double ReversalPenaltyFactor;

        // ── Engine State ─────────────────────────────────────────────────────
        public double CurrentPsi;
        public double CurrentPressure;
        public double PeakPressure;
        public int    ConsecutiveLosses;
        public int    ClassACommitCount;
        public double[] Evidence;         // E[1..7] — raw accumulators
        public double[] SeverityPct;      // C[1..7] mapped 0..100
        public double[] PeakSeverityPct;  // peak C[1..7] this session
        public string[] DimLastClass;     // "A" / "B" / "None" per dim 1..7

        // ── Recent PSI commits ───────────────────────────────────────────────
        public CommitEventLine[] RecentCommits;  // last ≤20, oldest first

        // ── Session summary ──────────────────────────────────────────────────
        public DateTime SessionDate;
        public int      TotalTrades;
        public int      WinTrades;
        public double   TotalPnl;
        public double   SessionPnlLive;   // includes uncommitted session pnl
        public int      AlertsFired;
        public int      NakedPositionDetections;
        public double   MinPsi;
        public double   StartPsi;
        public double   TimeInCautionMin;
        public double   TimeInCriticalMin;

        // ── Baseline stats ───────────────────────────────────────────────────
        public int    BaselineSessionCount;
        public double BaselineMuLoss;
        public double BaselineSigmaLoss;
        public double BaselineMuGapSec;
        public int    BaselineGapSampleCount;

        // ── Guard rules ──────────────────────────────────────────────────────
        public GuardRuleLine[] GuardRules;

        // ── Integrity check ──────────────────────────────────────────────────
        public string IntegrityStatus;   // "OK" or violation summary
    }

    internal sealed class CommitEventLine
    {
        public string TimeLocal;
        public int    Dim;
        public string Class;    // "A" / "B"
        public double Amount;   // evidence deposited
        public double Pressure;
    }

    internal sealed class GuardRuleLine
    {
        public bool   Enabled;
        public string Name;
        public string Conditions;
        public string Action;
        public bool   LastTriggeredThisSession;
    }

    // =========================================================================
    // DiagnosticsExporter
    // =========================================================================
    internal static class DiagnosticsExporter
    {
        private static readonly string[] DimNames = {
            "", "D1 Revenge Entry", "D2 Naked Position", "D3 Oversize",
            "D4 Hold Bias", "D5 Overstay", "D6 Session / Daily-Loss",
            "D7 Overtrading"
        };

        /// <summary>
        /// Writes a plain-text diagnostic report to the user's Desktop and
        /// returns the full file path.
        /// </summary>
        public static string WriteToDesktop(DiagnosticsSnapshot s)
        {
            string ts   = s.ExportTimeUtc.ToString("yyyy-MM-dd_HH-mm-ss");
            string path = Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.Desktop),
                $"MeridianPSI_Diagnostics_{ts}.txt");

            string report = BuildReport(s);
            File.WriteAllText(path, report, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
            return path;
        }

        public static string BuildReport(DiagnosticsSnapshot s)
        {
            var sb = new StringBuilder(4096);
            string sep = new string('=', 60);
            string sub = new string('-', 40);

            sb.AppendLine(sep);
            sb.AppendLine("  MERIDIAN PSI -- SUPPORT DIAGNOSTICS REPORT");
            sb.AppendLine(sep);
            sb.AppendLine();

            // ── Metadata ─────────────────────────────────────────────────────
            sb.AppendLine("METADATA");
            sb.AppendLine(sub);
            Kv(sb, "Product Version", s.ProductVersion);
            Kv(sb, "Export Time (UTC)", s.ExportTimeUtc.ToString("u"));
            Kv(sb, "Export Time (Local)", s.ExportTimeUtc.ToLocalTime().ToString("u"));
            Kv(sb, "Machine", s.MachineName);
            Kv(sb, "OS", s.OsVersion);
            Kv(sb, "Trading Mode", s.TradingMode);
            Kv(sb, "Active Accounts",
                s.ActiveAccounts != null && s.ActiveAccounts.Length > 0
                    ? string.Join(", ", s.ActiveAccounts)
                    : "(none)");
            sb.AppendLine();

            // ── Strategy Profile ─────────────────────────────────────────────
            sb.AppendLine("STRATEGY PROFILE");
            sb.AppendLine(sub);
            Kv(sb, "Sensitivity",             s.Sensitivity);
            Kv(sb, "Session Window",
                s.SessionWindowEnabled
                    ? $"{s.SessionStartHour:00}:{s.SessionStartMinute:00} - {s.SessionEndHour:00}:{s.SessionEndMinute:00}"
                    : "Disabled");
            Kv(sb, "Size Min / Max",           $"{s.SizeMin} / {s.SizeMax} contracts");
            Kv(sb, "Trades Per Session",        $"{s.TradesPerSessionMin} - {s.TradesPerSessionMax}");
            Kv(sb, "Max Hold Minutes",          s.MaxHoldMinutes.ToString());
            Kv(sb, "Max Daily Loss USD",
                s.MaxDailyLossUsd > 0 ? $"${s.MaxDailyLossUsd:F2}" : "Disabled");
            Kv(sb, "Pause After N Losses",
                s.PauseAfterNLosses > 0 ? s.PauseAfterNLosses.ToString() : "Disabled");
            Kv(sb, "No Stop Loss Trader",       s.NoStopLossTrader ? "Yes" : "No");
            Kv(sb, "No Stop Grace Seconds",     s.NoStopGraceSeconds.ToString());
            Kv(sb, "Stop Loss Ticks Max",       s.SlTicksMax.ToString());
            Kv(sb, "Reversal Penalty Factor",   s.ReversalPenaltyFactor.ToString("F2"));
            Kv(sb, "Exclude Strategy Orders",   s.ExcludeStrategyOrders ? "Yes" : "No");
            Kv(sb, "Cold-Start Gap Prior (s)",  s.ColdStartInterTradeGapPriorSec.ToString());
            sb.AppendLine();

            // ── Engine State ─────────────────────────────────────────────────
            sb.AppendLine("ENGINE STATE (current)");
            sb.AppendLine(sub);
            Kv(sb, "PSI",                    s.CurrentPsi.ToString("F1"));
            Kv(sb, "Pressure",               s.CurrentPressure.ToString("F3"));
            Kv(sb, "Peak Pressure",          s.PeakPressure.ToString("F3"));
            Kv(sb, "Consecutive Losses",     s.ConsecutiveLosses.ToString());
            Kv(sb, "Class-A Commits (session)", s.ClassACommitCount.ToString());
            sb.AppendLine();

            sb.AppendLine("  Dim  Name                      E (accum)   Sev%   Peak%   LastClass");
            sb.AppendLine("  " + new string('-', 72));
            for (int i = 1; i <= 7; i++)
            {
                double e    = s.Evidence      != null && s.Evidence.Length      > i ? s.Evidence[i]      : 0;
                double sev  = s.SeverityPct   != null && s.SeverityPct.Length   > i ? s.SeverityPct[i]   : 0;
                double peak = s.PeakSeverityPct != null && s.PeakSeverityPct.Length > i ? s.PeakSeverityPct[i] : 0;
                string cls  = s.DimLastClass  != null && s.DimLastClass.Length  > i ? s.DimLastClass[i]  : "-";
                sb.AppendLine($"  D{i}   {DimNames[i],-26}  {e,8:F3}   {sev,5:F1}  {peak,6:F1}   {cls}");
            }
            sb.AppendLine();

            // ── Recent commits ────────────────────────────────────────────────
            sb.AppendLine("RECENT PSI COMMITS (last 20)");
            sb.AppendLine(sub);
            if (s.RecentCommits == null || s.RecentCommits.Length == 0)
            {
                sb.AppendLine("  (none this session)");
            }
            else
            {
                sb.AppendLine("  Time (local)        Dim  Class    Amount     Pressure");
                sb.AppendLine("  " + new string('-', 54));
                foreach (var c in s.RecentCommits)
                {
                    sb.AppendLine($"  {c.TimeLocal,-20}  D{c.Dim}   [{c.Class}]   {c.Amount,8:F3}   {c.Pressure:F3}");
                }
            }
            sb.AppendLine();

            // ── Session ───────────────────────────────────────────────────────
            sb.AppendLine("SESSION SUMMARY");
            sb.AppendLine(sub);
            Kv(sb, "Session Date",          s.SessionDate.ToString("yyyy-MM-dd"));
            Kv(sb, "Total Trades",          s.TotalTrades.ToString());
            Kv(sb, "Win Trades",            s.WinTrades.ToString());
            Kv(sb, "Win Rate",
                s.TotalTrades > 0
                    ? $"{100.0 * s.WinTrades / s.TotalTrades:F1}%"
                    : "N/A");
            Kv(sb, "Total PnL",             $"${s.TotalPnl:F2}");
            Kv(sb, "Session PnL (live)",    $"${s.SessionPnlLive:F2}");
            Kv(sb, "Alerts Fired",          s.AlertsFired.ToString());
            Kv(sb, "Naked Pos Detections",  s.NakedPositionDetections.ToString());
            Kv(sb, "Start PSI",             s.StartPsi.ToString("F1"));
            Kv(sb, "Min PSI",               s.MinPsi.ToString("F1"));
            Kv(sb, "Time in Caution",       $"{s.TimeInCautionMin:F1} min");
            Kv(sb, "Time in Critical",      $"{s.TimeInCriticalMin:F1} min");
            sb.AppendLine();

            // ── Baseline ─────────────────────────────────────────────────────
            sb.AppendLine("BASELINE STATS");
            sb.AppendLine(sub);
            Kv(sb, "Sessions Recorded",     s.BaselineSessionCount.ToString());
            Kv(sb, "Mu Loss",               $"${s.BaselineMuLoss:F2}");
            Kv(sb, "Sigma Loss",            $"${s.BaselineSigmaLoss:F2}");
            Kv(sb, "Mean Inter-Trade Gap",  $"{s.BaselineMuGapSec:F1}s");
            Kv(sb, "Gap Sample Count",      s.BaselineGapSampleCount.ToString());
            sb.AppendLine();

            // ── Guard rules ───────────────────────────────────────────────────
            sb.AppendLine("GUARD RULES");
            sb.AppendLine(sub);
            if (s.GuardRules == null || s.GuardRules.Length == 0)
            {
                sb.AppendLine("  (no rules configured)");
            }
            else
            {
                for (int i = 0; i < s.GuardRules.Length; i++)
                {
                    var r = s.GuardRules[i];
                    sb.AppendLine($"  [{i + 1}] {(r.Enabled ? "ON " : "OFF")} | {r.Name}");
                    sb.AppendLine($"       Conditions : {r.Conditions}");
                    sb.AppendLine($"       Action     : {r.Action}");
                    sb.AppendLine($"       Triggered  : {(r.LastTriggeredThisSession ? "YES (this session)" : "No")}");
                }
            }
            sb.AppendLine();

            // ── Integrity check ───────────────────────────────────────────────
            sb.AppendLine("INTEGRITY CHECK");
            sb.AppendLine(sub);
            sb.AppendLine("  " + (s.IntegrityStatus ?? "Not run"));
            sb.AppendLine();

            sb.AppendLine(sep);
            sb.AppendLine("  END OF REPORT");
            sb.AppendLine(sep);

            return sb.ToString();
        }

        private static void Kv(StringBuilder sb, string key, string value)
        {
            sb.AppendLine($"  {key,-34}  {value}");
        }
    }
}
