// PsiEngineConfig.cs
//
// Named configuration for every tunable parameter in PsiEngine.
//
// Architecture:
//   Phase 1 extracted all hard-coded literals into named fields.
//   Phase 2 (Level 2 Statistical Math Upgrade) replaced heuristic sigmoid
//   mappings with NormalCdf(z - k) derived from the trader's own baseline.
//   D-score thresholds are now controlled by a single FalsePositiveRate
//   parameter (default 2.5%) instead of per-dimension sigmoid offsets.
//
// Design constraints:
//   - Zero NinjaTrader API dependencies (unit-testable).
//   - Immutable after construction — safe for concurrent reads from PsiEngine.
//   - Default property returns calibrated values for the Balanced preset.

using System;

namespace NinjaTrader.NinjaScript.AddOns
{
    public sealed class PsiEngineConfig
    {
        // =================================================================
        // Session carry-forward  (overnight EWMA decay model)
        //
        // PSI carries forward via the same EWMA decay formula used intra-session,
        // but applied to the overnight gap:
        //
        //   decayFactor = exp(-overnightHours / OvernightRecoveryTauHours)
        //
        // When live C_i values are available (cross-day boundary during a run):
        //   C_i_tomorrow = C_i_today × decayFactor          (ApplyOvernightDecay)
        //   openPSI      = 100 − Σ C_i_tomorrow − carryDebt_tomorrow
        //
        // When only prevFinalPsi is available (startup / Playback restart):
        //   openPSI = 100 − (100 − prevFinalPsi) × decayFactor  (StartNewSession)
        //
        // Example (tau=48h, overnight=16h → decay≈0.72):
        //   prevPSI=0  → openPSI≈28    (severely tilted — limited overnight recovery)
        //   prevPSI=24 → openPSI≈45
        //   prevPSI=71 → openPSI≈79    (oversize debt → NOT wiped to 95 like buckets did)
        //   prevPSI=90 → openPSI≈93
        // =================================================================

        /// <summary>
        /// Time constant (hours) for overnight PSI debt recovery.
        /// 48 h ≈ 2 days of calm behaviour to fully dissolve the worst session's debt.
        /// Conservative preset uses 72 h; Aggressive uses 36 h.
        /// </summary>
        public double OvernightRecoveryTauHours { get; set; } = 48.0;

        /// <summary>
        /// Estimated overnight gap (hours) used when the actual gap is unknown
        /// (e.g. at startup when only the previous session's final PSI is stored).
        /// 16 h represents a typical market-close-to-open gap.
        /// </summary>
        public double OvernightEstimatedHours { get; set; } = 16.0;

        // =================================================================
        // Consecutive-loss tracking
        // =================================================================

        /// <summary>Geometric decay factor applied to the loss-streak counter on each win (0.6 = 40% reduction).</summary>
        public double WinStreakDecayFactor { get; set; } = 0.6;

        /// <summary>Streak is zeroed when it decays below this threshold.</summary>
        public double StreakClearThreshold { get; set; } = 0.05;

        // =================================================================
        // D1: Revenge Entry
        // =================================================================

        /// <summary>Floor for the time delta between fills (prevents div-by-zero).</summary>
        public double D1MinDeltaSeconds { get; set; } = 1.0;

        /// <summary>Guard: if baseline muSize is below this, treat ratio as 1.0 to avoid div-by-zero.</summary>
        public double D1MuSizeZeroGuard { get; set; } = 0.01;

        /// <summary>
        /// Floor multiplier applied when size z-score is at or below baseline (sizeX near zero).
        /// Ensures a same-size revenge re-entry still scores partially even without size escalation.
        /// A value of 0.35 gives ~35% of full score for same-size re-entries.
        /// Set to 0.0 to restore the original strict size-gating behavior.
        /// </summary>
        public double D1MinSizeFactor { get; set; } = 0.35;

        /// <summary>
        /// Saturation ceiling of the consecutive-loss pressure component injected into D1's
        /// lossX factor.  At infinite streak length the component asymptotes to this value.
        /// A value of 0.50 means 3 back-to-back losses can contribute at most 0.44 lossX even
        /// if each individual loss is exactly average (lossZ = 0).
        /// Set to 0.0 to disable streak-based D1 pressure entirely (reverts to pure z-score gating).
        /// </summary>
        public double D1ConsecutiveLossBase { get; set; } = 0.50;

        /// <summary>
        /// Saturation ceiling of the BACKGROUND streak pressure — the persistent floor returned
        /// by CalcD1 on close fills and used as a minimum on entry fills.
        ///
        /// Design separation:
        ///   D1ConsecutiveLossBase  (0.50) — controls the urgency spike on fast re-entries
        ///                                   (lossX component, combined with urgency × sizeX).
        ///   D1StreakBackgroundBase (0.25) — controls the quiet, continuous pressure that
        ///                                   accumulates just from being on a losing streak,
        ///                                   regardless of re-entry speed.
        ///
        /// Kept smaller than D1ConsecutiveLossBase so that a disciplined 45%-win-rate trader
        /// (whose streak naturally oscillates 1–3 without fully clearing) does not accumulate
        /// excessive permanent C1 debt.  The entry urgency path retains its full strength.
        /// Set to 0.0 to disable the background component entirely.
        /// </summary>
        public double D1StreakBackgroundBase { get; set; } = 0.25;

        /// <summary>
        /// Exponential growth rate of the consecutive-loss pressure component.
        /// streakPressure = D1ConsecutiveLossBase × (1 − exp(−gain × consecutiveLosses)).
        /// At gain = 0.70: after 1 loss ≈ 0.25, after 2 ≈ 0.38, after 3 ≈ 0.44.
        /// Higher values saturate faster (sharper first-loss impact).
        /// </summary>
        public double D1ConsecutiveLossGain { get; set; } = 0.70;

        // =================================================================
        // D2: Stop-Loss Manipulation
        // =================================================================

        /// <summary>Tick buffer for classifying a stop-move as "widening" vs rounding noise.</summary>
        public double D2SlTickRoundingBuffer { get; set; } = 0.5;

        /// <summary>
        /// Exponential saturation rate for adverse-move count → D2 base score.
        /// baseScore = 1 - exp(-rate × adverseMoveCount).
        /// </summary>
        public double D2AdverseSaturationRate { get; set; } = 0.8;

        /// <summary>
        /// Multiplier on SlTicksMax: SL width beyond this triggers the boost path in D2.
        /// 1.5 = 50% above the declared max triggers the severe-manipulation signal.
        /// </summary>
        public double D2SlBreachMultiplier { get; set; } = 1.5;

        /// <summary>
        /// Time constant (seconds) for the D2 naked-position continuous signal.
        /// raw_naked = 1 − exp(−nakedSeconds / D2NakedTimeConstantSec).
        /// At 60 s (default): 30 s exposure → 0.39, 60 s → 0.63, 120 s → 0.86.
        /// Smaller τ = faster alarm growth; larger τ = more forgiving.
        /// Replaces the legacy one-shot NakedPositionDeduction hard deduction
        /// (removed in the 2026-04-21 first-principles refactor).
        /// </summary>
        public double D2NakedTimeConstantSec { get; set; } = 60.0;

        // =================================================================
        // D3: Size Outlier — unified over-limit evidence accumulator E(t)
        //
        // E(t) is a single state variable with unit [contract·seconds].
        // It accumulates three physically-homogeneous contributions, none of
        // which is an "exceptional path":
        //
        //   1. Commit jump on any fill that deepens |q|-SizeMax:
        //        ΔE = k_commit × (excess_now - excess_prev)⁺
        //      Captures the DECISION to enter or deepen an over-limit state
        //      even when held for zero seconds.  k_commit has unit
        //      [seconds per contract committed over limit].
        //
        //   2. Persistence integration while |q| > SizeMax:
        //        dE/dt = excess(t)       (sample-and-hold between events)
        //      Captures the CHOICE TO STAY in an over-limit state.
        //
        //   3. Natural first-order decay once back within profile:
        //        dE/dt = -E / τ_decay    (strictly no cooldown state machine)
        //      E relaxes back to 0; the memory of the commitment fades.
        //
        // The D3 raw score is a smooth bijection of E:
        //        D3_raw = 1 - exp(-E / τ_size)
        // Fed through the unchanged snap-up / recovery pipeline in
        // ApplyDecomposedEwma.  Note: D3 does NOT read _consecutiveLosses,
        // pnl, or any outcome signal — this preserves the discipline-over-
        // outcome invariant (see psi-discipline-over-outcome.mdc).
        // =================================================================

        /// <summary>
        /// Commit-jump equivalence constant (seconds per contract committed
        /// over limit).  The act of sending a fill that takes the net position
        /// from excess=a to excess=b (b&gt;a) credits E by <c>(b-a) × this</c>
        /// contract·seconds — i.e. "committing one contract over is equivalent
        /// to having held one contract over for this many seconds".
        /// Closes scalper loophole: even a zero-duration over-size still
        /// registers a proportional D3 reaction.  Larger value = the decision
        /// to oversize hurts more; smaller = the persistence term dominates.
        /// </summary>
        public double D3CommitEquivalentSec { get; set; } = 30.0;

        /// <summary>
        /// Time constant (seconds) for natural decay of the over-limit
        /// evidence accumulator E(t) once the position is back within the
        /// declared profile (|q| ≤ SizeMax).  E *= exp(-dt/this) per sample.
        /// Replaces the legacy <c>EwmaFrozenRecoveryTau</c> +
        /// <c>EwmaPostOverexposureTau</c> + <c>OverexposureCooldownMinutes</c>
        /// state machine.
        /// </summary>
        public double D3ExcessDecayTauSec { get; set; } = 90.0;

        /// <summary>
        /// Time constant (contract·seconds) mapping accumulated over-limit
        /// evidence to the D3 raw signal:  raw = 1 − exp(−E / this).
        /// Lower value = D3 saturates faster (small E already gives raw ≈ 1);
        /// higher = more forgiving.  Replaces the legacy
        /// <c>D3ProfileViolationFloor</c> / <c>D3WithinProfileCap</c> pair.
        /// </summary>
        public double D3ExcessIntegralTau { get; set; } = 60.0;

        // =================================================================
        // D4: Hold-Time Collapse
        // =================================================================

        /// <summary>Floor for baseline hold-time mean (seconds), prevents div-by-zero.</summary>
        public double D4MinHoldGuardSec { get; set; } = 1.0;

        /// <summary>Epsilon added to log-odds numerator/denominator to prevent log(0).</summary>
        public double D4LogOddsEpsilon { get; set; } = 0.01;

        /// <summary>
        /// Log-scale standard deviation for the per-trade hold-time signal.
        /// A value of 0.7 means a hold time that is ~50% shorter than the historical
        /// mean produces z ≈ 1.0 — the signal requires a 2σ deviation to fire.
        /// Smaller values = more sensitive to individual trade anomalies.
        /// </summary>
        public double D4PerTradeLogSigma { get; set; } = 0.7;

        /// <summary>
        /// Confidence divisor for the D4 session-level signal.
        /// sessionConf = 1 − 1/√(sessionN / divisor).
        /// Higher values slow the confidence ramp, reducing the raw signal volatility
        /// during early-session periods when the session averages are based on few trades.
        /// Default 2.0: confidence reaches 0.50 at n=8 trades (vs n=4 with divisor=1).
        /// Set to 1.0 to restore the original sqrt(n) confidence formula.
        /// </summary>
        public double D4SessionConfidenceDivisor { get; set; } = 2.0;

        /// <summary>
        /// E4 single-sample cap on the per-trade D4 raw signal (0..1).
        /// A single quick manual exit is statistically ambiguous evidence
        /// (panic vs legitimate re-evaluation).  Treating one fill as a
        /// saturating signal (as pre-v1.1.1 did) caused catastrophic PSI
        /// drops on disciplined stop-loss hits.  The cap limits any single
        /// fill's per-trade D4 contribution; the session signal (uncapped)
        /// is the correct accumulator for repeated quick exits.
        ///
        /// At 0.15:
        ///   1 isolated quick manual exit  → d4 ≲ 0.15 → ~15 PSI pts from D4
        ///   Session of 4-5 quick exits    → d4Session rises (unbounded) to
        ///                                   dominate; D4 becomes meaningfully red
        ///
        /// Set to 1.0 to disable (restores pre-v1.1.1 strong single-sample signal).
        /// </summary>
        public double D4PerTradeSingleSampleCap { get; set; } = 0.15;

        // =================================================================
        // D5: Position Hold (扛单)
        // =================================================================

        /// <summary>
        /// Background signal factor: when hold time is within p90, D5 = severity × this.
        /// Keeps a faint signal visible without raising a false alarm.
        /// </summary>
        public double D5BackgroundSignalFactor { get; set; } = 0.05;

        /// <summary>Floor for the p90 denominator (seconds) — prevents tiny p90 from amplifying overtime.</summary>
        public double D5P90DenomFloorSec { get; set; } = 60.0;

        /// <summary>
        /// Upper bound on D5 output.  Set to 1.0 (no effective cap) so that
        /// extreme hold durations (3h+ vs 30min) remain fully distinguishable.
        /// The old value of 0.7 was intended to protect long-timeframe traders
        /// from a static threshold, but the NormalCdf formula already handles
        /// this via each trader's personal p90 baseline — the cap is redundant
        /// and suppresses the rightmost tail of the overstay signal.
        /// </summary>
        public double D5MaxCap { get; set; } = 1.0;

        // =================================================================
        // D6: Rule Compliance
        // =================================================================

        /// <summary>
        /// Time constant (minutes) for the D6 session-window magnitude envelope.
        /// magnitude = 1 − exp(−minutesOver / D6WindowMagnitudeTau).
        /// 5 min over → 0.18, 15 min → 0.45, 30 min → 0.71, 60 min → 0.91.
        /// Controls how the continuous D6 raw signal rises as a fill lands
        /// further outside the trader's declared session window.
        /// </summary>
        public double D6WindowMagnitudeTau { get; set; } = 30.0;

        /// <summary>
        /// Saturation rate for repeated out-of-window fills within a session.
        /// recency = 1 − exp(−D6RecencyTau × violationCount).
        /// At 0.5: 1 fill → 0.39, 2 → 0.63, 4 → 0.86.
        /// Higher values = steeper escalation per repeated violation.
        /// </summary>
        public double D6RecencyTau { get; set; } = 0.5;

        // =================================================================
        // Financial stress (session P&L hidden debt component)
        //
        // Contributes a continuous, session-level PSI pressure when the
        // cumulative session P&L deficit materially exceeds the trader's
        // typical single-trade loss.  This captures the psychological
        // reality that a -$800 session feels categorically different from
        // a flat session, independent of any individual trade behaviour.
        // =================================================================

        /// <summary>
        /// Weight applied to the financial stress raw score in PSI points.
        /// financialStressDebt_target = FinancialStressWeight × raw × 100.
        /// At 0.12: maximum contribution ≈ 12 PSI points (when session loss
        /// is extremely severe relative to historical baseline).
        /// </summary>
        public double FinancialStressWeight { get; set; } = 0.12;

        // =================================================================
        // Session fatigue (session duration hidden debt component)
        //
        // Applies a mild, continuously rising PSI pressure once the trading
        // session exceeds the optimal-performance window.  Based on the
        // empirically observed decline in decision-making quality over
        // extended trading sessions (cognitive load and cortisol accumulation).
        // Fully resets overnight.
        // =================================================================

        /// <summary>
        /// Session duration (minutes) before fatigue pressure begins.
        /// Below this threshold fatigue contribution is zero.
        /// Default 120 minutes = 2 hours of optimal-performance window.
        /// </summary>
        public double FatigueOptimalWindowMinutes { get; set; } = 120.0;

        /// <summary>
        /// Duration (minutes) over which fatigue ramps from 0 → 1.0 after
        /// the optimal window.  Linear ramp: at OptimalWindow + RampMinutes
        /// the fatigue raw signal reaches its phase-1 ceiling of 1.0.
        /// Default 90 min → phase-1 full at 3.5 hours of trading.
        /// </summary>
        public double FatigueRampMinutes { get; set; } = 90.0;

        /// <summary>
        /// Duration (minutes) of the secondary fatigue ramp, applied after
        /// FatigueRampMinutes is exhausted.  During this window fatigueRaw
        /// grows from 1.0 toward FatigueExtendedCap, allowing the engine to
        /// differentiate a 4-hour session from a 6-hour session.
        /// Default 180 min → extended cap reached at 3.5 h + 3 h = 6.5 h.
        /// Set to 0 to disable the extended ramp (reverts to Clamp01 behaviour).
        /// </summary>
        public double FatigueExtendedRampMinutes { get; set; } = 180.0;

        /// <summary>
        /// Upper bound for the fatigueRaw signal (Phase 1 + Phase 2).
        /// 1.0 = no extended ramp (original behaviour).
        /// 1.5 = maximum fatigue contribution ≈ FatigueWeight × 150 = 15 PSI pts
        ///       reached after OptimalWindow + RampMinutes + ExtendedRampMinutes.
        /// </summary>
        public double FatigueExtendedCap { get; set; } = 1.5;

        /// <summary>
        /// Weight applied to the fatigue raw score in PSI points.
        /// fatigueDebt_target = FatigueWeight × raw × 100.
        /// At 0.08 with ExtendedCap=1.5: range is 0–12 PSI points.
        /// </summary>
        public double FatigueWeight { get; set; } = 0.08;

        // =================================================================
        // D1: Consecutive-loss streak PSI floor protection
        //
        // When a trader is in an active losing streak AND the current event
        // is a loss, the net PSI should not improve even if other dimensions
        // (e.g. D4 hold-time) have decayed.  Without this guard, D4 recovery
        // between trades can push PSI up by 0.1–0.3 pts on the very tick of a
        // new loss — psychologically incorrect: a new loss during a streak
        // increases pressure, it does not relieve it.
        // =================================================================

        /// <summary>
        /// Minimum consecutive-loss EWMA count (ConsecutiveLosses) above which
        /// a loss event is prevented from producing a net PSI increase.
        /// 3.0 corresponds to roughly 3 back-to-back real losses in the EWMA.
        /// Set to 0 to disable (restores pre-fix behaviour).
        /// </summary>
        public double LossStreakPsiFloorMinStreak { get; set; } = 3.0;

        // =================================================================
        // D7: Overtrading (过度交易)
        //
        // Signal A — Session-internal acceleration:
        //   accelRatio = recentAvgGap / sessionAvgGap
        //   accelZ     = -log(accelRatio) / D7AccelSigma
        //   D7_A       = NormalCdf(accelZ − ZThreshold)
        //   Fires when the trader's recent inter-entry gap is significantly
        //   shorter than their own session average, regardless of P&L.
        //
        // Signal B — Profile frequency baseline (cold-start safe):
        //   expectedGap = 3600 / LambdaVelocity  (from StrategyProfile)
        //   profileZ    = -log(sessionAvgGap / expectedGap) / D7ProfileSigma
        //   D7_B        = NormalCdf(profileZ − ZThreshold) × rampConf(n)
        //   Fires when session pace is significantly faster than the trader's
        //   declared TradesPerSession range.
        //
        // D7_raw = max(D7_A, D7_B)
        //
        // Partial-fill deduplication: only one entry is counted per
        // OversizeImpulseCooldownSec window (reuses existing config).
        // =================================================================

        /// <summary>
        /// Number of the most recent entries to include in the acceleration
        /// window.  A value of 5 means: compare the last 5 inter-entry gaps
        /// against the session average.
        /// </summary>
        public int D7AccelWindowEntries { get; set; } = 5;

        /// <summary>
        /// Minimum inter-entry gap (seconds) used as floor in ratio calculations
        /// to prevent division-by-zero when two entries happen at the same timestamp.
        /// </summary>
        public double D7MinGapFloorSec { get; set; } = 10.0;

        /// <summary>
        /// Log-scale standard deviation for Signal A (session acceleration).
        /// Smaller = more sensitive.  0.5 means a 5× acceleration produces z ≈ 3.2.
        /// </summary>
        public double D7AccelSigma { get; set; } = 0.5;

        /// <summary>
        /// Log-scale standard deviation for Signal B (profile baseline).
        /// Slightly wider than AccelSigma because the profile is a rougher prior.
        /// </summary>
        public double D7ProfileSigma { get; set; } = 0.7;

        // =================================================================
        // (Hard deductions removed 2026-04-21.  All D-signals now flow
        //  through a single EWMA pipeline.  See ARCHITECTURE.md §0.)
        //
        // Composite penalty & escalation parameters (ExtremeThreshold,
        // BoostFactor, EscalationPerFill, MaxEscalationFills) were removed
        // in v1.1 (2026-04-21).  They existed to compensate for the ceiling
        // effect of weighted-sum aggregation — a problem that no longer
        // exists under the p=2 Euclidean norm (ARCHITECTURE.md §3).  Any
        // preset body that still assigned ExtremeThreshold has been scrubbed.

        // =================================================================
        // EWMA — time constants and guards
        //
        // Drop τ (120 s, ~2-min half-life):
        //   Approximates sympathetic nervous system (adrenaline) response onset.
        //   Ref: Goldstein & McEwen (2002), "Allostasis, Homeostats, and the
        //   Nature of Stress," Annals of the New York Academy of Sciences.
        //
        // Recovery τ (1200 s, ~20-min half-life):
        //   Approximates HPA axis cortisol clearance half-life (60–90 min).
        //   Ref: Sapolsky, Romero & Munck (2000), "How Do Glucocorticoids
        //   Influence Stress Responses?" Endocrine Reviews 21(1):55–89.
        // =================================================================

        /// <summary>Time constant (seconds) when PSI is dropping. ~2-min half-life (adrenaline).</summary>
        public double EwmaDropTau { get; set; } = 120.0;

        /// <summary>Time constant (seconds) for normal PSI recovery. ~20-min half-life (cortisol).</summary>
        public double EwmaNormalRecoveryTau { get; set; } = 1200.0;

        // Legacy overexposure-state-machine knobs deleted in the v1.1.4
        // unified-E(t) refactor.  The D3 dimension now uses a single smooth
        // accumulator (D3ExcessDecayTauSec / D3ExcessIntegralTau /
        // D3CommitEquivalentSec) so no "frozen τ" / "post-exposure cooldown
        // τ" / "overexposure cooldown minutes" branch is needed:
        //   EwmaFrozenRecoveryTau        — replaced by snap-up pressure while E grows
        //   EwmaPostOverexposureTau      — replaced by E's own decay τ
        //   OverexposureCooldownMinutes  — replaced by D3ExcessDecayTauSec

        /// <summary>Maximum PSI drop allowed in a single EWMA step.</summary>
        public double EwmaPerEventDropCap { get; set; } = 25.0;

        /// <summary>Floor for the EWMA time delta (seconds) — prevents alpha from being exactly 0.</summary>
        public double EwmaMinDeltaSec { get; set; } = 0.1;

        /// <summary>
        /// Safety clamp: the effective EWMA delta is clipped to this maximum
        /// (seconds) before computing alpha.  This prevents long idle gaps or
        /// a one-off clock anomaly from collapsing C_i in a single step, while
        /// still allowing the normal time-weighted recovery to proceed.
        /// Time-domain transitions (Live ↔ Playback) are handled upstream by
        /// TradingClock.ModeChanged + ResetClockAnchor — this clamp exists
        /// only to cap pathological deltas inside a single domain.
        /// </summary>
        public double EwmaMaxDeltaSec { get; set; } = 600.0;

        // =================================================================
        // Oversize entry-pace deduplication (shared with D7 pace)
        // =================================================================

        /// <summary>
        /// Seconds within which consecutive oversize fills are treated as partial
        /// fills of the same order decision, suppressing duplicate impulse
        /// deductions.  A 3-lot order reported by NT8 as three 1-lot fills within
        /// this window fires only one impulse penalty.
        /// </summary>
        public double OversizeImpulseCooldownSec { get; set; } = 3.0;

        // =================================================================
        // Statistical threshold (Level 2 upgrade)
        //
        // FalsePositiveRate alpha controls the z-threshold k = Phi^-1(1-alpha).
        // Every CalcD* method uses k to decide when observed behaviour crosses
        // from "normal" to "flagged."  alpha = 0.025 → k ≈ 1.96 (standard
        // 95% confidence interval boundary).
        //
        // Ref: NIST/SEMATECH e-Handbook of Statistical Methods, Section 6.3.2
        //      (Shewhart control charts).
        // =================================================================

        /// <summary>
        /// Probability of flagging NORMAL behaviour as abnormal.
        /// 0.025 = 2.5%, the standard two-tailed significance level.
        /// </summary>
        public double FalsePositiveRate { get; set; } = 0.025;

        /// <summary>
        /// Derived z-threshold: k = Phi^-1(1 - FalsePositiveRate).
        /// Precomputed once during config construction.  At FPR=0.025, k ≈ 1.96.
        /// </summary>
        public double ZThreshold { get; set; } = 1.96;

        // =================================================================
        // Factory
        // =================================================================

        /// <summary>
        /// Returns a config with all values set to the original hard-coded defaults.
        /// Bit-identical to pre-extraction behaviour.
        /// </summary>
        public static PsiEngineConfig Default => new PsiEngineConfig();

        /// <summary>
        /// Builds a config from the user's <see cref="StrategyProfile"/> settings.
        /// Starts from the chosen <see cref="PsiSensitivity"/> preset, then applies
        /// any user overrides (NakedPositionPenalty, RecoverySpeedMultiplier, etc.).
        /// </summary>
        public static PsiEngineConfig FromProfile(StrategyProfile p)
        {
            if (p == null) return Default;

            var cfg = PresetFor(p.Sensitivity);

            // ── Apply user overrides (value of -1 = "use preset default") ──
            //
            // Historical note: `NakedPositionPenalty` and `SessionWindowPenalty`
            // used to control one-shot hard-deduction magnitudes.  Those
            // mechanisms were removed in the 2026-04-21 refactor; D2 and D6
            // are now continuous signals driven by D2NakedTimeConstantSec and
            // D6WindowMagnitudeTau / D6RecencyTau.  The profile fields are
            // retained on StrategyProfile for backward-compat serialisation
            // but no longer map to any runtime knob.

            if (p.RecoverySpeedMultiplier > 0)
            {
                double m = Clamp(p.RecoverySpeedMultiplier, 0.25, 4.0);
                cfg.EwmaNormalRecoveryTau       /= m;
                // D3 over-limit evidence decay scales with the same recovery
                // multiplier so a trader who wants faster PSI recovery overall
                // also dissolves oversize-commitment memory proportionally faster.
                cfg.D3ExcessDecayTauSec         /= m;
            }

            if (p.FalsePositiveRate > 0)
                cfg.FalsePositiveRate = Clamp(p.FalsePositiveRate, 0.01, 0.10);

            // Derive z-threshold from false-positive rate: k = Phi^-1(1 - alpha)
            cfg.ZThreshold = PsiEngine.NormalCdfInverse(1.0 - cfg.FalsePositiveRate);

            return cfg;
        }

        // =================================================================
        // Presets
        //
        // Balanced  = default calibrated values.  FPR = 2.5% → k = 1.96.
        //
        // Conservative (stricter):
        //   Higher FPR (5%) → lower z-threshold (1.645) → D-scores fire earlier.
        //   Hard deductions raised  → violations sting more.
        //   Drop τ shortened        → PSI falls faster.
        //   Recovery τ lengthened   → PSI recovers slower.
        //   Extreme threshold lower → escalation triggers sooner.
        //   Rationale: for traders who want the system to catch subtle
        //   deviations and enforce strict discipline.
        //
        // Aggressive (more lenient):
        //   Lower FPR (1%) → higher z-threshold (2.326) → D-scores need larger deviations.
        //   Hard deductions reduced → violations are less punishing.
        //   Drop τ lengthened       → PSI falls more gradually.
        //   Recovery τ shortened    → PSI bounces back faster.
        //   Extreme threshold higher → escalation needs clearer extremes.
        //   Rationale: for experienced traders who self-manage well and
        //   want alerts only for genuinely abnormal behaviour.
        // =================================================================

        private static PsiEngineConfig PresetFor(PsiSensitivity level)
        {
            switch (level)
            {
                case PsiSensitivity.Conservative:
                    return new PsiEngineConfig
                    {
                        // Statistical threshold — 5% FPR → k ≈ 1.645
                        FalsePositiveRate          = 0.05,
                        ZThreshold                 = 1.645,

                        // Harder penalties
                        EwmaPerEventDropCap        = 30.0,

                        // Faster drop, slower recovery
                        EwmaDropTau                = 90.0,
                        EwmaNormalRecoveryTau      = 1800.0,

                        // (ExtremeThreshold removed in v1.1 — escalation was
                        //  a weighted-sum-era compensation; p=2 norm needs none.)

                        // D6 continuous-signal tightening: faster magnitude
                        // ramp outside window and steeper escalation per fill.
                        D6WindowMagnitudeTau       = 20.0,
                        D6RecencyTau               = 0.65,

                        // D2 naked-position alarm grows faster (stricter).
                        D2NakedTimeConstantSec     = 40.0,

                        // D3 unified-E(t) settings — stricter oversize enforcement:
                        //   heavier commit cost (45 s per contract over limit),
                        //   slower decay (150 s τ) so memory lingers,
                        //   tighter raw-mapping τ (45 s) so E saturates faster.
                        D3CommitEquivalentSec      = 45.0,
                        D3ExcessDecayTauSec        = 150.0,
                        D3ExcessIntegralTau        = 45.0,

                        // Slower overnight recovery: 3 days to dissolve severe debt
                        OvernightRecoveryTauHours  = 72.0,

                        // Financial stress fires at smaller session loss
                        FinancialStressWeight      = 0.15,

                        // Fatigue kicks in earlier (90 min optimal window)
                        FatigueOptimalWindowMinutes  = 90.0,
                        FatigueRampMinutes           = 60.0,
                        FatigueExtendedRampMinutes   = 120.0,
                        FatigueExtendedCap           = 1.8,
                        FatigueWeight                = 0.10,

                        // D4 per-trade more sensitive; slower session confidence ramp
                        D4PerTradeLogSigma          = 0.5,
                        D4SessionConfidenceDivisor  = 2.0,
                        // Stricter single-sample cap still holds (a single quick
                        // exit is not yet a pattern even for a strict trader).
                        D4PerTradeSingleSampleCap   = 0.20,

                        // Background streak pressure slightly stronger (stricter mode)
                        D1StreakBackgroundBase       = 0.30,

                        // Stricter loss-streak PSI floor (fires at 2+ consecutive losses)
                        LossStreakPsiFloorMinStreak  = 2.0,
                    };

                case PsiSensitivity.Aggressive:
                    return new PsiEngineConfig
                    {
                        // Statistical threshold — 1% FPR → k ≈ 2.326
                        FalsePositiveRate          = 0.01,
                        ZThreshold                 = 2.326,

                        // Softer penalties
                        EwmaPerEventDropCap        = 20.0,

                        // Slower drop, faster recovery
                        EwmaDropTau                = 180.0,
                        EwmaNormalRecoveryTau      = 600.0,

                        // (ExtremeThreshold removed in v1.1 — see Conservative preset note.)

                        // D6 continuous-signal relaxation: slower magnitude
                        // ramp outside window and gentler escalation per fill.
                        D6WindowMagnitudeTau       = 45.0,
                        D6RecencyTau               = 0.35,

                        // D2 naked-position alarm grows more gradually.
                        D2NakedTimeConstantSec     = 90.0,

                        // D3 unified-E(t) settings — lenient oversize enforcement:
                        //   lighter commit cost (20 s per contract over limit),
                        //   faster decay (60 s τ) so memory clears quickly,
                        //   wider raw-mapping τ (90 s) so E needs more evidence to saturate.
                        D3CommitEquivalentSec      = 20.0,
                        D3ExcessDecayTauSec        = 60.0,
                        D3ExcessIntegralTau        = 90.0,

                        // Faster overnight recovery: 1.5 days
                        OvernightRecoveryTauHours  = 36.0,

                        // Financial stress requires a deeper hole to fire
                        FinancialStressWeight      = 0.09,

                        // Fatigue tolerance: 3-hour optimal window; narrower extended ramp
                        FatigueOptimalWindowMinutes  = 180.0,
                        FatigueRampMinutes           = 120.0,
                        FatigueExtendedRampMinutes   = 240.0,
                        FatigueExtendedCap           = 1.3,
                        FatigueWeight                = 0.06,

                        // D4 per-trade less sensitive; confidence ramp at normal speed
                        D4PerTradeLogSigma          = 0.9,
                        D4SessionConfidenceDivisor  = 2.0,
                        D4PerTradeSingleSampleCap   = 0.10,

                        // Background streak pressure slightly softer (lenient mode)
                        D1StreakBackgroundBase       = 0.18,

                        // Lenient loss-streak PSI floor (fires at 4+ consecutive losses)
                        LossStreakPsiFloorMinStreak  = 4.0,
                    };

                default: // Balanced
                    return new PsiEngineConfig();
            }
        }

        private static double Clamp(double v, double min, double max)
        {
            return v < min ? min : v > max ? max : v;
        }
    }
}

