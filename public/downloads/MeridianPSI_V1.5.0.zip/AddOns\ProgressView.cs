using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Collections.Generic;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Progress — the ANSWER-layer "am I getting better over time?" surface.
    /// PURE WPF. ONE job: is my profit becoming real edge, or still luck?
    /// Curated (hero trend + KPIs + auto-surfaced insights + calendar); the full
    /// chart library lives in EXPLORE, reached via the footer link.
    /// </summary>
    internal static class ProgressView
    {
        public static FrameworkElement Build(ProgressData d, System.Action onExplore = null, System.Action<DateTime> onDayClick = null,
            System.Action onPrevMonth = null, System.Action onNextMonth = null, bool canGoPrev = true, bool canGoNext = false,
            System.Action onExport = null)
        {
            var root = new StackPanel();

            // headline eyebrow + month navigation (browse prior months); arrows grey when at a bound.
            var navRow = new StackPanel { Orientation = Orientation.Horizontal };
            bool hasNav = onPrevMonth != null || onNextMonth != null;
            if (hasNav)
            {
                var prev = NavArrow("◀", canGoPrev);
                if (canGoPrev && onPrevMonth != null) prev.MouseLeftButtonDown += (_, e) => { e.Handled = true; onPrevMonth(); };
                navRow.Children.Add(prev);
            }
            var eyebrow = Ui.Txt("History  ·  " + d.MonthLabel, Theme.TCaption, Theme.FgHint, FontWeights.SemiBold);
            eyebrow.VerticalAlignment = VerticalAlignment.Center;
            eyebrow.Margin = new Thickness(hasNav ? Theme.S2 : 0, 0, Theme.S2, 0);
            navRow.Children.Add(eyebrow);
            if (hasNav)
            {
                var next = NavArrow("▶", canGoNext);
                if (canGoNext && onNextMonth != null) next.MouseLeftButtonDown += (_, e) => { e.Handled = true; onNextMonth(); };
                navRow.Children.Add(next);
            }
            root.Children.Add(navRow);
            var head = Ui.Txt(d.Headline, Theme.TTitle + 2, Theme.FgPrimary, FontWeights.SemiBold);
            head.Margin = new Thickness(0, Theme.S2, 0, 0); head.TextWrapping = TextWrapping.Wrap;
            root.Children.Add(head);
            if (!string.IsNullOrEmpty(d.HeadlineSub))
            {
                var sub = Ui.Txt(d.HeadlineSub, Theme.TSubhead, Theme.FgSecondary);
                sub.Margin = new Thickness(0, Theme.S2, 0, Theme.S4); sub.TextWrapping = TextWrapping.Wrap;
                root.Children.Add(sub);
            }

            // KPI band (full width) — colour carries state
            root.Children.Add(KpiStrip(
                ("Avg composure", d.AvgComposure.ToString("0") + "%", ComposureWord(d.AvgComposure), Theme.Zone(d.AvgComposure)),
                ("Sessions", d.Sessions.ToString(), "this month", Theme.FgPrimary),
                ("Net P&L", Money(d.MonthPnl), "this month", d.MonthPnl >= 0 ? Theme.Good : Theme.Bad),
                ("Edge share", d.EdgeShareNow >= 0 ? d.EdgeShareNow.ToString("0") + "%" : "—", d.EdgeShareNow >= 0 ? "of profit" : "accruing", d.EdgeShareNow >= 50 ? Theme.Good : Theme.Warning),
                ("Broke down", d.BrokeDown + " / " + d.Sessions, "< 55% composure", d.BrokeDown > 0 ? Theme.Bad : Theme.FgPrimary)));

            // Trends: the time dimension a calendar alone cannot show (am I improving?).
            var trendRow = Row2(ComposureTrendChart(d), 1.0, EquityCurveChart(d), 1.0, Theme.S4);
            trendRow.Margin = new Thickness(0, Theme.S4, 0, Theme.S4);
            root.Children.Add(trendRow);

            // ── Calendar HERO (full width): each day shows its composure %, zone-coloured
            //    and clickable straight into that day's report. The month's shape — the
            //    thing you actually scan for — reads at a glance from the cell tints. ──
            string calTitle = d.MonthLabel + "  ·  composure by day";
            if (onDayClick != null) calTitle += "  ·  click a day to open it";
            root.Children.Add(WithBottom(HeaderCard(calTitle, BuildCalendar(d, onDayClick)), Theme.S4));

            // Discipline x outcome: are the green days earned or just lucky?
            root.Children.Add(WithBottom(CorrelationScatter(d), Theme.S4));

            // ── Recent sessions + auto-surfaced insights ──
            var tableCard = HeaderCard("Recent sessions", RecentSessionsTable(d, onDayClick));
            if (d.Insights.Count > 0)
                root.Children.Add(WithBottom(Row2(tableCard, 1.3, InsightsCard(d), 1.0, Theme.S4), Theme.S4));
            else
                root.Children.Add(WithBottom(tableCard, Theme.S4));

            // Footer: explore link + CSV export (restored data portability)
            var footer = new StackPanel { Orientation = Orientation.Horizontal };
            var link = Ui.Txt("Explore all analytics  →", Theme.TBody, Theme.Accent, FontWeights.SemiBold);
            // Only present it as clickable when it actually has somewhere to go.
            if (onExplore != null)
            {
                link.Cursor = System.Windows.Input.Cursors.Hand;
                link.MouseLeftButtonDown += (_, e) => { e.Handled = true; onExplore(); };
            }
            footer.Children.Add(link);
            if (onExport != null)
            {
                var exp = Ui.Txt("Export CSV", Theme.TBody, Theme.FgSecondary, FontWeights.SemiBold);
                exp.Cursor = System.Windows.Input.Cursors.Hand;
                exp.Margin = new Thickness(Theme.S5, 0, 0, 0);
                exp.MouseLeftButtonDown += (_, e) => { e.Handled = true; onExport(); };
                footer.Children.Add(exp);
            }
            root.Children.Add(footer);

            return Ui.Page(root, 1320);
        }

        private static FrameworkElement WithBottom(FrameworkElement el, double gap)
        {
            el.Margin = new Thickness(0, 0, 0, gap);
            return el;
        }

        // Month-nav arrow (◀ / ▶) — greyed + inert when disabled (e.g. ▶ at the current month).
        private static Border NavArrow(string glyph, bool enabled)
        {
            var tb = Ui.Txt(glyph, Theme.TCaption, enabled ? Theme.FgSecondary : Theme.FgHint, FontWeights.Bold);
            tb.HorizontalAlignment = HorizontalAlignment.Center;
            tb.VerticalAlignment   = VerticalAlignment.Center;
            var b = new Border
            {
                Width = 26, Height = 22, CornerRadius = new CornerRadius(Theme.R1),
                Background = Theme.BgElevated, BorderBrush = Theme.Border, BorderThickness = new Thickness(1),
                Child = tb, VerticalAlignment = VerticalAlignment.Center,
                Cursor = enabled ? System.Windows.Input.Cursors.Hand : System.Windows.Input.Cursors.Arrow,
            };
            if (enabled)
            {
                b.MouseEnter += (_, __) => b.Background = Theme.Border;
                b.MouseLeave += (_, __) => b.Background = Theme.BgElevated;
            }
            return b;
        }

        // Two weighted columns, both tiles stretched to the row's height (bento row).
        private static FrameworkElement Row2(FrameworkElement a, double wa, FrameworkElement b, double wb, double gap)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(wa, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(gap) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(wb, GridUnitType.Star) });
            a.VerticalAlignment = VerticalAlignment.Stretch; b.VerticalAlignment = VerticalAlignment.Stretch;
            Grid.SetColumn(a, 0); g.Children.Add(a);
            Grid.SetColumn(b, 2); g.Children.Add(b);
            return g;
        }

        // A tile: a header label inside a card, above its content.
        private static FrameworkElement HeaderCard(string title, FrameworkElement content)
        {
            var sp = new StackPanel();
            sp.Children.Add(Ui.Txt(title, Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            content.Margin = new Thickness(0, Theme.S3, 0, 0);
            sp.Children.Add(content);
            return Ui.Card(sp, Theme.S4);
        }

        private static FrameworkElement InsightsCard(ProgressData d)
        {
            var sp = new StackPanel();
            sp.Children.Add(Ui.Txt("What we noticed", Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            var list = new StackPanel { Margin = new Thickness(0, Theme.S2, 0, 0) };
            for (int i = 0; i < d.Insights.Count; i++)
                list.Children.Add(InsightRow(d.Insights[i], i < d.Insights.Count - 1));
            sp.Children.Add(list);
            return Ui.Card(sp, Theme.S4);
        }

        // ── Calendar ─────────────────────────────────────────────────────────
        private static FrameworkElement BuildCalendar(ProgressData d, System.Action<DateTime> onDayClick = null)
        {
            var wrap = new StackPanel();

            var header = new UniformGrid { Columns = 7 };
            foreach (var w in new[] { "MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN" })
            {
                var tb = Ui.Txt(w, Theme.TCaption, Theme.FgHint, FontWeights.SemiBold);
                tb.HorizontalAlignment = HorizontalAlignment.Center;
                tb.Margin = new Thickness(0, 0, 0, Theme.S2);
                header.Children.Add(tb);
            }
            wrap.Children.Add(header);

            var grid = new UniformGrid { Columns = 7 };
            for (int i = 0; i < d.FirstBlank; i++) grid.Children.Add(new Border());
            foreach (var day in d.Days) grid.Children.Add(DayCell(day, onDayClick));
            wrap.Children.Add(grid);

            // legend
            var legend = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, Theme.S3, 0, 0) };
            legend.Children.Add(LegendDot("Stable", Theme.Stable));
            legend.Children.Add(LegendDot("Caution", Theme.Caution));
            legend.Children.Add(LegendDot("Warning", Theme.Warning));
            legend.Children.Add(LegendDot("Critical", Theme.Critical));
            wrap.Children.Add(legend);

            return wrap;
        }

        private static Border DayCell(ProgressDay day, System.Action<DateTime> onDayClick = null)
        {
            var g = new Grid();

            // Day number — top-left, muted (the % is the hero, not the date).
            var num = Ui.Txt(day.Day.ToString(), Theme.TCaption, day.HasSession ? Theme.FgSecondary : Theme.FgHint, FontWeights.SemiBold);
            num.HorizontalAlignment = HorizontalAlignment.Left;
            num.VerticalAlignment   = VerticalAlignment.Top;
            num.Margin = new Thickness(Theme.S2 + 2, Theme.S2, 0, 0);
            g.Children.Add(num);

            Brush zone = day.HasSession ? Theme.Zone(day.Composure) : null;

            // The composure % — what you scan for — big, centred, zone-coloured.
            if (day.HasSession)
            {
                var pct = Ui.Num((int)Math.Round(day.Composure) + "%", Theme.TSubhead, zone, FontWeights.Bold);
                pct.HorizontalAlignment = HorizontalAlignment.Center;
                pct.VerticalAlignment   = VerticalAlignment.Center;
                pct.Margin = new Thickness(0, Theme.S3, 0, 0);
                g.Children.Add(pct);
            }

            // Session days carry a faint zone tint + matching hairline so the month's
            // shape (where you broke down) reads instantly without reading every number.
            Brush idle = day.HasSession ? Theme.Tint(zone, 22) : Theme.BgSubtle;
            var cell = new Border
            {
                Height = 66,
                Margin = new Thickness(3),
                Background = idle,
                CornerRadius = new CornerRadius(Theme.R2),
                BorderBrush = day.IsToday ? Theme.Accent : (day.HasSession ? Theme.Tint(zone, 55) : null),
                BorderThickness = new Thickness(day.IsToday ? 1.6 : (day.HasSession ? 1 : 0)),
                Child = g,
            };

            // Hover tooltip — the day's detail at a glance (restores the old calendar's hover).
            if (day.HasSession)
            {
                string tip = day.Date.ToString("ddd, MMM d") + "     " + (int)Math.Round(day.Composure) + "% composure"
                    + (day.FinalPsi >= 0 ? "     ·     PSI " + (int)Math.Round(day.FinalPsi) : "")
                    + "     ·     " + day.Trades + (day.Trades == 1 ? " trade" : " trades")
                    + "     ·     " + (day.Pnl >= 0 ? "+$" : "-$") + Math.Abs(Math.Round(day.Pnl)).ToString("0");
                cell.ToolTip = new ToolTip
                {
                    Content         = new TextBlock { Text = tip, Foreground = Theme.FgPrimary, FontFamily = Theme.Font, FontSize = 12 },
                    Background      = Theme.BgElevated,
                    BorderBrush     = Theme.Border,
                    BorderThickness = new Thickness(1),
                    Padding         = new Thickness(10, 6, 10, 6),
                };
            }

            // A day with a recorded session is clickable → opens that day's full report.
            if (day.HasSession && onDayClick != null)
            {
                cell.Cursor = System.Windows.Input.Cursors.Hand;
                cell.MouseEnter += (_, __) => cell.Background = Theme.Tint(zone, 42);
                cell.MouseLeave += (_, __) => cell.Background = idle;
                cell.MouseLeftButtonDown += (_, e) => { e.Handled = true; onDayClick(day.Date); };
            }

            return cell;
        }

        private static StackPanel LegendDot(string label, Brush color)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, Theme.S4, 0) };
            sp.Children.Add(new Border { Width = 8, Height = 8, CornerRadius = new CornerRadius(99), Background = color, VerticalAlignment = VerticalAlignment.Center });
            var tb = Ui.Txt(label, Theme.TCaption, Theme.FgSecondary);
            tb.Margin = new Thickness(Theme.S1 + 2, 0, 0, 0);
            sp.Children.Add(tb);
            return sp;
        }

        // ── Insight row ──────────────────────────────────────────────────────
        private static UIElement InsightRow(ProgressInsight ins, bool divider)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var dot = new Border { Width = 8, Height = 8, CornerRadius = new CornerRadius(99), Background = ins.Accent ?? Theme.Accent, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, Theme.S3, 0) };
            Grid.SetColumn(dot, 0); g.Children.Add(dot);

            var body = new StackPanel();
            body.Children.Add(Ui.Txt(ins.Title, Theme.TBody, Theme.FgPrimary, FontWeights.SemiBold));
            if (!string.IsNullOrEmpty(ins.Detail))
                body.Children.Add(Ui.Txt(ins.Detail, Theme.TCaption, Theme.FgSecondary));
            Grid.SetColumn(body, 1); g.Children.Add(body);

            var arrow = Ui.Txt("→", Theme.TBody, Theme.FgHint);
            arrow.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(arrow, 2); g.Children.Add(arrow);

            var row = new Border { Child = g, Padding = new Thickness(0, Theme.S2, 0, Theme.S2) };
            if (divider) { row.BorderBrush = Theme.Border; row.BorderThickness = new Thickness(0, 0, 0, 1); }
            return row;
        }

        // ── KPI strip — ONE bordered band, columns hairline-separated; value sized
        // consistently, colour carries the state (shadcn / FINBRO stat bar). ─────────
        private static FrameworkElement KpiStrip(params (string label, string value, string sub, Brush color)[] items)
        {
            var g = new Grid();
            for (int i = 0; i < items.Length; i++)
            {
                if (i > 0) g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            }
            int col = 0;
            for (int i = 0; i < items.Length; i++)
            {
                if (i > 0)
                {
                    var sep = new Border { Width = 1, Background = Theme.Border, Margin = new Thickness(0, 2, 0, 2) };
                    Grid.SetColumn(sep, col++); g.Children.Add(sep);
                }
                var sp = new StackPanel { Margin = new Thickness(i == 0 ? 0 : Theme.S4, Theme.S1, Theme.S4, Theme.S1) };
                sp.Children.Add(Ui.Txt(items[i].label, Theme.TCaption, Theme.FgSecondary, FontWeights.SemiBold));
                var val = Ui.Num(items[i].value, Theme.TTitle, items[i].color, FontWeights.SemiBold);
                val.Margin = new Thickness(0, Theme.S2, 0, 0);
                sp.Children.Add(val);
                sp.Children.Add(Ui.Txt(items[i].sub, Theme.TCaption, Theme.FgHint));
                Grid.SetColumn(sp, col++); g.Children.Add(sp);
            }
            return Ui.Card(g, Theme.S4);
        }

        private static Border ChartCard(string title, string note, Brush noteColor, UIElement chart)
        {
            var sp = new StackPanel();
            var header = new StackPanel { Orientation = Orientation.Horizontal };
            header.Children.Add(Ui.Txt(title, Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            if (!string.IsNullOrEmpty(note))
            {
                var n = Ui.Txt(note, Theme.TCaption, noteColor, FontWeights.SemiBold);
                n.Margin = new Thickness(Theme.S2, 0, 0, 0);
                header.Children.Add(n);
            }
            sp.Children.Add(header);
            ((FrameworkElement)chart).Margin = new Thickness(0, Theme.S2, 0, 0);
            sp.Children.Add(chart);
            return Ui.Card(sp);
        }

        // ── Recent sessions table (shadcn: hairline rows + tinted status pill) ──────
        private static FrameworkElement RecentSessionsTable(ProgressData d, System.Action<DateTime> onDayClick)
        {
            var stack = new StackPanel();
            stack.Children.Add(SessionHeaderRow());
            if (d.RecentSessions.Count == 0)
            {
                var empty = Ui.Txt("No sessions yet this month.", Theme.TBody, Theme.FgHint);
                empty.Margin = new Thickness(Theme.S3, Theme.S4, 0, Theme.S4);
                stack.Children.Add(empty);
            }
            else
            {
                for (int i = 0; i < d.RecentSessions.Count; i++)
                    stack.Children.Add(SessionDataRow(d.RecentSessions[i], i < d.RecentSessions.Count - 1, onDayClick));
            }
            return stack;   // carded by HeaderCard in Build (bento tile)
        }

        private static Grid SessionGrid()
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(82) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(72) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(88) });
            return g;
        }

        private static UIElement SessionHeaderRow()
        {
            var g = SessionGrid();
            string[] hs = { "Date", "Composure", "P&L", "Status" };
            for (int i = 0; i < hs.Length; i++)
            {
                var t = Ui.Txt(hs[i], Theme.TCaption, Theme.FgHint, FontWeights.SemiBold);
                if (i >= 2) t.HorizontalAlignment = HorizontalAlignment.Right;
                Grid.SetColumn(t, i); g.Children.Add(t);
            }
            return new Border { Child = g, Padding = new Thickness(Theme.S3, Theme.S2, Theme.S3, Theme.S3), BorderBrush = Theme.Border, BorderThickness = new Thickness(0, 0, 0, 1) };
        }

        private static UIElement SessionDataRow(ProgressSession s, bool divider, System.Action<DateTime> onDayClick)
        {
            var g = SessionGrid();
            var date = Ui.Txt(s.Date.ToString("ddd, MMM d"), Theme.TBody, Theme.FgPrimary, FontWeights.SemiBold);
            date.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(date, 0); g.Children.Add(date);

            var comp = Ui.Num((int)Math.Round(s.Composure) + "%", Theme.TBody, Theme.Zone(s.Composure), FontWeights.SemiBold);
            comp.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(comp, 1); g.Children.Add(comp);

            var pnl = Ui.Num(Money(s.Pnl), Theme.TBody, s.Pnl >= 0 ? Theme.Good : Theme.Bad, FontWeights.SemiBold);
            pnl.HorizontalAlignment = HorizontalAlignment.Right; pnl.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(pnl, 2); g.Children.Add(pnl);

            var pill = Ui.Pill(ZoneWord(s.Composure), Theme.Zone(s.Composure));
            pill.HorizontalAlignment = HorizontalAlignment.Right; pill.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(pill, 3); g.Children.Add(pill);

            var row = new Border { Child = g, Padding = new Thickness(Theme.S3, Theme.S3, Theme.S3, Theme.S3), Background = Brushes.Transparent };
            if (divider) { row.BorderBrush = Theme.Border; row.BorderThickness = new Thickness(0, 0, 0, 1); }
            if (onDayClick != null)
            {
                var dt = s.Date;
                row.Cursor = System.Windows.Input.Cursors.Hand;
                row.MouseEnter += (_, __) => row.Background = Theme.BgElevated;
                row.MouseLeave += (_, __) => row.Background = Brushes.Transparent;
                row.MouseLeftButtonDown += (_, e) => { e.Handled = true; onDayClick(dt); };
            }
            return row;
        }

        // Pill word matches the pill colour (Theme.Zone, canonical 88/72/55 bands).
        private static string ZoneWord(double c)
            => c >= 88 ? "Stable" : c >= 72 ? "Caution" : c >= 55 ? "Warning" : "Critical";

        // Neutral, factual zone words — informative, not catastrophizing (a monitor reports,
        // it does not scold). See UX_DESIGN_ROOT.md tone doctrine.
        private static string ComposureWord(double c)
            => c >= 88 ? "Composed" : c >= 72 ? "Steady" : c >= 55 ? "Caution" : "Under pressure";

        private static List<ProgressSession> Chrono(ProgressData d)
        {
            var list = new List<ProgressSession>(d.RecentSessions);
            list.Sort((a, b) => a.Date.CompareTo(b.Date));   // RecentSessions is newest-first
            return list;
        }

        private static FrameworkElement BuildingHint(string msg)
        {
            var t = Ui.Txt(msg, Theme.TBody, Theme.FgHint);
            t.TextWrapping = TextWrapping.Wrap;
            t.Margin = new Thickness(0, Theme.S4, 0, Theme.S4);
            return t;
        }

        // Composure across recent sessions, zone thresholds drawn in.
        private static FrameworkElement ComposureTrendChart(ProgressData d)
        {
            var ch = Chrono(d);
            UIElement inner; string note = ""; Brush nc = Theme.FgHint;
            if (ch.Count < 2) inner = BuildingHint("Builds as you log more sessions.");
            else
            {
                var vals = new List<double>();
                foreach (var s in ch) vals.Add(s.Composure);
                inner = new SparkAreaChart { Values = vals, MinY = 0, MaxY = 100, Thresholds = new double[] { 55, 72, 88 }, Stroke = Theme.Accent, ChartHeight = 150 };
                double delta = vals[vals.Count - 1] - vals[0];
                note = (delta >= 0 ? "+" : "") + Math.Round(delta) + " pts";
                nc = delta >= 0 ? Theme.Good : Theme.Bad;
            }
            return ChartCard("Composure trend", note, nc, inner);
        }

        // Cumulative P&L across recent sessions (the equity curve).
        private static FrameworkElement EquityCurveChart(ProgressData d)
        {
            var ch = Chrono(d);
            UIElement inner; string note = ""; Brush nc = Theme.FgHint;
            if (ch.Count < 2) inner = BuildingHint("Builds as you log more sessions.");
            else
            {
                var cum = new List<double>(); double run = 0;
                foreach (var s in ch) { run += s.Pnl; cum.Add(run); }
                double fin = cum[cum.Count - 1];
                inner = new SparkAreaChart { Values = cum, Stroke = fin >= 0 ? Theme.Good : Theme.Bad, ShowZeroLine = true, ChartHeight = 150 };
                note = Money(fin); nc = fin >= 0 ? Theme.Good : Theme.Bad;
            }
            return ChartCard("Equity curve", note, nc, inner);
        }

        // Discipline (composure) vs outcome (P&L) per session: earned vs lucky.
        private static FrameworkElement CorrelationScatter(ProgressData d)
        {
            UIElement inner;
            if (d.RecentSessions.Count < 2)
                inner = BuildingHint("Each session plots here as you log more, so you can see whether your green days are earned or just lucky.");
            else
            {
                var dots = new List<ScatterDot>();
                foreach (var s in d.RecentSessions)
                    dots.Add(new ScatterDot { Pnl = s.Pnl, Disc = Math.Max(0, Math.Min(1, s.Composure / 100.0)), Size = 2, Win = s.Pnl >= 0, Color = Theme.Zone(s.Composure), Label = "" });
                inner = new QuadrantScatter { Dots = dots, ChartHeight = 240 };
            }
            return ChartCard("Discipline x outcome", "each dot = a session", Theme.FgHint, inner);
        }

        private static string Money(double v) => (v >= 0 ? "+$" : "-$") + Math.Abs(v).ToString("0");
    }
}
