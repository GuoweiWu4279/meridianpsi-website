using System.Collections.Generic;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// The Discipline × Outcome quadrant a trade (or session) falls into.
    /// EARNED = disciplined + profit; LUCK = rule-break + profit;
    /// VARIANCE = disciplined + loss; SPIRAL = rule-break + loss.
    /// </summary>
    internal enum DebriefCell { Earned, Luck, Variance, Spiral }

    /// <summary>One reconstructed round-trip for the Debrief.</summary>
    internal sealed class DebriefTrade
    {
        public string Label;       // "A", "B", ...
        public string TimeText;    // "06:38"
        public string Dir;         // "Long" / "Short"
        public int    Size;        // peak contracts
        public double EntryPrice;
        public double ExitPrice;
        public double Pnl;
        public bool   IsWin;
        public bool   Disciplined; // size within the trader's declared limit
        public DebriefCell Cell;
    }

    /// <summary>
    /// Pure data model for The Debrief (the post-session "truth ledger").
    /// Contains ONLY what can be honestly derived from a session's fills +
    /// the trader's declared limits. No NinjaTrader types — the view that
    /// renders it is pure WPF and renders offline in the UI harness.
    /// </summary>
    internal sealed class DebriefData
    {
        public string DateText;          // "June 2, 2026"
        public double NetPnl;
        public int    TotalTrades;
        public int    Wins;
        public double WinRatePct;
        public double FinalPsi;          // last PSI seen in the session (<0 = unknown)

        public string      Verdict;      // headline, e.g. "You got lucky today."
        public string      VerdictSub;   // one-line explanation
        public DebriefCell  VerdictCell; // drives the headline color

        // Discipline × Outcome aggregation
        public double EarnedPnl, LuckPnl, VariancePnl, SpiralPnl;
        public int    EarnedN,   LuckN,   VarianceN,   SpiralN;
        public double DisciplinedNetPnl; // EARNED + VARIANCE (your repeatable edge)

        // Distance-to-blowup (the value the trader cannot feel)
        public string DistanceTitle;
        public string DistanceBody;

        public string OneFix;            // the single thing to change tomorrow

        // Danger hero — "the risk you didn't feel" (risk vs your own daily limit)
        public bool   HasDanger;
        public string DangerTradeLabel;  // "Trade B · 12 contracts"
        public double DangerRisk;        // $ at risk on a normal stop-out
        public double DangerLimit;       // the trader's daily loss limit
        public double DangerReward;      // $ the trade actually made
        public double DangerStopPts;     // the "normal" adverse move used
        public string DangerCaption;

        public int SizeMax;
        public List<DebriefTrade> Trades = new List<DebriefTrade>();
        public List<double> PsiSeries = new List<double>();   // PSI samples through the session

        // Cumulative behavioral-dimension scores (D1..D7) for the session — drives the
        // "what drove your discipline score" breakdown. Null/empty = no signals recorded.
        public double[] DimScores;
    }
}
