// LicenseStatus.cs
//
// Pure license-state enum, split out of LicenseManager.cs. LicenseManager the
// CLASS is NinjaTrader-coupled (NinjaTrader.Code.Output / PrintTo), which keeps
// it out of the offline UI harness. This enum is a pure type with no such
// coupling, so the License page view (LicensePageView) can reference it and
// render offline. Same namespace, so every existing reference resolves unchanged.

namespace NinjaTrader.NinjaScript.AddOns
{
    public enum LicenseStatus
    {
        /// <summary>First install, trial period has not expired.</summary>
        Trial_Active,

        /// <summary>Trial period has expired. No valid license key entered.</summary>
        Trial_Expired,

        /// <summary>Valid license key, subscription active.</summary>
        Licensed,

        /// <summary>
        /// License was valid at last check but server is unreachable.
        /// Full functionality preserved for up to LicenseManager.GraceDays days.
        /// </summary>
        Offline_Grace,

        /// <summary>Subscription has expired or been cancelled.</summary>
        Expired,

        /// <summary>License key is invalid, revoked, or entered incorrectly.</summary>
        Invalid,
    }
}
