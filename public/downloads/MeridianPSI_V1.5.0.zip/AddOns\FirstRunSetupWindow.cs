// FirstRunSetupWindow.cs
//
// First-run "Quick Setup" wizard.
//
// WHY THIS EXISTS (see AUDIT.md §4–§6):
//   The PSI engine's strongest signals — the Class A commitment-break dimensions
//   (D6 daily-loss, D1 revenge-pause, D7 overtrading) — only exist once the
//   trader DECLARES their personal limits.  Those limits default to 0/disabled
//   in StrategyProfile, so an install-and-go user gets only weak Class B pattern
//   signals against generic thresholds, plus a baseline that needs 20–30 sessions
//   to calibrate.  This wizard asks the four questions that matter, writes the
//   profile Class A limits, and seeds matching Guard starter rules in one pass —
//   turning "install → weak" into "install → strong."
//
// DESIGN:
//   • Self-contained.  One static entry point: Show(...).  No new HubPage, no
//     nav-rail entry, no entanglement with the giant Hub/Settings windows.
//   • Matches the existing chromeless modal pattern used by
//     ShowEarlyExitConfirmDialog / ShowCountdownConfirmDialog in
//     TradeMonitorHub.cs (WindowStyle.None + WindowChrome + CenterScreen +
//     dark palette).
//   • Never traps the user: every field has a safe default, parsing failures
//     fall back rather than blocking, and "Skip for now" always exits cleanly.
//
// WIRING (TradeMonitor.cs first-run block, ~line 916): instead of opening the
//   Settings page directly, call FirstRunSetupWindow.Show(...).  The onComplete
//   callback rebuilds the engine config from the freshly-written profile
//   (the engine was constructed at startup from the empty default profile, so
//   it must be reconfigured for the new limits to take effect this session) and
//   then navigates to the License tab so the next natural step (activation) is
//   front-and-centre.
//
// NOTE: pure WPF + the AddOn's own data types; no NinjaTrader API dependency,
//   so it is independently reviewable.  MUST be compiled and smoke-tested inside
//   NinjaTrader 8 before shipping (see the checklist at the end of the PR notes).

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// One-time first-run configuration wizard.  See file header for rationale.
    /// </summary>
    public static class FirstRunSetupWindow
    {
        // ── Palette (matches TradeMonitorHub modal dialogs) ───────────────────
        private static readonly Brush Bg          = new SolidColorBrush(Color.FromRgb(28, 28, 30));
        private static readonly Brush Card        = new SolidColorBrush(Color.FromRgb(36, 36, 38));
        private static readonly Brush FieldBg     = new SolidColorBrush(Color.FromRgb(29, 31, 36));
        private static readonly Brush FieldBorder = new SolidColorBrush(Color.FromRgb(58, 61, 69));
        private static readonly Brush FgPrimary   = new SolidColorBrush(Color.FromRgb(236, 237, 238));
        private static readonly Brush FgSecondary = new SolidColorBrush(Color.FromRgb(161, 161, 170));
        private static readonly Brush FgHint      = new SolidColorBrush(Color.FromRgb(113, 113, 122));
        private static readonly Brush Accent      = new SolidColorBrush(Color.FromRgb( 16, 185, 129));
        private static readonly FontFamily Ui     = Theme.Font;

        /// <summary>
        /// Shows the wizard modally over the desktop.  On completion (Finish or
        /// Skip) the window closes and <paramref name="onComplete"/> is invoked
        /// on the UI thread.  Never throws — any failure is logged and treated
        /// as a skip so first-run can never block startup.
        /// </summary>
        /// <param name="profile">The live profile instance (mutated in place on Finish).</param>
        /// <param name="guardEngine">Guard engine; starter rules are seeded only if it currently has none.</param>
        /// <param name="onComplete">Invoked after the window closes (both Finish and Skip paths).</param>
        /// <param name="log">Optional log sink for diagnostics.</param>
        public static void Show(StrategyProfile profile,
                                GuardEngine     guardEngine,
                                Action          onComplete,
                                Action<string>  log = null)
        {
            try
            {
                BuildAndShow(profile, guardEngine, onComplete, log);
            }
            catch (Exception ex)
            {
                log?.Invoke("[FirstRunSetup] Wizard failed to open — skipping. " + ex.Message);
                onComplete?.Invoke();
            }
        }

        /// <summary>
        /// Builds the wizard's visual tree (no window, no click handlers) wrapped in a
        /// dark background panel, for OFFLINE RENDERING by the UI harness so the layout
        /// can be reviewed without launching NinjaTrader.  Reuses the exact same styling
        /// primitives (<see cref="Field"/>, <see cref="MakeBox"/>, <see cref="MakeButton"/>,
        /// brushes, fonts) as the live <see cref="Show"/> path, so the preview is faithful.
        /// </summary>
        internal static FrameworkElement BuildPreview(StrategyProfile profile, GuardEngine guardEngine)
        {
            var root = new StackPanel { Margin = new Thickness(28, 24, 28, 22) };

            root.Children.Add(new TextBlock
            {
                Text = "Quick Setup", FontFamily = Ui, FontSize = 18, FontWeight = FontWeights.SemiBold,
                Foreground = FgPrimary, Margin = new Thickness(0, 0, 0, 4),
            });
            root.Children.Add(new TextBlock
            {
                Text = "Meridian gets sharp when it knows YOUR limits. Set these once — you can "
                     + "change them any time in Settings. Leave a field blank to skip it.",
                FontFamily = Ui, FontSize = 12, Foreground = FgSecondary,
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 18),
            });

            root.Children.Add(Field("Daily loss limit  ($)",
                "When your realised session loss crosses this, Meridian flags a hard rule-break and (Guard) can stop you for the day. Most-important field.",
                profile.MaxDailyLossUsd > 0 ? profile.MaxDailyLossUsd.ToString("0") : "", "e.g. 300", out _));
            root.Children.Add(Field("Pause after N losses in a row",
                "After this many consecutive losing trades, the next entry counts as a revenge break.",
                profile.PauseAfterNLosses > 0 ? profile.PauseAfterNLosses.ToString() : "3", "e.g. 3", out _));
            root.Children.Add(Field("Max trades per session",
                "Entering past this is overtrading. Used to calibrate the pace signal.",
                profile.TradesPerSessionMax > 0 ? profile.TradesPerSessionMax.ToString() : "15", "e.g. 15", out _));
            root.Children.Add(Field("Typical position size  (contracts)",
                "Your normal size. Going well past this under pressure is a size-spike signal.",
                profile.SizeMax > 0 ? profile.SizeMax.ToString("0.##") : "2", "e.g. 2", out _));

            var sessRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2) };
            sessRow.Children.Add(LabelFor("Session hours  (24h, local)"));
            sessRow.Children.Add(MakeBox(string.Format("{0:00}:{1:00}", profile.SessionStartHour, profile.SessionStartMinute), "09:30", 78));
            sessRow.Children.Add(new TextBlock { Text = "to", FontFamily = Ui, FontSize = 12, Foreground = FgSecondary,
                Margin = new Thickness(8, 0, 8, 0), VerticalAlignment = VerticalAlignment.Center });
            sessRow.Children.Add(MakeBox(string.Format("{0:00}:{1:00}", profile.SessionEndHour, profile.SessionEndMinute), "12:00", 78));
            root.Children.Add(WrapField(sessRow,
                "Out-of-window trading is a rule-break signal. Tick the box if you have no fixed session."));
            root.Children.Add(new CheckBox { Content = "I don't trade fixed hours", Foreground = FgSecondary,
                FontFamily = Ui, FontSize = 12, Margin = new Thickness(0, 6, 0, 0), IsChecked = !profile.SessionWindowEnabled });

            root.Children.Add(new TextBlock
            {
                Text = "On finish, Meridian also creates a starter set of Guard protection rules "
                     + "from these answers (active on the Guard tier).",
                FontFamily = Ui, FontSize = 11, Foreground = FgHint, TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 16, 0, 18),
            });

            var btnRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right };
            var skip = MakeButton("Skip for now", Card, FgSecondary); skip.Margin = new Thickness(0, 0, 10, 0);
            btnRow.Children.Add(skip);
            btnRow.Children.Add(MakeButton("Finish setup", Accent, Theme.AccentInk));
            root.Children.Add(btnRow);

            return new Border { Background = Bg, Child = root };
        }

        private static void BuildAndShow(StrategyProfile profile,
                                         GuardEngine     guardEngine,
                                         Action          onComplete,
                                         Action<string>  log)
        {
            var win = new Window
            {
                WindowStyle           = WindowStyle.None,
                AllowsTransparency    = false,
                Background            = Bg,
                Width                 = 520,
                SizeToContent         = SizeToContent.Height,
                MaxHeight             = 760,
                WindowStartupLocation = WindowStartupLocation.CenterScreen,
                Topmost               = true,
                ResizeMode            = ResizeMode.NoResize,
                ShowInTaskbar         = false,
            };
            System.Windows.Shell.WindowChrome.SetWindowChrome(win,
                new System.Windows.Shell.WindowChrome
                {
                    CaptionHeight         = 0,
                    ResizeBorderThickness = new Thickness(0),
                });

            var root = new StackPanel { Margin = new Thickness(28, 24, 28, 22) };

            // ── Header ────────────────────────────────────────────────────────
            root.Children.Add(new TextBlock
            {
                Text       = "Quick Setup",
                FontFamily = Ui, FontSize = 18, FontWeight = FontWeights.SemiBold,
                Foreground = FgPrimary, Margin = new Thickness(0, 0, 0, 4),
            });
            root.Children.Add(new TextBlock
            {
                Text         = "Meridian gets sharp when it knows YOUR limits. Set these once — "
                             + "you can change them any time in Settings. Leave a field blank to skip it.",
                FontFamily   = Ui, FontSize = 12, Foreground = FgSecondary,
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 18),
            });

            // ── Fields ────────────────────────────────────────────────────────
            TextBox txDailyLoss, txPauseN, txMaxTrades, txSize, txStart, txEnd;

            root.Children.Add(Field(
                "Daily loss limit  ($)",
                "When your realised session loss crosses this, Meridian flags a hard rule-break and (Guard) can stop you for the day. Most-important field.",
                profile.MaxDailyLossUsd > 0 ? profile.MaxDailyLossUsd.ToString("0") : "",
                "e.g. 300", out txDailyLoss));

            root.Children.Add(Field(
                "Pause after N losses in a row",
                "After this many consecutive losing trades, the next entry counts as a revenge break.",
                profile.PauseAfterNLosses > 0 ? profile.PauseAfterNLosses.ToString() : "3",
                "e.g. 3", out txPauseN));

            root.Children.Add(Field(
                "Max trades per session",
                "Entering past this is overtrading. Used to calibrate the pace signal.",
                profile.TradesPerSessionMax > 0 ? profile.TradesPerSessionMax.ToString() : "15",
                "e.g. 15", out txMaxTrades));

            root.Children.Add(Field(
                "Typical position size  (contracts)",
                "Your normal size. Going well past this under pressure is a size-spike signal.",
                profile.SizeMax > 0 ? profile.SizeMax.ToString("0.##") : "2",
                "e.g. 2", out txSize));

            // ── Session window (optional) ─────────────────────────────────────
            var sessRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 2) };
            txStart = MakeBox(string.Format("{0:00}:{1:00}", profile.SessionStartHour, profile.SessionStartMinute), "09:30", 78);
            txEnd   = MakeBox(string.Format("{0:00}:{1:00}", profile.SessionEndHour,   profile.SessionEndMinute),   "12:00", 78);
            sessRow.Children.Add(LabelFor("Session hours  (24h, local)"));
            sessRow.Children.Add(txStart);
            sessRow.Children.Add(new TextBlock
            {
                Text = "to", FontFamily = Ui, FontSize = 12, Foreground = FgSecondary,
                Margin = new Thickness(8, 0, 8, 0), VerticalAlignment = VerticalAlignment.Center,
            });
            sessRow.Children.Add(txEnd);

            var noFixedHours = new CheckBox
            {
                Content    = "I don't trade fixed hours",
                Foreground = FgSecondary, FontFamily = Ui, FontSize = 12,
                Margin     = new Thickness(0, 6, 0, 0),
                IsChecked  = !profile.SessionWindowEnabled,
            };
            noFixedHours.Checked   += (_, __) => { txStart.IsEnabled = false; txEnd.IsEnabled = false; };
            noFixedHours.Unchecked += (_, __) => { txStart.IsEnabled = true;  txEnd.IsEnabled = true;  };
            if (noFixedHours.IsChecked == true) { txStart.IsEnabled = false; txEnd.IsEnabled = false; }

            root.Children.Add(WrapField(sessRow,
                "Out-of-window trading is a rule-break signal. Tick the box if you have no fixed session."));
            root.Children.Add(noFixedHours);

            // ── Guard note ────────────────────────────────────────────────────
            root.Children.Add(new TextBlock
            {
                Text         = "On finish, Meridian also creates a starter set of Guard protection rules "
                             + "from these answers (active on the Guard tier).",
                FontFamily   = Ui, FontSize = 11, Foreground = FgHint,
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 16, 0, 18),
            });

            // ── Buttons ───────────────────────────────────────────────────────
            var btnRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
            };
            var skipBtn   = MakeButton("Skip for now", Card, FgSecondary);
            var finishBtn = MakeButton("Finish setup", Accent, Theme.AccentInk);
            skipBtn.Margin = new Thickness(0, 0, 10, 0);

            bool closed = false;
            Action close = () => { if (!closed) { closed = true; try { win.Close(); } catch { } onComplete?.Invoke(); } };

            skipBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                log?.Invoke("[FirstRunSetup] User skipped the wizard.");
                close();
            };

            finishBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                try
                {
                    ApplyAnswers(profile, guardEngine,
                        txDailyLoss.Text, txPauseN.Text, txMaxTrades.Text, txSize.Text,
                        txStart.Text, txEnd.Text, noFixedHours.IsChecked == true, log);
                }
                catch (Exception ex)
                {
                    log?.Invoke("[FirstRunSetup] Apply failed (continuing): " + ex.Message);
                }
                close();
            };

            btnRow.Children.Add(skipBtn);
            btnRow.Children.Add(finishBtn);
            root.Children.Add(btnRow);

            // Wrap in a scroll viewer so small screens never clip the buttons.
            var scroll = new ScrollViewer
            {
                Content = root,
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };
            win.Content = scroll;
            win.ShowDialog();
            // ShowDialog blocks until close(); guarantee onComplete fired exactly once
            // even if the user closed via the OS (no chrome here, but defensive).
            if (!closed) { closed = true; onComplete?.Invoke(); }
        }

        // =====================================================================
        // Apply — write profile + seed Guard starter rules
        // =====================================================================

        private static void ApplyAnswers(StrategyProfile profile, GuardEngine guardEngine,
                                         string sDailyLoss, string sPauseN, string sMaxTrades,
                                         string sSize, string sStart, string sEnd,
                                         bool noFixedHours, Action<string> log)
        {
            // ── Daily loss (0 / blank = leave disabled) ──
            double dailyLoss = ParseDouble(sDailyLoss, 0);
            if (dailyLoss > 0) profile.MaxDailyLossUsd = dailyLoss;

            // ── Pause after N losses ──
            int pauseN = ParseInt(sPauseN, 0);
            if (pauseN > 0) profile.PauseAfterNLosses = pauseN;

            // ── Max trades / session ──
            int maxTrades = ParseInt(sMaxTrades, 0);
            if (maxTrades > 0)
            {
                profile.TradesPerSessionMax = maxTrades;
                if (profile.TradesPerSessionMin > maxTrades)
                    profile.TradesPerSessionMin = maxTrades;
            }

            // ── Typical size ──
            double size = ParseDouble(sSize, 0);
            if (size > 0)
            {
                profile.SizeMax = size;
                if (profile.SizeMin > size) profile.SizeMin = size;
            }

            // ── Session window ──
            profile.SessionWindowEnabled = !noFixedHours;
            if (!noFixedHours)
            {
                if (TryParseHhMm(sStart, out int sh, out int sm)) { profile.SessionStartHour = sh; profile.SessionStartMinute = sm; }
                if (TryParseHhMm(sEnd,   out int eh, out int em)) { profile.SessionEndHour   = eh; profile.SessionEndMinute   = em; }
                // Guard against inverted window — fall back to enabling-off rather than a bad config.
                if (new TimeSpan(profile.SessionStartHour, profile.SessionStartMinute, 0)
                    >= new TimeSpan(profile.SessionEndHour, profile.SessionEndMinute, 0))
                {
                    profile.SessionWindowEnabled = false;
                    log?.Invoke("[FirstRunSetup] Session start >= end; session-window check left disabled.");
                }
            }

            profile.SaveToFile(msg => log?.Invoke("[FirstRunSetup] " + msg));
            log?.Invoke(string.Format(
                "[FirstRunSetup] Profile written — dailyLoss={0}, pauseN={1}, maxTrades={2}, size={3}, sessionWindow={4}.",
                profile.MaxDailyLossUsd, profile.PauseAfterNLosses, profile.TradesPerSessionMax,
                profile.SizeMax, profile.SessionWindowEnabled));

            SeedGuardStarterRules(profile, guardEngine, dailyLoss, pauseN, log);
        }

        // =====================================================================
        // Guard starter rules (derived from the same answers; MERIDIAN.md §6).
        // Only seeded when the user has NO existing rules, so we never clobber.
        // =====================================================================

        private static void SeedGuardStarterRules(StrategyProfile profile, GuardEngine guardEngine,
                                                  double dailyLoss, int pauseN, Action<string> log)
        {
            if (guardEngine == null) return;
            if (guardEngine.Rules != null && guardEngine.Rules.Count > 0)
            {
                log?.Invoke("[FirstRunSetup] Guard already has rules — starter pack skipped.");
                return;
            }

            int seeded = 0;

            // 1. Tilt Early Warning — PSI < 70 → Notify (non-blocking awareness).
            guardEngine.AddRule(new GuardRule
            {
                Name            = "Tilt Early Warning",
                Action          = GuardActionType.Toast,
                CooldownMinutes = 10,
                Conditions      = { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 70 } },
            });
            seeded++;

            // 2. Hard Tilt Stop — PSI < 45 → Trading Pause (cancel new entries, 30 min).
            guardEngine.AddRule(new GuardRule
            {
                Name                 = "Hard Tilt Stop",
                Action               = GuardActionType.TradingPause,
                PauseMode            = PauseModeType.CancelOrders,
                PauseDurationMinutes = 30,
                ConfirmationSeconds  = 90,
                CooldownMinutes      = 15,
                Conditions           = { new GuardCondition { Type = GuardConditionType.PsiBelow, Threshold = 45 } },
            });
            seeded++;

            // 3. Revenge Trade Check — N consecutive losses → Acknowledge + 60s.
            if (pauseN > 0)
            {
                guardEngine.AddRule(new GuardRule
                {
                    Name                          = "Revenge Trade Check",
                    Action                        = GuardActionType.Acknowledge,
                    CountdownSeconds              = 60,
                    BlockTradesWhileAcknowledging = true,
                    OverridePhrase                = "I am revenge trading and I need to stop",
                    CooldownMinutes               = 10,
                    Conditions = { new GuardCondition { Type = GuardConditionType.ConsecutiveLossesAtLeast, Threshold = pauseN } },
                });
                seeded++;
            }

            // 4. Daily Loss Limit — realised session loss past declared limit → Trading Pause (rest of day).
            if (dailyLoss > 0)
            {
                guardEngine.AddRule(new GuardRule
                {
                    Name                 = "Daily Loss Limit",
                    Action               = GuardActionType.TradingPause,
                    PauseMode            = PauseModeType.Disconnect,
                    PauseDurationMinutes = 0,        // 0 = rest of day
                    ConfirmationSeconds  = 30,
                    CooldownMinutes      = 0,
                    Conditions           = { new GuardCondition { Type = GuardConditionType.SessionPnlBelow, Threshold = dailyLoss } },
                });
                seeded++;
            }

            log?.Invoke(string.Format("[FirstRunSetup] Seeded {0} Guard starter rule(s).", seeded));
        }

        // =====================================================================
        // UI helpers
        // =====================================================================

        private static FrameworkElement Field(string label, string hint, string initial,
                                              string placeholder, out TextBox box)
        {
            box = MakeBox(initial, placeholder, 160);
            var stack = new StackPanel { Margin = new Thickness(0, 0, 0, 14) };
            stack.Children.Add(LabelFor(label));
            stack.Children.Add(box);
            if (!string.IsNullOrEmpty(hint))
                stack.Children.Add(new TextBlock
                {
                    Text = hint, FontFamily = Ui, FontSize = 11, Foreground = FgHint,
                    TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 4, 0, 0),
                });
            return stack;
        }

        private static FrameworkElement WrapField(FrameworkElement inner, string hint)
        {
            var stack = new StackPanel { Margin = new Thickness(0, 0, 0, 4) };
            stack.Children.Add(inner);
            if (!string.IsNullOrEmpty(hint))
                stack.Children.Add(new TextBlock
                {
                    Text = hint, FontFamily = Ui, FontSize = 11, Foreground = FgHint,
                    TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 4, 0, 0),
                });
            return stack;
        }

        private static TextBlock LabelFor(string label) => new TextBlock
        {
            Text = label, FontFamily = Ui, FontSize = 12, FontWeight = FontWeights.SemiBold,
            Foreground = FgPrimary, Margin = new Thickness(0, 0, 0, 5),
            VerticalAlignment = VerticalAlignment.Center,
        };

        private static TextBox MakeBox(string initial, string placeholder, double width)
        {
            var tb = new TextBox
            {
                Text            = initial ?? "",
                Width           = width,
                HorizontalAlignment = HorizontalAlignment.Left,
                Background      = FieldBg,
                Foreground      = FgPrimary,
                CaretBrush      = FgPrimary,
                BorderBrush     = FieldBorder,
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(8, 6, 8, 6),
                FontFamily      = Ui,
                FontSize        = 13,
                Tag             = placeholder,   // kept for reference; lightweight (no placeholder adorner to keep it dependency-free)
            };
            return tb;
        }

        private static Border MakeButton(string text, Brush bg, Brush fg)
        {
            return new Border
            {
                Background      = bg,
                CornerRadius    = new CornerRadius(8),
                Padding         = new Thickness(18, 9, 18, 9),
                Cursor          = System.Windows.Input.Cursors.Hand,
                Child = new TextBlock
                {
                    Text = text, FontFamily = Ui, FontSize = 13, FontWeight = FontWeights.SemiBold,
                    Foreground = fg, HorizontalAlignment = HorizontalAlignment.Center,
                },
            };
        }

        // =====================================================================
        // Parsing — tolerant; never throws, always falls back.
        // =====================================================================

        private static double ParseDouble(string s, double fallback)
            => double.TryParse((s ?? "").Trim(),
                   System.Globalization.NumberStyles.Any,
                   System.Globalization.CultureInfo.InvariantCulture, out double v) && v >= 0
               ? v : fallback;

        private static int ParseInt(string s, int fallback)
            => int.TryParse((s ?? "").Trim(), out int v) && v >= 0 ? v : fallback;

        private static bool TryParseHhMm(string s, out int hh, out int mm)
        {
            hh = 0; mm = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            var parts = s.Trim().Split(':');
            if (parts.Length != 2) return false;
            if (!int.TryParse(parts[0], out hh) || !int.TryParse(parts[1], out mm)) return false;
            if (hh < 0 || hh > 23 || mm < 0 || mm > 59) return false;
            return true;
        }
    }
}
