using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Adapter: history + profile → PreSessionData (the pre-trade PRIME surface).
    /// Pure C# (no NT8/WPF). The ONE focus is the trader's single highest-probability
    /// leak, taken from the existing IntelligenceEngine risk brief — this is the
    /// "discover → prime" handoff in the discipline loop (UX_DESIGN_ROOT.md §1/§2.2).
    /// Below the data threshold it is HONEST (no fabricated risk label).
    /// </summary>
    internal static class PreSessionAdapter
    {
        public static PreSessionData From(SessionHistoryStore store, StrategyProfile profile, DateTime today)
        {
            var d = new PreSessionData
            {
                DateText = today.ToString("ddd, MMMM d", CultureInfo.InvariantCulture).ToUpperInvariant()
            };

            var all = (store?.Sessions ?? new List<SessionHistoryEntry>())
                      .Where(s => s != null).OrderBy(s => s.Date).ToList();
            var brief = IntelligenceEngine.ComputeRiskBrief(all.ToList());

            d.HasData = brief != null && brief.HasEnoughData;

            if (!d.HasData)
            {
                d.FocusTitle  = "Still learning your patterns.";
                d.FocusDetail = (brief != null && !string.IsNullOrEmpty(brief.RecommendationText))
                    ? brief.RecommendationText
                    : "Trade your plan and stay inside your limits. After a few sessions, Meridian will point you at the one thing most likely to trip you up today.";
                d.StandingLine = all.Count > 0
                    ? all.Count + (all.Count == 1 ? " session recorded so far." : " sessions recorded so far.")
                    : null;
            }
            else
            {
                var focus = FocusFromWeakness(brief.TopWeaknessThisWeek, profile);
                d.FocusTitle  = focus.Item1;
                // Prefer the on-brand coach line over the engine's clinical recommendation
                // (which can leak raw internal labels like 'Size Spike').
                d.FocusDetail = focus.Item2;

                // Two small, subordinate reminders — genuine priming substance, never colored.
                string focusKey = (brief.TopWeaknessThisWeek ?? "").ToLowerInvariant();
                if (profile != null)
                {
                    if (profile.PauseAfterNLosses > 0 && !(focusKey.Contains("revenge") || focusKey.Contains("loss") || focusKey.Contains("streak")))
                        d.AlsoWatch.Add("After " + profile.PauseAfterNLosses + " losses in a row, step away — that's where revenge entries cluster.");
                    if (profile.SessionWindowEnabled && !focusKey.Contains("window") && !focusKey.Contains("session"))
                        d.AlsoWatch.Add("Stop when your window closes at " + Hm(profile.SessionEndHour, profile.SessionEndMinute) + " — late P&L is usually given back.");
                }

                var last30 = all.Where(s => (today - s.Date).TotalDays <= 30).ToList();
                int comp30 = last30.Count > 0 ? (int)Math.Round(last30.Average(s => (double)s.ComposurePct)) : 0;
                string weekday = today.ToString("dddd", CultureInfo.InvariantCulture) + "s";
                string trend = brief.IsTodayAboveAverage
                    ? weekday + " usually run a little above your average."
                    : weekday + " usually run a little below your average.";
                // Surface composure as a structured, color-coded read (the view renders it
                // as the "Today's read" card) instead of a buried gray footnote string.
                d.HasComposure  = last30.Count > 0;
                d.Composure30   = comp30;
                d.ComposureRead = trend;
                d.StandingLine  = d.HasComposure ? null : trend;
            }

            // Confirmation: only protections actually set (neutral, never an alarm).
            if (profile != null)
            {
                if (profile.MaxDailyLossUsd > 0) d.Protections.Add(new PreSessionProt { Label = "Daily loss limit", Value = "$" + profile.MaxDailyLossUsd.ToString("0") });
                if (profile.PauseAfterNLosses > 0) d.Protections.Add(new PreSessionProt { Label = "Pause after losses", Value = profile.PauseAfterNLosses + " in a row" });
                if (profile.SizeMax > 0) d.Protections.Add(new PreSessionProt { Label = "Max position size", Value = (int)profile.SizeMax + " contracts" });
                if (profile.SessionWindowEnabled) d.Protections.Add(new PreSessionProt { Label = "Session window", Value = Hm(profile.SessionStartHour, profile.SessionStartMinute) + " – " + Hm(profile.SessionEndHour, profile.SessionEndMinute) });
            }

            // ── Home: read-band KPIs, trajectory, leaks, lesson, ritual ──────────
            var month = all.Where(s => s.Date.Year == today.Year && s.Date.Month == today.Month).ToList();
            var last  = all.Count > 0 ? all[all.Count - 1] : null;
            d.HasKpis       = all.Count > 0;
            d.LastComp      = last != null ? last.ComposurePct : -1;
            d.LastDate      = last != null ? last.Date.ToString("ddd, MMM d", CultureInfo.InvariantCulture) : "";
            d.MonthSessions = month.Count;
            d.NetMonthPnl   = month.Sum(s => s.TotalPnl);
            d.StableDays    = month.Count(s => s.ComposurePct >= SessionData.ComposureStableThreshold);

            // trajectory — last 12 sessions' composure
            var traj = all.Skip(Math.Max(0, all.Count - 12)).ToList();
            foreach (var s in traj) d.TrajSeries.Add(s.ComposurePct);
            if (traj.Count > 0)
            {
                d.TrajNow   = traj[traj.Count - 1].ComposurePct;
                int avg     = (int)Math.Round(traj.Average(s => (double)s.ComposurePct));
                d.TrajGrade = Grade(avg);
                if (traj.Count >= 5)
                {
                    int half  = Math.Max(1, traj.Count / 2);
                    double e  = traj.Take(half).Average(s => (double)s.ComposurePct);
                    double l  = traj.Skip(traj.Count - half).Average(s => (double)s.ComposurePct);
                    int delta = (int)Math.Round(l - e);
                    d.TrajDelta = delta <= -4 ? "↓ " + Math.Abs(delta) + " pts · trending down"
                                : delta >=  4 ? "↑ " + delta + " pts · trending up"
                                : "holding steady";
                }
                else d.TrajDelta = traj.Count + " session" + (traj.Count == 1 ? "" : "s") + " logged";
            }

            // "what wrecks you most" — top dimensions across the broke-down sessions
            var worst = all.Where(s => s.ComposurePct < 55).ToList();
            if (worst.Count > 0)
            {
                var groups = worst.GroupBy(s => s.TopDimensionLabel)
                                  .Where(g => !string.IsNullOrEmpty(g.Key) && g.Key != "None")
                                  .Select(g => new { Name = g.Key, Count = g.Count() })
                                  .OrderByDescending(g => g.Count).Take(3);
                foreach (var g in groups)
                    d.Leaks.Add(new PreSessionLeak {
                        Name = g.Name,
                        Freq = g.Count + "/" + worst.Count + " days",
                        Sev  = (g.Count * 2 >= worst.Count) ? 0 : 1 });
            }

            // yesterday's lesson — from the last session's dominant leak
            if (last != null)
            {
                d.LessonText = LessonFor(last.TopDimensionLabel);
                d.LessonDate = last.Date.ToString("MMM d", CultureInfo.InvariantCulture) + " debrief";
            }

            // pre-session ritual — the USER's own steps (RitualStore), not imposed defaults.
            foreach (var step in RitualStore.Load()) d.Ritual.Add(step);

            return d;
        }

        private static string Grade(int comp)
            => comp >= 90 ? "A+" : comp >= 80 ? "A" : comp >= 72 ? "B+"
             : comp >= 60 ? "B"  : comp >= 50 ? "C" : "D";

        private static string LessonFor(string dim)
        {
            string w = (dim ?? "").ToLowerInvariant();
            if (w.Contains("size") || w.Contains("outlier"))  return "Cut size after your first win — that's when the oversize adds start.";
            if (w.Contains("revenge") || w.Contains("streak") || w.Contains("freq") || w.Contains("overtrad")) return "After two losses, step away — your re-entries are where it spirals.";
            if (w.Contains("stop") || w.Contains("sl"))        return "Take the stop you planned — widening it turns a small loss into a spiral.";
            if (w.Contains("overstay") || w.Contains("hold"))  return "Close on your max hold — the winners you overstay give it back.";
            if (w.Contains("window") || w.Contains("session") || w.Contains("time")) return "Stop when your window closes — late P&L is usually returned.";
            return "Trade your plan and stay inside your limits — that's the whole game.";
        }

        // Humanize the engine's top-weakness dimension into one crisp title + action.
        // Substring match so it is robust to the exact dimension label.
        private static Tuple<string, string> FocusFromWeakness(string weakness, StrategyProfile profile)
        {
            string w = (weakness ?? "").ToLowerInvariant();
            int sizeMax = profile != null ? (int)profile.SizeMax : 0;
            int pause   = profile != null ? profile.PauseAfterNLosses : 0;

            if (w.Contains("size") || w.Contains("outlier"))
                return Tuple.Create("Keep your size flat today.",
                    (sizeMax > 0 ? "Adds past " + sizeMax + " contracts" : "Oversized adds") + " have made money lately, but they broke your size rule every time — that's luck, not edge.");
            if (w.Contains("revenge") || w.Contains("loss") || w.Contains("streak") || w.Contains("freq") || w.Contains("overtrad"))
                return Tuple.Create("Step away after consecutive losses.",
                    (pause > 0 ? "After " + pause + " losses in a row, take a break" : "After back-to-back losses, take a break") + " — that's where your worst trades have clustered.");
            if (w.Contains("stop") || w.Contains("sl"))
                return Tuple.Create("Honor your planned stops.",
                    "Take the stop you planned — widening it is what turns a small loss into a spiral.");
            if (w.Contains("overstay") || w.Contains("hold"))
                return Tuple.Create("Close your trades on plan.",
                    "Once a trade passes your max hold, the gains are usually given back — close it on plan.");
            if (w.Contains("window") || w.Contains("session") || w.Contains("time"))
                return Tuple.Create("Stop when your window closes.",
                    "P&L earned after your window closes is usually given back — stop when it closes.");

            return Tuple.Create("Trade your plan today.",
                "Stay inside your declared limits — that's the whole game.");
        }

        private static string Hm(int h, int m) => h.ToString("00") + ":" + m.ToString("00");
    }
}
