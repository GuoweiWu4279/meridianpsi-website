using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Best-effort, anonymized upload of a recorded session for the (opt-in) research
    /// program. PURELY GATED: does nothing unless <see cref="ResearchData.Enabled"/>
    /// (consent given AND endpoint configured). Fire-and-forget and exception-swallowing
    /// so it can NEVER block or affect trading. The product works fully if it is blocked.
    ///
    /// Anonymization: the account identifier is replaced with the install's random anon id;
    /// no name, credentials, account numbers, or funds are present in the recorder stream.
    /// </summary>
    internal static class ResearchUploader
    {
        private static readonly HttpClient Http = new HttpClient { Timeout = TimeSpan.FromSeconds(30) };
        private static readonly Regex AcctField = new Regex("\"acct\":\"[^\"]*\"", RegexOptions.Compiled);

        // Near-real-time streaming state. The endpoint stores each session under a STABLE
        // key (= the recording filename), so every re-upload OVERWRITES the prior copy —
        // the cloud object always converges to the latest local bytes. _lastSentLen lets
        // us skip a flush when the live file hasn't grown; _flushBusy prevents overlapping
        // streaming flushes from piling up.
        private static readonly ConcurrentDictionary<string, long> _lastSentLen =
            new ConcurrentDictionary<string, long>(StringComparer.OrdinalIgnoreCase);
        private static int _flushBusy; // 0 = idle, 1 = a streaming flush is in flight

        /// <summary>Anonymize one JSONL line: strip the account id → anon id.</summary>
        public static string Anonymize(string line, string anonId)
        {
            if (string.IsNullOrEmpty(line)) return line;
            return AcctField.Replace(line, "\"acct\":\"" + (anonId ?? "anon") + "\"");
        }

        /// <summary>
        /// STREAMING flush of the live (still-being-written) recording — called on a
        /// throttled cadence (~60 s) from CallbackRecorder.Emit. Ships the whole growing
        /// file, anonymized, overwriting the session's stable cloud object. Does NOT mark
        /// the file done (it is not finished). Skips when unchanged since the last flush,
        /// and never overlaps itself. Non-blocking; never throws; no-op unless enabled.
        /// </summary>
        public static void FlushActive(string recordingPath)
        {
            try
            {
                if (!ResearchData.Enabled || string.IsNullOrEmpty(recordingPath) || !File.Exists(recordingPath))
                    return;
                if (AlreadyUploaded(recordingPath)) return; // already finalized
                long len = new FileInfo(recordingPath).Length;
                if (len <= 0) return;
                if (_lastSentLen.TryGetValue(recordingPath, out long prev) && prev == len)
                    return; // not grown since last flush — nothing to do
                if (Interlocked.CompareExchange(ref _flushBusy, 1, 0) != 0)
                    return; // a streaming flush is already running
                Task.Run(async () =>
                {
                    try { await UploadFile(recordingPath, markDone: false).ConfigureAwait(false); }
                    finally { Interlocked.Exchange(ref _flushBusy, 0); }
                });
            }
            catch { }
        }

        /// <summary>
        /// FINALIZE upload of a finished recording (session roll / add-on stop / startup
        /// recovery): ship the complete file and, on success, mark it done so it is never
        /// re-sent. Idempotent (skips already-done). Non-blocking; never throws.
        /// </summary>
        public static void QueueUpload(string recordingPath)
        {
            try
            {
                if (!ResearchData.Enabled || string.IsNullOrEmpty(recordingPath) || !File.Exists(recordingPath))
                    return;
                if (AlreadyUploaded(recordingPath)) return;
                // Never finalize the file that is still being written (the live session).
                if (string.Equals(recordingPath, CallbackRecorder.ActivePath, StringComparison.OrdinalIgnoreCase))
                    return;
                if (new FileInfo(recordingPath).Length <= 0) return; // empty → nothing to send
                Task.Run(() => UploadFile(recordingPath, markDone: true));
            }
            catch { }
        }

        /// <summary>
        /// Re-upload every finished recording in <paramref name="recordingsDir"/> that
        /// has no success marker — the crash / offline / shutdown-race recovery path.
        /// Runs on add-on Start. Best-effort; never throws. No-op unless research enabled.
        /// </summary>
        public static void DrainPending(string recordingsDir)
        {
            try
            {
                if (!ResearchData.Enabled || string.IsNullOrEmpty(recordingsDir) || !Directory.Exists(recordingsDir))
                    return;
                foreach (var path in Directory.GetFiles(recordingsDir, "*.jsonl"))
                    QueueUpload(path);   // QueueUpload skips active/empty/already-uploaded
            }
            catch { }
        }

        private static async Task UploadFile(string recordingPath, bool markDone)
        {
            try
            {
                string anon = ResearchData.AnonId;
                long lenAtRead;
                try { lenAtRead = new FileInfo(recordingPath).Length; } catch { lenAtRead = 0; }

                var sb = new StringBuilder();
                foreach (var line in ReadLinesShared(recordingPath))
                    sb.AppendLine(Anonymize(line, anon));

                using (var content = new StringContent(sb.ToString(), Encoding.UTF8, "application/x-ndjson"))
                {
                    content.Headers.Add("X-Meridian-Key", ResearchData.Key);
                    content.Headers.Add("X-Meridian-Anon", anon);
                    // Stable per-session id (filename) → the endpoint overwrites one object
                    // per session, so streaming flush + final flush converge, never duplicate.
                    content.Headers.Add("X-Meridian-Session", Path.GetFileNameWithoutExtension(recordingPath));
                    var resp = await Http.PostAsync(ResearchData.Endpoint, content).ConfigureAwait(false);
                    if (resp != null && resp.IsSuccessStatusCode)
                    {
                        _lastSentLen[recordingPath] = lenAtRead;
                        // Mark done ONLY on a finalize 2xx → a failed/blocked/offline POST is
                        // retried next launch by DrainPending instead of being lost.
                        if (markDone) MarkUploaded(recordingPath);
                    }
                    resp?.Dispose();
                }
            }
            catch { /* network unavailable / blocked / anything — silently ignored, retried later */ }
        }

        // Reads a file that may be open for writing (the live recording). FileShare.ReadWrite
        // is required because CallbackRecorder holds it open with a StreamWriter. A trailing
        // partial line (not yet newline-terminated) is tolerated: the endpoint stores NDJSON
        // and the analysis skips unparseable lines; the next overwrite supersedes it.
        private static IEnumerable<string> ReadLinesShared(string path)
        {
            using (var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            using (var sr = new StreamReader(fs))
            {
                string line;
                while ((line = sr.ReadLine()) != null)
                    yield return line;
            }
        }

        private static string MarkerPath(string recordingPath)
        {
            string dir = Path.Combine(Path.GetDirectoryName(recordingPath) ?? ".", "uploaded");
            return Path.Combine(dir, Path.GetFileName(recordingPath) + ".done");
        }

        private static bool AlreadyUploaded(string recordingPath)
        {
            try { return File.Exists(MarkerPath(recordingPath)); } catch { return false; }
        }

        private static void MarkUploaded(string recordingPath)
        {
            try
            {
                string marker = MarkerPath(recordingPath);
                Directory.CreateDirectory(Path.GetDirectoryName(marker));
                File.WriteAllText(marker, DateTime.UtcNow.ToString("o"));
            }
            catch { }
        }
    }
}
