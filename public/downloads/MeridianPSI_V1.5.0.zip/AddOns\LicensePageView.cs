// LicensePageView.cs
//
// PURE-WPF static view for the dashboard's License page. Extracted from
// MeridianDashboard.CreateLicensePage so the page can be rendered OFFLINE
// (in the UI harness, with no NinjaTrader) AND drive the LIVE page.
//
// Build(...) produces the SAME visual tree CreateLicensePage produced, but is
// a pure function of plain-C# parameters (the live page reads a LicenseManager
// singleton + two hub instance fields + two statics; those values are passed
// in here so Build is renderable with sample values offline). It wires NO live
// click handlers (Activate / Deactivate / Copy / Export Diagnostics / dev-tools
// reveal). The live hub calls its own CreateLicensePage path for interactivity;
// the offline harness renders Build(...) straight to PNG. Hover-only visual
// feedback IS wired (presentation, not data interaction).
//
// Palette: the hub's private brush fields were aliases of the central Theme
// tokens (FgPrimary→Theme.FgPrimary, FgSecondary→Theme.FgSecondary,
// FgHint→Theme.FgHint, FgAccent→Theme.Accent, BgCard→Theme.CardGradient).
// Those substitutions are applied here verbatim.
//
// Helpers (MakeLicenseLabel / MakeLicenseButton) are DUPLICATED here as private
// statics — the hub keeps its own copies intact.

using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal static class LicensePageView
    {
        // ── Palette aliases (mirror MeridianDashboard's private fields) ─────────
        private static readonly Brush FgPrimary   = Theme.FgPrimary;
        private static readonly Brush FgSecondary = Theme.FgSecondary;
        private static readonly Brush FgHint      = Theme.FgHint;
        private static readonly Brush FgAccent    = Theme.Accent;
        private static readonly Brush BgCard      = Theme.CardGradient;

        /// <summary>
        /// Builds the License page visual tree as a pure function of license
        /// state. PURE WPF — read-only, no live click handlers are attached.
        /// </summary>
        /// <param name="status">Current license status (Trial/Licensed/Expired/…).</param>
        /// <param name="trialDaysRemaining">Days left in trial (used only for Trial_Active).</param>
        /// <param name="licenseKey">Stored license key, or null/empty if none. Masked when licensed; pre-fills the key box otherwise.</param>
        /// <param name="machineId">This machine's fingerprint (LicenseManager.GetMachineId()).</param>
        /// <param name="productVersion">Product version string for the footer (MeridianPSI.ProductVersion).</param>
        /// <param name="updateVersion">Newer version available, or null to hide the update banner.</param>
        /// <param name="updateNotes">Release notes shown under the update banner (optional).</param>
        public static FrameworkElement Build(
            LicenseStatus status,
            int           trialDaysRemaining,
            string        licenseKey,
            string        machineId,
            string        productVersion,
            int           graceDays,
            string        storeUrl,
            string        updateVersion = null,
            string        updateNotes   = null)
        {
            // ── Status badge colours ─────────────────────────────────────────
            string statusText;
            Brush  statusBg;
            switch (status)
            {
                case LicenseStatus.Trial_Active:
                    int days = trialDaysRemaining;
                    statusText = $"Trial Active — {days} day{(days == 1 ? "" : "s")} remaining";
                    statusBg   = new SolidColorBrush(Color.FromRgb(5, 120, 84));
                    break;
                case LicenseStatus.Trial_Expired:
                    statusText = "Trial Expired — Please activate";
                    statusBg   = new SolidColorBrush(Color.FromRgb(160, 60, 40));
                    break;
                case LicenseStatus.Licensed:
                    statusText = "Licensed  ✓";
                    statusBg   = new SolidColorBrush(Color.FromRgb(5, 120, 84));
                    break;
                case LicenseStatus.Offline_Grace:
                    statusText = $"Offline Grace — up to {graceDays} days";
                    statusBg   = new SolidColorBrush(Color.FromRgb(140, 100, 20));
                    break;
                case LicenseStatus.Expired:
                    statusText = "Subscription Expired — Please renew";
                    statusBg   = new SolidColorBrush(Color.FromRgb(160, 60, 40));
                    break;
                default:
                    statusText = "License Invalid — Please re-activate";
                    statusBg   = new SolidColorBrush(Color.FromRgb(160, 60, 40));
                    break;
            }

            // ── Root scroll ─────────────────────────────────────────────────
            var scroll = new System.Windows.Controls.ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };

            // A license / activation surface reads as a focused, capped column (like a
            // checkout) — not a form stretched across the whole tab. Cap + centre it.
            var stack = new StackPanel
            {
                Margin              = new Thickness(28, 24, 28, 24),
                MaxWidth            = 620,
                HorizontalAlignment = HorizontalAlignment.Center,
            };

            // ── Update available banner (shown above everything else) ─────────
            if (updateVersion != null)
            {
                var updateBorder = new Border
                {
                    Background   = new SolidColorBrush(Color.FromRgb(40, 80, 140)),
                    CornerRadius = new CornerRadius(6),
                    Padding      = new Thickness(16, 12, 16, 12),
                    Margin       = new Thickness(0, 0, 0, 20),
                };
                var updateInner = new StackPanel();
                updateInner.Children.Add(new TextBlock
                {
                    Text       = $"⬆  Update available — {updateVersion}",
                    FontSize   = 14,
                    FontFamily = Theme.Font,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = FgPrimary,
                    Margin     = new Thickness(0, 0, 0, 4),
                });
                if (!string.IsNullOrEmpty(updateNotes))
                {
                    updateInner.Children.Add(new TextBlock
                    {
                        Text       = updateNotes,
                        FontSize   = 12,
                        FontFamily = Theme.Font,
                        Foreground = FgSecondary,
                        TextWrapping = TextWrapping.Wrap,
                        Margin     = new Thickness(0, 0, 0, 8),
                    });
                }
                var dlBtn = new Button
                {
                    Content             = "Go to Download",
                    Padding             = new Thickness(14, 6, 14, 6),
                    Background          = new SolidColorBrush(Color.FromRgb(30, 120, 220)),
                    Foreground          = FgPrimary,
                    BorderThickness     = new Thickness(0),
                    FontFamily          = Theme.Font,
                    FontSize            = 12,
                    HorizontalAlignment = HorizontalAlignment.Left,
                    Cursor              = System.Windows.Input.Cursors.Hand,
                };
                // NOTE: live click (→ StoreUrl) is attached by the hub.
                updateInner.Children.Add(dlBtn);
                updateBorder.Child = updateInner;
                stack.Children.Add(updateBorder);
            }

            // ── Status badge ────────────────────────────────────────────────
            var badge = new Border
            {
                Background    = statusBg,
                CornerRadius  = new CornerRadius(6),
                Padding       = new Thickness(14, 8, 14, 8),
                Margin        = new Thickness(0, 0, 0, 24),
                HorizontalAlignment = HorizontalAlignment.Left,
            };
            badge.Child = new TextBlock
            {
                Text       = statusText,
                FontSize   = 13,
                FontFamily = Theme.Font,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgPrimary,
            };
            stack.Children.Add(badge);

            // ── Machine ID row ───────────────────────────────────────────────
            stack.Children.Add(MakeLicenseLabel("Machine ID"));
            var midRow = new Grid { Margin = new Thickness(0, 4, 0, 20) };
            midRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            midRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var midBox = new TextBox
            {
                Text              = machineId,
                IsReadOnly        = true,
                FontFamily        = new FontFamily("Consolas"),
                FontSize          = 12,
                Foreground        = FgSecondary,
                Background        = BgCard,
                BorderBrush       = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness   = new Thickness(1),
                Padding           = new Thickness(10, 7, 10, 7),
            };
            Grid.SetColumn(midBox, 0);
            midRow.Children.Add(midBox);

            var copyBtn = MakeLicenseButton("Copy");
            copyBtn.Margin = new Thickness(8, 0, 0, 0);
            // NOTE: live click (→ Clipboard.SetText) is attached by the hub.
            Grid.SetColumn(copyBtn, 1);
            midRow.Children.Add(copyBtn);
            stack.Children.Add(midRow);

            // ── Key input (hidden when already licensed) ─────────────────────
            bool showActivate = status != LicenseStatus.Licensed &&
                                status != LicenseStatus.Offline_Grace;

            if (showActivate)
            {
                stack.Children.Add(MakeLicenseLabel("License Key"));
                var keyRow = new Grid { Margin = new Thickness(0, 4, 0, 8) };
                keyRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                keyRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

                var keyBox = new TextBox
                {
                    FontFamily      = new FontFamily("Consolas"),
                    FontSize        = 12,
                    Foreground      = FgPrimary,
                    Background      = BgCard,
                    BorderBrush     = new SolidColorBrush(Color.FromArgb(80, 255, 255, 255)),
                    BorderThickness = new Thickness(1),
                    Padding         = new Thickness(10, 7, 10, 7),
                    ToolTip         = "Paste your Whop license key — find it at whop.com/hub after purchase",
                };
                // Pre-fill with existing key if we have one (invalid/expired case).
                if (!string.IsNullOrEmpty(licenseKey)) keyBox.Text = licenseKey;
                Grid.SetColumn(keyBox, 0);
                keyRow.Children.Add(keyBox);

                var activateBtn = MakeLicenseButton("Activate", accent: true);
                activateBtn.Margin = new Thickness(8, 0, 0, 0);
                Grid.SetColumn(activateBtn, 1);
                keyRow.Children.Add(activateBtn);
                stack.Children.Add(keyRow);

                // Feedback label
                var feedbackLabel = new TextBlock
                {
                    FontSize   = 12,
                    FontFamily = Theme.Font,
                    Foreground = FgSecondary,
                    Margin     = new Thickness(0, 4, 0, 20),
                    TextWrapping = TextWrapping.Wrap,
                };
                stack.Children.Add(feedbackLabel);
                // NOTE: live click handler (→ lm.ActivateAsync) is attached by the hub.
            }
            else
            {
                // Already licensed — show masked key + deactivate option
                stack.Children.Add(MakeLicenseLabel("License Key"));
                string maskedKey = licenseKey ?? "";
                if (maskedKey.Length > 8)
                    maskedKey = maskedKey.Substring(0, 4) + "-****-****-" + maskedKey.Substring(maskedKey.Length - 4);

                stack.Children.Add(new TextBlock
                {
                    Text         = maskedKey,
                    FontFamily   = new FontFamily("Consolas"),
                    FontSize     = 12,
                    Foreground   = FgSecondary,
                    Margin       = new Thickness(0, 4, 0, 20),
                });

                // Remove license button — clears local cache so key can be entered on another PC
                var deactBtn = MakeLicenseButton("Remove license from this machine (to move to another PC)");
                deactBtn.Margin = new Thickness(0, 0, 0, 8);

                var deactFeedback = new TextBlock
                {
                    FontSize   = 12,
                    FontFamily = Theme.Font,
                    Foreground = FgSecondary,
                    Margin     = new Thickness(0, 4, 0, 20),
                    TextWrapping = TextWrapping.Wrap,
                };
                stack.Children.Add(deactBtn);
                stack.Children.Add(deactFeedback);
                // NOTE: live click handler (→ lm.DeactivateAsync) is attached by the hub.
            }

            // ── Divider ──────────────────────────────────────────────────────
            stack.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 8, 0, 20),
            });

            // ── Store link ───────────────────────────────────────────────────
            stack.Children.Add(new TextBlock
            {
                Text         = "Subscribe / Purchase",
                FontSize     = 11,
                FontFamily   = Theme.Font,
                FontWeight   = FontWeights.SemiBold,
                Foreground   = FgHint,
                Margin       = new Thickness(0, 0, 0, 4),
            });

            var storeLink = new TextBlock
            {
                Text            = storeUrl,
                FontSize        = 12,
                FontFamily      = Theme.Font,
                Foreground      = FgAccent,
                Cursor          = Cursors.Hand,
                TextDecorations = TextDecorations.Underline,
                Margin          = new Thickness(0, 0, 0, 0),
            };
            // NOTE: live click (→ StoreUrl) is attached by the hub.
            stack.Children.Add(storeLink);

            // ── Trial upgrade CTA (shown for trial / expired users) ──────────
            if (status == LicenseStatus.Trial_Active || status == LicenseStatus.Trial_Expired
                || status == LicenseStatus.Expired)
            {
                stack.Children.Add(new Border
                {
                    Height     = 1,
                    Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                    Margin     = new Thickness(0, 20, 0, 16),
                });
                stack.Children.Add(new TextBlock
                {
                    Text       = "Unlock with a full license",
                    FontSize   = 13,
                    FontFamily = Theme.Font,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = FgPrimary,
                    Margin     = new Thickness(0, 0, 0, 8),
                });
                string[] features =
                {
                    "Guard — rules that enforce themselves (6 triggers · 5 action levels)",
                    "Intel — monthly digest, weekday patterns & crash-trigger analysis",
                    "PSI × P&L correlation — Stable vs Critical session averages",
                    "Today's Risk Brief — personalized pre-session summary",
                };
                foreach (var f in features)
                    stack.Children.Add(new TextBlock
                    {
                        Text         = "✓  " + f,
                        FontSize     = 11,
                        FontFamily   = Theme.Font,
                        Foreground   = FgSecondary,
                        TextWrapping = TextWrapping.Wrap,
                        Margin       = new Thickness(0, 0, 0, 5),
                    });
                var ctaBtn = new Border
                {
                    Background      = new SolidColorBrush(Color.FromRgb(16, 185, 129)),
                    CornerRadius    = new CornerRadius(8),
                    Padding         = new Thickness(0, 12, 0, 12),
                    Margin          = new Thickness(0, 12, 0, 0),
                    Cursor          = Cursors.Hand,
                    HorizontalAlignment = HorizontalAlignment.Stretch,
                    Child = new TextBlock
                    {
                        Text                = "Upgrade — full access  →",
                        FontSize            = 13,
                        FontFamily          = Theme.Font,
                        FontWeight          = FontWeights.SemiBold,
                        Foreground          = Theme.AccentInk,
                        HorizontalAlignment = HorizontalAlignment.Center,
                    },
                };
                ctaBtn.MouseEnter += (_, __) => ctaBtn.Background = new SolidColorBrush(Color.FromRgb(40, 155, 255));
                ctaBtn.MouseLeave += (_, __) => ctaBtn.Background = new SolidColorBrush(Color.FromRgb(16, 185, 129));
                // NOTE: live click (→ StoreUrl) is attached by the hub.
                stack.Children.Add(ctaBtn);
            }

            // ── Export Diagnostics ───────────────────────────────────────────
            stack.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(18, 255, 255, 255)),
                Margin     = new Thickness(0, 24, 0, 16),
            });
            stack.Children.Add(new TextBlock
            {
                Text         = "Having an issue? Export a diagnostics file and send it to support.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 8),
            });
            var diagStatusLbl = new TextBlock
            {
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 6, 0, 0),
            };
            var diagBtn = new Button
            {
                Content             = "Export Diagnostics File",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = BgCard,
                Foreground          = FgPrimary,
                BorderBrush         = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255)),
                BorderThickness     = new Thickness(1),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            // NOTE: live click (→ DiagnosticsExporter) is attached by the hub.
            stack.Children.Add(diagBtn);
            stack.Children.Add(diagStatusLbl);

            // ── Version footer (click 5× to reveal developer tools) ──────────
            stack.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(18, 255, 255, 255)),
                Margin     = new Thickness(0, 24, 0, 12),
            });

            // ── Help / documentation link ────────────────────────────────────
            var docsRow = new StackPanel
            {
                Orientation         = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 0, 0, 10),
            };
            var docsTb = new TextBlock
            {
                Text              = "Documentation & User Guide",
                FontSize          = 10,
                FontFamily        = Theme.Font,
                Foreground        = FgAccent,
                TextDecorations   = null,
                Cursor            = System.Windows.Input.Cursors.Hand,
                VerticalAlignment = VerticalAlignment.Center,
            };
            docsTb.MouseEnter += (_, __) => docsTb.TextDecorations = TextDecorations.Underline;
            docsTb.MouseLeave += (_, __) => docsTb.TextDecorations = null;
            // NOTE: live click (→ DocsUrl) is attached by the hub.
            docsRow.Children.Add(docsTb);
            stack.Children.Add(docsRow);

            var devPanel  = new StackPanel { Visibility = Visibility.Collapsed };

            var versionTb = new TextBlock
            {
                Text      = $"MeridianPSI v{productVersion}",
                FontSize  = 10,
                FontFamily = Theme.Font,
                Foreground = FgHint,
                Cursor     = Cursors.Hand,
                Margin     = new Thickness(0, 0, 0, 16),
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            // NOTE: live click (5× → reveal devPanel) is attached by the hub.
            stack.Children.Add(versionTb);

            // ── Developer Tools (hidden; reveal by clicking version 5 times) ──
            devPanel.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 0, 0, 12),
            });
            devPanel.Children.Add(new TextBlock
            {
                Text       = "Developer Tools",
                FontSize   = 11,
                FontFamily = Theme.Font,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgHint,
                Margin     = new Thickness(0, 0, 0, 6),
            });

            // ── Demo Data ──────────────────────────────────────────────────────
            devPanel.Children.Add(new TextBlock
            {
                Text         = "Seed 5 months of story-driven demo history (Dec 2025 – Apr 2026). ⚠ This overwrites your real history.xml. Back up TradeMonitorData\\history.xml first.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 8),
            });

            var demoStatusLbl = new TextBlock
            {
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 6, 0, 0),
            };

            var seedBtn = new Button
            {
                Content             = "Seed Demo Data (Dec 2025 – Apr 2026)",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(80, 60, 120)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            // NOTE: live click (→ MeridianDevTools.SeedDemoData) is attached by the hub.
            devPanel.Children.Add(seedBtn);
            devPanel.Children.Add(demoStatusLbl);

            devPanel.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 16, 0, 12),
            });

            // ── V2 Engine Test Suite ──────────────────────────────────────────
            devPanel.Children.Add(new TextBlock
            {
                Text         = "Runs PsiEngineV2 against all acceptance scenarios. Does NOT touch the live engine, HUD, or baseline. Results written to Desktop\\PsiV2TestResults.txt.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 10),
            });

            var v2StatusLbl = new TextBlock
            {
                FontSize   = 11,
                FontFamily = Theme.Font,
                Foreground = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin     = new Thickness(0, 8, 0, 0),
            };

            var v2RunBtn = new Button
            {
                Content             = "Run V2 Engine Test Suite (S201–S255)",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(60, 80, 120)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            // NOTE: live click (→ MeridianDevTools.RunPsiV2Tests) is attached by the hub.
            devPanel.Children.Add(v2RunBtn);

            var v2OpenBtn = new Button
            {
                Content             = "Open PsiV2TestResults.txt",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(70, 70, 80)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
                Margin              = new Thickness(0, 8, 0, 0),
            };
            // NOTE: live click (→ open results file) is attached by the hub.
            devPanel.Children.Add(v2OpenBtn);
            devPanel.Children.Add(v2StatusLbl);

            // ── Guard Engine acceptance tests ──────────────────────────────────
            devPanel.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 16, 0, 12),
            });
            devPanel.Children.Add(new TextBlock
            {
                Text         = "Guard Rule Tests",
                FontSize     = 11,
                FontFamily   = Theme.Font,
                FontWeight   = FontWeights.SemiBold,
                Foreground   = FgPrimary,
                Margin       = new Thickness(0, 0, 0, 4),
            });
            devPanel.Children.Add(new TextBlock
            {
                Text         = "67 acceptance scenarios: conditions, cooldown, confirmation, pause " +
                               "state machine, persistence, MinLossUsd, ALL/ANY logic, RiskAlert, " +
                               "legacy Disconnect. Writes GuardTestResults.txt to Desktop.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 10),
            });

            var guardStatusLbl = new TextBlock
            {
                FontSize     = 11,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 8, 0, 0),
            };

            var guardRunBtn = new Button
            {
                Content             = "Run Guard Test Suite (G001–G067)",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(80, 60, 100)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            // NOTE: live click (→ MeridianDevTools.RunGuardTests) is attached by the hub.

            var guardOpenBtn = new Button
            {
                Content             = "Open GuardTestResults.txt",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(70, 70, 80)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
                Margin              = new Thickness(0, 8, 0, 0),
            };
            // NOTE: live click (→ open results file) is attached by the hub.
            devPanel.Children.Add(guardRunBtn);
            devPanel.Children.Add(guardOpenBtn);
            devPanel.Children.Add(guardStatusLbl);

            // State Integrity Tools
            devPanel.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 16, 0, 12),
            });
            devPanel.Children.Add(new TextBlock
            {
                Text       = "State Integrity Tools",
                FontSize   = 11,
                FontFamily = Theme.Font,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgHint,
                Margin     = new Thickness(0, 0, 0, 6),
            });
            devPanel.Children.Add(new TextBlock
            {
                Text         = "Replay diagnoses any past CSV log against the current build to surface state-tearing / lifecycle bugs that happened in that session. Fuzzer generates 1000 random NT8 event scenarios and asserts our state-machine invariants always hold. Both write detailed reports to your Desktop.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 10),
            });

            var integrityStatusLbl = new TextBlock
            {
                FontSize   = 11,
                FontFamily = Theme.Font,
                Foreground = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin     = new Thickness(0, 8, 0, 0),
            };

            var replayBtn = new Button
            {
                Content             = "Run Replay Harness on CSV log(s)…",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(60, 80, 120)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
            };
            // NOTE: live click (→ LogReplayHarness) is attached by the hub.
            devPanel.Children.Add(replayBtn);

            var fuzzBtn = new Button
            {
                Content             = "Run Property Fuzzer (1000 scenarios)",
                Padding             = new Thickness(14, 6, 14, 6),
                Background          = new SolidColorBrush(Color.FromRgb(70, 70, 80)),
                Foreground          = FgPrimary,
                BorderThickness     = new Thickness(0),
                FontFamily          = Theme.Font,
                FontSize            = 12,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = System.Windows.Input.Cursors.Hand,
                Margin              = new Thickness(0, 8, 0, 0),
            };
            // NOTE: live click (→ MeridianDevTools.RunPropertyFuzzer) is attached by the hub.
            devPanel.Children.Add(fuzzBtn);

            devPanel.Children.Add(integrityStatusLbl);
            stack.Children.Add(devPanel);

            scroll.Content = stack;
            return scroll;
        }

        // ── License page helpers (duplicated from MeridianDashboard) ──────────

        private static TextBlock MakeLicenseLabel(string text) => new TextBlock
        {
            Text       = text,
            FontSize   = 11,
            FontFamily = Theme.Font,
            FontWeight = FontWeights.SemiBold,
            Foreground = FgHint,
            Margin     = new Thickness(0, 0, 0, 2),
        };

        private static System.Windows.Controls.Button MakeLicenseButton(string label, bool accent = false)
        {
            Brush bg = accent ? Theme.AccentSolid : BgCard;
            Brush fg = accent ? Theme.AccentInk : FgPrimary;       // dark ink on the emerald — never white
            Brush bd = accent ? Theme.Tint(Theme.Accent, 64) : new SolidColorBrush(Color.FromArgb(60, 255, 255, 255));
            return new System.Windows.Controls.Button
            {
                Content          = label,
                FontSize         = 12,
                FontFamily       = Theme.Font,
                FontWeight       = FontWeights.SemiBold,
                Foreground       = fg,
                Cursor           = Cursors.Hand,
                FocusVisualStyle = null,
                Template         = Ui.FlatButtonTemplate(bg, bd, 6, 14, 7),
            };
        }
    }
}
