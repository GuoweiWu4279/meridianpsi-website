using System;
using System.IO;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Identity + activation state for the anonymized research-data program.
    ///
    /// CONSENT MODEL: consent is disclosed/given via the download page + Terms of Service on
    /// the website — NOT an in-app toggle. There is therefore no in-app opt-IN switch. An
    /// opt-OUT mechanism still exists (research_optout.dat) so an install can be excluded on
    /// request, honored without any UI.
    ///
    /// ACTIVE only when a backend endpoint + key are configured — baked into the shipped
    /// build via <see cref="DefaultEndpoint"/>/<see cref="DefaultKey"/> (single source), or
    /// dropped as research_endpoint.dat / research_key.dat — AND the install has not opted
    /// out. With NO endpoint configured the whole pipeline is fully INERT: nothing is
    /// recorded or transmitted. So dev builds, and any build shipped before an endpoint is
    /// set, collect absolutely nothing — flipping the program on is a one-line release step.
    ///
    /// Anonymization: the raw account name is stripped on upload (→ the install's random anon
    /// id); the uploaded payload is trade-activity + PSI signals + DERIVED account categories,
    /// keyed only to that random id — no name, account number, credentials, or balances.
    /// (Note: a stable per-install id is PSEUDONYMOUS, not strictly anonymous — word the
    /// public privacy promise accordingly.)
    /// </summary>
    internal static class ResearchData
    {
        // ── Release provisioning (single source of truth) ─────────────────────
        // Set these in the build you actually ship to start collecting. Leave EMPTY and the
        // entire pipeline stays inert. A research_endpoint.dat / research_key.dat file in the
        // data dir overrides the constant (so a build can be pointed without recompiling).
        internal const string DefaultEndpoint = "https://www.meridianpsi.com/api/research/ingest";
        internal const string DefaultKey      = "bf59aad006ef4d6200313302559b7c6890aa505ef910498e";

        private static string _dir;
        private static string _anonId;
        private static bool   _loaded;
        private static bool   _optedOut;        // research_optout.dat == "1"
        private static string _endpoint = "";
        private static string _key = "";

        public static void Init(string dataDir)
        {
            _dir = dataDir;
            _loaded = false;
            Load();
        }

        /// <summary>Stable random anonymous id — no PII. Created once per install.</summary>
        public static string AnonId   { get { EnsureLoaded(); return _anonId; } }
        public static string Endpoint { get { EnsureLoaded(); return _endpoint; } }
        public static string Key      { get { EnsureLoaded(); return _key; } }

        /// <summary>True if this install has opted out (research_optout.dat).</summary>
        public static bool OptedOut   { get { EnsureLoaded(); return _optedOut; } }

        /// <summary>
        /// Active when a backend endpoint + key are configured AND the install hasn't opted
        /// out. No endpoint → false → fully inert (records and uploads nothing).
        /// </summary>
        public static bool Enabled
        {
            get
            {
                EnsureLoaded();
                return !_optedOut
                    && !string.IsNullOrEmpty(_endpoint)
                    && !string.IsNullOrEmpty(_key)
                    && !string.IsNullOrEmpty(_anonId);
            }
        }

        /// <summary>Opt out (stop everything) or opt back in. Persisted; honored with no UI.</summary>
        public static void SetOptOut(bool optOut)
        {
            EnsureLoaded();
            _optedOut = optOut;
            TryWrite("research_optout.dat", optOut ? "1" : "0");
        }

        private static void EnsureLoaded() { if (!_loaded) Load(); }

        private static void Load()
        {
            _loaded = true;
            // Start from the build defaults each load so state reflects the current files.
            _endpoint = DefaultEndpoint;
            _key      = DefaultKey;
            _optedOut = false;
            try
            {
                if (string.IsNullOrEmpty(_dir)) return;

                // anonymous id — create once, persist
                string idPath = Path.Combine(_dir, "research_id.dat");
                if (File.Exists(idPath))
                    _anonId = File.ReadAllText(idPath).Trim();
                if (string.IsNullOrEmpty(_anonId))
                {
                    _anonId = Guid.NewGuid().ToString("N");
                    TryWrite("research_id.dat", _anonId);
                }

                string optPath = Path.Combine(_dir, "research_optout.dat");
                if (File.Exists(optPath))
                    _optedOut = File.ReadAllText(optPath).Trim() == "1";

                // endpoint / key — override the build default if a file is present + non-empty
                string epPath = Path.Combine(_dir, "research_endpoint.dat");
                if (File.Exists(epPath))
                {
                    var v = File.ReadAllText(epPath).Trim();
                    if (!string.IsNullOrEmpty(v)) _endpoint = v;
                }

                string keyPath = Path.Combine(_dir, "research_key.dat");
                if (File.Exists(keyPath))
                {
                    var v = File.ReadAllText(keyPath).Trim();
                    if (!string.IsNullOrEmpty(v)) _key = v;
                }
            }
            catch { /* never let research state affect the product */ }
        }

        private static void TryWrite(string name, string content)
        {
            try { if (!string.IsNullOrEmpty(_dir)) File.WriteAllText(Path.Combine(_dir, name), content); }
            catch { }
        }
    }
}
