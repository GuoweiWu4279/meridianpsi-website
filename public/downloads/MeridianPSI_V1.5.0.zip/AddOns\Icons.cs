using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Lucide line icons (the set shadcn/ui ships) as WPF stroke geometry. 24×24,
    /// stroke-based, round caps/joins — rendered via a Path with Stretch=Uniform so
    /// the same geometry scales to any size. PURE WPF (renders in the harness + NT8).
    ///
    /// Each Geometry is parsed once and frozen. If a path string were malformed it would
    /// throw here at static-init, so these are verified on the harness (icons.png) before
    /// being wired into any window.
    /// </summary>
    internal static class Icons
    {
        public static readonly Geometry Dashboard = G("M3 3h7v9h-7z M14 3h7v5h-7z M14 12h7v9h-7z M3 16h7v5h-7z");
        public static readonly Geometry Shield     = G("M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z");
        public static readonly Geometry Pen        = G("M12 20h9 M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z");
        public static readonly Geometry Chart      = G("M3 3v18h18 M19 9l-5 5-4-4-3 3");
        public static readonly Geometry Sparkles   = G("M9.94 14.06A2 2 0 0 0 8.5 12.62l-5.13-1.32a.5.5 0 0 1 0-.96L8.5 9.02a2 2 0 0 0 1.44-1.44l1.32-5.13a.5.5 0 0 1 .96 0l1.32 5.13a2 2 0 0 0 1.44 1.44l5.13 1.32a.5.5 0 0 1 0 .96l-5.13 1.32a2 2 0 0 0-1.44 1.44l-1.32 5.13a.5.5 0 0 1-.96 0z");
        public static readonly Geometry User       = G("M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2 M8 7a4 4 0 1 0 8 0a4 4 0 1 0-8 0");
        public static readonly Geometry Settings   = G("M12.2 2h-.4a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.4a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z M9 12a3 3 0 1 0 6 0a3 3 0 1 0-6 0");
        public static readonly Geometry Key        = G("M2.59 17.41A2 2 0 0 0 2 18.83V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.17a2 2 0 0 0 1.41-.59l.82-.81a6.5 6.5 0 1 0-4-4z");
        public static readonly Geometry Search     = G("M3 11a8 8 0 1 0 16 0a8 8 0 1 0-16 0 M21 21l-4.3-4.3");
        public static readonly Geometry Bell       = G("M10.27 21a2 2 0 0 0 3.46 0 M3.26 15.33A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.67C19.41 13.96 18 12.5 18 8A6 6 0 0 0 6 8c0 4.5-1.41 5.96-2.74 7.33z");
        public static readonly Geometry Download   = G("M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4 M7 10l5 5 5-5 M12 15V3");
        public static readonly Geometry ChevronDown = G("M6 9l6 6 6-6");
        public static readonly Geometry ArrowRight = G("M5 12h14 M12 5l7 7-7 7");
        public static readonly Geometry ArrowDown  = G("M12 5v14 M19 12l-7 7-7-7");
        public static readonly Geometry Star        = G("M11.5 2.3a.5.5 0 0 1 .96 0l2.4 5.07 5.32.78a.5.5 0 0 1 .3.9l-3.85 3.75.9 5.3a.5.5 0 0 1-.77.6L12 16.5l-4.76 2.5a.5.5 0 0 1-.77-.6l.9-5.3-3.85-3.75a.5.5 0 0 1 .3-.9l5.32-.78z");
        public static readonly Geometry AlertCircle = G("M12 2a10 10 0 1 0 0 20a10 10 0 1 0 0-20 M12 8v4 M12 16h.01");

        private static Geometry G(string d)
        {
            var g = Geometry.Parse(d);
            g.Freeze();
            return g;
        }

        /// <summary>A Path rendering of an icon geometry at the given size + stroke.</summary>
        public static Path Make(Geometry geo, double size, Brush stroke, double weight = 1.8)
        {
            return new Path
            {
                Data = geo,
                Stroke = stroke,
                StrokeThickness = weight,
                StrokeStartLineCap = PenLineCap.Round,
                StrokeEndLineCap = PenLineCap.Round,
                StrokeLineJoin = PenLineJoin.Round,
                Fill = null,
                Stretch = Stretch.Uniform,
                Width = size,
                Height = size,
                SnapsToDevicePixels = true,
            };
        }
    }
}
