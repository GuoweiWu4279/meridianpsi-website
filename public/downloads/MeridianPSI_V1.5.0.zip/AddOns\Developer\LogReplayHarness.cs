﻿#region Using declarations
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using NinjaTrader.Cbi;
#endregion

// =====================================================================
// LogReplayHarness — offline diagnosis tool.
//
// Purpose: take any "NinjaTrader Grid YYYY-MM-DD HH-MM XX.csv" log file
// and answer the question:
//
//   "If the user re-ran exactly this trading session, would the current
//    MeridianPSI build still produce the same bugs?"
//
// How it works:
//   1. Parse the CSV in chronological order, extracting:
//        • Position events  (Add / Update / Remove with dir + qty)
//        • Execution events (fill price, qty, side)
//        • The NinjaScript log lines we previously emitted, so we can
//          DIFF the historical behaviour against what a fresh replay
//          would now produce.
//   2. Drive an in-process StandalonePositionSimulator through the
//      events.  This simulator implements EXACTLY the same lifecycle
//      edge classification as MeridianPSI.ReconcileLifecycleEdgeAtomic
//      — kept intentionally as a small mirror so the replay can run
//      without an NT8 Account / engine instance.  Any divergence
//      between this and the live router is a bug surface and will be
//      detected by the IntegrityCheck assertions on every step.
//   3. After each event, build an IntegritySnapshot (from the simulator's
//      internal state plus the most-recent Position event as ground
//      truth) and run IntegrityCheck.Run.
//   4. Emit a ReplayResults.txt with:
//        a. Chronological timeline of edges
//        b. Per-step IntegrityCheck violations
//        c. A summary table: total edges, total violations by Group
//
// Design constraints:
//   • Pure offline.  No NinjaTrader.Cbi.Account, no engine instance,
//     no UI dispatcher.  Runnable from the License → Developer Tools
//     button or from a standalone test harness.
//   • Parsing is regex-based, intentionally robust to unknown columns
//     (NT8 changes the log format occasionally).
//   • Duplicate events (NT8 sometimes re-emits identical Position lines
//     during reconnection) are deduped by (Time, Account, Instrument,
//     Operation, Direction, Quantity) tuple.
//   • Time precision: the CSV gives us seconds.  Within-second event
//     ordering is taken from the file's row order (post-reverse).
// =====================================================================

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// One Position event parsed out of an NT8 CSV log line.
    /// </summary>
    public sealed class ParsedPositionEvent
    {
        public DateTime       Time;
        public string         Account;
        public string         Instrument;          // master name (no contract suffix)
        public MarketPosition Direction;
        public double         Quantity;
        public double         AveragePrice;
        public string         Operation;           // "Add" / "Update" / "Remove"
        public string         RawLine;
    }

    /// <summary>
    /// One Execution event parsed out of an NT8 CSV log line.  Currently
    /// captured for richness of the report but not yet driven through the
    /// simulator (the simulator focuses on lifecycle edges, which are
    /// produced by Position events alone).
    /// </summary>
    public sealed class ParsedExecutionEvent
    {
        public DateTime       Time;
        public string         ExecutionId;
        public string         OrderId;
        public string         Account;
        public string         Instrument;
        public MarketPosition FillSide;     // Long / Short — direction of the fill
        public double         Price;
        public double         Quantity;
        public double         Pnl;          // realized PnL for this fill (0 for entry fills; set by fuzzer scenarios)
        public string         RawLine;
    }

    /// <summary>
    /// All events parsed out of one CSV file, in chronological order.
    /// </summary>
    public sealed class ParsedReplayLog
    {
        public string                       FilePath;
        public List<ParsedPositionEvent>    Positions   = new List<ParsedPositionEvent>();
        public List<ParsedExecutionEvent>   Executions  = new List<ParsedExecutionEvent>();
        public int                          TotalRows;
        public int                          UnparseableRows;
    }

    /// <summary>
    /// One step of the replay timeline: a Position event followed by the
    /// edge our simulator deduced and the IntegrityCheck verdict immediately
    /// after.
    /// </summary>
    public sealed class ReplayStep
    {
        public ParsedPositionEvent              Event;
        public string                           DerivedEdge;          // ADD / REMOVE / REVERSAL / UPDATE / IDLE
        public List<IntegrityViolation>         Violations;
    }

    /// <summary>
    /// Final replay outcome.  Self-describing and serialisable as plain text
    /// for ReplayResults.txt.
    /// </summary>
    public sealed class ReplayReport
    {
        public string                FilePath;
        public DateTime              StartedUtc;
        public DateTime              FinishedUtc;
        public int                   TotalPositionEvents;
        public int                   TotalExecutionEvents;
        public int                   TotalSteps;
        public int                   TotalViolations;
        // HUD display invariants (Bug-1 / UI completeness checks)
        public int                   ExpectedTradeCount;   // REMOVE edges with OriginObserved=true
        public int                   ActualTradeCount;     // sim.TotalTrades at end of replay
        public bool                  TradeCountMatches => ExpectedTradeCount == ActualTradeCount;
        public Dictionary<string, int> ViolationsByCode = new Dictionary<string, int>();
        public List<ReplayStep>      Steps = new List<ReplayStep>();
        public List<string>          Notes = new List<string>();

        public string ToText()
        {
            var sb = new StringBuilder();
            sb.Append("==================== REPLAY REPORT ====================\n");
            sb.Append("File:        ").Append(FilePath).Append('\n');
            sb.Append("Started:     ").Append(StartedUtc.ToString("o")).Append('\n');
            sb.Append("Finished:    ").Append(FinishedUtc.ToString("o")).Append('\n');
            sb.Append("Position events: ").Append(TotalPositionEvents).Append('\n');
            sb.Append("Execution events: ").Append(TotalExecutionEvents).Append('\n');
            sb.Append("Steps:           ").Append(TotalSteps).Append('\n');
            sb.Append("Violations:      ").Append(TotalViolations).Append('\n');
            sb.Append("Expected trades: ").Append(ExpectedTradeCount).Append('\n');
            sb.Append("Actual trades:   ").Append(ActualTradeCount);
            sb.Append(TradeCountMatches ? "  ✓ HUD trade count correct\n" : "  ✗ HUD TRADE COUNT MISMATCH\n");
            sb.Append("\n--- Violations by code ---\n");
            foreach (var kv in ViolationsByCode.OrderByDescending(x => x.Value))
                sb.Append("  ").Append(kv.Key.PadRight(40)).Append(kv.Value).Append('\n');

            sb.Append("\n--- Notes ---\n");
            foreach (var n in Notes) sb.Append("  ").Append(n).Append('\n');

            sb.Append("\n--- Timeline ---\n");
            foreach (var st in Steps)
            {
                sb.Append("[").Append(st.Event.Time.ToString("HH:mm:ss")).Append("] ");
                sb.Append(st.Event.Account).Append("::").Append(st.Event.Instrument).Append("  ");
                sb.Append("dir=").Append(st.Event.Direction).Append(" qty=").Append(st.Event.Quantity);
                sb.Append("  edge=").Append(st.DerivedEdge);
                if (st.Violations != null && st.Violations.Count > 0)
                {
                    sb.Append("  VIOLATIONS=").Append(st.Violations.Count);
                    foreach (var v in st.Violations)
                        sb.Append("\n      ").Append(v);
                }
                sb.Append('\n');
            }

            sb.Append("\n=========================== END ===========================\n");
            return sb.ToString();
        }
    }

    /// <summary>
    /// Standalone CSV parser + replay engine.  Stateless static API; all
    /// state lives on the StandalonePositionSimulator instance.
    /// </summary>
    public static class LogReplayHarness
    {
        // ── Regex compiled once for performance.  All patterns intentionally
        //    permissive about column ordering — NT8 sometimes adds new keys.
        private static readonly Regex RxCsvRow = new Regex(
            @"^(?<time>[^,]+),(?<cat>[^,]+),(?<msg>.+?),?$", RegexOptions.Compiled);

        private static readonly Regex RxKeyValue = new Regex(
            @"(?<k>\w[\w ]*)=(?:'(?<vq>[^']*)'|(?<v>[^\s,]+))", RegexOptions.Compiled);

        // ─── Public entry points ─────────────────────────────────────────

        /// <summary>
        /// Parse a NinjaTrader Grid CSV log file.  Returns events in
        /// chronological (oldest-first) order.  Errors are tolerated row-by-row.
        /// </summary>
        public static ParsedReplayLog Parse(string csvPath)
        {
            var log = new ParsedReplayLog { FilePath = csvPath };
            if (!File.Exists(csvPath)) return log;

            var rawLines = new List<(DateTime t, string cat, string msg)>();

            using (var sr = new StreamReader(csvPath))
            {
                string header = sr.ReadLine(); // skip "Time,Category,Message,"
                _ = header;
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    log.TotalRows++;
                    var m = RxCsvRow.Match(line);
                    if (!m.Success) { log.UnparseableRows++; continue; }
                    var timeStr = m.Groups["time"].Value.Trim();
                    var cat     = m.Groups["cat"].Value.Trim();
                    var msg     = m.Groups["msg"].Value;
                    if (!DateTime.TryParse(timeStr, CultureInfo.InvariantCulture,
                                            DateTimeStyles.AssumeLocal, out DateTime t))
                    {
                        log.UnparseableRows++;
                        continue;
                    }
                    rawLines.Add((t, cat, msg));
                }
            }

            // Reverse to chronological order (CSV is newest-first by row).
            // Within the same timestamp, preserve original order; doing so
            // matches NT8's natural per-second ordering when re-reversed.
            rawLines.Reverse();

            // Dedup within (time, account, instrument, operation, direction, qty).
            // NT8 sometimes emits identical Position lines during reconnects.
            var seenPos = new HashSet<string>(StringComparer.Ordinal);
            var seenExe = new HashSet<string>(StringComparer.Ordinal);

            foreach (var row in rawLines)
            {
                if (string.Equals(row.cat, "Position", StringComparison.OrdinalIgnoreCase))
                {
                    var ev = ParsePositionLine(row.t, row.msg);
                    if (ev == null) continue;
                    string dedupKey = string.Format("{0:o}|{1}|{2}|{3}|{4}|{5}",
                        ev.Time, ev.Account, ev.Instrument, ev.Operation, ev.Direction, ev.Quantity);
                    if (!seenPos.Add(dedupKey)) continue;
                    log.Positions.Add(ev);
                }
                else if (string.Equals(row.cat, "Execution", StringComparison.OrdinalIgnoreCase))
                {
                    var ex = ParseExecutionLine(row.t, row.msg);
                    if (ex == null) continue;
                    // Dedup on ExecutionId if available; otherwise full-tuple.
                    string dedupKey = !string.IsNullOrEmpty(ex.ExecutionId)
                        ? ex.ExecutionId
                        : string.Format("{0:o}|{1}|{2}|{3}|{4}",
                            ex.Time, ex.Account, ex.Instrument, ex.FillSide, ex.Quantity);
                    if (!seenExe.Add(dedupKey)) continue;
                    log.Executions.Add(ex);
                }
            }
            return log;
        }

        /// <summary>
        /// Run the full replay against a parsed log.  Position and Execution
        /// events are interleaved by timestamp, with Position events before
        /// Execution events at the same second (matching NT8's documented order
        /// for close fills).  IntegrityCheck runs after each Position event.
        /// Execution events are processed silently to maintain shadow state
        /// and consume bridge dicts — exactly as OnExecutionUpdate does in
        /// production — so that IntegrityCheck results reflect real post-fill
        /// state, not a position-event-only approximation.
        /// </summary>
        public static ReplayReport Run(ParsedReplayLog parsed)
        {
            var rep = new ReplayReport
            {
                FilePath              = parsed.FilePath,
                StartedUtc            = DateTime.UtcNow,
                TotalPositionEvents   = parsed.Positions.Count,
                TotalExecutionEvents  = parsed.Executions.Count,
            };

            if (parsed.Positions.Count == 0)
            {
                rep.Notes.Add("No Position events parsed — check CSV format.");
                rep.FinishedUtc = DateTime.UtcNow;
                return rep;
            }

            var sim = new StandalonePositionSimulator();
            sim.SubscriptionTimeUtc = parsed.Positions[0].Time;

            // ── Build merged event list ───────────────────────────────────
            // typeOrd: Position=0 fires before Execution=1 at equal timestamps.
            // This matches NT8's documented ordering for close fills
            // (OnPositionUpdate fires before OnExecutionUpdate).
            const int POS = 0, EXE = 1;
            var merged = new List<(DateTime t, int typeOrd, int srcIdx, object ev)>(
                parsed.Positions.Count + parsed.Executions.Count);

            for (int i = 0; i < parsed.Positions.Count; i++)
                merged.Add((parsed.Positions[i].Time, POS, i, parsed.Positions[i]));
            for (int i = 0; i < parsed.Executions.Count; i++)
                merged.Add((parsed.Executions[i].Time, EXE, i, parsed.Executions[i]));

            merged.Sort((a, b) =>
            {
                int tc = a.t.CompareTo(b.t);
                if (tc != 0) return tc;
                int oc = a.typeOrd.CompareTo(b.typeOrd); // Position before Execution
                if (oc != 0) return oc;
                return a.srcIdx.CompareTo(b.srcIdx);      // preserve original row order
            });

            // ── Process events ────────────────────────────────────────────
            foreach (var item in merged)
            {
                if (item.typeOrd == EXE)
                {
                    // Execution events update shadow state and consume bridge dicts.
                    // They do NOT generate a step in the report — their effect is
                    // visible on the NEXT position event's IntegrityCheck result.
                    var exEv  = (ParsedExecutionEvent)item.ev;
                    string ek = exEv.Account + "::" + exEv.Instrument;
                    sim.ApplyExecutionEvent(ek, exEv);
                    continue;
                }

                var ev     = (ParsedPositionEvent)item.ev;
                string posKey = ev.Account + "::" + ev.Instrument;

                // Pre-edge: capture lifecycle state before applying, so we can
                // determine OriginObserved for the REMOVE case (trade counter check).
                sim.Lifecycles.TryGetValue(posKey, out var preLifeForCount);

                string edge   = sim.ApplyPositionEvent(posKey, ev);

                // HUD trade count invariant: count every lifecycle REMOVE (or REVERSAL)
                // whose retiring lifecycle was observed (post-bootstrap).  This is the
                // ground truth for what the HUD's Trades counter should show.
                if ((edge == "REMOVE" || edge == "REVERSAL") &&
                    preLifeForCount != null && preLifeForCount.OriginObserved)
                    rep.ExpectedTradeCount++;

                // Build NT8 truth from THIS event (the event represents what
                // NT8 just told us authoritatively).  We do not preserve other
                // posKeys' truth here — the test is "given just this event,
                // is our internal state consistent with what NT8 reported?"
                var nt8Truth = new Dictionary<string, Nt8PositionSnap>();
                if (ev.Direction != MarketPosition.Flat)
                {
                    nt8Truth[posKey] = new Nt8PositionSnap
                    {
                        AccountName    = ev.Account,
                        InstrumentName = ev.Instrument,
                        Direction      = ev.Direction,
                        Quantity       = ev.Quantity,
                        AveragePrice   = ev.AveragePrice,
                    };
                }

                // Carry over any OTHER posKeys our simulator believes are open
                // but that this event didn't address (multi-instrument session).
                foreach (var kv in sim.Lifecycles)
                {
                    if (kv.Key == posKey) continue;
                    if (!nt8Truth.ContainsKey(kv.Key))
                    {
                        nt8Truth[kv.Key] = new Nt8PositionSnap
                        {
                            AccountName    = ParseAccount(kv.Key),
                            InstrumentName = ParseInstrument(kv.Key),
                            Direction      = kv.Value.Direction,
                            Quantity       = kv.Value.MaxQtySeen,
                            AveragePrice   = 0,
                        };
                    }
                }

                IntegritySnapshot snap = sim.BuildSnapshot(nt8Truth, inBootstrap: false);
                List<IntegrityViolation> violations = IntegrityCheck.Run(snap);

                rep.Steps.Add(new ReplayStep
                {
                    Event       = ev,
                    DerivedEdge = edge,
                    Violations  = violations,
                });
                rep.TotalSteps++;
                rep.TotalViolations += violations.Count;

                foreach (var v in violations)
                {
                    string code = v.Code.ToString();
                    rep.ViolationsByCode.TryGetValue(code, out var c);
                    rep.ViolationsByCode[code] = c + 1;
                }
            }

            rep.FinishedUtc = DateTime.UtcNow;
            rep.ActualTradeCount = sim.TotalTrades;
            rep.Notes.Add(string.Format("Parsed {0}/{1} CSV rows ({2} unparseable).",
                parsed.TotalRows - parsed.UnparseableRows, parsed.TotalRows, parsed.UnparseableRows));
            rep.Notes.Add(string.Format("StandalonePositionSimulator: final lifecycles open={0}",
                sim.Lifecycles.Count));
            rep.Notes.Add(string.Format("Execution events interleaved: {0} position + {1} execution = {2} total.",
                parsed.Positions.Count, parsed.Executions.Count,
                parsed.Positions.Count + parsed.Executions.Count));
            if (!rep.TradeCountMatches)
                rep.Notes.Add(string.Format(
                    "** HUD TRADE COUNT MISMATCH: expected={0} actual={1}. Lifecycle retirement is dropping trades.",
                    rep.ExpectedTradeCount, rep.ActualTradeCount));
            return rep;
        }

        /// <summary>
        /// One-shot helper.  Parse + run + write report to file.  Returns
        /// the report and the path of the written results file.
        /// </summary>
        public static (ReplayReport report, string resultsPath) RunFile(string csvPath, string outDir)
        {
            var parsed = Parse(csvPath);
            var report = Run(parsed);
            string fname = "ReplayResults_" + Path.GetFileNameWithoutExtension(csvPath) + ".txt";
            string outPath = Path.Combine(outDir ?? Path.GetTempPath(), fname);
            File.WriteAllText(outPath, report.ToText());
            return (report, outPath);
        }

        // ─── Parsing helpers ─────────────────────────────────────────────

        private static string ParseAccount(string posKey)
        {
            int idx = posKey.IndexOf("::", StringComparison.Ordinal);
            return idx < 0 ? posKey : posKey.Substring(0, idx);
        }

        private static string ParseInstrument(string posKey)
        {
            int idx = posKey.IndexOf("::", StringComparison.Ordinal);
            return idx < 0 ? "" : posKey.Substring(idx + 2);
        }

        private static ParsedPositionEvent ParsePositionLine(DateTime t, string msg)
        {
            // Example:
            //   Instrument='MNQ 06-26' Account='Playback101' Average price=26379.75 Quantity=5 Market position=Short Operation=Update
            var fields = ExtractKeyValues(msg);
            if (fields.Count == 0) return null;
            string instr = GetField(fields, "Instrument");
            string acct  = GetField(fields, "Account");
            string mp    = GetField(fields, "Market position");
            string op    = GetField(fields, "Operation");
            string qStr  = GetField(fields, "Quantity");
            string apStr = GetField(fields, "Average price");

            if (string.IsNullOrEmpty(instr) || string.IsNullOrEmpty(acct)) return null;
            MarketPosition dir = ParseMarketPosition(mp);
            double qty   = ParseDoubleSafe(qStr);
            double avgPx = ParseDoubleSafe(apStr);

            // Strip contract suffix from instrument: "MNQ 06-26" → "MNQ"
            string instrMaster = instr.Split(' ')[0];

            return new ParsedPositionEvent
            {
                Time         = t,
                Account      = acct,
                Instrument   = instrMaster,
                Direction    = dir,
                Quantity     = qty,
                AveragePrice = avgPx,
                Operation    = NormalizeOperation(op),
                RawLine      = msg,
            };
        }

        private static ParsedExecutionEvent ParseExecutionLine(DateTime t, string msg)
        {
            var fields = ExtractKeyValues(msg);
            if (fields.Count == 0) return null;
            string ex   = GetField(fields, "Execution");
            string ord  = GetField(fields, "Order");
            string acct = GetField(fields, "Account");
            string instr= GetField(fields, "Instrument");
            string mp   = GetField(fields, "Market position");
            string price= GetField(fields, "Price");
            string qStr = GetField(fields, "Quantity");
            if (string.IsNullOrEmpty(acct) || string.IsNullOrEmpty(instr)) return null;

            string instrMaster = instr.Split(' ')[0];
            return new ParsedExecutionEvent
            {
                Time        = t,
                ExecutionId = ex,
                OrderId     = ord,
                Account     = acct,
                Instrument  = instrMaster,
                FillSide    = ParseMarketPosition(mp),
                Price       = ParseDoubleSafe(price),
                Quantity    = ParseDoubleSafe(qStr),
                RawLine     = msg,
            };
        }

        private static Dictionary<string, string> ExtractKeyValues(string msg)
        {
            var d = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            foreach (Match m in RxKeyValue.Matches(msg))
            {
                string k = m.Groups["k"].Value.Trim();
                string v = m.Groups["vq"].Success ? m.Groups["vq"].Value : m.Groups["v"].Value;
                d[k] = v;
            }
            return d;
        }

        private static string GetField(Dictionary<string, string> d, string key)
        {
            return d.TryGetValue(key, out var v) ? v : null;
        }

        private static MarketPosition ParseMarketPosition(string s)
        {
            if (string.IsNullOrEmpty(s)) return MarketPosition.Flat;
            if (string.Equals(s, "Long", StringComparison.OrdinalIgnoreCase))
                return MarketPosition.Long;
            if (string.Equals(s, "Short", StringComparison.OrdinalIgnoreCase))
                return MarketPosition.Short;
            return MarketPosition.Flat;
        }

        private static double ParseDoubleSafe(string s)
        {
            if (string.IsNullOrEmpty(s)) return 0;
            if (double.TryParse(s, NumberStyles.Any, CultureInfo.InvariantCulture, out var v))
                return v;
            return 0;
        }

        private static string NormalizeOperation(string op)
        {
            if (string.IsNullOrEmpty(op)) return "Unknown";
            // NT8 emits "Add" / "Update" / "Remove" but historical logs sometimes
            // use "Operation_Add".  Strip prefix.
            const string pre = "Operation_";
            if (op.StartsWith(pre, StringComparison.OrdinalIgnoreCase))
                op = op.Substring(pre.Length);
            return op;
        }
    }

    /// <summary>
    /// Mirrors MeridianPSI.ReconcileLifecycleEdgeAtomic in pure C#, no NT8
    /// dependencies.  Used by the replay harness AND the property fuzzer to
    /// drive the same lifecycle edge logic in an isolated test environment.
    /// </summary>
    // =====================================================================
    // SimLifecycle — the per-position object the simulator uses to mirror
    // PositionLifecycle in MeridianPSI.cs (new lifecycle-centric arch).
    // =====================================================================
    public sealed class SimLifecycle
    {
        public Guid           LifecycleId;
        public DateTime       EntryTime;
        public double         MaxQtySeen;
        public bool           OriginObserved;
        public MarketPosition Direction;
        // trade-recording state
        public double         AccumulatedPnl;
        public int            QtyAtLastScaleIn;
        public int            PostLastScaleInCloseQty;
        public bool           IsRemoved;
        public bool           Recorded;
        public DateTime       LastCloseFillTime;

        public LifecycleSnap  ToSnap() => new LifecycleSnap
        {
            LifecycleId    = LifecycleId,
            EntryTime      = EntryTime,
            MaxQtySeen     = MaxQtySeen,
            OriginObserved = OriginObserved,
            Direction      = Direction,
        };
        public RetiringLifecycleSnap ToRetiringSnap() => new RetiringLifecycleSnap
        {
            LifecycleId             = LifecycleId,
            EntryTime               = EntryTime,
            Direction               = Direction,
            OriginObserved          = OriginObserved,
            IsRemoved               = IsRemoved,
            Recorded                = Recorded,
            AccumulatedPnl          = AccumulatedPnl,
            QtyAtLastScaleIn        = QtyAtLastScaleIn,
            PostLastScaleInCloseQty = PostLastScaleInCloseQty,
            LastCloseFillTime       = LastCloseFillTime,
        };
    }

    // =====================================================================
    // StandalonePositionSimulator
    //
    // Mirrors ReconcileLifecycleEdgeAtomic + TryRecordTrade + OnExecutionUpdate
    // using the NEW lifecycle-centric architecture (post-refactor).
    //
    // Design invariants (same as MeridianPSI):
    //  • TotalTrades is incremented ONLY by TryRecordTrade.
    //  • TryRecordTrade is called from REMOVE/REVERSAL and from ApplyExecutionEvent.
    //  • The three gates in TryRecordTrade (Recorded, IsRemoved, fills-gate) make
    //    all calls idempotent — no double-counting is structurally possible.
    //  • _retiringLifecycles holds every lifecycle between IsRemoved=true and
    //    Recorded=true.  A lifecycle is never lost.
    // =====================================================================
    public sealed class StandalonePositionSimulator
    {
        public DateTime SubscriptionTimeUtc;
        public TimeSpan BootstrapWindow = TimeSpan.FromSeconds(2.0);

        // Active lifecycles (position currently open)
        public Dictionary<string, SimLifecycle>   Lifecycles          = new Dictionary<string, SimLifecycle>();
        // Retiring lifecycles (between REMOVE and TryRecordTrade completing)
        public Dictionary<string, SimLifecycle>   RetiringLifecycles  = new Dictionary<string, SimLifecycle>();

        // Shadow state — PSI-cache only; NOT used for recording decisions
        public Dictionary<string, double>          PositionQuantities  = new Dictionary<string, double>();
        public Dictionary<string, MarketPosition>  PositionDirections  = new Dictionary<string, MarketPosition>();
        public Dictionary<string, DateTime>        PositionEntryTimes  = new Dictionary<string, DateTime>();
        public Dictionary<string, double>          PositionEntryPrices = new Dictionary<string, double>();
        public Dictionary<string, double>          PositionMinPnl      = new Dictionary<string, double>();

        public int TotalTrades;
        public int SessionEntryCount;

        // ── TryRecordTrade — the ONLY function that increments TotalTrades ──────
        // Mirror of MeridianPSI.TryRecordTrade.
        public string TryRecordTrade(SimLifecycle lc)
        {
            if (lc.Recorded)                                        return "SKIP_ALREADY_RECORDED";
            if (!lc.IsRemoved)                                      return "SKIP_NOT_REMOVED";
            if (lc.PostLastScaleInCloseQty < lc.QtyAtLastScaleIn)  return "SKIP_FILLS_PENDING";

            lc.Recorded = true;
            RetiringLifecycles.Remove(lc.LifecycleId.ToString()); // keyed by posKey in prod; keyed by posKey here too
            // Remove from RetiringLifecycles by posKey — do a linear scan since we don't store posKey on lifecycle
            // (In practice the caller always has posKey; use the helper below.)
            if (!lc.OriginObserved) return "SKIP_BOOTSTRAP_GHOST";

            TotalTrades++;
            return "RECORDED";
        }

        // Overload that also cleans up the RetiringLifecycles dict by posKey.
        public string TryRecordTrade(string posKey, SimLifecycle lc)
        {
            if (lc.Recorded)                                        return "SKIP_ALREADY_RECORDED";
            if (!lc.IsRemoved)                                      return "SKIP_NOT_REMOVED";
            if (lc.PostLastScaleInCloseQty < lc.QtyAtLastScaleIn)  return "SKIP_FILLS_PENDING";

            lc.Recorded = true;
            RetiringLifecycles.Remove(posKey);
            if (!lc.OriginObserved) return "SKIP_BOOTSTRAP_GHOST";

            TotalTrades++;
            return "RECORDED";
        }

        // ── ApplyPositionEvent — mirrors ReconcileLifecycleEdgeAtomic ────────────
        public string ApplyPositionEvent(string posKey, ParsedPositionEvent ev)
        {
            MarketPosition postDir = ev.Direction;
            double         postQty = ev.Quantity;

            SimLifecycle existing;
            bool hadLife = Lifecycles.TryGetValue(posKey, out existing);

            // (1) no lifecycle & flat
            if (!hadLife && postDir == MarketPosition.Flat) return "IDLE";

            // (2) ADD — new position opened
            if (!hadLife)
            {
                bool observed = (ev.Time - SubscriptionTimeUtc) > BootstrapWindow;
                var life = new SimLifecycle
                {
                    LifecycleId      = Guid.NewGuid(),
                    EntryTime        = ev.Time,
                    MaxQtySeen       = postQty,
                    OriginObserved   = observed,
                    Direction        = postDir,
                    QtyAtLastScaleIn = (int)postQty,
                    PostLastScaleInCloseQty = 0,
                };
                Lifecycles[posKey] = life;
                // Clear any stale retiring entry from a previous trade on this posKey
                RetiringLifecycles.Remove(posKey);
                // Seed shadow state so IntegrityCheck A-group doesn't fire on the ADD event
                PositionQuantities[posKey] = postQty;
                PositionDirections[posKey] = postDir;
                if (observed) SessionEntryCount++;
                return "ADD";
            }

            // (3) REMOVE — position went flat
            if (postDir == MarketPosition.Flat)
            {
                existing.IsRemoved = true;
                RetiringLifecycles[posKey] = existing;
                Lifecycles.Remove(posKey);
                TryRecordTrade(posKey, existing);  // Path B: fills may already be in AccumulatedPnl
                return "REMOVE";
            }

            // (4) REVERSAL — direction flipped (no flat in between)
            if (postDir != existing.Direction)
            {
                existing.IsRemoved = true;
                RetiringLifecycles[posKey] = existing;
                Lifecycles.Remove(posKey);
                TryRecordTrade(posKey, existing);

                bool newObs = (ev.Time - SubscriptionTimeUtc) > BootstrapWindow;
                var newLife = new SimLifecycle
                {
                    LifecycleId      = Guid.NewGuid(),
                    EntryTime        = ev.Time,
                    MaxQtySeen       = postQty,
                    OriginObserved   = newObs,
                    Direction        = postDir,
                    QtyAtLastScaleIn = (int)postQty,
                    PostLastScaleInCloseQty = 0,
                };
                Lifecycles[posKey] = newLife;
                PositionQuantities[posKey] = postQty;
                PositionDirections[posKey] = postDir;
                if (newObs) SessionEntryCount++;
                return "REVERSAL";
            }

            // (5) UPDATE — same direction; track scale-in vs scale-out
            if (postQty > existing.MaxQtySeen)
            {
                // Scale-in: reset the close-fill gate for the new, larger batch
                existing.MaxQtySeen              = postQty;
                existing.QtyAtLastScaleIn        = (int)postQty;
                existing.PostLastScaleInCloseQty = 0;
            }
            else
            {
                existing.MaxQtySeen = Math.Max(existing.MaxQtySeen, postQty);
            }
            PositionQuantities[posKey] = postQty;
            PositionDirections[posKey] = postDir;
            return "UPDATE";
        }

        // ── ApplyExecutionEvent — mirrors OnExecutionUpdate close-fill path ───────
        // Returns a label describing what happened.
        public string ApplyExecutionEvent(string posKey, ParsedExecutionEvent ev)
        {
            double fillQty = ev.Quantity;
            if (fillQty <= 0) return "SKIP_ZERO_QTY";

            MarketPosition fillSide = ev.FillSide;

            // ── RETIRING-FIRST: if this posKey has a retiring lifecycle, this is
            // definitively a close fill for it regardless of shadow state.
            // This is the Path A case (fills arrive after REMOVE).
            SimLifecycle retiring;
            if (RetiringLifecycles.TryGetValue(posKey, out retiring) && retiring != null && !retiring.Recorded)
            {
                retiring.AccumulatedPnl           += ev.Pnl;
                retiring.PostLastScaleInCloseQty  += (int)fillQty;
                retiring.LastCloseFillTime         = ev.Time;
                TryRecordTrade(posKey, retiring);
                // Shadow cleanup after a flat close (no new lifecycle yet)
                if (!Lifecycles.ContainsKey(posKey))
                {
                    PositionQuantities.Remove(posKey);
                    PositionDirections.Remove(posKey);
                }
                return "EXEC_CLOSE_RETIRING";
            }

            // ── ACTIVE LIFECYCLE: check if this is a scale-out or entry fill ────
            SimLifecycle active;
            bool hadActive = Lifecycles.TryGetValue(posKey, out active);

            PositionQuantities.TryGetValue(posKey, out double currentQty);
            PositionDirections.TryGetValue(posKey, out var shadowDir);
            bool shadowIsFlat = currentQty <= 0;

            if (shadowIsFlat || !hadActive)
            {
                // Entry fill: opens a new position in shadow
                PositionQuantities[posKey] = fillQty;
                PositionDirections[posKey] = fillSide;
                if (hadActive && active.EntryTime == DateTime.MinValue)
                    active.EntryTime = ev.Time;
                return "EXEC_ENTRY";
            }

            bool fillMatchesDir = (fillSide == shadowDir);
            if (fillMatchesDir)
            {
                // Add-on entry fill (scale-in or multi-fill order)
                PositionQuantities[posKey] = currentQty + fillQty;
                return "EXEC_ENTRY_ADDON";
            }

            // Closing fill against an active lifecycle (Path B: REMOVE not yet fired)
            if (hadActive)
            {
                active.AccumulatedPnl          += ev.Pnl;
                active.PostLastScaleInCloseQty += (int)fillQty;
                active.LastCloseFillTime        = ev.Time;
                // TryRecordTrade will be a no-op here (IsRemoved=false) — that's correct:
                // the trade is not complete until REMOVE fires.
            }

            double remaining = currentQty - fillQty;
            if (remaining <= 0)
            {
                PositionQuantities.Remove(posKey);
                PositionDirections.Remove(posKey);
                return "EXEC_CLOSE_FULL";
            }
            PositionQuantities[posKey] = remaining;
            return "EXEC_CLOSE_PARTIAL";
        }

        // ── BuildSnapshot — for IntegrityCheck.Run ───────────────────────────────
        public IntegritySnapshot BuildSnapshot(
            Dictionary<string, Nt8PositionSnap> nt8Truth, bool inBootstrap)
        {
            var lifeSnaps = new Dictionary<string, LifecycleSnap>();
            foreach (var kv in Lifecycles)
                lifeSnaps[kv.Key] = kv.Value.ToSnap();

            var retiringSnaps = new Dictionary<string, RetiringLifecycleSnap>();
            foreach (var kv in RetiringLifecycles)
                retiringSnaps[kv.Key] = kv.Value.ToRetiringSnap();

            var emptyBool   = new Dictionary<string, bool>();
            var emptyDouble = new Dictionary<string, double>();

            return new IntegritySnapshot
            {
                SnapshotTime                = DateTime.UtcNow,
                PositionQuantities          = new Dictionary<string, double>(PositionQuantities),
                PositionDirections          = new Dictionary<string, MarketPosition>(PositionDirections),
                Lifecycles                  = lifeSnaps,
                RetiringLifecycles          = retiringSnaps,
                PosOriginObserved           = emptyBool,
                ReversalCloseOriginObserved = emptyBool,
                FlatPending                 = emptyBool,
                PendingPartialPnl           = emptyDouble,
                PendingPartialQty           = emptyDouble,
                PositionEntryTimes          = new Dictionary<string, DateTime>(PositionEntryTimes),
                PositionEntryPrices         = new Dictionary<string, double>(PositionEntryPrices),
                PositionMinPnl              = new Dictionary<string, double>(PositionMinPnl),
                Nt8Positions                = nt8Truth,
                TotalTrades                 = TotalTrades,
                SessionEntryCount           = SessionEntryCount,
                InBootstrapWindow           = inBootstrap,
            };
        }

        // ── Self-healing helpers — mirrors IntegrityCheck B1/B3 repair ───────────

        /// <summary>
        /// Simulate IntegrityCheck B1 repair: NT8 says flat but lifecycle is still
        /// active (missed Remove).  Sets IsRemoved=true, moves to RetiringLifecycles,
        /// calls TryRecordTrade.
        /// </summary>
        public string SimulateB1MissedRemove(string posKey)
        {
            SimLifecycle life;
            if (!Lifecycles.TryGetValue(posKey, out life)) return "NO_ACTIVE_LIFECYCLE";
            life.IsRemoved = true;
            RetiringLifecycles[posKey] = life;
            Lifecycles.Remove(posKey);
            return TryRecordTrade(posKey, life);
        }

        /// <summary>
        /// Simulate IntegrityCheck B3 force-complete: fills never arrived fully;
        /// accept whatever partial PnL accumulated and force-complete the lifecycle.
        /// </summary>
        public string SimulateB3ForceComplete(string posKey)
        {
            SimLifecycle lc;
            if (!RetiringLifecycles.TryGetValue(posKey, out lc)) return "NO_RETIRING_LIFECYCLE";
            // Attempt normal record first
            string first = TryRecordTrade(posKey, lc);
            if (lc.Recorded) return first + "_NORMAL";
            // Force-complete: accept partial fills
            lc.QtyAtLastScaleIn = lc.PostLastScaleInCloseQty;
            string forced = TryRecordTrade(posKey, lc);
            return forced + "_FORCED";
        }

        /// <summary>
        /// Simulate the ClearAllPositionTrackingState path (Market Replay restart /
        /// mode transition): clears ALL tracking state except session counters.
        /// </summary>
        public void SimulateModeTransition()
        {
            Lifecycles.Clear();
            RetiringLifecycles.Clear();
            PositionDirections.Clear();
            PositionQuantities.Clear();
            PositionEntryTimes.Clear();
            PositionEntryPrices.Clear();
            PositionMinPnl.Clear();
        }

        /// <summary>
        /// Simulate ApplyOvernightDecay: clears retiring lifecycles (any unrecorded
        /// trade has been committed or lost at session boundary) and resets entry
        /// counters for the new session.  TotalTrades is NOT reset — it accumulates
        /// across the day (mirrors production CarryDebt behaviour).
        /// </summary>
        public void SimulateOvernightDecay()
        {
            // Force-complete any unrecorded retiring lifecycles so trades from the
            // previous session are not silently dropped.
            foreach (var kv in new Dictionary<string, SimLifecycle>(RetiringLifecycles))
                SimulateB3ForceComplete(kv.Key);
            RetiringLifecycles.Clear();
            SessionEntryCount = 0;
            // Active lifecycles (position held overnight): keep them — they carry forward.
        }

        // ── Legacy test-helper stubs (kept for PropertyFuzzer backward compat) ────

        /// <summary>Kept for backward compat with DesyncQuickReentry scenario.</summary>
        public void SimulateDesyncShadowClearOnly(string posKey)
        {
            PositionDirections.Remove(posKey);
            PositionQuantities.Remove(posKey);
            PositionEntryTimes.Remove(posKey);
            PositionEntryPrices.Remove(posKey);
            PositionMinPnl.Remove(posKey);
        }

        /// <summary>Kept for backward compat with StaleDirAfterReversalSuppressed scenario.</summary>
        public void SimulateFallbackShadowCleanup(string posKey)
        {
            PositionDirections.Remove(posKey);
            PositionQuantities.Remove(posKey);
        }

        /// <summary>Kept for backward compat with StaleDirAfterReversalSuppressed scenario.</summary>
        public string SimulateStaleDirClear(string posKey, MarketPosition fillDir)
        {
            SimLifecycle life;
            if (!Lifecycles.TryGetValue(posKey, out life))
            {
                PositionDirections.Remove(posKey);
                PositionQuantities.Remove(posKey);
                return "NO_LIFECYCLE";
            }
            if (life.Direction == fillDir)
            {
                PositionDirections[posKey] = fillDir;
                PositionQuantities.Remove(posKey);
                return "DICT_CORRECTED";
            }
            Lifecycles.Remove(posKey);
            PositionDirections.Remove(posKey);
            PositionQuantities.Remove(posKey);
            PositionEntryTimes.Remove(posKey);
            PositionEntryPrices.Remove(posKey);
            PositionMinPnl.Remove(posKey);
            life.IsRemoved = true;
            RetiringLifecycles[posKey] = life;
            TryRecordTrade(posKey, life);
            return "LIFECYCLE_RETIRED";
        }
    }
}
