// DisplaySettings.cs — HUD display-preference store
// Persists the user's chosen display mode, pressure representation, and
// bar-opacity behaviour independently of the trading StrategyProfile so that
// UX preferences survive profile resets.
//
// File location: UserDataDir/AddOns/PsiMonitorDisplay.xml
// (Same directory as PsiMonitorLayout.dat for conceptual consistency.)
//
// Design rule: this file contains NO engine logic.  It is pure view-layer
// preference.  Changing any value here changes ONLY how data is rendered,
// never what is computed.

using System;
using System.IO;
using System.Xml.Serialization;

namespace NinjaTrader.NinjaScript.AddOns
{
    // ── Display mode ────────────────────────────────────────────────────────
    // Controls how much information is permanently visible on the HUD.
    // All modes use intensity-encoding (elements are always present; only
    // their visual weight changes) — no element ever appears or disappears
    // mid-session.  The difference is which elements exist at all.
    public enum HudDisplayMode
    {
        /// <summary>
        /// PSI gauge + context line only.
        /// Behavioural-signal bars hidden; Pressure follows <see cref="HudPressureDisplay"/> (ring and/or SESSION row).
        /// For experienced traders who have internalised the system.
        /// </summary>
        Minimal  = 0,

        /// <summary>
        /// Default.  Gauge + context line + dim-bars with opacity encoding
        /// (inactive bars fade to 25%, active bars at full opacity) +
        /// Pressure shown as ring colour AND as a number in SESSION stats.
        /// </summary>
        Standard = 1,

        /// <summary>
        /// All elements always at full opacity.
        /// For traders who want maximum data transparency at all times.
        /// </summary>
        Full     = 2,
    }

    // ── Pressure display ────────────────────────────────────────────────────
    // Controls how Pressure P(t) is communicated.
    // P is the context variable (Axiom 4): it amplifies Class B commits and
    // gates decay.  High P = psychological "hot moment".
    public enum HudPressureDisplay
    {
        /// <summary>
        /// Coloured ring around the gauge arc only (gradual intensity change;
        /// no jumping number).  Best for traders who find the number distracting.
        /// </summary>
        GaugeRing = 0,

        /// <summary>
        /// Default.  Both gauge ring AND numeric value in SESSION stats.
        /// </summary>
        Both      = 1,

        /// <summary>
        /// Numeric value in SESSION stats only (legacy display, no ring).
        /// </summary>
        Number    = 2,
    }

    // ═══════════════════════════════════════════════════════════════════════
    // DisplaySettings — serialisable preference bag
    // ═══════════════════════════════════════════════════════════════════════

    [XmlRoot("PsiMonitorDisplay")]
    public sealed class DisplaySettings
    {
        // ── Persisted properties ────────────────────────────────────────────

        [XmlElement]
        public HudDisplayMode    Mode            { get; set; } = HudDisplayMode.Standard;

        [XmlElement]
        public HudPressureDisplay PressureDisplay { get; set; } = HudPressureDisplay.Both;

        // ── Factory / persistence ───────────────────────────────────────────

        public static DisplaySettings Default() => new DisplaySettings();

        private static readonly XmlSerializer _xs = new XmlSerializer(typeof(DisplaySettings));

        /// <summary>
        /// Loads from <paramref name="path"/>.  Returns defaults if the file
        /// does not exist, is corrupt, or any I/O error occurs.
        /// </summary>
        public static DisplaySettings Load(string path)
        {
            if (!File.Exists(path)) return Default();
            try
            {
                using (var fs = File.OpenRead(path))
                    return (DisplaySettings)_xs.Deserialize(fs) ?? Default();
            }
            catch
            {
                return Default();
            }
        }

        /// <summary>
        /// Saves to <paramref name="path"/>.  Silently ignores I/O failures —
        /// failing to persist a UI preference must never crash the add-on.
        /// </summary>
        public void Save(string path)
        {
            try
            {
                Directory.CreateDirectory(Path.GetDirectoryName(path));
                using (var fs = File.Create(path))
                    _xs.Serialize(fs, this);
            }
            catch { /* non-fatal — preference simply reverts to default on next load */ }
        }
    }
}
