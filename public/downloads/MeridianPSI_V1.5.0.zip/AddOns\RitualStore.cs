using System;
using System.Collections.Generic;
using System.IO;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// The user's OWN pre-session ritual steps — the checklist items themselves.
    /// These belong to the user (they add/remove their own via the + on Home); we do
    /// NOT impose a fixed ritual. The per-day CHECKED state is separate (in-memory in
    /// the hub). Persisted one-step-per-line to ritual.txt in the same TradeMonitorData
    /// folder as journal/baseline. Pure C# (no NinjaTrader / WPF). All I/O is swallowed —
    /// the ritual must never break the dashboard.
    /// </summary>
    public static class RitualStore
    {
        private static readonly object _sync = new object();

        private static string _dataDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
            "NinjaTrader 8", "bin", "Custom", "AddOns", "TradeMonitorData");

        internal static void SetDataDir(string path) { if (!string.IsNullOrEmpty(path)) _dataDir = path; }

        private static string FilePath => Path.Combine(_dataDir, "ritual.txt");

        // First-run STARTER TEMPLATE only — every item is editable / removable, and the
        // user adds their own. Not an imposed ritual; just a non-empty starting point.
        private static readonly string[] Starter =
        {
            "Reviewed yesterday's lesson",
            "Size plan set",
            "No open positions",
            "Walked / cleared my head",
        };

        public static List<string> Load()
        {
            lock (_sync)
            {
                try
                {
                    if (File.Exists(FilePath))
                    {
                        var list = new List<string>();
                        foreach (var line in File.ReadAllLines(FilePath))
                        {
                            string t = (line ?? "").Trim();
                            if (t.Length > 0) list.Add(t);
                        }
                        return list;
                    }
                }
                catch { }
                var seed = new List<string>(Starter);
                Save(seed);
                return seed;
            }
        }

        public static void Save(List<string> items)
        {
            lock (_sync)
            {
                try
                {
                    Directory.CreateDirectory(_dataDir);
                    File.WriteAllLines(FilePath, items ?? new List<string>());
                }
                catch { }
            }
        }

        public static void Add(string item)
        {
            string t = (item ?? "").Trim();
            if (t.Length == 0) return;
            var list = Load();
            foreach (var x in list)
                if (string.Equals(x, t, StringComparison.OrdinalIgnoreCase)) return;   // no duplicates
            list.Add(t);
            Save(list);
        }

        public static void Remove(string item)
        {
            var list = Load();
            list.RemoveAll(x => string.Equals(x, item, StringComparison.OrdinalIgnoreCase));
            Save(list);
        }
    }
}
