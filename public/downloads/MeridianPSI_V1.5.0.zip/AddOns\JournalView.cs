using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Journal — its own tab (kept independent, not merged). ONE job: capture
    /// how it felt, in your words, and reflect. Quick notes are captured live on
    /// the HUD and anchored with PSI context; the day reflection is written here.
    /// PURE WPF. Representative content.
    /// </summary>
    internal static class JournalView
    {
        public static FrameworkElement Build()
        {
            var root = new StackPanel();

            root.Children.Add(Ui.Txt("JOURNAL", Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            var head = Ui.Txt("Session reflection", Theme.THeadline, Theme.FgPrimary, FontWeights.Bold);
            head.Margin = new Thickness(0, Theme.S2, 0, Theme.S4);
            root.Children.Add(head);

            // date nav
            var nav = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, Theme.S4) };
            nav.Children.Add(NavBtn("◀"));
            var date = Ui.Txt("Monday, June 2, 2026", Theme.TSubhead, Theme.FgPrimary, FontWeights.SemiBold);
            date.Margin = new Thickness(Theme.S3, 0, Theme.S3, 0); date.VerticalAlignment = VerticalAlignment.Center;
            nav.Children.Add(date);
            nav.Children.Add(NavBtn("▶"));
            var today = Ui.Button("Today", BtnVariant.Ghost);
            today.Margin = new Thickness(Theme.S3, 0, 0, 0);
            nav.Children.Add(today);
            root.Children.Add(nav);

            // emotion chips
            root.Children.Add(Ui.SectionHeader("How did it feel?"));
            var chips = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, Theme.S4) };
            chips.Children.Add(Ui.Chip("😀  Great", Theme.Stable, false));
            chips.Children.Add(Ui.Chip("😐  Neutral", Theme.FgSecondary, false));
            chips.Children.Add(Ui.Chip("😖  Frustrated", Theme.Warning, true));
            root.Children.Add(chips);

            // quick notes captured live
            root.Children.Add(Ui.SectionHeader("Quick notes (captured live)"));
            var notes = new StackPanel();
            notes.Children.Add(NoteRow("06:38", 53, "D3 Size", "added to the long, felt like it had to come back", true));
            notes.Children.Add(NoteRow("06:49", 62, "—", "ok calmed down, sticking to 6 now", false));
            root.Children.Add(Ui.Card(notes, Theme.S3));

            // end-of-day reflection
            var rh = Ui.SectionHeader("End-of-day reflection");
            rh.Margin = new Thickness(0, Theme.S5, 0, Theme.S2);
            root.Children.Add(rh);
            var refl = new StackPanel();
            refl.Children.Add(ReflectField("What went well?", "Stuck to 6 contracts for the last 4 trades. Stopped on time."));
            refl.Children.Add(ReflectField("What to improve?", "The 12-lot at 06:38 — I knew it was oversized and did it anyway."));
            refl.Children.Add(ReflectField("Focus for tomorrow?", "Hard cap at 6. No adds after the first fill."));
            root.Children.Add(Ui.Card(refl, Theme.S4));

            var done = Ui.Button("✦  Complete journal", BtnVariant.Primary);
            done.Margin = new Thickness(0, Theme.S5, 0, 0);
            root.Children.Add(done);

            return Ui.Page(root);
        }

        private static Border NavBtn(string glyph)
        {
            var tb = Ui.Txt(glyph, Theme.TBody, Theme.FgSecondary);
            tb.HorizontalAlignment = HorizontalAlignment.Center;
            return new Border { Width = 30, Height = 28, Background = Theme.BgElevated, CornerRadius = new CornerRadius(Theme.R1), Child = tb };
        }

        private static UIElement NoteRow(string time, double psi, string dim, string text, bool divider)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var meta = new StackPanel { Margin = new Thickness(0, 0, Theme.S4, 0) };
            meta.Children.Add(Ui.Txt(time, Theme.TBody, Theme.FgPrimary, FontWeights.SemiBold));
            meta.Children.Add(Ui.Txt("PSI " + psi.ToString("0") + (dim != "—" ? " · " + dim : ""), Theme.TCaption, Theme.Zone(psi)));
            Grid.SetColumn(meta, 0); g.Children.Add(meta);
            var t = Ui.Txt("“" + text + "”", Theme.TBody, Theme.FgSecondary);
            t.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(t, 1); g.Children.Add(t);
            var row = new Border { Child = g, Padding = new Thickness(0, Theme.S2, 0, Theme.S2) };
            if (divider) { row.BorderBrush = Theme.Border; row.BorderThickness = new Thickness(0, 0, 0, 1); }
            return row;
        }

        private static UIElement ReflectField(string label, string text)
        {
            var sp = new StackPanel { Margin = new Thickness(0, 0, 0, Theme.S4) };
            sp.Children.Add(Ui.Txt(label, Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            var box = new Border
            {
                Background = Theme.BgElevated,
                CornerRadius = new CornerRadius(Theme.R1),
                Padding = new Thickness(Theme.S3),
                Margin = new Thickness(0, Theme.S1, 0, 0),
                Child = Ui.Txt(text, Theme.TBody, Theme.FgPrimary),
            };
            sp.Children.Add(box);
            return sp;
        }
    }
}
