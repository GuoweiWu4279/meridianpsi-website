// JournalPageView.cs
//
// PURE-WPF static view for the dashboard's Journal page. Extracted from
// MeridianDashboard.CreateJournalPage so the page can be rendered OFFLINE
// (in the UI harness, with no NinjaTrader) AND drive the LIVE page.
//
// Build(...) produces the SAME visual tree CreateJournalPage produced, but is
// read-only over the supplied data — it wires NO live click handlers and NO
// DispatcherTimers. The live hub calls BuildWithAnchors(), then re-attaches
// interactivity onto the anchors exposed via the returned Result (date-nav
// buttons, the day-note / quick-note / reflection TextBoxes, emotion buttons,
// the Save / Complete-Journal buttons, and the entries list it repopulates).
// The offline harness just renders Build(...) straight to PNG.
//
// Palette: the hub's private brush fields were aliases of the central Theme
// tokens (FgPrimary→Theme.FgPrimary, FgSecondary→Theme.FgSecondary,
// FgHint→Theme.FgHint, FgAccent→Theme.Accent, BgCard→Theme.CardGradient,
// BgElevated→Theme.BgElevated). Those substitutions are applied here verbatim.
// BgNavHover (the emotion-button hover fill) was a literal ARGB(18,255,255,255)
// in the hub; it is reproduced inline as a private static.
//
// Helpers (BuildJournalRail / BuildEmotionButton / BuildJournalRow /
// BuildSimpleButton + the entries-list renderer) are DUPLICATED here as private
// statics — the hub keeps its own copies intact.
//
// DATA: CreateJournalPage reads its content live from JournalStore
// (LoadDayNote / LoadReflection / Recent → List<JournalEntry>). JournalEntry,
// JournalEmotion and JournalKind are all pure-C# public types (no NinjaTrader
// coupling), so Build takes the already-resolved data as plain parameters:
// the shown date, the day-note text, the three reflection strings, and the
// List<JournalEntry> for the selected date. Build renders from those.

using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal static class JournalPageView
    {
        // ── Palette aliases (mirror MeridianDashboard's private fields) ─────────
        private static readonly Brush FgPrimary   = Theme.FgPrimary;
        private static readonly Brush FgSecondary = Theme.FgSecondary;
        private static readonly Brush FgHint      = Theme.FgHint;
        private static readonly Brush FgAccent    = Theme.Accent;
        private static readonly Brush BgCard      = Theme.CardGradient;
        // Hub's BgNavHover literal (emotion-button hover fill).
        private static readonly Brush BgNavHover  = new SolidColorBrush(Color.FromArgb(18, 255, 255, 255));

        /// <summary>
        /// Interactive anchors the live hub re-wires after Build(). The offline
        /// harness ignores these and renders <see cref="Root"/> directly.
        /// </summary>
        internal sealed class Result
        {
            public FrameworkElement Root;            // the ScrollViewer to host
            public TextBlock        DateLabel;       // "Today · …" / "ddd, MMM d, yyyy"
            public Border           PrevDayButton;   // ◀
            public Border           NextDayButton;   // ▶ (greyed at today)
            public Border           TodayButton;     // "Today"
            public Border           CompileButton;   // "✦ Complete Journal"
            public TextBox          DayNoteBox;      // full-text per-day journal
            public Button           SaveDayButton;   // "Save journal"
            public StackPanel       EmotionRow;      // 3 emotion buttons (hub re-wires)
            public TextBox          QuickNoteBox;    // one-line quick note
            public Button           AddNoteButton;   // "Add note"
            public TextBlock        ReflChevron;     // ▼ / ▶
            public StackPanel       ReflToggleRow;   // collapse header
            public Border           ReflectionPanel; // expandable reflection body
            public TextBox          ReflWentWellBox;
            public TextBox          ReflImproveBox;
            public TextBox          ReflFocusBox;
            public Button           SaveReflButton;  // "Save reflection"
            public StackPanel       EntriesList;     // hub clears + repopulates with live rows
        }

        /// <summary>
        /// Builds the Journal page visual tree (read-only over the supplied data).
        /// PURE WPF — no live click handlers / timers are attached.
        /// </summary>
        /// <param name="shownDate">Trading date the page is showing.</param>
        /// <param name="dayNote">Full-text day journal for <paramref name="shownDate"/>.</param>
        /// <param name="reflWentWell">Reflection: what went well.</param>
        /// <param name="reflImprove">Reflection: what to improve.</param>
        /// <param name="reflFocus">Reflection: focus for next session.</param>
        /// <param name="entries">Journal entries for <paramref name="shownDate"/> (chronological).</param>
        public static FrameworkElement Build(
            DateTime           shownDate,
            string             dayNote,
            string             reflWentWell,
            string             reflImprove,
            string             reflFocus,
            List<JournalEntry> entries)
        {
            return BuildWithAnchors(shownDate, dayNote, reflWentWell, reflImprove, reflFocus, entries).Root;
        }

        /// <summary>
        /// Same as <see cref="Build"/> but also returns the interactive anchors so
        /// the live hub can attach behavior. Hover-only visual feedback IS wired
        /// here (presentation, not data interaction); data handlers are not.
        /// </summary>
        internal static Result BuildWithAnchors(
            DateTime           shownDate,
            string             dayNote,
            string             reflWentWell,
            string             reflImprove,
            string             reflFocus,
            List<JournalEntry> entries)
        {
            var result = new Result();

            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };

            var root = new StackPanel { Margin = new Thickness(24, 24, 18, 48) };
            var journalGrid = new Grid();
            journalGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.55, GridUnitType.Star) });
            journalGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            Grid.SetColumn(root, 0); journalGrid.Children.Add(root);
            var journalRail = (StackPanel)BuildJournalRail();
            journalRail.Margin = new Thickness(18, 24, 24, 48);
            Grid.SetColumn(journalRail, 1); journalGrid.Children.Add(journalRail);
            scroll.Content = journalGrid;

            // ── Title row ─────────────────────────────────────────────────────
            root.Children.Add(new TextBlock
            {
                Text       = "Journal",
                FontSize   = 18,
                FontWeight = FontWeights.Bold,
                FontFamily = Theme.Font,
                Foreground = FgPrimary,
            });
            root.Children.Add(new TextBlock
            {
                Text         = "Quick notes and emotion tags captured during the session are compiled here.  Nothing is mandatory.",
                FontSize     = 11,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 2, 0, 16),
            });

            // ── Date navigation row ───────────────────────────────────────────
            var dateNavRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 0, 0, 14),
            };

            var prevDayBtn = new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(5),
                Padding         = new Thickness(10, 5, 10, 5),
                Cursor          = Cursors.Hand,
                Child           = new TextBlock { Text = "◀", FontSize = 12, Foreground = FgSecondary,
                                                  FontFamily = Theme.Font },
            };

            bool isToday = shownDate.Date == DateTime.Today.Date;
            var dateLabel = new TextBlock
            {
                Text                = isToday
                                          ? "Today  ·  " + shownDate.ToString("MMM d")
                                          : shownDate.ToString("ddd, MMM d, yyyy"),
                FontSize            = 13,
                FontWeight          = FontWeights.SemiBold,
                FontFamily          = Theme.Font,
                Foreground          = FgPrimary,
                VerticalAlignment   = VerticalAlignment.Center,
                Margin              = new Thickness(10, 0, 10, 0),
                MinWidth            = 180,
                TextAlignment       = TextAlignment.Center,
            };

            // "Next" is greyed/disabled once we're already at today — match the
            // live page's post-refresh state.
            bool atOrAfterToday = shownDate.Date >= DateTime.Today.Date;
            var nextDayBtn = new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(5),
                Padding         = new Thickness(10, 5, 10, 5),
                Cursor          = atOrAfterToday ? Cursors.Arrow : Cursors.Hand,
                Child           = new TextBlock { Text = "▶", FontSize = 12,
                                                  Foreground = atOrAfterToday ? FgHint : FgSecondary,
                                                  FontFamily = Theme.Font },
            };

            var todayBtn = new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(5),
                Padding         = new Thickness(10, 5, 10, 5),
                Cursor          = Cursors.Hand,
                Margin          = new Thickness(8, 0, 0, 0),
                Child           = new TextBlock { Text = "Today", FontSize = 11, Foreground = FgSecondary,
                                                  FontFamily = Theme.Font },
            };

            dateNavRow.Children.Add(prevDayBtn);
            dateNavRow.Children.Add(dateLabel);
            dateNavRow.Children.Add(nextDayBtn);
            dateNavRow.Children.Add(todayBtn);
            root.Children.Add(dateNavRow);

            result.DateLabel     = dateLabel;
            result.PrevDayButton = prevDayBtn;
            result.NextDayButton = nextDayBtn;
            result.TodayButton   = todayBtn;

            // ── Day note area ─────────────────────────────────────────────────
            var dayNoteHeader = new Grid();
            dayNoteHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            dayNoteHeader.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var dayNoteLabel = new TextBlock
            {
                Text              = "Day journal",
                FontSize          = 13,
                FontWeight        = FontWeights.SemiBold,
                FontFamily        = Theme.Font,
                Foreground        = FgPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(0, 0, 0, 0),
            };
            Grid.SetColumn(dayNoteLabel, 0);
            dayNoteHeader.Children.Add(dayNoteLabel);

            // "Complete Journal" (auto-compile) button
            var compileBtn = new Border
            {
                Background      = Theme.Tint(Theme.Accent, 18),
                BorderBrush     = Theme.Tint(Theme.Accent, 60),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(5),
                Padding         = new Thickness(10, 4, 10, 4),
                Cursor          = Cursors.Hand,
                ToolTip         = "Auto-compile all today's quick notes, emotion tags and session stats into a draft journal. Review, edit, then save.",
                Child           = new TextBlock
                {
                    Text       = "✦ Complete Journal",
                    FontSize   = 11,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = Theme.Accent,
                    FontFamily = Theme.Font,
                },
            };
            Grid.SetColumn(compileBtn, 1);
            dayNoteHeader.Children.Add(compileBtn);
            result.CompileButton = compileBtn;

            dayNoteHeader.Margin = new Thickness(0, 0, 0, 6);
            root.Children.Add(dayNoteHeader);

            root.Children.Add(new TextBlock
            {
                Text         = "Compiled automatically or write freely. Saved per trading day — visible in History.",
                FontSize     = 10,
                FontFamily   = Theme.Font,
                Foreground   = FgHint,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 8),
            });

            var dayNoteBox = new TextBox
            {
                Text            = dayNote ?? "",
                Background      = BgCard,
                Foreground      = FgPrimary,
                CaretBrush      = FgPrimary,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(10, 8, 10, 8),
                FontFamily      = new FontFamily("Consolas"),
                FontSize        = 11,
                AcceptsReturn   = true,
                TextWrapping    = TextWrapping.Wrap,
                MinHeight       = 130,
                MaxHeight       = 380,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            };
            root.Children.Add(dayNoteBox);
            result.DayNoteBox = dayNoteBox;

            var saveDayBtn = BuildSimpleButton("Save journal", accent: true);
            saveDayBtn.Margin = new Thickness(0, 8, 0, 20);
            // NOTE: live click (→ JournalStore.SaveDayNote) is attached by the hub.
            root.Children.Add(saveDayBtn);
            result.SaveDayButton = saveDayBtn;

            // ── Divider ───────────────────────────────────────────────────────
            root.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 0, 0, 18),
            });

            // ── Quick emotion tags (live — always for today) — in the capture rail ─
            journalRail.Children.Add(new TextBlock
            {
                Text       = "Tag your mood",
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                FontFamily = Theme.Font,
                Foreground = FgPrimary,
                Margin     = new Thickness(0, 18, 0, 8),
            });
            var emotionRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 0, 0, 14),
            };
            emotionRow.Children.Add(BuildEmotionButton("😊 Great",      JournalEmotion.Calm));
            emotionRow.Children.Add(BuildEmotionButton("😐 Neutral",    JournalEmotion.Neutral));
            emotionRow.Children.Add(BuildEmotionButton("😤 Frustrated", JournalEmotion.Stressed));
            journalRail.Children.Add(emotionRow);
            result.EmotionRow = emotionRow;

            // ── Quick note input — in the capture rail ────────────────────────
            journalRail.Children.Add(new TextBlock
            {
                Text       = "Quick note",
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                FontFamily = Theme.Font,
                Foreground = FgPrimary,
                Margin     = new Thickness(0, 14, 0, 6),
            });

            var quickNoteBox = new TextBox
            {
                Background      = BgCard,
                Foreground      = FgPrimary,
                CaretBrush      = FgPrimary,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(10, 8, 10, 8),
                FontFamily      = Theme.Font,
                FontSize        = 12,
                AcceptsReturn   = false,
                MinHeight       = 34,
            };
            // NOTE: live Enter-key → SubmitQuickNote is attached by the hub.
            journalRail.Children.Add(quickNoteBox);
            result.QuickNoteBox = quickNoteBox;

            var actionRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 8, 0, 16),
            };
            var addBtn = BuildSimpleButton("Add note", accent: true);
            // NOTE: live click (→ SubmitQuickNote) is attached by the hub.
            actionRow.Children.Add(addBtn);
            journalRail.Children.Add(actionRow);
            result.AddNoteButton = addBtn;

            // ── Session Reflection (collapsible) ──────────────────────────────
            var reflToggleRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                Margin      = new Thickness(0, 0, 0, 8),
                Cursor      = Cursors.Hand,
            };
            var reflChevron = new TextBlock
            {
                Text       = "▼",
                FontSize   = 9,
                FontFamily = Theme.Font,
                Foreground = FgHint,
                VerticalAlignment = VerticalAlignment.Center,
                Margin     = new Thickness(0, 0, 6, 0),
            };
            reflToggleRow.Children.Add(reflChevron);
            reflToggleRow.Children.Add(new TextBlock
            {
                Text       = "Session reflection",
                FontSize   = 11,
                FontWeight = FontWeights.SemiBold,
                FontFamily = Theme.Font,
                Foreground = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            });
            root.Children.Add(reflToggleRow);
            result.ReflChevron   = reflChevron;
            result.ReflToggleRow = reflToggleRow;

            // Reflection text boxes — styling matches the quick-note box exactly.
            TextBox MakeReflBox(string text) => new TextBox
            {
                Text            = text ?? "",
                Background      = BgCard,
                Foreground      = FgPrimary,
                CaretBrush      = FgPrimary,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(10, 8, 10, 8),
                FontFamily      = Theme.Font,
                FontSize        = 12,
                AcceptsReturn   = true,
                TextWrapping    = TextWrapping.Wrap,
                MinHeight       = 46,
                MaxHeight       = 120,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            };
            var wentWellBox = MakeReflBox(reflWentWell);
            var improveBox  = MakeReflBox(reflImprove);
            var focusBox    = MakeReflBox(reflFocus);
            result.ReflWentWellBox = wentWellBox;
            result.ReflImproveBox  = improveBox;
            result.ReflFocusBox    = focusBox;

            TextBlock ReflLabel(string text, bool first = false) => new TextBlock
            {
                Text       = text,
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                FontFamily = Theme.Font,
                Foreground = FgPrimary,
                Margin     = new Thickness(0, first ? 0 : 12, 0, 6),
            };

            var reflInner = new StackPanel();

            // Customizable reflection template (item 2): render only ENABLED prompts with
            // the user's own labels; an inline editor renames/toggles each. Answers still
            // persist in the 3 fixed slots (boxes above) so there is no data migration.
            var prompts = JournalStore.LoadReflectionPrompts();
            TextBox[] slotBoxes = { wentWellBox, improveBox, focusBox };

            var promptsBody = new StackPanel();
            Action rebuildPrompts = () =>
            {
                promptsBody.Children.Clear();
                bool any = false, firstShown = true;
                foreach (var p in prompts)
                {
                    if (p == null || !p.Enabled || p.Slot < 0 || p.Slot > 2) continue;
                    promptsBody.Children.Add(ReflLabel((p.Label ?? "") + ":", firstShown));
                    promptsBody.Children.Add(slotBoxes[p.Slot]);
                    any = true; firstShown = false;
                }
                if (!any)
                    promptsBody.Children.Add(new TextBlock { Text = "All prompts are turned off. Use Customize to switch some back on.", FontFamily = Theme.Font, FontSize = 11, Foreground = FgHint, TextWrapping = TextWrapping.Wrap });
            };
            rebuildPrompts();

            var editorBody = new StackPanel { Visibility = Visibility.Collapsed, Margin = new Thickness(0, 8, 0, 0) };
            var editBoxes = new System.Collections.Generic.List<TextBox>();
            Action commitEdits = () =>
            {
                for (int i = 0; i < prompts.Count && i < editBoxes.Count; i++)
                {
                    var lb = editBoxes[i]; if (lb == null) continue;
                    if (!string.IsNullOrWhiteSpace(lb.Text)) prompts[i].Label = lb.Text.Trim();
                    if (lb.Tag is CheckBox cb) prompts[i].Enabled = cb.IsChecked == true;
                }
            };
            Action rebuildEditor = null;
            rebuildEditor = () =>
            {
                editorBody.Children.Clear();
                editBoxes.Clear();
                editorBody.Children.Add(new TextBlock { Text = "Rename, reorder or turn off each prompt; your saved answers are kept.", FontFamily = Theme.Font, FontSize = 10, Foreground = FgHint, Margin = new Thickness(0, 0, 0, 8), TextWrapping = TextWrapping.Wrap });
                for (int pi = 0; pi < prompts.Count; pi++)
                {
                    int idx = pi;
                    var rowg = new Grid { Margin = new Thickness(0, 0, 0, 6) };
                    rowg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                    rowg.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                    rowg.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

                    var ud = new StackPanel { Orientation = Orientation.Vertical, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 8, 0) };
                    var up = MakeReorderBtn("▲", idx > 0);
                    if (idx > 0) up.MouseLeftButtonDown += (_, e) => { e.Handled = true; commitEdits(); var tmp = prompts[idx - 1]; prompts[idx - 1] = prompts[idx]; prompts[idx] = tmp; rebuildEditor(); };
                    var dn = MakeReorderBtn("▼", idx < prompts.Count - 1);
                    if (idx < prompts.Count - 1) dn.MouseLeftButtonDown += (_, e) => { e.Handled = true; commitEdits(); var tmp = prompts[idx + 1]; prompts[idx + 1] = prompts[idx]; prompts[idx] = tmp; rebuildEditor(); };
                    ud.Children.Add(up); ud.Children.Add(dn);
                    Grid.SetColumn(ud, 0); rowg.Children.Add(ud);

                    var chk = new CheckBox { IsChecked = prompts[pi].Enabled, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 8, 0), Foreground = FgSecondary };
                    Grid.SetColumn(chk, 1); rowg.Children.Add(chk);
                    var lb = MakeReflBox(prompts[pi].Label); lb.AcceptsReturn = false; lb.MinHeight = 30; lb.MaxHeight = 36; lb.Tag = chk;
                    Grid.SetColumn(lb, 2); rowg.Children.Add(lb);
                    editBoxes.Add(lb);
                    editorBody.Children.Add(rowg);
                }
                var saveEditBtn = BuildSimpleButton("Save prompts", accent: true);
                saveEditBtn.Margin = new Thickness(0, 4, 0, 0);
                saveEditBtn.Click += (_, __) =>
                {
                    commitEdits();
                    JournalStore.SaveReflectionPrompts(prompts);
                    rebuildPrompts();
                    editorBody.Visibility = Visibility.Collapsed;
                };
                editorBody.Children.Add(saveEditBtn);
            };
            rebuildEditor();

            var custRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 0, 0, 2) };
            var custLink = new TextBlock { Text = "Customize", FontFamily = Theme.Font, FontSize = 11, FontWeight = FontWeights.SemiBold, Foreground = FgAccent, Cursor = Cursors.Hand };
            custLink.MouseLeftButtonDown += (_, e) => { e.Handled = true; editorBody.Visibility = editorBody.Visibility == Visibility.Visible ? Visibility.Collapsed : Visibility.Visible; };
            custRow.Children.Add(custLink);

            reflInner.Children.Add(custRow);
            reflInner.Children.Add(promptsBody);
            reflInner.Children.Add(editorBody);

            var saveReflBtn = BuildSimpleButton("Save reflection", accent: false);
            saveReflBtn.Margin = new Thickness(0, 10, 0, 0);
            reflInner.Children.Add(saveReflBtn);
            result.SaveReflButton = saveReflBtn;

            var reflectionPanel = new Border
            {
                Visibility      = Visibility.Visible,
                Background      = Brushes.Transparent,
                BorderThickness = new Thickness(0),
                Margin          = new Thickness(0, 0, 0, 16),
                Child           = reflInner,
            };
            root.Children.Add(reflectionPanel);
            result.ReflectionPanel = reflectionPanel;
            // NOTE: live expand/collapse toggle is attached by the hub.

            // ── Entries for selected date — the capture log, in the rail ──────
            journalRail.Children.Add(new TextBlock
            {
                Text       = "Session entries",
                FontSize   = 12,
                FontWeight = FontWeights.SemiBold,
                FontFamily = Theme.Font,
                Foreground = FgPrimary,
                Margin     = new Thickness(0, 18, 0, 8),
            });

            var entriesList = new StackPanel();
            journalRail.Children.Add(entriesList);
            result.EntriesList = entriesList;
            PopulateEntries(entriesList, entries, dateSpecific: true);

            result.Root = scroll;
            return result;
        }

        // ── Entries list rendering (read-only) ────────────────────────────────
        // Mirrors RefreshJournalEntries' body. The live hub clears EntriesList and
        // rebuilds it with its own RefreshJournalEntries; this exact rendering is
        // what shows offline. `dateSpecific` selects the empty-state copy (the live
        // page passes a concrete date here, matching dateSpecific:true).
        internal static void PopulateEntries(StackPanel entriesList, List<JournalEntry> entries, bool dateSpecific)
        {
            entriesList.Children.Clear();
            var list = entries ?? new List<JournalEntry>();

            if (list.Count == 0)
            {
                entriesList.Children.Add(new TextBlock
                {
                    Text       = dateSpecific
                                 ? "No quick notes or emotion tags recorded for this session."
                                 : "No entries yet.  Tag an emotion or write one line above.",
                    FontSize   = 11,
                    FontFamily = Theme.Font,
                    Foreground = FgHint,
                    FontStyle  = FontStyles.Italic,
                });
                return;
            }

            for (int i = list.Count - 1; i >= 0; i--)
                entriesList.Children.Add(BuildJournalRow(list[i]));
        }

        // ── Right-rail reference card ─────────────────────────────────────────
        private static FrameworkElement BuildJournalRail()
        {
            var card = new Border
            {
                Background = Theme.BgCard, BorderBrush = Theme.Border, BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(Theme.R3), Padding = new Thickness(16),
            };
            var sp = new StackPanel();
            sp.Children.Add(new TextBlock { Text = "Why journal", FontFamily = Theme.Font, FontSize = 10, FontWeight = FontWeights.Bold, Foreground = FgHint, Margin = new Thickness(0, 0, 0, 10) });
            sp.Children.Add(new TextBlock { Text = "PSI measures what you did. The journal captures how it felt — the part the engine can't see. A line written in the moment is hard to retcon later.", FontFamily = Theme.Font, FontSize = 12, Foreground = FgSecondary, TextWrapping = TextWrapping.Wrap, LineHeight = 19 });
            card.Child = sp;
            var rail = new StackPanel();
            rail.Children.Add(card);
            return rail;
        }

        // ── Emotion tag button (rendered with hover; data click attached by hub) ─
        private static Border BuildEmotionButton(string label, JournalEmotion em)
        {
            var textBlock = new TextBlock
            {
                Text              = label,
                FontSize          = 12,
                FontFamily        = Theme.Font,
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            };

            var border = new Border
            {
                Background      = BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(16),
                Padding         = new Thickness(12, 6, 14, 6),
                Margin          = new Thickness(0, 0, 8, 0),
                Cursor          = Cursors.Hand,
                Child           = textBlock,
                Tag             = em,   // hub reads this to wire RecordJournalEntry
            };
            border.MouseEnter += (_, __) => border.Background = BgNavHover;
            border.MouseLeave += (_, __) => border.Background = BgCard;
            // NOTE: live click (→ _monitor.RecordJournalEntry) is attached by the hub.
            return border;
        }

        // ── Single journal entry row (visuals identical to the hub's) ─────────
        private static Border BuildJournalRow(JournalEntry e)
        {
            bool isSystem = string.Equals(e.Kind, "SessionSummary", StringComparison.OrdinalIgnoreCase);

            // User-friendly kind label
            string kindLabel;
            if (isSystem)
                kindLabel = "End of session";
            else if (string.Equals(e.Kind, "QuickNote", StringComparison.OrdinalIgnoreCase))
                kindLabel = "Note";
            else if (string.Equals(e.Kind, "EmotionTag", StringComparison.OrdinalIgnoreCase))
            {
                string em = e.EmotionString ?? "";
                if (string.Equals(em, "Calm",     StringComparison.OrdinalIgnoreCase)) kindLabel = "Calm";
                else if (string.Equals(em, "Neutral",  StringComparison.OrdinalIgnoreCase)) kindLabel = "Neutral";
                else if (string.Equals(em, "Stressed", StringComparison.OrdinalIgnoreCase)) kindLabel = "Stressed";
                else kindLabel = em;
            }
            else
                kindLabel = e.Kind ?? "";

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(96) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Time + kind (left col)
            var leftStack = new StackPanel();
            leftStack.Children.Add(new TextBlock
            {
                Text       = e.Timestamp.ToString("HH:mm:ss"),
                FontSize   = 11,
                FontFamily = new FontFamily("Consolas"),
                Foreground = isSystem ? FgHint : FgSecondary,
            });
            leftStack.Children.Add(new TextBlock
            {
                Text       = kindLabel,
                FontSize   = 10,
                FontFamily = Theme.Font,
                Foreground = isSystem ? FgHint : FgSecondary,
            });
            Grid.SetColumn(leftStack, 0);
            grid.Children.Add(leftStack);

            // Note + context (right col)
            var midStack = new StackPanel();
            midStack.Children.Add(new TextBlock
            {
                Text         = isSystem && string.IsNullOrWhiteSpace(e.Note)
                                   ? "(auto)"
                                   : string.IsNullOrWhiteSpace(e.Note) ? "(no note)" : e.Note,
                FontSize     = isSystem ? 11 : 12,
                FontFamily   = Theme.Font,
                Foreground   = isSystem ? FgHint
                             : string.IsNullOrWhiteSpace(e.Note) ? FgHint : FgPrimary,
                TextWrapping = TextWrapping.Wrap,
                FontStyle    = isSystem ? FontStyles.Italic : FontStyles.Normal,
            });
            midStack.Children.Add(new TextBlock
            {
                Text = string.Format("PSI {0:F0}  ·  {1}  ·  {2}{3:F2}",
                                     e.Psi,
                                     string.IsNullOrEmpty(e.DominantDim) ? "—" : e.DominantDim,
                                     e.SessionPnl >= 0 ? "+" : "",
                                     e.SessionPnl),
                FontSize   = 9,
                FontFamily = Theme.Font,
                Foreground = FgHint,
                Margin     = new Thickness(0, 2, 0, 0),
            });
            Grid.SetColumn(midStack, 1);
            grid.Children.Add(midStack);

            return new Border
            {
                Background      = isSystem
                    ? new SolidColorBrush(Color.FromArgb(15, 255, 255, 255))
                    : BgCard,
                BorderBrush     = new SolidColorBrush(Color.FromArgb((byte)(isSystem ? 15 : 30), 255, 255, 255)),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(6),
                Padding         = new Thickness(10, 7, 10, 7),
                Margin          = new Thickness(0, 0, 0, 5),
                Child           = grid,
            };
        }

        // ── Simple text button (Save journal / Add note / Save reflection) ────
        // Tiny up/down reorder button for the prompt editor.
        private static Border MakeReorderBtn(string glyph, bool enabled)
        {
            var tb = new TextBlock { Text = glyph, FontFamily = Theme.Font, FontSize = 8, Foreground = enabled ? FgSecondary : FgHint, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            return new Border
            {
                Width = 18, Height = 13, CornerRadius = new CornerRadius(3),
                Background = enabled ? BgCard : Brushes.Transparent,
                BorderBrush = enabled ? new SolidColorBrush(Color.FromArgb(50, 255, 255, 255)) : Brushes.Transparent,
                BorderThickness = new Thickness(1), Margin = new Thickness(0, 1, 0, 1),
                Cursor = enabled ? Cursors.Hand : Cursors.Arrow, Child = tb,
            };
        }
        private static Button BuildSimpleButton(string label, bool accent)
        {
            // accent → ghost-emerald (tinted outline + emerald text — no heavy fill, no white
            // text); neutral → card surface. Flat template kills the native blue focus ring.
            Brush bg = accent ? Theme.Tint(Theme.Accent, 20) : BgCard;
            Brush fg = accent ? Theme.Accent : FgPrimary;
            Brush bd = accent ? Theme.Tint(Theme.Accent, 64) : new SolidColorBrush(Color.FromArgb(60, 255, 255, 255));
            var b = new Button
            {
                Content          = label,
                FontSize         = 12,
                FontFamily       = Theme.Font,
                FontWeight       = FontWeights.SemiBold,
                Foreground       = fg,
                Cursor           = Cursors.Hand,
                FocusVisualStyle = null,
                Template         = Ui.FlatButtonTemplate(bg, bd, 7, 14, 7),
            };
            Ui.WireLift(b, 1.5);
            return b;
        }
    }
}
