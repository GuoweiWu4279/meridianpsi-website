using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Settings — configure the profile (the limits that power the signals) and
    /// the HUD display. ONE job: set your rules once, clearly. PURE WPF.
    /// Representative content.
    /// </summary>
    internal static class SettingsView
    {
        public static FrameworkElement Build()
        {
            var root = new StackPanel();

            root.Children.Add(Ui.Txt("SETTINGS", Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            var head = Ui.Txt("Your rules & display", Theme.THeadline, Theme.FgPrimary, FontWeights.Bold);
            head.Margin = new Thickness(0, Theme.S2, 0, Theme.S5);
            root.Children.Add(head);

            // trading profile
            root.Children.Add(Ui.SectionHeader("Trading profile"));
            var prof = new StackPanel();
            prof.Children.Add(Ui.FormRow("Account", Ui.Value("MFFUEVPRO535453037 ▾")));
            prof.Children.Add(Ui.FormRow("Instruments", Ui.Value("MNQ ▾")));
            prof.Children.Add(Ui.FormRow("Session window", Ui.Value("06:30 – 07:30")));
            prof.Children.Add(Ui.FormRow("Max position size", ValueWithUnit("6", "contracts")));
            prof.Children.Add(Ui.FormRow("Daily loss limit", ValueWithUnit("$200", "")));
            prof.Children.Add(Ui.FormRow("Pause after losses", ValueWithUnit("2", "in a row")));
            prof.Children.Add(Ui.FormRow("Stop-loss range", ValueWithUnit("4 – 200", "ticks", false)));
            root.Children.Add(Ui.Card(prof, Theme.S4));

            // display
            var dh = Ui.SectionHeader("Display");
            dh.Margin = new Thickness(0, Theme.S5, 0, Theme.S2);
            root.Children.Add(dh);
            var disp = new StackPanel();

            var modes = new StackPanel { Orientation = Orientation.Horizontal };
            modes.Children.Add(Ui.Chip("Minimal", Theme.Accent, false));
            modes.Children.Add(Ui.Chip("Standard", Theme.Accent, true));
            modes.Children.Add(Ui.Chip("Full", Theme.Accent, false));
            disp.Children.Add(Ui.FormRow("HUD mode", modes));

            disp.Children.Add(Ui.FormRow("Stress indicator", Ui.Toggle(true)));
            disp.Children.Add(Ui.FormRow("Window opacity", Slider(0.92)));

            var themes = new StackPanel { Orientation = Orientation.Horizontal };
            themes.Children.Add(Ui.Chip("Dark", Theme.Accent, true));
            themes.Children.Add(Ui.Chip("Light", Theme.Accent, false));
            disp.Children.Add(Ui.FormRow("Theme", themes, false));

            root.Children.Add(Ui.Card(disp, Theme.S4));

            var save = Ui.Button("Save", BtnVariant.Primary);
            save.Margin = new Thickness(0, Theme.S5, 0, 0);
            root.Children.Add(save);

            return Ui.Page(root);
        }

        private static UIElement ValueWithUnit(string value, string unit, bool unusedDivider = true)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            var box = new Border
            {
                Background = Theme.BgElevated,
                BorderBrush = Theme.Border,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(Theme.R1),
                Padding = new Thickness(Theme.S3, Theme.S1, Theme.S3, Theme.S1),
                Child = Ui.Value(value),
            };
            sp.Children.Add(box);
            if (!string.IsNullOrEmpty(unit))
            {
                var u = Ui.Txt(unit, Theme.TBody, Theme.FgHint);
                u.VerticalAlignment = VerticalAlignment.Center; u.Margin = new Thickness(Theme.S2, 0, 0, 0);
                sp.Children.Add(u);
            }
            return sp;
        }

        private static UIElement Slider(double frac)
        {
            var g = new Grid { Width = 160, Height = 18 };
            var track = new Border { Height = 4, CornerRadius = new CornerRadius(2), Background = Theme.BgElevated, VerticalAlignment = VerticalAlignment.Center };
            g.Children.Add(track);
            var fillGrid = new Grid { VerticalAlignment = VerticalAlignment.Center, Height = 4 };
            fillGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(frac, GridUnitType.Star) });
            fillGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1 - frac, GridUnitType.Star) });
            var fill = new Border { CornerRadius = new CornerRadius(2), Background = Theme.Accent };
            Grid.SetColumn(fill, 0); fillGrid.Children.Add(fill);
            g.Children.Add(fillGrid);
            var knob = new Border { Width = 16, Height = 16, CornerRadius = new CornerRadius(99), Background = Theme.FgPrimary, HorizontalAlignment = HorizontalAlignment.Left, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(frac * 144, 0, 0, 0) };
            g.Children.Add(knob);
            return g;
        }
    }
}
