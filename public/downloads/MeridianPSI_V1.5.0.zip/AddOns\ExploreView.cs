using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Explore — the on-demand analytics layer. PURE WPF. Organized BY THEME
    /// (Discipline / Risk / Performance / Timing / Behavior), one theme at a
    /// time, filterable — never a flat dump. This is the skeleton: the Discipline
    /// theme is populated (the Trade Map scatter lives here), the others are
    /// stubs that fill in as we build. The breadth lives here so the ANSWER
    /// surfaces (Debrief / Progress) can stay curated.
    /// </summary>
    internal static class ExploreView
    {
        private static readonly string[] Themes = { "Discipline", "Risk", "Performance", "Timing", "Behavior" };

        public static FrameworkElement Build(System.Collections.Generic.List<DebriefTrade> trades)
        {
            var root = new StackPanel();

            // header
            root.Children.Add(Ui.Txt("EXPLORE", Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            var head = Ui.Txt("Dig into any dimension", Theme.THeadline, Theme.FgPrimary, FontWeights.Bold);
            head.Margin = new Thickness(0, Theme.S2, 0, 0);
            root.Children.Add(head);

            // filter bar
            var filters = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, Theme.S3, 0, Theme.S4) };
            filters.Children.Add(FilterPill("This month  ▾"));
            filters.Children.Add(FilterPill("MNQ  ▾"));
            filters.Children.Add(FilterPill("All sessions  ▾"));
            root.Children.Add(filters);

            // theme tabs
            var tabs = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, Theme.S4) };
            for (int i = 0; i < Themes.Length; i++)
                tabs.Children.Add(Tab(Themes[i], i == 0));
            root.Children.Add(tabs);

            // ── Discipline theme content ───────────────────────────────────
            // Trade Map (the scatter — exploratory, lives here, not on the Debrief)
            var mapInner = new StackPanel();
            mapInner.Children.Add(Ui.Txt("TRADE MAP", Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            var dots = new List<ScatterDot>();
            if (trades != null)
                foreach (var t in trades)
                    dots.Add(new ScatterDot { Label = t.Label, Pnl = t.Pnl, Disc = t.Disciplined ? 0.74 : 0.26, Size = t.Size, Win = t.IsWin, Color = CellBrush(t.Cell) });
            var scatter = new QuadrantScatter { Dots = dots, ChartHeight = 240 };
            scatter.Margin = new Thickness(0, Theme.S2, 0, 0);
            mapInner.Children.Add(scatter);
            var legend = Ui.Txt("Right = profit   ·   Up = within your size rule   ·   bubble = contracts   ·   color: green earned · amber luck · red spiral", Theme.TCaption, Theme.FgHint);
            legend.Margin = new Thickness(0, Theme.S2, 0, 0);
            legend.HorizontalAlignment = HorizontalAlignment.Center;
            mapInner.Children.Add(legend);
            root.Children.Add(Ui.Card(mapInner));

            // two analytic cards (one live sample, one stub) side by side
            var adherence = StatChartCard("SIZE-RULE ADHERENCE", "last 8 sessions",
                new SparkAreaChart { Values = new System.Collections.Generic.List<double> { 70, 62, 80, 75, 68, 90, 82, 78 }, MinY = 0, MaxY = 100, Thresholds = new[] { 100.0 }, Stroke = Theme.Accent, ChartHeight = 96 });
            var edgeByWeek = StatChartCard("EDGE SHARE BY WEEK", "% of profit",
                new SparkAreaChart { Values = new System.Collections.Generic.List<double> { 21, 28, 25, 34 }, MinY = 0, MaxY = 100, Thresholds = new[] { 50.0 }, Stroke = Theme.Good, ChartHeight = 96 });
            var pair = Ui.Grid2(adherence, edgeByWeek, Theme.S3);
            pair.Margin = new Thickness(0, Theme.S3, 0, 0);
            root.Children.Add(pair);

            var note = Ui.Txt("Skeleton — Risk / Performance / Timing / Behavior themes and more charts fill in as sessions accumulate. The insight engine promotes the noteworthy ones to Progress.", Theme.TCaption, Theme.FgHint);
            note.Margin = new Thickness(0, Theme.S4, 0, 0);
            root.Children.Add(note);

            return Ui.Page(root, 880);
        }

        private static Border Tab(string text, bool active)
        {
            var bg = active ? new SolidColorBrush(Theme.ColorOf(Theme.Accent)) { Opacity = 0.16 } : Brushes.Transparent;
            if (bg is SolidColorBrush sb) sb.Freeze();
            var tb = Ui.Txt(text, Theme.TBody, active ? Theme.Accent : Theme.FgSecondary, active ? FontWeights.SemiBold : FontWeights.Normal);
            tb.TextWrapping = TextWrapping.NoWrap;
            return new Border
            {
                Background = bg,
                CornerRadius = new CornerRadius(Theme.R1),
                Padding = new Thickness(Theme.S3, Theme.S2 - 1, Theme.S3, Theme.S2 - 1),
                Margin = new Thickness(0, 0, Theme.S2, 0),
                Child = tb,
            };
        }

        private static Border FilterPill(string text)
        {
            var tb = Ui.Txt(text, Theme.TCaption, Theme.FgSecondary, FontWeights.SemiBold);
            tb.TextWrapping = TextWrapping.NoWrap;
            return new Border
            {
                Background = Theme.BgElevated,
                BorderBrush = Theme.Border,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(Theme.R1),
                Padding = new Thickness(Theme.S3, Theme.S1 + 1, Theme.S3, Theme.S1 + 1),
                Margin = new Thickness(0, 0, Theme.S2, 0),
                Child = tb,
            };
        }

        private static Border StatChartCard(string title, string note, UIElement chart)
        {
            var sp = new StackPanel();
            var header = new StackPanel { Orientation = Orientation.Horizontal };
            header.Children.Add(Ui.Txt(title, Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            if (!string.IsNullOrEmpty(note))
            {
                var n = Ui.Txt(note, Theme.TCaption, Theme.FgSecondary);
                n.Margin = new Thickness(Theme.S2, 0, 0, 0);
                header.Children.Add(n);
            }
            sp.Children.Add(header);
            ((FrameworkElement)chart).Margin = new Thickness(0, Theme.S2, 0, 0);
            sp.Children.Add(chart);
            return Ui.Card(sp);
        }

        private static Brush CellBrush(DebriefCell c)
        {
            switch (c)
            {
                case DebriefCell.Earned:   return Theme.Good;
                case DebriefCell.Luck:     return Theme.Warning;
                case DebriefCell.Variance: return Theme.FgSecondary;
                default:                   return Theme.Critical;
            }
        }
    }
}
