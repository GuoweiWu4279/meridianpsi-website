﻿// GuardEngine.cs
//
// Runtime evaluation engine for the Guard protection system.
//
// Responsibilities:
//   • Load / save GuardConfig (list of GuardRules) to guard.xml
//   • Evaluate all rules on every PSI update (called from PushPsiToHud)
//   • Fire the Triggered event when a rule's conditions are met
//   • Fire PauseActivated / PauseExpired events for TradingPause enforcement
//   • Track the pause-lock timer (suppresses rule evaluation during lockout)
//   • Expose active RiskAlert rules for HUD banner rendering
//   • ForceReset — emergency override that clears all runtime state
//
// No NinjaTrader API dependencies — UI dispatch and broker actions are
// handled by MeridianPSI which subscribes to the Triggered / PauseActivated events.

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Serialization;

namespace NinjaTrader.NinjaScript.AddOns
{
    // =========================================================================
    // GuardTrigger — payload delivered with the Triggered event
    // =========================================================================

    public class GuardTrigger
    {
        public GuardRule       Rule    { get; set; }
        public GuardActionType Action  { get; set; }
        public string          Message { get; set; }
    }

    // =========================================================================
    // GuardEngine
    // =========================================================================

    public sealed class GuardEngine
    {
        // ── Data directory (injected at startup, same pattern as other data files)
        private static string _dataDir;
        internal static void SetDataDir(string path)
        {
            if (!string.IsNullOrEmpty(path)) _dataDir = path;
        }
        private static string ConfigPath =>
            Path.Combine(_dataDir ?? "", "guard.xml");

        private static string PauseStatePath =>
            Path.Combine(_dataDir ?? "", "guard_pause_state.dat");

        private static string StrictLockPath =>
            Path.Combine(_dataDir ?? "", "guard_strict_lock.dat");

        private static readonly XmlSerializer _serializer =
            new XmlSerializer(typeof(GuardConfig));

        // ── State ─────────────────────────────────────────────────────────────
        private GuardConfig          _config          = new GuardConfig();

        // Legacy disconnect-only timer — kept for IsDisconnectActive backward compat.
        // _pauseUntil is now the primary timer for both TradingPause and Disconnect.
        private DateTime             _disconnectUntil = DateTime.MinValue;

        // Pause state machine (TradingPause + Disconnect actions share this).
        private DateTime             _pauseUntil      = DateTime.MinValue;
        private GuardRule            _activePauseRule = null;
        private bool                 _pauseExpiredFired = false;  // prevents double-fire

        // ── Strict Lock (commitment device) ──────────────────────────────────
        // A self-set, IRREVERSIBLE window during which every Guard bypass (Emergency
        // Override / End Early) is disabled. Armed when calm; can only be EXTENDED,
        // never shortened or cancelled; auto-releases when the clock passes it. Exit
        // orders are NEVER blocked, so the user can always close positions — strict
        // lock only removes the ability to resume *entering* early.
        private DateTime             _strictLockUntil     = DateTime.MinValue;
        private int                  _strictBypassBlocked = 0;   // accountability counter

        private readonly object      _sync            = new object();
        private Action<string>       _logWarning;

        // ── Public properties ─────────────────────────────────────────────────

        public bool MasterEnabled
        {
            get { lock (_sync) return _config.MasterEnabled; }
            set
            {
                // Strict Lock: turning Guard OFF is exactly the bypass you gave up when you armed
                // the lock. While it is active, refuse to disable and count the attempt
                // (accountability) — the SAME backstop as ForceReset, so EVERY caller is covered,
                // not just the UI toggle. Turning ON is always allowed (more protection).
                bool blocked;
                lock (_sync) { blocked = !value && DateTime.Now < _strictLockUntil; if (blocked) _strictBypassBlocked++; }
                if (blocked) { SaveStrictLock(); return; }
                lock (_sync) _config.MasterEnabled = value;
                SaveConfig();
            }
        }

        /// <summary>True while the legacy Disconnect lock timer is active.</summary>
        public bool IsDisconnectActive
        {
            get { lock (_sync) return DateTime.Now < _disconnectUntil; }
        }

        public TimeSpan DisconnectRemaining
        {
            get
            {
                lock (_sync)
                {
                    var rem = _disconnectUntil - DateTime.Now;
                    return rem > TimeSpan.Zero ? rem : TimeSpan.Zero;
                }
            }
        }

        /// <summary>True while any TradingPause (or legacy Disconnect) lock is active.</summary>
        public bool IsPauseActive
        {
            get { lock (_sync) return DateTime.Now < _pauseUntil; }
        }

        // ── Acknowledge-block state ───────────────────────────────────────────
        // Set by TradeMonitor while an Acknowledge dialog with BlockTradesWhileAcknowledging=true
        // is open.  Causes new entry orders to be cancelled exactly like CancelOrders mode,
        // but does NOT write to disk, does NOT fire PauseActivated, and does NOT interact with
        // the Disconnect/reconnect guard — it is ephemeral UI state only.
        private volatile bool _acknowledgeBlockActive;

        /// <summary>
        /// True while an Acknowledge dialog that has BlockTradesWhileAcknowledging enabled
        /// is currently open.  Entry orders are cancelled during this window.
        /// </summary>
        public bool IsAcknowledgeBlockActive => _acknowledgeBlockActive;

        /// <summary>
        /// Called by TradeMonitor on the UI thread when an Acknowledge dialog opens or closes.
        /// Thread-safe via volatile write; only ever flipped by the UI thread.
        /// </summary>
        public void SetAcknowledgeBlock(bool active) => _acknowledgeBlockActive = active;

        public TimeSpan PauseRemaining
        {
            get
            {
                lock (_sync)
                {
                    var rem = _pauseUntil - DateTime.Now;
                    return rem > TimeSpan.Zero ? rem : TimeSpan.Zero;
                }
            }
        }

        /// <summary>
        /// True when the active pause is a "rest of day" (PauseDurationMinutes == 0)
        /// day-lock rather than a timed pause.
        /// </summary>
        public bool IsDayLockActive
        {
            get
            {
                lock (_sync)
                    return IsPauseActive && _activePauseRule != null
                        && _activePauseRule.EffectivePauseDurationMinutes == 0;
            }
        }

        /// <summary>The rule that activated the current pause, or null if no pause is active.</summary>
        public GuardRule ActivePauseRule
        {
            get { lock (_sync) return _activePauseRule; }
        }

        public IReadOnlyList<GuardRule> Rules
        {
            get { lock (_sync) return _config.Rules.AsReadOnly(); }
        }

        /// <summary>
        /// Returns the names of all currently-active RiskAlert rules whose condition
        /// is still met.  Used by the HUD banner renderer to show a live status string.
        /// Returns an empty list when no RiskAlert is active.
        /// </summary>
        public IReadOnlyList<string> ActiveRiskAlertNames
        {
            get
            {
                lock (_sync)
                    return _config.Rules
                        .Where(r => r.Enabled && r.Action == GuardActionType.RiskAlert && r.RiskAlertActive)
                        .Select(r => r.Name)
                        .ToList()
                        .AsReadOnly();
            }
        }

        /// <summary>True if any enabled RiskAlert rule currently has its condition met.</summary>
        public bool IsRiskAlertActive
        {
            get
            {
                lock (_sync)
                    return _config.Rules.Any(r =>
                        r.Enabled && r.Action == GuardActionType.RiskAlert && r.RiskAlertActive);
            }
        }

        // ── Events ────────────────────────────────────────────────────────────

        /// <summary>
        /// Fired on the calling thread (NT8 event thread) when a rule triggers.
        /// Subscribers must dispatch to the UI thread themselves.
        /// </summary>
        public event Action<GuardTrigger> Triggered;

        /// <summary>
        /// Fired when a TradingPause or Disconnect rule activates the pause state.
        /// The payload is the rule that triggered.  Subscribers must dispatch to
        /// the UI thread themselves.
        /// </summary>
        public event Action<GuardRule> PauseActivated;

        /// <summary>
        /// Fired when the active pause window expires naturally (not by ForceReset).
        /// Called from Tick() which runs on the UI thread.
        /// </summary>
        public event Action PauseExpired;

        // =====================================================================
        // Load / Save
        // =====================================================================

        public static GuardEngine LoadFromFile(Action<string> logWarning = null)
        {
            var engine = new GuardEngine();
            engine._logWarning = logWarning;
            if (string.IsNullOrEmpty(_dataDir) || !File.Exists(ConfigPath))
                return engine;
            try
            {
                using (var sr = new StreamReader(ConfigPath))
                    engine._config = (GuardConfig)_serializer.Deserialize(sr);

                // Backward compat: migrate legacy Countdown action → Acknowledge.
                // CountdownSeconds carries over so the "wait N seconds" behaviour is preserved.
                foreach (var rule in engine._config.Rules)
                {
                    if (rule.Action == GuardActionType.Countdown)
                        rule.Action = GuardActionType.Acknowledge;
                }
            }
            catch (Exception ex)
            {
                logWarning?.Invoke($"[Guard] Failed to load config: {ex.Message}");
            }
            return engine;
        }

        public void SaveConfig()
        {
            if (string.IsNullOrEmpty(_dataDir)) return;
            try
            {
                Directory.CreateDirectory(_dataDir);
                lock (_sync)
                using (var sw = new StreamWriter(ConfigPath))
                    _serializer.Serialize(sw, _config);
            }
            catch (Exception ex)
            {
                _logWarning?.Invoke($"[Guard] SaveConfig failed — rule changes were NOT persisted: {ex.Message}");
            }
        }

        /// <summary>
        /// Persists the active pause end-time and rule name so that a pause
        /// survives an NT8 crash or deliberate close.
        /// Call after any pause activation or expiry.
        /// </summary>
        public void SavePauseState()
        {
            if (string.IsNullOrEmpty(_dataDir)) return;
            try
            {
                Directory.CreateDirectory(_dataDir);
                lock (_sync)
                {
                    if (DateTime.Now >= _pauseUntil)
                    {
                        // Pause is not active — delete any stale file.
                        if (File.Exists(PauseStatePath)) File.Delete(PauseStatePath);
                        return;
                    }
                    // v2 format:
                    //   endTime|@2|action|pauseMode|durMin|autoFlatten|blockReconnect|ruleName
                    // The enforcement fields let a restored pause keep enforcing with the
                    // SAME mode it was created with even if the rule is later deleted /
                    // renamed (see TryRestorePauseState).  ruleName is LAST so a user
                    // name containing '|' cannot corrupt the structured fields.
                    string ruleName = _activePauseRule?.Name ?? "";
                    int action      = (int)(_activePauseRule?.Action ?? GuardActionType.TradingPause);
                    int pauseMode   = (int)(_activePauseRule?.PauseMode ?? PauseModeType.CancelOrders);
                    int durMin      = _activePauseRule?.EffectivePauseDurationMinutes ?? 0;
                    int autoFlatten = (_activePauseRule?.AutoFlattenOnPause ?? false) ? 1 : 0;
                    int blockReconn = (_activePauseRule?.BlockReconnectDuringPause ?? true) ? 1 : 0;
                    File.WriteAllText(PauseStatePath, string.Join("|", new[] {
                        _pauseUntil.ToString("o"), "@2",
                        action.ToString(), pauseMode.ToString(), durMin.ToString(),
                        autoFlatten.ToString(), blockReconn.ToString(), ruleName }));
                }
            }
            catch { }
        }

        /// <summary>
        /// Reads a persisted pause state on AddOn startup.  If the saved pause
        /// end-time is still in the future, restores _pauseUntil and _activePauseRule
        /// so that <see cref="IsPauseActive"/> and <see cref="IsDisconnectPauseActive"/>
        /// return the correct values immediately.
        /// Returns true if a live pause was restored (caller should re-activate
        /// the reconnect guard and refresh the HUD banner).
        /// </summary>
        public bool TryRestorePauseState()
        {
            if (string.IsNullOrEmpty(_dataDir)) return false;
            try
            {
                if (!File.Exists(PauseStatePath)) return false;
                string text = File.ReadAllText(PauseStatePath).Trim();
                if (string.IsNullOrEmpty(text)) return false;

                // Parse both formats: legacy "endTime|ruleName" and v2
                // "endTime|@2|action|pauseMode|durMin|autoFlatten|blockReconnect|ruleName".
                string[] parts = text.Split('|');
                string datePart = parts[0];
                bool v2 = parts.Length >= 8 && parts[1] == "@2";
                GuardActionType sAction = GuardActionType.TradingPause;
                PauseModeType   sMode   = PauseModeType.CancelOrders;
                int  sDurMin = 0; bool sAutoFlatten = false, sBlockReconn = true;
                string ruleName;
                if (v2)
                {
                    int tmp;
                    if (int.TryParse(parts[2], out tmp)) sAction = (GuardActionType)tmp;
                    if (int.TryParse(parts[3], out tmp)) sMode   = (PauseModeType)tmp;
                    int.TryParse(parts[4], out sDurMin);
                    sAutoFlatten = parts[5] == "1";
                    sBlockReconn = parts[6] == "1";
                    ruleName = string.Join("|", parts, 7, parts.Length - 7); // rest (may contain '|')
                }
                else
                {
                    int pipe = text.IndexOf('|');
                    ruleName = pipe >= 0 ? text.Substring(pipe + 1) : "";
                }

                DateTime until = DateTime.Parse(datePart, null,
                    System.Globalization.DateTimeStyles.RoundtripKind);

                if (DateTime.Now >= until)
                {
                    File.Delete(PauseStatePath);
                    return false;
                }

                lock (_sync)
                {
                    _pauseUntil          = until;
                    _pauseExpiredFired   = false;
                    _activePauseRule     = !string.IsNullOrEmpty(ruleName)
                        ? _config.Rules.FirstOrDefault(r => r.Name == ruleName)
                        : null;
                    // If the rule was deleted/renamed since the pause began, reconstruct
                    // a synthetic rule from the persisted enforcement fields (v2) so the
                    // order-cancel guard, the disconnect gate, and the HUD banner all
                    // agree on the original mode.  Before this fix a restored CancelOrders
                    // pause fell back to a Disconnect-mode rule (or null) — the banner
                    // showed "LOCKED" while new entries silently still went through.
                    if (_activePauseRule == null)
                    {
                        if (v2)
                            _activePauseRule = new GuardRule
                            {
                                Name                      = string.IsNullOrEmpty(ruleName) ? "Restored pause" : ruleName,
                                Action                    = sAction,
                                PauseMode                 = sMode,
                                PauseDurationMinutes      = sDurMin,
                                LockMinutes               = sDurMin,
                                AutoFlattenOnPause        = sAutoFlatten,
                                BlockReconnectDuringPause = sBlockReconn,
                                AllowEarlyExit            = false,   // conservative: enforce the full window
                            };
                        else
                            // Legacy v1 file has no persisted mode. Default to a synthetic
                            // CancelOrders pause (block new entries, let exits through) so the HUD
                            // banner and the order-cancel gate AGREE — instead of leaving it null
                            // (banner showed 'LOCKED' while new entries silently still went through)
                            // or guessing Disconnect (which could wrongly imply a broker cut).
                            _activePauseRule = new GuardRule
                            {
                                Name           = string.IsNullOrEmpty(ruleName) ? "Restored pause" : ruleName,
                                Action         = GuardActionType.TradingPause,
                                PauseMode      = PauseModeType.CancelOrders,
                                AllowEarlyExit = false,
                            };
                    }
                }
                return true;
            }
            catch { return false; }
        }

        // =====================================================================
        // Rule management (called from the Guard UI tab)
        // =====================================================================

        public void AddRule(GuardRule rule)
        {
            lock (_sync) _config.Rules.Add(rule);
            SaveConfig();
        }

        public void UpdateRule(GuardRule rule)
        {
            lock (_sync)
            {
                int idx = _config.Rules.FindIndex(r => r.Id == rule.Id);
                if (idx >= 0) _config.Rules[idx] = rule;
            }
            SaveConfig();
        }

        public void DeleteRule(string id)
        {
            lock (_sync) _config.Rules.RemoveAll(r => r.Id == id);
            SaveConfig();
        }

        // =====================================================================
        // Emergency override — clears all runtime state without touching rules
        // =====================================================================

        /// <summary>
        /// Clears every runtime latch, counter, and lock timer without modifying
        /// the rules themselves.  Called by the Emergency Override button in the
        /// Guard settings UI.  The action is logged by the caller (MeridianPSI).
        /// Also fires PauseExpired if a pause was active, so subscribers can
        /// clean up HUD banners and reconnect guards.
        /// </summary>
        public bool ForceReset()
        {
            // Strict Lock: the emergency override is exactly the escape hatch you gave up
            // when you armed the lock. Refuse to clear ANY lock state, count the attempt
            // (accountability), and persist. Covers every caller, not just the button.
            bool strictBlocked;
            lock (_sync) { strictBlocked = DateTime.Now < _strictLockUntil; if (strictBlocked) _strictBypassBlocked++; }
            if (strictBlocked) { SaveStrictLock(); return false; }

            bool wasPauseActive;
            lock (_sync)
            {
                wasPauseActive        = DateTime.Now < _pauseUntil;
                _disconnectUntil      = DateTime.MinValue;
                _pauseUntil           = DateTime.MinValue;
                _activePauseRule      = null;
                _pauseExpiredFired    = false;
                _acknowledgeBlockActive = false;   // clear acknowledge block so orders flow again
                foreach (var r in _config.Rules)
                {
                    // Stamp LastTriggeredUtc to NOW so the rule enters its normal
                    // CooldownMinutes window — prevents it from immediately re-firing
                    // on the next PushPsiToHud evaluation while the underlying condition
                    // is still true.  WasConditionMet=true acts as a secondary gate for
                    // rules whose CooldownMinutes is 0 (IsInCooldown() is always false
                    // in that case, so the latch is the only re-fire barrier).
                    r.LastTriggeredUtc  = DateTime.UtcNow;
                    r.WasConditionMet   = true;
                    r.FirstMetUtc       = DateTime.MinValue;
                    r.ConditionMetCount = 0;
                    r.RiskAlertActive   = false;
                }
            }

            // Notify subscribers that the pause ended (even if forced) so HUD banners
            // and reconnect guards are cleaned up on the calling thread.
            if (wasPauseActive)
            {
                SavePauseState();   // delete persisted file — pause cleared by force-reset
                PauseExpired?.Invoke();
            }
            return true;
        }

        // =====================================================================
        // Strict Lock — the irreversible commitment window
        // =====================================================================

        public bool     IsStrictLockActive { get { lock (_sync) return DateTime.Now < _strictLockUntil; } }
        public DateTime StrictLockUntil    { get { lock (_sync) return _strictLockUntil; } }
        public TimeSpan StrictLockRemaining
        {
            get { lock (_sync) { var r = _strictLockUntil - DateTime.Now; return r > TimeSpan.Zero ? r : TimeSpan.Zero; } }
        }
        public int      StrictBypassBlockedCount { get { lock (_sync) return _strictBypassBlocked; } }

        /// <summary>
        /// Standing Strict Lock setting (commitment device). When on, a triggered pause/disconnect
        /// auto-engages an un-bypassable lockout for <see cref="StrictModeLockMinutes"/>. Turning it
        /// OFF is refused while a lock is currently engaged (that would be the bypass) and counts the
        /// attempt. Inert when off — zero behaviour change.
        /// </summary>
        public bool StrictModeEnabled
        {
            get { lock (_sync) return _config.StrictModeEnabled; }
            set
            {
                bool blocked;
                lock (_sync) { blocked = !value && DateTime.Now < _strictLockUntil; if (blocked) _strictBypassBlocked++; }
                if (blocked) { SaveStrictLock(); return; }
                lock (_sync) _config.StrictModeEnabled = value;
                SaveConfig();
            }
        }

        /// <summary>Lockout length once engaged, in minutes. 0 = rest of day (until 17:00).</summary>
        public int StrictModeLockMinutes
        {
            get { lock (_sync) return _config.StrictModeLockMinutes; }
            set { lock (_sync) _config.StrictModeLockMinutes = value < 0 ? 0 : value; SaveConfig(); }
        }

        /// <summary>
        /// If the standing Strict Lock setting is on, engage an un-bypassable lockout the moment a
        /// pause/disconnect fires: extend (never shorten) the active pause so entries stay frozen for
        /// the whole window, arm the strict lock so every escape is refused, and force Guard on.
        /// No-op when the setting is off — so Guard behaves exactly as before unless the user opted in.
        /// </summary>
        private void MaybeEngageStrictLock(bool isDisconnect)
        {
            lock (_sync)
            {
                if (!_config.StrictModeEnabled) return;
                int mins = _config.StrictModeLockMinutes;
                DateTime until;
                if (mins <= 0)
                {
                    var now = DateTime.Now;
                    until = now.Date.AddHours(17);
                    if (now >= until) until = until.AddDays(1);
                }
                else until = DateTime.Now.AddMinutes(mins);
                if (until < _strictLockUntil) until = _strictLockUntil;          // never shorten
                _strictLockUntil = until;
                if (until > _pauseUntil) _pauseUntil = until;                    // entries frozen the whole lock
                if (isDisconnect && until > _disconnectUntil) _disconnectUntil = until;
                _config.MasterEnabled = true;                                    // invariant: locked ⇒ Guard on
            }
            SaveStrictLock();
            SavePauseState();
            SaveConfig();
        }

        /// <summary>
        /// Arm the strict lock until <paramref name="until"/>. COMMITMENT DEVICE: the lock
        /// can only be EXTENDED — re-arming with an earlier time is ignored — and there is
        /// intentionally NO method to cancel it. It auto-releases when the clock passes the
        /// end time. Safe to call repeatedly.
        /// </summary>
        public void ArmStrictLock(DateTime until)
        {
            // Arming a commitment turns protection ON and extends the lock — you cannot lock
            // yourself into an "off" (unprotected) state. Invariant: strict lock active ⇒ Guard on.
            lock (_sync) { if (until > _strictLockUntil) _strictLockUntil = until; _config.MasterEnabled = true; }
            SaveStrictLock();
            SaveConfig();
        }

        /// <summary>Persist the strict-lock end time + bypass-blocked counter.</summary>
        public void SaveStrictLock()
        {
            if (string.IsNullOrEmpty(_dataDir)) return;
            try
            {
                Directory.CreateDirectory(_dataDir);
                lock (_sync)
                {
                    if (DateTime.Now >= _strictLockUntil)
                    {
                        if (File.Exists(StrictLockPath)) File.Delete(StrictLockPath);
                        return;
                    }
                    File.WriteAllText(StrictLockPath, _strictLockUntil.ToString("o") + "|" + _strictBypassBlocked);
                }
            }
            catch { }
        }

        /// <summary>Restore a strict lock on startup — you cannot escape it by restarting NT8.</summary>
        public void TryRestoreStrictLock()
        {
            if (string.IsNullOrEmpty(_dataDir)) return;
            try
            {
                if (!File.Exists(StrictLockPath)) return;
                string text = File.ReadAllText(StrictLockPath).Trim();
                if (string.IsNullOrEmpty(text)) return;
                string[] parts = text.Split('|');
                DateTime until = DateTime.Parse(parts[0], null, System.Globalization.DateTimeStyles.RoundtripKind);
                int blocked = 0; if (parts.Length > 1) int.TryParse(parts[1], out blocked);
                if (DateTime.Now >= until) { File.Delete(StrictLockPath); return; }
                // Invariant: a restored, still-active lock keeps Guard ON — restarting NT8 must not
                // leave you locked-but-unprotected. Re-applied every startup while the lock holds.
                lock (_sync) { _strictLockUntil = until; _strictBypassBlocked = blocked; _config.MasterEnabled = true; }
            }
            catch { }
        }

        /// <summary>
        /// DEV ONLY. Hard-clears the strict lock (in-memory + the persisted guard_strict_lock.dat)
        /// and then runs a normal ForceReset — deliberately bypassing the strict-lock block. Callers
        /// MUST gate this behind a developer sentinel; it is never wired to a user-facing control.
        /// For resetting test/screenshot state, never a user escape hatch.
        /// </summary>
        internal void DevForceClearStrictLock()
        {
            lock (_sync) { _strictLockUntil = DateTime.MinValue; _strictBypassBlocked = 0; }
            try { if (File.Exists(StrictLockPath)) File.Delete(StrictLockPath); } catch { }
            ForceReset();   // strict lock now cleared → clears pauses/disconnect/latches + fires PauseExpired
        }

        // =====================================================================
        // Tick — called on the UI thread every second (from IntegrityTick)
        // =====================================================================

        /// <summary>
        /// Checks if an active pause window just expired and fires PauseExpired.
        /// Must be called on the UI thread.  Called from IntegrityTick_OnUiThread
        /// (1-second cadence) so the banner countdown stays accurate.
        /// </summary>
        public void Tick()
        {
            bool justExpired = false;
            lock (_sync)
            {
                if (!_pauseExpiredFired && _pauseUntil != DateTime.MinValue && DateTime.Now >= _pauseUntil)
                {
                    _pauseExpiredFired = true;
                    // Re-arm a cooldown==0 Pause/Disconnect rule on natural expiry so a STILL-TRUE
                    // protective condition (session P&L below limit, session-minutes over, etc.) can
                    // re-engage. Without this its WasConditionMet latch stays set and the rule never
                    // fires again — a silent total loss of protection. Cooldown>0 rules keep their
                    // existing re-arm-after-cooldown path untouched.
                    var expired = _activePauseRule;
                    if (expired != null && expired.CooldownMinutes <= 0)
                    {
                        expired.WasConditionMet = false;
                        expired.FirstMetUtc     = DateTime.MinValue;
                    }
                    _activePauseRule   = null;
                    justExpired        = true;
                }
            }
            if (justExpired)
            {
                SavePauseState();   // delete the persisted file — pause fully expired
                PauseExpired?.Invoke();
            }
        }

        // =====================================================================
        // Evaluation — called from PushPsiToHud on every PSI update
        // =====================================================================

        public void Evaluate(GuardContext ctx)
        {
            List<GuardRule> snapshot;
            bool masterEnabled;
            lock (_sync)
            {
                masterEnabled = _config.MasterEnabled;
                snapshot = new List<GuardRule>(_config.Rules);
            }

            if (!masterEnabled) return;

            // While a pause is active (covers both TradingPause and legacy Disconnect),
            // suppress further rule evaluation so we don't pile on more actions.
            // Also suppress while an Acknowledge block is active so a second dialog
            // cannot queue behind the one that is already showing.
            if (IsPauseActive || _acknowledgeBlockActive) return;

            // ── Pass 1: evaluate all rules, updating latches (WasConditionMet,
            //   RiskAlertActive).  Collect the subset that actually want to fire.
            var toFire = new List<GuardRule>();
            foreach (var rule in snapshot)
            {
                if (rule.Evaluate(ctx))
                    toFire.Add(rule);
            }
            if (toFire.Count == 0) return;

            // ── Pass 2: find the highest priority among BLOCKING actions
            //   (Acknowledge / Countdown / TradingPause / Disconnect).
            //   Toast and RiskAlert are non-blocking and always fire regardless.
            //
            //   Priority: TradingPause=Disconnect=5, Countdown=Acknowledge=3, RiskAlert=2, Toast=1
            //
            //   When PSI drops through multiple thresholds in a single tick
            //   without this gate ALL THREE would produce dialogs simultaneously.
            //   The gate ensures only the most severe blocking action is shown;
            //   the lower-priority ones already have WasConditionMet=true so they
            //   will not re-fire unless their condition clears and re-enters.
            int maxBlocking = 0;
            foreach (var rule in toFire)
            {
                int p = ActionPriority(rule.Action);
                if (p >= 3 && p > maxBlocking) maxBlocking = p;
            }

            // ── Pass 3: fire triggers, suppressing blocking actions below the max.
            foreach (var rule in toFire)
            {
                int p = ActionPriority(rule.Action);

                // Non-blocking (Toast=1, RiskAlert=2): always fire.
                // Blocking (>=3): only fire if at the max priority level.
                if (p >= 3 && p < maxBlocking)
                    continue;

                // Mark cooldown for rules that actually fire.
                rule.LastTriggeredUtc = DateTime.UtcNow;

                string message = string.IsNullOrWhiteSpace(rule.CustomMessage)
                    ? BuildDefaultMessage(rule, ctx)
                    : rule.CustomMessage;

                if (rule.Action == GuardActionType.TradingPause)
                {
                    // Activate pause state machine.
                    ActivatePause(rule);
                    MaybeEngageStrictLock(false);   // standing Strict Lock → un-bypassable lockout

                    Triggered?.Invoke(new GuardTrigger
                    {
                        Rule    = rule,
                        Action  = rule.Action,
                        Message = message,
                    });
                    PauseActivated?.Invoke(rule);
                    return;   // pause suppresses all further processing
                }

                if (rule.Action == GuardActionType.Disconnect)
                {
                    // Legacy action: activate pause with Disconnect semantics.
                    // Also set _disconnectUntil for IsDisconnectActive backward compat.
                    int lockMins = Math.Max(1, rule.LockMinutes);
                    lock (_sync)
                    {
                        _disconnectUntil = DateTime.Now.AddMinutes(lockMins);
                        _pauseUntil      = _disconnectUntil;
                        _activePauseRule = rule;
                        _pauseExpiredFired = false;
                    }
                    SavePauseState();
                    MaybeEngageStrictLock(true);    // standing Strict Lock → un-bypassable lockout

                    Triggered?.Invoke(new GuardTrigger
                    {
                        Rule    = rule,
                        Action  = rule.Action,
                        Message = message,
                    });
                    PauseActivated?.Invoke(rule);
                    return;
                }

                Triggered?.Invoke(new GuardTrigger
                {
                    Rule    = rule,
                    Action  = rule.Action,
                    Message = message,
                });
            }
        }

        private void ActivatePause(GuardRule rule)
        {
            DateTime until;
            int pauseMins = rule.EffectivePauseDurationMinutes;
            if (pauseMins <= 0)
            {
                // Rest-of-day: expire at 17:00 local time (or next day if already past 17:00).
                var today = DateTime.Now;
                until = today.Date.AddHours(17);
                if (today >= until) until = until.AddDays(1);
            }
            else
            {
                until = DateTime.Now.AddMinutes(pauseMins);
            }

            lock (_sync)
            {
                _pauseUntil        = until;
                _activePauseRule   = rule;
                _pauseExpiredFired = false;
            }
            SavePauseState();
        }

        private static int ActionPriority(GuardActionType a)
        {
            switch (a)
            {
                case GuardActionType.TradingPause: return 5;
                case GuardActionType.Disconnect:   return 5;
                case GuardActionType.Countdown:    return 4;  // legacy, mapped to Acknowledge at load
                case GuardActionType.Acknowledge:  return 3;
                case GuardActionType.RiskAlert:    return 2;
                case GuardActionType.Toast:        return 1;
                default:                           return 0;
            }
        }

        /// <summary>Manually clear the disconnect lock (user override).</summary>
        public void ClearDisconnect()
        {
            lock (_sync)
            {
                _disconnectUntil = DateTime.MinValue;
                // Don't clear _pauseUntil here — use ForceReset() for that.
            }
        }

        // =====================================================================
        // Helpers
        // =====================================================================

        private static string BuildDefaultMessage(GuardRule rule, GuardContext ctx)
        {
            var parts = new System.Text.StringBuilder();
            parts.AppendLine($"Guard: {rule.Name}");
            parts.AppendLine();
            foreach (var c in rule.Conditions)
            {
                switch (c.Type)
                {
                    case GuardConditionType.PsiBelow:
                        parts.AppendLine($"• PSI {ctx.Psi:F0} dropped below your threshold of {c.Threshold}");
                        break;
                    case GuardConditionType.ConsecutiveLossesAtLeast:
                        double streak = rule.MinLossUsdForStreak > 0
                            ? ctx.ConsecutiveLossesAboveMin : ctx.ConsecutiveLosses;
                        string filterNote = rule.MinLossUsdForStreak > 0
                            ? $" (losses > ${rule.MinLossUsdForStreak:F0})" : "";
                        parts.AppendLine($"• {streak:F0} consecutive losses{filterNote} (your limit: {c.Threshold})");
                        break;
                    case GuardConditionType.SessionPnlBelow:
                        parts.AppendLine($"• Session P&L −${Math.Abs(ctx.SessionPnl):F0} (your limit: −${c.Threshold})");
                        break;
                    case GuardConditionType.SessionMinutesOver:
                        parts.AppendLine($"• {ctx.SessionMinutes:F0} min trading (your limit: {c.Threshold} min)");
                        break;
                    case GuardConditionType.UnrealizedPnlBelow:
                        parts.AppendLine($"• Floating loss −${Math.Abs(ctx.UnrealizedPnl):F0} (your limit: −${c.Threshold})");
                        break;
                    case GuardConditionType.SingleTradeLossExceeds:
                        parts.AppendLine($"• Last trade lost ${Math.Abs(ctx.LastTradePnl):F0} (your limit: ${c.Threshold})");
                        break;
                }
            }
            parts.AppendLine();

            string actionDesc;
            switch (rule.Action)
            {
                case GuardActionType.TradingPause:
                    actionDesc = rule.PauseMode == PauseModeType.CancelOrders
                        ? $"New entries blocked for {rule.PauseDurationMinutes} min."
                        : $"Broker disconnected for {rule.PauseDurationMinutes} min.";
                    break;
                case GuardActionType.Disconnect:
                    actionDesc = $"Disconnecting for {rule.LockMinutes} min.";
                    break;
                default:
                    actionDesc = "This is a rule you set for yourself.";
                    break;
            }
            parts.Append(actionDesc);
            return parts.ToString().TrimEnd();
        }
    }
}
