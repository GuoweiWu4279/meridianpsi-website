// GuardOrderPolicy.cs
//
// The SAFETY BOUNDARY for Guard order enforcement, extracted as a pure decision
// so it can be unit-tested and replayed against real recorded order streams.
//
// Why this exists as its own file:
//   The live enforcement lives in MeridianPSI.OnOrderUpdate (TradeMonitor.cs),
//   which is saturated with NinjaTrader UI/account dependencies and cannot be
//   compiled or executed outside NT8. But the *decision* — "is this order a new
//   entry that a pause/acknowledge-block should cancel, or an exit that must
//   ALWAYS pass?" — is pure logic over the order's action, OCO group, and state.
//   Pulling it here lets the standalone test island (engine-tests) exercise the
//   EXACT code that runs live, including the critical guarantee that EXIT orders
//   are never cancelled (so a paused trader can always close a position).
//
// Only NinjaTrader.Cbi.OrderAction / OrderState are referenced — both are plain
// enums, stubbed in the test island exactly like Cbi.Account already is. No
// behaviour change: OnOrderUpdate and IsNewEntryOrder now delegate here.

namespace NinjaTrader.NinjaScript.AddOns
{
    public static class GuardOrderPolicy
    {
        /// <summary>
        /// True for orders that OPEN or ADD TO a position; false for bracket
        /// TP/SL legs and for close/flatten orders.
        ///
        /// SAFETY BOUNDARY — exits must never be classified as entries:
        ///   • OrderAction.Sell and OrderAction.BuyToCover CLOSE positions.
        ///     Cancelling them would trap a paused trader in a live position.
        ///   • Bracket legs always carry a non-empty OCO group — never cancel them.
        ///   • Only Buy and SellShort unambiguously represent new entries.
        /// </summary>
        public static bool IsNewEntryOrder(NinjaTrader.Cbi.OrderAction action, string oco)
        {
            bool isEntryAction = action == NinjaTrader.Cbi.OrderAction.Buy
                              || action == NinjaTrader.Cbi.OrderAction.SellShort;
            bool isBracket     = !string.IsNullOrEmpty(oco);
            return isEntryAction && !isBracket;
        }

        /// <summary>
        /// The full enforcement decision used by OnOrderUpdate: cancel this order
        /// only when (a) it is at the entry-submission state, (b) a CancelOrders
        /// pause OR an acknowledge-block is active, and (c) it is a new entry.
        ///
        /// <paramref name="state"/> gates on the transition NT8 actually fires:
        /// Initialized in Live/Sim, Working in Playback (NT8 skips Initialized in
        /// replay). Exit and bracket orders return false regardless of pause state.
        /// </summary>
        public static bool ShouldCancelEntry(
            NinjaTrader.Cbi.OrderAction action,
            string oco,
            NinjaTrader.Cbi.OrderState state,
            bool pauseActiveCancelMode,
            bool ackBlockActive)
        {
            bool isNewEntryState = state == NinjaTrader.Cbi.OrderState.Initialized   // Live / Sim
                                || state == NinjaTrader.Cbi.OrderState.Working;      // Playback
            return isNewEntryState
                && (pauseActiveCancelMode || ackBlockActive)
                && IsNewEntryOrder(action, oco);
        }
    }
}
