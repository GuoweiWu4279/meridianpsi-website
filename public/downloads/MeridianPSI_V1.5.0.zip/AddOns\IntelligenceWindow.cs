// IntelligenceWindow.cs
//
// PSI Intelligence tab — behavioral analytics page.
// Sections (top to bottom, all scrollable):
//   1. Pre-Session Risk Brief
//   2. Monthly Digest  (◀ MMMM YYYY ▶)
//   3. PSI × Performance Correlation table
//   4. Weekday Heatmap
//   5. Progress Trend (6-month sparkline)
//   6. Crash Triggers ranking
//
// This is a Window subclass so MeridianDashboard can transplant its body
// via TransplantWindowBody(), identical to HistoryWindow and SessionReportWindow.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal sealed class IntelligenceWindow : Window
    {
        // ── Data ──────────────────────────────────────────────────────────────
        private readonly List<SessionHistoryEntry> _sessions;

        // ── Navigation state ─────────────────────────────────────────────────
        private DateTime _currentMonth;
        private int      _view      = 0;   // sub-tab: 0=Insights 1=Stats

        // Insights custom analysis range (optional). When both are set, the analysis
        // cards narrow to [start,end]; otherwise each card uses its own natural window.
        private DateTime? _rangeStart, _rangeEnd;
        private bool      _rangeOpen;      // is the range editor expanded

        // ── Live rebuild targets ──────────────────────────────────────────────
        private StackPanel _root;   // rebuilt on month navigation

        // ── Palette: mapped to the shared Theme tokens so Intel matches the rest of
        // the app. The old local set used iOS-vivid greens/yellows/reds that read
        // glaring and "sharp" next to the calmer Theme ramp on the Home page.
        private static readonly Brush FgPrimary   = Theme.FgPrimary;
        private static readonly Brush FgSecondary = Theme.FgSecondary;
        private static readonly Brush FgHint      = Theme.FgHint;
        private static readonly Brush FgAccent    = Theme.Accent;
        private static readonly Brush BgWindow    = Theme.BgWindow;
        private static readonly Brush BgCard      = Theme.BgCard;
        private static readonly Brush BgHeader    = Theme.BgElevated;
        private static readonly Color ColStable      = Theme.ColorOf(Theme.Stable);    // emerald (was 48,209,88)
        private static readonly Color ColYellowGreen = Theme.ColorOf(Theme.Caution);   // muted gold (was 163,213,72)
        private static readonly Color ColCaution     = Theme.ColorOf(Theme.Warning);   // amber (was pure 255,214,0)
        private static readonly Color ColCritical    = Theme.ColorOf(Theme.Critical);  // controlled red (was 255,69,58)

        // Composure colour aligned to the canonical PSI zone bands
        // (SessionData.ZoneOf — 88/72/55, same as the live HUD & alerts).
        private static Color CompColor(double pct) =>
            pct >= 88 ? ColStable :
            pct >= 72 ? ColYellowGreen :
            pct >= 55 ? ColCaution : ColCritical;
        private static readonly Color ColAccent   = Color.FromRgb( 16, 185, 129);

        private static readonly string[] DayShort = { "Mon", "Tue", "Wed", "Thu", "Fri" };

        // =====================================================================
        // Constructor
        // =====================================================================

        internal IntelligenceWindow(List<SessionHistoryEntry> sessions)
        {
            _sessions     = sessions ?? new List<SessionHistoryEntry>();
            _currentMonth = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);

            WindowStyle        = WindowStyle.None;
            AllowsTransparency = true;
            Background         = Brushes.Transparent;
            ResizeMode         = ResizeMode.NoResize;
            ShowInTaskbar      = false;
            Title              = "PSI Intelligence";
            Width              = 480;
            Height             = 640;

            var outer = new Border
            {
                CornerRadius    = new CornerRadius(14),
                Background      = BgWindow,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(44) });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // ── Header ───────────────────────────────────────────────────────
            var hdr     = new Border { Background = BgHeader };
            var hdrGrid = new Grid();
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            hdrGrid.Children.Add(new TextBlock
            {
                Text              = "PSI Intelligence",
                FontSize          = 12,
                FontFamily        = Theme.Font,
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(14, 0, 0, 0),
            });

            var closeBtn = MakeHeaderBtn("✕");
            closeBtn.MouseLeftButtonDown += (_, e) => { e.Handled = true; Close(); };
            Grid.SetColumn(closeBtn, 1);
            hdrGrid.Children.Add(closeBtn);

            hdr.Child = hdrGrid;
            Grid.SetRow(hdr, 0);
            root.Children.Add(hdr);

            // ── Scrollable body ───────────────────────────────────────────────
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Padding = new Thickness(12, 8, 12, 16),
            };

            _root = new StackPanel { Orientation = Orientation.Vertical };
            scroll.Content = _root;
            Grid.SetRow(scroll, 1);
            root.Children.Add(scroll);

            outer.Child = root;
            Content     = outer;

            BuildPage();
        }

        // Preview hook for the offline UI harness only: switch sub-tab / timeframe + rebuild.
        internal void PreviewView(int view, int timeframe = -1,
            DateTime? rangeStart = null, DateTime? rangeEnd = null, bool rangeOpen = false)
        {
            _view = view;
            _rangeStart = rangeStart; _rangeEnd = rangeEnd; _rangeOpen = rangeOpen;
            BuildPage();
        }

        // =====================================================================
        // Page builder — called on initial render and on month navigation
        // =====================================================================

        private void BuildPage()
        {
            _root.Children.Clear();

            var all = _sessions.Where(s => s.TotalTrades > 0).ToList();

            _root.Children.Add(BuildViewToggle());

            // Stats sub-tab keeps the period buckets — "this month vs all" ratios are
            // meaningful there. Insights does NOT use them: forcing one global window onto
            // cards with different natural scales (today's risk vs a multi-month trend) is
            // what made the tab flip between empty and full. Insights cards default to ALL
            // your data (each applies its own minimum); an optional custom range narrows them.
            if (_view == 1)
            {
                // Stats uses the SAME custom-range control as Insights (was: fixed
                // Today/Month/6mo/All buckets, which couldn't do an arbitrary window).
                var sData = ApplyCustomRange(all);
                _root.Children.Add(BuildRangeControl(all, sData));
                _root.Children.Add(BuildStatsPanel(sData));
                return;
            }

            // Insights sub-tab. `data` = all sessions unless the user set a custom range.
            var data = ApplyCustomRange(all);
            _root.Children.Add(BuildRangeControl(all, data));

            // Composed top-down, not tiled:
            //   HERO  — one full-width band: today's risk (action) + composure standing/trend.
            //   ROW 1 — this month (digest) | your leaks (worst sessions).
            //   ROW 2 — the deeper descriptive analytics: PSI×perf | weekday.
            // Cards in a row share height (CaptureSection stretches the card) so there are
            // no ragged half-empty columns.
            BuildHeroBand(all);   // "Today's" risk + trend = always current; not the retrospective range

            var saved   = _root;
            var digest  = CaptureSection(() => BuildMonthlyDigest(all));   // ALL → month-over-month delta is never starved
            var crash   = CaptureSection(() => BuildCrashTriggers(data));  // ↓ these are the retrospective cards the range scopes
            var psiperf = CaptureSection(() => BuildPsiPerfCorrelation(data));
            var weekday = CaptureSection(() => BuildWeekdayHeatmap(data));
            _root = saved;

            var r1 = IntelRow(18, digest, crash);    r1.Margin = new Thickness(0, 18, 0, 0);
            _root.Children.Add(r1);
            var r2 = IntelRow(18, psiperf, weekday); r2.Margin = new Thickness(0, 18, 0, 0);
            _root.Children.Add(r2);
        }

        // Optional custom analysis range for the Insights cards. Default (no range) =
        // all data, so the tab always shows everything it can. A set range narrows the
        // analysis cards (each still applies its own minimum + says so if unmet).
        private System.Collections.Generic.List<SessionHistoryEntry> ApplyCustomRange(
            System.Collections.Generic.List<SessionHistoryEntry> all)
        {
            if (_rangeStart == null || _rangeEnd == null) return all;
            DateTime a = _rangeStart.Value.Date, b = _rangeEnd.Value.Date;
            if (a > b) { var t = a; a = b; b = t; }
            return all.Where(s => s.Date.Date >= a && s.Date.Date <= b).ToList();
        }

        // The range control: a status line ("Showing all N sessions" / "Analysis range …")
        // plus a collapsible From/To editor. Replaces the old Today/Month/6mo/All buckets,
        // which forced one window onto cards with different natural scales.
        private FrameworkElement BuildRangeControl(
            System.Collections.Generic.List<SessionHistoryEntry> all,
            System.Collections.Generic.List<SessionHistoryEntry> data)
        {
            bool hasRange = _rangeStart != null && _rangeEnd != null;
            DateTime earliest = all.Count > 0 ? all.Min(s => s.Date).Date : DateTime.Today;
            var font = Theme.Font;
            int n = data.Count;

            var wrap = new StackPanel { Margin = new Thickness(0, 0, 0, 14) };

            var row = new StackPanel { Orientation = Orientation.Horizontal };
            row.Children.Add(new TextBlock
            {
                Text       = hasRange ? $"Analysis range  ·  {_rangeStart:MMM d, yyyy} – {_rangeEnd:MMM d, yyyy}"
                                      : $"Showing all {n} session{(n == 1 ? "" : "s")}",
                FontSize   = 12, FontFamily = font, FontWeight = FontWeights.SemiBold,
                Foreground = hasRange ? Theme.Accent : FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            });
            if (hasRange)
                row.Children.Add(new TextBlock
                {
                    Text = $"  ·  {n} session{(n == 1 ? "" : "s")}", FontSize = 12, FontFamily = font,
                    Foreground = FgSecondary, VerticalAlignment = VerticalAlignment.Center,
                });

            var toggle = RangeLink(_rangeOpen ? "Close" : (hasRange ? "Edit" : "Custom range  ▾"), Theme.Accent);
            toggle.Margin = new Thickness(14, 0, 0, 0);
            toggle.MouseLeftButtonDown += (_, e) => { e.Handled = true; _rangeOpen = !_rangeOpen; BuildPage(); };
            row.Children.Add(toggle);

            if (hasRange)
            {
                var clear = RangeLink("Clear", FgHint);
                clear.Margin = new Thickness(12, 0, 0, 0);
                clear.MouseLeftButtonDown += (_, e) => { e.Handled = true; _rangeStart = _rangeEnd = null; _rangeOpen = false; BuildPage(); };
                row.Children.Add(clear);
            }
            wrap.Children.Add(row);

            if (_rangeOpen)
            {
                var ed = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 12, 0, 0) };
                DateTime fromDate = _rangeStart ?? earliest;
                DateTime toDate   = _rangeEnd ?? DateTime.Today;
                var from = MakeDateField(fromDate, d => fromDate = d);
                var to   = MakeDateField(toDate,   d => toDate   = d);
                ed.Children.Add(RangeFieldLabel("From")); ed.Children.Add(from);
                ed.Children.Add(RangeFieldLabel("To"));   ed.Children.Add(to);

                var apply = new Border
                {
                    Background = Theme.AccentSolid, CornerRadius = new CornerRadius(7),
                    Padding = new Thickness(16, 6, 16, 6), Margin = new Thickness(6, 0, 0, 0),
                    Cursor = System.Windows.Input.Cursors.Hand, VerticalAlignment = VerticalAlignment.Center,
                    Child = new TextBlock { Text = "Apply", FontFamily = font, FontSize = 12, FontWeight = FontWeights.SemiBold, Foreground = Theme.AccentInk },
                };
                apply.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    _rangeStart = fromDate <= toDate ? fromDate : toDate;
                    _rangeEnd   = fromDate <= toDate ? toDate   : fromDate;
                    _rangeOpen  = false;
                    BuildPage();
                };
                ed.Children.Add(apply);
                wrap.Children.Add(ed);
            }
            return wrap;
        }

        private static TextBlock RangeLink(string text, Brush color) => new TextBlock
        {
            Text = text, FontSize = 12, FontFamily = Theme.Font, FontWeight = FontWeights.SemiBold,
            Foreground = color, VerticalAlignment = VerticalAlignment.Center, Cursor = System.Windows.Input.Cursors.Hand,
        };

        private static FrameworkElement RangeFieldLabel(string t) => new TextBlock
        {
            Text = t, FontSize = 12, FontFamily = Theme.Font, Foreground = FgSecondary,
            VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 6, 0),
        };

        // A dark, on-brand date field (WPF's DatePicker forces a white chrome that clashes
        // with the theme). Pre-filled in ISO format so the format is self-evident.
        private static TextBox MakeRangeInput(DateTime initial) => new TextBox
        {
            Text            = initial.ToString("yyyy-MM-dd"),
            Width           = 104,
            Margin          = new Thickness(0, 0, 12, 0),
            FontFamily      = Theme.Font,
            FontSize        = 12,
            Padding         = new Thickness(8, 5, 8, 5),
            Background      = Theme.BgElevated,
            Foreground      = FgPrimary,
            CaretBrush      = FgPrimary,
            BorderBrush     = Theme.Border,
            BorderThickness = new Thickness(1),
            VerticalContentAlignment = VerticalAlignment.Center,
        };

        // A dark, on-brand date field that opens a themed calendar popup on click.
        // (WPF's DatePicker forces white chrome that clashes; a bare Calendar in a dark
        // Popup stays on-theme.) onPick is invoked with the chosen date.
        private FrameworkElement MakeDateField(DateTime initial, Action<DateTime> onPick)
        {
            var label = new TextBlock { Text = initial.ToString("MMM d, yyyy"), FontFamily = Theme.Font, FontSize = 12, Foreground = FgPrimary, VerticalAlignment = VerticalAlignment.Center };
            var glyph = new TextBlock { Text = "", FontFamily = new FontFamily("Segoe MDL2 Assets"), FontSize = 12, Foreground = FgHint, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(8, 0, 0, 0) };
            var inner = new StackPanel { Orientation = Orientation.Horizontal };
            inner.Children.Add(label); inner.Children.Add(glyph);
            var field = new Border
            {
                Background = Theme.BgElevated, BorderBrush = Theme.Border, BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(7), Padding = new Thickness(10, 6, 10, 6),
                Margin = new Thickness(0, 0, 12, 0), Cursor = System.Windows.Input.Cursors.Hand,
                VerticalAlignment = VerticalAlignment.Center, Child = inner,
            };
            var cal = new Calendar { Background = Theme.BgElevated, Foreground = FgPrimary, BorderThickness = new Thickness(0), SelectedDate = initial, DisplayDate = initial };
            var pop = new System.Windows.Controls.Primitives.Popup
            {
                PlacementTarget = field, Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom,
                StaysOpen = false, AllowsTransparency = true,
                Child = new Border { Background = Theme.BgElevated, BorderBrush = Theme.Border, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(8), Padding = new Thickness(6), Effect = Ui.CardShadow, Child = cal },
            };
            cal.SelectedDatesChanged += (_, __) =>
            {
                if (cal.SelectedDate.HasValue)
                {
                    var dd = cal.SelectedDate.Value.Date;
                    label.Text = dd.ToString("MMM d, yyyy");
                    onPick(dd);
                    pop.IsOpen = false;
                }
            };
            field.MouseLeftButtonDown += (_, e) => { e.Handled = true; if (!pop.IsOpen) field.Dispatcher.BeginInvoke(new Action(() => { pop.IsOpen = true; }), System.Windows.Threading.DispatcherPriority.Input); };
            field.MouseEnter += (_, __) => field.BorderBrush = Theme.Tint(Theme.Accent, 90);
            field.MouseLeave += (_, __) => field.BorderBrush = Theme.Border;
            var host = new Grid();
            host.Children.Add(field);
            host.Children.Add(pop);
            return host;
        }

        // Subtle fade-in when switching the Insights/Stats sub-tab (smooth transition).
        private void FadeInRoot()
        {
            if (_root == null) return;
            var fade = new System.Windows.Media.Animation.DoubleAnimation(0.0, 1.0, new Duration(TimeSpan.FromMilliseconds(160)))
            { EasingFunction = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut } };
            _root.BeginAnimation(UIElement.OpacityProperty, fade);
        }

        private FrameworkElement CaptureSection(System.Action build)
        {
            var p = new StackPanel(); _root = p;
            try { build(); } catch { }
            if (p.Children.Count < 2) return p;
            // Re-flow [header…, card] into a grid where the LAST element (the card)
            // takes a star row, so it STRETCHES to the row height its IntelRow column
            // is given — paired cards stay equal-height instead of floating at the top.
            var els = new System.Collections.Generic.List<UIElement>();
            foreach (UIElement c in p.Children) els.Add(c);
            p.Children.Clear();
            var g = new Grid();
            for (int i = 0; i < els.Count; i++)
                g.RowDefinitions.Add(new RowDefinition {
                    Height = i == els.Count - 1 ? new GridLength(1, GridUnitType.Star) : GridLength.Auto });
            for (int i = 0; i < els.Count; i++) { Grid.SetRow(els[i], i); g.Children.Add(els[i]); }
            return g;
        }

        private static void PlaceSection(Grid g, FrameworkElement el, int row, int col)
        {
            el.Margin = new Thickness(col == 0 ? 0 : 7, row == 0 ? 0 : 14, col == 2 ? 0 : 7, 0);
            el.VerticalAlignment = VerticalAlignment.Top;
            Grid.SetRow(el, row); Grid.SetColumn(el, col); g.Children.Add(el);
        }

        private static FrameworkElement IntelRow(double gap, params FrameworkElement[] cards)
            => IntelRow(gap, null, cards);

        // Tile row with optional column weights. Cards STRETCH to the row's height so
        // paired cards stay equal-height (no ragged half-empty columns). weights[i]
        // sets column i's star size (default 1) — lets the hero lean wider on one side.
        private static FrameworkElement IntelRow(double gap, double[] weights, params FrameworkElement[] cards)
        {
            var present = new System.Collections.Generic.List<FrameworkElement>();
            foreach (var c in cards) if (c != null) present.Add(c);
            if (present.Count == 0) return new StackPanel();
            var g = new Grid();
            for (int i = 0; i < present.Count; i++)
            {
                if (i > 0) g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(gap) });
                double w = (weights != null && i < weights.Length) ? weights[i] : 1.0;
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(w, GridUnitType.Star) });
            }
            int col = 0;
            foreach (var c in present)
            {
                c.VerticalAlignment = VerticalAlignment.Stretch;
                Grid.SetColumn(c, col); g.Children.Add(c); col += 2;
            }
            return g;
        }

        // =====================================================================
        // Sub-view tabs: Insights | Stats
        // =====================================================================
        private static readonly string[] _viewLabels = { "Insights", "Stats" };
        private FrameworkElement BuildViewToggle()
        {
            var seg = new Border
            {
                Background = Theme.BgElevated, BorderBrush = Theme.Border, BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(10), Padding = new Thickness(3),
                HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 0, 0, 10),
            };
            var row = new StackPanel { Orientation = Orientation.Horizontal };
            for (int i = 0; i < _viewLabels.Length; i++)
            {
                int idx = i; bool on = _view == i;
                var b = new Border
                {
                    Background = on ? Theme.AccentSolid : System.Windows.Media.Brushes.Transparent,
                    CornerRadius = new CornerRadius(7), Padding = new Thickness(16, 6, 16, 6),
                    Cursor = System.Windows.Input.Cursors.Hand,
                };
                b.Child = new TextBlock { Text = _viewLabels[i], FontFamily = Theme.Font, FontSize = 12, FontWeight = FontWeights.SemiBold, Foreground = on ? Theme.AccentInk : Theme.FgSecondary };
                b.MouseLeftButtonDown += (_, e) => { e.Handled = true; _view = idx; BuildPage(); FadeInRoot(); CallbackRecorder.UiEvent("intel", "view_switch", _viewLabels[idx]); };
                row.Children.Add(b);
            }
            seg.Child = row;
            return seg;
        }

        // =====================================================================
        // Stats panel — ratios + the Meridian "discipline edge" (session-level)
        // =====================================================================
        private FrameworkElement BuildStatsPanel(List<SessionHistoryEntry> s)
        {
            var root = new StackPanel();
            if (s == null || s.Count == 0)
            {
                root.Children.Add(Ui.Txt("No sessions in this range yet — your ratios appear here once you've traded a few.", Theme.TBody, Theme.FgSecondary));
                return root;
            }

            // ── Day / session level (from history.xml) ────────────────────────
            int    sessions = s.Count;
            double pnl      = s.Sum(x => x.TotalPnl);
            double perSess  = pnl / sessions;
            int    winDays  = s.Count(x => x.TotalPnl > 0);
            int    lossDays = s.Count(x => x.TotalPnl < 0);
            double dayWin   = sessions > 0 ? 100.0 * winDays / sessions : 0;
            var daily = s.OrderBy(x => x.Date).Select(x => x.TotalPnl).ToList();
            double peak = 0, cum = 0, maxDD = 0; int ddDur = 0, ddRun = 0;
            foreach (var d in daily)
            {
                cum += d;
                if (cum >= peak) { peak = cum; ddRun = 0; }
                else { ddRun++; if (ddRun > ddDur) ddDur = ddRun; }
                double dd = peak - cum; if (dd > maxDD) maxDD = dd;
            }
            double meanDay  = daily.Count > 0 ? daily.Average() : 0;
            double stdDay   = Std(daily);
            double sharpe   = stdDay > 0.01 ? meanDay / stdDay : 0;
            double dnStd    = DownStd(daily);
            double sortino  = dnStd > 0.01 ? meanDay / dnStd : 0;
            double recovery = maxDD > 0.01 ? pnl / maxDD : 0;

            // ── Trade level (loaded from per-session detail files) ────────────
            var    fills   = ClosingFills(s);                // per-trade detail (P&L + hold)
            var    tp      = fills.Select(f => f.Pnl).ToList();
            int    tn      = tp.Count;
            var    winsL   = tp.Where(p => p > 0).ToList();
            var    lossL   = tp.Where(p => p < 0).ToList();
            int    tWins   = winsL.Count, tLoss = lossL.Count;
            double tWinR   = tn > 0 ? 100.0 * tWins / tn : 0;
            double avgWin  = tWins > 0 ? winsL.Average() : 0;
            double avgLoss = tLoss > 0 ? Math.Abs(lossL.Average()) : 0;
            double payoff  = avgLoss > 0.01 ? avgWin / avgLoss : 0;
            double expR    = tn > 0 ? tp.Average() : 0;
            double grossW  = winsL.Sum(), grossL = Math.Abs(lossL.Sum());
            double pf      = grossL > 0.01 ? grossW / grossL : (grossW > 0 ? 99 : 0);
            double Wf      = tn > 0 ? (double)tWins / tn : 0;
            double kelly   = payoff > 0.01 ? (Wf - (1 - Wf) / payoff) : 0;
            double bigWin  = winsL.Count > 0 ? winsL.Max() : 0;
            double bigLoss = lossL.Count > 0 ? lossL.Min() : 0;
            int    mWin = 0, mLoss = 0, cw = 0, cl = 0;
            foreach (var p in tp)
            {
                if (p > 0) { cw++; cl = 0; if (cw > mWin) mWin = cw; }
                else if (p < 0) { cl++; cw = 0; if (cl > mLoss) mLoss = cl; }
            }
            bool haveTrades = tn > 0;

            // ── Discipline edge (composed vs tilted) ──────────────────────────
            var comp = s.Where(x => x.ComposurePct >= SessionData.ComposureStableThreshold).ToList();
            var tilt = s.Where(x => x.ComposurePct <  SessionData.ComposureStableThreshold).ToList();
            double compAvg   = comp.Count > 0 ? comp.Average(x => x.TotalPnl) : 0;
            double tiltAvg   = tilt.Count > 0 ? tilt.Average(x => x.TotalPnl) : 0;
            int    compTr    = comp.Sum(x => x.TotalTrades), tiltTr = tilt.Sum(x => x.TotalTrades);
            double compWin   = compTr > 0 ? 100.0 * comp.Sum(x => x.WinTrades) / compTr : 0;
            double tiltWin   = tiltTr > 0 ? 100.0 * tilt.Sum(x => x.WinTrades) / tiltTr : 0;
            double compTrPer = comp.Count > 0 ? (double)compTr / comp.Count : 0;
            double tiltTrPer = tilt.Count > 0 ? (double)tiltTr / tilt.Count : 0;
            double corr      = StatPearson(s);

            string na = "—";

            // Hero: the discipline edge (the differentiator no other platform shows).
            root.Children.Add(StatHero(compAvg, tiltAvg, comp.Count, tilt.Count));

            // Equity curve (cumulative session P&L).
            var eq = EquityCurve(s); eq.Margin = new Thickness(0, 14, 0, 0);
            root.Children.Add(eq);

            // Performance (trade-level).
            root.Children.Add(StatHeader("Performance", 18));
            root.Children.Add(Ui.TileGrid(3, 12,
                StatCard("Win rate",      haveTrades ? tWinR.ToString("0") + "%" : na,            haveTrades ? tWins + " / " + tn + " trades" : "no trade detail", Theme.FgPrimary),
                StatCard("Profit factor", haveTrades ? (pf >= 99 ? "∞" : pf.ToString("0.00")) : na, "$ won ÷ $ lost",            pf >= 1 ? Theme.Good : Theme.Bad),
                StatCard("Expectancy",    haveTrades ? Usd(expR) : na,                            "avg $ per trade",                expR >= 0 ? Theme.Good : Theme.Bad),
                StatCard("Avg win",       haveTrades ? Usd(avgWin) : na,                          tWins + " winners",               Theme.Good),
                StatCard("Avg loss",      haveTrades ? "-$" + avgLoss.ToString("0") : na,         tLoss + " losers",                Theme.Bad),
                StatCard("Payoff ratio",  haveTrades && payoff > 0 ? payoff.ToString("0.00") : na, "avg win ÷ avg loss",       payoff >= 1 ? Theme.Good : Theme.Bad),
                StatCard("Kelly %",       haveTrades && payoff > 0 ? (kelly * 100).ToString("0") + "%" : na, "optimal full-Kelly size", kelly > 0 ? Theme.Good : Theme.Bad),
                StatCard("Largest win",   haveTrades ? Usd(bigWin) : na,                          "single trade",                   Theme.Good),
                StatCard("Largest loss",  haveTrades ? "-$" + Math.Abs(bigLoss).ToString("0") : na, "single trade",                 Theme.Bad)));

            // Consistency & risk (day-level).
            root.Children.Add(StatHeader("Consistency & risk", 18));
            root.Children.Add(Ui.TileGrid(3, 12,
                StatCard("Net P&L",        Usd(pnl),                    sessions + " sessions",                    pnl >= 0 ? Theme.Good : Theme.Bad),
                StatCard("Avg / session",  Usd(perSess),                "per trading day",                         perSess >= 0 ? Theme.Good : Theme.Bad),
                StatCard("Day win rate",   dayWin.ToString("0") + "%",  winDays + " green · " + lossDays + " red", Theme.FgPrimary),
                StatCard("Max drawdown",   "-$" + maxDD.ToString("0"),  ddDur > 0 ? ddDur + "-session drawdown" : "peak-to-trough", maxDD > 0 ? Theme.Bad : Theme.FgPrimary),
                StatCard("Recovery factor",maxDD > 0.01 ? recovery.ToString("0.00") : "∞", "net ÷ max drawdown", (recovery >= 1 || maxDD < 0.01) ? Theme.Good : Theme.Bad),
                StatCard("Daily Sharpe",   sharpe.ToString("0.00"),     "mean ÷ σ of daily P&L",              sharpe >= 0 ? Theme.Good : Theme.Bad),
                StatCard("Daily Sortino",  sortino.ToString("0.00"),    "mean ÷ downside σ",                  sortino >= 0 ? Theme.Good : Theme.Bad),
                StatCard("Win streak",     haveTrades ? mWin + " trades" : na, "longest run of winners",      Theme.Good),
                StatCard("Loss streak",    haveTrades ? mLoss + " trades" : na, "longest run of losers",      Theme.Bad)));

            // Tempo & timing.
            root.Children.Add(StatHeader("Tempo & timing", 18));
            root.Children.Add(Ui.Grid2(WeekdayPnl(s), HoldCard(fills), Theme.S4));

            // Breakdowns — slice P&L by what / when / how long / which behaviour.
            root.Children.Add(StatHeader("Breakdowns", 18));
            root.Children.Add(Ui.Grid2(ByInstrumentCard(fills), BySideCard(fills), Theme.S4));
            var tod = Ui.Grid2(TimeOfDayCard(fills), DurationCard(fills), Theme.S4); tod.Margin = new Thickness(0, 12, 0, 0);
            root.Children.Add(tod);
            var leak = LeakCard(fills); leak.Margin = new Thickness(0, 12, 0, 0);
            root.Children.Add(leak);

            // Discipline edge — composed vs tilted, side by side.
            root.Children.Add(StatHeader("Your discipline edge", 18));
            var cmp = new StackPanel();
            cmp.Children.Add(CompareRow("",                   "Composed",                 "Tilted",                   true,  Theme.Accent,                      Theme.Bad));
            cmp.Children.Add(CompareRow("Avg P&L / session",  Usd(compAvg),               Usd(tiltAvg),               false, compAvg >= 0 ? Theme.Good : Theme.Bad, tiltAvg >= 0 ? Theme.Good : Theme.Bad));
            cmp.Children.Add(CompareRow("Win rate",           compWin.ToString("0") + "%", tiltWin.ToString("0") + "%", false, Theme.FgPrimary,                  Theme.FgPrimary));
            cmp.Children.Add(CompareRow("Trades / session",   compTrPer.ToString("0.0"),  tiltTrPer.ToString("0.0"),  false, Theme.FgPrimary,                  Theme.FgPrimary));
            cmp.Children.Add(CompareRow("Sessions",           comp.Count.ToString(),      tilt.Count.ToString(),      false, Theme.FgHint,                     Theme.FgHint));
            root.Children.Add(Ui.Card(cmp, Theme.S4));

            var ct = Ui.Txt("Composure ↔ P&L correlation:  r = " + corr.ToString("0.00") + "  ·  " + CorrWord(corr), Theme.TBody, Theme.FgSecondary);
            ct.Margin = new Thickness(2, 10, 0, 0); ct.TextWrapping = TextWrapping.Wrap;
            root.Children.Add(ct);

            if (!haveTrades)
            {
                var note = Ui.Txt("Trade-level ratios (avg win/loss, payoff, Kelly, streaks) need the per-session detail files recorded each session — sessions traded before that feature won't have them.", Theme.TCaption, Theme.FgHint);
                note.Margin = new Thickness(2, 10, 0, 0); note.TextWrapping = TextWrapping.Wrap;
                root.Children.Add(note);
            }

            return root;
        }

        private FrameworkElement StatHero(double compAvg, double tiltAvg, int compN, int tiltN)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var L = new StackPanel { Margin = new Thickness(0, 0, 18, 0) };
            L.Children.Add(Ui.Txt("When you're composed", Theme.TCaption, Theme.Accent, FontWeights.SemiBold));
            var lv = Ui.Num(Usd(compAvg), Theme.THeadline, compAvg >= 0 ? Theme.Good : Theme.Bad, FontWeights.SemiBold);
            lv.Margin = new Thickness(0, 4, 0, 0); L.Children.Add(lv);
            L.Children.Add(Ui.Txt("per session  ·  " + compN + " sessions at 70%+ composure", Theme.TCaption, Theme.FgHint));
            Grid.SetColumn(L, 0); g.Children.Add(L);

            var div = new Border { Background = Theme.Border, Width = 1, Margin = new Thickness(0, 4, 0, 4) };
            Grid.SetColumn(div, 1); g.Children.Add(div);

            var R = new StackPanel { Margin = new Thickness(18, 0, 0, 0) };
            R.Children.Add(Ui.Txt("When you're tilted", Theme.TCaption, Theme.Bad, FontWeights.SemiBold));
            var rv = Ui.Num(Usd(tiltAvg), Theme.THeadline, tiltAvg >= 0 ? Theme.Good : Theme.Bad, FontWeights.SemiBold);
            rv.Margin = new Thickness(0, 4, 0, 0); R.Children.Add(rv);
            R.Children.Add(Ui.Txt("per session  ·  " + tiltN + " sessions below 70%", Theme.TCaption, Theme.FgHint));
            Grid.SetColumn(R, 2); g.Children.Add(R);

            var wrap = new StackPanel();
            wrap.Children.Add(g);
            double edge = compAvg - tiltAvg;
            string takeaway = (compN >= 2 && tiltN >= 2 && edge > 0)
                ? "Staying composed is worth about " + Usd(edge) + " per session to you."
                : "Not enough split yet to size the edge — a few more sessions will sharpen this.";
            var tk = Ui.Txt(takeaway, Theme.TBody, Theme.FgSecondary);
            tk.Margin = new Thickness(0, 12, 0, 0); tk.TextWrapping = TextWrapping.Wrap;
            wrap.Children.Add(tk);
            return Ui.AccentCard(wrap, Theme.Accent);
        }

        private static FrameworkElement StatCard(string label, string value, string sub, System.Windows.Media.Brush color)
        {
            var sp = new StackPanel();
            sp.Children.Add(Ui.Txt(label, Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            var v = Ui.Num(value, Theme.TTitle, color, FontWeights.SemiBold);
            v.Margin = new Thickness(0, 4, 0, 2); sp.Children.Add(v);
            sp.Children.Add(Ui.Txt(sub, Theme.TCaption, Theme.FgSecondary));
            return Ui.Card(sp, Theme.S4);
        }

        private static FrameworkElement CompareRow(string label, string left, string right, bool header, System.Windows.Media.Brush lc, System.Windows.Media.Brush rc)
        {
            var g = new Grid { Margin = new Thickness(0, header ? 0 : 7, 0, header ? 8 : 7) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.4, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var l = Ui.Txt(label, Theme.TBody, Theme.FgSecondary, header ? FontWeights.SemiBold : (FontWeight?)null);
            l.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(l, 0); g.Children.Add(l);
            var a = Ui.Num(left, Theme.TBody, lc, FontWeights.SemiBold);
            a.HorizontalAlignment = HorizontalAlignment.Right; a.Margin = new Thickness(0, 0, 14, 0); Grid.SetColumn(a, 1); g.Children.Add(a);
            var b = Ui.Num(right, Theme.TBody, rc, FontWeights.SemiBold);
            b.HorizontalAlignment = HorizontalAlignment.Right; b.Margin = new Thickness(0, 0, 14, 0); Grid.SetColumn(b, 2); g.Children.Add(b);
            if (header) return g;
            return new Border { Child = g, BorderBrush = Theme.Border, BorderThickness = new Thickness(0, 0, 0, 1) };
        }

        private static double StatPearson(List<SessionHistoryEntry> s)
        {
            int n = s.Count; if (n < 3) return 0;
            double mx = s.Average(a => (double)a.ComposurePct), my = s.Average(a => a.TotalPnl);
            double num = 0, dx = 0, dy = 0;
            foreach (var a in s) { double ex = a.ComposurePct - mx, ey = a.TotalPnl - my; num += ex * ey; dx += ex * ex; dy += ey * ey; }
            double den = Math.Sqrt(dx * dy);
            return den > 0 ? num / den : 0;
        }

        private static string CorrWord(double r)
        {
            double a = Math.Abs(r);
            if (a < 0.15) return "little link so far";
            string strength = a >= 0.5 ? "strong" : a >= 0.3 ? "moderate" : "mild";
            return strength + (r > 0 ? " — calmer sessions tend to pay more" : " — calmer sessions pay less here (check sizing on green days)");
        }

        private static string Usd(double v) => (v >= 0 ? "+$" : "-$") + Math.Abs(v).ToString("0");

        private static FrameworkElement StatHeader(string text, double top)
        {
            var h = (FrameworkElement)SectionHeader(text);
            h.Margin = new Thickness(0, top, 0, 8);
            return h;
        }

        // One completed trade (closing fill): realized P&L + how long it was held.
        private struct Tf { public double Pnl; public double Hold; public int Hour; public int DomDim; public string Side; public string Instr; }
        private struct BRow { public string Label; public double Net; public int N; public double WinPct; }

        // Per-trade detail for the given sessions, loaded from the per-session detail files
        // (SessionDetailStore: sessions/YYYY-MM-DD.xml). Cached by date so toggling the
        // timeframe/view never re-reads the same files.
        private static readonly System.Collections.Generic.Dictionary<DateTime, Tf[]> _fillCache
            = new System.Collections.Generic.Dictionary<DateTime, Tf[]>();
        private static List<Tf> ClosingFills(List<SessionHistoryEntry> s)
        {
            var all = new List<Tf>();
            foreach (var e in s)
            {
                var key = e.Date.Date;
                if (!_fillCache.TryGetValue(key, out Tf[] fills))
                {
                    fills = new Tf[0];
                    try
                    {
                        var detail = SessionDetailStore.Load(e.Date);
                        if (detail != null && detail.Fills != null)
                            fills = detail.Fills.Where(f => f.IsClosing)
                                          .Select(f => MakeTf(f))
                                          .ToArray();
                    }
                    catch { fills = new Tf[0]; }
                    _fillCache[key] = fills;
                }
                all.AddRange(fills);
            }
            return all;
        }

        // Project a persisted fill into the richer Tf used by the breakdowns: entry hour
        // (exit time − hold) and the dominant discipline signal at the fill (argmax D1–D7).
        private static Tf MakeTf(SdFill f)
        {
            DateTime entry;
            try { entry = new DateTime(f.Ticks).AddSeconds(-f.HoldSeconds); } catch { entry = DateTime.MinValue; }
            var ds = new[] { f.D1, f.D2, f.D3, f.D4, f.D5, f.D6, f.D7 };
            int dom = -1; float mx = 0.30f;   // only attribute when a leak is clearly active
            for (int i = 0; i < 7; i++) if (ds[i] > mx) { mx = ds[i]; dom = i; }
            return new Tf { Pnl = f.Pnl, Hold = f.HoldSeconds, Hour = entry.Hour, DomDim = dom, Side = f.Dir, Instr = f.Instr };
        }

        // =====================================================================
        // Breakdowns — slice realised P&L by when / how long / which behaviour.
        // (The "discipline leak" card is unique to Meridian — no P&L journal has it.)
        // =====================================================================
        private static FrameworkElement TimeOfDayCard(List<Tf> fills)
        {
            var rows = new List<BRow>();
            foreach (var grp in fills.GroupBy(f => f.Hour).OrderBy(g => g.Key))
            {
                int n = grp.Count();
                rows.Add(new BRow { Label = grp.Key.ToString("00") + ":00", Net = grp.Sum(f => f.Pnl),
                                    N = n, WinPct = n > 0 ? 100.0 * grp.Count(f => f.Pnl > 0) / n : 0 });
            }
            string note = "";
            if (rows.Count >= 2)
            {
                var best = rows.OrderByDescending(r => r.Net).First();
                var worst = rows.OrderBy(r => r.Net).First();
                if (worst.Net < 0) note = "Strongest window: " + best.Label + " (" + Usd(best.Net) + ")  ·  " + worst.Label + " bleeds (" + Usd(worst.Net) + "). Trading your best hours is an edge.";
            }
            return BreakdownCard("By time of day", rows, note, 56);
        }

        private static FrameworkElement DurationCard(List<Tf> fills)
        {
            string[] labels = { "< 1 min", "1–5 min", "5–15 min", "15–60 min", "> 1 hr" };
            int[] lo = { 0, 60, 300, 900, 3600 };
            int[] hi = { 60, 300, 900, 3600, int.MaxValue };
            var rows = new List<BRow>();
            for (int i = 0; i < labels.Length; i++)
            {
                var grp = fills.Where(f => f.Hold >= lo[i] && f.Hold < hi[i]).ToList();
                rows.Add(new BRow { Label = labels[i], Net = grp.Sum(f => f.Pnl), N = grp.Count,
                                    WinPct = grp.Count > 0 ? 100.0 * grp.Count(f => f.Pnl > 0) / grp.Count : 0 });
            }
            return BreakdownCard("By hold time", rows, "Where your size and patience pay — or don't.", 72);
        }

        private static FrameworkElement LeakCard(List<Tf> fills)
        {
            var net = new double[7]; var cnt = new int[7]; var wins = new int[7];
            foreach (var f in fills) if (f.DomDim >= 0 && f.DomDim < 7) { net[f.DomDim] += f.Pnl; cnt[f.DomDim]++; if (f.Pnl > 0) wins[f.DomDim]++; }
            var rows = new List<BRow>();
            for (int i = 0; i < 7; i++) if (cnt[i] > 0)
                rows.Add(new BRow { Label = IntelligenceEngine.HumanizeDimIndex(i), Net = net[i], N = cnt[i], WinPct = 100.0 * wins[i] / cnt[i] });
            rows = rows.OrderBy(r => r.Net).ToList();   // costliest (most negative) first
            string note;
            if (rows.Count == 0) note = "No single behaviour dominated your trades — they ran clean (or this range predates per-trade behaviour capture).";
            else { var worst = rows[0]; note = worst.Net < 0
                ? "Your costliest pattern is " + worst.Label + ": " + Usd(worst.Net) + " across " + worst.N + " trade" + (worst.N == 1 ? "" : "s") + " — the one to fix first."
                : "No behaviour is a net drain right now — keep it up."; }
            return BreakdownCard("Where your $ goes — by discipline leak", rows, note, 150);
        }

        private static FrameworkElement BySideCard(List<Tf> fills)
        {
            var with = fills.Where(f => !string.IsNullOrEmpty(f.Side)).ToList();
            var rows = new List<BRow>();
            foreach (var grp in with.GroupBy(f => f.Side).OrderBy(g => g.Key))
            {
                int n = grp.Count();
                rows.Add(new BRow { Label = grp.Key, Net = grp.Sum(f => f.Pnl), N = n, WinPct = n > 0 ? 100.0 * grp.Count(f => f.Pnl > 0) / n : 0 });
            }
            string note = with.Count == 0 ? "Long/short split appears for trades recorded after this update." : "";
            return BreakdownCard("By side", rows, note, 72);
        }

        private static FrameworkElement ByInstrumentCard(List<Tf> fills)
        {
            var with = fills.Where(f => !string.IsNullOrEmpty(f.Instr)).ToList();
            var rows = new List<BRow>();
            foreach (var grp in with.GroupBy(f => f.Instr))
            {
                int n = grp.Count();
                rows.Add(new BRow { Label = grp.Key, Net = grp.Sum(f => f.Pnl), N = n, WinPct = n > 0 ? 100.0 * grp.Count(f => f.Pnl > 0) / n : 0 });
            }
            rows = rows.OrderByDescending(r => Math.Abs(r.Net)).Take(8).ToList();   // top instruments by $ impact
            string note = with.Count == 0 ? "Per-instrument P&L appears for trades recorded after this update." : "";
            return BreakdownCard("By instrument", rows, note, 72);
        }

        private static FrameworkElement BreakdownCard(string title, List<BRow> rows, string note, double labelW)
        {
            var col = new StackPanel();
            col.Children.Add(Ui.Txt(title, Theme.TSubhead, Theme.FgSecondary, FontWeights.SemiBold));
            double maxAbs = 1; foreach (var r in rows) maxAbs = Math.Max(maxAbs, Math.Abs(r.Net));
            var body = new StackPanel { Margin = new Thickness(0, 8, 0, 0) };
            if (rows.Count == 0)
                body.Children.Add(Ui.Txt("Not enough trade detail in this range yet.", Theme.TCaption, Theme.FgHint));
            foreach (var r in rows)
            {
                bool pos = r.Net >= 0; double frac = Math.Min(1.0, Math.Abs(r.Net) / maxAbs);
                var g = new Grid { Margin = new Thickness(0, 4, 0, 4) };
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(labelW) });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(96) });
                var nm = Ui.Txt(r.Label, Theme.TBody, Theme.FgSecondary); nm.VerticalAlignment = VerticalAlignment.Center; nm.TextTrimming = TextTrimming.CharacterEllipsis; Grid.SetColumn(nm, 0); g.Children.Add(nm);
                var track = new Grid { Height = 10, VerticalAlignment = VerticalAlignment.Center };
                track.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(frac, GridUnitType.Star) });
                track.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1 - frac, GridUnitType.Star) });
                var fill = new Border { Background = r.N == 0 ? Theme.BgElevated : (pos ? Theme.Good : Theme.Bad), CornerRadius = new CornerRadius(5) }; Grid.SetColumn(fill, 0); track.Children.Add(fill);
                Grid.SetColumn(track, 1); g.Children.Add(track);
                var val = Ui.Num(r.N == 0 ? "—" : Usd(r.Net), Theme.TCaption, r.N == 0 ? Theme.FgHint : (pos ? Theme.Good : Theme.Bad), FontWeights.SemiBold);
                val.HorizontalAlignment = HorizontalAlignment.Right; val.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(val, 2); g.Children.Add(val);
                if (r.N > 0) g.ToolTip = r.N + " trade" + (r.N == 1 ? "" : "s") + "  ·  " + r.WinPct.ToString("0") + "% win";
                body.Children.Add(g);
            }
            col.Children.Add(body);
            if (!string.IsNullOrEmpty(note)) { var nb = Ui.Txt(note, Theme.TCaption, Theme.FgHint); nb.Margin = new Thickness(0, 10, 0, 0); nb.TextWrapping = TextWrapping.Wrap; col.Children.Add(nb); }
            return Ui.Card(col, Theme.S4);
        }

        private static double Std(List<double> v)
        {
            if (v.Count < 2) return 0;
            double m = v.Average(), ss = 0;
            foreach (var x in v) ss += (x - m) * (x - m);
            return Math.Sqrt(ss / (v.Count - 1));
        }
        private static double DownStd(List<double> v)
        {
            if (v.Count < 2) return 0;
            double ss = 0;
            foreach (var x in v) if (x < 0) ss += x * x;
            return Math.Sqrt(ss / v.Count);
        }
        private static string HoldFmt(double sec)
        {
            if (sec <= 0) return "—";
            if (sec < 90)   return sec.ToString("0") + "s";
            if (sec < 3600) return (sec / 60.0).ToString("0") + "m";
            return (sec / 3600.0).ToString("0.0") + "h";
        }

        // ── Equity curve: cumulative session P&L, responsive width ────────────
        private static FrameworkElement EquityCurve(List<SessionHistoryEntry> s)
        {
            var ordered = s.OrderBy(x => x.Date).ToList();
            var cum = new List<double>(); double c = 0;
            foreach (var e in ordered) { c += e.TotalPnl; cum.Add(c); }
            double lo = Math.Min(0, cum.Count > 0 ? cum.Min() : 0);
            double hi = Math.Max(0, cum.Count > 0 ? cum.Max() : 0);
            double range = hi - lo; if (range < 1) range = 1;
            const double W = 600, H = 120;

            var canvas = new System.Windows.Controls.Canvas { Width = W, Height = H };
            double zeroY = H - (0 - lo) / range * H;
            canvas.Children.Add(new System.Windows.Shapes.Line
            {
                X1 = 0, Y1 = zeroY, X2 = W, Y2 = zeroY, Stroke = Theme.Border, StrokeThickness = 1,
                StrokeDashArray = new System.Windows.Media.DoubleCollection { 4, 4 },
            });
            var pts = new System.Windows.Media.PointCollection();
            int n = cum.Count;
            for (int i = 0; i < n; i++)
            {
                double x = n <= 1 ? 0 : (double)i / (n - 1) * W;
                double y = H - (cum[i] - lo) / range * H;
                pts.Add(new System.Windows.Point(x, y));
            }
            bool up = c >= 0;
            canvas.Children.Add(new System.Windows.Shapes.Polyline
            {
                Stroke = up ? Theme.Good : Theme.Bad, StrokeThickness = 2, Points = pts,
                StrokeLineJoin = System.Windows.Media.PenLineJoin.Round,
                StrokeStartLineCap = System.Windows.Media.PenLineCap.Round,
                StrokeEndLineCap = System.Windows.Media.PenLineCap.Round,
            });
            var vb = new System.Windows.Controls.Viewbox { Stretch = System.Windows.Media.Stretch.Fill, Height = H, Child = canvas, HorizontalAlignment = HorizontalAlignment.Stretch, Margin = new Thickness(0, 10, 0, 0) };

            var hdr = new Grid();
            hdr.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            hdr.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var t = Ui.Txt("Equity curve", Theme.TSubhead, Theme.FgSecondary, FontWeights.SemiBold); Grid.SetColumn(t, 0); hdr.Children.Add(t);
            var fv = Ui.Num(Usd(c), Theme.TSubhead, up ? Theme.Good : Theme.Bad, FontWeights.SemiBold); fv.HorizontalAlignment = HorizontalAlignment.Right; Grid.SetColumn(fv, 1); hdr.Children.Add(fv);

            var col = new StackPanel(); col.Children.Add(hdr); col.Children.Add(vb);
            return Ui.Card(col, Theme.S4);
        }

        // ── Avg P&L by weekday (Mon–Fri) ──────────────────────────────────────
        private static FrameworkElement WeekdayPnl(List<SessionHistoryEntry> s)
        {
            var sum = new double[7]; var cnt = new int[7];
            foreach (var e in s) { int d = (int)e.Date.DayOfWeek; sum[d] += e.TotalPnl; cnt[d]++; }
            var names = new[] { "Mon", "Tue", "Wed", "Thu", "Fri" };
            var idx   = new[] { 1, 2, 3, 4, 5 };
            var avgs  = new double[5]; double maxAbs = 1;
            for (int k = 0; k < 5; k++) { avgs[k] = cnt[idx[k]] > 0 ? sum[idx[k]] / cnt[idx[k]] : 0; maxAbs = Math.Max(maxAbs, Math.Abs(avgs[k])); }

            var col = new StackPanel();
            col.Children.Add(Ui.Txt("Avg P&L by weekday", Theme.TSubhead, Theme.FgSecondary, FontWeights.SemiBold));
            var rows = new StackPanel { Margin = new Thickness(0, 8, 0, 0) };
            for (int k = 0; k < 5; k++)
            {
                bool has = cnt[idx[k]] > 0; bool pos = avgs[k] >= 0; double frac = Math.Abs(avgs[k]) / maxAbs;
                var g = new Grid { Margin = new Thickness(0, 4, 0, 4) };
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(38) });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(64) });
                var nm = Ui.Txt(names[k], Theme.TBody, Theme.FgSecondary); nm.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(nm, 0); g.Children.Add(nm);
                var track = new Grid { Height = 10, VerticalAlignment = VerticalAlignment.Center };
                track.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(frac, GridUnitType.Star) });
                track.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1 - frac, GridUnitType.Star) });
                var fill = new Border { Background = !has ? Theme.BgElevated : (pos ? Theme.Good : Theme.Bad), CornerRadius = new CornerRadius(5) }; Grid.SetColumn(fill, 0); track.Children.Add(fill);
                Grid.SetColumn(track, 1); g.Children.Add(track);
                var val = Ui.Num(!has ? "—" : Usd(avgs[k]), Theme.TCaption, !has ? Theme.FgHint : (pos ? Theme.Good : Theme.Bad), FontWeights.SemiBold);
                val.HorizontalAlignment = HorizontalAlignment.Right; val.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(val, 2); g.Children.Add(val);
                rows.Children.Add(g);
            }
            col.Children.Add(rows);
            return Ui.Card(col, Theme.S4);
        }

        // ── Hold time: winners vs losers (makes D4 hold-bias concrete) ────────
        private static FrameworkElement HoldCard(List<Tf> fills)
        {
            var col = new StackPanel();
            col.Children.Add(Ui.Txt("Hold time — winners vs losers", Theme.TSubhead, Theme.FgSecondary, FontWeights.SemiBold));
            var wins = fills.Where(f => f.Pnl > 0).ToList();
            var loss = fills.Where(f => f.Pnl < 0).ToList();
            double hw = wins.Count > 0 ? wins.Average(f => f.Hold) : 0;
            double hl = loss.Count > 0 ? loss.Average(f => f.Hold) : 0;
            var body = new StackPanel { Margin = new Thickness(0, 10, 0, 0) };
            body.Children.Add(HoldRow("Avg winner held", HoldFmt(hw), Theme.Good));
            body.Children.Add(HoldRow("Avg loser held",  HoldFmt(hl), Theme.Bad));
            col.Children.Add(body);
            string note = "";
            if (fills.Count == 0) note = "No trade detail in this range yet.";
            else if (hw > 0 && hl > hw * 1.25) note = "You hold losers ~" + (hl / hw).ToString("0.0") + "× longer than winners — classic hold-bias (D4). Cutting losers faster is the edge.";
            else if (hw > 0 || hl > 0)         note = "Hold times are balanced — no strong hold-bias showing.";
            if (note.Length > 0) { var nb = Ui.Txt(note, Theme.TCaption, Theme.FgHint); nb.Margin = new Thickness(0, 10, 0, 0); nb.TextWrapping = TextWrapping.Wrap; col.Children.Add(nb); }
            return Ui.Card(col, Theme.S4);
        }
        private static FrameworkElement HoldRow(string label, string val, System.Windows.Media.Brush c)
        {
            var g = new Grid { Margin = new Thickness(0, 4, 0, 4) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var l = Ui.Txt(label, Theme.TBody, Theme.FgSecondary); l.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(l, 0); g.Children.Add(l);
            var v = Ui.Num(val, Theme.TSubhead, c, FontWeights.SemiBold); v.HorizontalAlignment = HorizontalAlignment.Right; Grid.SetColumn(v, 1); g.Children.Add(v);
            return g;
        }

        // =====================================================================
        // Hero band — "where you stand right now": today's risk (left) + your
        // composure standing & trend (right) in one composed full-width card.
        // Replaces two separate short cards that each left a void.
        // =====================================================================
        private void BuildHeroBand(List<SessionHistoryEntry> all)
        {
            _root.Children.Add(SectionHeader("Where you stand"));
            var card  = Card();
            var inner = CardInner(card);
            var font  = Theme.Font;

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.5, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.0, GridUnitType.Star) });

            // ── LEFT: today's risk (the action) ──
            var left  = new StackPanel { Margin = new Thickness(2, 2, 18, 2) };
            var brief = IntelligenceEngine.ComputeRiskBrief(all);

            var head = new Grid { Margin = new Thickness(0, 0, 0, 6) };
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            head.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            head.Children.Add(new TextBlock {
                Text = $"Today — {DateTime.Today:dddd, MMMM d}", FontSize = 13, FontFamily = font,
                FontWeight = FontWeights.SemiBold, Foreground = FgPrimary, VerticalAlignment = VerticalAlignment.Center });
            if (brief.HasEnoughData)
            {
                Color rc = brief.RiskScore >= 70 ? ColCritical : brief.RiskScore >= 50 ? ColCaution
                         : brief.RiskScore >= 30 ? ColYellowGreen : ColStable;
                var badge = new Border {
                    Background = new SolidColorBrush(Color.FromArgb(40, rc.R, rc.G, rc.B)),
                    CornerRadius = new CornerRadius(6), Padding = new Thickness(8, 3, 8, 3), VerticalAlignment = VerticalAlignment.Center,
                    Child = new TextBlock { Text = $"{brief.RiskLabel} Risk  ·  {brief.RiskScore}/100", FontSize = 12, FontFamily = font, FontWeight = FontWeights.SemiBold, Foreground = new SolidColorBrush(rc) } };
                Grid.SetColumn(badge, 1); head.Children.Add(badge);
            }
            left.Children.Add(head);

            if (!brief.HasEnoughData)
                left.Children.Add(new TextBlock { Text = brief.RecommendationText, FontSize = 12, FontFamily = font, Foreground = FgSecondary, TextWrapping = TextWrapping.Wrap });
            else
            {
                foreach (var f in brief.Factors)
                {
                    Color fc = f.IsGood ? ColStable : f.Delta >= 15 ? ColCritical : ColCaution;
                    string ic = f.IsGood ? "✓" : f.Delta >= 15 ? "⚠" : "·";
                    left.Children.Add(new TextBlock { Text = $"{ic}  {f.Reason}", FontSize = 12, FontFamily = font, Foreground = new SolidColorBrush(fc), TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 3, 0, 0) });
                }
                left.Children.Add(Divider());
                left.Children.Add(new TextBlock { Text = brief.RecommendationText, FontSize = 12, FontFamily = font, Foreground = FgSecondary, TextWrapping = TextWrapping.Wrap, FontStyle = FontStyles.Italic });
            }
            Grid.SetColumn(left, 0); grid.Children.Add(left);

            // ── vertical divider ──
            var vdiv = new Border { Width = 1, Background = new SolidColorBrush(Color.FromArgb(28, 255, 255, 255)), Margin = new Thickness(0, 2, 0, 2) };
            Grid.SetColumn(vdiv, 1); grid.Children.Add(vdiv);

            // ── RIGHT: composure standing + trend (where you're heading) ──
            var right  = new StackPanel { Margin = new Thickness(20, 2, 2, 2) };
            var points = IntelligenceEngine.ComputeProgressTrend(all, 6);
            var active = points.Where(p => p.SessionCount > 0).ToList();
            right.Children.Add(new TextBlock { Text = "Composure standing", FontSize = 12, FontFamily = font, FontWeight = FontWeights.SemiBold, Foreground = FgHint, Margin = new Thickness(0, 0, 0, 3) });

            if (active.Count >= 1)
            {
                var lastp = active.Last();
                int now = (int)System.Math.Round(lastp.AvgComposure);
                Color cc = CompColor(lastp.AvgComposure);
                var bigRow = new StackPanel { Orientation = Orientation.Horizontal };
                bigRow.Children.Add(new TextBlock { Text = now + "%", FontSize = 30, FontFamily = font, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(cc) });
                bigRow.Children.Add(new TextBlock { Text = ZoneWord(now), FontSize = 13, FontFamily = font, FontWeight = FontWeights.SemiBold, Foreground = new SolidColorBrush(cc), VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(8, 0, 0, 5) });
                right.Children.Add(bigRow);

                if (active.Count >= 2)
                {
                    double d = lastp.AvgComposure - active.First().AvgComposure;
                    string ar = d >= 3 ? "↑" : d <= -3 ? "↓" : "→";
                    Color tc = d >= 3 ? ColStable : d <= -3 ? ColCritical : ColCaution;
                    right.Children.Add(new TextBlock { Text = $"{ar}  {Math.Abs(d):F0} pt{(Math.Abs(d) >= 1.5 ? "s" : "")} {(d >= 0 ? "up" : "down")} over {active.Count} months", FontSize = 12, FontFamily = font, FontWeight = FontWeights.SemiBold, Foreground = new SolidColorBrush(tc), Margin = new Thickness(0, 1, 0, 7) });
                }
                else
                    right.Children.Add(new TextBlock { Text = "Trend builds with 2+ months of sessions.", FontSize = 12, FontFamily = font, Foreground = FgHint, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 1, 0, 7) });

                var pills = new WrapPanel();
                foreach (var p in points)
                {
                    Color pc = p.SessionCount == 0 ? Color.FromRgb(60, 60, 64) : CompColor(p.AvgComposure);
                    var pill = new Border {
                        Background = new SolidColorBrush(Color.FromArgb(30, pc.R, pc.G, pc.B)),
                        BorderBrush = new SolidColorBrush(Color.FromArgb(70, pc.R, pc.G, pc.B)),
                        BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(7),
                        Padding = new Thickness(7, 3, 7, 3), Margin = new Thickness(0, 0, 5, 5), Child = new StackPanel() };
                    var sp = (StackPanel)pill.Child;
                    sp.Children.Add(new TextBlock { Text = p.Month.ToString("MMM"), FontSize = 10, FontFamily = font, Foreground = new SolidColorBrush(Color.FromRgb(120, 120, 124)), HorizontalAlignment = HorizontalAlignment.Center });
                    sp.Children.Add(new TextBlock { Text = p.SessionCount == 0 ? "—" : $"{p.AvgComposure:F0}", FontSize = 12, FontFamily = font, FontWeight = FontWeights.Bold, Foreground = new SolidColorBrush(pc), HorizontalAlignment = HorizontalAlignment.Center });
                    pills.Children.Add(pill);
                }
                right.Children.Add(pills);
            }
            else
                right.Children.Add(Placeholder("Composure standing appears after your first session."));

            Grid.SetColumn(right, 2); grid.Children.Add(right);

            inner.Children.Add(grid);
            _root.Children.Add(card);
        }

        private static string ZoneWord(int c) => c >= 88 ? "Stable" : c >= 72 ? "Steady" : c >= 55 ? "Caution" : "Critical";

        // =====================================================================
        // Section 2: Monthly Digest
        // =====================================================================

        private void BuildMonthlyDigest(List<SessionHistoryEntry> sessions)
        {
            // ── Month navigation header ───────────────────────────────────────
            var navBar  = new Grid { Margin = new Thickness(0, 12, 0, 0) };
            navBar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            navBar.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            navBar.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var available     = IntelligenceEngine.GetAvailableMonths(sessions);
            bool canGoPrev    = available.Count > 0 && _currentMonth > available.First();
            bool canGoNext    = _currentMonth < new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);

            var prevBtn = MakeNavArrow("◀", canGoPrev);
            var nextBtn = MakeNavArrow("▶", canGoNext);

            if (canGoPrev)
                prevBtn.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    _currentMonth = _currentMonth.AddMonths(-1);
                    BuildPage();
                };
            if (canGoNext)
                nextBtn.MouseLeftButtonDown += (_, e) =>
                {
                    e.Handled = true;
                    _currentMonth = _currentMonth.AddMonths(1);
                    BuildPage();
                };

            var monthLabel = new TextBlock
            {
                Text                = $"Monthly digest  ·  {_currentMonth:MMMM yyyy}",
                FontSize            =  12,
                FontFamily          = Theme.Font,
                FontWeight          = FontWeights.SemiBold,
                Foreground          = FgSecondary,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
            };

            Grid.SetColumn(prevBtn,    0);
            Grid.SetColumn(monthLabel, 1);
            Grid.SetColumn(nextBtn,    2);
            navBar.Children.Add(prevBtn);
            navBar.Children.Add(monthLabel);
            navBar.Children.Add(nextBtn);
            _root.Children.Add(navBar);

            // ── Compute digests ───────────────────────────────────────────────
            var prevMonthSessions = sessions
                .Where(s => s.Date >= _currentMonth.AddMonths(-1)
                         && s.Date < _currentMonth).ToList();
            MonthDigest prev = IntelligenceEngine.ComputeMonthDigest(
                sessions, _currentMonth.AddMonths(-1));
            MonthDigest cur  = IntelligenceEngine.ComputeMonthDigest(
                sessions, _currentMonth, prev.SessionCount > 0 ? prev : null);

            var card  = Card();
            var inner = CardInner(card);

            if (cur.SessionCount == 0)
            {
                inner.Children.Add(Placeholder("No trading sessions recorded for this month."));
                _root.Children.Add(card);
                return;
            }

            // ── Grade badge + headline stats ──────────────────────────────────
            var topRow = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            topRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            topRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            // Grade badge
            Color gradeColor = CompColor(cur.AvgComposure);
            var gradeBadge = new Border
            {
                Background    = new SolidColorBrush(Color.FromArgb(50,
                    gradeColor.R, gradeColor.G, gradeColor.B)),
                BorderBrush   = new SolidColorBrush(Color.FromArgb(120,
                    gradeColor.R, gradeColor.G, gradeColor.B)),
                BorderThickness = new Thickness(1),
                CornerRadius  = new CornerRadius(8),
                Padding       = new Thickness(10, 6, 10, 6),
                Margin        = new Thickness(0, 0, 12, 0),
                VerticalAlignment = VerticalAlignment.Center,
                Child = new TextBlock
                {
                    Text       = ((int)System.Math.Round(cur.AvgComposure)) + "%",
                    FontSize   = 22,
                    FontFamily = Theme.Font,
                    FontWeight = FontWeights.Bold,
                    Foreground = new SolidColorBrush(gradeColor),
                },
            };
            topRow.Children.Add(gradeBadge);

            // Key stats column
            string prevMonthShort = _currentMonth.AddMonths(-1).ToString("MMM");
            int stableDaysDelta = prev.SessionCount > 0 ? cur.StableDays - prev.StableDays : 0;
            var statsCol = new StackPanel { Orientation = Orientation.Vertical };
            statsCol.Children.Add(DigestStatRow(
                "Composure",
                $"{cur.AvgComposure:F0}%",
                cur.ComposureChange.HasValue
                    ? FormatChange(cur.ComposureChange.Value, $"% vs {prevMonthShort}")
                    : null,
                cur.ComposureChange));
            statsCol.Children.Add(DigestStatRow(
                "Stable days",
                $"{cur.StableDays} days",
                prev.SessionCount > 0
                    ? FormatChange(stableDaysDelta, $" days vs {prevMonthShort}")
                    : null,
                prev.SessionCount > 0 ? (double?)stableDaysDelta : null));
            statsCol.Children.Add(DigestStatRow(
                "Win rate",
                $"{cur.WinRate * 100:F0}%",
                null, null));
            statsCol.Children.Add(DigestStatRow(
                "Avg P&L / session",
                cur.AvgPnl >= 0 ? $"+${cur.AvgPnl:F0}" : $"-${Math.Abs(cur.AvgPnl):F0}",
                null, null));

            Grid.SetColumn(statsCol, 1);
            topRow.Children.Add(statsCol);
            inner.Children.Add(topRow);

            // ── Divider ───────────────────────────────────────────────────────
            inner.Children.Add(Divider());

            // ── Best / worst day ──────────────────────────────────────────────
            if (cur.BestDay != null)
            {
                inner.Children.Add(TwoColRow(
                    $"Best day — {cur.BestDay.Date:MMM d}",
                    $"Composure {cur.BestDay.ComposurePct}%",
                    ColStable));
            }
            if (cur.WorstDay != null && cur.WorstDay.Date != cur.BestDay?.Date)
            {
                inner.Children.Add(TwoColRow(
                    $"Hardest day — {cur.WorstDay.Date:MMM d}",
                    $"Composure {cur.WorstDay.ComposurePct}%",
                    ColCritical));
            }

            // ── Strength / Weakness ───────────────────────────────────────────
            inner.Children.Add(Divider());
            inner.Children.Add(TwoColRow("Top strength",   IntelligenceEngine.HumanizeDim(cur.TopStrength), ColStable));
            inner.Children.Add(TwoColRow("Needs attention", IntelligenceEngine.HumanizeDim(cur.TopWeakness), ColCaution));

            _root.Children.Add(card);
        }

        // =====================================================================
        // Section 3: PSI × Performance Correlation
        // =====================================================================

        private void BuildPsiPerfCorrelation(List<SessionHistoryEntry> sessions)
        {
            _root.Children.Add(SectionHeader("PSI × performance"));
            _root.Children.Add(new TextBlock
            {
                Text         = "P&L in this section is descriptive only; PSI does not use profit or loss to score discipline.",
                FontSize     =  12,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 2, 0, 8),
            });

            if (sessions.Count < IntelligenceEngine.MinSessionsCorr)
            {
                _root.Children.Add(InsufficientDataCard(
                    IntelligenceEngine.MinSessionsCorr - sessions.Count,
                    "PSI × performance analysis"));
                return;
            }

            var psiBuckets  = IntelligenceEngine.ComputePsiPerfCorrelation(sessions);
            var compBuckets = IntelligenceEngine.ComputeComposurePerfCorrelation(sessions);

            // ── Two-column card layout ─────────────────────────────────────────
            var outerCard = Card();
            var outerInner = CardInner(outerCard);

            // Stacked vertically (not side-by-side): in the Intel grid each section is only
            // ~1/3 width, too narrow for two 4-column tables abreast — they overlapped.
            var twoCol = new StackPanel { Orientation = Orientation.Vertical };

            // ── Left: PSI Zone table ───────────────────────────────────────────
            var leftPanel = new StackPanel { Orientation = Orientation.Vertical };

            leftPanel.Children.Add(new TextBlock
            {
                Text       = "Avg PSI zone with session P&L (descriptive)",
                FontSize   =  12,
                FontFamily = Theme.Font,
                Foreground = FgSecondary,
                Margin     = new Thickness(0, 0, 0, 6),
                TextWrapping = TextWrapping.Wrap,
            });

            BuildTableHeader(leftPanel, new[] { "Zone", "Days", "Win%", "Avg P&L" },
                             new[] { 1.8, 0.6, 0.6, 1.0 });

            foreach (var b in psiBuckets)
            {
                Color zoneColor = b.PsiMin >= 75 ? ColStable
                                : b.PsiMin >= 55 ? ColCaution
                                : ColCritical;
                if (b.SessionCount == 0)
                    BuildTableRow(leftPanel, new[] { b.Label, "—", "—", "—" },
                        new[] { 1.8, 0.6, 0.6, 1.0 }, zoneColor, dim: true);
                else
                {
                    string pnlStr = b.AvgPnl >= 0 ? $"+${b.AvgPnl:F0}" : $"-${Math.Abs(b.AvgPnl):F0}";
                    BuildTableRow(leftPanel, new[] { b.Label, $"{b.SessionCount}", $"{b.WinRate:F0}%", pnlStr },
                        new[] { 1.8, 0.6, 0.6, 1.0 }, zoneColor, dim: false);
                }
            }

            twoCol.Children.Add(leftPanel);

            // ── Separator (horizontal, between the stacked tables) ────────────
            twoCol.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                Margin     = new Thickness(0, 12, 0, 12),
            });

            // ── Right: Composure table ─────────────────────────────────────────
            var rightPanel = new StackPanel { Orientation = Orientation.Vertical };

            rightPanel.Children.Add(new TextBlock
            {
                Text       = "Composure score with session P&L (descriptive)",
                FontSize   =  12,
                FontFamily = Theme.Font,
                Foreground = FgSecondary,
                Margin     = new Thickness(0, 0, 0, 6),
                TextWrapping = TextWrapping.Wrap,
            });

            BuildTableHeader(rightPanel, new[] { "Score", "Days", "Win%", "Avg P&L" },
                             new[] { 1.8, 0.6, 0.6, 1.0 });

            foreach (var b in compBuckets)
            {
                Color zoneColor = CompColor(b.ComposureMin);
                if (b.SessionCount == 0)
                    BuildTableRow(rightPanel, new[] { b.Label, "—", "—", "—" },
                        new[] { 1.8, 0.6, 0.6, 1.0 }, zoneColor, dim: true);
                else
                {
                    string pnlStr = b.AvgPnl >= 0 ? $"+${b.AvgPnl:F0}" : $"-${Math.Abs(b.AvgPnl):F0}";
                    BuildTableRow(rightPanel, new[] { b.Label, $"{b.SessionCount}", $"{b.WinRate:F0}%", pnlStr },
                        new[] { 1.8, 0.6, 0.6, 1.0 }, zoneColor, dim: false);
                }
            }

            twoCol.Children.Add(rightPanel);

            outerInner.Children.Add(twoCol);

            // ── Insights row (full width below tables) ─────────────────────────
            var stableBucket   = psiBuckets.FirstOrDefault(b => b.PsiMin >= 75);
            var criticalBucket = psiBuckets.FirstOrDefault(b => b.PsiMax <= 55);
            if (stableBucket != null && criticalBucket != null
                && stableBucket.SessionCount > 0 && criticalBucket.SessionCount > 0)
            {
                double winDiff = stableBucket.WinRate - criticalBucket.WinRate;
                double pnlDiff = stableBucket.AvgPnl  - criticalBucket.AvgPnl;
                if (Math.Abs(winDiff) > 5 || Math.Abs(pnlDiff) > 50)
                {
                    outerInner.Children.Add(Divider());
                    outerInner.Children.Add(InsightText(
                        $"Stable PSI → {winDiff:F0}% higher win rate and ${pnlDiff:F0} more per session vs. Critical-zone."));
                }
            }

            var composedBucket     = compBuckets.FirstOrDefault(b => b.ComposureMin >= SessionData.ComposureStableThreshold);
            var breakingDownBucket = compBuckets.FirstOrDefault(b => b.ComposureMax <= 40);
            if (composedBucket != null && breakingDownBucket != null
                && breakingDownBucket.SessionCount > 0 && composedBucket.SessionCount > 0)
            {
                double lostPnl = breakingDownBucket.TotalPnl;
                if (lostPnl < -100)
                {
                    outerInner.Children.Add(Divider());
                    outerInner.Children.Add(InsightText(
                        $"Your {breakingDownBucket.SessionCount} 'Breaking Down' session{(breakingDownBucket.SessionCount > 1 ? "s" : "")} " +
                        $"cost ${Math.Abs(lostPnl):F0} in losses — the cost of trading on low-composure days."));
                }
            }

            _root.Children.Add(outerCard);
        }

        // =====================================================================
        // Section 4: Weekday Heatmap
        // =====================================================================

        private void BuildWeekdayHeatmap(List<SessionHistoryEntry> sessions)
        {
            _root.Children.Add(SectionHeader("Weekday patterns"));

            if (sessions.Count < IntelligenceEngine.MinSessionsPattern)
            {
                _root.Children.Add(InsufficientDataCard(
                    IntelligenceEngine.MinSessionsPattern - sessions.Count,
                    "Weekday pattern analysis"));
                return;
            }

            var stats = IntelligenceEngine.ComputeWeekdayStats(sessions);
            if (stats.Length == 0)
            {
                _root.Children.Add(InsufficientDataCard(5, "Weekday pattern analysis"));
                return;
            }

            var card  = Card();
            var inner = CardInner(card);

            // ── Grid: day headers + 4 metric rows ────────────────────────────
            var grid = new Grid { Margin = new Thickness(0, 0, 0, 4) };
            // Col 0: label, Cols 1-5: Mon-Fri
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(80) });
            for (int d = 0; d < 5; d++)
                grid.ColumnDefinitions.Add(new ColumnDefinition
                    { Width = new GridLength(1, GridUnitType.Star) });

            // Row definitions: header + 4 data rows
            for (int r = 0; r < 5; r++)
                grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(26) });

            // Row 0: day-of-week headers
            for (int d = 0; d < 5; d++)
            {
                var s = stats.FirstOrDefault(x => (int)x.Day == d + 1); // Mon=1..Fri=5
                Color dayColor = s == null || s.SessionCount == 0 ? Color.FromRgb(80, 80, 84)
                               : s.IsHighRisk  ? ColCritical
                               : s.IsBestDay   ? ColStable
                               : Color.FromRgb(174, 174, 178);

                var hdr = new Border
                {
                    Background    = new SolidColorBrush(Color.FromArgb(30,
                        dayColor.R, dayColor.G, dayColor.B)),
                    CornerRadius  = new CornerRadius(5),
                    Margin        = new Thickness(2, 1, 2, 1),
                    Child = new TextBlock
                    {
                        Text                = DayShort[d],
                        FontSize            =  12,
                        FontFamily          = Theme.Font,
                        FontWeight          = FontWeights.SemiBold,
                        Foreground          = new SolidColorBrush(dayColor),
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment   = VerticalAlignment.Center,
                        ToolTip             = s?.SessionCount > 0
                            ? $"{s.SessionCount} sessions recorded" : "No sessions",
                    },
                };
                Grid.SetRow(hdr, 0); Grid.SetColumn(hdr, d + 1);
                grid.Children.Add(hdr);
            }

            // Row label col
            AddHeatmapLabel(grid, "Composure", 1);
            AddHeatmapLabel(grid, "Win %",     2);
            AddHeatmapLabel(grid, "Critical %", 3);
            AddHeatmapLabel(grid, "Sessions",  4);

            // Data cells
            double[] allComposure = stats.Where(s => s.SessionCount > 0)
                .Select(s => s.AvgComposure).ToArray();
            double maxComp = allComposure.Length > 0 ? allComposure.Max() : 100;
            double minComp = allComposure.Length > 0 ? allComposure.Min() : 0;

            for (int d = 0; d < 5; d++)
            {
                var s = stats.FirstOrDefault(x => (int)x.Day == d + 1);
                if (s == null || s.SessionCount == 0)
                {
                    // Show "No data" in row 1, empty for others — makes absence explicit
                    AddHeatmapCell(grid, "–", 1, d + 1, Color.FromRgb(60, 60, 64), dim: true);
                    for (int r = 2; r <= 4; r++)
                        AddHeatmapCell(grid, "–", r, d + 1, Color.FromRgb(60, 60, 64), dim: true);
                    continue;
                }

                // Composure cell — use semantic 4-tier CompColor
                Color compColor = CompColor(s.AvgComposure);
                AddHeatmapCell(grid, $"{s.AvgComposure:F0}%", 1, d + 1, compColor, false);

                // Win rate
                Color winColor = s.WinRate >= 55 ? ColStable
                               : s.WinRate >= 45 ? ColCaution
                               : ColCritical;
                AddHeatmapCell(grid, $"{s.WinRate:F0}%", 2, d + 1, winColor, false);

                // Critical %
                Color critColor = s.AvgCriticalPct <= 10 ? ColStable
                                : s.AvgCriticalPct <= 25 ? ColCaution
                                : ColCritical;
                AddHeatmapCell(grid, $"{s.AvgCriticalPct:F0}%", 3, d + 1, critColor, false);

                // Session count
                AddHeatmapCell(grid, $"{s.SessionCount}", 4, d + 1,
                    Color.FromRgb(99, 99, 102), false);
            }

            inner.Children.Add(grid);

            // ── Auto insight ──────────────────────────────────────────────────
            var bestDay  = stats.Where(s => s.SessionCount >= 2).OrderByDescending(s => s.AvgComposure).FirstOrDefault();
            var worstDay = stats.Where(s => s.SessionCount >= 2).OrderBy(s => s.AvgComposure).FirstOrDefault();
            if (bestDay != null && worstDay != null && bestDay.Day != worstDay.Day)
            {
                double gap = bestDay.AvgComposure - worstDay.AvgComposure;
                if (gap > 10)
                {
                    inner.Children.Add(Divider());
                    inner.Children.Add(InsightText(
                        $"Your best day is {bestDay.Day} (avg {bestDay.AvgComposure:F0}% Composure). " +
                        $"Your hardest day is {worstDay.Day} ({worstDay.AvgComposure:F0}%). " +
                        $"Consider reducing size or skipping {worstDay.Day} trades."));
                }
            }

            _root.Children.Add(card);
        }

        // =====================================================================
        // Section 6: Crash Triggers
        // =====================================================================

        private void BuildCrashTriggers(List<SessionHistoryEntry> sessions)
        {
            _root.Children.Add(SectionHeader("What your worst sessions share"));

            var triggers = IntelligenceEngine.ComputeCrashTriggers(sessions);

            if (triggers.Count == 0)
            {
                var eCard = Card();
                CardInner(eCard).Children.Add(Placeholder(
                    sessions.Count < IntelligenceEngine.MinSessionsBasic
                        ? $"Need {IntelligenceEngine.MinSessionsBasic - sessions.Count} more sessions to identify crash patterns."
                        : "No significant crash patterns identified in your session history."));
                _root.Children.Add(eCard);
                return;
            }

            var card  = Card();
            var inner = CardInner(card);

            int crashDayTotal = triggers.Max(t2 => t2.CrashDayCount);

            inner.Children.Add(new TextBlock
            {
                Text         = $"How consistently each behavior appeared in your {crashDayTotal} worst sessions:",
                FontSize     =  12,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 10),
            });

            for (int i = 0; i < triggers.Count; i++)
            {
                var t = triggers[i];
                Color barColor = i == 0 ? ColCritical
                               : i == 1 ? ColCaution
                               : Color.FromRgb(174, 174, 178);

                // Severity badge color
                Color sevColor = t.SeverityLabel == "HIGH" ? ColCritical
                               : t.SeverityLabel == "MED"  ? ColCaution
                               : Color.FromRgb(99, 99, 102);

                var row = new StackPanel
                {
                    Orientation = Orientation.Vertical,
                    Margin      = new Thickness(0, 0, 0, 12),
                };

                // ── Label row: rank + name | frequency text | severity badge ──
                var labelGrid = new Grid();
                labelGrid.ColumnDefinitions.Add(new ColumnDefinition
                    { Width = new GridLength(1, GridUnitType.Star) });
                labelGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                labelGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                labelGrid.Margin = new Thickness(0, 0, 0, 4);

                labelGrid.Children.Add(new TextBlock
                {
                    Text              = $"#{i + 1}  {IntelligenceEngine.HumanizeDim(t.DimName)}",
                    FontSize          =  12,
                    FontFamily        = Theme.Font,
                    FontWeight        = FontWeights.SemiBold,
                    Foreground        = new SolidColorBrush(barColor),
                    VerticalAlignment = VerticalAlignment.Center,
                });

                // Frequency text: "X / Y worst sessions"
                var freqLbl = new TextBlock
                {
                    Text              = $"{t.PresentOnCrashDays} / {t.CrashDayCount} worst sessions",
                    FontSize          =  12,
                    FontFamily        = Theme.Font,
                    Foreground        = FgSecondary,
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin            = new Thickness(0, 0, 8, 0),
                };
                Grid.SetColumn(freqLbl, 1);
                labelGrid.Children.Add(freqLbl);

                // Severity badge
                var sevBadge = new Border
                {
                    Background    = new SolidColorBrush(Color.FromArgb(35,
                        sevColor.R, sevColor.G, sevColor.B)),
                    CornerRadius  = new CornerRadius(3),
                    Padding       = new Thickness(5, 1, 5, 1),
                    VerticalAlignment = VerticalAlignment.Center,
                    Child = new TextBlock
                    {
                        Text       = t.SeverityLabel,
                        FontSize   =  12,
                        FontFamily = Theme.Font,
                        FontWeight = FontWeights.SemiBold,
                        Foreground = new SolidColorBrush(sevColor),
                    },
                };
                Grid.SetColumn(sevBadge, 2);
                labelGrid.Children.Add(sevBadge);

                row.Children.Add(labelGrid);

                // ── Frequency bar (PresentOnCrashDays / CrashDayCount) ─────────
                double fillPct = t.CrashDayCount > 0
                    ? (double)t.PresentOnCrashDays / t.CrashDayCount : 0;
                var barBg = new Border
                {
                    Background   = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                    CornerRadius = new CornerRadius(3),
                    Height       = 5,
                };
                var barFill = new Border
                {
                    Background          = new SolidColorBrush(barColor),
                    CornerRadius        = new CornerRadius(3),
                    Height              = 5,
                    HorizontalAlignment = HorizontalAlignment.Left,
                };
                barFill.Loaded += (_, __) => { barFill.Width = barBg.ActualWidth * fillPct; };
                barBg.Loaded   += (_, __) => { barFill.Width = barBg.ActualWidth * fillPct; };
                barBg.Child = barFill;
                row.Children.Add(barBg);



                inner.Children.Add(row);
            }

            if (triggers.Count > 0)
            {
                inner.Children.Add(Divider());
                inner.Children.Add(InsightText(
                    $"'{IntelligenceEngine.HumanizeDim(triggers[0].DimName)}' is your most consistent pattern on hard days — " +
                    $"present in {triggers[0].PresentOnCrashDays} of your {triggers[0].CrashDayCount} worst sessions. " +
                    $"Working on this one behavior is the change most likely to help."));
            }

            _root.Children.Add(card);
        }

        // =====================================================================
        // Table builder helpers
        // =====================================================================

        private void BuildTableHeader(StackPanel inner, string[] cols, double[] weights)
        {
            var row = MakeTableRow(cols, weights,
                new SolidColorBrush(Color.FromRgb(99, 99, 102)), bold: true);
            row.Margin = new Thickness(0, 0, 0, 2);
            inner.Children.Add(row);
        }

        private void BuildTableRow(StackPanel inner, string[] cols, double[] weights,
                                   Color accent, bool dim)
        {
            Brush fg = dim ? FgHint : FgSecondary;
            var row = MakeTableRow(cols, weights, fg, bold: false);
            if (!dim)
            {
                // Colorize first cell
                var g = (Grid)row;
                if (g.Children.Count > 0 && g.Children[0] is TextBlock tb)
                    tb.Foreground = new SolidColorBrush(accent);
            }
            row.Margin = new Thickness(0, 0, 0, 2);
            inner.Children.Add(row);
        }

        private static Grid MakeTableRow(string[] cols, double[] weights, Brush fg, bool bold)
        {
            var g = new Grid { Margin = new Thickness(0, 1, 0, 1) };
            for (int i = 0; i < cols.Length; i++)
            {
                g.ColumnDefinitions.Add(new ColumnDefinition
                    { Width = new GridLength(weights[i], GridUnitType.Star) });
                var tb = new TextBlock
                {
                    Text       = cols[i],
                    FontSize   =  12,
                    FontFamily = Theme.Font,
                    FontWeight = bold ? FontWeights.SemiBold : FontWeights.Normal,
                    Foreground = fg,
                    HorizontalAlignment = i == 0 ? HorizontalAlignment.Left : HorizontalAlignment.Right,
                    VerticalAlignment   = VerticalAlignment.Center,
                    Padding             = new Thickness(i == 0 ? 0 : 4, 0, 0, 0),
                };
                Grid.SetColumn(tb, i);
                g.Children.Add(tb);
            }
            return g;
        }

        // =====================================================================
        // Heatmap cell helpers
        // =====================================================================

        private static void AddHeatmapLabel(Grid grid, string text, int row)
        {
            var tb = new TextBlock
            {
                Text              = text,
                FontSize          =  12,
                FontFamily        = Theme.Font,
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(0, 0, 4, 0),
            };
            Grid.SetRow(tb, row); Grid.SetColumn(tb, 0);
            grid.Children.Add(tb);
        }

        private static void AddHeatmapCell(Grid grid, string text, int row, int col,
                                           Color accent, bool dim)
        {
            Brush fg = dim
                ? new SolidColorBrush(Color.FromRgb(60, 60, 64))
                : new SolidColorBrush(accent);

            var cell = new Border
            {
                Background   = new SolidColorBrush(Color.FromArgb(dim ? (byte)0 : (byte)20,
                    accent.R, accent.G, accent.B)),
                CornerRadius = new CornerRadius(4),
                Margin       = new Thickness(2, 1, 2, 1),
                Child = new TextBlock
                {
                    Text                = text,
                    FontSize            =  12,
                    FontFamily          = Theme.Font,
                    FontWeight          = FontWeights.SemiBold,
                    Foreground          = fg,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                },
            };
            Grid.SetRow(cell, row); Grid.SetColumn(cell, col);
            grid.Children.Add(cell);
        }

        private static Color HeatColor(double value, double min, double max)
        {
            if (max <= min) return Color.FromRgb(174, 174, 178);
            double t = (value - min) / (max - min);
            if (t >= 0.6) return ColStable;
            if (t >= 0.35) return ColCaution;
            return ColCritical;
        }

        // =====================================================================
        // Shared UI primitives
        // =====================================================================

        private static Border Card() => new Border
        {
            Background      = BgCard,
            CornerRadius    = new CornerRadius(Theme.R3),   // 18 — soft corners, matches Ui.Card on Home
            BorderBrush     = Theme.Border,
            BorderThickness = new Thickness(1),
            Padding         = new Thickness(14, 12, 14, 12),
            Margin          = new Thickness(0, 4, 0, 0),
            Effect          = Ui.CardShadow,                // same soft elevation as Home (kills the "flat/sharp" feel)
            Child           = new StackPanel { Orientation = Orientation.Vertical },
        };

        private static StackPanel CardInner(Border card) => (StackPanel)card.Child;

        private static UIElement SectionHeader(string text) => new TextBlock
        {
            Text       = text,
            FontSize   = Theme.TSubhead,
            FontFamily = Theme.Font,
            FontWeight = FontWeights.SemiBold,
            Foreground = Theme.FgSecondary,
            TextWrapping = TextWrapping.Wrap,
            Margin     = new Thickness(2, 12, 0, 6),
        };

        private static Border InsufficientDataCard(int remaining, string feature)
        {
            var c = Card();
            CardInner(c).Children.Add(Placeholder(
                $"Need {remaining} more session{(remaining == 1 ? "" : "s")} to unlock {feature}."));
            return c;
        }

        private static UIElement Placeholder(string text) => new TextBlock
        {
            Text         = text,
            FontSize     =  12,
            FontFamily   = Theme.Font,
            Foreground   = FgHint,
            TextWrapping = TextWrapping.Wrap,
            Padding      = new Thickness(0, 4, 0, 4),
        };

        private static UIElement InsightText(string text) => new Border
        {
            Background      = new SolidColorBrush(Color.FromArgb(18, 16, 185, 129)),
            BorderBrush     = new SolidColorBrush(Color.FromArgb(120, 16, 185, 129)),
            BorderThickness = new Thickness(2, 0, 0, 0),
            CornerRadius    = new CornerRadius(0, 4, 4, 0),
            Padding         = new Thickness(8, 6, 8, 6),
            Margin          = new Thickness(0, 4, 0, 0),
            Child = new TextBlock
            {
                Text         = $"💡  {text}",
                FontSize     =  12,
                FontFamily   = Theme.Font,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
            },
        };

        private static Border Divider() => new Border
        {
            Height     = 1,
            Background = new SolidColorBrush(Color.FromArgb(25, 255, 255, 255)),
            Margin     = new Thickness(0, 6, 0, 6),
        };

        private static UIElement DigestStatRow(string label, string value, string change, double? delta)
        {
            var g = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(70) });

            g.Children.Add(new TextBlock
            {
                Text              = label,
                FontSize          =  12,
                FontFamily        = Theme.Font,
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            });

            if (change != null)
            {
                Color cc = delta.HasValue && delta.Value > 0 ? ColStable
                         : delta.HasValue && delta.Value < 0 ? ColCritical
                         : Color.FromRgb(99, 99, 102);
                var changeLbl = new TextBlock
                {
                    Text              = change,
                    FontSize          =  12,
                    FontFamily        = Theme.Font,
                    Foreground        = new SolidColorBrush(cc),
                    VerticalAlignment = VerticalAlignment.Center,
                    TextAlignment     = TextAlignment.Right,
                };
                Grid.SetColumn(changeLbl, 1);
                g.Children.Add(changeLbl);
            }

            var valueLbl = new TextBlock
            {
                Text              = value,
                FontSize          = 12,
                FontFamily        = Theme.Font,
                FontWeight        = FontWeights.SemiBold,
                Foreground        = FgPrimary,
                VerticalAlignment = VerticalAlignment.Center,
                TextAlignment     = TextAlignment.Right,
            };
            Grid.SetColumn(valueLbl, 2);
            g.Children.Add(valueLbl);
            return g;
        }

        private static UIElement TwoColRow(string label, string value, Color valueColor)
        {
            var g = new Grid { Margin = new Thickness(0, 2, 0, 2) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            g.Children.Add(new TextBlock
            {
                Text              = label,
                FontSize          =  12,
                FontFamily        = Theme.Font,
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
            });

            var vLbl = new TextBlock
            {
                Text      = value,
                FontSize  =  12,
                FontFamily = Theme.Font,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(valueColor),
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(vLbl, 1);
            g.Children.Add(vLbl);
            return g;
        }

        private static TextBlock MakeNavArrow(string text, bool enabled) => new TextBlock
        {
            Text              = text,
            FontSize          = 13,
            FontFamily        = Theme.Font,
            Foreground        = enabled
                ? new SolidColorBrush(Color.FromRgb(16, 185, 129))
                : new SolidColorBrush(Color.FromRgb(60, 60, 64)),
            Cursor            = enabled ? Cursors.Hand : Cursors.Arrow,
            VerticalAlignment = VerticalAlignment.Center,
            Padding           = new Thickness(4, 0, 4, 0),
        };

        private static Border MakeHeaderBtn(string text)
        {
            var lbl = new TextBlock
            {
                Text              = text,
                FontSize          = 13,
                FontFamily        = Theme.Font,
                Foreground        = new SolidColorBrush(Color.FromRgb(142, 142, 147)),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Width             = 40,
                Background        = Brushes.Transparent,
                Cursor            = Cursors.Hand,
                Child             = lbl,
                VerticalAlignment = VerticalAlignment.Center,
            };
            btn.MouseEnter += (_, __) => lbl.Foreground =
                new SolidColorBrush(Color.FromRgb(220, 220, 224));
            btn.MouseLeave += (_, __) => lbl.Foreground =
                new SolidColorBrush(Color.FromRgb(142, 142, 147));
            return btn;
        }

        private static string FormatChange(double delta, string unit)
        {
            if (delta > 0) return $"↑ +{delta:F0}{unit}";
            if (delta < 0) return $"↓ {delta:F0}{unit}";
            return $"→ 0{unit}";
        }
    }
}
