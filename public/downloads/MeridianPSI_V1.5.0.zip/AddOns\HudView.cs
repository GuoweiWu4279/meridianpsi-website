using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>How loud the HUD should be — a function of divergence (process, not P&L).</summary>
    internal enum HudSalience { Composed, Caution, Warning, Critical }

    /// <summary>
    /// HUD — the floating in-session glance. Derived from UX_DESIGN_ROOT.md §2.1:
    /// a PUSH surface whose salience is DYNAMIC. When composed it recedes to near-nothing;
    /// as the trader diverges it climbs a cost-ordered ladder — ambient color → focal label
    /// that NAMES the breach → consequence → (live: Guard friction). It tracks PROCESS
    /// divergence, never P&L, and only speaks while an interrupt can still change the outcome.
    /// PURE WPF; the live PsiOverlayWindow drives this with the real salience state.
    /// </summary>
    internal static class HudView
    {
        public static FrameworkElement Build() => Build(HudSalience.Warning);

        public static FrameworkElement Build(HudSalience s)
        {
            bool composed = s == HudSalience.Composed;
            Brush zone = ZoneBrush(s);
            double psi = PsiFor(s);

            var card = new StackPanel { Margin = new Thickness(Theme.S4) };

            // ── Header: monitor id + mode, quiet always ──────────────────────
            var header = new Grid();
            header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var title = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            title.Children.Add(Ui.Txt("PSI MONITOR", Theme.TCaption, Theme.FgSecondary, FontWeights.SemiBold));
            var sim = new Border { Background = new SolidColorBrush(Theme.ColorOf(Theme.Caution)) { Opacity = 0.9 }, CornerRadius = new CornerRadius(3), Margin = new Thickness(Theme.S2, 0, 0, 0), Padding = new Thickness(5, 1, 5, 1) };
            sim.Child = Ui.Txt("SIM", 9, Theme.BgWindow, FontWeights.Bold);
            title.Children.Add(sim);
            Grid.SetColumn(title, 0); header.Children.Add(title);
            var icons = Ui.Txt("☰   ✎   ⤢   ✕", Theme.TBody, Theme.FgHint);
            Grid.SetColumn(icons, 1); header.Children.Add(icons);
            card.Children.Add(header);

            // ── PSI value + zone + sparkline ─────────────────────────────────
            var psiRow = new Grid { Margin = new Thickness(0, Theme.S4, 0, 0) };
            psiRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            psiRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var psiBlock = new StackPanel();
            var psiVal = new StackPanel { Orientation = Orientation.Horizontal };
            psiVal.Children.Add(Ui.Txt(psi.ToString("0"), Theme.TDisplay, zone, FontWeights.Bold));
            var znTb = Ui.Txt(ZoneName(s), Theme.TCaption, zone, FontWeights.Bold);
            znTb.VerticalAlignment = VerticalAlignment.Bottom; znTb.Margin = new Thickness(Theme.S2, 0, 0, 6);
            psiVal.Children.Add(znTb);
            psiBlock.Children.Add(psiVal);
            psiBlock.Children.Add(Ui.Txt(composed ? "trading your plan" : "PSI · discipline state", Theme.TCaption, Theme.FgHint));
            Grid.SetColumn(psiBlock, 0); psiRow.Children.Add(psiBlock);

            var spark = new SparkAreaChart { Values = SparkFor(s), MinY = 35, MaxY = 100, Stroke = composed ? Theme.FgHint : zone, ChartHeight = 46 };
            spark.VerticalAlignment = VerticalAlignment.Center; spark.Margin = new Thickness(Theme.S4, 8, 0, 0);
            Grid.SetColumn(spark, 1); psiRow.Children.Add(spark);
            card.Children.Add(psiRow);

            // ── Escalation band: name the breach + the consequence ───────────
            // Silent when composed (no band at all). At Caution it's a soft hint; at
            // Warning it NAMES the specific breach; at Critical it adds the consequence
            // (and in the live overlay, this is where Guard friction engages).
            string breach = BreachFor(s);
            if (breach != null)
            {
                var band = new StackPanel { Margin = new Thickness(0, Theme.S3, 0, 0) };
                var tint = new SolidColorBrush(Theme.ColorOf(zone)) { Opacity = s == HudSalience.Critical ? 0.20 : 0.12 }; tint.Freeze();
                var brow = new StackPanel { Orientation = Orientation.Horizontal };
                brow.Children.Add(new Border { Width = 6, Height = 6, CornerRadius = new CornerRadius(99), Background = zone, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, Theme.S2, 0) });
                brow.Children.Add(Ui.Txt(breach, Theme.TBody, zone, FontWeights.Bold));
                var inner = new StackPanel();
                inner.Children.Add(brow);
                string consequence = ConsequenceFor(s);
                if (consequence != null)
                {
                    var c = Ui.Txt(consequence, Theme.TCaption, s == HudSalience.Critical ? Theme.Critical : Theme.FgSecondary, FontWeights.SemiBold);
                    c.Margin = new Thickness(Theme.S3 + 2, 2, 0, 0);
                    inner.Children.Add(c);
                }
                band.Children.Add(new Border { Background = tint, CornerRadius = new CornerRadius(Theme.R1), Padding = new Thickness(Theme.S3, Theme.S2, Theme.S3, Theme.S2), Child = inner });
                card.Children.Add(band);
            }
            else if (composed)
            {
                var clear = Ui.Txt("✓  Clear — nothing to flag", Theme.TCaption, Theme.FgHint);
                clear.Margin = new Thickness(0, Theme.S3, 0, 0);
                card.Children.Add(clear);
            }

            // ── Session stats (always, quiet) ────────────────────────────────
            var stats = new Border { Margin = new Thickness(0, Theme.S4, 0, 0), Padding = new Thickness(0, Theme.S3, 0, Theme.S3), BorderBrush = Theme.Border, BorderThickness = new Thickness(0, 1, 0, 1) };
            var sg = new UniformGrid { Columns = 4 };
            sg.Children.Add(MiniStat("TRADES", "5", Theme.FgPrimary));
            sg.Children.Add(MiniStat("WIN", "80%", Theme.FgPrimary));
            sg.Children.Add(MiniStat("P&L", "+$390", Theme.Good));
            sg.Children.Add(MiniStat("TIME", "15m", Theme.FgPrimary));
            stats.Child = sg;
            card.Children.Add(stats);

            // ── Signal bars — escalate with severity; muted/hidden when composed ─
            if (!composed)
            {
                var sig = new StackPanel { Margin = new Thickness(0, Theme.S3, 0, 0) };
                foreach (var bar in SignalsFor(s)) sig.Children.Add(Ui.MetricBar(bar.Item1, bar.Item2, bar.Item3, ((int)(bar.Item2 * 100)).ToString()));
                card.Children.Add(sig);
            }

            // ── Manual debrief trigger (always) ──────────────────────────────
            var end = Ui.Button("End session & review  →", BtnVariant.Secondary);
            end.HorizontalAlignment = HorizontalAlignment.Stretch;
            end.Margin = new Thickness(0, Theme.S4, 0, 0);
            ((TextBlock)((Border)end).Child).HorizontalAlignment = HorizontalAlignment.Center;
            card.Children.Add(end);

            // Border ESCALATES: dim hairline when composed → bold zone edge at Critical.
            Brush border = composed ? Theme.Border : zone;
            double bt = s == HudSalience.Critical ? 2.2 : s == HudSalience.Warning ? 1.5 : 1;
            return new Border
            {
                Background = Theme.BgWindow,
                BorderBrush = border,
                BorderThickness = new Thickness(bt),
                CornerRadius = new CornerRadius(Theme.R3),
                Child = card,
            };
        }

        /// <summary>The escalation ladder, 4 states side by side, for offline review.</summary>
        public static FrameworkElement BuildLadder()
        {
            var row = new StackPanel { Orientation = Orientation.Horizontal };
            var states = new[] { HudSalience.Composed, HudSalience.Caution, HudSalience.Warning, HudSalience.Critical };
            var caps = new[] { "COMPOSED — recede to ambient", "CAUTION — a soft hint", "WARNING — name the breach", "CRITICAL — consequence + Guard" };
            for (int i = 0; i < states.Length; i++)
            {
                var col = new StackPanel { Width = 348, Margin = new Thickness(0, 0, Theme.S5, 0) };
                var cap = Ui.Txt(caps[i], Theme.TCaption, Theme.FgHint, FontWeights.SemiBold);
                cap.Margin = new Thickness(2, 0, 0, Theme.S2);
                col.Children.Add(cap);
                col.Children.Add(Build(states[i]));
                row.Children.Add(col);
            }
            var note = Ui.Txt("As the trader corrects (size back within rules), the HUD recedes back down this ladder — standing down is itself the signal: “you fixed it.” Salience tracks PROCESS, never P&L: a disciplined loser stays quiet; a reckless winner lights up.", Theme.TCaption, Theme.FgHint);
            note.Margin = new Thickness(2, Theme.S4, 0, 0); note.MaxWidth = 1100;
            var wrap = new StackPanel();
            wrap.Children.Add(row);
            wrap.Children.Add(note);
            return new Border { Background = Theme.BgWindow, Padding = new Thickness(Theme.S6), Child = wrap };
        }

        private static double PsiFor(HudSalience s) => s == HudSalience.Composed ? 91 : s == HudSalience.Caution ? 76 : s == HudSalience.Warning ? 60 : 43;
        private static Brush ZoneBrush(HudSalience s) => s == HudSalience.Composed ? Theme.Stable : s == HudSalience.Caution ? Theme.Caution : s == HudSalience.Warning ? Theme.Warning : Theme.Critical;
        private static string ZoneName(HudSalience s) => s == HudSalience.Composed ? "CLEAR" : s == HudSalience.Caution ? "CAUTION" : s == HudSalience.Warning ? "WARNING" : "CRITICAL";

        private static string BreachFor(HudSalience s)
        {
            switch (s)
            {
                case HudSalience.Composed: return null;
                case HudSalience.Caution:  return "Size creeping up — 7, your max is 6";
                case HudSalience.Warning:  return "Size 9 — 3 over your max";
                default:                   return "Size 12 — 2× your limit, no stop";
            }
        }
        private static string ConsequenceFor(HudSalience s)
        {
            switch (s)
            {
                case HudSalience.Warning:  return "Step away before you add again";
                case HudSalience.Critical: return "Guard pauses you in 5s";
                default:                   return null;
            }
        }
        private static List<double> SparkFor(HudSalience s)
        {
            switch (s)
            {
                case HudSalience.Composed: return new List<double> { 88, 90, 89, 91, 90, 92, 91, 91, 91 };
                case HudSalience.Caution:  return new List<double> { 92, 90, 88, 84, 82, 80, 78, 77, 76 };
                case HudSalience.Warning:  return new List<double> { 88, 82, 74, 70, 66, 63, 61, 60, 60 };
                default:                   return new List<double> { 80, 70, 58, 52, 49, 46, 44, 43, 43 };
            }
        }
        private static List<Tuple<string, double, Brush>> SignalsFor(HudSalience s)
        {
            var list = new List<Tuple<string, double, Brush>>();
            switch (s)
            {
                case HudSalience.Caution:
                    list.Add(Tuple.Create("D3 Size", 0.45, Theme.Caution));
                    break;
                case HudSalience.Warning:
                    list.Add(Tuple.Create("D3 Size", 0.78, Theme.Warning));
                    list.Add(Tuple.Create("D1 Revenge", 0.30, Theme.Caution));
                    break;
                case HudSalience.Critical:
                    list.Add(Tuple.Create("D3 Size", 0.95, Theme.Critical));
                    list.Add(Tuple.Create("D1 Revenge", 0.52, Theme.Warning));
                    break;
            }
            return list;
        }

        private static StackPanel MiniStat(string label, string value, Brush color)
        {
            var sp = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            var v = Ui.Txt(value, Theme.TSubhead, color, FontWeights.Bold);
            v.HorizontalAlignment = HorizontalAlignment.Center;
            sp.Children.Add(v);
            var l = Ui.Txt(label, 10, Theme.FgHint, FontWeights.SemiBold);
            l.HorizontalAlignment = HorizontalAlignment.Center;
            sp.Children.Add(l);
            return sp;
        }
    }
}
