using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// HOME / TODAY — the daily landing page. A bento layout that FILLS the canvas in
    /// stacked rows of tiles (no tall-skinny column leaving a void):
    ///   • read band   — composure + month KPIs (full-width strip)
    ///   • hero        — the ONE thing to watch today (full-width focus banner)
    ///   • analytics   — trajectory · yesterday's lesson · what wrecks me  (3-tile row)
    ///   • prep        — pre-session ritual · armed-to-stop-you guardrails  (2-tile row)
    ///   • Start       — commit
    /// Emerald accent, ≥12px text, Theme tokens, balanced tiles.
    /// </summary>
    internal static class PreSessionView
    {
        public static FrameworkElement Build(PreSessionData d, Action onStart = null,
            System.Collections.Generic.HashSet<string> ritualDone = null, Action<string> onRitualToggle = null,
            Action onRitualAdd = null, Action<string> onRitualRemove = null,
            Action onOpenIntel = null, Action onOpenLesson = null, Action onOpenWrecks = null)
        {
            var root = new StackPanel();

            if (d.HasComposure || d.HasKpis)
                root.Children.Add(WithBottom(ReadBand(d), Theme.S4));

            root.Children.Add(WithBottom(HeroCard(d), Theme.S4));

            var analytics = TileRow(Theme.S4, TrajectoryCard(d, onOpenIntel), LessonCard(d, onOpenLesson), WrecksCard(d, onOpenWrecks));
            if (analytics != null) root.Children.Add(WithBottom(analytics, Theme.S4));

            var prep = TileRow(Theme.S4, RitualCard(d, ritualDone, onRitualToggle, onRitualAdd, onRitualRemove), GuardrailsCard(d));
            if (prep != null) root.Children.Add(WithBottom(prep, Theme.S4));

            if (!string.IsNullOrEmpty(d.StandingLine))
                root.Children.Add(WithBottom(Ui.Txt(d.StandingLine, Theme.TCaption, Theme.FgHint), Theme.S4));

            root.Children.Add(StartButton(onStart));

            return Ui.Page(root, 1320);
        }

        private static FrameworkElement WithBottom(FrameworkElement el, double gap)
        {
            el.Margin = new Thickness(0, 0, 0, gap);
            return el;
        }

        // Equal-width tile row (skips null cards); all tiles stretch to the row's height.
        private static FrameworkElement TileRow(double gap, params FrameworkElement[] cards)
        {
            int n = 0; foreach (var c in cards) if (c != null) n++;
            if (n == 0) return null;
            var g = new Grid();
            for (int i = 0; i < n; i++)
            {
                if (i > 0) g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(gap) });
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            }
            int col = 0;
            foreach (var c in cards)
            {
                if (c == null) continue;
                c.VerticalAlignment = VerticalAlignment.Stretch;
                Grid.SetColumn(c, col); g.Children.Add(c); col += 2;
            }
            return g;
        }

        // ── Read band: composure + month KPIs (one card, hairline-divided cells) ──
        private static FrameworkElement ReadBand(PreSessionData d)
        {
            var g = new Grid();
            for (int i = 0; i < 4; i++)
                g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(i == 0 ? 1.5 : 1, GridUnitType.Star) });

            Brush c = Theme.Zone(d.Composure30);
            var comp = new StackPanel { Margin = new Thickness(Theme.S5, Theme.S4, Theme.S5, Theme.S4) };
            comp.Children.Add(Ui.Txt("Today's read", Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            var crow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 6, 0, 0) };
            var big = Ui.Num((d.HasComposure ? d.Composure30 : 0) + "%", Theme.TTitle, c, FontWeights.SemiBold);
            big.VerticalAlignment = VerticalAlignment.Center;
            crow.Children.Add(big);
            var cl = Ui.Txt(d.HasComposure ? "30-day composure" : "still learning", Theme.TBody, Theme.FgSecondary);
            cl.VerticalAlignment = VerticalAlignment.Bottom; cl.Margin = new Thickness(Theme.S2, 0, 0, 4);
            crow.Children.Add(cl);
            comp.Children.Add(crow);
            if (!string.IsNullOrEmpty(d.ComposureRead))
            {
                var rl = Ui.Txt(d.ComposureRead, Theme.TCaption, Theme.FgHint);
                rl.Margin = new Thickness(0, 5, 0, 0); rl.TextWrapping = TextWrapping.Wrap;
                comp.Children.Add(rl);
            }
            AddCell(g, 0, comp, false);

            AddCell(g, 1, Kpi("Last session", d.LastComp >= 0 ? d.LastComp + "%" : "—",
                d.LastComp >= 0 ? Theme.Zone(d.LastComp) : Theme.FgHint, d.LastDate), true);
            AddCell(g, 2, Kpi("Net P&L · month", Money(d.NetMonthPnl),
                d.NetMonthPnl >= 0 ? Theme.Good : Theme.Bad, d.MonthSessions + " sessions"), true);
            AddCell(g, 3, Kpi("Stable days", d.StableDays + " / " + Math.Max(d.MonthSessions, d.StableDays),
                Theme.FgPrimary, "composure 70%+"), true);

            return Ui.Card(g, 0);
        }

        private static void AddCell(Grid g, int col, FrameworkElement el, bool divider)
        {
            if (divider)
            {
                var b = new Border { BorderBrush = Theme.Border, BorderThickness = new Thickness(1, 0, 0, 0), Child = el };
                Grid.SetColumn(b, col); g.Children.Add(b);
            }
            else { Grid.SetColumn(el, col); g.Children.Add(el); }
        }

        private static FrameworkElement Kpi(string label, string value, Brush vb, string sub)
        {
            var sp = new StackPanel { Margin = new Thickness(Theme.S5, Theme.S4, Theme.S5, Theme.S4), VerticalAlignment = VerticalAlignment.Center };
            sp.Children.Add(Ui.Txt(label, Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            var v = Ui.Num(value, Theme.TSubhead + 6, vb, FontWeights.SemiBold);
            v.Margin = new Thickness(0, 6, 0, 3); sp.Children.Add(v);
            sp.Children.Add(Ui.Txt(sub ?? "", Theme.TCaption, Theme.FgSecondary));
            return sp;
        }

        // ── Hero: the one thing to watch — full-width focus banner (2-col inside) ──
        private static FrameworkElement HeroCard(PreSessionData d)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.35, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(Theme.S7) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

            var left = new StackPanel();
            left.Children.Add(Ui.Txt(d.HasData ? "One thing to watch today" : "Getting started",
                Theme.TCaption, d.HasData ? Theme.Accent : Theme.FgHint, FontWeights.SemiBold));
            var title = Ui.Txt(d.FocusTitle, Theme.THeadline, Theme.FgPrimary, FontWeights.SemiBold);
            title.Margin = new Thickness(0, Theme.S3, 0, 0); title.TextWrapping = TextWrapping.Wrap;
            left.Children.Add(title);
            if (!string.IsNullOrEmpty(d.FocusDetail))
            {
                var detail = Ui.Txt(d.FocusDetail, Theme.TSubhead, Theme.FgPrimary);
                detail.Margin = new Thickness(0, Theme.S4, 0, 0); detail.LineHeight = Theme.TSubhead + 9;
                detail.TextWrapping = TextWrapping.Wrap; left.Children.Add(detail);
            }
            Grid.SetColumn(left, 0); g.Children.Add(left);

            if (d.AlsoWatch != null && d.AlsoWatch.Count > 0)
            {
                var right = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
                right.Children.Add(Ui.Txt("Also keep in mind", Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
                foreach (var w in d.AlsoWatch)
                {
                    var roww = new DockPanel { Margin = new Thickness(0, Theme.S3, 0, 0), LastChildFill = true };
                    var dt = Dot(Theme.Accent, 4); dt.VerticalAlignment = VerticalAlignment.Top; dt.Margin = new Thickness(0, 7, Theme.S2, 0);
                    DockPanel.SetDock(dt, Dock.Left); roww.Children.Add(dt);
                    var t = Ui.Txt(w, Theme.TBody, Theme.FgSecondary); t.TextWrapping = TextWrapping.Wrap; t.LineHeight = Theme.TBody + 5;
                    roww.Children.Add(t);
                    right.Children.Add(roww);
                }
                Grid.SetColumn(right, 2); g.Children.Add(right);
            }

            return Ui.AccentCard(g, d.HasData ? Theme.Accent : Theme.FgHint);
        }

        // ── Analytics tiles ──────────────────────────────────────────────────
        private static FrameworkElement TrajectoryCard(PreSessionData d, Action onOpenIntel)
        {
            if (d.TrajSeries.Count == 0) return null;
            var t = new StackPanel();
            t.Children.Add(RailHead("Composure trend", "Open Intel →", onOpenIntel));
            var hr = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 0) };
            var nowBrush = Theme.Zone(d.TrajNow);
            hr.Children.Add(Ui.Num(d.TrajNow + "%", Theme.TTitle, nowBrush, FontWeights.SemiBold));
            var gd = new StackPanel { VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(Theme.S3, 0, 0, 0) };
            gd.Children.Add(Ui.Txt(ZoneName(d.TrajNow), Theme.TCaption, nowBrush, FontWeights.SemiBold));
            if (!string.IsNullOrEmpty(d.TrajDelta)) gd.Children.Add(Ui.Txt(d.TrajDelta, Theme.TCaption, Theme.FgHint));
            hr.Children.Add(gd);
            t.Children.Add(hr);
            var spark = Sparkline(d.TrajSeries, nowBrush);
            spark.Margin = new Thickness(0, Theme.S4, 0, 0);
            t.Children.Add(spark);
            // Anchor the number: it's a composure score across the recent sessions.
            var cap = Ui.Txt("composure · last " + d.TrajSeries.Count + " sessions", Theme.TCaption, Theme.FgHint);
            cap.Margin = new Thickness(0, Theme.S2, 0, 0);
            t.Children.Add(cap);
            return Ui.Card(t, Theme.S4 + 2);
        }

        private static FrameworkElement LessonCard(PreSessionData d, Action onOpenLesson)
        {
            if (string.IsNullOrEmpty(d.LessonText)) return null;
            var t = new StackPanel();
            t.Children.Add(RailHead("Yesterday's lesson", d.LessonDate, onOpenLesson));
            var l = Ui.Txt(d.LessonText, Theme.TBody, Theme.FgPrimary);
            l.TextWrapping = TextWrapping.Wrap; l.LineHeight = Theme.TBody + 6;
            t.Children.Add(l);
            return Ui.Card(t, Theme.S4 + 2);
        }

        private static FrameworkElement WrecksCard(PreSessionData d, Action onOpenWrecks)
        {
            if (d.Leaks.Count == 0) return null;
            var t = new StackPanel();
            t.Children.Add(RailHead("What wrecks you most", "worst days", onOpenWrecks));
            int rank = 1;
            foreach (var lk in d.Leaks) { t.Children.Add(LeakRow(rank, lk)); rank++; }
            return Ui.Card(t, Theme.S4 + 2);
        }

        // ── Prep tiles ───────────────────────────────────────────────────────
        private static FrameworkElement RitualCard(PreSessionData d, System.Collections.Generic.HashSet<string> done,
            Action<string> onToggle, Action onAdd, Action<string> onRemove)
        {
            // Empty + no way to add → nothing to show (static harness with no items).
            if (d.Ritual.Count == 0 && onAdd == null) return null;
            // Live checked-state when supplied; for the static harness, default to all-but-last ticked.
            var state = new System.Collections.Generic.HashSet<string>(done ?? new System.Collections.Generic.HashSet<string>());
            if (done == null) for (int k = 0; k < d.Ritual.Count - 1; k++) state.Add(d.Ritual[k]);

            var t = new StackPanel();
            var countTb = Ui.Txt(state.Count + "/" + d.Ritual.Count, Theme.TCaption, Theme.Accent, FontWeights.SemiBold);
            t.Children.Add(RailHeadWith("Pre-session ritual", countTb));
            int[] count = { state.Count };
            foreach (var step in d.Ritual)
            {
                string item = step;
                Action rowToggle = onToggle == null ? (Action)null : () =>
                {
                    bool nowOn = !state.Contains(item);
                    if (nowOn) state.Add(item); else state.Remove(item);
                    count[0] += nowOn ? 1 : -1;
                    countTb.Text = count[0] + "/" + d.Ritual.Count;
                    onToggle(item);
                };
                Action rowRemove = onRemove == null ? (Action)null : () => onRemove(item);
                t.Children.Add(RitualRow(item, state.Contains(item), rowToggle, rowRemove));
            }
            if (d.Ritual.Count == 0)
                t.Children.Add(Ui.Txt("No steps yet — add the routine you run before every session.", Theme.TCaption, Theme.FgHint));
            if (onAdd != null) t.Children.Add(AddStepRow(onAdd));
            return Ui.Card(t, Theme.S4 + 2);
        }

        // "+ Add step" — the user builds their OWN ritual; we don't impose one.
        private static FrameworkElement AddStepRow(Action onAdd)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, Theme.S2 + 2, 0, 0), Background = Brushes.Transparent, Cursor = System.Windows.Input.Cursors.Hand };
            var plus = new Border
            {
                Width = 20, Height = 20, CornerRadius = new CornerRadius(5),
                Background = Theme.Tint(Theme.Accent, 18), BorderBrush = Theme.Tint(Theme.Accent, 64), BorderThickness = new Thickness(1),
                VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, Theme.S2 + 2, 0),
                Child = new TextBlock { Text = "+", FontSize = 14, FontWeight = FontWeights.Bold, Foreground = Theme.Accent, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center },
            };
            sp.Children.Add(plus);
            var t = Ui.Txt("Add step", Theme.TBody, Theme.Accent, FontWeights.SemiBold);
            t.VerticalAlignment = VerticalAlignment.Center; sp.Children.Add(t);
            sp.MouseLeftButtonDown += (_, e) => { e.Handled = true; onAdd(); };
            return sp;
        }

        private static FrameworkElement GuardrailsCard(PreSessionData d)
        {
            if (d.Protections.Count == 0) return null;
            var sp = new StackPanel();
            var hdr = new StackPanel { Orientation = Orientation.Horizontal };
            hdr.Children.Add(Dot(Theme.Good, 7));
            hdr.Children.Add(Ui.Txt("Armed to stop you", Theme.TBody, Theme.FgPrimary, FontWeights.Bold));
            sp.Children.Add(hdr);
            var chips = new WrapPanel { Margin = new Thickness(0, Theme.S3, 0, 0) };
            foreach (var p in d.Protections) chips.Children.Add(GuardChip(p.Label, p.Value));
            sp.Children.Add(chips);
            return Ui.Card(sp, Theme.S4 + 2);
        }

        private static FrameworkElement StartButton(Action onStart)
        {
            var start = Ui.Button("Start session  →", BtnVariant.GhostAccent);
            start.Padding = new Thickness(Theme.S4, Theme.S3 + 2, Theme.S4, Theme.S3 + 2);
            start.HorizontalAlignment = HorizontalAlignment.Stretch;
            start.Cursor = System.Windows.Input.Cursors.Hand;
            if (onStart != null) start.MouseLeftButtonDown += (_, e) => { e.Handled = true; onStart(); };
            return start;
        }

        // ── building blocks ─────────────────────────────────────────────────
        private static FrameworkElement RailHead(string title, string right, Action onClick = null)
        {
            var g = new Grid { Margin = new Thickness(0, 0, 0, Theme.S3) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var t = Ui.Txt(title, Theme.TBody, Theme.FgPrimary, FontWeights.Bold);
            Grid.SetColumn(t, 0); g.Children.Add(t);
            if (!string.IsNullOrEmpty(right))
            {
                var r = Ui.Txt(right, Theme.TCaption, Theme.Accent, FontWeights.SemiBold);
                r.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(r, 1); g.Children.Add(r);
                // A right-side accent label is only a LINK when it has somewhere to go.
                // Without a handler it would read as clickable but do nothing (dead link).
                if (onClick != null)
                {
                    r.Cursor = System.Windows.Input.Cursors.Hand;
                    r.MouseEnter += (_, __) => r.Opacity = 0.65;
                    r.MouseLeave += (_, __) => r.Opacity = 1.0;
                    r.MouseLeftButtonDown += (_, e) => { e.Handled = true; onClick(); };
                }
            }
            return g;
        }

        private static FrameworkElement RailHeadWith(string title, FrameworkElement right)
        {
            var g = new Grid { Margin = new Thickness(0, 0, 0, Theme.S3) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var t = Ui.Txt(title, Theme.TBody, Theme.FgPrimary, FontWeights.Bold);
            Grid.SetColumn(t, 0); g.Children.Add(t);
            if (right != null) { right.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(right, 1); g.Children.Add(right); }
            return g;
        }

        private static string ZoneName(int c) => c >= 88 ? "Stable" : c >= 72 ? "Caution" : c >= 55 ? "Warning" : "Critical";

        private static FrameworkElement LeakRow(int rank, PreSessionLeak lk)
        {
            var g = new Grid { Margin = new Thickness(0, 5, 0, 5) };
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(22) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var rk = Ui.Txt("#" + rank, Theme.TCaption, Theme.FgHint, FontWeights.Bold);
            rk.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(rk, 0); g.Children.Add(rk);
            var nm = Ui.Txt(lk.Name, Theme.TBody, Theme.FgPrimary, FontWeights.SemiBold);
            nm.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(nm, 1); g.Children.Add(nm);
            var sev = lk.Sev == 0 ? Theme.Bad : Theme.Warning;
            var tag = Ui.Pill(lk.Freq + (lk.Sev == 0 ? " · HIGH" : " · MED"), sev);
            tag.VerticalAlignment = VerticalAlignment.Center; Grid.SetColumn(tag, 2); g.Children.Add(tag);
            return g;
        }

        private static FrameworkElement RitualRow(string text, bool ticked, Action onToggle, Action onRemove)
        {
            var row = new Grid { Margin = new Thickness(0, 6, 0, 6) };
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            row.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var sp = new StackPanel { Orientation = Orientation.Horizontal, Background = Brushes.Transparent };
            var box = new Border
            {
                Width = 20, Height = 20, CornerRadius = new CornerRadius(5),
                BorderThickness = new Thickness(1),
                VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, Theme.S2 + 2, 0),
            };
            var check = new TextBlock { Text = "✓", FontSize = 13, FontWeight = FontWeights.Bold, Foreground = Theme.Accent, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            box.Child = check;
            var t = Ui.Txt(text, Theme.TBody, Theme.FgPrimary);
            t.VerticalAlignment = VerticalAlignment.Center;
            sp.Children.Add(box); sp.Children.Add(t);
            Grid.SetColumn(sp, 0); row.Children.Add(sp);

            Action<bool> apply = on =>
            {
                box.Background  = on ? Theme.Tint(Theme.Accent, 32) : Theme.BgElevated;
                box.BorderBrush = on ? Theme.Accent : Theme.Border;
                check.Visibility = on ? Visibility.Visible : Visibility.Collapsed;
                t.Foreground = on ? Theme.FgSecondary : Theme.FgPrimary;
            };
            bool[] cur = { ticked };
            apply(cur[0]);

            if (onToggle != null)
            {
                sp.Cursor = System.Windows.Input.Cursors.Hand;
                sp.MouseLeftButtonDown += (_, e) => { e.Handled = true; cur[0] = !cur[0]; apply(cur[0]); onToggle(); };
            }

            // Per-step remove (✕) — the user owns the list, so they can drop any step.
            if (onRemove != null)
            {
                var x = new TextBlock { Text = "✕", FontSize = 12, Foreground = Theme.FgHint, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
                var xb = new Border { Child = x, Width = 22, Height = 22, CornerRadius = new CornerRadius(5), Background = Brushes.Transparent, Cursor = System.Windows.Input.Cursors.Hand, VerticalAlignment = VerticalAlignment.Center };
                xb.MouseEnter += (_, __) => { xb.Background = Theme.BgElevated; x.Foreground = Theme.Bad; };
                xb.MouseLeave += (_, __) => { xb.Background = Brushes.Transparent; x.Foreground = Theme.FgHint; };
                xb.MouseLeftButtonDown += (_, e) => { e.Handled = true; onRemove(); };
                Grid.SetColumn(xb, 1); row.Children.Add(xb);
            }
            return row;
        }

        // Sparkline: composure series (0..100) as a thin zone-coloured line.
        private static FrameworkElement Sparkline(List<int> series, Brush color)
        {
            const double W = 260, H = 46;
            var poly = new Polyline { Stroke = color, StrokeThickness = 2.5, StrokeLineJoin = PenLineJoin.Round, StrokeStartLineCap = PenLineCap.Round, StrokeEndLineCap = PenLineCap.Round };
            var pts = new PointCollection();
            int n = series.Count;
            for (int i = 0; i < n; i++)
            {
                double x = n <= 1 ? 0 : (double)i / (n - 1) * W;
                double y = H - Math.Max(0, Math.Min(100, series[i])) / 100.0 * H;
                pts.Add(new Point(x, y));
            }
            poly.Points = pts;
            var canvas = new Canvas { Width = W, Height = H };
            canvas.Children.Add(poly);
            return new Viewbox { Stretch = Stretch.Fill, Height = H, Child = canvas, HorizontalAlignment = HorizontalAlignment.Stretch };
        }

        // A scannable guardrail chip: short label (muted) + value (primary).
        private static UIElement GuardChip(string label, string value)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            sp.Children.Add(Dot(Theme.Good, 6));
            var l = Ui.Txt(ShortLabel(label), Theme.TCaption, Theme.FgSecondary);
            l.VerticalAlignment = VerticalAlignment.Center; sp.Children.Add(l);
            var v = Ui.Txt(value, Theme.TCaption, Theme.FgPrimary, FontWeights.SemiBold);
            v.VerticalAlignment = VerticalAlignment.Center; v.Margin = new Thickness(Theme.S2, 0, 0, 0);
            sp.Children.Add(v);
            return new Border
            {
                Background = Theme.BgElevated, BorderBrush = Theme.Border, BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(Theme.R2), Padding = new Thickness(Theme.S3, 6, Theme.S3, 6),
                Margin = new Thickness(0, 0, Theme.S2, Theme.S2), Child = sp,
            };
        }

        private static Border Dot(Brush b, double size) => new Border
        {
            Width = size, Height = size, CornerRadius = new CornerRadius(99), Background = b,
            VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, Theme.S2, 0),
        };

        private static string Money(double v) => (v >= 0 ? "+$" : "-$") + Math.Abs(v).ToString("0");

        private static string ShortLabel(string label)
        {
            switch (label)
            {
                case "Daily loss limit":   return "Loss cap";
                case "Pause after losses": return "Pause";
                case "Max position size":  return "Max size";
                case "Session window":     return "Window";
                default:                   return label;
            }
        }

        // ── Harness previews ────────────────────────────────────────────────
        public static FrameworkElement BuildPreview()
        {
            var d = new PreSessionData
            {
                DateText = "THU, JUNE 4", HasData = true, HasComposure = true, HasKpis = true,
                Composure30 = 29, ComposureRead = "Thursdays usually run a little below your average.",
                FocusTitle = "Keep your size flat today.",
                FocusDetail = "Your last 6 oversize adds made money but broke your size rule every time — that's luck, not edge. Keep size flat and let the read build before you press.",
                LastComp = 7, LastDate = "Wed, Jun 3", NetMonthPnl = 78, MonthSessions = 3, StableDays = 0,
                TrajNow = 13, TrajGrade = "D", TrajDelta = "↓ 39 pts · trending down",
                LessonText = "Cut size after your first win — that's when the oversize adds start.",
                LessonDate = "Jun 3 debrief",
            };
            d.AlsoWatch.Add("After 2 losses in a row, step away — that's where revenge entries cluster.");
            d.AlsoWatch.Add("Stop when your window closes at 07:30 — late P&L is usually given back.");
            d.Protections.Add(new PreSessionProt { Label = "Daily loss limit", Value = "$200" });
            d.Protections.Add(new PreSessionProt { Label = "Pause after losses", Value = "2 in a row" });
            d.Protections.Add(new PreSessionProt { Label = "Max position size", Value = "6 contracts" });
            d.Protections.Add(new PreSessionProt { Label = "Session window", Value = "06:30 – 07:30" });
            d.TrajSeries.AddRange(new[] { 71, 64, 58, 53, 40, 28, 31, 24, 13 });
            d.Leaks.Add(new PreSessionLeak { Name = "Rule violations", Freq = "3/3 days", Sev = 0 });
            d.Leaks.Add(new PreSessionLeak { Name = "Revenge entry",   Freq = "3/3 days", Sev = 0 });
            d.Leaks.Add(new PreSessionLeak { Name = "Size spike",      Freq = "2/3 days", Sev = 1 });
            d.Ritual.Add("Reviewed yesterday's lesson");
            d.Ritual.Add("Size plan set — flat, max 6");
            d.Ritual.Add("No open positions");
            d.Ritual.Add("Walked / coffee");
            return Build(d, null, null, null, () => { }, _ => { });
        }

        public static FrameworkElement BuildPreviewFirstRun()
        {
            var d = new PreSessionData
            {
                DateText = "THU, JUNE 4", HasData = false,
                FocusTitle = "Still learning your patterns.",
                FocusDetail = "Trade your plan and stay inside your limits. After a few sessions, " +
                              "Meridian will point you at the one thing most likely to trip you up today.",
                StandingLine = "2 sessions recorded so far.",
            };
            d.Protections.Add(new PreSessionProt { Label = "Daily loss limit", Value = "$200" });
            d.Protections.Add(new PreSessionProt { Label = "Pause after losses", Value = "2 in a row" });
            d.Protections.Add(new PreSessionProt { Label = "Max position size", Value = "6 contracts" });
            d.Protections.Add(new PreSessionProt { Label = "Session window", Value = "06:30 – 07:30" });
            return Build(d);
        }
    }
}
