using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Effects;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal enum BtnVariant { Primary, Secondary, Ghost, GhostAccent, Danger }

    /// <summary>
    /// Reusable WPF component factory built on <see cref="Theme"/> tokens.
    /// PURE WPF (no NinjaTrader types) so it renders offline in the UI harness
    /// and inside NinjaTrader. One implementation per component — replaces the
    /// copy-pasted per-file builders (three different button factories, etc.).
    /// </summary>
    internal static class Ui
    {
        // ── Text ────────────────────────────────────────────────────────
        public static TextBlock Txt(string text, double size, Brush fg, FontWeight? weight = null)
        {
            return new TextBlock
            {
                Text = text ?? "",
                FontFamily = Theme.Font,
                FontSize = size,
                Foreground = fg ?? Theme.FgPrimary,
                TextWrapping = TextWrapping.Wrap,
                FontWeight = weight ?? FontWeights.Normal,
            };
        }

        public static TextBlock SectionHeader(string text)
        {
            // Sentence-case subhead (was tiny ALL-CAPS). Hierarchy comes from size + colour,
            // not from shouting in capitals.
            var tb = Txt(text ?? "", Theme.TSubhead, Theme.FgSecondary, FontWeights.SemiBold);
            tb.Margin = new Thickness(0, 0, 0, Theme.S3);
            return tb;
        }

        // Numeric/figure text with TABULAR numerals (digits share one width) so columns
        // of P&L, PSI, prices, % align like a real financial terminal. Use for all figures.
        public static TextBlock Num(string text, double size, Brush fg, FontWeight? weight = null)
        {
            var tb = Txt(text, size, fg, weight);
            System.Windows.Documents.Typography.SetNumeralAlignment(tb, FontNumeralAlignment.Tabular);
            return tb;
        }

        // ── Card ──────────────────────────────────────────────────────────
        // shadcn card: a FLAT solid surface + a 1px white-alpha hairline border + 10px
        // radius. No gradient, no drop-shadow — the visible border IS the depth. Calm.
        public static readonly Brush  CardFill   = Theme.BgCard;   // flat fill, lifted by a soft shadow
        public static readonly Effect CardShadow = BuildCardShadow();
        private static Effect BuildCardShadow()
        {
            // Subtle lift so a card edge is a soft falloff, not a hard 1px step. Depth via
            // elevation — the flat shadcn card was the source of the "hard台阶/尖锐" feel.
            var e = new DropShadowEffect { Color = Colors.Black, BlurRadius = 24, ShadowDepth = 1, Direction = 270, Opacity = 0.22 };
            e.Freeze();
            return e;
        }

        public static Border Card(UIElement content, double pad = Theme.S4)
        {
            return new Border
            {
                Background = CardFill,
                BorderBrush = Theme.Border,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(Theme.R3),
                Padding = new Thickness(pad),
                Child = content,
                Effect = CardShadow,
            };
        }

        // "Focus" card: a whisper of the accent in the FILL (a tinted highlight, like the
        // reference dashboards' goal card) — NOT a hard left stripe and NOT a coloured
        // outline (both are sharp). The accent eyebrow text inside carries the emphasis.
        public static Border AccentCard(UIElement content, Brush accent, double pad = Theme.S5)
        {
            var ac = Theme.ColorOf(accent ?? Theme.Accent);
            Func<byte, byte, byte> mix = (b, f) => (byte)(b + (f - b) * 0.09);   // 9% accent over the card
            var fill = new SolidColorBrush(Color.FromRgb(mix(22, ac.R), mix(22, ac.G), mix(25, ac.B)));
            fill.Freeze();
            return new Border
            {
                Background = fill,
                BorderBrush = Theme.Border,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(Theme.R3),
                Padding = new Thickness(pad),
                Child = content,
                Effect = CardShadow,
            };
        }

        // ── Page shell ──────────────────────────────────────────────────────
        // Every PULL page wraps its content here: a centered, max-width reading
        // column on the window background. Without this, content stretches to the
        // full (wide) NT8 window and reads as sparse/dumped-top-left. Centering a
        // bounded column is what makes a focused page look INTENTIONAL, not empty.
        public static FrameworkElement Page(UIElement content, double maxWidth = 680)
        {
            var column = new Border
            {
                MaxWidth = maxWidth,
                HorizontalAlignment = HorizontalAlignment.Center,
                Child = content,
            };
            return new Border
            {
                Background = Theme.BgWindow,
                Padding = new Thickness(Theme.S6, Theme.S6, Theme.S6, Theme.S7),
                Child = column,
            };
        }

        // ── Stat tile (KPI box) ─────────────────────────────────────────────
        public static Border StatTile(string label, string value, string sub = null, Brush valueColor = null)
        {
            var stack = new StackPanel();
            stack.Children.Add(Txt(label ?? "", Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));

            var val = Txt(value, Theme.TTitle, valueColor ?? Theme.FgPrimary, FontWeights.SemiBold);
            val.Margin = new Thickness(0, Theme.S1, 0, 0);
            stack.Children.Add(val);

            if (!string.IsNullOrEmpty(sub))
            {
                var s = Txt(sub, Theme.TCaption, Theme.FgSecondary);
                s.Margin = new Thickness(0, Theme.S1, 0, 0);
                stack.Children.Add(s);
            }

            return new Border
            {
                Background = Theme.BgElevated,
                CornerRadius = new CornerRadius(Theme.R2),
                Padding = new Thickness(Theme.S3),
                Child = stack,
            };
        }

        // ── Button ──────────────────────────────────────────────────────────
        public static Border Button(string text, BtnVariant variant = BtnVariant.Primary)
        {
            Brush bg, fg, border = null;
            switch (variant)
            {
                case BtnVariant.Primary: bg = Theme.AccentSolid; fg = Theme.AccentInk; break;   // dark text on the green
                case BtnVariant.Danger:  bg = Theme.Critical; fg = Theme.FgPrimary; break;
                // Calm CTA for full-width buttons: a tinted outline (emerald on faint emerald),
                // not a heavy solid fill. Mirrors the Guard "Add Commitment" treatment.
                case BtnVariant.GhostAccent: bg = Theme.Tint(Theme.Accent, 20); fg = Theme.Accent; border = Theme.Tint(Theme.Accent, 64); break;
                case BtnVariant.Ghost:   bg = Theme.BgCard; fg = Theme.FgPrimary; border = Theme.Border; break;
                default:                 bg = Theme.BgElevated; fg = Theme.FgPrimary; break;
            }

            var tb = Txt(text, Theme.TBody, fg, FontWeights.SemiBold);
            tb.TextWrapping = TextWrapping.NoWrap;
            tb.HorizontalAlignment = HorizontalAlignment.Center;

            var btn = new Border
            {
                Background = bg,
                BorderBrush = border,
                BorderThickness = new Thickness(border == null ? 0 : 1),
                CornerRadius = new CornerRadius(Theme.R2),
                Padding = new Thickness(Theme.S4, Theme.S2 + 1, Theme.S4, Theme.S2 + 1),
                Child = tb,
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor = System.Windows.Input.Cursors.Hand,
            };
            WireLift(btn);
            return btn;
        }

        // ── Micro-interaction: subtle hover-lift + press dip ─────────────────
        // Cosmetic feedback for interactive elements — lifts ~2px on hover, dips on
        // press, animated. Sets RenderTransform, so only use on elements that don't
        // already own one (buttons, chips, nav items — not the page-transition host).
        public static void WireLift(FrameworkElement el, double lift = 2.0)
        {
            // Hover-lift DISABLED. The per-element transform animation re-fired via
            // MouseEnter/Leave as content scrolled under the cursor — that caused the
            // sidebar "bounce" and the scroll jank. Elements keep their existing
            // background-hover feedback (no transform = no repaint storm). Left as a
            // no-op so call sites don't need touching; a cheaper effect can replace it.
            return;
        }

        private static void LiftTo(TranslateTransform tt, double toY)
        {
            tt.BeginAnimation(TranslateTransform.YProperty,
                new System.Windows.Media.Animation.DoubleAnimation(toY, new Duration(TimeSpan.FromMilliseconds(110)))
                { EasingFunction = new System.Windows.Media.Animation.CubicEase { EasingMode = System.Windows.Media.Animation.EasingMode.EaseOut } });
        }

        // Flat, rounded chrome for native Buttons (which need .Click) — a Border + centred
        // ContentPresenter that REPLACES the system template, so there is no grey hover box
        // and no blue default-button focus ring. Pair with FocusVisualStyle = null.
        public static System.Windows.Controls.ControlTemplate FlatButtonTemplate(
            Brush bg, Brush border = null, double radius = 7, double padH = 16, double padV = 7)
        {
            var b = new FrameworkElementFactory(typeof(Border));
            b.SetValue(Border.BackgroundProperty, bg);
            if (border != null) { b.SetValue(Border.BorderBrushProperty, border); b.SetValue(Border.BorderThicknessProperty, new Thickness(1)); }
            b.SetValue(Border.CornerRadiusProperty, new CornerRadius(radius));
            b.SetValue(Border.PaddingProperty, new Thickness(padH, padV, padH, padV));
            var cp = new FrameworkElementFactory(typeof(ContentPresenter));
            cp.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            cp.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
            b.AppendChild(cp);
            return new System.Windows.Controls.ControlTemplate(typeof(System.Windows.Controls.Button)) { VisualTree = b };
        }

        // ── Pill / badge (shadcn): tinted fill + subtle same-hue border + small radius ──
        public static Border Pill(string text, Brush color)
        {
            color = color ?? Theme.Accent;
            var tb = Txt(text, Theme.TCaption, color, FontWeights.SemiBold);
            tb.TextWrapping = TextWrapping.NoWrap;

            return new Border
            {
                Background = Theme.Tint(color, 38),
                CornerRadius = new CornerRadius(999),                 // fully rounded pill
                Padding = new Thickness(Theme.S3, 3, Theme.S3, 3),
                Child = tb,
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Center,
            };
        }

        // ── Metric bar (D1-D7 / composure) ──────────────────────────────────
        public static FrameworkElement MetricBar(string label, double fraction, Brush color, string valueText = null)
        {
            fraction = fraction < 0 ? 0 : fraction > 1 ? 1 : fraction;
            color = color ?? Theme.Accent;

            var grid = new Grid { Margin = new Thickness(0, Theme.S1, 0, Theme.S1) };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(130) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var lbl = Txt(label, Theme.TBody, Theme.FgSecondary);
            lbl.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(lbl, 0);
            grid.Children.Add(lbl);

            // proportional fill using star-sized columns inside the track
            var track = new Grid { Height = 8, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(Theme.S2, 0, Theme.S2, 0) };
            track.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(fraction, GridUnitType.Star) });
            track.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1 - fraction, GridUnitType.Star) });

            var trackBg = new Border { Background = Theme.BgSubtle, CornerRadius = new CornerRadius(4) };
            Grid.SetColumnSpan(trackBg, 2);
            track.Children.Add(trackBg);

            var fill = new Border { Background = color, CornerRadius = new CornerRadius(4) };
            Grid.SetColumn(fill, 0);
            track.Children.Add(fill);

            Grid.SetColumn(track, 1);
            grid.Children.Add(track);

            if (!string.IsNullOrEmpty(valueText))
            {
                var vt = Txt(valueText, Theme.TCaption, Theme.FgSecondary, FontWeights.SemiBold);
                vt.VerticalAlignment = VerticalAlignment.Center;
                Grid.SetColumn(vt, 2);
                grid.Children.Add(vt);
            }

            return grid;
        }

        // ── Layout helpers (kill single-column stacking) ────────────────────
        public static StackPanel Stack(double gap, params UIElement[] children)
        {
            var sp = new StackPanel { Orientation = Orientation.Vertical };
            AddWithGap(sp, gap, false, children);
            return sp;
        }

        public static StackPanel Row(double gap, params UIElement[] children)
        {
            var sp = new StackPanel { Orientation = Orientation.Horizontal };
            AddWithGap(sp, gap, true, children);
            return sp;
        }

        private static void AddWithGap(StackPanel sp, double gap, bool horizontal, UIElement[] children)
        {
            for (int i = 0; i < children.Length; i++)
            {
                var c = children[i];
                if (i < children.Length - 1 && c is FrameworkElement fe)
                    fe.Margin = horizontal ? new Thickness(0, 0, gap, 0) : new Thickness(0, 0, 0, gap);
                sp.Children.Add(c);
            }
        }

        public static UniformGrid TileGrid(int cols, double gap, params UIElement[] children)
        {
            var ug = new UniformGrid { Columns = cols, Margin = new Thickness(-gap / 2) };
            foreach (var c in children)
            {
                if (c is FrameworkElement fe) fe.Margin = new Thickness(gap / 2);
                ug.Children.Add(c);
            }
            return ug;
        }

        public static Border Divider()
        {
            return new Border { Height = 1, Background = Theme.Border, Margin = new Thickness(0, Theme.S4, 0, Theme.S4) };
        }

        /// <summary>Two equal columns separated by a gap.</summary>
        public static Grid Grid2(UIElement left, UIElement right, double gap)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(gap) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            Grid.SetColumn(left, 0); Grid.SetColumn(right, 2);
            g.Children.Add(left); g.Children.Add(right);
            return g;
        }

        /// <summary>iOS-style pill toggle.</summary>
        public static Border Toggle(bool on)
        {
            var knob = new Border
            {
                Width = 16, Height = 16, CornerRadius = new CornerRadius(99), Background = Theme.FgPrimary,
                HorizontalAlignment = on ? HorizontalAlignment.Right : HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(2, 0, 2, 0),
            };
            return new Border { Width = 40, Height = 22, CornerRadius = new CornerRadius(99), Background = on ? Theme.Good : Theme.BgElevated, Child = knob };
        }

        /// <summary>Label (left) + value/control (right), optional bottom hairline.</summary>
        public static Border FormRow(string label, UIElement value, bool divider = true)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var lbl = Txt(label, Theme.TBody, Theme.FgSecondary);
            lbl.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(lbl, 0); g.Children.Add(lbl);
            if (value is FrameworkElement fe) fe.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(value, 1); g.Children.Add(value);
            var row = new Border { Child = g, Padding = new Thickness(0, Theme.S3, 0, Theme.S3) };
            if (divider) { row.BorderBrush = Theme.Border; row.BorderThickness = new Thickness(0, 0, 0, 1); }
            return row;
        }

        /// <summary>Selectable chip (emotion tags, options).</summary>
        public static Border Chip(string text, Brush color, bool selected)
        {
            color = color ?? Theme.Accent;
            Brush bg = Brushes.Transparent;
            if (selected) { var b = new SolidColorBrush(Theme.ColorOf(color)) { Opacity = 0.18 }; b.Freeze(); bg = b; }
            var tb = Txt(text, Theme.TBody, selected ? color : Theme.FgSecondary, selected ? FontWeights.SemiBold : FontWeights.Normal);
            tb.TextWrapping = TextWrapping.NoWrap;
            var chip = new Border
            {
                Background = bg,
                BorderBrush = selected ? color : Theme.BorderStrong,
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(99),
                Padding = new Thickness(Theme.S3, Theme.S2 - 2, Theme.S3, Theme.S2 - 2),
                Margin = new Thickness(0, 0, Theme.S2, 0),
                Child = tb,
                Cursor = System.Windows.Input.Cursors.Hand,
            };
            WireLift(chip, 1.5);
            return chip;
        }

        /// <summary>Read-only value text used on the right of a FormRow.</summary>
        public static TextBlock Value(string text) => Txt(text, Theme.TBody, Theme.FgPrimary, FontWeights.SemiBold);
    }
}
