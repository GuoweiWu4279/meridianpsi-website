// GuardPageView.cs
//
// PURE-WPF static view for the dashboard's Guard page. Extracted from
// MeridianDashboard.CreateGuardPage so the page can be rendered OFFLINE
// (in the UI harness, with no NinjaTrader) AND drive the LIVE page.
//
// Build(ge) produces the SAME visual tree CreateGuardPage produced, but is
// read-only over `ge` — it wires NO live click handlers. The live hub calls
// Build(), then re-attaches interactivity onto the anchors exposed via the
// returned Result (master toggle, rules panel, status-zone host, add/override
// buttons). The offline harness just renders Build(ge).Root straight to PNG.
//
// Palette: the hub's private brush fields were aliases of the central Theme
// tokens (FgPrimary→Theme.FgPrimary, FgSecondary→Theme.FgSecondary,
// FgHint→Theme.FgHint, FgAccent→Theme.Accent, BgCard→Theme.CardGradient,
// BgElevated→Theme.BgElevated). Those substitutions are applied here verbatim.
//
// Helpers (MakeToggleBtn / UpdateToggleBtn / MakeActionBtn / MakePillToggle /
// MakeIconBtn2 / BuildConditionSummary / FormatAction / GuardInfoCard /
// BuildGuardLadder / rule-card builder) are DUPLICATED here as private statics
// — the hub keeps its own copies intact (some are shared by other pages).

using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal static class GuardPageView
    {
        // ── Palette aliases (mirror MeridianDashboard's private fields) ─────────
        private static readonly Brush FgPrimary   = Theme.FgPrimary;
        private static readonly Brush FgSecondary = Theme.FgSecondary;
        private static readonly Brush FgHint      = Theme.FgHint;
        private static readonly Brush FgAccent    = Theme.Accent;
        private static readonly Brush BgCard      = Theme.CardGradient;

        /// <summary>
        /// Interactive anchors the live hub re-wires after Build(). The offline
        /// harness ignores these and renders <see cref="Root"/> directly.
        /// </summary>
        internal sealed class Result
        {
            public FrameworkElement Root;            // the ScrollViewer to host
            public Border           MasterToggle;    // header ON/OFF pill
            public StackPanel       RulesPanel;      // hub clears + repopulates with live cards
            public Border           StatusZoneHost;  // hub swaps Child for the live status zone
            public Border           AddButton;       // "Add Commitment"
            public Border           OverrideButton;  // "Force reset Guard"
            public Action           RefreshProtection; // re-evaluates the Protection card (Off/Idle/Armed) from live engine
        }

        /// <summary>
        /// Builds the Guard page visual tree (read-only over <paramref name="ge"/>).
        /// PURE WPF — no live click handlers are attached.
        /// </summary>
        public static FrameworkElement Build(GuardEngine ge)
        {
            return BuildWithAnchors(ge).Root;
        }

        /// <summary>
        /// Same as <see cref="Build"/> but also returns the interactive anchors so
        /// the live hub can attach behavior. Hover-only visual feedback IS wired
        /// here (it is presentation, not data interaction); data handlers are not.
        /// </summary>
        internal static Result BuildWithAnchors(GuardEngine ge)
        {
            var result = new Result();

            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            };
            var root = new StackPanel { Margin = new Thickness(24, 24, 18, 48) };
            // Workbench 2-column: rules (left) + protection/reference rail (right).
            var guardGrid = new Grid();
            guardGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1.5, GridUnitType.Star) });
            guardGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            Grid.SetColumn(root, 0); guardGrid.Children.Add(root);

            // Master switch lives in the rail's "Protection" card (a labelled status
            // panel) instead of a tiny header pill — clearer affordance, and it anchors
            // the right rail so it balances the taller rules column.
            bool masterOn = ge?.MasterEnabled ?? true;
            var masterToggle = MakeToggleBtn(masterOn, "Guard ON", "Guard OFF");
            masterToggle.Tag = (bool?)masterOn;
            result.MasterToggle = masterToggle;
            // NOTE: live click handler (→ ge.MasterEnabled) is attached by the hub.

            var guardRail = BuildProtectionRail(ge, masterToggle, result);
            guardRail.Margin = new Thickness(18, 24, 24, 48);
            Grid.SetColumn(guardRail, 1); guardGrid.Children.Add(guardRail);
            scroll.Content = guardGrid;

            // ── Header: title + subtitle (master switch now lives in the rail) ─
            var titleStack = new StackPanel();
            titleStack.Children.Add(new TextBlock
            {
                Text       = "Guard",
                FontSize   = 18,
                FontWeight = FontWeights.Bold,
                FontFamily = Theme.Font,
                Foreground = FgPrimary,
            });
            titleStack.Children.Add(new TextBlock
            {
                Text         = "Rules you set when calm, enforced when you're not.",
                FontFamily   = Theme.Font,
                FontSize     = 11,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 3, 0, 0),
            });
            root.Children.Add(titleStack);

            // Divider
            root.Children.Add(new Border
            {
                Height     = 1,
                Background = new SolidColorBrush(Color.FromRgb(50, 50, 54)),
                Margin     = new Thickness(0, 16, 0, 16),
            });

            // ── Active Status Zone host ───────────────────────────────────────
            // Static snapshot of the pause/lock banner (collapsed when no pause is
            // active — matching the live initial state). The live hub swaps this
            // host's Child for its ticking BuildGuardStatusZone element.
            var statusZoneHost = new Border { Margin = new Thickness(0, 0, 0, 0) };
            statusZoneHost.Child = BuildStaticStatusZone(ge);
            root.Children.Add(statusZoneHost);
            result.StatusZoneHost = statusZoneHost;

            // ── My Rules label ────────────────────────────────────────────────
            root.Children.Add(new TextBlock
            {
                Text       = "My Rules",
                FontFamily = Theme.Font,
                FontSize   = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgPrimary,
                Margin     = new Thickness(0, 0, 0, 10),
            });

            // ── Rules list (rendered read-only here; hub repopulates live) ─────
            var rulesPanel = new StackPanel();
            root.Children.Add(rulesPanel);
            result.RulesPanel = rulesPanel;
            PopulateRules(rulesPanel, ge);

            // ── Add Rule button ───────────────────────────────────────────────
            var addBtn = new Border
            {
                Background      = new SolidColorBrush(Color.FromArgb(18, 16, 185, 129)),
                CornerRadius    = new CornerRadius(10),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(60, 16, 185, 129)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(0, 14, 0, 14),
                Margin          = new Thickness(0, 6, 0, 0),
                Cursor          = Cursors.Hand,
            };
            var addBtnRow = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Center };
            addBtnRow.Children.Add(new Border
            {
                Width        = 26, Height = 26, CornerRadius = new CornerRadius(13),
                Background   = new SolidColorBrush(Color.FromArgb(50, 16, 185, 129)),
                Margin       = new Thickness(0, 0, 10, 0),
                VerticalAlignment = VerticalAlignment.Center,
                Child = new TextBlock
                {
                    Text = "+", FontSize = 16, FontWeight = FontWeights.Bold,
                    Foreground = FgAccent,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                },
            });
            addBtnRow.Children.Add(new TextBlock
            {
                Text = "Add Commitment",
                FontFamily = Theme.Font, FontSize = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgAccent, VerticalAlignment = VerticalAlignment.Center,
            });
            addBtn.Child = addBtnRow;
            addBtn.MouseEnter += (_, __) => addBtn.Background = new SolidColorBrush(Color.FromArgb(35, 16, 185, 129));
            addBtn.MouseLeave += (_, __) => addBtn.Background = new SolidColorBrush(Color.FromArgb(18, 16, 185, 129));
            // NOTE: live click (→ GuardRuleEditorWindow) is attached by the hub.
            root.Children.Add(addBtn);
            result.AddButton = addBtn;

            // ── Strict Lock — elevated into the MAIN column. It's a major commitment
            //    (locks every Guard bypass for a window), so it belongs with the rules
            //    it enforces — not tucked in a sidebar reference rail.
            var strictCard = BuildStrictLockCard(ge, result);
            strictCard.Margin = new Thickness(0, 20, 0, 0);
            root.Children.Add(strictCard);

            // ── Emergency override — rare + destructive ⇒ small + tucked, not a giant red block.
            // (Weight ∝ frequency × value; the confirm dialog still guards against accidents.)
            // Hidden entirely while a Strict Lock is active — the lock refuses Force-reset anyway,
            // so showing the button would contradict the card's "Bypass disabled".
            if (!(ge?.IsStrictLockActive ?? false))
            {
            root.Children.Add(new Border
            {
                Height     = 1,
                Background = Theme.Border,
                Margin     = new Thickness(0, 24, 0, 12),
            });

            var overrideBtn = new Border
            {
                Background          = Theme.BgElevated,
                CornerRadius        = new CornerRadius(Theme.R1),
                BorderBrush         = Theme.Border,
                BorderThickness     = new Thickness(1),
                Padding             = new Thickness(14, 8, 14, 8),
                HorizontalAlignment = HorizontalAlignment.Left,
                Cursor              = Cursors.Hand,
            };
            overrideBtn.Child = new TextBlock
            {
                Text       = "Force reset Guard",
                FontFamily = Theme.Font, FontSize = 12,
                FontWeight = FontWeights.SemiBold,
                Foreground = Theme.Bad,
                VerticalAlignment = VerticalAlignment.Center,
            };
            overrideBtn.MouseEnter += (_, __) => overrideBtn.Background = Theme.BgCard;
            overrideBtn.MouseLeave += (_, __) => overrideBtn.Background = Theme.BgElevated;
            // NOTE: live click (→ ShowEmergencyOverrideDialog) is attached by the hub.
            root.Children.Add(overrideBtn);
            result.OverrideButton = overrideBtn;

            root.Children.Add(new TextBlock
            {
                Text         = "Only if Guard malfunctions with open positions — clears active Guard states, keeps your rules. Logged.",
                FontFamily   = Theme.Font,
                FontSize     = 10,
                Foreground   = Theme.FgHint,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 6, 0, 0),
            });
            }

            result.Root = scroll;
            return result;
        }

        // ── Rules list rendering (read-only) ──────────────────────────────────
        // Mirrors CreateGuardPage's refreshList body, minus the live card handlers.
        // The hub clears RulesPanel and rebuilds it with its own live BuildRuleCard,
        // so this exact rendering is what shows offline.
        internal static void PopulateRules(StackPanel rulesPanel, GuardEngine ge)
        {
            rulesPanel.Children.Clear();
            var rules = ge?.Rules ?? new List<GuardRule>().AsReadOnly();

            // Active-rules status — clarifies that the "Guard ON" master toggle
            // only protects you when at least one rule is actually ENABLED.
            if (rules.Count > 0)
            {
                int enabledCount = 0;
                foreach (var rr in rules) if (rr.Enabled) enabledCount++;
                bool masterOnNow = ge?.MasterEnabled ?? true;

                string statusTxt;
                Brush  statusCol;
                if (!masterOnNow)
                {
                    statusTxt = "Guard is off — your rules are paused.";
                    statusCol = new SolidColorBrush(Color.FromRgb(230, 165, 90));
                }
                else if (enabledCount == 0)
                {
                    statusTxt = "Guard is on, but no rules are active — enable one below to be protected.";
                    statusCol = new SolidColorBrush(Color.FromRgb(230, 165, 90));
                }
                else
                {
                    statusTxt = enabledCount + (enabledCount == 1 ? " rule active" : " rules active");
                    statusCol = new SolidColorBrush(Color.FromRgb(91, 201, 140));
                }
                rulesPanel.Children.Add(new TextBlock
                {
                    Text         = statusTxt,
                    FontFamily   = Theme.Font,
                    FontSize     = 11,
                    Foreground   = statusCol,
                    TextWrapping = TextWrapping.Wrap,
                    Margin       = new Thickness(0, 0, 0, 10),
                });
            }

            if (rules.Count == 0)
            {
                // First-run guidance card
                var guideCard = new Border
                {
                    Background      = new SolidColorBrush(Color.FromArgb(26, 16, 185, 129)),
                    CornerRadius    = new CornerRadius(8),
                    Padding         = new Thickness(14, 12, 14, 14),
                    BorderBrush     = new SolidColorBrush(Color.FromArgb(60, 16, 185, 129)),
                    BorderThickness = new Thickness(1),
                    Margin          = new Thickness(0, 0, 0, 16),
                };
                var guideStack = new StackPanel();
                guideStack.Children.Add(new TextBlock
                {
                    Text         = "No rules yet",
                    FontSize     = 12,
                    FontFamily   = Theme.Font,
                    FontWeight   = FontWeights.SemiBold,
                    Foreground   = FgPrimary,
                    Margin       = new Thickness(0, 0, 0, 6),
                });
                guideStack.Children.Add(new TextBlock
                {
                    Text         = "Add a rule to protect yourself when emotion takes over. Example:",
                    FontSize     = 11,
                    FontFamily   = Theme.Font,
                    Foreground   = FgSecondary,
                    TextWrapping = TextWrapping.Wrap,
                    Margin       = new Thickness(0, 0, 0, 6),
                });
                guideStack.Children.Add(new TextBlock
                {
                    Text         = "  When PSI < 70  →  Notify me in the HUD",
                    FontSize     = 11,
                    FontFamily   = new FontFamily("Consolas"),
                    Foreground   = FgAccent,
                    Margin       = new Thickness(0, 0, 0, 0),
                });
                guideCard.Child = guideStack;
                rulesPanel.Children.Add(guideCard);
            }
            else
            {
                foreach (var r in rules)
                {
                    var ruleCopy = r;
                    rulesPanel.Children.Add(BuildRuleCardStatic(ruleCopy));
                }
            }
        }

        // ── Right rail: protection status + enforcement-ladder reference ──────
        private static FrameworkElement BuildProtectionRail(GuardEngine ge, Border masterToggle, Result result)
        {
            var rail = new StackPanel();
            rail.Children.Add(BuildProtectionCard(ge, masterToggle, result));

            // Slim escalation reference (the rule editor explains each action in full).
            var ladder = BuildLadderLegend();
            ladder.Margin = new Thickness(0, 14, 0, 0);
            rail.Children.Add(ladder);
            return rail;
        }

        // ── Strict Lock card — a STANDING commitment (toggle), not a manual countdown ─────────
        // Turned on when calm; it sits dormant until Guard pauses/disconnects you, then auto-engages
        // an un-bypassable lockout for the chosen duration. While engaged you can't force-reset, end
        // the pause early, turn Guard off, or turn this off — only the clock releases you. The card
        // wires itself to the engine (no hub handlers) and re-renders its body in place on change.
        private static FrameworkElement BuildStrictLockCard(GuardEngine ge, Result result)
        {
            bool engaged = ge?.IsStrictLockActive ?? false;
            var card = new Border
            {
                Background      = Theme.BgCard,
                BorderBrush     = engaged ? Theme.Tint(Theme.Good, 80) : Theme.Border,
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(Theme.R3),
                Padding         = new Thickness(16),
            };
            var sp = new StackPanel();
            card.Child = sp;

            Action render = null;
            render = () =>
            {
                sp.Children.Clear();
                bool engagedNow = ge?.IsStrictLockActive ?? false;
                bool modeOn     = ge?.StrictModeEnabled ?? false;

                // Header: label + (when not engaged) an on/off pill toggle on the right.
                var header = new Grid { Margin = new Thickness(0, 0, 0, 12) };
                header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
                header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
                var lbl = new TextBlock { Text = "Strict lock", FontFamily = Theme.Font, FontSize = 10, FontWeight = FontWeights.Bold, Foreground = FgHint, VerticalAlignment = VerticalAlignment.Center };
                Grid.SetColumn(lbl, 0);
                header.Children.Add(lbl);
                if (!engagedNow)
                {
                    var toggle = MakePillToggle(modeOn);
                    toggle.HorizontalAlignment = HorizontalAlignment.Right;
                    toggle.MouseLeftButtonDown += (_, e) =>
                    {
                        e.Handled = true;
                        if (ge != null) ge.StrictModeEnabled = !ge.StrictModeEnabled;
                        CallbackRecorder.UiEvent("guard", "strict_mode", (ge != null && ge.StrictModeEnabled) ? "on" : "off");
                        render();
                    };
                    Grid.SetColumn(toggle, 1);
                    header.Children.Add(toggle);
                }
                sp.Children.Add(header);

                if (engagedNow)
                {
                    var until   = ge.StrictLockUntil;
                    int blocked = ge.StrictBypassBlockedCount;
                    var stateRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 5) };
                    stateRow.Children.Add(new Border { Width = 9, Height = 9, CornerRadius = new CornerRadius(99), Background = Theme.Good, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 9, 0) });
                    stateRow.Children.Add(new TextBlock { Text = "Locked", FontFamily = Theme.Font, FontSize = 18, FontWeight = FontWeights.SemiBold, Foreground = Theme.Good, VerticalAlignment = VerticalAlignment.Center });
                    sp.Children.Add(stateRow);
                    sp.Children.Add(new TextBlock { Text = "until " + until.ToString("HH:mm"), FontFamily = Theme.Font, FontSize = 13, Foreground = FgSecondary, Margin = new Thickness(0, 0, 0, 6) });
                    string blk = "Bypass disabled" + (blocked > 0 ? "  ·  " + blocked + " attempt" + (blocked == 1 ? "" : "s") + " blocked" : "");
                    sp.Children.Add(new TextBlock { Text = blk, FontFamily = Theme.Font, FontSize = 11, Foreground = FgHint, Margin = new Thickness(0, 0, 0, 8) });
                    bool discLock = ge?.IsDisconnectActive ?? false;
                    sp.Children.Add(new TextBlock { Text = discLock
                        ? "Locked in by your commitment — it releases automatically. Your broker is disconnected until then; manage any open position from your platform's native stops."
                        : "Locked in by your commitment — it releases automatically. You can still close any open position at any time.",
                        FontFamily = Theme.Font, FontSize = 12, Foreground = FgSecondary, TextWrapping = TextWrapping.Wrap, LineHeight = 18 });
                }
                else if (modeOn)
                {
                    sp.Children.Add(new TextBlock { Text = "On. If Guard pauses or disconnects you, you're locked for the duration below — no early exit, no force reset, and you can't turn this off until it releases.", FontFamily = Theme.Font, FontSize = 12, Foreground = FgSecondary, TextWrapping = TextWrapping.Wrap, LineHeight = 18, Margin = new Thickness(0, 0, 0, 12) });
                    sp.Children.Add(BuildDurationPicker(ge, render));
                }
                else
                {
                    sp.Children.Add(new TextBlock { Text = "Off. Turn it on to make your pauses un-bypassable: once Guard pauses you, you can't end it early or force-reset until the clock releases you.", FontFamily = Theme.Font, FontSize = 12, Foreground = FgSecondary, TextWrapping = TextWrapping.Wrap, LineHeight = 18, Margin = new Thickness(0, 0, 0, 10) });
                    sp.Children.Add(new TextBlock { Text = "This is for traders who need 100% protection that can't be bypassed, not even by themselves.", FontFamily = Theme.Font, FontSize = 11, FontWeight = FontWeights.SemiBold, Foreground = Theme.Caution, TextWrapping = TextWrapping.Wrap, LineHeight = 16 });
                }
            };
            render();
            return card;
        }

        // Duration picker: presets + a custom-minutes input. Selecting one sets StrictModeLockMinutes
        // and re-renders so the selection highlights. 0 = rest of day (until 17:00).
        private static FrameworkElement BuildDurationPicker(GuardEngine ge, Action onChange)
        {
            int cur = ge?.StrictModeLockMinutes ?? 60;
            bool isPreset = cur == 15 || cur == 30 || cur == 60 || cur == 120 || cur == 240 || cur == 0;

            var wrap = new StackPanel();
            wrap.Children.Add(new TextBlock { Text = "LOCK FOR", FontFamily = Theme.Font, FontSize = 10, FontWeight = FontWeights.Bold, Foreground = FgHint, Margin = new Thickness(0, 0, 0, 8) });

            var row = new WrapPanel();
            row.Children.Add(MakeDurationChip("15m", cur == 15,  () => { if (ge != null) ge.StrictModeLockMinutes = 15;  onChange(); }));
            row.Children.Add(MakeDurationChip("30m", cur == 30,  () => { if (ge != null) ge.StrictModeLockMinutes = 30;  onChange(); }));
            row.Children.Add(MakeDurationChip("1h",  cur == 60,  () => { if (ge != null) ge.StrictModeLockMinutes = 60;  onChange(); }));
            row.Children.Add(MakeDurationChip("2h",  cur == 120, () => { if (ge != null) ge.StrictModeLockMinutes = 120; onChange(); }));
            row.Children.Add(MakeDurationChip("4h",  cur == 240, () => { if (ge != null) ge.StrictModeLockMinutes = 240; onChange(); }));
            row.Children.Add(MakeDurationChip("Rest of day", cur == 0, () => { if (ge != null) ge.StrictModeLockMinutes = 0; onChange(); }));
            wrap.Children.Add(row);

            var customRow = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 2, 0, 0) };
            customRow.Children.Add(new TextBlock { Text = "Custom", FontFamily = Theme.Font, FontSize = 11, Foreground = FgHint, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 8, 0) });
            var input = new TextBox
            {
                Width                    = 56,
                FontFamily               = Theme.Font,
                FontSize                 = 12,
                Background               = Theme.BgElevated,
                Foreground               = Theme.FgPrimary,
                BorderBrush              = Theme.Border,
                BorderThickness          = new Thickness(1),
                Padding                  = new Thickness(6, 4, 6, 4),
                VerticalContentAlignment = VerticalAlignment.Center,
                Text                     = (!isPreset && cur > 0) ? cur.ToString() : "",
            };
            customRow.Children.Add(input);
            customRow.Children.Add(new TextBlock { Text = "min", FontFamily = Theme.Font, FontSize = 11, Foreground = FgHint, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(6, 0, 8, 0) });
            var setChip = MakeDurationChip("Set", !isPreset && cur > 0, () =>
            {
                if (int.TryParse(input.Text.Trim(), out int m) && m > 0) { if (ge != null) ge.StrictModeLockMinutes = m; onChange(); }
            });
            setChip.Margin = new Thickness(0);
            customRow.Children.Add(setChip);
            wrap.Children.Add(customRow);

            return wrap;
        }

        private static Border MakeDurationChip(string label, bool selected, Action onClick)
        {
            var tb = new TextBlock { Text = label, FontFamily = Theme.Font, FontSize = 12, FontWeight = FontWeights.SemiBold, Foreground = selected ? Theme.AccentInk : FgAccent, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            var b = new Border
            {
                Background      = selected ? Theme.AccentSolid : Theme.Tint(Theme.Accent, 18),
                BorderBrush     = selected ? Theme.AccentSolid : Theme.Tint(Theme.Accent, 64),
                BorderThickness = new Thickness(1),
                CornerRadius    = new CornerRadius(Theme.R1),
                Padding         = new Thickness(12, 7, 12, 7),
                Margin          = new Thickness(0, 0, 8, 8),
                Cursor          = Cursors.Hand,
                Child           = tb,
            };
            if (!selected)
            {
                b.MouseEnter += (_, __) => b.Background = Theme.Tint(Theme.Accent, 32);
                b.MouseLeave += (_, __) => b.Background = Theme.Tint(Theme.Accent, 18);
            }
            b.MouseLeftButtonDown += (_, e) => { e.Handled = true; onClick(); };
            return b;
        }

        // ── Protection status card — the master switch as a labelled state panel.
        // Reads the live engine: Armed (≥1 rule enforcing) / Idle (on, none active) /
        // Off (master disabled). Anchors the rail; the hub re-wires the toggle. ───
        private static FrameworkElement BuildProtectionCard(GuardEngine ge, Border masterToggle, Result result)
        {
            var card = new Border { Background = Theme.BgCard, BorderBrush = Theme.Border, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(Theme.R3), Padding = new Thickness(16) };
            var sp = new StackPanel();
            sp.Children.Add(new TextBlock { Text = "Protection", FontFamily = Theme.Font, FontSize = 10, FontWeight = FontWeights.Bold, Foreground = FgHint, Margin = new Thickness(0, 0, 0, 12) });

            var dot     = new Border { Width = 9, Height = 9, CornerRadius = new CornerRadius(99), VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 9, 0) };
            var stateTb = new TextBlock { FontFamily = Theme.Font, FontSize = 18, FontWeight = FontWeights.SemiBold, VerticalAlignment = VerticalAlignment.Center };
            var stateRow = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 6) };
            stateRow.Children.Add(dot);
            stateRow.Children.Add(stateTb);
            sp.Children.Add(stateRow);

            var subTb = new TextBlock { FontFamily = Theme.Font, FontSize = 12, Foreground = FgSecondary, TextWrapping = TextWrapping.Wrap, LineHeight = 18, Margin = new Thickness(0, 0, 0, 14) };
            sp.Children.Add(subTb);

            // Live refresh — recompute Off/Idle/Armed from the engine. Wired (by the hub)
            // to the master toggle AND rule enable/disable so it never shows a stale state.
            Action refresh = () =>
            {
                bool on = ge?.MasterEnabled ?? true;
                int enabled = 0;
                var rules = ge?.Rules;
                if (rules != null) foreach (var r in rules) if (r.Enabled) enabled++;
                string state; Brush col; string sub;
                if (!on)              { state = "Off";   col = Theme.FgHint;  sub = "Rules paused — turn Guard on to enforce them."; }
                else if (enabled == 0){ state = "Idle";  col = Theme.Warning; sub = "No rules active — enable one to be protected."; }
                else                  { state = "Armed"; col = Theme.Good;    sub = enabled + (enabled == 1 ? " rule enforcing" : " rules enforcing") + " · live."; }
                dot.Background = col; stateTb.Text = state; stateTb.Foreground = col; subTb.Text = sub;
            };
            refresh();
            if (result != null) result.RefreshProtection = refresh;

            masterToggle.HorizontalAlignment = HorizontalAlignment.Left;
            sp.Children.Add(masterToggle);
            card.Child = sp;
            return card;
        }

        // Slim escalation legend — one line per tier. Replaces the old heavy
        // "Enforcement ladder" card (which carried more chrome than information).
        private static FrameworkElement BuildLadderLegend()
        {
            var card = new Border { Background = Theme.BgCard, BorderBrush = Theme.Border, BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(Theme.R3), Padding = new Thickness(16, 13, 16, 11) };
            var sp = new StackPanel();
            sp.Children.Add(new TextBlock { Text = "How Guard escalates", FontFamily = Theme.Font, FontSize = 10, FontWeight = FontWeights.Bold, Foreground = FgHint, Margin = new Thickness(0, 0, 0, 11) });
            var tiers = new[]
            {
                new[] { "Notify",      "a quiet nudge",      "h" },
                new[] { "Acknowledge", "blocking prompt",    "w" },
                new[] { "Pause",       "new entries frozen", "w" },
                new[] { "Disconnect",  "flat + broker cut",  "b" },
            };
            foreach (var t in tiers)
            {
                Brush dot = t[2] == "b" ? Theme.Bad : t[2] == "w" ? Theme.Warning : Theme.FgHint;
                var row = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 0, 0, 8) };
                row.Children.Add(new Border { Width = 6, Height = 6, CornerRadius = new CornerRadius(99), Background = dot, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, 10, 0) });
                row.Children.Add(new TextBlock { Text = t[0], FontFamily = Theme.Font, FontSize = 12, FontWeight = FontWeights.SemiBold, Foreground = FgPrimary, VerticalAlignment = VerticalAlignment.Center, Width = 88 });
                row.Children.Add(new TextBlock { Text = t[1], FontFamily = Theme.Font, FontSize = 11, Foreground = FgHint, VerticalAlignment = VerticalAlignment.Center });
                sp.Children.Add(row);
            }
            card.Child = sp;
            return card;
        }

        // ── Static rule card (visuals identical to the hub's BuildRuleCard, but
        //    no toggle/edit/delete handlers — read-only for offline render) ─────
        private static Border BuildRuleCardStatic(GuardRule rule)
        {
            Color accentColor;
            string iconGlyph;
            switch (rule.Action)
            {
                case GuardActionType.TradingPause:
                case GuardActionType.Disconnect:
                    accentColor = Theme.ColorOf(Theme.Bad);
                    iconGlyph   = ""; // Pause glyph
                    break;
                case GuardActionType.Acknowledge:
                case GuardActionType.Countdown:
                    accentColor = Theme.ColorOf(Theme.Warning);
                    iconGlyph   = ""; // Comment/Chat glyph
                    break;
                case GuardActionType.RiskAlert:
                    accentColor = Theme.ColorOf(Theme.Warning);
                    iconGlyph   = ""; // Warning glyph
                    break;
                default: // Toast / Notify
                    accentColor = Theme.ColorOf(Theme.Stable);
                    iconGlyph   = ""; // Bell glyph
                    break;
            }

            var outerCard = new Border
            {
                Background      = BgCard,
                CornerRadius    = new CornerRadius(Theme.R3),
                Margin          = new Thickness(0, 0, 0, 8),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(rule.Enabled ? (byte)70 : (byte)25, accentColor.R, accentColor.G, accentColor.B)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(12, 12, 14, 12),
                Effect          = Ui.CardShadow,
            };
            var accentStrip = new Border
            {
                Width        = 3,
                Background   = new SolidColorBrush(Color.FromArgb(rule.Enabled ? (byte)220 : (byte)55, accentColor.R, accentColor.G, accentColor.B)),
                CornerRadius = new CornerRadius(2, 0, 0, 2),
                Margin       = new Thickness(-12, -12, 0, -12),
            };

            var mainGrid = new Grid();
            mainGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            mainGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            mainGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            mainGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            outerCard.Child = mainGrid;

            Grid.SetColumn(accentStrip, 0);
            mainGrid.Children.Add(accentStrip);

            // Icon badge
            byte bgAlpha   = rule.Enabled ? (byte)55  : (byte)20;
            byte bdAlpha   = rule.Enabled ? (byte)100 : (byte)30;
            byte iconAlpha = rule.Enabled ? (byte)230 : (byte)80;
            var iconBg = new Border
            {
                Width           = 38,
                Height          = 38,
                CornerRadius    = new CornerRadius(19),
                Background      = new SolidColorBrush(Color.FromArgb(bgAlpha, accentColor.R, accentColor.G, accentColor.B)),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(bdAlpha, accentColor.R, accentColor.G, accentColor.B)),
                BorderThickness = new Thickness(1),
                Margin          = new Thickness(8, 0, 12, 0),
                VerticalAlignment = VerticalAlignment.Center,
                Child = new TextBlock
                {
                    Text       = iconGlyph,
                    FontFamily = new FontFamily("Segoe MDL2 Assets"),
                    FontSize   = 16,
                    Foreground = new SolidColorBrush(Color.FromArgb(iconAlpha, accentColor.R, accentColor.G, accentColor.B)),
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment   = VerticalAlignment.Center,
                },
            };
            Grid.SetColumn(iconBg, 1);
            mainGrid.Children.Add(iconBg);

            // Text
            var textStack = new StackPanel { VerticalAlignment = VerticalAlignment.Center };
            Grid.SetColumn(textStack, 2);

            var nameTb = new TextBlock
            {
                Text       = rule.Name,
                FontFamily = Theme.Font,
                FontSize   = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = rule.Enabled ? FgPrimary : FgHint,
            };
            textStack.Children.Add(nameTb);

            var condSummary  = BuildConditionSummary(rule);
            string actionSummary = FormatAction(rule);
            textStack.Children.Add(new TextBlock
            {
                Text         = condSummary + "  →  " + actionSummary,
                FontFamily   = Theme.Font,
                FontSize     = 11,
                Foreground   = rule.Enabled ? FgSecondary : FgHint,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 3, 8, 0),
            });
            mainGrid.Children.Add(textStack);

            // Right controls: pill toggle + edit + delete (rendered, not wired)
            var ctrlStack = new StackPanel
            {
                Orientation       = Orientation.Horizontal,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(8, 0, 0, 0),
            };
            Grid.SetColumn(ctrlStack, 3);

            var pillToggle = MakePillToggle(rule.Enabled);
            pillToggle.Margin = new Thickness(0, 0, 10, 0);
            ctrlStack.Children.Add(pillToggle);

            ctrlStack.Children.Add(MakeIconBtn2("✎", "Edit rule"));
            ctrlStack.Children.Add(MakeIconBtn2("🗑", "Delete rule"));

            mainGrid.Children.Add(ctrlStack);
            return outerCard;
        }

        private static string BuildConditionSummary(GuardRule rule)
        {
            if (rule.Conditions.Count == 0) return "(no conditions)";
            string logic = rule.Logic == GuardConditionLogic.All ? " AND " : " OR ";
            var parts = new List<string>();
            foreach (var c in rule.Conditions)
            {
                switch (c.Type)
                {
                    case GuardConditionType.PsiBelow:
                        parts.Add(string.Format("PSI < {0}", c.Threshold)); break;
                    case GuardConditionType.ConsecutiveLossesAtLeast:
                        string lossNote = rule.MinLossUsdForStreak > 0
                            ? string.Format(" (>${0:F0})", rule.MinLossUsdForStreak) : "";
                        parts.Add(string.Format("{0} losses≥{1}{2}",
                            lossNote.Length > 0 ? "" : "Consecutive ", c.Threshold, lossNote));
                        break;
                    case GuardConditionType.SessionPnlBelow:
                        parts.Add(string.Format("Session P&L below −${0}", c.Threshold)); break;
                    case GuardConditionType.SessionMinutesOver:
                        parts.Add(string.Format("Session time > {0} min", c.Threshold)); break;
                    case GuardConditionType.UnrealizedPnlBelow:
                        parts.Add(string.Format("Floating loss > ${0}", c.Threshold)); break;
                    case GuardConditionType.SingleTradeLossExceeds:
                        parts.Add(string.Format("Single trade loss > ${0}", c.Threshold)); break;
                    default:
                        parts.Add("?"); break;
                }
            }
            return string.Join(logic, parts);
        }

        private static string FormatAction(GuardRule rule)
        {
            switch (rule.Action)
            {
                case GuardActionType.Toast:
                    return "Notify";
                case GuardActionType.Acknowledge:
                case GuardActionType.Countdown:  // legacy, same behaviour
                {
                    var parts = new List<string>();
                    if (!string.IsNullOrWhiteSpace(rule.OverridePhrase))
                        parts.Add("phrase required");
                    if (rule.CountdownSeconds > 0)
                        parts.Add(string.Format("wait {0}s", rule.CountdownSeconds));
                    return parts.Count > 0
                        ? string.Format("Acknowledge ({0})", string.Join(", ", parts))
                        : "Acknowledge";
                }
                case GuardActionType.RiskAlert:
                    return "Alert (persistent)";
                case GuardActionType.TradingPause:
                {
                    int durMins = rule.PauseDurationMinutes;
                    string dur = durMins == 0 ? "rest of day" : string.Format("{0} min", durMins);
                    string mode = rule.PauseMode == PauseModeType.CancelOrders
                        ? "cancel entries" : "disconnect";
                    int sec = rule.EffectiveConfirmationSeconds;
                    string conf = sec > 0 ? string.Format(" after {0}s", sec) : "";
                    return string.Format("Pause {0}{1}, {2}", dur, conf, mode);
                }
                case GuardActionType.Disconnect:
                {
                    int sec = rule.EffectiveConfirmationSeconds;
                    return sec > 0
                        ? string.Format("Disconnect {0} min (after {1}s)", rule.LockMinutes, sec)
                        : string.Format("Disconnect {0} min", rule.LockMinutes);
                }
                default:
                    return "?";
            }
        }

        // ── Header master ON/OFF toggle pill ──────────────────────────────────
        private static Border MakeToggleBtn(bool isOn, string onText, string offText)
        {
            var tb = new TextBlock
            {
                Text              = isOn ? onText : offText,
                FontFamily        = Theme.Font,
                FontSize          = 11,
                FontWeight        = FontWeights.SemiBold,
                Foreground        = isOn
                                        ? new SolidColorBrush(Color.FromRgb(50, 220, 80))
                                        : new SolidColorBrush(Color.FromRgb(150, 150, 155)),
                VerticalAlignment = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Background    = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                CornerRadius  = new CornerRadius(4),
                Padding       = new Thickness(8, 3, 8, 3),
                Cursor        = Cursors.Hand,
                Child         = tb,
            };
            btn.MouseEnter += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(50, 255, 255, 255));
            btn.MouseLeave += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255));
            return btn;
        }

        // ── iOS-style pill toggle (rule cards) ────────────────────────────────
        private static Border MakePillToggle(bool isOn)
        {
            var thumb = new Border
            {
                Width             = 18,
                Height            = 18,
                CornerRadius      = new CornerRadius(9),
                Background        = new SolidColorBrush(Colors.White),
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = isOn ? new Thickness(20, 0, 2, 0) : new Thickness(2, 0, 20, 0),
            };
            var track = new Border
            {
                Width             = 42,
                Height            = 24,
                CornerRadius      = new CornerRadius(12),
                Background        = isOn
                                        ? new SolidColorBrush(Color.FromRgb(91, 201, 140))
                                        : new SolidColorBrush(Color.FromRgb(60, 60, 65)),
                Cursor            = Cursors.Hand,
                Child             = thumb,
                Tag = thumb,
            };
            return track;
        }

        // ── Slim icon button for rule card (pencil / trash) ───────────────────
        private static Border MakeIconBtn2(string glyph, string tip)
        {
            var tb = new TextBlock
            {
                Text              = glyph,
                FontSize          = 14,
                Foreground        = FgSecondary,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center,
            };
            var btn = new Border
            {
                Width         = 30,
                Height        = 30,
                Background    = Brushes.Transparent,
                CornerRadius  = new CornerRadius(6),
                Cursor        = Cursors.Hand,
                Child         = tb,
                ToolTip       = tip,
                Margin        = new Thickness(3, 0, 0, 0),
            };
            btn.MouseEnter += (_, __) =>
            {
                btn.Background = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255));
                tb.Foreground  = FgPrimary;
            };
            btn.MouseLeave += (_, __) =>
            {
                btn.Background = Brushes.Transparent;
                tb.Foreground  = FgSecondary;
            };
            return btn;
        }

        // ── Pill action button (e.g. "End Early") ─────────────────────────────
        private static Border MakeActionBtn(string text, Brush fg)
        {
            var tb = new TextBlock
            {
                Text              = text,
                FontFamily        = Theme.Font,
                FontSize          = 13,
                Foreground        = fg,
                VerticalAlignment = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Background   = new SolidColorBrush(Color.FromArgb(25, 16, 185, 129)),
                CornerRadius = new CornerRadius(6),
                Padding      = new Thickness(16, 8, 16, 8),
                Cursor       = Cursors.Hand,
                Child        = tb,
            };
            btn.MouseEnter += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(50, 16, 185, 129));
            btn.MouseLeave += (_, __) =>
                btn.Background = new SolidColorBrush(Color.FromArgb(25, 16, 185, 129));
            Ui.WireLift(btn, 1.5);
            return btn;
        }

        // ── Static snapshot of the Active Status Zone ─────────────────────────
        // Mirrors BuildGuardStatusZone's visual tree at its INITIAL state (no live
        // DispatcherTimer / early-exit dialog). Collapsed unless a pause is active,
        // exactly matching the live page on first render. The hub swaps this for
        // its ticking version; offline this read-only snapshot is what renders.
        private static FrameworkElement BuildStaticStatusZone(GuardEngine ge)
        {
            var zone = new Border
            {
                Background      = new SolidColorBrush(Color.FromArgb(40, 242, 129, 138)),
                CornerRadius    = new CornerRadius(8),
                BorderBrush     = new SolidColorBrush(Color.FromRgb(242, 129, 138)),
                BorderThickness = new Thickness(1),
                Padding         = new Thickness(14, 12, 14, 12),
                Margin          = new Thickness(0, 0, 0, 16),
                Visibility      = Visibility.Collapsed,
            };
            var zoneStack = new StackPanel();
            zone.Child = zoneStack;

            var titleRow = new Grid();
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            titleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var statusLabel = new TextBlock
            {
                FontFamily  = Theme.Font,
                FontSize    = 13,
                FontWeight  = FontWeights.SemiBold,
                Foreground  = new SolidColorBrush(Color.FromRgb(242, 129, 138)),
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(statusLabel, 0);

            var progressBar = new System.Windows.Controls.ProgressBar
            {
                Height     = 8,
                Margin     = new Thickness(12, 0, 12, 0),
                Background = new SolidColorBrush(Color.FromArgb(60, 255, 255, 255)),
                Foreground = new SolidColorBrush(Color.FromRgb(242, 129, 138)),
                BorderThickness = new Thickness(0),
                Minimum    = 0,
                Maximum    = 100,
                Value      = 50,
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(progressBar, 1);

            var timeLabel = new TextBlock
            {
                FontFamily  = new FontFamily("Consolas"),
                FontSize    = 13,
                FontWeight  = FontWeights.Bold,
                Foreground  = new SolidColorBrush(Color.FromRgb(242, 129, 138)),
                VerticalAlignment = VerticalAlignment.Center,
            };
            Grid.SetColumn(timeLabel, 2);

            titleRow.Children.Add(statusLabel);
            titleRow.Children.Add(progressBar);
            titleRow.Children.Add(timeLabel);
            zoneStack.Children.Add(titleRow);

            var ruleNameLabel = new TextBlock
            {
                FontFamily  = Theme.Font,
                FontSize    = 11,
                Foreground  = new SolidColorBrush(Color.FromRgb(200, 140, 130)),
                Margin      = new Thickness(0, 4, 0, 0),
            };
            zoneStack.Children.Add(ruleNameLabel);

            var earlyExitRow = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin      = new Thickness(0, 8, 0, 0),
                Visibility  = Visibility.Collapsed,
            };
            earlyExitRow.Children.Add(MakeActionBtn("End Early ▸",
                new SolidColorBrush(Color.FromRgb(242, 129, 138))));
            zoneStack.Children.Add(earlyExitRow);

            // Populate the static snapshot from current engine state (no timer).
            if (ge != null && ge.IsPauseActive)
            {
                zone.Visibility = Visibility.Visible;
                var rule = ge.ActivePauseRule;
                TimeSpan rem = ge.PauseRemaining;
                bool isDayLock = ge.IsDayLockActive;

                string timeStr = rem.TotalHours >= 1
                    ? string.Format("{0:h\\:mm\\:ss}", rem)
                    : string.Format("{0:mm\\:ss}", rem);

                bool isDisconnect = rule == null
                    || rule.Action == GuardActionType.Disconnect
                    || (rule.Action == GuardActionType.TradingPause && rule.PauseMode == PauseModeType.Disconnect);

                statusLabel.Text = isDayLock ? "Day lock"
                    : isDisconnect ? "Trading locked"
                    : "Trading paused";
                timeLabel.Text = timeStr;
                ruleNameLabel.Text = string.Format("Rule: \"{0}\"", rule?.Name ?? "");

                int durMins = rule != null ? rule.EffectivePauseDurationMinutes : 15;
                double totalSec = durMins == 0 ? 3600 : durMins * 60.0;
                progressBar.Value = totalSec > 0 ? Math.Max(0, Math.Min(100, rem.TotalSeconds / totalSec * 100)) : 0;

                earlyExitRow.Visibility = (rule != null && rule.AllowEarlyExit)
                    ? Visibility.Visible : Visibility.Collapsed;
            }

            return zone;
        }
    }
}
