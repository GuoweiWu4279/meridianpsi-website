using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace NinjaTrader.NinjaScript.AddOns
{
    /// <summary>
    /// Guard — reframed as "bind your future self." ONE job: rules you set when
    /// calm, enforced when you're not. PURE WPF. Representative content.
    /// </summary>
    internal static class GuardView
    {
        public static FrameworkElement Build()
        {
            var root = new StackPanel();

            // header + master toggle
            var header = new Grid();
            header.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            header.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });
            var hb = new StackPanel();
            hb.Children.Add(Ui.Txt("GUARD", Theme.TCaption, Theme.FgHint, FontWeights.SemiBold));
            var h = Ui.Txt("Bind your future self", Theme.THeadline, Theme.FgPrimary, FontWeights.Bold);
            h.Margin = new Thickness(0, Theme.S2, 0, 0);
            hb.Children.Add(h);
            Grid.SetColumn(hb, 0); header.Children.Add(hb);
            var tog = new StackPanel { Orientation = Orientation.Horizontal, VerticalAlignment = VerticalAlignment.Center };
            tog.Children.Add(Ui.Txt("ON", Theme.TCaption, Theme.Good, FontWeights.Bold));
            var t = Ui.Toggle(true); t.Margin = new Thickness(Theme.S2, 0, 0, 0);
            tog.Children.Add(t);
            Grid.SetColumn(tog, 1); header.Children.Add(tog);
            root.Children.Add(header);

            var sub = Ui.Txt("Rules you set when calm, enforced when you're not. The mast you tie yourself to before the sirens sing.", Theme.TSubhead, Theme.FgSecondary);
            sub.Margin = new Thickness(0, Theme.S2, 0, Theme.S5);
            root.Children.Add(sub);

            // status
            var status = new StackPanel { Orientation = Orientation.Horizontal };
            status.Children.Add(new Border { Width = 8, Height = 8, CornerRadius = new CornerRadius(99), Background = Theme.Good, VerticalAlignment = VerticalAlignment.Center, Margin = new Thickness(0, 0, Theme.S2, 0) });
            status.Children.Add(Ui.Txt("2 rules active — you're protected.", Theme.TBody, Theme.FgPrimary, FontWeights.SemiBold));
            root.Children.Add(Ui.Card(status, Theme.S3));

            // rules
            var rh = Ui.SectionHeader("My rules");
            rh.Margin = new Thickness(0, Theme.S5, 0, Theme.S2);
            root.Children.Add(rh);
            var rules = new StackPanel();
            rules.Children.Add(RuleRow("Stop after 2 losses", "2 losses in a row", "Trading Pause · 15 min", true, true));
            rules.Children.Add(RuleRow("Daily loss limit", "Session P&L < −$200", "Disconnect + flatten", true, true));
            rules.Children.Add(RuleRow("Critical PSI", "PSI < 55", "Acknowledge (type to continue)", false, false));
            root.Children.Add(Ui.Card(rules, Theme.S3));

            var add = Ui.Button("+  Add rule", BtnVariant.Secondary);
            add.Margin = new Thickness(0, Theme.S4, 0, 0);
            root.Children.Add(add);

            var note = Ui.Txt("Guard is the “bind thyself” tier — for when seeing the truth isn't enough and you want the limit enforced before you can act on the impulse.", Theme.TCaption, Theme.FgHint);
            note.Margin = new Thickness(0, Theme.S4, 0, 0);
            root.Children.Add(note);

            return Ui.Page(root);
        }

        private static UIElement RuleRow(string name, string trigger, string action, bool on, bool divider)
        {
            var g = new Grid();
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            g.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var body = new StackPanel();
            body.Children.Add(Ui.Txt(name, Theme.TBody, on ? Theme.FgPrimary : Theme.FgHint, FontWeights.SemiBold));
            var rule = new StackPanel { Orientation = Orientation.Horizontal, Margin = new Thickness(0, 2, 0, 0) };
            rule.Children.Add(Ui.Txt("when ", Theme.TCaption, Theme.FgHint));
            rule.Children.Add(Ui.Txt(trigger, Theme.TCaption, Theme.FgSecondary, FontWeights.SemiBold));
            rule.Children.Add(Ui.Txt("  →  ", Theme.TCaption, Theme.FgHint));
            rule.Children.Add(Ui.Txt(action, Theme.TCaption, on ? Theme.Warning : Theme.FgHint, FontWeights.SemiBold));
            body.Children.Add(rule);
            Grid.SetColumn(body, 0); g.Children.Add(body);

            var tog = Ui.Toggle(on); tog.VerticalAlignment = VerticalAlignment.Center;
            Grid.SetColumn(tog, 1); g.Children.Add(tog);

            var row = new Border { Child = g, Padding = new Thickness(0, Theme.S3, 0, Theme.S3) };
            if (divider) { row.BorderBrush = Theme.Border; row.BorderThickness = new Thickness(0, 0, 0, 1); }
            return row;
        }
    }
}
