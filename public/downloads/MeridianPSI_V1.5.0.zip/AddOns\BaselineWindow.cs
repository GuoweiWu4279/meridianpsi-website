// BaselineWindow.cs
//
// "My Trading Profile" viewer — shows the user's accumulated baseline
// statistics in natural language, maturity indicators, and a reset option.
// Read-only except for the Reset function. No NinjaTrader API dependencies
// beyond the WPF UI framework.
//
// Apple dark-mode style consistent with HistoryWindow / SessionReportWindow.

using System;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal sealed class BaselineWindow : Window
    {
        public event Action ResetRequested;
        public event Action ClearHistoryRequested;

        private readonly TradeBaseline   _baseline;
        private readonly StrategyProfile _profile;
        // Final PSI of the most recent ARCHIVED session (from SessionHistoryStore),
        // so the "Last Session PSI" tile matches what Session/History show. The
        // baseline's own LastSessionFinalPsi is a live-only carry value (Playback
        // sessions are excluded from the baseline) and must not be shown here, or it
        // reads the default 100 while History shows the real Playback result.
        private readonly double?         _lastRecordedSessionPsi;

        // ── Palette (matches HistoryWindow) ──────────────────────────────────
        private static readonly Brush FgPrimary   = new SolidColorBrush(Color.FromRgb(250, 250, 250));
        private static readonly Brush FgSecondary = new SolidColorBrush(Color.FromRgb(180, 180, 189));
        private static readonly Brush FgHint      = Theme.FgHint;
        private static readonly Brush FgAccent    = Theme.Accent;     // shadcn green (was indigo)
        private static readonly Brush BgWindow    = Theme.BgWindow;   // shadcn canvas
        private static readonly Brush BgCard      = Theme.BgCard;     // shadcn card
        private static readonly Brush BgHeader    = Theme.BgElevated;
        private static readonly Brush BgRed       = new SolidColorBrush(Color.FromRgb( 55,  30,  30));
        private static readonly Color ColStable   = Color.FromRgb( 16, 185, 129);
        private static readonly Color ColCaution  = Color.FromRgb(215, 181,  73);

        // =====================================================================
        // Constructor
        // =====================================================================

        public BaselineWindow(TradeBaseline baseline, StrategyProfile profile,
                              double? lastRecordedSessionPsi = null)
        {
            _baseline = baseline ?? new TradeBaseline();
            _profile  = profile  ?? new StrategyProfile();
            _lastRecordedSessionPsi = lastRecordedSessionPsi;

            WindowStyle        = WindowStyle.None;
            AllowsTransparency = true;
            Background         = Brushes.Transparent;
            ResizeMode         = ResizeMode.CanResizeWithGrip;
            ShowInTaskbar      = true;
            Title              = "My Trading Profile";
            Width              = 900;
            Height             = 660;
            MinWidth           = 720;
            MinHeight          = 480;
            Left = (SystemParameters.WorkArea.Width  - Width)  / 2;
            Top  = (SystemParameters.WorkArea.Height - Height) / 2;

            var card = new Border
            {
                CornerRadius    = new CornerRadius(14),
                Background      = BgWindow,
                BorderBrush     = new SolidColorBrush(Color.FromArgb(40, 255, 255, 255)),
                BorderThickness = new Thickness(1),
                ClipToBounds    = true,
            };

            var root = new Grid();
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(44) });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });

            // ── Header bar ─────────────────────────────────────────────────────
            var hdrBorder = new Border { Background = BgHeader };
            hdrBorder.MouseLeftButtonDown += (s, e) => DragMove();

            var hdrGrid = new Grid();
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            hdrGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var titleText = new TextBlock
            {
                Text              = "My Trading Profile",
                Foreground        = FgPrimary,
                FontSize          = 12,
                FontWeight        = FontWeights.SemiBold,
                VerticalAlignment = VerticalAlignment.Center,
                Margin            = new Thickness(16, 0, 0, 0),
            };
            Grid.SetColumn(titleText, 0);

            var closeBtn = MakeHeaderButton("\u2715");
            closeBtn.ToolTip = "Close";
            closeBtn.MouseLeftButtonDown += (s, e) => { e.Handled = true; Close(); };
            Grid.SetColumn(closeBtn, 1);

            hdrGrid.Children.Add(titleText);
            hdrGrid.Children.Add(closeBtn);
            hdrBorder.Child = hdrGrid;
            Grid.SetRow(hdrBorder, 0);
            root.Children.Add(hdrBorder);

            // ── Body ───────────────────────────────────────────────────────────
            var scroll = new ScrollViewer
            {
                VerticalScrollBarVisibility   = ScrollBarVisibility.Auto,
                HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                Padding                       = new Thickness(0),
            };

            var body = new StackPanel { Margin = new Thickness(20, 16, 20, 20) };

            // ── Maturity indicator ──────────────────────────────────────────────
            int sessions = _baseline.SessionCount;
            int totalN   = _baseline.MuLoss.N + _baseline.MuSize.N;
            bool mature  = sessions >= 5 && totalN >= 30;

            var maturityCard = new Border
            {
                Background   = BgCard,
                CornerRadius = new CornerRadius(10),
                Padding      = new Thickness(16, 12, 16, 12),
                Margin       = new Thickness(0, 0, 0, 16),
            };

            var matStack = new StackPanel();
            var matTitle = new StackPanel { Orientation = Orientation.Horizontal };

            var matDot = new Ellipse
            {
                Width  = 10,
                Height = 10,
                Fill   = new SolidColorBrush(mature ? ColStable : ColCaution),
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(0, 0, 8, 0),
            };

            var matLabel = new TextBlock
            {
                Text       = mature ? "Baseline Calibrated" : "Baseline Learning",
                FontSize   = 14,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgPrimary,
            };

            matTitle.Children.Add(matDot);
            matTitle.Children.Add(matLabel);
            matStack.Children.Add(matTitle);

            string matDesc = mature
                ? $"Your profile has been trained on {sessions} sessions and {totalN}+ data points. " +
                  "The PSI engine is using your personal trading patterns for maximum accuracy."
                : $"Your profile is still learning. " +
                  $"{(sessions == 0 ? "No sessions" : sessions == 1 ? "1 session" : $"{sessions} sessions")} recorded so far — " +
                  $"the engine needs about 5 sessions and 30+ trades for full calibration. " +
                  "Until then, PSI uses conservative defaults blended with your emerging patterns.";

            matStack.Children.Add(new TextBlock
            {
                Text         = matDesc,
                FontSize     = 11,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 6, 0, 0),
            });

            int pct = mature ? 100 : Math.Min(99, (int)(100.0 * Math.Min(sessions / 5.0, totalN / 30.0)));
            var progBg = new Border
            {
                Background   = new SolidColorBrush(Color.FromRgb(38, 38, 41)),
                CornerRadius = new CornerRadius(3),
                Height       = 6,
                Margin       = new Thickness(0, 10, 0, 0),
            };
            var progFill = new Border
            {
                Background            = new SolidColorBrush(mature ? ColStable : ColCaution),
                CornerRadius          = new CornerRadius(3),
                Height                = 6,
                HorizontalAlignment   = HorizontalAlignment.Left,
                Width                 = 0, // set after layout
            };
            progBg.Child = progFill;
            progBg.SizeChanged += (_, ev) =>
            {
                progFill.Width = ev.NewSize.Width * pct / 100.0;
            };

            string calibText;
            if (mature)
                calibText = $"{pct}% calibrated — fully personalised";
            else
            {
                int sessNeed  = Math.Max(0, 5  - sessions);
                int tradeNeed = Math.Max(0, 30 - totalN);
                var need = new System.Collections.Generic.List<string>();
                if (sessNeed  > 0) need.Add($"{sessNeed} more session{(sessNeed  != 1 ? "s" : "")}");
                if (tradeNeed > 0) need.Add($"{tradeNeed} more trade{(tradeNeed != 1 ? "s" : "")}");
                calibText = need.Count > 0
                    ? $"{pct}% calibrated — needs {string.Join(" and ", need)}"
                    : $"{pct}% calibrated — almost there";
            }

            var progLabel = new TextBlock
            {
                Text       = calibText,
                FontSize   = 10,
                Foreground = FgHint,
                Margin     = new Thickness(0, 4, 0, 0),
            };

            matStack.Children.Add(progBg);
            matStack.Children.Add(progLabel);
            maturityCard.Child = matStack;
            body.Children.Add(maturityCard);

            // ── Baseline Statistics ─────────────────────────────────────────────
            body.Children.Add(SectionLabel("Your baseline"));

            // 3-column grid of the learned-stat cards (2 rows × 3 cols), matching the
            // approved mockup. Cards themselves are unchanged — only placed into cells.
            var statGrid = new Grid { Margin = new Thickness(0, 0, 0, 8) };
            statGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            statGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            statGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            statGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            statGrid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var statCards = new Border[]
            {
                StatCard("Average Loss Size",
                    FormatMuLoss(),
                    "The typical dollar amount you lose on a losing trade. " +
                    "Used to detect unusually large losses that may indicate emotional trading."),
                StatCard("Position Size",
                    FormatMuSize(),
                    "Your normal trading size. Positions significantly larger than this " +
                    "trigger the Size Outlier (D3) signal."),
                StatCard("Risk:Reward Ratio",
                    FormatRiskReward(),
                    "Your average win amount divided by your average loss. " +
                    "Tracks consistency of your trade management."),
                StatCard("Win Hold Time",
                    FormatHoldTime(_baseline.WinHold, "winning"),
                    "How long you typically hold winning trades. " +
                    "Used to detect premature exits after a loss."),
                StatCard("Loss Hold Time",
                    FormatHoldTime(_baseline.LossHold, "losing"),
                    "How long you typically hold losing trades. " +
                    "Used to detect position overstay (D5)."),
                StatCard("Loss Hold Percentiles",
                    FormatLossPercentiles(),
                    "The median (p50) and 90th percentile (p90) of your losing-trade " +
                    "hold times. Beyond p90 the system considers you to be overstaying."),
            };

            for (int i = 0; i < statCards.Length; i++)
            {
                var c = statCards[i];
                int col = i % 3;
                int row = i / 3;
                // Even gutters between cells (override only the card's outer margin).
                c.Margin = new Thickness(col == 0 ? 0 : 4, 0, col == 2 ? 0 : 4, 8);
                Grid.SetColumn(c, col);
                Grid.SetRow(c, row);
                statGrid.Children.Add(c);
            }
            body.Children.Add(statGrid);

            // ── Data summary ────────────────────────────────────────────────────
            body.Children.Add(SectionLabel("Data summary"));

            var summaryGrid = new Grid { Margin = new Thickness(0, 0, 0, 16) };
            summaryGrid.ColumnDefinitions.Add(new ColumnDefinition());
            summaryGrid.ColumnDefinitions.Add(new ColumnDefinition());
            summaryGrid.ColumnDefinitions.Add(new ColumnDefinition());

            var tSessions = TileBlock("Sessions",       sessions > 0 ? sessions.ToString() : "\u2014");
            var tTrades   = TileBlock("Total Trades",   totalN   > 0 ? totalN.ToString()   : "\u2014");
            var tLastPsi  = TileBlock("Last Session PSI",
                _lastRecordedSessionPsi.HasValue ? _lastRecordedSessionPsi.Value.ToString("F0") : "\u2014");

            Grid.SetColumn(tSessions, 0); summaryGrid.Children.Add(tSessions);
            Grid.SetColumn(tTrades,   1); summaryGrid.Children.Add(tTrades);
            Grid.SetColumn(tLastPsi,  2); summaryGrid.Children.Add(tLastPsi);
            body.Children.Add(summaryGrid);

            // ── Test Mode toggle ────────────────────────────────────────────────
            body.Children.Add(SectionLabel("Test mode"));

            bool testActive = _profile.IsTestModeActive;
            var testCardBorder = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(22, 22, 25)),
                CornerRadius    = new CornerRadius(8),
                Padding         = new Thickness(14, 12, 14, 12),
                Margin          = new Thickness(0, 0, 0, 8),
                BorderBrush     = new SolidColorBrush(Color.FromArgb(30, 255, 255, 255)),
                BorderThickness = new Thickness(1),
            };
            var testCardStack = new StackPanel();

            var testDescText = new TextBlock
            {
                Text         = "Pause baseline recording so experimental trades don't affect your profile. " +
                               "PSI still runs live — only statistics updates are frozen. " +
                               "Auto-expires after the configured duration (set in Settings → Advanced).",
                FontSize     = 10,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 0, 0, 10),
            };
            testCardStack.Children.Add(testDescText);

            var testToggleRow = new Grid();
            testToggleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            testToggleRow.ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            var testStatusText = new TextBlock
            {
                FontSize          = 11,
                FontFamily        = Theme.Font,
                VerticalAlignment = VerticalAlignment.Center,
            };

            var testToggleBtn = new ToggleButton
            {
                Content           = testActive ? "ON" : "OFF",
                IsChecked         = testActive,
                Width             = 60,
                Height            = 28,
                FontSize          = 10,
                FontWeight        = FontWeights.Bold,
                FontFamily        = Theme.Font,
                Foreground        = testActive ? Theme.AccentInk : Brushes.White,
                Background        = testActive
                    ? new SolidColorBrush(Color.FromRgb(16, 185, 129))
                    : new SolidColorBrush(Color.FromRgb(72, 72, 74)),
                BorderThickness   = new Thickness(0),
                FocusVisualStyle  = null,
                VerticalAlignment = VerticalAlignment.Center,
            };

            void RefreshTestStatus()
            {
                bool active = _profile.IsTestModeActive;
                if (active)
                {
                    testStatusText.Text       = $"Active — {_profile.TestModeRemainingMinutes} min remaining";
                    testStatusText.Foreground = new SolidColorBrush(Color.FromRgb(16, 185, 129));
                }
                else
                {
                    testStatusText.Text       = "Inactive";
                    testStatusText.Foreground = FgHint;
                }
            }
            RefreshTestStatus();

            testToggleBtn.Checked += (_, __) =>
            {
                _profile.ActivateTestMode();
                _profile.SaveToFile(null);
                testToggleBtn.Content    = "ON";
                testToggleBtn.Background = new SolidColorBrush(Color.FromRgb(16, 185, 129));
                testToggleBtn.Foreground = Theme.AccentInk;
                RefreshTestStatus();
            };
            testToggleBtn.Unchecked += (_, __) =>
            {
                _profile.DeactivateTestMode();
                _profile.SaveToFile(null);
                testToggleBtn.Content    = "OFF";
                testToggleBtn.Background = new SolidColorBrush(Color.FromRgb(72, 72, 74));
                testToggleBtn.Foreground = Brushes.White;
                RefreshTestStatus();
            };

            Grid.SetColumn(testStatusText, 0); testToggleRow.Children.Add(testStatusText);
            Grid.SetColumn(testToggleBtn,  1); testToggleRow.Children.Add(testToggleBtn);
            testCardStack.Children.Add(testToggleRow);
            testCardBorder.Child = testCardStack;
            body.Children.Add(testCardBorder);

            // ── Reset button ────────────────────────────────────────────────────
            body.Children.Add(SectionLabel("Danger zone"));

            var resetBtn = new Border
            {
                Background      = BgRed,
                CornerRadius    = new CornerRadius(8),
                Padding         = new Thickness(16, 10, 16, 10),
                Margin          = new Thickness(0, 0, 0, 8),
                Cursor          = Cursors.Hand,
                BorderBrush     = new SolidColorBrush(Color.FromRgb(226, 86, 78)),
                BorderThickness = new Thickness(1),
            };

            var resetStack = new StackPanel();
            resetStack.Children.Add(new TextBlock
            {
                Text       = "Reset Baseline",
                FontSize   = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(226, 86, 78)),
            });
            resetStack.Children.Add(new TextBlock
            {
                Text         = "Erase all historical trading data and start fresh. " +
                               "The PSI engine will revert to conservative defaults until " +
                               "enough new data is collected. This cannot be undone.",
                FontSize     = 10,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 4, 0, 0),
            });
            resetBtn.Child = resetStack;
            resetBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                OnResetClicked();
            };
            body.Children.Add(resetBtn);

            // ── Clear session history (data management) ──────────────────────
            var clearBtn = new Border
            {
                Background      = new SolidColorBrush(Color.FromRgb(38, 28, 28)),
                CornerRadius    = new CornerRadius(8),
                Padding         = new Thickness(16, 10, 16, 10),
                Margin          = new Thickness(0, 0, 0, 8),
                Cursor          = Cursors.Hand,
                BorderBrush     = new SolidColorBrush(Color.FromRgb(226, 86, 78)),
                BorderThickness = new Thickness(1),
            };
            var clearStack = new StackPanel();
            clearStack.Children.Add(new TextBlock
            {
                Text       = "Clear Session History",
                FontSize   = 13,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(226, 86, 78)),
            });
            clearStack.Children.Add(new TextBlock
            {
                Text         = "Deletes all session log entries. Does not affect your statistical baseline.",
                FontSize     = 10,
                Foreground   = FgSecondary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 4, 0, 0),
            });
            clearBtn.Child = clearStack;
            clearBtn.MouseLeftButtonDown += (_, e) =>
            {
                e.Handled = true;
                var result = System.Windows.MessageBox.Show(
                    "This will permanently delete all session history entries.\n\n" +
                    "Your statistical baseline is NOT affected — only the session log will be cleared.\n\n" +
                    "Are you sure?",
                    "Clear Session History",
                    System.Windows.MessageBoxButton.YesNo,
                    System.Windows.MessageBoxImage.Warning,
                    System.Windows.MessageBoxResult.No);

                if (result == System.Windows.MessageBoxResult.Yes)
                    ClearHistoryRequested?.Invoke();
            };
            body.Children.Add(clearBtn);

            scroll.Content = body;
            Grid.SetRow(scroll, 1);
            root.Children.Add(scroll);

            card.Child = root;
            Content    = card;
        }

        // =====================================================================
        // Reset confirmation
        // =====================================================================

        private void OnResetClicked()
        {
            var result = MessageBox.Show(
                "This will permanently erase your trading baseline.\n\n" +
                "All accumulated statistics (average loss, position size, hold times, " +
                "win/loss patterns) will be deleted. The PSI engine will revert to " +
                "conservative default values and will need 5+ sessions to re-calibrate.\n\n" +
                "Your session history log is NOT affected — use the History page to clear that separately.\n\n" +
                "Are you absolutely sure?",
                "Reset Trading Baseline",
                MessageBoxButton.YesNo,
                MessageBoxImage.Warning,
                MessageBoxResult.No);

            if (result == MessageBoxResult.Yes)
            {
                var confirm = MessageBox.Show(
                    "Final confirmation: type-to-confirm is not available, so this is your " +
                    "last chance.\n\nClick YES to permanently delete all baseline data.",
                    "Confirm Reset",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Stop,
                    MessageBoxResult.No);

                if (confirm == MessageBoxResult.Yes)
                    ResetRequested?.Invoke();
            }
        }

        // =====================================================================
        // Natural-language formatters
        // =====================================================================

        private string FormatMuLoss()
        {
            var s = _baseline.MuLoss;
            if (s.N < 3) return "Building your profile — calibrates after 3+ losing trades.";
            return $"${s.Mean:F0} average loss (σ = ${s.StdDev:F0}) based on {s.N} trades.";
        }

        private string FormatMuSize()
        {
            var s = _baseline.MuSize;
            if (s.N < 3) return "Building your profile — calibrates after 3+ trades.";
            double effective = _baseline.GetEffectiveMuSize(_profile);
            return $"{effective:F1} contracts/lots (σ = {s.StdDev:F2}) " +
                   $"based on {s.N} trades.";
        }

        private string FormatHoldTime(WelfordStat stat, string label)
        {
            if (stat.N < 3) return $"Building your profile — calibrates after 3+ {label} trades.";
            string meanStr = FormatSeconds(stat.Mean);
            string sdStr   = FormatSeconds(stat.StdDev);
            return $"{meanStr} average (σ = {sdStr}) based on {stat.N} {label} trades.";
        }

        private string FormatRiskReward()
        {
            var s = _baseline.RiskReward;
            if (s.N < 5) return "Building your profile — calibrates after 5+ round-trips.";
            return $"{s.Mean:F2} : 1 average (σ = {s.StdDev:F2}) based on {s.N} trades.";
        }

        private string FormatLossPercentiles()
        {
            int n = _baseline.LossHoldTimeSamples.Count;
            if (n < 20) return $"Building your profile — calibrates after 20+ closing trades ({n} so far).";
            double p50 = _baseline.GetP50LossHold(_profile);
            double p90 = _baseline.GetP90LossHold(_profile);
            return $"Median (p50): {FormatSeconds(p50)}  •  90th percentile: {FormatSeconds(p90)}  " +
                   $"({n} samples)";
        }

        private static string FormatSeconds(double sec)
        {
            if (sec < 60)   return $"{sec:F0}s";
            if (sec < 3600) return $"{sec / 60.0:F1}m";
            return $"{sec / 3600.0:F1}h";
        }

        // =====================================================================
        // UI factory helpers
        // =====================================================================

        private static Border StatCard(string title, string value, string tooltip)
        {
            var card = new Border
            {
                Background   = BgCard,
                CornerRadius = new CornerRadius(8),
                Padding      = new Thickness(14, 10, 14, 10),
                Margin       = new Thickness(0, 0, 0, 6),
                ToolTip      = tooltip,
            };

            var stack = new StackPanel();
            stack.Children.Add(new TextBlock
            {
                Text       = title,
                FontSize   = 10,
                FontWeight = FontWeights.SemiBold,
                Foreground = FgHint,
            });
            stack.Children.Add(new TextBlock
            {
                Text         = value,
                FontSize     = 12,
                Foreground   = FgPrimary,
                TextWrapping = TextWrapping.Wrap,
                Margin       = new Thickness(0, 4, 0, 0),
            });

            card.Child = stack;
            return card;
        }

        private static TextBlock SectionLabel(string text)
        {
            return new TextBlock
            {
                Text       = text,
                FontSize   = Theme.TSubhead,
                FontWeight = FontWeights.SemiBold,
                Foreground = Theme.FgSecondary,
                Margin     = new Thickness(0, 8, 0, 8),
            };
        }

        private static Border TileBlock(string label, string value)
        {
            var tile = new Border
            {
                Background   = BgCard,
                CornerRadius = new CornerRadius(8),
                Padding      = new Thickness(10, 8, 10, 8),
                Margin       = new Thickness(2, 0, 2, 0),
            };

            var stack = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
            stack.Children.Add(new TextBlock
            {
                Text                = value,
                FontSize            = 18,
                FontWeight          = FontWeights.Bold,
                Foreground          = FgPrimary,
                HorizontalAlignment = HorizontalAlignment.Center,
            });
            stack.Children.Add(new TextBlock
            {
                Text                = label,
                FontSize            = 9,
                Foreground          = FgHint,
                HorizontalAlignment = HorizontalAlignment.Center,
                Margin              = new Thickness(0, 2, 0, 0),
            });
            tile.Child = stack;
            return tile;
        }

        private static Border MakeHeaderButton(string glyph)
        {
            var lbl = new TextBlock
            {
                Text                = glyph,
                FontSize            = 14,
                Foreground          = FgSecondary,
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment   = VerticalAlignment.Center,
            };
            var btn = new Border
            {
                Width               = 36,
                Height              = 36,
                Background          = Brushes.Transparent,
                Cursor              = Cursors.Hand,
                Child               = lbl,
                VerticalAlignment   = VerticalAlignment.Center,
            };
            btn.MouseEnter += (_, __) => btn.Background =
                new SolidColorBrush(Color.FromArgb(40, 255, 255, 255));
            btn.MouseLeave += (_, __) => btn.Background = Brushes.Transparent;
            return btn;
        }
    }
}
