// MeridianDevTools.cs
//
// Optional developer-tool bridge.  Production code calls these helpers instead
// of referencing GuardTestRunner / PsiTestRunnerV2 / etc. directly.
//
// When the Developer\*.cs files are present they are invoked via reflection.
// When they are absent (release export without dev tools) the UI shows a
// short message and the product compiles cleanly — no CS0246 errors.

using System;
using System.Reflection;

namespace NinjaTrader.NinjaScript.AddOns
{
    internal static class MeridianDevTools
    {
        private const string AssemblyName = "NinjaTrader.Custom";

        public static bool IsAvailable(string typeName) =>
            Type.GetType($"NinjaTrader.NinjaScript.AddOns.{typeName}, {AssemblyName}") != null;

        public static bool PsiV1RunOnStartup
        {
            get
            {
                var f = GetField("PsiTestRunner", "RunOnStartup");
                return f != null && f.FieldType == typeof(bool) && (bool)f.GetValue(null);
            }
        }

        public static string RunPsiV1Tests() =>
            InvokeStaticString("PsiTestRunner", "RunAll");

        public static string RunPsiV2Tests() =>
            InvokeStaticString("PsiTestRunnerV2", "RunAll");

        public static string RunGuardTests() =>
            InvokeStaticString("GuardTestRunner", "RunAll");

        public static bool FlattenRunOnStartup
        {
            get
            {
                var f = GetField("FlattenVerifierTests", "RunOnStartup");
                return f != null && f.FieldType == typeof(bool) && (bool)f.GetValue(null);
            }
        }

        public static string RunFlattenTests() =>
            InvokeStaticString("FlattenVerifierTests", "RunAll");

        public static string SeedDemoData(Action<string> logLine) =>
            InvokeStaticStringWithCallback("DemoDataSeeder", "Seed", logLine);

        /// <summary>steps, violations, results file path (null if tool missing).</summary>
        public static (int steps, int violations, string path) RunReplayFile(string csvPath, string outDir)
        {
            var t = GetType("LogReplayHarness");
            if (t == null) return (0, 0, null);
            try
            {
                var m = t.GetMethod("RunFile", BindingFlags.Public | BindingFlags.Static);
                if (m == null) return (0, 0, null);
                object result = m.Invoke(null, new object[] { csvPath, outDir });
                if (result == null) return (0, 0, null);
                object report = result.GetType().GetProperty("Item1")?.GetValue(result);
                string path   = (string)result.GetType().GetProperty("Item2")?.GetValue(result);
                if (report == null) return (0, 0, path);
                int steps = (int)(report.GetType().GetProperty("TotalSteps")?.GetValue(report) ?? 0);
                int viol  = (int)(report.GetType().GetProperty("TotalViolations")?.GetValue(report) ?? 0);
                return (steps, viol, path);
            }
            catch
            {
                return (0, 0, null);
            }
        }

        public static (int pass, int fail, int seed, string path) RunPropertyFuzzer(int count, string outDir)
        {
            var t = GetType("PropertyFuzzer");
            if (t == null) return (0, 0, 0, null);
            try
            {
                var m = t.GetMethod("RunAndWrite", BindingFlags.Public | BindingFlags.Static);
                if (m == null) return (0, 0, 0, null);
                object result = m.Invoke(null, new object[] { count, outDir });
                if (result == null) return (0, 0, 0, null);
                var rep  = result.GetType().GetProperty("Item1")?.GetValue(result);
                var path = (string)result.GetType().GetProperty("Item2")?.GetValue(result);
                if (rep == null) return (0, 0, 0, path);
                int pass = (int)(rep.GetType().GetProperty("PassCount")?.GetValue(rep) ?? 0);
                int fail = (int)(rep.GetType().GetProperty("FailCount")?.GetValue(rep) ?? 0);
                int seed = (int)(rep.GetType().GetProperty("MasterSeed")?.GetValue(rep) ?? 0);
                return (pass, fail, seed, path);
            }
            catch (Exception ex)
            {
                return (0, 1, 0, "Fuzz error: " + ex.Message);
            }
        }

        public static string NotInstalledMessage =>
            "Developer tools not in this build. Copy the Developer\\ folder from the full repo, then recompile.";

        // ── reflection helpers ────────────────────────────────────────────────

        private static Type GetType(string shortName) =>
            Type.GetType($"NinjaTrader.NinjaScript.AddOns.{shortName}, {AssemblyName}");

        private static FieldInfo GetField(string typeName, string fieldName) =>
            GetType(typeName)?.GetField(fieldName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);

        private static string InvokeStaticString(string typeName, string methodName)
        {
            var t = GetType(typeName);
            if (t == null) return NotInstalledMessage;
            try
            {
                var m = t.GetMethod(methodName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
                if (m == null) return $"{typeName}.{methodName} not found.";
                return (string)m.Invoke(null, null) ?? "(no output)";
            }
            catch (TargetInvocationException ex)
            {
                return $"{typeName} threw: {ex.InnerException?.Message ?? ex.Message}";
            }
            catch (Exception ex)
            {
                return $"{typeName} error: {ex.Message}";
            }
        }

        private static string InvokeStaticStringWithCallback(string typeName, string methodName, Action<string> cb)
        {
            var t = GetType(typeName);
            if (t == null) return NotInstalledMessage;
            try
            {
                var m = t.GetMethod(methodName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
                if (m == null) return $"{typeName}.{methodName} not found.";
                return (string)m.Invoke(null, new object[] { cb }) ?? "(no output)";
            }
            catch (TargetInvocationException ex)
            {
                return $"{typeName} threw: {ex.InnerException?.Message ?? ex.Message}";
            }
            catch (Exception ex)
            {
                return $"{typeName} error: {ex.Message}";
            }
        }
    }
}
